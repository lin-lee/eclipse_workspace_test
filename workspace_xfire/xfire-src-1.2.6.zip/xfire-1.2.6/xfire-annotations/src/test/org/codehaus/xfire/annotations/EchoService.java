package org.codehaus.xfire.annotations;

/**
 * @author Arjen Poutsma
 */
public interface EchoService
{
    public String echo(String input);
}
