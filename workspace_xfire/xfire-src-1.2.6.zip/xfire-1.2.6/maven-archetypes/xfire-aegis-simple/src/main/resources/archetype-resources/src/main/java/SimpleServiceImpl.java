package ${groupId};


public class SimpleServiceImpl {
	

 public String  echoMethod(String value){
	 return value;
 }
}
