package org.codehaus.xfire.aegis.type.collection;

import java.util.List;

public class TestBean
{
    private List strings;
    private List doubles;
    
    public List getDoubles()
    {
        return doubles;
    }
    public void setDoubles(List doubles)
    {
        this.doubles = doubles;
    }
    public List getStrings()
    {
        return strings;
    }
    public void setStrings(List strings)
    {
        this.strings = strings;
    }
}
