package org.codehaus.xfire.type.basic.intf;

public interface BeanServiceIntf extends BeanIgnoredIntf
{
    BeanIntf getBeanIntf();
}
