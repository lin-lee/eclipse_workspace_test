package org.codehaus.xfire.aegis.type.collection.bean;

import java.util.Map;

public class MapBean
{
    private Map map;

    public Map getMap()
    {
        return map;
    }

    public void setMap(Map map)
    {
        this.map = map;
    }
}
