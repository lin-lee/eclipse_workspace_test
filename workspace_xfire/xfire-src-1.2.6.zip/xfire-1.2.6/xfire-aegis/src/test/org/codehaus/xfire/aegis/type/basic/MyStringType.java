package org.codehaus.xfire.aegis.type.basic;

public class MyStringType extends StringType
{

}
