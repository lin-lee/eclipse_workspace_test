package org.codehaus.xfire.aegis.inheritance.xfire704;

public class TestValue
{

}
