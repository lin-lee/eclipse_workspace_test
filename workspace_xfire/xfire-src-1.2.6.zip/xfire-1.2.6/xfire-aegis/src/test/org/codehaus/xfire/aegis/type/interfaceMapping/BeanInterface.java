package org.codehaus.xfire.aegis.type.interfaceMapping;

public interface BeanInterface extends ParentBeanInterface {

	String getHiddenName();
}
