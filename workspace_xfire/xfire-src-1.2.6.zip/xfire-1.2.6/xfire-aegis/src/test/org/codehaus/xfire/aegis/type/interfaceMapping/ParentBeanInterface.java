package org.codehaus.xfire.aegis.type.interfaceMapping;

public interface ParentBeanInterface {

	String getHiddenParentName();

}
