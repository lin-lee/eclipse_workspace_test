package org.codehaus.xfire.aegis.inheritance.xfire704.response;

public class TestBaseResponse
{

}
