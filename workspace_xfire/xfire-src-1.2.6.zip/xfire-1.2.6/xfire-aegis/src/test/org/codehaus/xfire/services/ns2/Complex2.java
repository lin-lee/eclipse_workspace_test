package org.codehaus.xfire.services.ns2;

public class Complex2
{
    private String property;

    public String getProperty()
    {
        return property;
    }

    public void setProperty(String property)
    {
        this.property = property;
    }
}
