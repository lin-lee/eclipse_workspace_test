package org.codehaus.xfire.aegis.inheritance.intf;

public interface IParent  {
    String getParentName();
}
