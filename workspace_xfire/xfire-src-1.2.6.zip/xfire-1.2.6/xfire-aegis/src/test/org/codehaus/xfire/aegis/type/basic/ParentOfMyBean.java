package org.codehaus.xfire.aegis.type.basic;

/**
 * SomeBean
 * 
 * @author <a href="mailto:dan@envoisolutions.com">Dan Diephouse</a>
 */
public class ParentOfMyBean
    extends MyBean
{
}
