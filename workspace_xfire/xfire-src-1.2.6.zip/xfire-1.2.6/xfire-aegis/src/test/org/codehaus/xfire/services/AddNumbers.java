package org.codehaus.xfire.services;

public class AddNumbers
{
    public int add(int one, int two)
    {
        return one+two;
    }
}
