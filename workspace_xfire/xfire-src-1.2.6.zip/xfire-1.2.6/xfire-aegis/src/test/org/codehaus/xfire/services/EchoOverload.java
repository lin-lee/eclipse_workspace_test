package org.codehaus.xfire.services;

public interface EchoOverload
{
    public String echo( String echo );
    
    public String echo( String echo, String echo2 );
}
