package org.codehaus.xfire.configuration;

public class EchoImpl {

	public String getEchoMsg(int param1, String value2){
		return "";
	}
}
