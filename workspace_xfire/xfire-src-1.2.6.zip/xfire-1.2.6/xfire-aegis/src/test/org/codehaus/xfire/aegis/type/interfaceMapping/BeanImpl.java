package org.codehaus.xfire.aegis.type.interfaceMapping;

public class BeanImpl implements BeanInterface {
	
	private String hiddenName;

	public String getHiddenName() {
		return hiddenName;
	}

	public void setHiddenName(String hiddenName) {
		this.hiddenName = hiddenName;
	}

	public String getHiddenParentName() {
		return hiddenName;
	}
	
}
