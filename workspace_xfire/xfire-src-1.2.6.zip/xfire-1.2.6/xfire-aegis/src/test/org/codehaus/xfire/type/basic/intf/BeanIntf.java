package org.codehaus.xfire.type.basic.intf;

public interface BeanIntf
{
    void setName(String name);
    String getName();
}
