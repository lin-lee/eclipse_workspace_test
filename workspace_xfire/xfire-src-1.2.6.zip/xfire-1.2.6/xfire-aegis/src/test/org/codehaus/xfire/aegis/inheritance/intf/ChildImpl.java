package org.codehaus.xfire.aegis.inheritance.intf;

public class ChildImpl implements IChild {

    public String getChildName() {
        return "child";
    }

    public String getParentName() {
        return "parent";
    }

}
