package org.codehaus.xfire.services;

import org.codehaus.xfire.services.ns1.Complex1;

public class ComplexService
{
    public Complex1 getComplex1()
    {
        Complex1 c1 = new Complex1();
     
        return c1;
    }

}
