package org.codehaus.xfire.aegis.type.collection;

public class InheritanceTestBean extends TestBean {
	private String property;

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}
	
}
