package org.codehaus.xfire.aegis.type.basic;

import java.util.List;

public class ListHolderBean
{
    private List beans;

    public List getBeans()
    {
        return beans;
    }

    public void setBeans(List beans)
    {
        this.beans = beans;
    }
}
