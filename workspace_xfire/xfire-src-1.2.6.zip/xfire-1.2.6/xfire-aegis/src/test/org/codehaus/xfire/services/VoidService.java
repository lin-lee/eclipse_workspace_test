package org.codehaus.xfire.services;

public class VoidService
{
    public void doNothing()
    {
    }
}
