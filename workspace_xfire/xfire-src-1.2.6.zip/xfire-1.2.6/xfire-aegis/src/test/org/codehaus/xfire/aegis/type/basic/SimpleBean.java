package org.codehaus.xfire.aegis.type.basic;

/**
 * SomeBean
 * 
 * @author <a href="mailto:dan@envoisolutions.com">Dan Diephouse</a>
 */
public class SimpleBean
{
    private String bleh;
    
    private String howdy;

    public String getBleh()
    {
        return bleh;
    }

    public void setBleh(String bleh)
    {
        this.bleh = bleh;
    }
    
    public String getHowdy()
    {
        return howdy;
    }

    public void setHowdy(String howdy)
    {
        this.howdy = howdy;
    }
}
