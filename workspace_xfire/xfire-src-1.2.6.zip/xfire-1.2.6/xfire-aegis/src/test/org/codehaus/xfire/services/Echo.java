package org.codehaus.xfire.services;

/**
 * Echo
 * 
 * @author <a href="mailto:dan@envoisolutions.com">Dan Diephouse</a>
 */
public class Echo
{
    public String echo( String echo )
    {
        return echo;
    }
}
