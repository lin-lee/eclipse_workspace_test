package org.codehaus.xfire.aegis.type.interfaceMapping;

public interface InterfaceService {
	BeanImpl getBean();
}
