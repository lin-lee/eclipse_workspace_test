package org.codehaus.xfire.type.basic.intf;

/**
 * @author Hani Suleiman
 *         Date: Jun 7, 2005
 *         Time: 2:20:08 PM
 */
public interface BeanIgnoredIntf
{
  String getStuff();
}
