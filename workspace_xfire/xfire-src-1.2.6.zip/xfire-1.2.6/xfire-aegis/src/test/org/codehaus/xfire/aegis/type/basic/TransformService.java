package org.codehaus.xfire.aegis.type.basic;

import org.w3c.dom.Document;

public class TransformService
{
    public Document transform(Document style, Document document)
    {
        return document;
    }
}
