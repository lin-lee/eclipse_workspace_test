package org.codehaus.xfire.aegis.inheritance.ws1;

import java.io.Serializable;

/**
 * @author jdavias
 */
public class BeanD
    implements Serializable
{
    private String m_propD;

    public String getM_propD()
    {
        return m_propD;
    }

    public void setM_propD(String m_propD)
    {
        this.m_propD = m_propD;
    }
}
