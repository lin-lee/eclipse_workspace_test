package org.codehaus.xfire.transport.http;

public class SoapActionService
{
    public int one() { return 1; }
    public int two() { return 2; }
}
