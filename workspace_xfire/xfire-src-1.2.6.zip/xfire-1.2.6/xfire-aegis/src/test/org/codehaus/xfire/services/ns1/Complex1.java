package org.codehaus.xfire.services.ns1;

import org.codehaus.xfire.services.ns2.Complex2;

public class Complex1
{
    private Complex2 property;

    public Complex2 getProperty()
    {
        return property;
    }
    
    public void setProperty(Complex2 property)
    {
        this.property = property;
    }
    
}
