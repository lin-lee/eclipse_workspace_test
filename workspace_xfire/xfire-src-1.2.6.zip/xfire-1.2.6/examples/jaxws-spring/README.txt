README
======

The goal of this sample XFire project is how to use:

*) A "contract first" (XML Schema/WSDL, not Java, first)

*) Spring-based server (AKA provider) and client (AKA consumer)

*) JSR181 (JAX-WS) and thus JAXB2 implementation
