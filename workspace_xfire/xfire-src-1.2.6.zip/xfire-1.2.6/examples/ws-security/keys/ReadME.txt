These scripts generate keys used for encryption and digital signature.
clientStore contains client private key ( alias : client-344-839 )  and server public key ( alias : serveralias ).
serverStore contains server private key ( alias : serveralias ) and client public key ( alias : client-344-839 ).
After generation copy serverStore.jks to main/META-INF/xfire and clientStore.jks to  main/org/codehaus/xfire/client.