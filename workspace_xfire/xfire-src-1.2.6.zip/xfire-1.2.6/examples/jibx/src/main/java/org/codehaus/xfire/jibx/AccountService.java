package org.codehaus.xfire.jibx;

/**
 * <a href="mailto:tsztelak@gmail.com">Tomasz Sztelak</a>
 *
 */
public interface AccountService {

	public AccountInfo getAccountStatus(Account param);
}
