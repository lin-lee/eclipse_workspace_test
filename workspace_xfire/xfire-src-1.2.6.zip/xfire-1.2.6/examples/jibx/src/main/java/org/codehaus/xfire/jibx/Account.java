package org.codehaus.xfire.jibx;

/**
 * <a href="mailto:tsztelak@gmail.com">Tomasz Sztelak</a>
 * 
 */
public class Account
{
    private String accountNo;

    public String getAccountNo()
    {
        return accountNo;
    }

    public void setAccountNo(String paramName)
    {
        this.accountNo = paramName;
    }

}
