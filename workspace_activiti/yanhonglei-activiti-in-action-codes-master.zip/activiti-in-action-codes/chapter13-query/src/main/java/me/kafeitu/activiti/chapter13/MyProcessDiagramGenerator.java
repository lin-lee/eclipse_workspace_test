package me.kafeitu.activiti.chapter13;

import org.activiti.image.impl.DefaultProcessDiagramGenerator;

/**
 * @author: Henry Yan
 */
public class MyProcessDiagramGenerator extends DefaultProcessDiagramGenerator {

    // 如果要更改图片生成的逻辑，覆盖默认的内部方法即可

}
