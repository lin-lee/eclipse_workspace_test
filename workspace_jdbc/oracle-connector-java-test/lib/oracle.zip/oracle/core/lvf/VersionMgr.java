// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   VersionMgr.java

package oracle.core.lvf;


public final class VersionMgr
{

    public static final byte ALPHA = 1;
    public static final byte BETA = 2;
    public static final byte PROD = 3;
    public static final byte NONE = 4;
    private final byte MAX_LEN = 64;
    private final byte MAX_PRODLEN = 30;
    private final byte MAX_VERLEN = 15;
    private final byte MAX_DISTLEN = 5;
    private final String alpha = "Alpha";
    private final String beta = "Beta";
    private final String prod = "Production";
    private String version;

    public VersionMgr()
    {
    }

    public void setVersion(String s, byte byte0, byte byte1, byte byte2, byte byte3, byte byte4, char c, 
            String s1, byte byte5, int i)
    {
        char ac[] = new char[64];
        String s3 = "";
        byte byte10;
        if((byte10 = (byte)s.length()) > 30)
            byte10 = 30;
        byte byte9;
        for(byte9 = 0; 0 < byte10--; byte9++)
            ac[byte9] = s.charAt(byte9);

        ac[byte9++] = '\t';
        if(byte0 < 0)
            byte0 = 0;
        if(byte1 < 0)
            byte1 = 0;
        if(byte2 < 0)
            byte2 = 0;
        if(byte3 < 0)
            byte3 = 0;
        if(byte4 < 0)
            byte4 = 0;
        if(byte0 > 99)
            byte0 = 99;
        if(byte1 > 99)
            byte1 = 99;
        if(byte2 > 99)
            byte2 = 99;
        if(byte3 > 99)
            byte3 = 99;
        if(byte4 > 99)
            byte4 = 99;
        String s2;
        if(c != 0)
            s2 = (new StringBuilder()).append(byte0).append(".").append(byte1).append(".").append(byte2).append(".").append(byte3).append(".").append(byte4).append(c).toString();
        else
            s2 = (new StringBuilder()).append(byte0).append(".").append(byte1).append(".").append(byte2).append(".").append(byte3).append(".").append(byte4).toString();
        byte byte11 = (byte)s2.length();
        byte byte6 = 0;
        while(0 < byte11--) 
            ac[byte9++] = s2.charAt(byte6++);
        if(byte5 != 4)
        {
            ac[byte9++] = '\t';
            if(s1 != null)
            {
                byte byte13 = 0;
                if((byte13 = (byte)s1.length()) > 5)
                    byte13 = 5;
                byte byte7 = 0;
                while(0 < byte13--) 
                    ac[byte9++] = s1.charAt(byte7++);
                ac[byte9++] = '\t';
            }
            switch(byte5)
            {
            case 1: // '\001'
                s3 = "Alpha";
                break;

            case 2: // '\002'
                s3 = "Beta";
                break;

            case 3: // '\003'
                s3 = "Production";
                break;
            }
            byte byte8 = 0;
            for(byte byte12 = (byte)s3.length(); 0 < byte12--;)
                ac[byte9++] = s3.charAt(byte8++);

        }
        version = new String(ac, 0, byte9);
    }

    public String getVersion()
    {
        return version;
    }
}
