// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   CoreException.java

package oracle.core.lmx;


public class CoreException extends Exception
{

    public static final byte UNIMPLEMENTED = 1;
    public static final byte UNDERFLOW = 2;
    public static final byte OVERFLOW = 3;
    public static final byte INVALIDORLN = 4;
    public static final byte BADFORMATORLN = 5;
    public static final byte INVALIDORLD = 6;
    public static final byte BADFORMATORLD = 7;
    public static final byte BADYEAR = 8;
    public static final byte BADDAYYEAR = 9;
    public static final byte BADJULIANDATE = 10;
    public static final byte INVALIDINPUTN = 11;
    public static final byte NLSNOTSUPPORTED = 12;
    public static final byte INVALIDINPUT = 13;
    public static final byte CONVERSIONERROR = 14;
    private static final String _errmsgs[] = {
        "Unknown Exception", "Unimplemented method called", "Underflow Exception", "Overflow Exception", "Invalid Oracle Number", "Bad Oracle Number format", "Invalid Oracle Date", "Bad Oracle Date format", "Year Not in Range", "Day of Year Not in Range", 
        "Julian Date Not in Range", "Invalid Input Number", "NLS Not Supported", "Invalid Input", "Conversion Error"
    };
    private byte ecode;

    public CoreException()
    {
    }

    public CoreException(String s)
    {
        super(s);
    }

    public CoreException(byte byte0)
    {
        ecode = byte0;
    }

    public void setErrorCode(byte byte0)
    {
        ecode = byte0;
    }

    public byte getErrorCode()
    {
        return ecode;
    }

    public String getMessage()
    {
        if(ecode == 0)
            return super.getMessage();
        else
            return getMessage(ecode);
    }

    public static String getMessage(byte byte0)
    {
        if(byte0 < 1 || byte0 > 14)
            return "Unknown exception";
        else
            return _errmsgs[byte0];
    }

}
