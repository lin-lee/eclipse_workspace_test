// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AQNotificationRegistration.java

package oracle.jdbc.aq;

import java.sql.SQLException;
import java.util.concurrent.Executor;
import oracle.jdbc.NotificationRegistration;

// Referenced classes of package oracle.jdbc.aq:
//            AQNotificationListener

public interface AQNotificationRegistration
    extends NotificationRegistration
{

    public abstract void addListener(AQNotificationListener aqnotificationlistener)
        throws SQLException;

    public abstract void addListener(AQNotificationListener aqnotificationlistener, Executor executor)
        throws SQLException;

    public abstract void removeListener(AQNotificationListener aqnotificationlistener)
        throws SQLException;

    public abstract String getQueueName();
}
