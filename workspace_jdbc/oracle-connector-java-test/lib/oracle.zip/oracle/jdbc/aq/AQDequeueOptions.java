// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AQDequeueOptions.java

package oracle.jdbc.aq;

import java.sql.SQLException;

public class AQDequeueOptions
{
    public static final class DeliveryFilter extends Enum
    {

        public static final DeliveryFilter PERSISTENT;
        public static final DeliveryFilter BUFFERED;
        public static final DeliveryFilter PERSISTENT_OR_BUFFERED;
        private final int mode;
        private static final DeliveryFilter $VALUES[];

        public static DeliveryFilter[] values()
        {
            return (DeliveryFilter[])$VALUES.clone();
        }

        public static DeliveryFilter valueOf(String s)
        {
            return (DeliveryFilter)Enum.valueOf(oracle/jdbc/aq/AQDequeueOptions$DeliveryFilter, s);
        }

        public final int getCode()
        {
            return mode;
        }

        static 
        {
            PERSISTENT = new DeliveryFilter("PERSISTENT", 0, 1);
            BUFFERED = new DeliveryFilter("BUFFERED", 1, 2);
            PERSISTENT_OR_BUFFERED = new DeliveryFilter("PERSISTENT_OR_BUFFERED", 2, 3);
            $VALUES = (new DeliveryFilter[] {
                PERSISTENT, BUFFERED, PERSISTENT_OR_BUFFERED
            });
        }

        private DeliveryFilter(String s, int i, int j)
        {
            super(s, i);
            mode = j;
        }
    }

    public static final class VisibilityOption extends Enum
    {

        public static final VisibilityOption ON_COMMIT;
        public static final VisibilityOption IMMEDIATE;
        private final int mode;
        private static final VisibilityOption $VALUES[];

        public static VisibilityOption[] values()
        {
            return (VisibilityOption[])$VALUES.clone();
        }

        public static VisibilityOption valueOf(String s)
        {
            return (VisibilityOption)Enum.valueOf(oracle/jdbc/aq/AQDequeueOptions$VisibilityOption, s);
        }

        public final int getCode()
        {
            return mode;
        }

        static 
        {
            ON_COMMIT = new VisibilityOption("ON_COMMIT", 0, 2);
            IMMEDIATE = new VisibilityOption("IMMEDIATE", 1, 1);
            $VALUES = (new VisibilityOption[] {
                ON_COMMIT, IMMEDIATE
            });
        }

        private VisibilityOption(String s, int i, int j)
        {
            super(s, i);
            mode = j;
        }
    }

    public static final class NavigationOption extends Enum
    {

        public static final NavigationOption FIRST_MESSAGE;
        public static final NavigationOption NEXT_MESSAGE;
        public static final NavigationOption NEXT_TRANSACTION;
        private final int mode;
        private static final NavigationOption $VALUES[];

        public static NavigationOption[] values()
        {
            return (NavigationOption[])$VALUES.clone();
        }

        public static NavigationOption valueOf(String s)
        {
            return (NavigationOption)Enum.valueOf(oracle/jdbc/aq/AQDequeueOptions$NavigationOption, s);
        }

        public final int getCode()
        {
            return mode;
        }

        static 
        {
            FIRST_MESSAGE = new NavigationOption("FIRST_MESSAGE", 0, 1);
            NEXT_MESSAGE = new NavigationOption("NEXT_MESSAGE", 1, 3);
            NEXT_TRANSACTION = new NavigationOption("NEXT_TRANSACTION", 2, 2);
            $VALUES = (new NavigationOption[] {
                FIRST_MESSAGE, NEXT_MESSAGE, NEXT_TRANSACTION
            });
        }

        private NavigationOption(String s, int i, int j)
        {
            super(s, i);
            mode = j;
        }
    }

    public static final class DequeueMode extends Enum
    {

        public static final DequeueMode BROWSE;
        public static final DequeueMode LOCKED;
        public static final DequeueMode REMOVE;
        public static final DequeueMode REMOVE_NODATA;
        private final int mode;
        private static final DequeueMode $VALUES[];

        public static DequeueMode[] values()
        {
            return (DequeueMode[])$VALUES.clone();
        }

        public static DequeueMode valueOf(String s)
        {
            return (DequeueMode)Enum.valueOf(oracle/jdbc/aq/AQDequeueOptions$DequeueMode, s);
        }

        public final int getCode()
        {
            return mode;
        }

        static 
        {
            BROWSE = new DequeueMode("BROWSE", 0, 1);
            LOCKED = new DequeueMode("LOCKED", 1, 2);
            REMOVE = new DequeueMode("REMOVE", 2, 3);
            REMOVE_NODATA = new DequeueMode("REMOVE_NODATA", 3, 4);
            $VALUES = (new DequeueMode[] {
                BROWSE, LOCKED, REMOVE, REMOVE_NODATA
            });
        }

        private DequeueMode(String s, int i, int j)
        {
            super(s, i);
            mode = j;
        }
    }


    public static final int DEQUEUE_WAIT_FOREVER = -1;
    public static final int DEQUEUE_NO_WAIT = 0;
    private String attrConsumerName;
    private String attrCorrelation;
    private DequeueMode attrDeqMode;
    private byte attrDeqMsgId[];
    private NavigationOption attrNavigation;
    private VisibilityOption attrVisibility;
    private int attrWait;
    private int maxBufferLength;
    private DeliveryFilter attrDeliveryMode;
    private boolean retrieveMsgId;
    private String transformation;
    private String condition;
    public static final int MAX_RAW_PAYLOAD = 0x3ffffb3;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public AQDequeueOptions()
    {
        attrConsumerName = null;
        attrCorrelation = null;
        attrDeqMode = DequeueMode.REMOVE;
        attrDeqMsgId = null;
        attrNavigation = NavigationOption.NEXT_MESSAGE;
        attrVisibility = VisibilityOption.ON_COMMIT;
        attrWait = -1;
        maxBufferLength = 0x3ffffb3;
        attrDeliveryMode = DeliveryFilter.PERSISTENT;
        retrieveMsgId = false;
    }

    public void setConsumerName(String s)
        throws SQLException
    {
        attrConsumerName = s;
    }

    public String getConsumerName()
    {
        return attrConsumerName;
    }

    public void setCorrelation(String s)
        throws SQLException
    {
        attrCorrelation = s;
    }

    public String getCorrelation()
    {
        return attrCorrelation;
    }

    public void setDequeueMode(DequeueMode dequeuemode)
        throws SQLException
    {
        attrDeqMode = dequeuemode;
    }

    public DequeueMode getDequeueMode()
    {
        return attrDeqMode;
    }

    public void setDequeueMessageId(byte abyte0[])
        throws SQLException
    {
        attrDeqMsgId = abyte0;
    }

    public byte[] getDequeueMessageId()
    {
        return attrDeqMsgId;
    }

    public void setNavigation(NavigationOption navigationoption)
        throws SQLException
    {
        attrNavigation = navigationoption;
    }

    public NavigationOption getNavigation()
    {
        return attrNavigation;
    }

    public void setVisibility(VisibilityOption visibilityoption)
        throws SQLException
    {
        attrVisibility = visibilityoption;
    }

    public VisibilityOption getVisibility()
    {
        return attrVisibility;
    }

    public void setWait(int i)
        throws SQLException
    {
        attrWait = i;
    }

    public int getWait()
    {
        return attrWait;
    }

    public void setMaximumBufferLength(int i)
        throws SQLException
    {
        if(i > 0)
            maxBufferLength = i;
    }

    public int getMaximumBufferLength()
    {
        return maxBufferLength;
    }

    public void setDeliveryFilter(DeliveryFilter deliveryfilter)
        throws SQLException
    {
        attrDeliveryMode = deliveryfilter;
    }

    public DeliveryFilter getDeliveryFilter()
    {
        return attrDeliveryMode;
    }

    public void setRetrieveMessageId(boolean flag)
    {
        retrieveMsgId = flag;
    }

    public boolean getRetrieveMessageId()
    {
        return retrieveMsgId;
    }

    public void setTransformation(String s)
    {
        transformation = s;
    }

    public String getTransformation()
    {
        return transformation;
    }

    public void setCondition(String s)
    {
        condition = s;
    }

    public String getCondition()
    {
        return condition;
    }

}
