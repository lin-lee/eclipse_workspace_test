// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AQFactory.java

package oracle.jdbc.aq;

import java.sql.SQLException;
import oracle.jdbc.driver.InternalFactory;

// Referenced classes of package oracle.jdbc.aq:
//            AQMessageProperties, AQMessage, AQAgent

public abstract class AQFactory
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public AQFactory()
    {
    }

    public static AQMessage createAQMessage(AQMessageProperties aqmessageproperties)
        throws SQLException
    {
        return InternalFactory.createAQMessage(aqmessageproperties);
    }

    public static AQMessageProperties createAQMessageProperties()
        throws SQLException
    {
        return InternalFactory.createAQMessageProperties();
    }

    public static AQAgent createAQAgent()
        throws SQLException
    {
        return InternalFactory.createAQAgent();
    }

}
