// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AQAgent.java

package oracle.jdbc.aq;

import java.sql.SQLException;

public interface AQAgent
{

    public abstract void setAddress(String s)
        throws SQLException;

    public abstract String getAddress();

    public abstract void setName(String s)
        throws SQLException;

    public abstract String getName();

    public abstract void setProtocol(int i)
        throws SQLException;

    public abstract int getProtocol();

    public abstract String toString();
}
