// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AQMessageProperties.java

package oracle.jdbc.aq;

import java.sql.SQLException;
import java.sql.Timestamp;

// Referenced classes of package oracle.jdbc.aq:
//            AQAgent

public interface AQMessageProperties
{
    public static final class DeliveryMode extends Enum
    {

        public static final DeliveryMode PERSISTENT;
        public static final DeliveryMode BUFFERED;
        private final int code;
        private static final DeliveryMode $VALUES[];

        public static DeliveryMode[] values()
        {
            return (DeliveryMode[])$VALUES.clone();
        }

        public static DeliveryMode valueOf(String s)
        {
            return (DeliveryMode)Enum.valueOf(oracle/jdbc/aq/AQMessageProperties$DeliveryMode, s);
        }

        public final int getCode()
        {
            return code;
        }

        public static final DeliveryMode getDeliveryMode(int i)
        {
            if(i == BUFFERED.getCode())
                return BUFFERED;
            else
                return PERSISTENT;
        }

        static 
        {
            PERSISTENT = new DeliveryMode("PERSISTENT", 0, 1);
            BUFFERED = new DeliveryMode("BUFFERED", 1, 2);
            $VALUES = (new DeliveryMode[] {
                PERSISTENT, BUFFERED
            });
        }

        private DeliveryMode(String s, int i, int j)
        {
            super(s, i);
            code = j;
        }
    }

    public static final class MessageState extends Enum
    {

        public static final MessageState WAITING;
        public static final MessageState READY;
        public static final MessageState PROCESSED;
        public static final MessageState EXPIRED;
        private final int code;
        private static final MessageState $VALUES[];

        public static MessageState[] values()
        {
            return (MessageState[])$VALUES.clone();
        }

        public static MessageState valueOf(String s)
        {
            return (MessageState)Enum.valueOf(oracle/jdbc/aq/AQMessageProperties$MessageState, s);
        }

        public final int getCode()
        {
            return code;
        }

        public static final MessageState getMessageState(int i)
        {
            if(i == WAITING.getCode())
                return WAITING;
            if(i == READY.getCode())
                return READY;
            if(i == PROCESSED.getCode())
                return PROCESSED;
            else
                return EXPIRED;
        }

        static 
        {
            WAITING = new MessageState("WAITING", 0, 1);
            READY = new MessageState("READY", 1, 0);
            PROCESSED = new MessageState("PROCESSED", 2, 2);
            EXPIRED = new MessageState("EXPIRED", 3, 3);
            $VALUES = (new MessageState[] {
                WAITING, READY, PROCESSED, EXPIRED
            });
        }

        private MessageState(String s, int i, int j)
        {
            super(s, i);
            code = j;
        }
    }


    public static final int MESSAGE_NO_DELAY = 0;
    public static final int MESSAGE_NO_EXPIRATION = -1;

    public abstract int getDequeueAttemptsCount();

    public abstract void setCorrelation(String s)
        throws SQLException;

    public abstract String getCorrelation();

    public abstract void setDelay(int i)
        throws SQLException;

    public abstract int getDelay();

    public abstract Timestamp getEnqueueTime();

    public abstract void setExceptionQueue(String s)
        throws SQLException;

    public abstract String getExceptionQueue();

    public abstract void setExpiration(int i)
        throws SQLException;

    public abstract int getExpiration();

    public abstract MessageState getState();

    public abstract void setPriority(int i)
        throws SQLException;

    public abstract int getPriority();

    public abstract void setRecipientList(AQAgent aaqagent[])
        throws SQLException;

    public abstract AQAgent[] getRecipientList();

    public abstract void setSender(AQAgent aqagent)
        throws SQLException;

    public abstract AQAgent getSender();

    public abstract String getTransactionGroup();

    public abstract byte[] getPreviousQueueMessageId();

    public abstract DeliveryMode getDeliveryMode();

    public abstract String toString();
}
