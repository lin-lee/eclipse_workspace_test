// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AQEnqueueOptions.java

package oracle.jdbc.aq;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.aq:
//            AQDequeueOptions

public class AQEnqueueOptions
{
    public static final class DeliveryMode extends Enum
    {

        public static final DeliveryMode PERSISTENT;
        public static final DeliveryMode BUFFERED;
        private final int mode;
        private static final DeliveryMode $VALUES[];

        public static DeliveryMode[] values()
        {
            return (DeliveryMode[])$VALUES.clone();
        }

        public static DeliveryMode valueOf(String s)
        {
            return (DeliveryMode)Enum.valueOf(oracle/jdbc/aq/AQEnqueueOptions$DeliveryMode, s);
        }

        public final int getCode()
        {
            return mode;
        }

        static 
        {
            PERSISTENT = new DeliveryMode("PERSISTENT", 0, AQDequeueOptions.DeliveryFilter.PERSISTENT.getCode());
            BUFFERED = new DeliveryMode("BUFFERED", 1, AQDequeueOptions.DeliveryFilter.BUFFERED.getCode());
            $VALUES = (new DeliveryMode[] {
                PERSISTENT, BUFFERED
            });
        }

        private DeliveryMode(String s, int i, int j)
        {
            super(s, i);
            mode = j;
        }
    }

    public static final class SequenceDeviationOption extends Enum
    {

        public static final SequenceDeviationOption BOTTOM;
        public static final SequenceDeviationOption BEFORE;
        public static final SequenceDeviationOption TOP;
        private final int mode;
        private static final SequenceDeviationOption $VALUES[];

        public static SequenceDeviationOption[] values()
        {
            return (SequenceDeviationOption[])$VALUES.clone();
        }

        public static SequenceDeviationOption valueOf(String s)
        {
            return (SequenceDeviationOption)Enum.valueOf(oracle/jdbc/aq/AQEnqueueOptions$SequenceDeviationOption, s);
        }

        public final int getCode()
        {
            return mode;
        }

        static 
        {
            BOTTOM = new SequenceDeviationOption("BOTTOM", 0, 0);
            BEFORE = new SequenceDeviationOption("BEFORE", 1, 2);
            TOP = new SequenceDeviationOption("TOP", 2, 3);
            $VALUES = (new SequenceDeviationOption[] {
                BOTTOM, BEFORE, TOP
            });
        }

        private SequenceDeviationOption(String s, int i, int j)
        {
            super(s, i);
            mode = j;
        }
    }

    public static final class VisibilityOption extends Enum
    {

        public static final VisibilityOption ON_COMMIT;
        public static final VisibilityOption IMMEDIATE;
        private final int mode;
        private static final VisibilityOption $VALUES[];

        public static VisibilityOption[] values()
        {
            return (VisibilityOption[])$VALUES.clone();
        }

        public static VisibilityOption valueOf(String s)
        {
            return (VisibilityOption)Enum.valueOf(oracle/jdbc/aq/AQEnqueueOptions$VisibilityOption, s);
        }

        public final int getCode()
        {
            return mode;
        }

        static 
        {
            ON_COMMIT = new VisibilityOption("ON_COMMIT", 0, 2);
            IMMEDIATE = new VisibilityOption("IMMEDIATE", 1, 1);
            $VALUES = (new VisibilityOption[] {
                ON_COMMIT, IMMEDIATE
            });
        }

        private VisibilityOption(String s, int i, int j)
        {
            super(s, i);
            mode = j;
        }
    }


    private byte attrRelativeMessageId[];
    private SequenceDeviationOption attrSequenceDeviation;
    private VisibilityOption attrVisibility;
    private DeliveryMode attrDeliveryMode;
    private boolean retrieveMsgId;
    private String transformation;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public AQEnqueueOptions()
    {
        attrRelativeMessageId = null;
        attrSequenceDeviation = SequenceDeviationOption.BOTTOM;
        attrVisibility = VisibilityOption.ON_COMMIT;
        attrDeliveryMode = DeliveryMode.PERSISTENT;
        retrieveMsgId = false;
    }

    /**
     * @deprecated Method setRelativeMessageId is deprecated
     */

    public void setRelativeMessageId(byte abyte0[])
        throws SQLException
    {
        attrRelativeMessageId = abyte0;
    }

    public byte[] getRelativeMessageId()
    {
        return attrRelativeMessageId;
    }

    /**
     * @deprecated Method setSequenceDeviation is deprecated
     */

    public void setSequenceDeviation(SequenceDeviationOption sequencedeviationoption)
        throws SQLException
    {
        attrSequenceDeviation = sequencedeviationoption;
    }

    public SequenceDeviationOption getSequenceDeviation()
    {
        return attrSequenceDeviation;
    }

    public void setVisibility(VisibilityOption visibilityoption)
        throws SQLException
    {
        attrVisibility = visibilityoption;
    }

    public VisibilityOption getVisibility()
    {
        return attrVisibility;
    }

    public void setDeliveryMode(DeliveryMode deliverymode)
        throws SQLException
    {
        attrDeliveryMode = deliverymode;
    }

    public DeliveryMode getDeliveryMode()
    {
        return attrDeliveryMode;
    }

    public void setRetrieveMessageId(boolean flag)
    {
        retrieveMsgId = flag;
    }

    public boolean getRetrieveMessageId()
    {
        return retrieveMsgId;
    }

    public void setTransformation(String s)
    {
        transformation = s;
    }

    public String getTransformation()
    {
        return transformation;
    }

}
