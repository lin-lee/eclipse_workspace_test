// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AQNotificationEvent.java

package oracle.jdbc.aq;

import java.sql.SQLException;
import java.util.EventObject;

// Referenced classes of package oracle.jdbc.aq:
//            AQMessageProperties

public abstract class AQNotificationEvent extends EventObject
{
    public static final class AdditionalEventType extends Enum
    {

        public static final AdditionalEventType NONE;
        public static final AdditionalEventType TIMEOUT;
        public static final AdditionalEventType GROUPING;
        private final int code;
        private static final AdditionalEventType $VALUES[];

        public static AdditionalEventType[] values()
        {
            return (AdditionalEventType[])$VALUES.clone();
        }

        public static AdditionalEventType valueOf(String s)
        {
            return (AdditionalEventType)Enum.valueOf(oracle/jdbc/aq/AQNotificationEvent$AdditionalEventType, s);
        }

        public final int getCode()
        {
            return code;
        }

        public static final AdditionalEventType getEventType(int i)
        {
            if(i == TIMEOUT.getCode())
                return TIMEOUT;
            if(i == GROUPING.getCode())
                return GROUPING;
            else
                return NONE;
        }

        static 
        {
            NONE = new AdditionalEventType("NONE", 0, 0);
            TIMEOUT = new AdditionalEventType("TIMEOUT", 1, 1);
            GROUPING = new AdditionalEventType("GROUPING", 2, 2);
            $VALUES = (new AdditionalEventType[] {
                NONE, TIMEOUT, GROUPING
            });
        }

        private AdditionalEventType(String s, int i, int j)
        {
            super(s, i);
            code = j;
        }
    }

    public static final class EventType extends Enum
    {

        public static final EventType REGULAR;
        public static final EventType DEREG;
        private final int code;
        private static final EventType $VALUES[];

        public static EventType[] values()
        {
            return (EventType[])$VALUES.clone();
        }

        public static EventType valueOf(String s)
        {
            return (EventType)Enum.valueOf(oracle/jdbc/aq/AQNotificationEvent$EventType, s);
        }

        public final int getCode()
        {
            return code;
        }

        static 
        {
            REGULAR = new EventType("REGULAR", 0, 0);
            DEREG = new EventType("DEREG", 1, 1);
            $VALUES = (new EventType[] {
                REGULAR, DEREG
            });
        }

        private EventType(String s, int i, int j)
        {
            super(s, i);
            code = j;
        }
    }


    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected AQNotificationEvent(Object obj)
    {
        super(obj);
    }

    public abstract AQMessageProperties getMessageProperties()
        throws SQLException;

    public abstract String getRegistration()
        throws SQLException;

    public abstract byte[] getPayload()
        throws SQLException;

    public abstract String getQueueName()
        throws SQLException;

    public abstract byte[] getMessageId()
        throws SQLException;

    public abstract String getConsumerName()
        throws SQLException;

    public abstract String getConnectionInformation();

    public abstract EventType getEventType();

    public abstract AdditionalEventType getAdditionalEventType();

    public abstract String toString();

}
