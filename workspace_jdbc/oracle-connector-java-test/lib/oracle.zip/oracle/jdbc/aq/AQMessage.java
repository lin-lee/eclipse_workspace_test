// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AQMessage.java

package oracle.jdbc.aq;

import java.sql.SQLException;
import oracle.sql.*;
import oracle.xdb.XMLType;

// Referenced classes of package oracle.jdbc.aq:
//            AQMessageProperties

public interface AQMessage
{

    public abstract byte[] getMessageId()
        throws SQLException;

    public abstract AQMessageProperties getMessageProperties()
        throws SQLException;

    public abstract void setPayload(byte abyte0[])
        throws SQLException;

    public abstract void setPayload(byte abyte0[], byte abyte1[])
        throws SQLException;

    public abstract void setPayload(STRUCT struct)
        throws SQLException;

    public abstract void setPayload(ANYDATA anydata)
        throws SQLException;

    public abstract void setPayload(RAW raw)
        throws SQLException;

    public abstract void setPayload(XMLType xmltype)
        throws SQLException;

    public abstract byte[] getPayload()
        throws SQLException;

    public abstract byte[] getPayloadTOID();

    public abstract STRUCT getSTRUCTPayload()
        throws SQLException;

    public abstract boolean isSTRUCTPayload()
        throws SQLException;

    public abstract ANYDATA getANYDATAPayload()
        throws SQLException;

    public abstract boolean isANYDATAPayload()
        throws SQLException;

    public abstract RAW getRAWPayload()
        throws SQLException;

    public abstract boolean isRAWPayload()
        throws SQLException;

    public abstract XMLType getXMLTypePayload()
        throws SQLException;

    public abstract boolean isXMLTypePayload()
        throws SQLException;

    public abstract String toString();
}
