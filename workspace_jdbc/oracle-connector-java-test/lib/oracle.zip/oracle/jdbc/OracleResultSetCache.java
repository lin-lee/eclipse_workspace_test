// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleResultSetCache.java

package oracle.jdbc;

import java.io.IOException;

public interface OracleResultSetCache
{

    public abstract void put(int i, int j, Object obj)
        throws IOException;

    public abstract Object get(int i, int j)
        throws IOException;

    public abstract void remove(int i)
        throws IOException;

    public abstract void remove(int i, int j)
        throws IOException;

    public abstract void clear()
        throws IOException;

    public abstract void close()
        throws IOException;
}
