// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDataFactory.java

package oracle.jdbc;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc:
//            OracleData

public interface OracleDataFactory
{

    public abstract OracleData create(Object obj, int i)
        throws SQLException;
}
