// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   StructMetaData.java

package oracle.jdbc;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc:
//            OracleResultSetMetaData

public interface StructMetaData
    extends OracleResultSetMetaData
{

    public abstract String getAttributeJavaName(int i)
        throws SQLException;

    public abstract String getOracleColumnClassName(int i)
        throws SQLException;

    public abstract boolean isInherited(int i)
        throws SQLException;

    public abstract int getLocalColumnCount()
        throws SQLException;
}
