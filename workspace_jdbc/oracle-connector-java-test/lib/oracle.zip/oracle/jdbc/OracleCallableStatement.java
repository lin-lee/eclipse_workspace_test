// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleCallableStatement.java

package oracle.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc:
//            OraclePreparedStatement, OracleDataFactory

public interface OracleCallableStatement
    extends CallableStatement, OraclePreparedStatement
{

    public abstract ARRAY getARRAY(int i)
        throws SQLException;

    public abstract InputStream getAsciiStream(int i)
        throws SQLException;

    public abstract BFILE getBFILE(int i)
        throws SQLException;

    public abstract BFILE getBfile(int i)
        throws SQLException;

    public abstract InputStream getBinaryStream(int i)
        throws SQLException;

    public abstract InputStream getBinaryStream(String s)
        throws SQLException;

    public abstract BLOB getBLOB(int i)
        throws SQLException;

    public abstract CHAR getCHAR(int i)
        throws SQLException;

    public abstract Reader getCharacterStream(int i)
        throws SQLException;

    public abstract CLOB getCLOB(int i)
        throws SQLException;

    public abstract ResultSet getCursor(int i)
        throws SQLException;

    /**
     * @deprecated Method getCustomDatum is deprecated
     */

    public abstract Object getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException;

    public abstract Object getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException;

    public abstract Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException;

    /**
     * @deprecated Method getAnyDataEmbeddedObject is deprecated
     */

    public abstract Object getAnyDataEmbeddedObject(int i)
        throws SQLException;

    public abstract DATE getDATE(int i)
        throws SQLException;

    public abstract NUMBER getNUMBER(int i)
        throws SQLException;

    public abstract OPAQUE getOPAQUE(int i)
        throws SQLException;

    public abstract Datum getOracleObject(int i)
        throws SQLException;

    public abstract RAW getRAW(int i)
        throws SQLException;

    public abstract REF getREF(int i)
        throws SQLException;

    public abstract ROWID getROWID(int i)
        throws SQLException;

    public abstract STRUCT getSTRUCT(int i)
        throws SQLException;

    public abstract INTERVALYM getINTERVALYM(int i)
        throws SQLException;

    public abstract INTERVALDS getINTERVALDS(int i)
        throws SQLException;

    public abstract TIMESTAMP getTIMESTAMP(int i)
        throws SQLException;

    public abstract TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException;

    public abstract TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException;

    public abstract InputStream getUnicodeStream(int i)
        throws SQLException;

    public abstract InputStream getUnicodeStream(String s)
        throws SQLException;

    public abstract void registerOutParameter(int i, int j, int k, int l)
        throws SQLException;

    /**
     * @deprecated Method registerOutParameterBytes is deprecated
     */

    public abstract void registerOutParameterBytes(int i, int j, int k, int l)
        throws SQLException;

    /**
     * @deprecated Method registerOutParameterChars is deprecated
     */

    public abstract void registerOutParameterChars(int i, int j, int k, int l)
        throws SQLException;

    public abstract int sendBatch()
        throws SQLException;

    public abstract void setExecuteBatch(int i)
        throws SQLException;

    public abstract Object getPlsqlIndexTable(int i)
        throws SQLException;

    public abstract Object getPlsqlIndexTable(int i, Class class1)
        throws SQLException;

    public abstract Datum[] getOraclePlsqlIndexTable(int i)
        throws SQLException;

    public abstract void registerIndexTableOutParameter(int i, int j, int k, int l)
        throws SQLException;

    public abstract void setBinaryFloat(String s, BINARY_FLOAT binary_float)
        throws SQLException;

    public abstract void setBinaryDouble(String s, BINARY_DOUBLE binary_double)
        throws SQLException;

    public abstract void setStringForClob(String s, String s1)
        throws SQLException;

    public abstract void setBytesForBlob(String s, byte abyte0[])
        throws SQLException;

    public abstract void registerOutParameter(String s, int i, int j, int k)
        throws SQLException;

    public abstract void setNull(String s, int i, String s1)
        throws SQLException;

    public abstract void setNull(String s, int i)
        throws SQLException;

    public abstract void setBoolean(String s, boolean flag)
        throws SQLException;

    public abstract void setByte(String s, byte byte0)
        throws SQLException;

    public abstract void setShort(String s, short word0)
        throws SQLException;

    public abstract void setInt(String s, int i)
        throws SQLException;

    public abstract void setLong(String s, long l)
        throws SQLException;

    public abstract void setFloat(String s, float f)
        throws SQLException;

    public abstract void setBinaryFloat(String s, float f)
        throws SQLException;

    public abstract void setBinaryDouble(String s, double d)
        throws SQLException;

    public abstract void setDouble(String s, double d)
        throws SQLException;

    public abstract void setBigDecimal(String s, BigDecimal bigdecimal)
        throws SQLException;

    public abstract void setString(String s, String s1)
        throws SQLException;

    public abstract void setFixedCHAR(String s, String s1)
        throws SQLException;

    public abstract void setCursor(String s, ResultSet resultset)
        throws SQLException;

    public abstract void setROWID(String s, ROWID rowid)
        throws SQLException;

    public abstract void setRAW(String s, RAW raw)
        throws SQLException;

    public abstract void setCHAR(String s, CHAR char1)
        throws SQLException;

    public abstract void setDATE(String s, DATE date)
        throws SQLException;

    public abstract void setNUMBER(String s, NUMBER number)
        throws SQLException;

    public abstract void setBLOB(String s, BLOB blob)
        throws SQLException;

    public abstract void setBlob(String s, Blob blob)
        throws SQLException;

    public abstract void setCLOB(String s, CLOB clob)
        throws SQLException;

    public abstract void setClob(String s, Clob clob)
        throws SQLException;

    public abstract void setBFILE(String s, BFILE bfile)
        throws SQLException;

    public abstract void setBfile(String s, BFILE bfile)
        throws SQLException;

    public abstract void setBytes(String s, byte abyte0[])
        throws SQLException;

    public abstract void setDate(String s, Date date)
        throws SQLException;

    public abstract void setTime(String s, Time time)
        throws SQLException;

    public abstract void setTimestamp(String s, Timestamp timestamp)
        throws SQLException;

    public abstract void setINTERVALYM(String s, INTERVALYM intervalym)
        throws SQLException;

    public abstract void setINTERVALDS(String s, INTERVALDS intervalds)
        throws SQLException;

    public abstract void setTIMESTAMP(String s, TIMESTAMP timestamp)
        throws SQLException;

    public abstract void setTIMESTAMPTZ(String s, TIMESTAMPTZ timestamptz)
        throws SQLException;

    public abstract void setTIMESTAMPLTZ(String s, TIMESTAMPLTZ timestampltz)
        throws SQLException;

    public abstract void setAsciiStream(String s, InputStream inputstream, int i)
        throws SQLException;

    public abstract void setBinaryStream(String s, InputStream inputstream, int i)
        throws SQLException;

    public abstract void setUnicodeStream(String s, InputStream inputstream, int i)
        throws SQLException;

    public abstract void setCharacterStream(String s, Reader reader, int i)
        throws SQLException;

    public abstract void setDate(String s, Date date, Calendar calendar)
        throws SQLException;

    public abstract void setTime(String s, Time time, Calendar calendar)
        throws SQLException;

    public abstract void setTimestamp(String s, Timestamp timestamp, Calendar calendar)
        throws SQLException;

    public abstract void setURL(String s, URL url)
        throws SQLException;

    public abstract void setArray(String s, Array array)
        throws SQLException;

    public abstract void setARRAY(String s, ARRAY array)
        throws SQLException;

    public abstract void setOPAQUE(String s, OPAQUE opaque)
        throws SQLException;

    public abstract void setStructDescriptor(String s, StructDescriptor structdescriptor)
        throws SQLException;

    public abstract void setSTRUCT(String s, STRUCT struct)
        throws SQLException;

    public abstract void setCustomDatum(String s, CustomDatum customdatum)
        throws SQLException;

    public abstract void setORAData(String s, ORAData oradata)
        throws SQLException;

    public abstract void setObject(String s, Object obj, int i, int j)
        throws SQLException;

    public abstract void setObject(String s, Object obj, int i)
        throws SQLException;

    public abstract void setRefType(String s, REF ref)
        throws SQLException;

    public abstract void setRef(String s, Ref ref)
        throws SQLException;

    public abstract void setREF(String s, REF ref)
        throws SQLException;

    public abstract void setObject(String s, Object obj)
        throws SQLException;

    public abstract void setOracleObject(String s, Datum datum)
        throws SQLException;
}
