// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleStruct.java

package oracle.jdbc;

import java.sql.SQLException;
import java.sql.Struct;

// Referenced classes of package oracle.jdbc:
//            OracleTypeMetaData

public interface OracleStruct
    extends Struct
{

    public abstract OracleTypeMetaData getOracleMetaData()
        throws SQLException;
}
