// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ClassGenerator.java

package oracle.jdbc.proxy;

import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.*;
import java.util.*;
import oracle.jdbc.proxy.annotation.ProxyFor;
import org.objectweb.asm.*;

// Referenced classes of package oracle.jdbc.proxy:
//            MethodSignature, MethodGenerator, _Proxy_, ProxyFactory, 
//            AnnotationsRegistry, Utils, GeneratedProxiesRegistry

class ClassGenerator
{
    static class AnnotationsForIface
    {

        private final AnnotationsRegistry registry;
        private final Class iface;
        private final AnnotationsRegistry.Value value;

        AnnotationsRegistry getRegistry()
        {
            return registry;
        }

        Class getIface()
        {
            return iface;
        }

        AnnotationsRegistry.Value getValue()
        {
            return value;
        }

        AnnotationsForIface(AnnotationsRegistry annotationsregistry, Class class1, AnnotationsRegistry.Value value1)
        {
            registry = annotationsregistry;
            iface = class1;
            value = value1;
        }
    }


    private final AnnotationsForIface annotationsForIface;
    private final String proxyName;
    private final String superclassName;
    private final String ifaceName;
    private final String proxyType;
    private final String ifaceType;
    final Map members;

    private ClassGenerator(AnnotationsForIface annotationsforiface, String s, String s1, String s2, Map map)
    {
        annotationsForIface = annotationsforiface;
        proxyName = Utils.makeSlashed(s);
        proxyType = Utils.makeType(s);
        superclassName = Utils.makeSlashed(s1);
        ifaceName = Utils.makeSlashed(s2);
        ifaceType = Utils.makeType(s2);
        members = map;
    }

    String getProxyName()
    {
        return proxyName;
    }

    String getSuperclassName()
    {
        return superclassName;
    }

    String getIfaceName()
    {
        return ifaceName;
    }

    String getProxyType()
    {
        return proxyType;
    }

    String getIfaceType()
    {
        return ifaceType;
    }

    static byte[] generateBytecode(GeneratedProxiesRegistry.Key key, AnnotationsRegistry annotationsregistry)
    {
        Class class1 = key.getIface();
        Class class2 = key.getSuperclass();
        if(!class1.isInterface())
            new RuntimeException("iface must be interface");
        if(class2.isInterface())
            new RuntimeException("sclass must not be interface");
        HashMap hashmap = new HashMap();
        HashMap hashmap1 = new HashMap();
        AnnotationsForIface annotationsforiface = new AnnotationsForIface(annotationsregistry, class1, annotationsregistry.get(class1));
        ClassGenerator classgenerator = new ClassGenerator(annotationsforiface, key.toString(), class2.getName(), class1.getName(), hashmap);
        (new Runnable(class2, hashmap1) {

            final Class val$superclass;
            final Map val$superclassMethods;

            public void run()
            {
                traverse(superclass);
            }

            void traverse(Class class3)
            {
                if(null == class3)
                    return;
                if(!class3.isAnnotationPresent(oracle/jdbc/proxy/annotation/ProxyFor))
                    return;
                Method amethod1[] = class3.getDeclaredMethods();
                int k = amethod1.length;
                for(int l = 0; l < k; l++)
                {
                    Method method2 = amethod1[l];
                    superclassMethods.put(new MethodSignature(method2), method2);
                }

                traverse(class3.getSuperclass());
            }

            
            {
                superclass = class1;
                superclassMethods = map;
                super();
            }
        }
).run();
        Method amethod[] = class1.getMethods();
        int i = amethod.length;
        for(int j = 0; j < i; j++)
        {
            Method method = amethod[j];
            MethodSignature methodsignature = new MethodSignature(method);
            Method method1 = (Method)hashmap1.get(methodsignature);
            hashmap.put(methodsignature, new MethodGenerator(classgenerator, method, null == method1 || Modifier.isAbstract(method1.getModifiers())));
        }

        ClassWriter classwriter = new ClassWriter(3);
        classgenerator.generate(classwriter);
        return classwriter.toByteArray();
    }

    static Class generate(Class class1, Class class2, AnnotationsRegistry annotationsregistry)
    {
        GeneratedProxiesRegistry.Key key = new GeneratedProxiesRegistry.Key(class1, class2);
        byte abyte0[] = generateBytecode(key, annotationsregistry);
        String s = System.getProperty("oracle.jdbc.proxy.asm.verify");
        if(null != s && 0 == "true".compareToIgnoreCase(s))
            try
            {
                Class class3 = Class.forName("org.objectweb.asm.util.CheckClassAdapter");
                Method method = class3.getMethod("verify", new Class[] {
                    org/objectweb/asm/ClassReader, Boolean.TYPE, java/io/PrintWriter
                });
                method.invoke(null, new Object[] {
                    new ClassReader(abyte0), Boolean.valueOf(true), new PrintWriter(new OutputStreamWriter(System.out))
                });
            }
            catch(ClassNotFoundException classnotfoundexception) { }
            catch(NoSuchMethodException nosuchmethodexception) { }
            catch(IllegalAccessException illegalaccessexception) { }
            catch(InvocationTargetException invocationtargetexception) { }
        try
        {
            return Class.forName(key.toString(), false, new ClassLoader(abyte0) {

                final byte val$bytecode[];

                protected Class findClass(String s1)
                {
                    return defineClass(s1, bytecode, 0, bytecode.length);
                }

            
            {
                bytecode = abyte0;
                super();
            }
            }
);
        }
        catch(ClassNotFoundException classnotfoundexception1)
        {
            throw new RuntimeException(classnotfoundexception1);
        }
    }

    private void generate(ClassWriter classwriter)
    {
        classwriter.visit(50, 33, proxyName, null, superclassName, new String[] {
            ifaceName, Utils.makeSlashed(oracle/jdbc/proxy/_Proxy_.getName())
        });
        Object obj = members.values().iterator();
        do
        {
            if(!((Iterator) (obj)).hasNext())
                break;
            MethodGenerator methodgenerator = (MethodGenerator)((Iterator) (obj)).next();
            if(null != methodgenerator)
                methodgenerator.generate(classwriter);
        } while(true);
        obj = classwriter.visitMethod(1, "_getDelegate_", (new StringBuilder()).append("()").append(ifaceType).toString(), null, null);
        ((MethodVisitor) (obj)).visitCode();
        ((MethodVisitor) (obj)).visitVarInsn(25, 0);
        ((MethodVisitor) (obj)).visitFieldInsn(180, proxyName, "delegate", ifaceType);
        ((MethodVisitor) (obj)).visitInsn(176);
        ((MethodVisitor) (obj)).visitMaxs(0, 0);
        ((MethodVisitor) (obj)).visitEnd();
        obj = classwriter.visitMethod(4161, "_getDelegate_", "()Ljava/lang/Object;", null, null);
        ((MethodVisitor) (obj)).visitCode();
        ((MethodVisitor) (obj)).visitVarInsn(25, 0);
        ((MethodVisitor) (obj)).visitMethodInsn(182, proxyName, "_getDelegate_", (new StringBuilder()).append("()").append(ifaceType).toString());
        ((MethodVisitor) (obj)).visitInsn(176);
        ((MethodVisitor) (obj)).visitMaxs(0, 0);
        ((MethodVisitor) (obj)).visitEnd();
        obj = annotationsForIface.getValue();
        if(null != obj)
        {
            Method method = ((AnnotationsRegistry.Value) (obj)).getMethodGetDelegate();
            if(null != method)
            {
                MethodVisitor methodvisitor = classwriter.visitMethod(1, method.getName(), (new StringBuilder()).append("()").append(Utils.makeType(method.getReturnType())).toString(), null, null);
                methodvisitor.visitCode();
                Label label1 = new Label();
                methodvisitor.visitLabel(label1);
                methodvisitor.visitVarInsn(25, 0);
                methodvisitor.visitFieldInsn(180, proxyName, "delegate", ifaceType);
                methodvisitor.visitInsn(176);
                Label label3 = new Label();
                methodvisitor.visitLabel(label3);
                methodvisitor.visitLocalVariable("this", proxyType, null, label1, label3, 0);
                methodvisitor.visitMaxs(0, 0);
                methodvisitor.visitEnd();
            }
            Method method1 = ((AnnotationsRegistry.Value) (obj)).getMethodSetDelegate();
            if(null != method1)
            {
                Class aclass[] = method1.getParameterTypes();
                if(1 != aclass.length)
                    throw new RuntimeException("wrong delegate setter signature");
                MethodVisitor methodvisitor2 = classwriter.visitMethod(1, method1.getName(), (new StringBuilder()).append("(").append(Utils.makeType(aclass[0])).append(")V").toString(), null, null);
                methodvisitor2.visitCode();
                Label label5;
                methodvisitor2.visitLabel(label5 = new Label());
                methodvisitor2.visitVarInsn(25, 0);
                methodvisitor2.visitFieldInsn(180, proxyName, "proxyFactory", Utils.makeType(oracle/jdbc/proxy/ProxyFactory));
                methodvisitor2.visitVarInsn(25, 0);
                methodvisitor2.visitVarInsn(25, 0);
                methodvisitor2.visitFieldInsn(180, proxyName, "delegate", ifaceType);
                methodvisitor2.visitVarInsn(25, 1);
                methodvisitor2.visitMethodInsn(182, Utils.makeSlashed(oracle/jdbc/proxy/ProxyFactory), "updateDelegate", "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V");
                methodvisitor2.visitVarInsn(25, 0);
                methodvisitor2.visitVarInsn(25, 1);
                methodvisitor2.visitFieldInsn(181, proxyName, "delegate", ifaceType);
                methodvisitor2.visitInsn(177);
                Label label8;
                methodvisitor2.visitLabel(label8 = new Label());
                methodvisitor2.visitLocalVariable("this", proxyType, null, label5, label8, 0);
                methodvisitor2.visitLocalVariable("delegate", ifaceType, null, label5, label8, 1);
                methodvisitor2.visitMaxs(0, 0);
                methodvisitor2.visitEnd();
            }
            Method method2 = ((AnnotationsRegistry.Value) (obj)).getMethodGetCreator();
            if(null != method2)
            {
                MethodVisitor methodvisitor3 = classwriter.visitMethod(1, method2.getName(), (new StringBuilder()).append("()").append(Utils.makeType(method2.getReturnType())).toString(), null, null);
                methodvisitor3.visitCode();
                Label label6 = new Label();
                methodvisitor3.visitLabel(label6);
                methodvisitor3.visitVarInsn(25, 0);
                methodvisitor3.visitFieldInsn(180, proxyName, "creator", "Ljava/lang/Object;");
                methodvisitor3.visitInsn(176);
                Label label9 = new Label();
                methodvisitor3.visitLabel(label9);
                methodvisitor3.visitLocalVariable("this", proxyType, null, label6, label9, 0);
                methodvisitor3.visitMaxs(1, 1);
                methodvisitor3.visitEnd();
            }
            Method method3 = ((AnnotationsRegistry.Value) (obj)).getMethodGetProxy();
            if(null != method3)
            {
                Class aclass1[] = method3.getParameterTypes();
                Class class1 = method3.getReturnType();
                if(!Arrays.deepEquals(new Class[] {
    java/lang/Object, java/lang/Object
}, aclass1) || !java/lang/Object.equals(class1))
                    throw new RuntimeException("internal error: wrong @GetProxy method");
                MethodVisitor methodvisitor4 = classwriter.visitMethod(1, method3.getName(), "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", "<T:Ljava/lang/Object;>(TT;Ljava/lang/Object;)TT;", null);
                methodvisitor4.visitCode();
                methodvisitor4.visitVarInsn(25, 0);
                methodvisitor4.visitFieldInsn(180, proxyName, "proxyFactory", Utils.makeType(oracle/jdbc/proxy/ProxyFactory));
                methodvisitor4.visitVarInsn(25, 1);
                methodvisitor4.visitVarInsn(25, 2);
                methodvisitor4.visitMethodInsn(182, Utils.makeSlashed(oracle/jdbc/proxy/ProxyFactory), "proxyFor", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
                methodvisitor4.visitInsn(176);
                methodvisitor4.visitMaxs(3, 3);
                methodvisitor4.visitEnd();
            }
        }
        classwriter.visitField(2, "delegate", ifaceType, null, null).visitEnd();
        classwriter.visitField(18, "creator", "Ljava/lang/Object;", null, null).visitEnd();
        classwriter.visitField(18, "proxyFactory", Utils.makeType(oracle/jdbc/proxy/ProxyFactory.getName()), null, null).visitEnd();
        classwriter.visitField(18, "proxyCache", "Ljava/util/Map;", "Ljava/util/Map<Ljava/lang/Object;Ljava/lang/Object;>;", null).visitEnd();
        classwriter.visitField(10, "zeroLengthObjectArray", "[Ljava/lang/Object;", null, null).visitEnd();
        boolean flag = false;
        for(Iterator iterator = members.values().iterator(); iterator.hasNext();)
        {
            MethodGenerator methodgenerator1 = (MethodGenerator)iterator.next();
            classwriter.visitField(10, methodgenerator1.getMethodObject(), "Ljava/lang/reflect/Method;", null, null).visitEnd();
            flag = true;
        }

        Object obj1 = classwriter.visitMethod(8, "<clinit>", "()V", null, null);
        ((MethodVisitor) (obj1)).visitCode();
        Utils.loadConst(((MethodVisitor) (obj1)), 0);
        ((MethodVisitor) (obj1)).visitTypeInsn(189, "java/lang/Object");
        ((MethodVisitor) (obj1)).visitFieldInsn(179, proxyName, "zeroLengthObjectArray", "[Ljava/lang/Object;");
        if(flag)
        {
            Label label;
            Label label2;
            Label label4;
            ((MethodVisitor) (obj1)).visitTryCatchBlock(label = new Label(), label2 = new Label(), label4 = new Label(), "java/lang/Throwable");
            ((MethodVisitor) (obj1)).visitLabel(label);
            MethodGenerator methodgenerator2;
            for(Iterator iterator1 = members.values().iterator(); iterator1.hasNext(); methodgenerator2.initializeMethodObject(((MethodVisitor) (obj1))))
                methodgenerator2 = (MethodGenerator)iterator1.next();

            ((MethodVisitor) (obj1)).visitLabel(label2);
            Label label7;
            ((MethodVisitor) (obj1)).visitJumpInsn(167, label7 = new Label());
            ((MethodVisitor) (obj1)).visitLabel(label4);
            ((MethodVisitor) (obj1)).visitFrame(4, 0, null, 1, new Object[] {
                "java/lang/Throwable"
            });
            ((MethodVisitor) (obj1)).visitVarInsn(58, 0);
            ((MethodVisitor) (obj1)).visitTypeInsn(187, "java/lang/RuntimeException");
            ((MethodVisitor) (obj1)).visitInsn(89);
            ((MethodVisitor) (obj1)).visitVarInsn(25, 0);
            ((MethodVisitor) (obj1)).visitMethodInsn(183, "java/lang/RuntimeException", "<init>", "(Ljava/lang/Throwable;)V");
            ((MethodVisitor) (obj1)).visitInsn(191);
            ((MethodVisitor) (obj1)).visitLabel(label7);
            ((MethodVisitor) (obj1)).visitFrame(3, 0, null, 0, null);
        }
        ((MethodVisitor) (obj1)).visitInsn(177);
        ((MethodVisitor) (obj1)).visitMaxs(0, 0);
        ((MethodVisitor) (obj1)).visitEnd();
        obj1 = (new StringBuilder()).append("(").append(ifaceType).append("Ljava/lang/Object;").append(Utils.makeType(oracle/jdbc/proxy/ProxyFactory.getName())).append("Ljava/util/Map;").append(")V").toString();
        MethodVisitor methodvisitor1 = classwriter.visitMethod(1, "<init>", ((String) (obj1)), null, null);
        methodvisitor1.visitCode();
        methodvisitor1.visitVarInsn(25, 0);
        methodvisitor1.visitMethodInsn(183, superclassName, "<init>", "()V");
        methodvisitor1.visitVarInsn(25, 0);
        methodvisitor1.visitVarInsn(25, 1);
        methodvisitor1.visitFieldInsn(181, proxyName, "delegate", ifaceType);
        methodvisitor1.visitVarInsn(25, 0);
        methodvisitor1.visitVarInsn(25, 2);
        methodvisitor1.visitFieldInsn(181, proxyName, "creator", "Ljava/lang/Object;");
        methodvisitor1.visitVarInsn(25, 0);
        methodvisitor1.visitVarInsn(25, 3);
        methodvisitor1.visitFieldInsn(181, proxyName, "proxyFactory", Utils.makeType(oracle/jdbc/proxy/ProxyFactory.getName()));
        methodvisitor1.visitVarInsn(25, 0);
        methodvisitor1.visitVarInsn(25, 4);
        methodvisitor1.visitFieldInsn(181, proxyName, "proxyCache", "Ljava/util/Map;");
        methodvisitor1.visitInsn(177);
        methodvisitor1.visitMaxs(0, 0);
        methodvisitor1.visitEnd();
        classwriter.visitEnd();
    }

    AnnotationsForIface getAnnotationsForIface()
    {
        return annotationsForIface;
    }
}
