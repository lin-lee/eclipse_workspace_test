// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ProxyExport.java

package oracle.jdbc.proxy;

import java.io.*;
import java.util.*;

// Referenced classes of package oracle.jdbc.proxy:
//            ProxyFactory, AnnotationsRegistry, GeneratedProxiesRegistry, ClassGenerator

public class ProxyExport
{

    public ProxyExport()
    {
    }

    public static void main(String args[])
        throws ClassNotFoundException, IOException
    {
        if(0 == args.length)
        {
            System.out.println("Usage:");
            System.out.println("java -classpath ojdbc6.jar oracle.jdbc.proxy.ProxyExport [-d dir] class1 class2 class3 ...");
            System.out.println("  dir - directory to store exported proxy classes");
            System.out.println("  class1 class2 class3 ... - superclasses equipped with @ProxyFor annotation");
            return;
        }
        int i = 0;
        String s = "";
        if("-d".equals(args[0]))
        {
            if(args.length < 2)
            {
                System.out.println("wrong directory");
                return;
            }
            s = args[1];
            i = 2;
            if(!(new File(s)).exists())
            {
                System.out.println("target directory does not exist");
                return;
            }
            if(0 != s.length() && !s.endsWith(File.separator))
                s = (new StringBuilder()).append(s).append(File.separator).toString();
        }
        ArrayList arraylist = new ArrayList();
        for(; i < args.length; i++)
            arraylist.add(Class.forName(args[i]));

        ProxyFactory proxyfactory = ProxyFactory.createProxyFactory((Class[])arraylist.toArray(new Class[0]));
        AnnotationsRegistry annotationsregistry = proxyfactory.annotationsRegistry;
        for(Iterator iterator = annotationsregistry.values().iterator(); iterator.hasNext();)
        {
            AnnotationsRegistry.Value value = (AnnotationsRegistry.Value)iterator.next();
            Class class1 = value.getSuperclass();
            Iterator iterator1 = value.getIfacesToProxy().iterator();
            while(iterator1.hasNext()) 
            {
                Class class2 = (Class)iterator1.next();
                GeneratedProxiesRegistry.Key key = new GeneratedProxiesRegistry.Key(class2, class1);
                byte abyte0[] = ClassGenerator.generateBytecode(key, proxyfactory.annotationsRegistry);
                String s1 = key.makePathname();
                int j = s1.lastIndexOf(File.separator);
                if(-1 != j)
                {
                    String s2 = s1.substring(0, j);
                    (new File((new StringBuilder()).append(s).append(s2).toString())).mkdirs();
                }
                BufferedOutputStream bufferedoutputstream = new BufferedOutputStream(new FileOutputStream((new StringBuilder()).append(s).append(s1).toString()));
                bufferedoutputstream.write(abyte0);
                bufferedoutputstream.close();
            }
        }

    }
}
