// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   SetDelegate.java

package oracle.jdbc.proxy.annotation;

import java.lang.annotation.Annotation;

public interface SetDelegate
    extends Annotation
{
}
