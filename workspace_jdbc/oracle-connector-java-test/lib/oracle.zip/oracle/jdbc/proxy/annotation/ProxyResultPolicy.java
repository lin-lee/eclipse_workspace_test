// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ProxyResultPolicy.java

package oracle.jdbc.proxy.annotation;


public final class ProxyResultPolicy extends Enum
{

    public static final ProxyResultPolicy MANUAL;
    public static final ProxyResultPolicy CREATE;
    public static final ProxyResultPolicy CACHE;
    public static final ProxyResultPolicy CREATE_CACHE;
    private static final ProxyResultPolicy $VALUES[];

    public static ProxyResultPolicy[] values()
    {
        return (ProxyResultPolicy[])$VALUES.clone();
    }

    public static ProxyResultPolicy valueOf(String s)
    {
        return (ProxyResultPolicy)Enum.valueOf(oracle/jdbc/proxy/annotation/ProxyResultPolicy, s);
    }

    private ProxyResultPolicy(String s, int i)
    {
        super(s, i);
    }

    static 
    {
        MANUAL = new ProxyResultPolicy("MANUAL", 0);
        CREATE = new ProxyResultPolicy("CREATE", 1);
        CACHE = new ProxyResultPolicy("CACHE", 2);
        CREATE_CACHE = new ProxyResultPolicy("CREATE_CACHE", 3);
        $VALUES = (new ProxyResultPolicy[] {
            MANUAL, CREATE, CACHE, CREATE_CACHE
        });
    }
}
