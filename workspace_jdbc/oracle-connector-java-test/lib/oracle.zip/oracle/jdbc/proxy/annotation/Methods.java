// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   Methods.java

package oracle.jdbc.proxy.annotation;

import java.lang.annotation.Annotation;

// Referenced classes of package oracle.jdbc.proxy.annotation:
//            Signature

public interface Methods
    extends Annotation
{

    public abstract Signature[] signatures();
}
