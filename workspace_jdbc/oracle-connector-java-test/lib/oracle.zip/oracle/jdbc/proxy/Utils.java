// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   Utils.java

package oracle.jdbc.proxy;

import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Type;

class Utils
{

    Utils()
    {
    }

    static String makeSlashed(Class class1)
    {
        return makeSlashed(class1.getName());
    }

    static String makeSlashed(String s)
    {
        return s.replace('.', '/');
    }

    static String makeSlashed(String s, String s1)
    {
        return (new StringBuilder()).append(makeSlashed(s)).append('/').append(s1).toString();
    }

    static String makeType(Class class1)
    {
        return makeType(class1.getName());
    }

    static String makeType(String s)
    {
        String s1 = makeSlashed(s);
        if("boolean".equals(s1))
            return "Z";
        if("char".equals(s1))
            return "C";
        if("byte".equals(s1))
            return "B";
        if("short".equals(s1))
            return "S";
        if("int".equals(s1))
            return "I";
        if("long".equals(s1))
            return "J";
        if("float".equals(s1))
            return "F";
        if("double".equals(s1))
            return "D";
        if("void".equals(s1))
            return "V";
        if(s1.startsWith("["))
            return s1;
        else
            return (new StringBuilder()).append('L').append(s1).append(';').toString();
    }

    static String makeSignature(Class aclass[], Class class1)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append('(');
        Class aclass1[] = aclass;
        int i = aclass1.length;
        for(int j = 0; j < i; j++)
        {
            Class class2 = aclass1[j];
            stringbuilder.append(makeType(makeSlashed(class2.getName())));
        }

        stringbuilder.append(')').append(makeType(makeSlashed(class1.getName())));
        return stringbuilder.toString();
    }

    static String[] makeThrowables(Class aclass[])
    {
        int i = aclass.length;
        String as[];
        if(0 == i)
        {
            as = null;
        } else
        {
            as = new String[i];
            for(int j = 0; j < i; j++)
                as[j] = makeSlashed(aclass[j].getName());

        }
        return as;
    }

    static int loadOpcode(Class class1)
    {
        String s = class1.getName();
        if("boolean".equals(s) || "byte".equals(s) || "char".equals(s) || "short".equals(s) || "int".equals(s))
            return 21;
        if("long".equals(s))
            return 22;
        if("float".equals(s))
            return 23;
        return !"double".equals(s) ? 25 : 24;
    }

    static int storeOpcode(Class class1)
    {
        String s = class1.getName();
        if("boolean".equals(s) || "byte".equals(s) || "char".equals(s) || "short".equals(s) || "int".equals(s))
            return 54;
        if("long".equals(s))
            return 55;
        if("float".equals(s))
            return 56;
        return !"double".equals(s) ? 58 : 57;
    }

    static int returnOpcode(Class class1)
    {
        String s = class1.getName();
        if("boolean".equals(s) || "byte".equals(s) || "char".equals(s) || "short".equals(s) || "int".equals(s))
            return 172;
        if("long".equals(s))
            return 173;
        if("float".equals(s))
            return 174;
        if("double".equals(s))
            return 175;
        return !"void".equals(s) ? 176 : 177;
    }

    static int varSize(Class class1)
    {
        String s = class1.getName();
        return !"double".equals(s) && !"long".equals(s) ? 1 : 2;
    }

    static void cast(MethodVisitor methodvisitor, Class class1, Class class2)
    {
        boolean flag = isPrimitive(class1);
        boolean flag1 = isPrimitive(class2);
        if(!flag && flag1)
            autoUnbox(methodvisitor, class2);
        else
        if(flag && !flag1)
            autoBox(methodvisitor, class1);
        else
        if(!flag && !flag1 && !class1.equals(class2))
            methodvisitor.visitTypeInsn(192, makeSlashed(class2));
    }

    static boolean isPrimitive(Class class1)
    {
        return Boolean.TYPE.equals(class1) || Character.TYPE.equals(class1) || Byte.TYPE.equals(class1) || Short.TYPE.equals(class1) || Integer.TYPE.equals(class1) || Long.TYPE.equals(class1) || Float.TYPE.equals(class1) || Double.TYPE.equals(class1);
    }

    static void autoBox(MethodVisitor methodvisitor, Class class1)
    {
        if(Boolean.TYPE.equals(class1))
            methodvisitor.visitMethodInsn(184, "java/lang/Boolean", "valueOf", "(Z)Ljava/lang/Boolean;");
        else
        if(Character.TYPE.equals(class1))
            methodvisitor.visitMethodInsn(184, "java/lang/Character", "valueOf", "(C)Ljava/lang/Character;");
        else
        if(Byte.TYPE.equals(class1))
            methodvisitor.visitMethodInsn(184, "java/lang/Byte", "valueOf", "(B)Ljava/lang/Byte;");
        else
        if(Short.TYPE.equals(class1))
            methodvisitor.visitMethodInsn(184, "java/lang/Short", "valueOf", "(S)Ljava/lang/Short;");
        else
        if(Integer.TYPE.equals(class1))
            methodvisitor.visitMethodInsn(184, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;");
        else
        if(Long.TYPE.equals(class1))
            methodvisitor.visitMethodInsn(184, "java/lang/Long", "valueOf", "(J)Ljava/lang/Long;");
        else
        if(Float.TYPE.equals(class1))
            methodvisitor.visitMethodInsn(184, "java/lang/Float", "valueOf", "(F)Ljava/lang/Float;");
        else
        if(Double.TYPE.equals(class1))
            methodvisitor.visitMethodInsn(184, "java/lang/Double", "valueOf", "(D)Ljava/lang/Double;");
    }

    static void autoUnbox(MethodVisitor methodvisitor, Class class1)
    {
        if(Boolean.TYPE.equals(class1))
        {
            methodvisitor.visitTypeInsn(192, "java/lang/Boolean");
            methodvisitor.visitMethodInsn(182, "java/lang/Boolean", "booleanValue", "()Z");
        } else
        if(Character.TYPE.equals(class1))
        {
            methodvisitor.visitTypeInsn(192, "java/lang/Character");
            methodvisitor.visitMethodInsn(182, "java/lang/Character", "charValue", "()C");
        } else
        if(Byte.TYPE.equals(class1))
        {
            methodvisitor.visitTypeInsn(192, "java/lang/Byte");
            methodvisitor.visitMethodInsn(182, "java/lang/Byte", "byteValue", "()B");
        } else
        if(Short.TYPE.equals(class1))
        {
            methodvisitor.visitTypeInsn(192, "java/lang/Short");
            methodvisitor.visitMethodInsn(182, "java/lang/Short", "shortValue", "()S");
        } else
        if(Integer.TYPE.equals(class1))
        {
            methodvisitor.visitTypeInsn(192, "java/lang/Integer");
            methodvisitor.visitMethodInsn(182, "java/lang/Integer", "intValue", "()I");
        } else
        if(Long.TYPE.equals(class1))
        {
            methodvisitor.visitTypeInsn(192, "java/lang/Long");
            methodvisitor.visitMethodInsn(182, "java/lang/Long", "longValue", "()J");
        } else
        if(Float.TYPE.equals(class1))
        {
            methodvisitor.visitTypeInsn(192, "java/lang/Float");
            methodvisitor.visitMethodInsn(182, "java/lang/Float", "floatValue", "()F");
        } else
        if(Double.TYPE.equals(class1))
        {
            methodvisitor.visitTypeInsn(192, "java/lang/Double");
            methodvisitor.visitMethodInsn(182, "java/lang/Double", "doubleValue", "()D");
        } else
        {
            methodvisitor.visitTypeInsn(192, makeSlashed(class1));
        }
    }

    static void loadClass(MethodVisitor methodvisitor, Class class1)
    {
        String s = class1.getName();
        if("boolean".equals(s))
            methodvisitor.visitFieldInsn(178, "java/lang/Boolean", "TYPE", "Ljava/lang/Class;");
        else
        if("char".equals(s))
            methodvisitor.visitFieldInsn(178, "java/lang/Character", "TYPE", "Ljava/lang/Class;");
        else
        if("byte".equals(s))
            methodvisitor.visitFieldInsn(178, "java/lang/Byte", "TYPE", "Ljava/lang/Class;");
        else
        if("short".equals(s))
            methodvisitor.visitFieldInsn(178, "java/lang/Short", "TYPE", "Ljava/lang/Class;");
        else
        if("int".equals(s))
            methodvisitor.visitFieldInsn(178, "java/lang/Integer", "TYPE", "Ljava/lang/Class;");
        else
        if("long".equals(s))
            methodvisitor.visitFieldInsn(178, "java/lang/Long", "TYPE", "Ljava/lang/Class;");
        else
        if("float".equals(s))
            methodvisitor.visitFieldInsn(178, "java/lang/Float", "TYPE", "Ljava/lang/Class;");
        else
        if("double".equals(s))
            methodvisitor.visitFieldInsn(178, "java/lang/Double", "TYPE", "Ljava/lang/Class;");
        else
            methodvisitor.visitLdcInsn(Type.getType(class1));
    }

    static void loadConst(MethodVisitor methodvisitor, int i)
    {
        switch(i)
        {
        case 0: // '\0'
            methodvisitor.visitInsn(3);
            return;

        case 1: // '\001'
            methodvisitor.visitInsn(4);
            return;

        case 2: // '\002'
            methodvisitor.visitInsn(5);
            return;

        case 3: // '\003'
            methodvisitor.visitInsn(6);
            return;

        case 4: // '\004'
            methodvisitor.visitInsn(7);
            return;

        case 5: // '\005'
            methodvisitor.visitInsn(8);
            return;
        }
        if(i >= -128 && i <= 127)
        {
            methodvisitor.visitIntInsn(16, i);
            return;
        } else
        {
            throw new RuntimeException((new StringBuilder()).append("do not know how to load ").append(i).toString());
        }
    }
}
