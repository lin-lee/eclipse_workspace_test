// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   MethodGenerator.java

package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.util.*;
import oracle.jdbc.proxy.annotation.ProxyResultPolicy;
import org.objectweb.asm.*;

// Referenced classes of package oracle.jdbc.proxy:
//            MethodSignature, ProxyFactory, _Proxy_, ClassGenerator, 
//            Utils, AnnotationsRegistry, ReadOnlyList

class MethodGenerator
{

    private static long ids = 0L;
    private final String methodObject;
    private final String proxyName;
    private final String ifaceName;
    private final String superclassName;
    private final String proxyType;
    private final String ifaceType;
    private final Method method;
    private final ClassGenerator.AnnotationsForIface annotationsForIface;
    private final boolean callDelegate;
    private final boolean returns;
    private final Class parameterTypes[];
    private final Class exceptionTypes[];
    private final Class returnType;
    private final String methodName;
    private final String signature;
    private final String throwables[];
    private final List exceptionsToCatch = new ReadOnlyList() {

        final MethodGenerator this$0;

        public Class get(int i)
        {
            return ((Class) (0 != i ? exceptionTypes[i - 1] : java/lang/RuntimeException));
        }

        public int size()
        {
            return exceptionTypes.length + 1;
        }

        public volatile Object get(int i)
        {
            return get(i);
        }

            
            {
                this$0 = MethodGenerator.this;
                super();
            }
    }
;

    MethodGenerator(ClassGenerator classgenerator, Method method1, boolean flag)
    {
        methodObject = (new StringBuilder()).append("methodObject").append(ids++).toString();
        proxyName = classgenerator.getProxyName();
        ifaceName = classgenerator.getIfaceName();
        superclassName = classgenerator.getSuperclassName();
        ifaceType = classgenerator.getIfaceType();
        proxyType = classgenerator.getProxyType();
        method = method1;
        annotationsForIface = classgenerator.getAnnotationsForIface();
        callDelegate = flag;
        parameterTypes = method1.getParameterTypes();
        exceptionTypes = method1.getExceptionTypes();
        returnType = method1.getReturnType();
        returns = !"void".equals(returnType.getName());
        methodName = method1.getName();
        signature = Utils.makeSignature(parameterTypes, returnType);
        throwables = Utils.makeThrowables(exceptionTypes);
    }

    String getMethodObject()
    {
        return methodObject;
    }

    private Method getMethodPre()
    {
        AnnotationsRegistry.Value value = annotationsForIface.getValue();
        if(null == value)
            return null;
        else
            return value.getMethodPre(annotationsForIface.getIface(), new MethodSignature(method));
    }

    private boolean isResultProxied()
    {
        if(!hasAssignableProxyForReturnType(returnType, annotationsForIface.getRegistry().keySet()))
            return false;
        AnnotationsRegistry.Value value = annotationsForIface.getValue();
        if(null == value)
        {
            return false;
        } else
        {
            boolean flag = value.belongsToIfaceToProxy(annotationsForIface.getIface(), new MethodSignature(method));
            return flag && ProxyResultPolicy.MANUAL != getProxyResultPolicy();
        }
    }

    private final boolean hasAssignableProxyForReturnType(Class class1, Set set)
    {
        for(Iterator iterator = set.iterator(); iterator.hasNext();)
        {
            Class class2 = (Class)iterator.next();
            if(class1.isAssignableFrom(class2))
                return true;
        }

        return false;
    }

    private boolean isMethodPreDefined()
    {
        return null != getMethodPre();
    }

    private Method getMethodVoidPost()
    {
        AnnotationsRegistry.Value value = annotationsForIface.getValue();
        if(null == value)
            return null;
        else
            return value.getMethodVoidPost(annotationsForIface.getIface(), new MethodSignature(method));
    }

    private boolean isMethodVoidPostDefined()
    {
        return null != getMethodVoidPost();
    }

    private Method getMethodReturningPost()
    {
        AnnotationsRegistry.Value value = annotationsForIface.getValue();
        if(null == value)
            return null;
        else
            return value.getMethodReturningPost(annotationsForIface.getIface(), new MethodSignature(method));
    }

    private boolean isMethodReturningPostDefined()
    {
        return null != getMethodReturningPost();
    }

    private Method getMethodVoidOnError(Class class1)
    {
        AnnotationsRegistry.Value value = annotationsForIface.getValue();
        if(null == value)
            return null;
        Map map = value.getMapVoidOnError(annotationsForIface.getIface(), new MethodSignature(method));
        if(null == map)
            return null;
        else
            return (Method)map.get(class1);
    }

    private boolean isMethodVoidOnErrorDefined()
    {
        boolean flag = false;
        Iterator iterator = exceptionsToCatch.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Class class1 = (Class)iterator.next();
            if(null != getMethodVoidOnError(class1))
                flag = true;
        } while(true);
        return flag;
    }

    private Method getMethodReturningOnError(Class class1)
    {
        AnnotationsRegistry.Value value = annotationsForIface.getValue();
        if(null == value)
            return null;
        Map map = value.getMapReturningOnError(annotationsForIface.getIface(), new MethodSignature(method));
        if(null == map)
            return null;
        else
            return (Method)map.get(class1);
    }

    private boolean isMethodReturningOnErrorDefined()
    {
        boolean flag = false;
        Iterator iterator = exceptionsToCatch.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Class class1 = (Class)iterator.next();
            if(null != getMethodReturningOnError(class1))
                flag = true;
        } while(true);
        return flag;
    }

    private boolean isMethodOnErrorDefined()
    {
        return returns ? isMethodReturningOnErrorDefined() : isMethodVoidOnErrorDefined();
    }

    private boolean isMethodPostDefined()
    {
        return returns ? isMethodReturningPostDefined() : isMethodVoidPostDefined();
    }

    final Method getMethodPost()
    {
        return returns ? getMethodReturningPost() : getMethodVoidPost();
    }

    boolean isAnyInterceptorDefined()
    {
        return isMethodPreDefined() || isMethodVoidPostDefined() || isMethodReturningPostDefined() || isMethodVoidOnErrorDefined() || isMethodReturningOnErrorDefined();
    }

    ProxyResultPolicy getProxyResultPolicy()
    {
        AnnotationsRegistry.Value value = annotationsForIface.getValue();
        if(null == value)
            return ProxyResultPolicy.CACHE;
        else
            return value.getProxyResultPolicy(method);
    }

    void generate(ClassWriter classwriter)
    {
        MethodVisitor methodvisitor = classwriter.visitMethod(method.isVarArgs() ? 129 : 1, methodName, signature, null, throwables);
        methodvisitor.visitCode();
        Label label = new Label();
        Label label1 = new Label();
        Label label2 = new Label();
        Label label3 = new Label();
        int j = 1;
        Class aclass[] = parameterTypes;
        int i2 = aclass.length;
        for(int j3 = 0; j3 < i2; j3++)
        {
            Class class4 = aclass[j3];
            j += Utils.varSize(class4);
        }

        int i = j;
        Label alabel[];
        if(isMethodOnErrorDefined())
        {
            int k = exceptionsToCatch.size();
            alabel = new Label[k];
            for(int i1 = 0; i1 < k; i1++)
            {
                Class class1 = (Class)exceptionsToCatch.get(i1);
                Method method1 = returns ? getMethodReturningOnError(class1) : getMethodVoidOnError(class1);
                if(null != method1)
                    methodvisitor.visitTryCatchBlock(label2, label3, alabel[i1] = new Label(), Utils.makeSlashed((Class)exceptionsToCatch.get(i1)));
            }

        } else
        {
            alabel = null;
        }
        methodvisitor.visitLabel(label);
        methodvisitor.visitLabel(label2);
        if(isMethodPreDefined())
        {
            methodvisitor.visitVarInsn(25, 0);
            methodvisitor.visitFieldInsn(178, proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
            methodvisitor.visitVarInsn(25, 0);
            int l = parameterTypes.length;
            if(method.isVarArgs() && 1 == l)
                methodvisitor.visitVarInsn(25, 1);
            else
            if(0 == l)
            {
                methodvisitor.visitFieldInsn(178, proxyName, "zeroLengthObjectArray", "[Ljava/lang/Object;");
            } else
            {
                Utils.loadConst(methodvisitor, l);
                methodvisitor.visitTypeInsn(189, "java/lang/Object");
                int j1 = 1;
                for(int j2 = 0; j2 < l; j2++)
                {
                    Class class2 = parameterTypes[j2];
                    methodvisitor.visitInsn(89);
                    Utils.loadConst(methodvisitor, j2);
                    methodvisitor.visitVarInsn(Utils.loadOpcode(class2), j1);
                    Utils.autoBox(methodvisitor, class2);
                    methodvisitor.visitInsn(83);
                    j1 += Utils.varSize(class2);
                }

            }
            methodvisitor.visitMethodInsn(183, superclassName, getMethodPre().getName(), "(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)V");
        }
        if(isMethodPostDefined())
        {
            methodvisitor.visitVarInsn(25, 0);
            methodvisitor.visitFieldInsn(178, proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
        }
        boolean flag = isResultProxied();
        if(returns && flag)
        {
            methodvisitor.visitVarInsn(25, 0);
            methodvisitor.visitFieldInsn(180, proxyName, "proxyFactory", Utils.makeType(oracle/jdbc/proxy/ProxyFactory.getName()));
        }
        methodvisitor.visitVarInsn(25, 0);
        if(callDelegate)
            methodvisitor.visitFieldInsn(180, proxyName, "delegate", ifaceType);
        loadDelegateParams(methodvisitor);
        methodvisitor.visitMethodInsn(callDelegate ? 185 : 183, callDelegate ? ifaceName : superclassName, methodName, signature);
        if(returns && flag)
        {
            Utils.cast(methodvisitor, returnType, java/lang/Object);
            methodvisitor.visitVarInsn(25, 0);
            methodvisitor.visitVarInsn(25, 0);
            methodvisitor.visitFieldInsn(180, proxyName, "proxyCache", "Ljava/util/Map;");
            methodvisitor.visitFieldInsn(178, proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
            static class _cls2
            {

                static final int $SwitchMap$oracle$jdbc$proxy$annotation$ProxyResultPolicy[];

                static 
                {
                    $SwitchMap$oracle$jdbc$proxy$annotation$ProxyResultPolicy = new int[ProxyResultPolicy.values().length];
                    try
                    {
                        $SwitchMap$oracle$jdbc$proxy$annotation$ProxyResultPolicy[ProxyResultPolicy.CREATE.ordinal()] = 1;
                    }
                    catch(NoSuchFieldError nosuchfielderror) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$proxy$annotation$ProxyResultPolicy[ProxyResultPolicy.CACHE.ordinal()] = 2;
                    }
                    catch(NoSuchFieldError nosuchfielderror1) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$proxy$annotation$ProxyResultPolicy[ProxyResultPolicy.CREATE_CACHE.ordinal()] = 3;
                    }
                    catch(NoSuchFieldError nosuchfielderror2) { }
                }
            }

            String s;
            switch(_cls2..SwitchMap.oracle.jdbc.proxy.annotation.ProxyResultPolicy[getProxyResultPolicy().ordinal()])
            {
            case 1: // '\001'
                s = "proxyForCreate";
                break;

            case 2: // '\002'
                s = "proxyForCache";
                break;

            case 3: // '\003'
                s = "proxyForCreateCache";
                break;

            default:
                throw new RuntimeException("internal error");
            }
            methodvisitor.visitMethodInsn(182, Utils.makeSlashed(oracle/jdbc/proxy/ProxyFactory.getName()), s, "(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Map;Ljava/lang/reflect/Method;)Ljava/lang/Object;");
        }
        if(isMethodPostDefined())
        {
            if(returns)
                Utils.cast(methodvisitor, ((Class) (flag ? java/lang/Object : returnType)), getMethodPost().getParameterTypes()[1]);
            methodvisitor.visitMethodInsn(182, superclassName, getMethodPost().getName(), (new StringBuilder()).append("(Ljava/lang/reflect/Method;").append(returns ? Utils.makeType(getMethodPost().getParameterTypes()[1]) : "").append(")").append(Utils.makeType(getMethodPost().getReturnType())).toString());
            if(returns)
                Utils.cast(methodvisitor, getMethodPost().getReturnType(), returnType);
        } else
        if(returns)
            Utils.cast(methodvisitor, ((Class) (flag ? java/lang/Object : returnType)), returnType);
        methodvisitor.visitLabel(label3);
        methodvisitor.visitInsn(Utils.returnOpcode(returnType));
        Label alabel1[];
        Label alabel2[];
        if(isMethodOnErrorDefined())
        {
            int k1 = exceptionsToCatch.size();
            alabel1 = new Label[k1];
            alabel2 = new Label[k1];
            for(int k2 = 0; k2 < k1; k2++)
            {
                Class class3 = (Class)exceptionsToCatch.get(k2);
                Method method2 = returns ? getMethodReturningOnError(class3) : getMethodVoidOnError(class3);
                if(null != method2)
                {
                    methodvisitor.visitLabel(alabel[k2]);
                    methodvisitor.visitFrame(4, 0, null, 1, new Object[] {
                        Utils.makeSlashed(class3)
                    });
                    methodvisitor.visitVarInsn(58, i);
                    methodvisitor.visitLabel(alabel1[k2] = new Label());
                    methodvisitor.visitVarInsn(25, 0);
                    methodvisitor.visitFieldInsn(178, proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
                    if(returns && isMethodPostDefined())
                    {
                        methodvisitor.visitVarInsn(25, 0);
                        methodvisitor.visitFieldInsn(178, proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
                    }
                    methodvisitor.visitVarInsn(25, i);
                    methodvisitor.visitMethodInsn(182, superclassName, method2.getName(), (new StringBuilder()).append("(Ljava/lang/reflect/Method;").append(Utils.makeType(method2.getParameterTypes()[1].getName())).append(")").append(Utils.makeType(method2.getReturnType().getName())).toString());
                    if(returns && isMethodPostDefined())
                    {
                        Utils.cast(methodvisitor, method2.getReturnType(), getMethodPost().getParameterTypes()[1]);
                        methodvisitor.visitMethodInsn(182, superclassName, getMethodPost().getName(), (new StringBuilder()).append("(Ljava/lang/reflect/Method;").append(Utils.makeType(getMethodPost().getParameterTypes()[1].getName())).append(")").append(Utils.makeType(getMethodPost().getReturnType().getName())).toString());
                        Utils.cast(methodvisitor, getMethodPost().getReturnType(), returnType);
                    } else
                    {
                        Utils.cast(methodvisitor, method2.getReturnType(), returnType);
                    }
                    methodvisitor.visitInsn(Utils.returnOpcode(returnType));
                    methodvisitor.visitLabel(alabel2[k2] = new Label());
                }
            }

        } else
        {
            alabel1 = alabel2 = null;
        }
        methodvisitor.visitLabel(label1);
        int l1 = 0;
        methodvisitor.visitLocalVariable("this", proxyType, null, label, label1, l1++);
        for(int l2 = 0; l2 < parameterTypes.length; l2++)
        {
            methodvisitor.visitLocalVariable((new StringBuilder()).append("arg").append(l2).toString(), Utils.makeType(parameterTypes[l2]), null, label, label1, l1);
            l1 += Utils.varSize(parameterTypes[l2]);
        }

        if(isMethodOnErrorDefined())
        {
            if(i != l1)
                throw new RuntimeException("wrong exception index");
            int i3 = exceptionsToCatch.size();
            for(int k3 = 0; k3 < i3; k3++)
            {
                Class class5 = (Class)exceptionsToCatch.get(k3);
                Method method3 = returns ? getMethodReturningOnError(class5) : getMethodVoidOnError(class5);
                if(null != method3)
                    methodvisitor.visitLocalVariable("e", Utils.makeType((Class)exceptionsToCatch.get(k3)), null, alabel1[k3], alabel2[k3], i);
            }

        }
        methodvisitor.visitMaxs(0, 0);
        methodvisitor.visitEnd();
    }

    private void loadDelegateParams(MethodVisitor methodvisitor)
    {
        String s = Utils.makeSlashed(oracle/jdbc/proxy/_Proxy_.getName());
        int i = 1;
        for(int j = 0; j < parameterTypes.length; j++)
        {
            Class class1 = parameterTypes[j];
            String s1 = Utils.makeSlashed(class1.getName());
            boolean flag = false;
            Iterator iterator = annotationsForIface.getRegistry().values().iterator();
label0:
            do
            {
                if(!iterator.hasNext())
                    break;
                AnnotationsRegistry.Value value = (AnnotationsRegistry.Value)iterator.next();
                Iterator iterator1 = value.getIfacesToProxy().iterator();
                Class class2;
                do
                {
                    if(!iterator1.hasNext())
                        continue label0;
                    class2 = (Class)iterator1.next();
                } while(!class1.isAssignableFrom(class2));
                flag = true;
            } while(true);
            if(flag)
            {
                methodvisitor.visitVarInsn(Utils.loadOpcode(class1), i);
                methodvisitor.visitTypeInsn(193, s);
                Label label = new Label();
                methodvisitor.visitJumpInsn(153, label);
                methodvisitor.visitVarInsn(Utils.loadOpcode(class1), i);
                methodvisitor.visitTypeInsn(192, s);
                methodvisitor.visitMethodInsn(185, s, "_getDelegate_", "()Ljava/lang/Object;");
                methodvisitor.visitTypeInsn(192, s1);
                Label label1 = new Label();
                methodvisitor.visitJumpInsn(167, label1);
                methodvisitor.visitLabel(label);
                methodvisitor.visitFrame(3, 0, null, 0, null);
                methodvisitor.visitVarInsn(Utils.loadOpcode(class1), i);
                methodvisitor.visitLabel(label1);
                methodvisitor.visitFrame(4, 0, null, 1, new Object[] {
                    s1
                });
            } else
            {
                methodvisitor.visitVarInsn(Utils.loadOpcode(class1), i);
            }
            i += Utils.varSize(parameterTypes[j]);
        }

    }

    void initializeMethodObject(MethodVisitor methodvisitor)
    {
        int i = parameterTypes.length;
        methodvisitor.visitLdcInsn(Type.getType(Utils.makeType(method.getDeclaringClass().getName())));
        methodvisitor.visitLdcInsn(methodName);
        Utils.loadConst(methodvisitor, i);
        methodvisitor.visitTypeInsn(189, "java/lang/Class");
        for(int j = 0; j < i; j++)
        {
            methodvisitor.visitInsn(89);
            Utils.loadConst(methodvisitor, j);
            Utils.loadClass(methodvisitor, parameterTypes[j]);
            methodvisitor.visitInsn(83);
        }

        methodvisitor.visitMethodInsn(182, "java/lang/Class", "getDeclaredMethod", "(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;");
        methodvisitor.visitFieldInsn(179, proxyName, getMethodObject(), "Ljava/lang/reflect/Method;");
    }


}
