// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   MethodSignature.java

package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.util.Arrays;

// Referenced classes of package oracle.jdbc.proxy:
//            HashUtil

class MethodSignature
{

    private final String name;
    private final Class parameterTypes[];
    private final Class returnType;
    private Integer hashCode;

    MethodSignature(Method method)
    {
        hashCode = null;
        name = method.getName();
        parameterTypes = method.getParameterTypes();
        returnType = method.getReturnType();
    }

    MethodSignature(String s, Class aclass[], Class class1)
    {
        hashCode = null;
        name = s;
        parameterTypes = aclass;
        returnType = class1;
    }

    public boolean equals(Object obj)
    {
        if(null == obj)
            return false;
        if(!(obj instanceof MethodSignature))
            return false;
        MethodSignature methodsignature = (MethodSignature)obj;
        if(this == methodsignature)
            return true;
        if(!name.equals(methodsignature.name))
            return false;
        if(!Arrays.deepEquals(parameterTypes, methodsignature.parameterTypes))
            return false;
        if(null != returnType && null != methodsignature.returnType && !returnType.equals(methodsignature.returnType))
            throw new RuntimeException((new StringBuilder()).append("methods \"").append(name).append("\" have the same signature \"").append(parameterTypes).append("\" but different return types: \"").append(returnType).append("\" and \"").append(methodsignature.returnType).append('"').toString());
        else
            return true;
    }

    public int hashCode()
    {
        if(null == hashCode)
        {
            hashCode = new Integer(23);
            hashCode = Integer.valueOf(HashUtil.hash(hashCode.intValue(), name));
            hashCode = Integer.valueOf(HashUtil.hash(hashCode.intValue(), parameterTypes));
        }
        return hashCode.intValue();
    }

    String getName()
    {
        return name;
    }

    Class[] getParameterTypes()
    {
        return parameterTypes;
    }

    Class getReturnType()
    {
        return returnType;
    }
}
