// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AnnotationsRegistry.java

package oracle.jdbc.proxy;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.*;
import oracle.jdbc.proxy.annotation.GetCreator;
import oracle.jdbc.proxy.annotation.GetDelegate;
import oracle.jdbc.proxy.annotation.GetProxy;
import oracle.jdbc.proxy.annotation.Methods;
import oracle.jdbc.proxy.annotation.OnError;
import oracle.jdbc.proxy.annotation.Post;
import oracle.jdbc.proxy.annotation.Pre;
import oracle.jdbc.proxy.annotation.ProxyFor;
import oracle.jdbc.proxy.annotation.ProxyLocale;
import oracle.jdbc.proxy.annotation.ProxyResult;
import oracle.jdbc.proxy.annotation.ProxyResultPolicy;
import oracle.jdbc.proxy.annotation.SetDelegate;
import oracle.jdbc.proxy.annotation.Signature;

// Referenced classes of package oracle.jdbc.proxy:
//            MethodSignature

class AnnotationsRegistry
{
    static class Value
    {
        private static class Rest
        {

            private final Method pre;
            private final Method voidPost;
            private final Method returningPost;
            private final Map voidOnErrorsMap;
            private final Map returningOnErrorsMap;

            Method getPre()
            {
                return pre;
            }

            Map getReturningOnError()
            {
                return returningOnErrorsMap;
            }

            Method getReturningPost()
            {
                return returningPost;
            }

            Map getVoidOnError()
            {
                return voidOnErrorsMap;
            }

            Method getVoidPost()
            {
                return voidPost;
            }

            Rest(Method method, Method method1, Method method2, Map map, Map map1)
            {
                pre = method;
                voidPost = method1;
                returningPost = method2;
                voidOnErrorsMap = map;
                returningOnErrorsMap = map1;
            }
        }

        private static class MethodSpecific
        {

            private final Map ref;
            private final String annotationType;

            void put(MethodSignature methodsignature, Object obj)
            {
                if(null != ref.put(methodsignature, obj))
                    throw SyntaxError.annotationDefinedMoreThanOnce(annotationType);
                else
                    return;
            }

            Object get(MethodSignature methodsignature)
            {
                return ref.get(methodsignature);
            }

            private MethodSpecific(String s)
            {
                ref = new HashMap();
                annotationType = s;
            }

        }


        private final Class superclass;
        private final List ifacesToProxy = new ArrayList();
        private final MethodSpecific.Pres pres = new MethodSpecific.Pres();
        private final MethodSpecific.VoidPosts voidPosts = new MethodSpecific.VoidPosts();
        private final MethodSpecific.ReturningPosts returningPosts = new MethodSpecific.ReturningPosts();
        private final MethodSpecific.VoidOnErrors voidOnErrors = new MethodSpecific.VoidOnErrors();
        private final MethodSpecific.ReturningOnErrors returningOnErrors = new MethodSpecific.ReturningOnErrors();
        private final Rest rest = parseAnnotations();
        private Method methodGetCreator;
        private Method methodGetDelegate;
        private Method methodGetProxy;
        private Method methodSetDelegate;
        private boolean isProxyLocale;
        private ProxyResultPolicy proxyResultPolicy;
        private Method pre;
        private Method voidPost;
        private Method returningPost;
        private Map voidOnErrorsMap;
        private Map returningOnErrorsMap;
        private static final Class listOfMethodOperators[] = {
            oracle/jdbc/proxy/annotation/Pre, oracle/jdbc/proxy/annotation/Post, oracle/jdbc/proxy/annotation/OnError, oracle/jdbc/proxy/annotation/GetCreator, oracle/jdbc/proxy/annotation/GetDelegate, oracle/jdbc/proxy/annotation/GetProxy, oracle/jdbc/proxy/annotation/SetDelegate
        };

        private void parseAnnotationTypeProxyResult()
        {
            if(superclass.isAnnotationPresent(oracle/jdbc/proxy/annotation/ProxyResult))
            {
                ProxyResult proxyresult = (ProxyResult)superclass.getAnnotation(oracle/jdbc/proxy/annotation/ProxyResult);
                proxyResultPolicy = proxyresult.value();
            }
        }

        private void parseAnnotationProxyLocale()
        {
            if(superclass.isAnnotationPresent(oracle/jdbc/proxy/annotation/ProxyLocale))
                isProxyLocale = true;
        }

        private void parseAnnotationProxyFor()
        {
            if(superclass.isAnnotationPresent(oracle/jdbc/proxy/annotation/ProxyFor))
            {
                ProxyFor proxyfor = (ProxyFor)superclass.getAnnotation(oracle/jdbc/proxy/annotation/ProxyFor);
                Class aclass[] = proxyfor.value();
                int i = aclass.length;
                for(int j = 0; j < i; j++)
                {
                    Class class1 = aclass[j];
                    if(!class1.isInterface())
                        throw SyntaxError.mustBeIface(class1);
                    ifacesToProxy.add(class1);
                }

            } else
            {
                throw SyntaxError.noProxyForClass(superclass);
            }
        }

        private void checkIsSingle(Method method, Class class1)
        {
            Class aclass[] = listOfMethodOperators;
            int i = aclass.length;
            for(int j = 0; j < i; j++)
            {
                Class class2 = aclass[j];
                if(!class2.equals(class1) && method.isAnnotationPresent(class2))
                    throw SyntaxError.onlyOneAllowed;
            }

        }

        private void parseAnnotationPre(Method method)
        {
            if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/Pre))
            {
                checkIsSingle(method, oracle/jdbc/proxy/annotation/Pre);
                if(!Arrays.deepEquals(new Class[0], method.getExceptionTypes()))
                    throw SyntaxError.wrongPre;
                if(!Arrays.deepEquals(new Class[] {
        java/lang/reflect/Method, java/lang/Object, [Ljava/lang/Object;
    }, method.getParameterTypes()))
                    throw SyntaxError.wrongPre;
                if(!Void.TYPE.equals(method.getReturnType()))
                    throw SyntaxError.wrongPre;
                if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/Methods))
                {
                    Signature asignature[] = ((Methods)method.getAnnotation(oracle/jdbc/proxy/annotation/Methods)).signatures();
                    int i = asignature.length;
                    for(int j = 0; j < i; j++)
                    {
                        Signature signature = asignature[j];
                        pres.put(new MethodSignature(signature.name(), signature.args(), null), method);
                    }

                } else
                {
                    if(null != pre)
                        throw SyntaxError.onlyOneMethodslessAllowed;
                    pre = method;
                }
            }
        }

        private Class doAutoBoxing(Class class1)
        {
            if(Boolean.TYPE.equals(class1))
                return java/lang/Boolean;
            if(Character.TYPE.equals(class1))
                return java/lang/Character;
            if(Byte.TYPE.equals(class1))
                return java/lang/Byte;
            if(Short.TYPE.equals(class1))
                return java/lang/Short;
            if(Integer.TYPE.equals(class1))
                return java/lang/Integer;
            if(Long.TYPE.equals(class1))
                return java/lang/Long;
            if(Float.TYPE.equals(class1))
                return java/lang/Float;
            if(Double.TYPE.equals(class1))
                return java/lang/Double;
            else
                return class1;
        }

        private void checkReturnTypesMismatch(MethodSignature methodsignature, Method method)
        {
            Method method1;
            Class class1;
            Iterator iterator;
            method1 = null;
            class1 = doAutoBoxing(method.getReturnType());
            iterator = getIfacesToProxy().iterator();
_L2:
            Class class2;
            if(!iterator.hasNext())
                break; /* Loop/switch isn't completed */
            class2 = (Class)iterator.next();
            Class class3;
            method1 = class2.getDeclaredMethod(methodsignature.getName(), methodsignature.getParameterTypes());
            class3 = doAutoBoxing(method1.getReturnType());
            if(!Void.TYPE.equals(class3))
                try
                {
                    class1.asSubclass(class3);
                }
                catch(NoSuchMethodException nosuchmethodexception) { }
                catch(ClassCastException classcastexception)
                {
                    throw SyntaxError.returnTypeMismatch(method, method1);
                }
            if(true) goto _L2; else goto _L1
_L1:
        }

        private void checkReturnTypesMismatch(Method method)
        {
            Class class1 = doAutoBoxing(method.getReturnType());
            for(Iterator iterator = getIfacesToProxy().iterator(); iterator.hasNext();)
            {
                Class class2 = (Class)iterator.next();
                Method amethod[] = class2.getDeclaredMethods();
                int i = amethod.length;
                int j = 0;
                while(j < i) 
                {
                    Method method1 = amethod[j];
                    Class class3 = doAutoBoxing(method1.getReturnType());
                    if(!Void.TYPE.equals(class3))
                        try
                        {
                            class3.asSubclass(class1);
                        }
                        catch(ClassCastException classcastexception)
                        {
                            throw SyntaxError.returnTypeMismatch(method, method1);
                        }
                    j++;
                }
            }

        }

        private void parseAnnotationPost(Method method)
        {
            if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/Post))
            {
                checkIsSingle(method, oracle/jdbc/proxy/annotation/Post);
                Class class1 = method.getReturnType();
                Class aclass[] = method.getParameterTypes();
                Class aclass1[] = method.getExceptionTypes();
                if(!Arrays.deepEquals(new Class[0], aclass1))
                    throw SyntaxError.wrongPost;
                if(Void.TYPE.equals(class1) && Arrays.deepEquals(new Class[] {
        java/lang/reflect/Method
    }, aclass))
                {
                    if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/Methods))
                    {
                        Signature asignature[] = ((Methods)method.getAnnotation(oracle/jdbc/proxy/annotation/Methods)).signatures();
                        int i = asignature.length;
                        for(int k = 0; k < i; k++)
                        {
                            Signature signature = asignature[k];
                            voidPosts.put(new MethodSignature(signature.name(), signature.args(), null), method);
                        }

                    } else
                    {
                        if(null != voidPost)
                            throw SyntaxError.onlyOneMethodslessAllowed;
                        voidPost = method;
                    }
                } else
                if(!Void.TYPE.equals(class1) && Arrays.deepEquals(new Class[] {
        java/lang/reflect/Method, class1
    }, aclass))
                {
                    if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/Methods))
                    {
                        Signature asignature1[] = ((Methods)method.getAnnotation(oracle/jdbc/proxy/annotation/Methods)).signatures();
                        int j = asignature1.length;
                        for(int l = 0; l < j; l++)
                        {
                            Signature signature1 = asignature1[l];
                            MethodSignature methodsignature = new MethodSignature(signature1.name(), signature1.args(), null);
                            checkReturnTypesMismatch(methodsignature, method);
                            returningPosts.put(methodsignature, method);
                        }

                    } else
                    {
                        checkReturnTypesMismatch(method);
                        if(null != returningPost)
                            throw SyntaxError.onlyOneMethodslessAllowed;
                        returningPost = method;
                    }
                } else
                {
                    throw SyntaxError.wrongPost;
                }
            }
        }

        private void parseAnnotationOnError(Method method)
        {
            if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/OnError))
            {
                checkIsSingle(method, oracle/jdbc/proxy/annotation/OnError);
                Class class1 = method.getReturnType();
                Class aclass[] = method.getParameterTypes();
                Class aclass1[] = method.getExceptionTypes();
                OnError onerror = (OnError)method.getAnnotation(oracle/jdbc/proxy/annotation/OnError);
                Class class2 = onerror.value();
                if(Arrays.deepEquals(new Class[] {
        java/lang/reflect/Method, class2
    }, aclass) && Arrays.deepEquals(new Class[] {
        class2
    }, aclass1) && Void.TYPE.equals(class1))
                {
                    if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/Methods))
                    {
                        Signature asignature[] = ((Methods)method.getAnnotation(oracle/jdbc/proxy/annotation/Methods)).signatures();
                        int i = asignature.length;
                        for(int k = 0; k < i; k++)
                        {
                            Signature signature = asignature[k];
                            MethodSignature methodsignature = new MethodSignature(signature.name(), signature.args(), null);
                            Object obj = (Map)voidOnErrors.get(methodsignature);
                            if(null == obj)
                                voidOnErrors.put(methodsignature, obj = new HashMap());
                            if(null != ((Map) (obj)).put(class2, method))
                                throw SyntaxError.onlyOneOnErrorExceptionTypeAllowed;
                        }

                    } else
                    if(null != voidOnErrorsMap.put(class2, method))
                        throw SyntaxError.onlyOneMethodslessAllowed;
                } else
                if(Arrays.deepEquals(new Class[] {
        java/lang/reflect/Method, class2
    }, aclass) && Arrays.deepEquals(new Class[] {
        class2
    }, aclass1) && !Void.TYPE.equals(class1))
                {
                    if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/Methods))
                    {
                        Signature asignature1[] = ((Methods)method.getAnnotation(oracle/jdbc/proxy/annotation/Methods)).signatures();
                        int j = asignature1.length;
                        for(int l = 0; l < j; l++)
                        {
                            Signature signature1 = asignature1[l];
                            MethodSignature methodsignature1 = new MethodSignature(signature1.name(), signature1.args(), null);
                            checkReturnTypesMismatch(methodsignature1, method);
                            Object obj1 = (Map)returningOnErrors.get(methodsignature1);
                            if(null == obj1)
                                returningOnErrors.put(methodsignature1, obj1 = new HashMap());
                            if(null != ((Map) (obj1)).put(class2, method))
                                throw SyntaxError.onlyOneOnErrorExceptionTypeAllowed;
                        }

                    } else
                    {
                        checkReturnTypesMismatch(method);
                        if(null != returningOnErrorsMap.put(class2, method))
                            throw SyntaxError.onlyOneMethodslessAllowed;
                    }
                } else
                {
                    throw SyntaxError.wrongOnError;
                }
            }
        }

        private void parseAnnotationGetCreator(Method method)
        {
            if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/GetCreator))
            {
                checkIsSingle(method, oracle/jdbc/proxy/annotation/GetCreator);
                if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/Methods))
                    throw SyntaxError.wrongMethodsContext;
                int i = method.getModifiers();
                if(!Modifier.isProtected(i))
                    throw SyntaxError.wrongGetCreatorMustBeProtected;
                if(!Modifier.isAbstract(i))
                    throw SyntaxError.wrongGetCreatorMustBeAbstract;
                if(!Arrays.deepEquals(new Class[0], method.getParameterTypes()))
                    throw SyntaxError.wrongGetCreator;
                if(!java/lang/Object.equals(method.getReturnType()))
                    throw SyntaxError.wrongGetCreator;
                methodGetCreator = method;
            }
        }

        private void parseAnnotationGetProxy(Method method)
        {
            if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/GetProxy))
            {
                checkIsSingle(method, oracle/jdbc/proxy/annotation/GetProxy);
                if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/Methods))
                    throw SyntaxError.wrongMethodsContext;
                int i = method.getModifiers();
                if(!Modifier.isProtected(i))
                    throw SyntaxError.wrongGetProxyMustBeProtected;
                if(!Modifier.isAbstract(i))
                    throw SyntaxError.wrongGetProxyMustBeAbstract;
                if(!Arrays.deepEquals(new Class[] {
        java/lang/Object, java/lang/Object
    }, method.getParameterTypes()))
                    throw SyntaxError.wrongGetProxy;
                if(!java/lang/Object.equals(method.getReturnType()))
                    throw SyntaxError.wrongGetProxy;
                methodGetProxy = method;
            }
        }

        private void parseAnnotationGetDelegate(Method method)
        {
            if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/GetDelegate))
            {
                checkIsSingle(method, oracle/jdbc/proxy/annotation/GetDelegate);
                if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/Methods))
                    throw SyntaxError.wrongMethodsContext;
                int i = method.getModifiers();
                if(!Modifier.isProtected(i))
                    throw SyntaxError.wrongGetDelegateMustBeProtected;
                if(!Modifier.isAbstract(i))
                    throw SyntaxError.wrongGetDelegateMustBeAbstract;
                if(!Arrays.deepEquals(new Class[0], method.getParameterTypes()))
                    throw SyntaxError.wrongGetDelegate;
                if(Void.TYPE.equals(method.getReturnType()))
                    throw SyntaxError.wrongGetDelegate;
                methodGetDelegate = method;
            }
        }

        private void parseAnnotationSetDelegate(Method method)
        {
            if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/SetDelegate))
            {
                checkIsSingle(method, oracle/jdbc/proxy/annotation/SetDelegate);
                if(method.isAnnotationPresent(oracle/jdbc/proxy/annotation/Methods))
                    throw SyntaxError.wrongMethodsContext;
                int i = method.getModifiers();
                if(!Modifier.isProtected(i))
                    throw SyntaxError.wrongSetDelegateMustBeProtected;
                if(!Modifier.isAbstract(i))
                    throw SyntaxError.wrongSetDelegateMustBeAbstract;
                if(1 != method.getParameterTypes().length)
                    throw SyntaxError.wrongSetDelegate;
                if(!Void.TYPE.equals(method.getReturnType()))
                    throw SyntaxError.wrongSetDelegate;
                methodSetDelegate = method;
            }
        }

        private Rest parseAnnotations()
        {
            parseAnnotationProxyFor();
            parseAnnotationProxyLocale();
            parseAnnotationTypeProxyResult();
            Method amethod[] = superclass.getDeclaredMethods();
            int i = amethod.length;
            for(int j = 0; j < i; j++)
            {
                Method method = amethod[j];
                parseAnnotationPre(method);
                parseAnnotationPost(method);
                parseAnnotationOnError(method);
                parseAnnotationGetCreator(method);
                parseAnnotationGetProxy(method);
                parseAnnotationGetDelegate(method);
                parseAnnotationSetDelegate(method);
            }

            return new Rest(pre, voidPost, returningPost, voidOnErrorsMap, returningOnErrorsMap);
        }

        boolean belongsToIfaceToProxy(Class class1, MethodSignature methodsignature)
        {
            Iterator iterator = ifacesToProxy.iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                Class class2 = (Class)iterator.next();
                try
                {
                    class1.asSubclass(class2);
                    if(isMethodDeclared(class2, methodsignature))
                        return true;
                }
                catch(ClassCastException classcastexception) { }
            } while(true);
            return false;
        }

        private boolean isMethodDeclared(Class class1, MethodSignature methodsignature)
        {
            try
            {
                if(null != class1.getDeclaredMethod(methodsignature.getName(), methodsignature.getParameterTypes()))
                    return true;
            }
            catch(NoSuchMethodException nosuchmethodexception) { }
            Class aclass[] = class1.getInterfaces();
            int i = aclass.length;
            for(int j = 0; j < i; j++)
            {
                Class class2 = aclass[j];
                if(isMethodDeclared(class2, methodsignature))
                    return true;
            }

            return false;
        }

        Method getMethodPre(Class class1, MethodSignature methodsignature)
        {
            Method method = (Method)pres.get(methodsignature);
            if(null != method)
                return method;
            else
                return belongsToIfaceToProxy(class1, methodsignature) ? rest.getPre() : null;
        }

        Method getMethodVoidPost(Class class1, MethodSignature methodsignature)
        {
            Method method = (Method)voidPosts.get(methodsignature);
            if(null != method)
                return method;
            else
                return belongsToIfaceToProxy(class1, methodsignature) ? rest.getVoidPost() : null;
        }

        Method getMethodReturningPost(Class class1, MethodSignature methodsignature)
        {
            Method method = (Method)returningPosts.get(methodsignature);
            if(null != method)
                return method;
            else
                return belongsToIfaceToProxy(class1, methodsignature) ? rest.getReturningPost() : null;
        }

        Map getMapVoidOnError(Class class1, MethodSignature methodsignature)
        {
            Map map = (Map)voidOnErrors.get(methodsignature);
            if(null != map)
                return map;
            else
                return belongsToIfaceToProxy(class1, methodsignature) ? rest.getVoidOnError() : null;
        }

        Map getMapReturningOnError(Class class1, MethodSignature methodsignature)
        {
            Map map = (Map)returningOnErrors.get(methodsignature);
            if(null != map)
                return map;
            else
                return belongsToIfaceToProxy(class1, methodsignature) ? rest.getReturningOnError() : null;
        }

        Method getMethodGetCreator()
        {
            return methodGetCreator;
        }

        Method getMethodGetDelegate()
        {
            return methodGetDelegate;
        }

        Method getMethodGetProxy()
        {
            return methodGetProxy;
        }

        Method getMethodSetDelegate()
        {
            return methodSetDelegate;
        }

        List getIfacesToProxy()
        {
            return ifacesToProxy;
        }

        Class getSuperclass()
        {
            return superclass;
        }

        boolean isProxyLocale()
        {
            return isProxyLocale;
        }

        ProxyResultPolicy getProxyResultPolicy()
        {
            return proxyResultPolicy;
        }

        ProxyResultPolicy getProxyResultPolicy(Method method)
        {
            Method method1;
            try
            {
                method1 = superclass.getDeclaredMethod(method.getName(), method.getParameterTypes());
            }
            catch(NoSuchMethodException nosuchmethodexception)
            {
                return proxyResultPolicy;
            }
            if(method1.isAnnotationPresent(oracle/jdbc/proxy/annotation/ProxyResult))
            {
                ProxyResult proxyresult = (ProxyResult)method1.getAnnotation(oracle/jdbc/proxy/annotation/ProxyResult);
                return proxyresult.value();
            } else
            {
                return proxyResultPolicy;
            }
        }


        Value(Class class1)
        {
            methodGetCreator = null;
            methodGetDelegate = null;
            methodGetProxy = null;
            methodSetDelegate = null;
            isProxyLocale = false;
            proxyResultPolicy = ProxyResultPolicy.CACHE;
            pre = null;
            voidPost = null;
            returningPost = null;
            voidOnErrorsMap = new HashMap();
            returningOnErrorsMap = new HashMap();
            superclass = class1;
        }
    }

    private static class SyntaxError extends RuntimeException
    {

        private static final SyntaxError onlyOneAllowed = new SyntaxError("only one @Pre/@Post/@OnError/@GetDelegate/@SetDelegate/@GetCreator/@GetProxy allowed");
        private static final SyntaxError onlyOneMethodslessAllowed = new SyntaxError("only one @Methods-less @Pre/@Post/@OnError allowed");
        private static final SyntaxError wrongMethodsContext = new SyntaxError("wrong context for @Methods");
        private static final SyntaxError wrongPre = new SyntaxError("wrong @Pre");
        private static final SyntaxError wrongPost = new SyntaxError("wrong @Post");
        private static final SyntaxError wrongOnError = new SyntaxError("wrong @OnError");
        private static final SyntaxError onlyOneOnErrorExceptionTypeAllowed = new SyntaxError("only one @OnError Exception type allowed for a given method");
        private static final SyntaxError wrongGetCreator = new SyntaxError("wrong @GetCreator");
        private static final SyntaxError wrongGetCreatorMustBeProtected = new SyntaxError("wrong @GetCreator: must be protected");
        private static final SyntaxError wrongGetCreatorMustBeAbstract = new SyntaxError("wrong @GetCreator: must be abstract");
        private static final SyntaxError wrongGetDelegate = new SyntaxError("wrong @GetDelegate");
        private static final SyntaxError wrongGetDelegateMustBeProtected = new SyntaxError("wrong @GetDelegate: must be protected");
        private static final SyntaxError wrongGetDelegateMustBeAbstract = new SyntaxError("wrong @GetDelegate: must be abstract");
        private static final SyntaxError wrongGetProxy = new SyntaxError("wrong @GetProxy");
        private static final SyntaxError wrongGetProxyMustBeProtected = new SyntaxError("wrong @GetProxy: must be protected");
        private static final SyntaxError wrongGetProxyMustBeAbstract = new SyntaxError("wrong @GetProxy: must be abstract");
        private static final SyntaxError wrongSetDelegate = new SyntaxError("wrong @SetDelegate");
        private static final SyntaxError wrongSetDelegateMustBeProtected = new SyntaxError("wrong @SetDelegate: must be protected");
        private static final SyntaxError wrongSetDelegateMustBeAbstract = new SyntaxError("wrong @SetDelegate: must be abstract");

        private static SyntaxError mustBeClass(Class class1)
        {
            return new SyntaxError((new StringBuilder()).append(class1.getName()).append(" must be an abstract or concrete class").toString());
        }

        private static SyntaxError mustBeIface(Class class1)
        {
            return new SyntaxError((new StringBuilder()).append(class1.getName()).append(" must be an interface").toString());
        }

        private static SyntaxError annotationDefinedMoreThanOnce(String s)
        {
            return new SyntaxError((new StringBuilder()).append(s).append(" is defined more than once for the same method").toString());
        }

        private static SyntaxError noProxyForClass(Class class1)
        {
            return new SyntaxError((new StringBuilder()).append("no @ProxyFor for class ").append(class1.getName()).toString());
        }

        private static SyntaxError returnTypeMismatch(Method method, Method method1)
        {
            return new SyntaxError((new StringBuilder()).append("interceptor ").append(method.getName()).append(" and interceptee ").append(method1.getName()).append(": have different return types (").append(method.getReturnType().getName()).append(" and ").append(method1.getReturnType().getName()).append(")").toString());
        }


























        SyntaxError(String s)
        {
            super(s);
        }
    }


    private Map ifacesToAnnotatedSuperclasses;

    AnnotationsRegistry()
    {
        ifacesToAnnotatedSuperclasses = new HashMap();
    }

    transient void register(Class aclass[])
    {
        Class aclass1[] = aclass;
        int i = aclass1.length;
        for(int j = 0; j < i; j++)
        {
            Class class1 = aclass1[j];
            if(class1.isInterface())
                throw SyntaxError.mustBeClass(class1);
            Value value = new Value(class1);
            Class class2;
            for(Iterator iterator = value.getIfacesToProxy().iterator(); iterator.hasNext(); ifacesToAnnotatedSuperclasses.put(class2, value))
                class2 = (Class)iterator.next();

        }

    }

    Value get(Class class1)
    {
        return (Value)ifacesToAnnotatedSuperclasses.get(class1);
    }

    Set keySet()
    {
        return ifacesToAnnotatedSuperclasses.keySet();
    }

    Collection values()
    {
        return ifacesToAnnotatedSuperclasses.values();
    }

    boolean containsKey(Object obj)
    {
        return ifacesToAnnotatedSuperclasses.containsKey(obj);
    }
}
