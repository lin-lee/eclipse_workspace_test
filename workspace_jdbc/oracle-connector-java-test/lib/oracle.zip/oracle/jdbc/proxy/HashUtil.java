// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   HashUtil.java

package oracle.jdbc.proxy;

import java.lang.reflect.Array;

class HashUtil
{

    static final int SEED = 23;
    private static final int ODD_PRIME_NUMBER = 37;

    HashUtil()
    {
    }

    static int hash(int i, boolean flag)
    {
        return firstTerm(i) + (flag ? 1 : 0);
    }

    static int hash(int i, char c)
    {
        return firstTerm(i) + c;
    }

    static int hash(int i, int j)
    {
        return firstTerm(i) + j;
    }

    static int hash(int i, long l)
    {
        return firstTerm(i) + (int)(l ^ l >>> 32);
    }

    static int hash(int i, float f)
    {
        return hash(i, Float.floatToIntBits(f));
    }

    static int hash(int i, double d)
    {
        return hash(i, Double.doubleToLongBits(d));
    }

    static int hash(int i, Object obj)
    {
        int j = i;
        if(obj == null)
            j = hash(j, 0);
        else
        if(!obj.getClass().isArray())
        {
            j = hash(j, obj.hashCode());
        } else
        {
            int k = Array.getLength(obj);
            for(int l = 0; l < k; l++)
            {
                Object obj1 = Array.get(obj, l);
                j = hash(j, obj1);
            }

        }
        return j;
    }

    private static int firstTerm(int i)
    {
        return 37 * i;
    }
}
