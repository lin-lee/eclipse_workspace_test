// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ProxyFactory.java

package oracle.jdbc.proxy;

import java.lang.ref.WeakReference;
import java.lang.reflect.*;
import java.util.*;

// Referenced classes of package oracle.jdbc.proxy:
//            AnnotationsRegistry, GeneratedProxiesRegistry, WeakIdentityHashMap, NullProxy, 
//            _Proxy_, ExtractDelegatePermission, ClassGenerator, OracleProxy

public class ProxyFactory
{
    private static final class EMPTY_CLASS
    {

        private EMPTY_CLASS()
        {
        }
    }


    final AnnotationsRegistry annotationsRegistry = new AnnotationsRegistry();
    private final GeneratedProxiesRegistry generatedRegistry = new GeneratedProxiesRegistry();
    private Map delegateClassToProxyClass;
    private final Map delegateToProxy = Collections.synchronizedMap(new WeakIdentityHashMap());
    private final Map delegateToMostSuitableIface = Collections.synchronizedMap(new HashMap());
    private static final Object STALE_DELEGATE = new Object();
    private static final Class EMPTY_VALUE = oracle/jdbc/proxy/ProxyFactory$EMPTY_CLASS;
    private static final ExtractDelegatePermission EXTRACT_DELEGATE_PERMISSION = new ExtractDelegatePermission();

    private ProxyFactory()
    {
        delegateClassToProxyClass = Collections.synchronizedMap(new HashMap());
    }

    public static transient ProxyFactory createProxyFactory(Class aclass[])
    {
        ProxyFactory proxyfactory = new ProxyFactory();
        proxyfactory.annotationsRegistry.register(aclass);
        return proxyfactory;
    }

    public static transient ProxyFactory createJDBCProxyFactory(Class aclass[])
    {
        ProxyFactory proxyfactory = new ProxyFactory();
        proxyfactory.annotationsRegistry.register(new Class[] {
            oracle/jdbc/proxy/NullProxy
        });
        proxyfactory.annotationsRegistry.register(aclass);
        return proxyfactory;
    }

    public final boolean isProxied(Class class1)
    {
        return annotationsRegistry.containsKey(class1);
    }

    public final Object proxyFor(Object obj)
    {
        return proxyFor(obj, this);
    }

    public final Object proxyFor(Object obj, Object obj1)
    {
        return proxyForCache(obj, obj1, null, null);
    }

    public final Object proxyForCreate(Object obj, Object obj1, Map map, Method method)
    {
        if(null == obj)
            return null;
        Class class1 = obj.getClass();
        Class class2 = findMostSuitableIface(class1);
        if(null != method && null != class2 && !method.getReturnType().isAssignableFrom(class2))
            return obj;
        AnnotationsRegistry.Value value = annotationsRegistry.get(class2);
        if(null == value)
            return obj;
        if(null == map)
            map = ((Map) (value.isProxyLocale() ? ((Map) (new WeakIdentityHashMap())) : delegateToProxy));
        Class class3 = getProxyClass(class2, class1);
        if(null == class3)
            return createProxy(class2, obj, obj1, map);
        try
        {
            return class3.getConstructor(new Class[] {
                class2, java/lang/Object, oracle/jdbc/proxy/ProxyFactory, java/util/Map
            }).newInstance(new Object[] {
                obj, obj1, this, map
            });
        }
        catch(NoSuchMethodException nosuchmethodexception)
        {
            throw new RuntimeException(nosuchmethodexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new RuntimeException(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new RuntimeException(invocationtargetexception);
        }
        catch(InstantiationException instantiationexception)
        {
            throw new RuntimeException(instantiationexception);
        }
    }

    public final Object proxyForCache(Object obj, Object obj1, Map map, Method method)
    {
        if(null == obj)
            return null;
        Class class1 = obj.getClass();
        Class class2 = findMostSuitableIface(class1);
        if(null != method && null != class2 && !method.getReturnType().isAssignableFrom(class2))
            return obj;
        AnnotationsRegistry.Value value = annotationsRegistry.get(class2);
        if(null == value)
            return obj;
        if(null == map)
            map = ((Map) (value.isProxyLocale() ? ((Map) (new WeakIdentityHashMap())) : delegateToProxy));
        WeakReference weakreference = (WeakReference)map.get(obj);
        if(null != weakreference)
        {
            Object obj2 = weakreference.get();
            if(null != obj2)
                if(STALE_DELEGATE == obj2)
                    throw new RuntimeException("stale delegate");
                else
                    return obj2;
        }
        Class class3 = getProxyClass(class2, class1);
        if(null == class3)
        {
            Object obj3 = createProxy(class2, obj, obj1, map);
            map.put(obj, new WeakReference(obj3));
            return obj3;
        }
        try
        {
            Object obj4 = class3.getConstructor(new Class[] {
                class2, java/lang/Object, oracle/jdbc/proxy/ProxyFactory, java/util/Map
            }).newInstance(new Object[] {
                obj, obj1, this, map
            });
            map.put(obj, new WeakReference(obj4));
            return obj4;
        }
        catch(NoSuchMethodException nosuchmethodexception)
        {
            throw new RuntimeException(nosuchmethodexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new RuntimeException(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new RuntimeException(invocationtargetexception);
        }
        catch(InstantiationException instantiationexception)
        {
            throw new RuntimeException(instantiationexception);
        }
    }

    public final Object proxyForCreateCache(Object obj, Object obj1, Map map, Method method)
    {
        if(null == obj)
            return null;
        Class class1 = obj.getClass();
        Class class2 = findMostSuitableIface(class1);
        if(null != method && null != class2 && !method.getReturnType().isAssignableFrom(class2))
            return obj;
        AnnotationsRegistry.Value value = annotationsRegistry.get(class2);
        if(null == value)
            return obj;
        if(null == map)
            map = ((Map) (value.isProxyLocale() ? ((Map) (new WeakIdentityHashMap())) : delegateToProxy));
        Class class3 = getProxyClass(class2, class1);
        if(null == class3)
        {
            Object obj2 = createProxy(class2, obj, obj1, map);
            map.put(obj, new WeakReference(obj2));
            return obj2;
        }
        try
        {
            Object obj3 = class3.getConstructor(new Class[] {
                class2, java/lang/Object, oracle/jdbc/proxy/ProxyFactory, java/util/Map
            }).newInstance(new Object[] {
                obj, obj1, this, map
            });
            map.put(obj, new WeakReference(obj3));
            return obj3;
        }
        catch(NoSuchMethodException nosuchmethodexception)
        {
            throw new RuntimeException(nosuchmethodexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new RuntimeException(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new RuntimeException(invocationtargetexception);
        }
        catch(InstantiationException instantiationexception)
        {
            throw new RuntimeException(instantiationexception);
        }
    }

    public void updateDelegate(Object obj, Object obj1, Object obj2)
    {
        delegateToProxy.put(obj1, new WeakReference(STALE_DELEGATE));
        delegateToProxy.put(obj2, new WeakReference(obj));
    }

    public static final Object extractDelegate(OracleProxy oracleproxy)
    {
        SecurityManager securitymanager = System.getSecurityManager();
        if(null != securitymanager)
            securitymanager.checkPermission(EXTRACT_DELEGATE_PERMISSION);
        _Proxy_ _lproxy_;
        try
        {
            _lproxy_ = (_Proxy_)oracleproxy;
        }
        catch(ClassCastException classcastexception)
        {
            throw new IllegalArgumentException();
        }
        return _lproxy_._getDelegate_();
    }

    private Object createProxy(Class class1, Object obj, Object obj1, Map map)
    {
        if(null == class1)
            return obj;
        AnnotationsRegistry.Value value = annotationsRegistry.get(class1);
        Class class2 = value.getSuperclass();
        GeneratedProxiesRegistry.Value value1 = generatedRegistry.get(class1, class2);
        Constructor constructor = null != value1 ? value1.getConstructor() : prepareProxy(class1, class2);
        try
        {
            return constructor.newInstance(new Object[] {
                obj, obj1, this, map
            });
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new RuntimeException(invocationtargetexception.getTargetException());
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new RuntimeException(illegalaccessexception);
        }
        catch(InstantiationException instantiationexception)
        {
            throw new RuntimeException(instantiationexception);
        }
    }

    private Constructor prepareProxy(Class class1, Class class2)
    {
        Class class3 = null;
        try
        {
            class3 = Class.forName((new GeneratedProxiesRegistry.Key(class1, class2)).toString());
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            class3 = ClassGenerator.generate(class1, class2, annotationsRegistry);
        }
        Constructor constructor;
        try
        {
            constructor = class3.getConstructor(new Class[] {
                class1, java/lang/Object, oracle/jdbc/proxy/ProxyFactory, java/util/Map
            });
        }
        catch(NoSuchMethodException nosuchmethodexception)
        {
            throw new RuntimeException(nosuchmethodexception);
        }
        generatedRegistry.put(class1, class2, new GeneratedProxiesRegistry.Value(null, null, class3, constructor));
        return constructor;
    }

    private Class getProxyClass(Class class1, Class class2)
    {
        if(null == class2)
            return null;
        Object obj = (Class)delegateClassToProxyClass.get(class2);
        if(null != obj)
            return EMPTY_VALUE == obj ? null : obj;
        if(null == class1)
            return null;
        obj = generatedRegistry.get(class1, annotationsRegistry.get(class1).getSuperclass());
        if(null == obj)
        {
            return null;
        } else
        {
            Class class3 = ((GeneratedProxiesRegistry.Value) (obj)).getClazz();
            delegateClassToProxyClass.put(class2, null == class3 ? ((Object) (EMPTY_VALUE)) : ((Object) (class3)));
            return class3;
        }
    }

    private Class findMostSuitableIface(Class class1)
    {
        if(null == class1)
            return null;
        Class class2 = (Class)delegateToMostSuitableIface.get(class1);
        if(null != class2)
            return EMPTY_VALUE == class2 ? null : class2;
        int i = -1;
        Class class3 = null;
        Iterator iterator = annotationsRegistry.keySet().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Class class4 = (Class)iterator.next();
            int j = intersectionCardinality(class1, class4);
            if(j >= 1 && j > i)
            {
                i = j;
                class3 = class4;
            }
        } while(true);
        delegateToMostSuitableIface.put(class1, null == class3 ? ((Object) (EMPTY_VALUE)) : ((Object) (class3)));
        return class3;
    }

    private int intersectionCardinality(Class class1, Class class2)
    {
        HashSet hashset = new HashSet();
        collectIfaces(class2, hashset);
        HashSet hashset1 = new HashSet();
        collectIfaces(class1, hashset1);
        int i = hashset.size();
        hashset.removeAll(hashset1);
        if(hashset.size() > 0)
            return -1;
        else
            return i;
    }

    private void collectIfaces(Class class1, Set set)
    {
        if(class1.isInterface())
            set.add(class1);
        Class aclass[] = class1.getInterfaces();
        int i = aclass.length;
        for(int j = 0; j < i; j++)
        {
            Class class3 = aclass[j];
            collectIfaces(class3, set);
        }

        Class class2 = class1.getSuperclass();
        if(null != class2)
            collectIfaces(class2, set);
    }

}
