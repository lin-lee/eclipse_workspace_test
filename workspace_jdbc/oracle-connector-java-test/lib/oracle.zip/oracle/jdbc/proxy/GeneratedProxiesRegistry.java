// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   GeneratedProxiesRegistry.java

package oracle.jdbc.proxy;

import java.lang.reflect.Constructor;
import java.util.*;

// Referenced classes of package oracle.jdbc.proxy:
//            HashUtil

class GeneratedProxiesRegistry
{
    static class Value
    {

        private final String name;
        private final String source;
        private final Class clazz;
        private final Constructor constructor;

        String getName()
        {
            return name;
        }

        String getSource()
        {
            return source;
        }

        Class getClazz()
        {
            return clazz;
        }

        Constructor getConstructor()
        {
            return constructor;
        }

        Value(String s, String s1, Class class1, Constructor constructor1)
        {
            name = s;
            source = s1;
            clazz = class1;
            constructor = constructor1;
        }
    }

    static class Key
    {

        private final String PREFIX = "oracle.jdbc.proxy.";
        private final String SUFFIX = "$$$Proxy";
        private final Class iface;
        private final Class superclass;
        private Integer hashCode;

        public boolean equals(Object obj)
        {
            if(null == obj)
                return false;
            try
            {
                Key key = (Key)obj;
                return iface.equals(key.iface) && superclass.equals(key.superclass);
            }
            catch(ClassCastException classcastexception)
            {
                return false;
            }
        }

        public int hashCode()
        {
            if(null == hashCode)
            {
                hashCode = Integer.valueOf(23);
                hashCode = Integer.valueOf(HashUtil.hash(hashCode.intValue(), iface));
                hashCode = Integer.valueOf(HashUtil.hash(hashCode.intValue(), superclass));
            }
            return hashCode.intValue();
        }

        public String toString()
        {
            return (new StringBuilder()).append("oracle.jdbc.proxy.").append(superclass.getName().replace(".", "$1")).append("$2").append(iface.getName().replace(".", "$1")).append("$$$Proxy").toString();
        }

        private Class parseSuperclass(String s)
        {
            try
            {
                String s1 = s.substring("oracle.jdbc.proxy.".length());
                String s2 = s1.replaceAll("\\$1", ".");
                String s3 = s2.substring(0, s2.indexOf("$2"));
                return Class.forName(s3);
            }
            catch(ClassNotFoundException classnotfoundexception)
            {
                throw new RuntimeException(classnotfoundexception);
            }
        }

        private Class parseIface(String s)
        {
            try
            {
                String s1 = s.substring("oracle.jdbc.proxy.".length());
                String s2 = s1.replaceAll("\\$1", ".");
                String s3 = s2.substring(s2.indexOf("$2") + 2, s2.indexOf("$$$Proxy"));
                return Class.forName(s3);
            }
            catch(ClassNotFoundException classnotfoundexception)
            {
                throw new RuntimeException(classnotfoundexception);
            }
        }

        public Class getIface()
        {
            return iface;
        }

        public Class getSuperclass()
        {
            return superclass;
        }

        public String makePathname()
        {
            return (new StringBuilder()).append(toString().replace(".", "/")).append(".class").toString();
        }

        Key(Class class1, Class class2)
        {
            hashCode = null;
            iface = class1;
            superclass = class2;
        }

        Key(String s)
        {
            hashCode = null;
            iface = parseIface(s);
            superclass = parseSuperclass(s);
        }
    }


    private Map registry;

    GeneratedProxiesRegistry()
    {
        registry = Collections.synchronizedMap(new HashMap());
    }

    void put(Class class1, Class class2, Value value)
    {
        registry.put(new Key(class1, class2), value);
    }

    Value get(Class class1, Class class2)
    {
        return (Value)registry.get(new Key(class1, class2));
    }

    int size()
    {
        return registry.size();
    }

    Set keySet()
    {
        return registry.keySet();
    }

    Collection values()
    {
        return registry.values();
    }
}
