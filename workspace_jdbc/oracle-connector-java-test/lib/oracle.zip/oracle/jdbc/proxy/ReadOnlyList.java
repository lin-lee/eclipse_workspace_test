// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ReadOnlyList.java

package oracle.jdbc.proxy;

import java.util.AbstractList;
import java.util.Collection;

abstract class ReadOnlyList extends AbstractList
{

    private final RuntimeException e = new RuntimeException("read only");

    protected ReadOnlyList()
    {
    }

    public final boolean add(Object obj)
    {
        throw e;
    }

    public final void add(int i, Object obj)
    {
        throw e;
    }

    public final boolean addAll(int i, Collection collection)
    {
        throw e;
    }

    public final void clear()
    {
        throw e;
    }

    public final Object remove(int i)
    {
        throw e;
    }

    public final void removeRange(int i, int j)
    {
        throw e;
    }

    public final Object set(int i, Object obj)
    {
        throw e;
    }
}
