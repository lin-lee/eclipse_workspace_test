// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   WeakIdentityHashMap.java

package oracle.jdbc.proxy;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.*;

public class WeakIdentityHashMap
    implements Map
{
    private class EntrySet extends AbstractSet
    {

        final WeakIdentityHashMap this$0;

        public Iterator iterator()
        {
            return new EntryIterator();
        }

        public boolean contains(Object obj)
        {
            if(!(obj instanceof java.util.Map.Entry))
            {
                return false;
            } else
            {
                java.util.Map.Entry entry = (java.util.Map.Entry)obj;
                WeakIdentityHashMap.Entry entry1 = getEntry(entry.getKey());
                return entry1 != null && entry1.equals(entry);
            }
        }

        public boolean remove(Object obj)
        {
            return removeMapping(obj);
        }

        public int size()
        {
            return WeakIdentityHashMap.this.size();
        }

        public void clear()
        {
            WeakIdentityHashMap.this.clear();
        }

        private List deepCopy()
        {
            ArrayList arraylist = new ArrayList(size());
            java.util.Map.Entry entry;
            for(Iterator iterator1 = iterator(); iterator1.hasNext(); arraylist.add(new java.util.AbstractMap.SimpleEntry(entry)))
                entry = (java.util.Map.Entry)iterator1.next();

            return arraylist;
        }

        public Object[] toArray()
        {
            return deepCopy().toArray();
        }

        public Object[] toArray(Object aobj[])
        {
            return deepCopy().toArray(aobj);
        }

        private EntrySet()
        {
            this$0 = WeakIdentityHashMap.this;
            super();
        }

    }

    private class Values extends AbstractCollection
    {

        final WeakIdentityHashMap this$0;

        public Iterator iterator()
        {
            return new ValueIterator();
        }

        public int size()
        {
            return WeakIdentityHashMap.this.size();
        }

        public boolean contains(Object obj)
        {
            return containsValue(obj);
        }

        public void clear()
        {
            WeakIdentityHashMap.this.clear();
        }

        private Values()
        {
            this$0 = WeakIdentityHashMap.this;
            super();
        }

    }

    private class KeySet extends AbstractSet
    {

        final WeakIdentityHashMap this$0;

        public Iterator iterator()
        {
            return new KeyIterator();
        }

        public int size()
        {
            return WeakIdentityHashMap.this.size();
        }

        public boolean contains(Object obj)
        {
            return containsKey(obj);
        }

        public boolean remove(Object obj)
        {
            if(containsKey(obj))
            {
                WeakIdentityHashMap.this.remove(obj);
                return true;
            } else
            {
                return false;
            }
        }

        public void clear()
        {
            WeakIdentityHashMap.this.clear();
        }

        private KeySet()
        {
            this$0 = WeakIdentityHashMap.this;
            super();
        }

    }

    private class EntryIterator extends HashIterator
    {

        final WeakIdentityHashMap this$0;

        public java.util.Map.Entry next()
        {
            return nextEntry();
        }

        public volatile Object next()
        {
            return next();
        }

        private EntryIterator()
        {
            this$0 = WeakIdentityHashMap.this;
            super();
        }

    }

    private class KeyIterator extends HashIterator
    {

        final WeakIdentityHashMap this$0;

        public Object next()
        {
            return nextEntry().getKey();
        }

        private KeyIterator()
        {
            this$0 = WeakIdentityHashMap.this;
            super();
        }

    }

    private class ValueIterator extends HashIterator
    {

        final WeakIdentityHashMap this$0;

        public Object next()
        {
            return nextEntry().value;
        }

        private ValueIterator()
        {
            this$0 = WeakIdentityHashMap.this;
            super();
        }

    }

    private abstract class HashIterator
        implements Iterator
    {

        private int index;
        private WeakIdentityHashMap.Entry entry;
        private WeakIdentityHashMap.Entry lastReturned;
        private int expectedModCount;
        private Object nextKey;
        private Object currentKey;
        final WeakIdentityHashMap this$0;

        public boolean hasNext()
        {
            WeakIdentityHashMap.Entry aentry[] = table;
            do
            {
                if(nextKey != null)
                    break;
                WeakIdentityHashMap.Entry entry1 = entry;
                int i;
                for(i = index; entry1 == null && i > 0; entry1 = aentry[--i]);
                entry = entry1;
                index = i;
                if(entry1 == null)
                {
                    currentKey = null;
                    return false;
                }
                nextKey = entry1.get();
                if(nextKey == null)
                    entry = entry.next;
            } while(true);
            return true;
        }

        protected WeakIdentityHashMap.Entry nextEntry()
        {
            if(modCount != expectedModCount)
                throw new ConcurrentModificationException();
            if(nextKey == null && !hasNext())
            {
                throw new NoSuchElementException();
            } else
            {
                lastReturned = entry;
                entry = entry.next;
                currentKey = nextKey;
                nextKey = null;
                return lastReturned;
            }
        }

        public void remove()
        {
            if(lastReturned == null)
                throw new IllegalStateException();
            if(modCount != expectedModCount)
            {
                throw new ConcurrentModificationException();
            } else
            {
                WeakIdentityHashMap.this.remove(currentKey);
                expectedModCount = modCount;
                lastReturned = null;
                currentKey = null;
                return;
            }
        }

        HashIterator()
        {
            this$0 = WeakIdentityHashMap.this;
            super();
            entry = null;
            lastReturned = null;
            expectedModCount = modCount;
            nextKey = null;
            currentKey = null;
            index = isEmpty() ? 0 : table.length;
        }
    }

    private static class Entry extends WeakReference
        implements java.util.Map.Entry
    {

        Object value;
        final int hash;
        Entry next;

        public Object getKey()
        {
            return WeakIdentityHashMap.unmaskNull(get());
        }

        public Object getValue()
        {
            return value;
        }

        public Object setValue(Object obj)
        {
            Object obj1 = value;
            value = obj;
            return obj1;
        }

        public boolean equals(Object obj)
        {
            if(!(obj instanceof java.util.Map.Entry))
                return false;
            java.util.Map.Entry entry = (java.util.Map.Entry)obj;
            Object obj1 = getKey();
            Object obj2 = entry.getKey();
            if(obj1 == obj2)
            {
                Object obj3 = getValue();
                Object obj4 = entry.getValue();
                if(obj3 == obj4 || obj3 != null && obj3.equals(obj4))
                    return true;
            }
            return false;
        }

        public int hashCode()
        {
            Object obj = getKey();
            Object obj1 = getValue();
            return (obj != null ? System.identityHashCode(obj) : 0) ^ (obj1 != null ? obj1.hashCode() : 0);
        }

        public String toString()
        {
            return (new StringBuilder()).append(getKey()).append("=").append(getValue()).toString();
        }

        Entry(Object obj, Object obj1, ReferenceQueue referencequeue, int i, Entry entry)
        {
            super(obj, referencequeue);
            value = obj1;
            hash = i;
            next = entry;
        }
    }


    private static final int DEFAULT_INITIAL_CAPACITY = 16;
    private static final int MAXIMUM_CAPACITY = 0x40000000;
    private static final float DEFAULT_LOAD_FACTOR = 0.75F;
    Entry table[];
    private int size;
    private int threshold;
    private final float loadFactor;
    private final ReferenceQueue queue;
    volatile int modCount;
    private static final Object NULL_KEY = new Object();
    private transient Set entrySet;
    volatile transient Set keySet;
    volatile transient Collection values;

    private Entry[] newTable(int i)
    {
        return (Entry[])new Entry[i];
    }

    public WeakIdentityHashMap(int i, float f)
    {
        queue = new ReferenceQueue();
        entrySet = null;
        keySet = null;
        values = null;
        if(i < 0)
            throw new IllegalArgumentException((new StringBuilder()).append("Illegal Initial Capacity: ").append(i).toString());
        if(i > 0x40000000)
            i = 0x40000000;
        if(f <= 0.0F || Float.isNaN(f))
            throw new IllegalArgumentException((new StringBuilder()).append("Illegal Load factor: ").append(f).toString());
        int j;
        for(j = 1; j < i; j <<= 1);
        table = newTable(j);
        loadFactor = f;
        threshold = (int)((float)j * f);
    }

    public WeakIdentityHashMap(int i)
    {
        this(i, 0.75F);
    }

    public WeakIdentityHashMap()
    {
        queue = new ReferenceQueue();
        entrySet = null;
        keySet = null;
        values = null;
        loadFactor = 0.75F;
        threshold = 16;
        table = newTable(16);
    }

    public WeakIdentityHashMap(Map map)
    {
        this(Math.max((int)((float)map.size() / 0.75F) + 1, 16), 0.75F);
        putAll(map);
    }

    private static Object maskNull(Object obj)
    {
        return obj != null ? obj : NULL_KEY;
    }

    static Object unmaskNull(Object obj)
    {
        return obj != NULL_KEY ? obj : null;
    }

    private static boolean eq(Object obj, Object obj1)
    {
        return obj == obj1;
    }

    private static int indexFor(int i, int j)
    {
        return i & j - 1;
    }

    private void expungeStaleEntries()
    {
        java.lang.ref.Reference reference;
        while((reference = queue.poll()) != null) 
            synchronized(queue)
            {
                Entry entry = (Entry)reference;
                int i = indexFor(entry.hash, table.length);
                Entry entry1 = table[i];
                Entry entry2 = entry1;
                do
                {
                    if(entry2 == null)
                        break;
                    Entry entry3 = entry2.next;
                    if(entry2 == entry)
                    {
                        if(entry1 == entry)
                            table[i] = entry3;
                        else
                            entry1.next = entry3;
                        entry.value = null;
                        size--;
                        break;
                    }
                    entry1 = entry2;
                    entry2 = entry3;
                } while(true);
            }
    }

    private Entry[] getTable()
    {
        expungeStaleEntries();
        return table;
    }

    public int size()
    {
        if(size == 0)
        {
            return 0;
        } else
        {
            expungeStaleEntries();
            return size;
        }
    }

    public boolean isEmpty()
    {
        return size() == 0;
    }

    public Object get(Object obj)
    {
        Object obj1 = maskNull(obj);
        int i = System.identityHashCode(obj1);
        Entry aentry[] = getTable();
        int j = indexFor(i, aentry.length);
        for(Entry entry = aentry[j]; entry != null; entry = entry.next)
            if(entry.hash == i && eq(obj1, entry.get()))
                return entry.value;

        return null;
    }

    public boolean containsKey(Object obj)
    {
        return getEntry(obj) != null;
    }

    Entry getEntry(Object obj)
    {
        Object obj1 = maskNull(obj);
        int i = System.identityHashCode(obj1);
        Entry aentry[] = getTable();
        int j = indexFor(i, aentry.length);
        Entry entry;
        for(entry = aentry[j]; entry != null && (entry.hash != i || !eq(obj1, entry.get())); entry = entry.next);
        return entry;
    }

    public Object put(Object obj, Object obj1)
    {
        Object obj2 = maskNull(obj);
        int i = System.identityHashCode(obj2);
        Entry aentry[] = getTable();
        int j = indexFor(i, aentry.length);
        for(Entry entry = aentry[j]; entry != null; entry = entry.next)
            if(i == entry.hash && eq(obj2, entry.get()))
            {
                Object obj3 = entry.value;
                if(obj1 != obj3)
                    entry.value = obj1;
                return obj3;
            }

        modCount++;
        Entry entry1 = aentry[j];
        aentry[j] = new Entry(obj2, obj1, queue, i, entry1);
        if(++size >= threshold)
            resize(aentry.length * 2);
        return null;
    }

    void resize(int i)
    {
        Entry aentry[] = getTable();
        int j = aentry.length;
        if(j == 0x40000000)
        {
            threshold = 0x7fffffff;
            return;
        }
        Entry aentry1[] = newTable(i);
        transfer(aentry, aentry1);
        table = aentry1;
        if(size >= threshold / 2)
        {
            threshold = (int)((float)i * loadFactor);
        } else
        {
            expungeStaleEntries();
            transfer(aentry1, aentry);
            table = aentry;
        }
    }

    private void transfer(Entry aentry[], Entry aentry1[])
    {
        for(int i = 0; i < aentry.length; i++)
        {
            Entry entry = aentry[i];
            aentry[i] = null;
            Entry entry1;
            for(; entry != null; entry = entry1)
            {
                entry1 = entry.next;
                Object obj = entry.get();
                if(obj == null)
                {
                    entry.next = null;
                    entry.value = null;
                    size--;
                } else
                {
                    int j = indexFor(entry.hash, aentry1.length);
                    entry.next = aentry1[j];
                    aentry1[j] = entry;
                }
            }

        }

    }

    public void putAll(Map map)
    {
        int i = map.size();
        if(i == 0)
            return;
        if(i > threshold)
        {
            int j = (int)((float)i / loadFactor + 1.0F);
            if(j > 0x40000000)
                j = 0x40000000;
            int k;
            for(k = table.length; k < j; k <<= 1);
            if(k > table.length)
                resize(k);
        }
        java.util.Map.Entry entry;
        for(Iterator iterator = map.entrySet().iterator(); iterator.hasNext(); put(entry.getKey(), entry.getValue()))
            entry = (java.util.Map.Entry)iterator.next();

    }

    public Object remove(Object obj)
    {
        Object obj1 = maskNull(obj);
        int i = System.identityHashCode(obj1);
        Entry aentry[] = getTable();
        int j = indexFor(i, aentry.length);
        Entry entry = aentry[j];
        Entry entry2;
        for(Entry entry1 = entry; entry1 != null; entry1 = entry2)
        {
            entry2 = entry1.next;
            if(i == entry1.hash && eq(obj1, entry1.get()))
            {
                modCount++;
                size--;
                if(entry == entry1)
                    aentry[j] = entry2;
                else
                    entry.next = entry2;
                return entry1.value;
            }
            entry = entry1;
        }

        return null;
    }

    boolean removeMapping(Object obj)
    {
        if(!(obj instanceof java.util.Map.Entry))
            return false;
        Entry aentry[] = getTable();
        java.util.Map.Entry entry = (java.util.Map.Entry)obj;
        Object obj1 = maskNull(entry.getKey());
        int i = System.identityHashCode(obj1);
        int j = indexFor(i, aentry.length);
        Entry entry1 = aentry[j];
        Entry entry3;
        for(Entry entry2 = entry1; entry2 != null; entry2 = entry3)
        {
            entry3 = entry2.next;
            if(i == entry2.hash && entry2.equals(entry))
            {
                modCount++;
                size--;
                if(entry1 == entry2)
                    aentry[j] = entry3;
                else
                    entry1.next = entry3;
                return true;
            }
            entry1 = entry2;
        }

        return false;
    }

    public void clear()
    {
        while(queue.poll() != null) ;
        modCount++;
        Arrays.fill(table, null);
        size = 0;
        while(queue.poll() != null) ;
    }

    public boolean containsValue(Object obj)
    {
        if(obj == null)
            return containsNullValue();
        Entry aentry[] = getTable();
        for(int i = aentry.length; i-- > 0;)
        {
            Entry entry = aentry[i];
            while(entry != null) 
            {
                if(obj.equals(entry.value))
                    return true;
                entry = entry.next;
            }
        }

        return false;
    }

    private boolean containsNullValue()
    {
        Entry aentry[] = getTable();
        for(int i = aentry.length; i-- > 0;)
        {
            Entry entry = aentry[i];
            while(entry != null) 
            {
                if(entry.value == null)
                    return true;
                entry = entry.next;
            }
        }

        return false;
    }

    public Set keySet()
    {
        Set set = keySet;
        return set == null ? (keySet = new KeySet()) : set;
    }

    public Collection values()
    {
        Collection collection = values;
        return collection == null ? (values = new Values()) : collection;
    }

    public Set entrySet()
    {
        Set set = entrySet;
        return set == null ? (entrySet = new EntrySet()) : set;
    }

    public boolean equals(Object obj)
    {
        Map map;
        if(obj == this)
            return true;
        if(!(obj instanceof Map))
            return false;
        map = (Map)obj;
        if(map.size() != size())
            return false;
        Iterator iterator = entrySet().iterator();
_L2:
        Object obj2;
        Object obj3;
        do
        {
            if(!iterator.hasNext())
                break MISSING_BLOCK_LABEL_143;
            java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
            obj2 = entry.getKey();
            obj3 = entry.getValue();
            if(obj3 != null)
                continue; /* Loop/switch isn't completed */
        } while(map.get(obj2) == null && map.containsKey(obj2));
        return false;
        if(obj3.equals(map.get(obj2))) goto _L2; else goto _L1
_L1:
        return false;
        Object obj1;
        obj1;
        return false;
        obj1;
        return false;
        return true;
    }

    public int hashCode()
    {
        int i = 0;
        for(Iterator iterator = entrySet().iterator(); iterator.hasNext();)
            i += ((java.util.Map.Entry)iterator.next()).hashCode();

        return i;
    }

    public String toString()
    {
        Iterator iterator = entrySet().iterator();
        if(!iterator.hasNext())
            return "{}";
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append('{');
        do
        {
            java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
            Object obj = entry.getKey();
            Object obj1 = entry.getValue();
            stringbuilder.append(obj != this ? obj : "(this Map)");
            stringbuilder.append('=');
            stringbuilder.append(obj1 != this ? obj1 : "(this Map)");
            if(!iterator.hasNext())
                return stringbuilder.append('}').toString();
            stringbuilder.append(", ");
        } while(true);
    }

    protected Object clone()
        throws CloneNotSupportedException
    {
        WeakIdentityHashMap weakidentityhashmap = (WeakIdentityHashMap)super.clone();
        weakidentityhashmap.keySet = null;
        weakidentityhashmap.values = null;
        return weakidentityhashmap;
    }

}
