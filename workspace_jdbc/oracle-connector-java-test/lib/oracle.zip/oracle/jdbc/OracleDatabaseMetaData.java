// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDatabaseMetaData.java

package oracle.jdbc;

import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.driver.OracleSql;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleResultSet;
import oracle.sql.SQLName;
import oracle.sql.TypeDescriptor;

// Referenced classes of package oracle.jdbc:
//            OracleCallableStatement, AdditionalDatabaseMetaData, OracleConnection, OracleTypeMetaData

public class OracleDatabaseMetaData
    implements AdditionalDatabaseMetaData
{

    private static String DRIVER_NAME = "Oracle JDBC driver";
    private static String DRIVER_VERSION = "11.2.0.4.0";
    private static int DRIVER_MAJOR_VERSION = 11;
    private static int DRIVER_MINOR_VERSION = 2;
    private static String LOB_MAXSIZE = "4294967295";
    private static long LOB_MAXLENGTH_32BIT = 0xffffffffL;
    protected OracleConnection connection;
    int procedureResultUnknown;
    int procedureNoResult;
    int procedureReturnsResult;
    int procedureColumnUnknown;
    int procedureColumnIn;
    int procedureColumnInOut;
    int procedureColumnOut;
    int procedureColumnReturn;
    int procedureColumnResult;
    int procedureNoNulls;
    int procedureNullable;
    int procedureNullableUnknown;
    int columnNoNulls;
    int columnNullable;
    int columnNullableUnknown;
    static final int bestRowTemporary = 0;
    static final int bestRowTransaction = 1;
    static final int bestRowSession = 2;
    static final int bestRowUnknown = 0;
    static final int bestRowNotPseudo = 1;
    static final int bestRowPseudo = 2;
    int versionColumnUnknown;
    int versionColumnNotPseudo;
    int versionColumnPseudo;
    int importedKeyCascade;
    int importedKeyRestrict;
    int importedKeySetNull;
    int typeNoNulls;
    int typeNullable;
    int typeNullableUnknown;
    int typePredNone;
    int typePredChar;
    int typePredBasic;
    int typeSearchable;
    short tableIndexStatistic;
    short tableIndexClustered;
    short tableIndexHashed;
    short tableIndexOther;
    short attributeNoNulls;
    short attributeNullable;
    short attributeNullableUnknown;
    int sqlStateXOpen;
    int sqlStateSQL99;
    protected static final String sqlWildcardRegex = "^%|^_|[^/]%|[^/]_";
    protected static Pattern sqlWildcardPattern = null;
    protected static final String sqlEscapeRegex = "/";
    protected static Pattern sqlEscapePattern = null;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    /**
     * @deprecated Method OracleDatabaseMetaData is deprecated
     */

    public OracleDatabaseMetaData(oracle.jdbc.OracleConnection oracleconnection)
    {
        procedureResultUnknown = 0;
        procedureNoResult = 1;
        procedureReturnsResult = 2;
        procedureColumnUnknown = 0;
        procedureColumnIn = 1;
        procedureColumnInOut = 2;
        procedureColumnOut = 4;
        procedureColumnReturn = 5;
        procedureColumnResult = 3;
        procedureNoNulls = 0;
        procedureNullable = 1;
        procedureNullableUnknown = 2;
        columnNoNulls = 0;
        columnNullable = 1;
        columnNullableUnknown = 2;
        versionColumnUnknown = 0;
        versionColumnNotPseudo = 1;
        versionColumnPseudo = 2;
        importedKeyCascade = 0;
        importedKeyRestrict = 1;
        importedKeySetNull = 2;
        typeNoNulls = 0;
        typeNullable = 1;
        typeNullableUnknown = 2;
        typePredNone = 0;
        typePredChar = 1;
        typePredBasic = 2;
        typeSearchable = 3;
        tableIndexStatistic = 0;
        tableIndexClustered = 1;
        tableIndexHashed = 2;
        tableIndexOther = 3;
        attributeNoNulls = 0;
        attributeNullable = 1;
        attributeNullableUnknown = 2;
        sqlStateXOpen = 1;
        sqlStateSQL99 = 2;
        connection = oracleconnection.physicalConnectionWithin();
    }

    public boolean allProceduresAreCallable()
        throws SQLException
    {
        return false;
    }

    public boolean allTablesAreSelectable()
        throws SQLException
    {
        return false;
    }

    public String getURL()
        throws SQLException
    {
        return connection.getURL();
    }

    public String getUserName()
        throws SQLException
    {
        return connection.getUserName();
    }

    public boolean isReadOnly()
        throws SQLException
    {
        return false;
    }

    public boolean nullsAreSortedHigh()
        throws SQLException
    {
        return false;
    }

    public boolean nullsAreSortedLow()
        throws SQLException
    {
        return true;
    }

    public boolean nullsAreSortedAtStart()
        throws SQLException
    {
        return false;
    }

    public boolean nullsAreSortedAtEnd()
        throws SQLException
    {
        return false;
    }

    public String getDatabaseProductName()
        throws SQLException
    {
        return "Oracle";
    }

    public String getDatabaseProductVersion()
        throws SQLException
    {
        return connection.getDatabaseProductVersion();
    }

    public String getDriverName()
        throws SQLException
    {
        return DRIVER_NAME;
    }

    public String getDriverVersion()
        throws SQLException
    {
        return DRIVER_VERSION;
    }

    public int getDriverMajorVersion()
    {
        return DRIVER_MAJOR_VERSION;
    }

    public int getDriverMinorVersion()
    {
        return DRIVER_MINOR_VERSION;
    }

    public boolean usesLocalFiles()
        throws SQLException
    {
        return false;
    }

    public boolean usesLocalFilePerTable()
        throws SQLException
    {
        return false;
    }

    public boolean supportsMixedCaseIdentifiers()
        throws SQLException
    {
        return false;
    }

    public boolean storesUpperCaseIdentifiers()
        throws SQLException
    {
        return true;
    }

    public boolean storesLowerCaseIdentifiers()
        throws SQLException
    {
        return false;
    }

    public boolean storesMixedCaseIdentifiers()
        throws SQLException
    {
        return false;
    }

    public boolean supportsMixedCaseQuotedIdentifiers()
        throws SQLException
    {
        return true;
    }

    public boolean storesUpperCaseQuotedIdentifiers()
        throws SQLException
    {
        return false;
    }

    public boolean storesLowerCaseQuotedIdentifiers()
        throws SQLException
    {
        return false;
    }

    public boolean storesMixedCaseQuotedIdentifiers()
        throws SQLException
    {
        return true;
    }

    public String getIdentifierQuoteString()
        throws SQLException
    {
        return "\"";
    }

    public String getSQLKeywords()
        throws SQLException
    {
        return "ACCESS, ADD, ALTER, AUDIT, CLUSTER, COLUMN, COMMENT, COMPRESS, CONNECT, DATE, DROP, EXCLUSIVE, FILE, IDENTIFIED, IMMEDIATE, INCREMENT, INDEX, INITIAL, INTERSECT, LEVEL, LOCK, LONG, MAXEXTENTS, MINUS, MODE, NOAUDIT, NOCOMPRESS, NOWAIT, NUMBER, OFFLINE, ONLINE, PCTFREE, PRIOR, all_PL_SQL_reserved_ words";
    }

    public String getNumericFunctions()
        throws SQLException
    {
        return "ABS,ACOS,ASIN,ATAN,ATAN2,CEILING,COS,EXP,FLOOR,LOG,LOG10,MOD,PI,POWER,ROUND,SIGN,SIN,SQRT,TAN,TRUNCATE";
    }

    public String getStringFunctions()
        throws SQLException
    {
        return "ASCII,CHAR,CHAR_LENGTH,CHARACTER_LENGTH,CONCAT,LCASE,LENGTH,LTRIM,OCTET_LENGTH,REPLACE,RTRIM,SOUNDEX,SUBSTRING,UCASE";
    }

    public String getSystemFunctions()
        throws SQLException
    {
        return "USER";
    }

    public String getTimeDateFunctions()
        throws SQLException
    {
        return "CURRENT_DATE,CURRENT_TIMESTAMP,CURDATE,EXTRACT,HOUR,MINUTE,MONTH,SECOND,YEAR";
    }

    public String getSearchStringEscape()
        throws SQLException
    {
        return "/";
    }

    public String getExtraNameCharacters()
        throws SQLException
    {
        return "$#";
    }

    public boolean supportsAlterTableWithAddColumn()
        throws SQLException
    {
        return true;
    }

    public boolean supportsAlterTableWithDropColumn()
        throws SQLException
    {
        return false;
    }

    public boolean supportsColumnAliasing()
        throws SQLException
    {
        return true;
    }

    public boolean nullPlusNonNullIsNull()
        throws SQLException
    {
        return true;
    }

    public boolean supportsConvert()
        throws SQLException
    {
        return false;
    }

    public boolean supportsConvert(int i, int j)
        throws SQLException
    {
        return false;
    }

    public boolean supportsTableCorrelationNames()
        throws SQLException
    {
        return true;
    }

    public boolean supportsDifferentTableCorrelationNames()
        throws SQLException
    {
        return true;
    }

    public boolean supportsExpressionsInOrderBy()
        throws SQLException
    {
        return true;
    }

    public boolean supportsOrderByUnrelated()
        throws SQLException
    {
        return true;
    }

    public boolean supportsGroupBy()
        throws SQLException
    {
        return true;
    }

    public boolean supportsGroupByUnrelated()
        throws SQLException
    {
        return true;
    }

    public boolean supportsGroupByBeyondSelect()
        throws SQLException
    {
        return true;
    }

    public boolean supportsLikeEscapeClause()
        throws SQLException
    {
        return true;
    }

    public boolean supportsMultipleResultSets()
        throws SQLException
    {
        return false;
    }

    public boolean supportsMultipleTransactions()
        throws SQLException
    {
        return true;
    }

    public boolean supportsNonNullableColumns()
        throws SQLException
    {
        return true;
    }

    public boolean supportsMinimumSQLGrammar()
        throws SQLException
    {
        return true;
    }

    public boolean supportsCoreSQLGrammar()
        throws SQLException
    {
        return true;
    }

    public boolean supportsExtendedSQLGrammar()
        throws SQLException
    {
        return true;
    }

    public boolean supportsANSI92EntryLevelSQL()
        throws SQLException
    {
        return true;
    }

    public boolean supportsANSI92IntermediateSQL()
        throws SQLException
    {
        return false;
    }

    public boolean supportsANSI92FullSQL()
        throws SQLException
    {
        return false;
    }

    public boolean supportsIntegrityEnhancementFacility()
        throws SQLException
    {
        return true;
    }

    public boolean supportsOuterJoins()
        throws SQLException
    {
        return true;
    }

    public boolean supportsFullOuterJoins()
        throws SQLException
    {
        return true;
    }

    public boolean supportsLimitedOuterJoins()
        throws SQLException
    {
        return true;
    }

    public String getSchemaTerm()
        throws SQLException
    {
        return "schema";
    }

    public String getProcedureTerm()
        throws SQLException
    {
        return "procedure";
    }

    public String getCatalogTerm()
        throws SQLException
    {
        return "";
    }

    public boolean isCatalogAtStart()
        throws SQLException
    {
        return false;
    }

    public String getCatalogSeparator()
        throws SQLException
    {
        return "";
    }

    public boolean supportsSchemasInDataManipulation()
        throws SQLException
    {
        return true;
    }

    public boolean supportsSchemasInProcedureCalls()
        throws SQLException
    {
        return true;
    }

    public boolean supportsSchemasInTableDefinitions()
        throws SQLException
    {
        return true;
    }

    public boolean supportsSchemasInIndexDefinitions()
        throws SQLException
    {
        return true;
    }

    public boolean supportsSchemasInPrivilegeDefinitions()
        throws SQLException
    {
        return true;
    }

    public boolean supportsCatalogsInDataManipulation()
        throws SQLException
    {
        return false;
    }

    public boolean supportsCatalogsInProcedureCalls()
        throws SQLException
    {
        return false;
    }

    public boolean supportsCatalogsInTableDefinitions()
        throws SQLException
    {
        return false;
    }

    public boolean supportsCatalogsInIndexDefinitions()
        throws SQLException
    {
        return false;
    }

    public boolean supportsCatalogsInPrivilegeDefinitions()
        throws SQLException
    {
        return false;
    }

    public boolean supportsPositionedDelete()
        throws SQLException
    {
        return false;
    }

    public boolean supportsPositionedUpdate()
        throws SQLException
    {
        return false;
    }

    public boolean supportsSelectForUpdate()
        throws SQLException
    {
        return true;
    }

    public boolean supportsStoredProcedures()
        throws SQLException
    {
        return true;
    }

    public boolean supportsSubqueriesInComparisons()
        throws SQLException
    {
        return true;
    }

    public boolean supportsSubqueriesInExists()
        throws SQLException
    {
        return true;
    }

    public boolean supportsSubqueriesInIns()
        throws SQLException
    {
        return true;
    }

    public boolean supportsSubqueriesInQuantifieds()
        throws SQLException
    {
        return true;
    }

    public boolean supportsCorrelatedSubqueries()
        throws SQLException
    {
        return true;
    }

    public boolean supportsUnion()
        throws SQLException
    {
        return true;
    }

    public boolean supportsUnionAll()
        throws SQLException
    {
        return true;
    }

    public boolean supportsOpenCursorsAcrossCommit()
        throws SQLException
    {
        return false;
    }

    public boolean supportsOpenCursorsAcrossRollback()
        throws SQLException
    {
        return false;
    }

    public boolean supportsOpenStatementsAcrossCommit()
        throws SQLException
    {
        return false;
    }

    public boolean supportsOpenStatementsAcrossRollback()
        throws SQLException
    {
        return false;
    }

    public int getMaxBinaryLiteralLength()
        throws SQLException
    {
        return 1000;
    }

    public int getMaxCharLiteralLength()
        throws SQLException
    {
        return 2000;
    }

    public int getMaxColumnNameLength()
        throws SQLException
    {
        return 30;
    }

    public int getMaxColumnsInGroupBy()
        throws SQLException
    {
        return 0;
    }

    public int getMaxColumnsInIndex()
        throws SQLException
    {
        return 32;
    }

    public int getMaxColumnsInOrderBy()
        throws SQLException
    {
        return 0;
    }

    public int getMaxColumnsInSelect()
        throws SQLException
    {
        return 0;
    }

    public int getMaxColumnsInTable()
        throws SQLException
    {
        return 1000;
    }

    public int getMaxConnections()
        throws SQLException
    {
        return 0;
    }

    public int getMaxCursorNameLength()
        throws SQLException
    {
        return 0;
    }

    public int getMaxIndexLength()
        throws SQLException
    {
        return 0;
    }

    public int getMaxSchemaNameLength()
        throws SQLException
    {
        return 30;
    }

    public int getMaxProcedureNameLength()
        throws SQLException
    {
        return 30;
    }

    public int getMaxCatalogNameLength()
        throws SQLException
    {
        return 0;
    }

    public int getMaxRowSize()
        throws SQLException
    {
        return 0;
    }

    public boolean doesMaxRowSizeIncludeBlobs()
        throws SQLException
    {
        return true;
    }

    public int getMaxStatementLength()
        throws SQLException
    {
        return 65535;
    }

    public int getMaxStatements()
        throws SQLException
    {
        return 0;
    }

    public int getMaxTableNameLength()
        throws SQLException
    {
        return 30;
    }

    public int getMaxTablesInSelect()
        throws SQLException
    {
        return 0;
    }

    public int getMaxUserNameLength()
        throws SQLException
    {
        return 30;
    }

    public int getDefaultTransactionIsolation()
        throws SQLException
    {
        return 2;
    }

    public boolean supportsTransactions()
        throws SQLException
    {
        return true;
    }

    public boolean supportsTransactionIsolationLevel(int i)
        throws SQLException
    {
        return i == 2 || i == 8;
    }

    public boolean supportsDataDefinitionAndDataManipulationTransactions()
        throws SQLException
    {
        return true;
    }

    public boolean supportsDataManipulationTransactionsOnly()
        throws SQLException
    {
        return true;
    }

    public boolean dataDefinitionCausesTransactionCommit()
        throws SQLException
    {
        return true;
    }

    public boolean dataDefinitionIgnoredInTransactions()
        throws SQLException
    {
        return false;
    }

    public synchronized ResultSet getProcedures(String s, String s1, String s2)
        throws SQLException
    {
        String s3 = "SELECT\n  -- Standalone procedures and functions\n  NULL AS procedure_cat,\n  owner AS procedure_schem,\n  object_name AS procedure_name,\n  NULL,\n  NULL,\n  NULL,\n  'Standalone procedure or function' AS remarks,\n  DECODE(object_type, 'PROCEDURE', 1,\n                      'FUNCTION', 2,\n                      0) AS procedure_type\n,  NULL AS specific_name\nFROM all_objects\nWHERE (object_type = 'PROCEDURE' OR object_type = 'FUNCTION')\n  AND owner LIKE :1 ESCAPE '/'\n  AND object_name LIKE :2 ESCAPE '/'\n";
        String s4 = "SELECT\n  -- Packaged procedures with no arguments\n  package_name AS procedure_cat,\n  owner AS procedure_schem,\n  object_name AS procedure_name,\n  NULL,\n  NULL,\n  NULL,\n  'Packaged procedure' AS remarks,\n  1 AS procedure_type\n,  NULL AS specific_name\nFROM all_arguments\nWHERE argument_name IS NULL\n  AND data_type IS NULL\n  AND ";
        String s5 = "SELECT\n  -- Packaged procedures with arguments\n  package_name AS procedure_cat,\n  owner AS procedure_schem,\n  object_name AS procedure_name,\n  NULL,\n  NULL,\n  NULL,\n  'Packaged procedure' AS remarks,\n  1 AS procedure_type\n,  NULL AS specific_name\nFROM all_arguments\nWHERE argument_name IS NOT NULL\n  AND position = 1\n  AND position = sequence\n  AND ";
        String s6 = "SELECT\n  -- Packaged functions\n  package_name AS procedure_cat,\n  owner AS procedure_schem,\n  object_name AS procedure_name,\n  NULL,\n  NULL,\n  NULL,\n  'Packaged function' AS remarks,\n  2 AS procedure_type\n,  NULL AS specific_name\nFROM all_arguments\nWHERE argument_name IS NULL\n  AND in_out = 'OUT'\n  AND   data_level = 0\n  AND ";
        String s7 = "package_name LIKE :3 ESCAPE '/'\n  AND owner LIKE :4 ESCAPE '/'\n  AND object_name LIKE :5 ESCAPE '/'\n";
        String s8 = "package_name IS NOT NULL\n  AND owner LIKE :6 ESCAPE '/'\n  AND object_name LIKE :7 ESCAPE '/'\n";
        String s9 = "ORDER BY procedure_schem, procedure_name\n";
        PreparedStatement preparedstatement = null;
        Object obj = null;
        String s13 = s1;
        if(s1 == null)
            s13 = "%";
        else
        if(s1.equals(""))
            s13 = getUserName().toUpperCase();
        String s14 = s2;
        if(s2 == null)
            s14 = "%";
        else
        if(s2.equals(""))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(s == null)
        {
            String s10 = (new StringBuilder()).append(s3).append("UNION ALL ").append(s4).append(s8).append("UNION ALL ").append(s5).append(s8).append("UNION ALL ").append(s6).append(s8).append(s9).toString();
            preparedstatement = connection.prepareStatement(s10);
            preparedstatement.setString(1, s13);
            preparedstatement.setString(2, s14);
            preparedstatement.setString(3, s13);
            preparedstatement.setString(4, s14);
            preparedstatement.setString(5, s13);
            preparedstatement.setString(6, s14);
            preparedstatement.setString(7, s13);
            preparedstatement.setString(8, s14);
        } else
        if(s.equals(""))
        {
            String s11 = s3;
            preparedstatement = connection.prepareStatement(s11);
            preparedstatement.setString(1, s13);
            preparedstatement.setString(2, s14);
        } else
        {
            String s12 = (new StringBuilder()).append(s4).append(s7).append("UNION ALL ").append(s5).append(s7).append("UNION ALL ").append(s6).append(s7).append(s9).toString();
            preparedstatement = connection.prepareStatement(s12);
            preparedstatement.setString(1, s);
            preparedstatement.setString(2, s13);
            preparedstatement.setString(3, s14);
            preparedstatement.setString(4, s);
            preparedstatement.setString(5, s13);
            preparedstatement.setString(6, s14);
            preparedstatement.setString(7, s);
            preparedstatement.setString(8, s13);
            preparedstatement.setString(9, s14);
        }
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public synchronized ResultSet getProcedureColumns(String s, String s1, String s2, String s3)
        throws SQLException
    {
        boolean flag = connection.getIncludeSynonyms();
        if("".equals(s) && (s1 == null || !hasSqlWildcard(s1)) && s2 != null && !hasSqlWildcard(s2))
            return getUnpackagedProcedureColumnsNoWildcards(s1 == null ? null : stripSqlEscapes(s1), s2 == null ? null : stripSqlEscapes(s2), s3);
        if(s != null && s.length() != 0 && !hasSqlWildcard(s) && (s1 == null || !hasSqlWildcard(s1)))
            return getPackagedProcedureColumnsNoWildcards(s == null ? null : stripSqlEscapes(s), s1 == null ? null : stripSqlEscapes(s1), s2, s3);
        else
            return getProcedureColumnsWithWildcards(s, s1, s2, s3, flag);
    }

    ResultSet getUnpackagedProcedureColumnsNoWildcards(String s, String s1, String s2)
        throws SQLException
    {
        String s3;
        CallableStatement callablestatement;
        ResultSet resultset;
        if("".equals(s2))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        s3 = getUnpackagedProcedureColumnsNoWildcardsPlsql();
        callablestatement = null;
        resultset = null;
        callablestatement = connection.prepareCall(s3);
        callablestatement.setString(1, s);
        callablestatement.setString(2, s1);
        callablestatement.setString(3, s2 != null ? s2 : "%");
        callablestatement.registerOutParameter(4, -10);
        callablestatement.registerOutParameter(5, 2);
        callablestatement.execute();
        int i = callablestatement.getInt(5);
        if(i == 0)
        {
            resultset = ((OracleCallableStatement)callablestatement).getCursor(4);
            ((OracleResultSet)resultset).closeStatementOnClose();
        } else
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 258);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(resultset == null && callablestatement != null)
            callablestatement.close();
        break MISSING_BLOCK_LABEL_221;
        Exception exception;
        exception;
        if(resultset == null && callablestatement != null)
            callablestatement.close();
        throw exception;
        return resultset;
    }

    ResultSet getPackagedProcedureColumnsNoWildcards(String s, String s1, String s2, String s3)
        throws SQLException
    {
        String s4;
        CallableStatement callablestatement;
        ResultSet resultset;
        if("".equals(s3))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        s4 = getPackagedProcedureColumnsNoWildcardsPlsql();
        callablestatement = null;
        resultset = null;
        callablestatement = connection.prepareCall(s4);
        callablestatement.setString(1, s);
        callablestatement.setString(2, s1);
        callablestatement.setString(3, s2);
        callablestatement.setString(4, s3 != null ? s3 : "%");
        callablestatement.registerOutParameter(5, -10);
        callablestatement.registerOutParameter(6, 2);
        callablestatement.execute();
        int i = callablestatement.getInt(6);
        if(i == 0)
        {
            resultset = ((OracleCallableStatement)callablestatement).getCursor(5);
            ((OracleResultSet)resultset).closeStatementOnClose();
        } else
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 258);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(resultset == null && callablestatement != null)
            callablestatement.close();
        break MISSING_BLOCK_LABEL_235;
        Exception exception;
        exception;
        if(resultset == null && callablestatement != null)
            callablestatement.close();
        throw exception;
        return resultset;
    }

    ResultSet getProcedureColumnsWithWildcards(String s, String s1, String s2, String s3, boolean flag)
        throws SQLException
    {
        String s4 = (new StringBuilder()).append("SELECT package_name AS procedure_cat,\n       owner AS procedure_schem,\n       object_name AS procedure_name,\n       argument_name AS column_name,\n       DECODE(position, 0, 5,\n                        DECODE(in_out, 'IN', 1,\n                                       'OUT', 4,\n                                       'IN/OUT', 2,\n                                       0)) AS column_type,\n       DECODE (data_type, 'CHAR', 1,\n                          'VARCHAR2', 12,\n                          'NUMBER', 3,\n                          'LONG', -1,\n                          'DATE', ").append(connection.getMapDateToTimestamp() ? "93,\n" : "91,\n").append("                          'RAW', -3,\n").append("                          'LONG RAW', -4,\n").append("                          'TIMESTAMP', 93, \n").append("                          'TIMESTAMP WITH TIME ZONE', -101, \n").append("               'TIMESTAMP WITH LOCAL TIME ZONE', -102, \n").append("               'INTERVAL YEAR TO MONTH', -103, \n").append("               'INTERVAL DAY TO SECOND', -104, \n").append("               'BINARY_FLOAT', 100, 'BINAvRY_DOUBLE', 101,").append("               1111) AS data_type,\n").append("       DECODE(data_type, 'OBJECT', type_owner || '.' || type_name, ").append("              data_type) AS type_name,\n").append("       DECODE (data_precision, NULL, data_length,\n").append("                               data_precision) AS precision,\n").append("       data_length AS length,\n").append("       data_scale AS scale,\n").append("       10 AS radix,\n").append("       1 AS nullable,\n").append("       NULL AS remarks,\n").append("       default_value AS column_def,\n").append("       NULL as sql_data_type,\n").append("       NULL AS sql_datetime_sub,\n").append("       DECODE(data_type,\n").append("                         'CHAR', 32767,\n").append("                         'VARCHAR2', 32767,\n").append("                         'LONG', 32767,\n").append("                         'RAW', 32767,\n").append("                         'LONG RAW', 32767,\n").append("                         NULL) AS char_octet_length,\n").append("       (sequence - 1) AS ordinal_position,\n").append("       'YES' AS is_nullable,\n").append("       NULL AS specific_name,\n").append("       sequence,\n").append("       overload,\n").append("       default_value\n").append(" FROM all_arguments\n").append("WHERE owner LIKE :1 ESCAPE '/'\n").append("  AND object_name LIKE :2 ESCAPE '/' AND data_level = 0\n").toString();
        String s5 = "  AND package_name LIKE :3 ESCAPE '/'\n";
        String s6 = "  AND package_name IS NULL\n";
        String s7 = "  AND argument_name LIKE :4 ESCAPE '/'\n";
        String s8 = "  AND (argument_name LIKE :5 ESCAPE '/'\n       OR (argument_name IS NULL\n           AND data_type IS NOT NULL))\n";
        String s9 = "ORDER BY procedure_schem, procedure_name, overload, sequence\n";
        Object obj = null;
        PreparedStatement preparedstatement = null;
        String s13 = null;
        String s14 = s1;
        if(s1 == null)
            s14 = "%";
        else
        if(s1.equals(""))
            s14 = getUserName().toUpperCase();
        String s15 = s2;
        if(s2 == null)
            s15 = "%";
        else
        if(s2.equals(""))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s16 = s3;
        if(s3 == null || s3.equals("%"))
        {
            s16 = "%";
            s13 = s8;
        } else
        {
            if(s3.equals(""))
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            s13 = s7;
        }
        if(s == null)
        {
            String s10 = (new StringBuilder()).append(s4).append(s13).append(s9).toString();
            preparedstatement = connection.prepareStatement(s10);
            preparedstatement.setString(1, s14);
            preparedstatement.setString(2, s15);
            preparedstatement.setString(3, s16);
        } else
        if(s.equals(""))
        {
            String s11 = (new StringBuilder()).append(s4).append(s6).append(s13).append(s9).toString();
            preparedstatement = connection.prepareStatement(s11);
            preparedstatement.setString(1, s14);
            preparedstatement.setString(2, s15);
            preparedstatement.setString(3, s16);
        } else
        {
            String s12 = (new StringBuilder()).append(s4).append(s5).append(s13).append(s9).toString();
            preparedstatement = connection.prepareStatement(s12);
            preparedstatement.setString(1, s14);
            preparedstatement.setString(2, s15);
            preparedstatement.setString(3, s);
            preparedstatement.setString(4, s16);
        }
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public ResultSet getFunctionColumns(String s, String s1, String s2, String s3)
        throws SQLException
    {
        String s4 = (new StringBuilder()).append("SELECT package_name AS function_cat,\n       arg.owner AS function_schem,\n       arg.object_name AS function_name,\n       arg.argument_name AS column_name,\n       DECODE(arg.position, 0, 5,\n                        DECODE(arg.in_out, 'IN', 1,\n                                       'OUT', 4,\n                                       'IN/OUT', 2,\n                                       0)) AS column_type,\n       DECODE (arg.data_type, 'CHAR', 1,\n                          'VARCHAR2', 12,\n                          'NUMBER', 3,\n                          'LONG', -1,\n                          'DATE', ").append(connection.getMapDateToTimestamp() ? "93,\n" : "91,\n").append("                          'RAW', -3,\n").append("                          'LONG RAW', -4,\n").append("                          'TIMESTAMP', 93, \n").append("                          'TIMESTAMP WITH TIME ZONE', -101, \n").append("               'TIMESTAMP WITH LOCAL TIME ZONE', -102, \n").append("               'INTERVAL YEAR TO MONTH', -103, \n").append("               'INTERVAL DAY TO SECOND', -104, \n").append("               'BINARY_FLOAT', 100, 'BINAvRY_DOUBLE', 101,").append("               1111) AS data_type,\n").append("       DECODE(arg.data_type, 'OBJECT', arg.type_owner || '.' || arg.type_name, ").append("              arg.data_type) AS type_name,\n").append("       DECODE (arg.data_precision, NULL, arg.data_length,\n").append("                               arg.data_precision) AS precision,\n").append("       arg.data_length AS length,\n").append("       arg.data_scale AS scale,\n").append("       10 AS radix,\n").append("       1 AS nullable,\n").append("       NULL AS remarks,\n").append("       arg.default_value AS column_def,\n").append("       NULL as sql_data_type,\n").append("       NULL AS sql_datetime_sub,\n").append("       DECODE(arg.data_type,\n").append("                         'CHAR', 32767,\n").append("                         'VARCHAR2', 32767,\n").append("                         'LONG', 32767,\n").append("                         'RAW', 32767,\n").append("                         'LONG RAW', 32767,\n").append("                         NULL) AS char_octet_length,\n").append("       (arg.sequence - 1) AS ordinal_position,\n").append("       'YES' AS is_nullable,\n").append("       NULL AS specific_name,\n").append("       arg.sequence,\n").append("       arg.overload,\n").append("       arg.default_value\n").append(" FROM all_arguments arg, all_procedures proc\n").append(" WHERE arg.owner LIKE :1 ESCAPE '/'\n").append("  AND arg.object_name LIKE :2 ESCAPE '/'\n").toString();
        short word0 = connection.getVersionNumber();
        String s5 = word0 < 10200 ? "  AND proc.owner = arg.owner\n  AND proc.object_name = arg.object_name\n" : "  AND proc.object_id = arg.object_id\n  AND proc.object_type = 'FUNCTION'\n";
        String s6 = "  AND arg.package_name LIKE :3 ESCAPE '/'\n";
        String s7 = "  AND arg.package_name IS NULL\n";
        String s8 = "  AND arg.argument_name LIKE :4 ESCAPE '/'\n";
        String s9 = "  AND (arg.argument_name LIKE :5 ESCAPE '/'\n     OR (arg.argument_name IS NULL\n         AND arg.data_type IS NOT NULL))\n";
        String s10 = "ORDER BY function_schem, function_name, overload, sequence\n";
        Object obj = null;
        PreparedStatement preparedstatement = null;
        String s14 = null;
        String s15 = s1;
        if(s1 == null)
            s15 = "%";
        else
        if(s1.equals(""))
            s15 = getUserName().toUpperCase();
        String s16 = s2;
        if(s2 == null)
            s16 = "%";
        else
        if(s2.equals(""))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s17 = s3;
        if(s3 == null || s3.equals("%"))
        {
            s17 = "%";
            s14 = s9;
        } else
        {
            if(s3.equals(""))
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            s14 = s8;
        }
        if(s == null)
        {
            String s11 = (new StringBuilder()).append(s4).append(s5).append(s14).append(s10).toString();
            preparedstatement = connection.prepareStatement(s11);
            preparedstatement.setString(1, s15);
            preparedstatement.setString(2, s16);
            preparedstatement.setString(3, s17);
        } else
        if(s.equals(""))
        {
            String s12 = (new StringBuilder()).append(s4).append(s5).append(s7).append(s14).append(s10).toString();
            preparedstatement = connection.prepareStatement(s12);
            preparedstatement.setString(1, s15);
            preparedstatement.setString(2, s16);
            preparedstatement.setString(3, s17);
        } else
        {
            String s13 = (new StringBuilder()).append(s4).append(s5).append(s6).append(s14).append(s10).toString();
            preparedstatement = connection.prepareStatement(s13);
            preparedstatement.setString(1, s15);
            preparedstatement.setString(2, s16);
            preparedstatement.setString(3, s);
            preparedstatement.setString(4, s17);
        }
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public synchronized ResultSet getTables(String s, String s1, String s2, String as[])
        throws SQLException
    {
        String s3 = "SELECT NULL AS table_cat,\n       o.owner AS table_schem,\n       o.object_name AS table_name,\n       o.object_type AS table_type,\n";
        String s4 = "       c.comments AS remarks\n";
        String s5 = "       NULL AS remarks\n";
        String s6 = "  FROM all_objects o, all_tab_comments c\n";
        String s7 = "  FROM all_objects o\n";
        String s8 = "  WHERE o.owner LIKE :1 ESCAPE '/'\n    AND o.object_name LIKE :2 ESCAPE '/'\n";
        String s9 = "    AND o.owner = c.owner (+)\n    AND o.object_name = c.table_name (+)\n";
        boolean flag = false;
        String s10 = "";
        String s11 = "";
        if(as != null)
        {
            s10 = "    AND o.object_type IN ('xxx'";
            s11 = "    AND o.object_type IN ('xxx'";
            for(int i = 0; i < as.length; i++)
                if(as[i].equals("SYNONYM"))
                {
                    s10 = (new StringBuilder()).append(s10).append(", '").append(as[i]).append("'").toString();
                    flag = true;
                } else
                {
                    s10 = (new StringBuilder()).append(s10).append(", '").append(as[i]).append("'").toString();
                    s11 = (new StringBuilder()).append(s11).append(", '").append(as[i]).append("'").toString();
                }

            s10 = (new StringBuilder()).append(s10).append(")\n").toString();
            s11 = (new StringBuilder()).append(s11).append(")\n").toString();
        } else
        {
            flag = true;
            s10 = "    AND o.object_type IN ('TABLE', 'SYNONYM', 'VIEW')\n";
            s11 = "    AND o.object_type IN ('TABLE', 'VIEW')\n";
        }
        String s12 = "  ORDER BY table_type, table_schem, table_name\n";
        String s13 = "SELECT NULL AS table_cat,\n       s.owner AS table_schem,\n       s.synonym_name AS table_name,\n       'SYNONYM' AS table_table_type,\n";
        String s14 = "       c.comments AS remarks\n";
        String s15 = "       NULL AS remarks\n";
        String s16 = "  FROM all_synonyms s, all_objects o, all_tab_comments c\n";
        String s17 = "  FROM all_synonyms s, all_objects o\n";
        String s18 = "  WHERE s.owner LIKE :3 ESCAPE '/'\n    AND s.synonym_name LIKE :4 ESCAPE '/'\n    AND s.table_owner = o.owner\n    AND s.table_name = o.object_name\n    AND o.object_type IN ('TABLE', 'VIEW')\n";
        String s19 = "";
        s19 = (new StringBuilder()).append(s19).append(s3).toString();
        if(connection.getRemarksReporting())
            s19 = (new StringBuilder()).append(s19).append(s4).append(s6).toString();
        else
            s19 = (new StringBuilder()).append(s19).append(s5).append(s7).toString();
        s19 = (new StringBuilder()).append(s19).append(s8).toString();
        if(connection.getRestrictGetTables())
            s19 = (new StringBuilder()).append(s19).append(s11).toString();
        else
            s19 = (new StringBuilder()).append(s19).append(s10).toString();
        if(connection.getRemarksReporting())
            s19 = (new StringBuilder()).append(s19).append(s9).toString();
        if(flag && connection.getRestrictGetTables())
        {
            s19 = (new StringBuilder()).append(s19).append("UNION\n").append(s13).toString();
            if(connection.getRemarksReporting())
                s19 = (new StringBuilder()).append(s19).append(s14).append(s16).toString();
            else
                s19 = (new StringBuilder()).append(s19).append(s15).append(s17).toString();
            s19 = (new StringBuilder()).append(s19).append(s18).toString();
            if(connection.getRemarksReporting())
                s19 = (new StringBuilder()).append(s19).append(s9).toString();
        }
        s19 = (new StringBuilder()).append(s19).append(s12).toString();
        PreparedStatement preparedstatement = connection.prepareStatement(s19);
        preparedstatement.setString(1, s1 != null ? s1 : "%");
        preparedstatement.setString(2, s2 != null ? s2 : "%");
        if(flag && connection.getRestrictGetTables())
        {
            preparedstatement.setString(3, s1 != null ? s1 : "%");
            preparedstatement.setString(4, s2 != null ? s2 : "%");
        }
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public ResultSet getSchemas()
        throws SQLException
    {
        Statement statement = connection.createStatement();
        String s = "SELECT username AS table_schem,null as table_catalog  FROM all_users ORDER BY table_schem";
        OracleResultSet oracleresultset = (OracleResultSet)statement.executeQuery(s);
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public ResultSet getCatalogs()
        throws SQLException
    {
        Statement statement = connection.createStatement();
        String s = "select 'nothing' as table_cat from dual where 1 = 2";
        OracleResultSet oracleresultset = (OracleResultSet)statement.executeQuery(s);
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public ResultSet getTableTypes()
        throws SQLException
    {
        Statement statement = connection.createStatement();
        String s = "select 'TABLE' as table_type from dual\nunion select 'VIEW' as table_type from dual\nunion select 'SYNONYM' as table_type from dual\n";
        OracleResultSet oracleresultset = (OracleResultSet)statement.executeQuery(s);
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public ResultSet getColumns(String s, String s1, String s2, String s3)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized ResultSet getColumnPrivileges(String s, String s1, String s2, String s3)
        throws SQLException
    {
        PreparedStatement preparedstatement = connection.prepareStatement("SELECT NULL AS table_cat,\n       table_schema AS table_schem,\n       table_name,\n       column_name,\n       grantor,\n       grantee,\n       privilege,\n       grantable AS is_grantable\nFROM all_col_privs\nWHERE table_schema LIKE :1 ESCAPE '/'\n  AND table_name LIKE :2 ESCAPE '/'\n  AND column_name LIKE :3 ESCAPE '/'\nORDER BY column_name, privilege\n");
        preparedstatement.setString(1, s1 != null ? s1 : "%");
        preparedstatement.setString(2, s2 != null ? s2 : "%");
        preparedstatement.setString(3, s3 != null ? s3 : "%");
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public synchronized ResultSet getTablePrivileges(String s, String s1, String s2)
        throws SQLException
    {
        PreparedStatement preparedstatement = connection.prepareStatement("SELECT NULL AS table_cat,\n       table_schema AS table_schem,\n       table_name,\n       grantor,\n       grantee,\n       privilege,\n       grantable AS is_grantable\nFROM all_tab_privs\nWHERE table_schema LIKE :1 ESCAPE '/'\n  AND table_name LIKE :2 ESCAPE '/'\nORDER BY table_schem, table_name, privilege\n");
        preparedstatement.setString(1, s1 != null ? s1 : "%");
        preparedstatement.setString(2, s2 != null ? s2 : "%");
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public synchronized ResultSet getBestRowIdentifier(String s, String s1, String s2, int i, boolean flag)
        throws SQLException
    {
        PreparedStatement preparedstatement = connection.prepareStatement((new StringBuilder()).append("SELECT 1 AS scope, 'ROWID' AS column_name, -8 AS data_type,\n 'ROWID' AS type_name, 0 AS column_size, 0 AS buffer_length,\n       0 AS decimal_digits, 2 AS pseudo_column\nFROM DUAL\nWHERE :1 = 1\nUNION\nSELECT 2 AS scope,\n  t.column_name,\n DECODE (t.data_type, 'CHAR', 1, 'VARCHAR2', 12, 'NUMBER', 3,\n 'LONG', -1, 'DATE', ").append(connection.getMapDateToTimestamp() ? "93,\n" : "91,\n").append(" 'RAW', -3, 'LONG RAW', -4, \n").append(" 'TIMESTAMP(6)', 93, ").append(" 'TIMESTAMP(6) WITH TIME ZONE', -101, \n").append(" 'TIMESTAMP(6) WITH LOCAL TIME ZONE', -102, \n").append(" 'INTERVAL YEAR(2) TO MONTH', -103, \n").append(" 'INTERVAL DAY(2) TO SECOND(6)', -104, \n").append(" 'BINARY_FLOAT', 100, ").append(" 'BINARY_DOUBLE', 101,").append(" 1111)\n").append(" AS data_type,\n").append(" t.data_type AS type_name,\n").append(" DECODE (t.data_precision, null, t.data_length, t.data_precision)\n").append("  AS column_size,\n").append("  0 AS buffer_length,\n").append("  t.data_scale AS decimal_digits,\n").append("       1 AS pseudo_column\n").append("FROM all_tab_columns t, all_ind_columns i\n").append("WHERE :2 = 1\n").append("  AND t.table_name = :3\n").append("  AND t.owner like :4 escape '/'\n").append("  AND t.nullable != :5\n").append("  AND t.owner = i.table_owner\n").append("  AND t.table_name = i.table_name\n").append("  AND t.column_name = i.column_name\n").toString());
        switch(i)
        {
        case 0: // '\0'
            preparedstatement.setInt(1, 0);
            preparedstatement.setInt(2, 0);
            break;

        case 1: // '\001'
            preparedstatement.setInt(1, 1);
            preparedstatement.setInt(2, 1);
            break;

        case 2: // '\002'
            preparedstatement.setInt(1, 0);
            preparedstatement.setInt(2, 1);
            break;
        }
        preparedstatement.setString(3, s2);
        preparedstatement.setString(4, s1 != null ? s1 : "%");
        preparedstatement.setString(5, flag ? "X" : "Y");
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public synchronized ResultSet getVersionColumns(String s, String s1, String s2)
        throws SQLException
    {
        PreparedStatement preparedstatement = connection.prepareStatement((new StringBuilder()).append("SELECT 0 AS scope,\n t.column_name,\n DECODE (c.data_type, 'CHAR', 1, 'VARCHAR2', 12, 'NUMBER', 3,\n  'LONG', -1, 'DATE',  ").append(connection.getMapDateToTimestamp() ? "93,\n" : "91,\n").append("  'RAW', -3, 'LONG RAW', -4, ").append("  'TIMESTAMP(6)', 93, 'TIMESTAMP(6) WITH TIME ZONE', -101, \n").append("  'TIMESTAMP(6) WITH LOCAL TIME ZONE', -102, \n").append("  'INTERVAL YEAR(2) TO MONTH', -103, \n").append("  'INTERVAL DAY(2) TO SECOND(6)', -104, \n").append("  'BINARY_FLOAT', 100, 'BINARY_DOUBLE', 101,").append("   1111)\n ").append(" AS data_type,\n").append("       c.data_type AS type_name,\n").append(" DECODE (c.data_precision, null, c.data_length, c.data_precision)\n").append("   AS column_size,\n").append("       0 as buffer_length,\n").append("   c.data_scale as decimal_digits,\n").append("   0 as pseudo_column\n").append("FROM all_trigger_cols t, all_tab_columns c\n").append("WHERE t.table_name = :1\n").append("  AND c.owner like :2 escape '/'\n").append(" AND t.table_owner = c.owner\n").append("  AND t.table_name = c.table_name\n").append(" AND t.column_name = c.column_name\n").toString());
        preparedstatement.setString(1, s2);
        preparedstatement.setString(2, s1 != null ? s1 : "%");
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public ResultSet getPrimaryKeys(String s, String s1, String s2)
        throws SQLException
    {
        PreparedStatement preparedstatement = connection.prepareStatement("SELECT NULL AS table_cat,\n       c.owner AS table_schem,\n       c.table_name,\n       c.column_name,\n       c.position AS key_seq,\n       c.constraint_name AS pk_name\nFROM all_cons_columns c, all_constraints k\nWHERE k.constraint_type = 'P'\n  AND k.table_name = :1\n  AND k.owner like :2 escape '/'\n  AND k.constraint_name = c.constraint_name \n  AND k.table_name = c.table_name \n  AND k.owner = c.owner \nORDER BY column_name\n");
        preparedstatement.setString(1, s2);
        preparedstatement.setString(2, s1 != null ? s1 : "%");
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    ResultSet keys_query(String s, String s1, String s2, String s3, String s4)
        throws SQLException
    {
        int i = 1;
        int j = s1 == null ? 0 : i++;
        int k = s3 == null ? 0 : i++;
        int l = s == null || s.length() <= 0 ? 0 : i++;
        int i1 = s2 == null || s2.length() <= 0 ? 0 : i++;
        PreparedStatement preparedstatement = connection.prepareStatement((new StringBuilder()).append("SELECT NULL AS pktable_cat,\n       p.owner as pktable_schem,\n       p.table_name as pktable_name,\n       pc.column_name as pkcolumn_name,\n       NULL as fktable_cat,\n       f.owner as fktable_schem,\n       f.table_name as fktable_name,\n       fc.column_name as fkcolumn_name,\n       fc.position as key_seq,\n       NULL as update_rule,\n       decode (f.delete_rule, 'CASCADE', 0, 'SET NULL', 2, 1) as delete_rule,\n       f.constraint_name as fk_name,\n       p.constraint_name as pk_name,\n       decode(f.deferrable,       'DEFERRABLE',5      ,'NOT DEFERRABLE',7      , 'DEFERRED', 6      ) deferrability \n      FROM all_cons_columns pc, all_constraints p,\n      all_cons_columns fc, all_constraints f\nWHERE 1 = 1\n").append(j == 0 ? "" : "  AND p.table_name = :1\n").append(k == 0 ? "" : "  AND f.table_name = :2\n").append(l == 0 ? "" : "  AND p.owner = :3\n").append(i1 == 0 ? "" : "  AND f.owner = :4\n").append("  AND f.constraint_type = 'R'\n").append("  AND p.owner = f.r_owner\n").append("  AND p.constraint_name = f.r_constraint_name\n").append("  AND p.constraint_type = 'P'\n").append("  AND pc.owner = p.owner\n").append("  AND pc.constraint_name = p.constraint_name\n").append("  AND pc.table_name = p.table_name\n").append("  AND fc.owner = f.owner\n").append("  AND fc.constraint_name = f.constraint_name\n").append("  AND fc.table_name = f.table_name\n").append("  AND fc.position = pc.position\n").append(s4).toString());
        if(j != 0)
            preparedstatement.setString(j, s1);
        if(k != 0)
            preparedstatement.setString(k, s3);
        if(l != 0)
            preparedstatement.setString(l, s);
        if(i1 != 0)
            preparedstatement.setString(i1, s2);
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public synchronized ResultSet getImportedKeys(String s, String s1, String s2)
        throws SQLException
    {
        return keys_query(null, null, s1, s2, "ORDER BY pktable_schem, pktable_name, key_seq");
    }

    public ResultSet getExportedKeys(String s, String s1, String s2)
        throws SQLException
    {
        return keys_query(s1, s2, null, null, "ORDER BY fktable_schem, fktable_name, key_seq");
    }

    public ResultSet getCrossReference(String s, String s1, String s2, String s3, String s4, String s5)
        throws SQLException
    {
        return keys_query(s1, s2, s4, s5, "ORDER BY fktable_schem, fktable_name, key_seq");
    }

    public ResultSet getTypeInfo()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized ResultSet getIndexInfo(String s, String s1, String s2, boolean flag, boolean flag1)
        throws SQLException
    {
        Statement statement = connection.createStatement();
        if(s1 != null && s1.length() != 0 && !OracleSql.isValidObjectName(s1) || s2 != null && s2.length() != 0 && !OracleSql.isValidObjectName(s2))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(!flag1)
        {
            String s3 = (new StringBuilder()).append("analyze table ").append(s1 != null ? (new StringBuilder()).append(s1).append(".").toString() : "").append(s2).append(" compute statistics").toString();
            statement.executeUpdate(s3);
        }
        if(s2.startsWith("\"") && s2.endsWith("\"") && s2.length() > 2)
            s2 = s2.substring(1, s2.length() - 1);
        String s4 = (new StringBuilder()).append("select null as table_cat,\n       owner as table_schem,\n       table_name,\n       0 as NON_UNIQUE,\n       null as index_qualifier,\n       null as index_name, 0 as type,\n       0 as ordinal_position, null as column_name,\n       null as asc_or_desc,\n       num_rows as cardinality,\n       blocks as pages,\n       null as filter_condition\nfrom all_tables\nwhere table_name = '").append(s2).append("'\n").toString();
        String s5 = "";
        if(s1 != null && s1.length() > 0)
        {
            if(s1.startsWith("\"") && s1.endsWith("\"") && s1.length() > 2)
                s1 = s1.substring(1, s1.length() - 1);
            s5 = (new StringBuilder()).append("  and owner = '").append(s1).append("'\n").toString();
        }
        String s6 = (new StringBuilder()).append("select null as table_cat,\n       i.owner as table_schem,\n       i.table_name,\n       decode (i.uniqueness, 'UNIQUE', 0, 1),\n       null as index_qualifier,\n       i.index_name,\n       1 as type,\n       c.column_position as ordinal_position,\n       c.column_name,\n       null as asc_or_desc,\n       i.distinct_keys as cardinality,\n       i.leaf_blocks as pages,\n       null as filter_condition\nfrom all_indexes i, all_ind_columns c\nwhere i.table_name = '").append(s2).append("'\n").toString();
        String s7 = "";
        if(s1 != null && s1.length() > 0)
            s7 = (new StringBuilder()).append("  and i.owner = '").append(s1).append("'\n").toString();
        String s8 = "";
        if(flag)
            s8 = "  and i.uniqueness = 'UNIQUE'\n";
        String s9 = "  and i.index_name = c.index_name\n  and i.table_owner = c.table_owner\n  and i.table_name = c.table_name\n  and i.owner = c.index_owner\n";
        String s10 = "order by non_unique, type, index_name, ordinal_position\n";
        String s11 = (new StringBuilder()).append(s4).append(s5).append("union\n").append(s6).append(s7).append(s8).append(s9).append(s10).toString();
        OracleResultSet oracleresultset = (OracleResultSet)statement.executeQuery(s11);
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    SQLException fail()
    {
        SQLException sqlexception = new SQLException("Not implemented yet");
        return sqlexception;
    }

    public boolean supportsResultSetType(int i)
        throws SQLException
    {
        return true;
    }

    public boolean supportsResultSetConcurrency(int i, int j)
        throws SQLException
    {
        return true;
    }

    public boolean ownUpdatesAreVisible(int i)
        throws SQLException
    {
        return i != 1003;
    }

    public boolean ownDeletesAreVisible(int i)
        throws SQLException
    {
        return i != 1003;
    }

    public boolean ownInsertsAreVisible(int i)
        throws SQLException
    {
        return false;
    }

    public boolean othersUpdatesAreVisible(int i)
        throws SQLException
    {
        return i == 1005;
    }

    public boolean othersDeletesAreVisible(int i)
        throws SQLException
    {
        return false;
    }

    public boolean othersInsertsAreVisible(int i)
        throws SQLException
    {
        return false;
    }

    public boolean updatesAreDetected(int i)
        throws SQLException
    {
        return false;
    }

    public boolean deletesAreDetected(int i)
        throws SQLException
    {
        return false;
    }

    public boolean insertsAreDetected(int i)
        throws SQLException
    {
        return false;
    }

    public boolean supportsBatchUpdates()
        throws SQLException
    {
        return true;
    }

    public ResultSet getUDTs(String s, String s1, String s2, int ai[])
        throws SQLException
    {
        boolean flag = false;
        if(s2 == null || s2.length() == 0)
            flag = false;
        else
        if(ai == null)
        {
            flag = true;
        } else
        {
            int i = 0;
            do
            {
                if(i >= ai.length)
                    break;
                if(ai[i] == 2002)
                {
                    flag = true;
                    break;
                }
                i++;
            } while(true);
        }
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append("SELECT NULL AS TYPE_CAT, owner AS TYPE_SCHEM, type_name, NULL AS CLASS_NAME, 'STRUCT' AS DATA_TYPE, NULL AS REMARKS FROM all_types ");
        if(flag)
            stringbuffer.append("WHERE typecode = 'OBJECT' AND owner LIKE :1 ESCAPE '/' AND type_name LIKE :2 ESCAPE '/'");
        else
            stringbuffer.append("WHERE 1 = 2");
        PreparedStatement preparedstatement = connection.prepareStatement(stringbuffer.substring(0, stringbuffer.length()));
        if(flag)
        {
            String as[] = new String[1];
            String as1[] = new String[1];
            if(SQLName.parse(s2, as, as1))
            {
                preparedstatement.setString(1, as[0]);
                preparedstatement.setString(2, as1[0]);
            } else
            {
                if(s1 != null)
                    preparedstatement.setString(1, s1);
                else
                    preparedstatement.setNull(1, 12);
                preparedstatement.setString(2, s2);
            }
        }
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public Connection getConnection()
        throws SQLException
    {
        return connection.getWrapper();
    }

    public boolean supportsSavepoints()
        throws SQLException
    {
        return true;
    }

    public boolean supportsNamedParameters()
        throws SQLException
    {
        return true;
    }

    public boolean supportsMultipleOpenResults()
        throws SQLException
    {
        return false;
    }

    public boolean supportsGetGeneratedKeys()
        throws SQLException
    {
        return true;
    }

    public ResultSet getSuperTypes(String s, String s1, String s2)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSet getSuperTables(String s, String s1, String s2)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSet getAttributes(String s, String s1, String s2, String s3)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean supportsResultSetHoldability(int i)
        throws SQLException
    {
        return i == 1;
    }

    public int getResultSetHoldability()
        throws SQLException
    {
        return 1;
    }

    public int getDatabaseMajorVersion()
        throws SQLException
    {
        return connection.getVersionNumber() / 1000;
    }

    public int getDatabaseMinorVersion()
        throws SQLException
    {
        return (connection.getVersionNumber() % 1000) / 100;
    }

    public int getJDBCMajorVersion()
        throws SQLException
    {
        return DRIVER_MAJOR_VERSION;
    }

    public int getJDBCMinorVersion()
        throws SQLException
    {
        return DRIVER_MINOR_VERSION;
    }

    public int getSQLStateType()
        throws SQLException
    {
        return 0;
    }

    public boolean locatorsUpdateCopy()
        throws SQLException
    {
        return true;
    }

    public boolean supportsStatementPooling()
        throws SQLException
    {
        return true;
    }

    public static String getDriverNameInfo()
        throws SQLException
    {
        return DRIVER_NAME;
    }

    /**
     * @deprecated Method getDriverVersionInfo is deprecated
     */

    public static String getDriverVersionInfo()
        throws SQLException
    {
        return DRIVER_VERSION;
    }

    /**
     * @deprecated Method getDriverMajorVersionInfo is deprecated
     */

    public static int getDriverMajorVersionInfo()
    {
        return DRIVER_MAJOR_VERSION;
    }

    /**
     * @deprecated Method getDriverMinorVersionInfo is deprecated
     */

    public static int getDriverMinorVersionInfo()
    {
        return DRIVER_MINOR_VERSION;
    }

    /**
     * @deprecated Method getLobPrecision is deprecated
     */

    public static String getLobPrecision()
        throws SQLException
    {
        return "-1";
    }

    public long getLobMaxLength()
        throws SQLException
    {
        return connection.getVersionNumber() < 10000 ? LOB_MAXLENGTH_32BIT : 0x7fffffffffffffffL;
    }

    public RowIdLifetime getRowIdLifetime()
        throws SQLException
    {
        return RowIdLifetime.ROWID_VALID_FOREVER;
    }

    public ResultSet getSchemas(String s, String s1)
        throws SQLException
    {
        if(s1 == null)
        {
            return getSchemas();
        } else
        {
            String s2 = "SELECT username AS table_schem, null as table_catalog FROM all_users WHERE username LIKE ? ORDER BY table_schem";
            PreparedStatement preparedstatement = connection.prepareStatement(s2);
            preparedstatement.setString(1, s1);
            OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
            oracleresultset.closeStatementOnClose();
            return oracleresultset;
        }
    }

    public boolean supportsStoredFunctionsUsingCallSyntax()
        throws SQLException
    {
        return true;
    }

    public boolean autoCommitFailureClosesAllResultSets()
        throws SQLException
    {
        return false;
    }

    public ResultSet getClientInfoProperties()
        throws SQLException
    {
        Statement statement = connection.createStatement();
        return statement.executeQuery("select NULL NAME, -1 MAX_LEN, NULL DEFAULT_VALUE, NULL DESCRIPTION  from dual where 0 = 1");
    }

    public ResultSet getFunctions(String s, String s1, String s2)
        throws SQLException
    {
        String s3 = "SELECT\n  -- Standalone functions\n  NULL AS function_cat,\n  owner AS function_schem,\n  object_name AS function_name,\n  'Standalone function' AS remarks,\n  0 AS function_type,\n  NULL AS specific_name\nFROM all_objects\nWHERE object_type = 'FUNCTION'\n  AND owner LIKE :1 ESCAPE '/'\n  AND object_name LIKE :2 ESCAPE '/'\n";
        String s4 = "SELECT\n  -- Packaged functions\n  package_name AS function_cat,\n  owner AS function_schem,\n  object_name AS function_name,\n  'Packaged function' AS remarks,\n  decode (data_type, 'TABLE', 2, 'PL/SQL TABLE', 2, 1) AS function_type,\n  NULL AS specific_name\nFROM all_arguments\nWHERE argument_name IS NULL\n  AND in_out = 'OUT'\n  AND data_level = 0\n";
        String s5 = "  AND package_name LIKE :3 ESCAPE '/'\n  AND owner LIKE :4 ESCAPE '/'\n  AND object_name LIKE :5 ESCAPE '/'\n";
        String s6 = "  AND package_name IS NOT NULL\n  AND owner LIKE :6 ESCAPE '/'\n  AND object_name LIKE :7 ESCAPE '/'\n";
        String s7 = "ORDER BY function_schem, function_name\n";
        PreparedStatement preparedstatement = null;
        Object obj = null;
        String s11 = s1;
        if(s1 == null)
            s11 = "%";
        else
        if(s1.equals(""))
            s11 = getUserName().toUpperCase();
        String s12 = s2;
        if(s2 == null)
            s12 = "%";
        else
        if(s2.equals(""))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(s == null)
        {
            String s8 = (new StringBuilder()).append(s3).append("UNION ALL ").append(s4).append(s6).append(s7).toString();
            preparedstatement = connection.prepareStatement(s8);
            preparedstatement.setString(1, s11);
            preparedstatement.setString(2, s12);
            preparedstatement.setString(3, s11);
            preparedstatement.setString(4, s12);
        } else
        if(s.equals(""))
        {
            String s9 = s3;
            preparedstatement = connection.prepareStatement(s9);
            preparedstatement.setString(1, s11);
            preparedstatement.setString(2, s12);
        } else
        {
            String s10 = (new StringBuilder()).append(s4).append(s5).append(s7).toString();
            preparedstatement = connection.prepareStatement(s10);
            preparedstatement.setString(1, s11);
            preparedstatement.setString(2, s11);
            preparedstatement.setString(3, s12);
        }
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public boolean isWrapperFor(Class class1)
        throws SQLException
    {
        if(class1.isInterface())
        {
            return class1.isInstance(this);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public Object unwrap(Class class1)
        throws SQLException
    {
        if(class1.isInterface() && class1.isInstance(this))
        {
            return this;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

    protected boolean hasSqlWildcard(String s)
    {
        if(sqlWildcardPattern == null)
            sqlWildcardPattern = Pattern.compile("^%|^_|[^/]%|[^/]_");
        Matcher matcher = sqlWildcardPattern.matcher(s);
        return matcher.find();
    }

    protected String stripSqlEscapes(String s)
    {
        if(sqlEscapePattern == null)
            sqlEscapePattern = Pattern.compile("/");
        Matcher matcher = sqlEscapePattern.matcher(s);
        StringBuffer stringbuffer = new StringBuffer();
        for(; matcher.find(); matcher.appendReplacement(stringbuffer, ""));
        matcher.appendTail(stringbuffer);
        return stringbuffer.toString();
    }

    String getUnpackagedProcedureColumnsNoWildcardsPlsql()
        throws SQLException
    {
        String s = "declare\n  in_owner varchar2(32) := null;\n  in_name varchar2(32) := null;\n  my_user_name varchar2(32) := null;\n  cnt number := 0;\n  temp_owner varchar2(32) := null;\n  temp_name  varchar2(32):= null;\n  out_owner varchar2(32) := null;\n  out_name  varchar2(32):= null;\n  loc varchar2(32) := null;\n  status number := 0;\n  TYPE recursion_check_type is table of number index by varchar2(65);\n  recursion_check recursion_check_type;\n  dotted_name varchar2(65);\n  recursion_cnt number := 0;\n  xxx SYS_REFCURSOR;\nbegin\n  in_owner := ?;\n  in_name := ?;\n  select user into my_user_name from dual;\n  if( my_user_name = in_owner ) then\n    select count(*) into cnt from user_procedures where object_name = in_name;\n    if( cnt = 1 ) then\n      out_owner := in_owner;\n      out_name := in_name;\n      loc := 'USER_PROCEDURES';\n    end if;\n  else\n    select count(*) into cnt from all_arguments where owner = in_owner and object_name = in_name;\n    if( cnt = 1 ) then\n      out_owner := in_owner;\n      out_name := in_name;\n      loc := 'ALL_ARGUMENTS';\n    end if;\n  end if;\n  if loc is null then\n    temp_owner := in_owner;\n    temp_name := in_name;\n    loop\n      begin\n        dotted_name := temp_owner || '.' ||temp_name;\n        begin\n          recursion_cnt := recursion_check(dotted_name );\n          status := -1;\n          exit;\n        exception\n        when NO_DATA_FOUND then\n          recursion_check( dotted_name ) := 1;\n        end;\n        select table_owner, table_name into out_owner, out_name from all_synonyms \n          where  owner = temp_owner and synonym_name = temp_name;\n        cnt := cnt + 1;\n        temp_owner  := out_owner;\n        temp_name := out_name;\n        exception\n        when NO_DATA_FOUND then\n          exit;\n        end;\n      end loop;\n      if( not(out_owner is null) ) then\n        loc := 'ALL_SYNONYMS';\n    end if;\n  end if;\n";
        short word0 = connection.getVersionNumber();
        String s1 = "if( status = 0 ) then \n open xxx for \n";
        String s2 = (new StringBuilder()).append("SELECT package_name AS procedure_cat,\n       owner AS procedure_schem,\n       object_name AS procedure_name,\n       argument_name AS column_name,\n       DECODE(position, 0, 5,\n                        DECODE(in_out, 'IN', 1,\n                                       'OUT', 4,\n                                       'IN/OUT', 2,\n                                       0)) AS column_type,\n       DECODE (data_type, 'CHAR', 1,\n                          'VARCHAR2', 12,\n                          'NUMBER', 3,\n                          'LONG', -1,\n                          'DATE', ").append(connection.getMapDateToTimestamp() ? "93,\n" : "91,\n").append("                          'RAW', -3,\n").append("                          'LONG RAW', -4,\n").append("                          'TIMESTAMP', 93, \n").append("                          'TIMESTAMP WITH TIME ZONE', -101, \n").append("               'TIMESTAMP WITH LOCAL TIME ZONE', -102, \n").append("               'INTERVAL YEAR TO MONTH', -103, \n").append("               'INTERVAL DAY TO SECOND', -104, \n").append("               'BINARY_FLOAT', 100, 'BINAvRY_DOUBLE', 101,").append("               1111) AS data_type,\n").append("       DECODE(data_type, 'OBJECT', type_owner || '.' || type_name, ").append("              data_type) AS type_name,\n").append("       DECODE (data_precision, NULL, data_length,\n").append("                               data_precision) AS precision,\n").append("       data_length AS length,\n").append("       data_scale AS scale,\n").append("       10 AS radix,\n").append("       1 AS nullable,\n").append("       NULL AS remarks,\n").append("       default_value AS column_def,\n").append("       NULL as sql_data_type,\n").append("       NULL AS sql_datetime_sub,\n").append("       DECODE(data_type,\n").append("                         'CHAR', 32767,\n").append("                         'VARCHAR2', 32767,\n").append("                         'LONG', 32767,\n").append("                         'RAW', 32767,\n").append("                         'LONG RAW', 32767,\n").append("                         NULL) AS char_octet_length,\n").append("       (sequence - 1) AS ordinal_position,\n").append("       'YES' AS is_nullable,\n").append("       NULL AS specific_name,\n").append("       sequence,\n").append("       overload,\n").append("       default_value\n").toString();
        String s3 = "FROM all_arguments a";
        String s4 = "WHERE a.owner = out_owner \n  AND a.object_name = out_name\n AND a.argument_name LIKE ? ESCAPE '/'\n AND data_level = 0\n AND package_name is null\n";
        String s5 = "ORDER BY procedure_schem, procedure_name, overload, sequence\n";
        String s6 = s1;
        s6 = (new StringBuilder()).append(s6).append(s2).toString();
        s6 = (new StringBuilder()).append(s6).append(s3).toString();
        s6 = (new StringBuilder()).append(s6).append("\n").append(s4).toString();
        s6 = (new StringBuilder()).append(s6).append("\n").append(s5).toString();
        String s7 = "; \n end if;\n  ? := xxx; ? := status;\n end;";
        String s8 = (new StringBuilder()).append(s).append(s6).append(s7).toString();
        return s8;
    }

    String getPackagedProcedureColumnsNoWildcardsPlsql()
        throws SQLException
    {
        String s = "declare\n  in_package_name varchar2(32) := null;\n  in_owner varchar2(32) := null;\n  in_name varchar2(32) := null;\n  my_user_name varchar2(32) := null;\n  cnt number := 0;\n  temp_package_name varchar2(32) := null;\n  temp_owner varchar2(32) := null;\n  out_package_name varchar2(32) := null;\n  out_owner varchar2(32) := null;\n  loc varchar2(32) := null;\n  status number := 0;\n  TYPE recursion_check_type is table of number index by varchar2(65);\n  recursion_check recursion_check_type;\n  dotted_name varchar2(65);\n  recursion_cnt number := 0;\n  xxx SYS_REFCURSOR;\nbegin\n  in_package_name := ?;\n  in_owner := ?;\n  in_name := ?;\n  select user into my_user_name from dual;\n  if( my_user_name = in_owner ) then\n    select count(*) into cnt from user_arguments where package_name = in_package_name;\n    if( cnt >= 1 ) then\n      out_owner := in_owner;\n      out_package_name := in_package_name;\n      loc := 'USER_ARGUMENTS';\n    end if;\n  else\n    select count(*) into cnt from all_arguments where owner = in_owner and package_name = in_package_name;\n    if( cnt >= 1 ) then\n      out_owner := in_owner;\n      out_package_name := in_package_name;\n      loc := 'ALL_ARGUMENTS';\n    end if;\n  end if;\n  if loc is null then\n  temp_owner := in_owner;\n  temp_package_name := in_package_name;\n  loop\n    begin\n      dotted_name := temp_owner || '.' ||temp_package_name;\n      begin\n        recursion_cnt := recursion_check(dotted_name );\n        status := -1;\n        exit;\n      exception\n      when NO_DATA_FOUND then\n        recursion_check( dotted_name ) := 1;\n      end;\n      select table_owner, table_name into out_owner, out_package_name from all_synonyms \n        where  owner = temp_owner and synonym_name = temp_package_name;\n      cnt := cnt + 1;\n      temp_owner  := out_owner;\n      temp_package_name := out_package_name;\n      exception\n      when NO_DATA_FOUND then\n        exit;\n      end;\n    end loop;\n    if( not(out_owner is null) ) then\n      loc := 'ALL_SYNONYMS';\n    end if;\n  end if;\n";
        short word0 = connection.getVersionNumber();
        String s1 = "if( status = 0 ) then \n open xxx for \n";
        String s2 = (new StringBuilder()).append("SELECT package_name AS procedure_cat,\n       owner AS procedure_schem,\n       object_name AS procedure_name,\n       argument_name AS column_name,\n       DECODE(position, 0, 5,\n                        DECODE(in_out, 'IN', 1,\n                                       'OUT', 4,\n                                       'IN/OUT', 2,\n                                       0)) AS column_type,\n       DECODE (data_type, 'CHAR', 1,\n                          'VARCHAR2', 12,\n                          'NUMBER', 3,\n                          'LONG', -1,\n                          'DATE', ").append(connection.getMapDateToTimestamp() ? "93,\n" : "91,\n").append("                          'RAW', -3,\n").append("                          'LONG RAW', -4,\n").append("                          'TIMESTAMP', 93, \n").append("                          'TIMESTAMP WITH TIME ZONE', -101, \n").append("               'TIMESTAMP WITH LOCAL TIME ZONE', -102, \n").append("               'INTERVAL YEAR TO MONTH', -103, \n").append("               'INTERVAL DAY TO SECOND', -104, \n").append("               'BINARY_FLOAT', 100, 'BINAvRY_DOUBLE', 101,").append("               1111) AS data_type,\n").append("       DECODE(data_type, 'OBJECT', type_owner || '.' || type_name, ").append("              data_type) AS type_name,\n").append("       DECODE (data_precision, NULL, data_length,\n").append("                               data_precision) AS precision,\n").append("       data_length AS length,\n").append("       data_scale AS scale,\n").append("       10 AS radix,\n").append("       1 AS nullable,\n").append("       NULL AS remarks,\n").append("       default_value AS column_def,\n").append("       NULL as sql_data_type,\n").append("       NULL AS sql_datetime_sub,\n").append("       DECODE(data_type,\n").append("                         'CHAR', 32767,\n").append("                         'VARCHAR2', 32767,\n").append("                         'LONG', 32767,\n").append("                         'RAW', 32767,\n").append("                         'LONG RAW', 32767,\n").append("                         NULL) AS char_octet_length,\n").append("       (sequence - 1) AS ordinal_position,\n").append("       'YES' AS is_nullable,\n").append("       NULL AS specific_name,\n").append("       sequence,\n").append("       overload,\n").append("       default_value\n").toString();
        String s3 = "FROM all_arguments a";
        String s4 = "WHERE a.owner = out_owner \n  AND a.object_name LIKE in_name ESCAPE '/' \n AND a.argument_name LIKE ? ESCAPE '/' \n AND data_level = 0\n AND package_name = out_package_name\n";
        String s5 = "ORDER BY procedure_schem, procedure_name, overload, sequence\n";
        String s6 = s1;
        s6 = (new StringBuilder()).append(s6).append(s2).toString();
        s6 = (new StringBuilder()).append(s6).append(s3).toString();
        s6 = (new StringBuilder()).append(s6).append("\n").append(s4).toString();
        s6 = (new StringBuilder()).append(s6).append("\n").append(s5).toString();
        String s7 = "; \n end if;\n  ? := xxx; ? := status;\n end;";
        String s8 = (new StringBuilder()).append(s).append(s6).append(s7).toString();
        return s8;
    }

    public OracleTypeMetaData getOracleTypeMetaData(String s)
        throws SQLException
    {
        return TypeDescriptor.getTypeDescriptor(s, connection);
    }

}
