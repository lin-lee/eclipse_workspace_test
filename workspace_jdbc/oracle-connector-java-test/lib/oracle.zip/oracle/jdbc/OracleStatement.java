// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleStatement.java

package oracle.jdbc;

import java.sql.SQLException;
import java.sql.Statement;
import oracle.jdbc.dcn.DatabaseChangeRegistration;

// Referenced classes of package oracle.jdbc:
//            OracleResultSetCache

public interface OracleStatement
    extends Statement
{

    public static final int NEW = 0;
    public static final int IMPLICIT = 1;
    public static final int EXPLICIT = 2;

    public abstract void clearDefines()
        throws SQLException;

    public abstract void defineColumnType(int i, int j)
        throws SQLException;

    public abstract void defineColumnType(int i, int j, int k)
        throws SQLException;

    public abstract void defineColumnType(int i, int j, int k, short word0)
        throws SQLException;

    public abstract void defineColumnTypeBytes(int i, int j, int k)
        throws SQLException;

    public abstract void defineColumnTypeChars(int i, int j, int k)
        throws SQLException;

    public abstract void defineColumnType(int i, int j, String s)
        throws SQLException;

    public abstract int getRowPrefetch();

    public abstract void setResultSetCache(OracleResultSetCache oracleresultsetcache)
        throws SQLException;

    public abstract void setRowPrefetch(int i)
        throws SQLException;

    public abstract int getLobPrefetchSize();

    public abstract void setLobPrefetchSize(int i)
        throws SQLException;

    public abstract void closeWithKey(String s)
        throws SQLException;

    /**
     * @deprecated Method creationState is deprecated
     */

    public abstract int creationState();

    public abstract boolean isNCHAR(int i)
        throws SQLException;

    public abstract void setDatabaseChangeRegistration(DatabaseChangeRegistration databasechangeregistration)
        throws SQLException;

    public abstract String[] getRegisteredTableNames()
        throws SQLException;

    public abstract long getRegisteredQueryId()
        throws SQLException;
}
