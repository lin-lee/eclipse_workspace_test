// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   DemultiplexingLogHandler.java

package oracle.jdbc.diagnostics;

import java.io.IOException;
import java.util.*;
import java.util.logging.*;

public class DemultiplexingLogHandler extends FileHandler
{

    static final String PROPERTY_PATTERN = "oracle.jdbc.diagnostics.DemultiplexingLogHandler.pattern";
    static final String PROPERTY_LIMIT = "oracle.jdbc.diagnostics.DemultiplexingLogHandler.limit";
    static final String PROPERTY_COUNT = "oracle.jdbc.diagnostics.DemultiplexingLogHandler.count";
    static final String PROPERTY_APPEND = "oracle.jdbc.diagnostics.DemultiplexingLogHandler.append";
    static final String DEFAULT_PATTERN = "%h/ojdbc_%s.trc";
    static final String DEFAULT_APPEND = String.valueOf(false);
    static final String DEFAULT_LIMIT = String.valueOf(0x7fffffff);
    static final String DEFAULT_COUNT = String.valueOf(1);
    String localPattern;
    boolean localAppend;
    int localLimit;
    int localCount;
    Hashtable handlerList;

    public DemultiplexingLogHandler()
        throws IOException
    {
        super(getFilename(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.pattern", "%h/ojdbc_%s.trc"), "MAIN"), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.limit", DEFAULT_LIMIT)), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.count", DEFAULT_COUNT)), Boolean.getBoolean(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.append", DEFAULT_APPEND)));
        handlerList = new Hashtable(50);
    }

    public DemultiplexingLogHandler(String s)
        throws IOException
    {
        super(getFilename(s, "MAIN"), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.limit", DEFAULT_LIMIT)), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.count", DEFAULT_COUNT)), Boolean.getBoolean(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.append", DEFAULT_APPEND)));
        handlerList = new Hashtable(50);
    }

    public DemultiplexingLogHandler(String s, boolean flag)
        throws IOException
    {
        super(getFilename(s, "MAIN"), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.limit", DEFAULT_LIMIT)), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.count", DEFAULT_COUNT)), flag);
        handlerList = new Hashtable(50);
    }

    public DemultiplexingLogHandler(String s, int i, int j)
        throws IOException
    {
        super(getFilename(s, "MAIN"), i, j, Boolean.getBoolean(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.append", DEFAULT_APPEND)));
        handlerList = new Hashtable(50);
    }

    public DemultiplexingLogHandler(String s, int i, int j, boolean flag)
        throws IOException
    {
        super(getFilename(s, "MAIN"), i, j, flag);
        handlerList = new Hashtable(50);
    }

    void initValues()
    {
        localPattern = getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.pattern", "%h/ojdbc_%s.trc");
        localLimit = Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.limit", DEFAULT_LIMIT));
        localCount = Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.count", DEFAULT_COUNT));
        localAppend = Boolean.getBoolean(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.append", DEFAULT_APPEND));
    }

    static final String getFilename(String s, String s1)
    {
        if(s == null)
            s = "%h/ojdbc_%s.trc";
        if(s.contains("%s"))
            return s.replaceAll("%s", s1);
        else
            return (new StringBuilder()).append(s).append(".").append(s1).toString();
    }

    static String getProperty(String s, String s1)
    {
        String s2 = LogManager.getLogManager().getProperty(s);
        return s2 == null ? s1 : s2;
    }

    public void publish(LogRecord logrecord)
    {
        Object aobj[] = logrecord.getParameters();
        if(aobj != null && aobj.length > 0)
        {
            Object obj = (Handler)handlerList.get(aobj[0]);
            if(obj == null)
            {
                if(localPattern == null)
                    initValues();
                try
                {
                    obj = new FileHandler(getFilename(localPattern, (String)aobj[0]), localLimit, localCount, localAppend);
                    ((Handler) (obj)).setFormatter(getFormatter());
                    ((Handler) (obj)).setFilter(getFilter());
                    ((Handler) (obj)).setLevel(getLevel());
                    ((Handler) (obj)).setEncoding(getEncoding());
                    ((Handler) (obj)).setErrorManager(getErrorManager());
                }
                catch(IOException ioexception)
                {
                    reportError("Unable open FileHandler", ioexception, 0);
                }
                handlerList.put(aobj[0], obj);
            }
            ((Handler) (obj)).publish(logrecord);
        } else
        {
            super.publish(logrecord);
        }
    }

    public void close()
    {
        Handler handler;
        for(Iterator iterator = handlerList.values().iterator(); iterator.hasNext(); handler.close())
            handler = (Handler)iterator.next();

        super.close();
    }

}
