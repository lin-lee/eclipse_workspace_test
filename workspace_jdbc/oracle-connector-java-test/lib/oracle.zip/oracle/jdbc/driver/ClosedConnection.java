// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ClosedConnection.java

package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.pool.OraclePooledConnection;
import oracle.sql.BLOB;
import oracle.sql.CLOB;

// Referenced classes of package oracle.jdbc.driver:
//            PhysicalConnection, DatabaseError, OracleStatement

class ClosedConnection extends PhysicalConnection
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    ClosedConnection()
    {
        lifecycle = 4;
    }

    void initializePassword(String s)
        throws SQLException
    {
    }

    OracleStatement RefCursorBytesToStatement(byte abyte0[], OracleStatement oraclestatement)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    int getDefaultStreamChunkSize()
    {
        return -1;
    }

    short doGetVersionNumber()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    String doGetDatabaseProductVersion()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void doRollback()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void doCommit(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void doSetAutoCommit(boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void cancelOperationOnServer(boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void doAbort()
        throws SQLException
    {
    }

    void open(OracleStatement oraclestatement)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void logon()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void getPropertyForPooledConnection(OraclePooledConnection oraclepooledconnection)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BLOB createTemporaryBlob(Connection connection, boolean flag, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public CLOB createTemporaryClob(Connection connection, boolean flag, int i, short word0)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

}
