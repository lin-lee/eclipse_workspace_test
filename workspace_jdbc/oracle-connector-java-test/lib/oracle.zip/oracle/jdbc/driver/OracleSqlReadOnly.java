// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleSql.java

package oracle.jdbc.driver;


class OracleSqlReadOnly
{
    static final class ODBCAction extends Enum
    {

        public static final ODBCAction NONE;
        public static final ODBCAction COPY;
        public static final ODBCAction QUESTION;
        public static final ODBCAction SAVE_DELIMITER;
        public static final ODBCAction LOOK_FOR_DELIMITER;
        public static final ODBCAction FUNCTION;
        public static final ODBCAction CALL;
        public static final ODBCAction TIME;
        public static final ODBCAction TIMESTAMP;
        public static final ODBCAction DATE;
        public static final ODBCAction ESCAPE;
        public static final ODBCAction SCALAR_FUNCTION;
        public static final ODBCAction OUTER_JOIN;
        public static final ODBCAction UNKNOWN_ESCAPE;
        public static final ODBCAction END_ODBC_ESCAPE;
        public static final ODBCAction COMMA;
        public static final ODBCAction OPEN_PAREN;
        public static final ODBCAction CLOSE_PAREN;
        public static final ODBCAction BEGIN;
        private static final ODBCAction $VALUES[];

        public static ODBCAction[] values()
        {
            return (ODBCAction[])$VALUES.clone();
        }

        public static ODBCAction valueOf(String s)
        {
            return (ODBCAction)Enum.valueOf(oracle/jdbc/driver/OracleSqlReadOnly$ODBCAction, s);
        }

        static 
        {
            NONE = new ODBCAction("NONE", 0);
            COPY = new ODBCAction("COPY", 1);
            QUESTION = new ODBCAction("QUESTION", 2);
            SAVE_DELIMITER = new ODBCAction("SAVE_DELIMITER", 3);
            LOOK_FOR_DELIMITER = new ODBCAction("LOOK_FOR_DELIMITER", 4);
            FUNCTION = new ODBCAction("FUNCTION", 5);
            CALL = new ODBCAction("CALL", 6);
            TIME = new ODBCAction("TIME", 7);
            TIMESTAMP = new ODBCAction("TIMESTAMP", 8);
            DATE = new ODBCAction("DATE", 9);
            ESCAPE = new ODBCAction("ESCAPE", 10);
            SCALAR_FUNCTION = new ODBCAction("SCALAR_FUNCTION", 11);
            OUTER_JOIN = new ODBCAction("OUTER_JOIN", 12);
            UNKNOWN_ESCAPE = new ODBCAction("UNKNOWN_ESCAPE", 13);
            END_ODBC_ESCAPE = new ODBCAction("END_ODBC_ESCAPE", 14);
            COMMA = new ODBCAction("COMMA", 15);
            OPEN_PAREN = new ODBCAction("OPEN_PAREN", 16);
            CLOSE_PAREN = new ODBCAction("CLOSE_PAREN", 17);
            BEGIN = new ODBCAction("BEGIN", 18);
            $VALUES = (new ODBCAction[] {
                NONE, COPY, QUESTION, SAVE_DELIMITER, LOOK_FOR_DELIMITER, FUNCTION, CALL, TIME, TIMESTAMP, DATE, 
                ESCAPE, SCALAR_FUNCTION, OUTER_JOIN, UNKNOWN_ESCAPE, END_ODBC_ESCAPE, COMMA, OPEN_PAREN, CLOSE_PAREN, BEGIN
            });
        }

        private ODBCAction(String s, int i)
        {
            super(s, i);
        }
    }


    private static final int BASE = 0;
    private static final int BASE_1 = 1;
    private static final int BASE_2 = 2;
    private static final int B_STRING = 3;
    private static final int B_NAME = 4;
    private static final int B_C_COMMENT = 5;
    private static final int B_C_COMMENT_1 = 6;
    private static final int B_COMMENT = 7;
    private static final int PARAMETER = 8;
    private static final int TOKEN = 9;
    private static final int B_EGIN = 10;
    private static final int BE_GIN = 11;
    private static final int BEG_IN = 12;
    private static final int BEGI_N = 13;
    private static final int BEGIN_ = 14;
    private static final int C_ALL = 15;
    private static final int CA_LL = 16;
    private static final int CAL_L = 17;
    private static final int CALL_ = 18;
    private static final int D_Eetc = 19;
    private static final int DE_etc = 20;
    private static final int DEC_LARE = 21;
    private static final int DECL_ARE = 22;
    private static final int DECLA_RE = 23;
    private static final int DECLAR_E = 24;
    private static final int DECLARE_ = 25;
    private static final int DEL_ETE = 26;
    private static final int DELE_TE = 27;
    private static final int DELET_E = 28;
    private static final int DELETE_ = 29;
    private static final int I_NSERT = 30;
    private static final int IN_SERT = 31;
    private static final int INS_ERT = 32;
    private static final int INSE_RT = 33;
    private static final int INSER_T = 34;
    private static final int INSERT_ = 35;
    private static final int S_ELECT = 36;
    private static final int SE_LECT = 37;
    private static final int SEL_ECT = 38;
    private static final int SELE_CT = 39;
    private static final int SELEC_T = 40;
    private static final int SELECT_ = 41;
    private static final int U_PDATE = 42;
    private static final int UP_DATE = 43;
    private static final int UPD_ATE = 44;
    private static final int UPDA_TE = 45;
    private static final int UPDAT_E = 46;
    private static final int UPDATE_ = 47;
    private static final int M_ERGE = 48;
    private static final int ME_RGE = 49;
    private static final int MER_GE = 50;
    private static final int MERG_E = 51;
    private static final int MERGE_ = 52;
    private static final int W_ITH = 53;
    private static final int WI_TH = 54;
    private static final int WIT_H = 55;
    private static final int WITH_ = 56;
    private static final int KNOW_KIND = 57;
    private static final int KNOW_KIND_1 = 58;
    private static final int KNOW_KIND_2 = 59;
    private static final int K_STRING = 60;
    private static final int K_NAME = 61;
    private static final int K_C_COMMENT = 62;
    private static final int K_C_COMMENT_1 = 63;
    private static final int K_COMMENT = 64;
    private static final int K_PARAMETER = 65;
    private static final int TOKEN_KK = 66;
    private static final int W_HERE = 67;
    private static final int WH_ERE = 68;
    private static final int WHE_RE = 69;
    private static final int WHER_E = 70;
    private static final int WHERE_ = 71;
    private static final int O_RDER_BY = 72;
    private static final int OR_DER_BY = 73;
    private static final int ORD_ER_BY = 74;
    private static final int ORDE_R_BY = 75;
    private static final int ORDER__BY = 76;
    private static final int ORDER_xBY = 77;
    private static final int ORDER_B_Y = 78;
    private static final int ORDER_BY_ = 79;
    private static final int ORDER_xBY_CC_1 = 80;
    private static final int ORDER_xBY_CC_2 = 81;
    private static final int ORDER_xBY_CC_3 = 82;
    private static final int ORDER_xBY_C_1 = 83;
    private static final int ORDER_xBY_C_2 = 84;
    private static final int F_OR_UPDATE = 85;
    private static final int FO_R_UPDATE = 86;
    private static final int FOR__UPDATE = 87;
    private static final int FOR_xUPDATE = 88;
    private static final int FOR_U_PDATE = 89;
    private static final int FOR_UP_DATE = 90;
    private static final int FOR_UPD_ATE = 91;
    private static final int FOR_UPDA_TE = 92;
    private static final int FOR_UPDAT_E = 93;
    private static final int FOR_UPDATE_ = 94;
    private static final int FOR_xUPDATE_CC_1 = 95;
    private static final int FOR_xUPDATE_CC_2 = 96;
    private static final int FOR_xUPDATE_CC_3 = 97;
    private static final int FOR_xUPDATE_C_1 = 98;
    private static final int FOR_xUPDATE_C_2 = 99;
    private static final int B_N_tick = 100;
    private static final int B_NCHAR = 101;
    private static final int K_N_tick = 102;
    private static final int K_NCHAR = 103;
    private static final int K_NCHAR_tick = 104;
    private static final int B_Q_tickDelimiterCharDelimiterTick = 105;
    private static final int B_QTick_delimiterCharDelimiterTick = 106;
    private static final int B_QTickDelimiter_charDelimiterTick = 107;
    private static final int B_QTickDelimiterChar_delimiterTick = 108;
    private static final int B_QTickDelimiterCharDelimiter_tick = 109;
    private static final int K_Q_tickDelimiterCharDelimiterTick = 110;
    private static final int K_QTick_delimiterCharDelimiterTick = 111;
    private static final int K_QTickDelimiter_charDelimiterTick = 112;
    private static final int K_QTickDelimiterChar_delimiterTick = 113;
    private static final int K_QTickDelimiterCharDelimiter_tick = 114;
    private static final int K_EscEtc = 115;
    private static final int K_EscQuestion = 116;
    private static final int K_EscC_ALL = 117;
    private static final int K_EscCA_LL = 118;
    private static final int K_EscCAL_L = 119;
    private static final int K_EscCALL_ = 120;
    private static final int K_EscT = 121;
    private static final int K_EscTS_ = 122;
    private static final int K_EscD_ = 123;
    private static final int K_EscE_SCAPE = 124;
    private static final int K_EscES_CAPE = 125;
    private static final int K_EscESC_APE = 126;
    private static final int K_EscESCA_PE = 127;
    private static final int K_EscESCAP_E = 128;
    private static final int K_EscESCAPE_ = 129;
    private static final int K_EscF_N = 130;
    private static final int K_EscFN_ = 131;
    private static final int K_EscO_J = 132;
    private static final int K_EscOJ_ = 133;
    private static final int SKIP_PARAMETER_WHITESPACE = 134;
    private static final int A_LTER_SESSION = 135;
    private static final int AL_TER_SESSION = 136;
    private static final int ALT_ER_SESSION = 137;
    private static final int ALTE_R_SESSION = 138;
    private static final int ALTER__SESSION = 139;
    private static final int ALTER_xSESSION = 140;
    private static final int ALTER_S_ESSION = 141;
    private static final int ALTER_SE_SSION = 142;
    private static final int ALTER_SES_SION = 143;
    private static final int ALTER_SESS_ION = 144;
    private static final int ALTER_SESSI_ON = 145;
    private static final int ALTER_SESSIO_N = 146;
    private static final int ALTER_SESSION_ = 147;
    private static final int ALTER_xSESSION_CC_1 = 148;
    private static final int ALTER_xSESSION_CC_2 = 149;
    private static final int ALTER_xSESSION_CC_3 = 150;
    private static final int ALTER_xSESSION_C_1 = 151;
    private static final int ALTER_xSESSION_C_2 = 152;
    private static final int R_ETURNING = 153;
    private static final int RE_TURNING = 154;
    private static final int RET_URNING = 155;
    private static final int RETU_RNING = 156;
    private static final int RETUR_NING = 157;
    private static final int RETURN_ING = 158;
    private static final int RETURNI_NG = 159;
    private static final int RETURNIN_G = 160;
    private static final int RETURNING_ = 161;
    private static final int I_NTO = 162;
    private static final int IN_TO = 163;
    private static final int INT_O = 164;
    private static final int INTO_ = 165;
    private static final int LAST_STATE = 166;
    private static final int EOKTSS_LAST_STATE = 166;
    public static final String PARSER_STATE_NAME[] = {
        "BASE", "BASE_1", "BASE_2", "B_STRING", "B_NAME", "B_C_COMMENT", "B_C_COMMENT_1", "B_COMMENT", "PARAMETER", "TOKEN", 
        "B_EGIN", "BE_GIN", "BEG_IN", "BEGI_N", "BEGIN_", "C_ALL", "CA_LL", "CAL_L", "CALL_", "D_Eetc", 
        "DE_etc", "DEC_LARE", "DECL_ARE", "DECLA_RE", "DECLAR_E", "DECLARE_", "DEL_ETE", "DELE_TE", "DELET_E", "DELETE_", 
        "I_NSERT", "IN_SERT", "INS_ERT", "INSE_RT", "INSER_T", "INSERT_", "S_ELECT", "SE_LECT", "SEL_ECT", "SELE_CT", 
        "SELEC_T", "SELECT_", "U_PDATE", "UP_DATE", "UPD_ATE", "UPDA_TE", "UPDAT_E", "UPDATE_", "M_ERGE", "ME_RGE", 
        "MER_GE", "MERG_E", "MERGE_", "W_ITH", "WI_TH", "WIT_H", "WITH_", "KNOW_KIND", "KNOW_KIND_1", "KNOW_KIND_2", 
        "K_STRING", "K_NAME", "K_C_COMMENT", "K_C_COMMENT_1", "K_COMMENT", "K_PARAMETER", "TOKEN_KK", "W_HERE", "WH_ERE", "WHE_RE", 
        "WHER_E", "WHERE_", "O_RDER_BY", "OR_DER_BY", "ORD_ER_BY", "ORDE_R_BY", "ORDER__BY", "ORDER_xBY", "ORDER_B_Y", "ORDER_BY_", 
        "ORDER_xBY_CC_1", "ORDER_xBY_CC_2", "ORDER_xBY_CC_3", "ORDER_xBY_C_1 ", "ORDER_xBY_C_2 ", "F_OR_UPDATE", "FO_R_UPDATE", "FOR__UPDATE", "FOR_xUPDATE", "FOR_U_PDATE", 
        "FOR_UP_DATE", "FOR_UPD_ATE", "FOR_UPDA_TE", "FOR_UPDAT_E", "FOR_UPDATE_", "FOR_xUPDATE_CC_1", "FOR_xUPDATE_CC_2", "FOR_xUPDATE_CC_3", "FOR_xUPDATE_C_1 ", "FOR_xUPDATE_C_2 ", 
        "B_N_tick", "B_NCHAR", "K_N_tick", "K_NCHAR", "K_NCHAR_tick", "B_Q_tickDelimiterCharDelimiterTick", "B_QTick_delimiterCharDelimiterTick", "B_QTickDelimiter_charDelimiterTick", "B_QTickDelimiterChar_delimiterTick", "B_QTickDelimiterCharDelimiter_tick", 
        "K_Q_tickDelimiterCharDelimiterTick", "K_QTick_delimiterCharDelimiterTick", "K_QTickDelimiter_charDelimiterTick", "K_QTickDelimiterChar_delimiterTick", "K_QTickDelimiterCharDelimiter_tick", "K_EscEtc", "K_EscQuestion", "K_EscC_ALL", "K_EscCA_LL", "K_EscCAL_L", 
        "K_EscCALL_", "K_EscT", "K_EscTS_", "K_EscD_", "K_EscE_SCAPE", "K_EscES_CAPE", "K_EscESC_APE", "K_EscESCA_PE", "K_EscESCAP_E", "K_EscESCAPE_", 
        "K_EscF_N", "K_EscFN_", "K_EscO_J", "K_EscOJ_", "SKIP_PARAMETER_WHITESPACE", "A_LTER_SESSION", "AL_TER_SESSION", "ALT_ER_SESSION", "ALTE_R_SESSION", "ALTER__SESSION", 
        "ALTER_xSESSION", "ALTER_S_ESSION", "ALTER_SE_SSION", "ALTER_SES_SION", "ALTER_SESS_ION", "ALTER_SESSI_ON", "ALTER_SESSIO_N", "ALTER_SESSION_", "ALTER_xSESSION_CC_1", "ALTER_xSESSION_CC_2", 
        "ALTER_xSESSION_CC_3", "ALTER_xSESSION_C_1 ", "ALTER_xSESSION_C_2 ", "R_ETURNING", "RE_TURNING", "RET_URNING", "RETU_RNING", "RETUR_NING", "RETURN_ING", "RETURNI_NG", 
        "RETURNIN_G", "RETURNING_", "I_NTO", "IN_TO", "INT_O", "INTO_", "LAST_STATE"
    };
    static final int TRANSITION[][];
    static final int NO_ACTION = 0;
    static final int DELETE_ACTION = 1;
    static final int INSERT_ACTION = 2;
    static final int MERGE_ACTION = 3;
    static final int UPDATE_ACTION = 4;
    static final int PLSQL_ACTION = 5;
    static final int CALL_ACTION = 6;
    static final int SELECT_ACTION = 7;
    static final int OTHER_ACTION = 8;
    static final int WHERE_ACTION = 9;
    static final int ORDER_ACTION = 10;
    static final int ORDER_BY_ACTION = 11;
    static final int FOR_ACTION = 12;
    static final int FOR_UPDATE_ACTION = 13;
    static final int QUESTION_ACTION = 14;
    static final int PARAMETER_ACTION = 15;
    static final int END_PARAMETER_ACTION = 16;
    static final int START_NCHAR_LITERAL_ACTION = 17;
    static final int END_NCHAR_LITERAL_ACTION = 18;
    static final int SAVE_DELIMITER_ACTION = 19;
    static final int LOOK_FOR_DELIMITER_ACTION = 20;
    static final int ALTER_SESSION_ACTION = 21;
    static final int RETURNING_ACTION = 22;
    static final int INTO_ACTION = 23;
    public static final String CBI_ACTION_NAME[] = {
        "NO_ACTION", "DELETE_ACTION", "INSERT_ACTION", "MERGE_ACTION", "UPDATE_ACTION", "PLSQL_ACTION", "CALL_ACTION", "SELECT_ACTION", "OTHER_ACTION", "WHERE_ACTION", 
        "ORDER_ACTION", "ORDER_BY_ACTION", "FOR_ACTION", "FOR_UPDATE_ACTION", "QUESTION_ACTION", "PARAMETER_ACTION", "END_PARAMETER_ACTION", "START_NCHAR_LITERAL_ACTION", "END_NCHAR_LITERAL_ACTION", "SAVE_DELIMITER_ACTION", 
        "LOOK_FOR_DELIMITER_ACTION", "ALTER_SESSION_ACTION", "RETURNING_ACTION", "INTO_ACTION"
    };
    static final int ACTION[][];
    static final int INITIAL_STATE = 0;
    static final int RESTART_STATE = 66;
    static final ODBCAction ODBC_ACTION[][];
    static final int cMax = 127;
    private static final int cMaxLength = 128;

    OracleSqlReadOnly()
    {
    }

    private static final int[] copy(int ai[])
    {
        int ai1[] = new int[ai.length];
        System.arraycopy(ai, 0, ai1, 0, ai.length);
        return ai1;
    }

    private static final ODBCAction[] copy(ODBCAction aodbcaction[])
    {
        ODBCAction aodbcaction1[] = new ODBCAction[aodbcaction.length];
        System.arraycopy(aodbcaction, 0, aodbcaction1, 0, aodbcaction.length);
        return aodbcaction1;
    }

    private static final int[] newArray(int i, int j)
    {
        int ai[] = new int[i];
        for(int k = 0; k < i; k++)
            ai[k] = j;

        return ai;
    }

    private static final ODBCAction[] newArray(int i, ODBCAction odbcaction)
    {
        ODBCAction aodbcaction[] = new ODBCAction[i];
        for(int j = 0; j < i; j++)
            aodbcaction[j] = odbcaction;

        return aodbcaction;
    }

    private static final int[] copyReplacing(int ai[], int i, int j)
    {
        int ai1[] = new int[ai.length];
        for(int k = 0; k < ai1.length; k++)
        {
            int l = ai[k];
            if(l == i)
                ai1[k] = j;
            else
                ai1[k] = l;
        }

        return ai1;
    }

    private static final ODBCAction[] copyReplacing(ODBCAction aodbcaction[], ODBCAction odbcaction, ODBCAction odbcaction1)
    {
        ODBCAction aodbcaction1[] = new ODBCAction[aodbcaction.length];
        for(int i = 0; i < aodbcaction1.length; i++)
        {
            ODBCAction odbcaction2 = aodbcaction[i];
            if(odbcaction2 == odbcaction)
                aodbcaction1[i] = odbcaction1;
            else
                aodbcaction1[i] = odbcaction2;
        }

        return aodbcaction1;
    }

    static 
    {
        TRANSITION = new int[166][];
        ACTION = new int[166][];
        ODBC_ACTION = new ODBCAction[166][];
        try
        {
            int ai[] = {
                57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 
                57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 
                57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 
                57, 57, 57, 57, 57, 9, 9, 57, 57, 57, 
                57, 57, 57, 57, 57, 57, 57, 57, 9, 9, 
                9, 9, 9, 9, 9, 9, 9, 9, 57, 57, 
                57, 57, 57, 57, 9, 9, 9, 9, 9, 9, 
                9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 
                9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 
                9, 57, 57, 57, 57, 9, 57, 9, 9, 9, 
                9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 
                9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 
                9, 9, 9, 57, 57, 57, 57, 57
            };
            int ai1[] = copy(ai);
            ai1[34] = 4;
            ai1[39] = 3;
            ai1[45] = 2;
            ai1[47] = 1;
            ai1[58] = 8;
            ai1[123] = 115;
            int ai2[] = copyReplacing(ai1, 57, 0);
            ai2[65] = 135;
            ai2[97] = 135;
            ai2[66] = 10;
            ai2[98] = 10;
            ai2[67] = 15;
            ai2[99] = 15;
            ai2[68] = 19;
            ai2[100] = 19;
            ai2[73] = 30;
            ai2[105] = 30;
            ai2[109] = 48;
            ai2[77] = 48;
            ai2[78] = 100;
            ai2[110] = 100;
            ai2[81] = 105;
            ai2[113] = 105;
            ai2[83] = 36;
            ai2[115] = 36;
            ai2[85] = 42;
            ai2[117] = 42;
            ai2[87] = 53;
            ai2[119] = 53;
            int ai3[] = copyReplacing(ai1, 9, 66);
            ai3[34] = 61;
            ai3[39] = 60;
            ai3[45] = 59;
            ai3[47] = 58;
            ai3[58] = 134;
            ai3[32] = 57;
            ai3[32] = 57;
            ai3[9] = 57;
            ai3[10] = 57;
            ai3[13] = 57;
            ai3[61] = 57;
            int ai4[] = copyReplacing(ai3, 9, 66);
            ai4[78] = 102;
            ai4[110] = 102;
            ai4[81] = 110;
            ai4[113] = 110;
            ai4[87] = 67;
            ai4[119] = 67;
            ai4[79] = 72;
            ai4[111] = 72;
            ai4[70] = 85;
            ai4[102] = 85;
            ai4[82] = 153;
            ai4[114] = 153;
            ai4[73] = 162;
            ai4[105] = 162;
            int ai5[] = copyReplacing(ai4, 57, 115);
            ai5[63] = 116;
            ai5[99] = 117;
            ai5[67] = 117;
            ai5[116] = 121;
            ai5[84] = 121;
            ai5[100] = 123;
            ai5[68] = 123;
            ai5[101] = 124;
            ai5[69] = 124;
            ai5[102] = 130;
            ai5[70] = 130;
            ai5[111] = 132;
            ai5[79] = 132;
            TRANSITION[0] = ai2;
            TRANSITION[1] = copy(ai2);
            TRANSITION[1][42] = 5;
            TRANSITION[2] = copy(ai2);
            TRANSITION[2][45] = 7;
            TRANSITION[3] = newArray(128, 3);
            TRANSITION[3][39] = 0;
            TRANSITION[100] = copy(ai1);
            TRANSITION[100][39] = 101;
            TRANSITION[101] = newArray(128, 101);
            TRANSITION[101][39] = 0;
            TRANSITION[105] = copy(ai1);
            TRANSITION[105][39] = 106;
            TRANSITION[106] = newArray(128, 107);
            TRANSITION[107] = newArray(128, 107);
            TRANSITION[108] = newArray(128, 109);
            TRANSITION[109] = newArray(128, 107);
            TRANSITION[109][39] = 0;
            TRANSITION[4] = newArray(128, 4);
            TRANSITION[4][34] = 0;
            TRANSITION[5] = newArray(128, 5);
            TRANSITION[5][42] = 6;
            TRANSITION[6] = newArray(128, 5);
            TRANSITION[6][42] = 6;
            TRANSITION[6][47] = 0;
            TRANSITION[7] = newArray(128, 7);
            TRANSITION[7][10] = 0;
            TRANSITION[8] = copyReplacing(ai1, 9, 8);
            TRANSITION[9] = ai1;
            TRANSITION[10] = copy(ai1);
            TRANSITION[10][69] = 11;
            TRANSITION[10][101] = 11;
            TRANSITION[11] = copy(ai1);
            TRANSITION[11][71] = 12;
            TRANSITION[11][103] = 12;
            TRANSITION[12] = copy(ai1);
            TRANSITION[12][73] = 13;
            TRANSITION[12][105] = 13;
            TRANSITION[13] = copy(ai1);
            TRANSITION[13][78] = 14;
            TRANSITION[13][110] = 14;
            TRANSITION[14] = ai4;
            TRANSITION[15] = copy(ai1);
            TRANSITION[15][65] = 16;
            TRANSITION[15][97] = 16;
            TRANSITION[16] = copy(ai1);
            TRANSITION[16][76] = 17;
            TRANSITION[16][108] = 17;
            TRANSITION[17] = copy(ai1);
            TRANSITION[17][76] = 18;
            TRANSITION[17][108] = 18;
            TRANSITION[18] = ai4;
            TRANSITION[19] = copy(ai1);
            TRANSITION[19][69] = 20;
            TRANSITION[19][101] = 20;
            TRANSITION[20] = copy(ai1);
            TRANSITION[20][67] = 21;
            TRANSITION[20][99] = 21;
            TRANSITION[20][76] = 26;
            TRANSITION[20][108] = 26;
            TRANSITION[21] = copy(ai1);
            TRANSITION[21][76] = 22;
            TRANSITION[21][108] = 22;
            TRANSITION[22] = copy(ai1);
            TRANSITION[22][65] = 23;
            TRANSITION[22][97] = 23;
            TRANSITION[23] = copy(ai1);
            TRANSITION[23][82] = 24;
            TRANSITION[23][114] = 24;
            TRANSITION[24] = copy(ai1);
            TRANSITION[24][69] = 25;
            TRANSITION[24][101] = 25;
            TRANSITION[25] = ai4;
            TRANSITION[26] = copy(ai1);
            TRANSITION[26][69] = 27;
            TRANSITION[26][101] = 27;
            TRANSITION[27] = copy(ai1);
            TRANSITION[27][84] = 28;
            TRANSITION[27][116] = 28;
            TRANSITION[28] = copy(ai1);
            TRANSITION[28][69] = 29;
            TRANSITION[28][101] = 29;
            TRANSITION[29] = ai4;
            TRANSITION[30] = copy(ai1);
            TRANSITION[30][78] = 31;
            TRANSITION[30][110] = 31;
            TRANSITION[31] = copy(ai1);
            TRANSITION[31][83] = 32;
            TRANSITION[31][115] = 32;
            TRANSITION[32] = copy(ai1);
            TRANSITION[32][69] = 33;
            TRANSITION[32][101] = 33;
            TRANSITION[33] = copy(ai1);
            TRANSITION[33][82] = 34;
            TRANSITION[33][114] = 34;
            TRANSITION[34] = copy(ai1);
            TRANSITION[34][84] = 35;
            TRANSITION[34][116] = 35;
            TRANSITION[35] = ai4;
            TRANSITION[36] = copy(ai1);
            TRANSITION[36][69] = 37;
            TRANSITION[36][101] = 37;
            TRANSITION[37] = copy(ai1);
            TRANSITION[37][76] = 38;
            TRANSITION[37][108] = 38;
            TRANSITION[38] = copy(ai1);
            TRANSITION[38][69] = 39;
            TRANSITION[38][101] = 39;
            TRANSITION[39] = copy(ai1);
            TRANSITION[39][67] = 40;
            TRANSITION[39][99] = 40;
            TRANSITION[40] = copy(ai1);
            TRANSITION[40][84] = 41;
            TRANSITION[40][116] = 41;
            TRANSITION[41] = ai4;
            TRANSITION[42] = copy(ai1);
            TRANSITION[42][80] = 43;
            TRANSITION[42][112] = 43;
            TRANSITION[43] = copy(ai1);
            TRANSITION[43][68] = 44;
            TRANSITION[43][100] = 44;
            TRANSITION[44] = copy(ai1);
            TRANSITION[44][65] = 45;
            TRANSITION[44][97] = 45;
            TRANSITION[45] = copy(ai1);
            TRANSITION[45][84] = 46;
            TRANSITION[45][116] = 46;
            TRANSITION[46] = copy(ai1);
            TRANSITION[46][69] = 47;
            TRANSITION[46][101] = 47;
            TRANSITION[47] = ai4;
            TRANSITION[48] = copy(ai1);
            TRANSITION[48][69] = 49;
            TRANSITION[48][101] = 49;
            TRANSITION[49] = copy(ai1);
            TRANSITION[49][82] = 50;
            TRANSITION[49][114] = 50;
            TRANSITION[50] = copy(ai1);
            TRANSITION[50][71] = 51;
            TRANSITION[50][103] = 51;
            TRANSITION[51] = copy(ai1);
            TRANSITION[51][69] = 52;
            TRANSITION[51][101] = 52;
            TRANSITION[52] = ai4;
            TRANSITION[53] = copy(ai1);
            TRANSITION[53][73] = 54;
            TRANSITION[53][105] = 54;
            TRANSITION[54] = copy(ai1);
            TRANSITION[54][84] = 55;
            TRANSITION[54][116] = 55;
            TRANSITION[55] = copy(ai1);
            TRANSITION[55][72] = 56;
            TRANSITION[55][104] = 56;
            TRANSITION[56] = ai4;
            TRANSITION[66] = ai3;
            TRANSITION[58] = copy(ai4);
            TRANSITION[58][42] = 62;
            TRANSITION[59] = copy(ai4);
            TRANSITION[59][45] = 64;
            TRANSITION[62] = newArray(128, 62);
            TRANSITION[62][42] = 63;
            TRANSITION[63] = newArray(128, 62);
            TRANSITION[63][42] = 63;
            TRANSITION[63][47] = 57;
            TRANSITION[64] = newArray(128, 64);
            TRANSITION[64][10] = 57;
            TRANSITION[61] = newArray(128, 61);
            TRANSITION[61][34] = 57;
            TRANSITION[60] = newArray(128, 60);
            TRANSITION[60][39] = 57;
            TRANSITION[65] = copyReplacing(ai3, 66, 65);
            TRANSITION[134] = copyReplacing(ai3, 66, 65);
            TRANSITION[134][32] = 134;
            TRANSITION[134][10] = 134;
            TRANSITION[134][13] = 134;
            TRANSITION[134][9] = 134;
            TRANSITION[57] = ai4;
            TRANSITION[67] = copy(ai3);
            TRANSITION[67][72] = 68;
            TRANSITION[67][104] = 68;
            TRANSITION[68] = copy(ai3);
            TRANSITION[68][69] = 69;
            TRANSITION[68][101] = 69;
            TRANSITION[69] = copy(ai3);
            TRANSITION[69][82] = 70;
            TRANSITION[69][114] = 70;
            TRANSITION[70] = copy(ai3);
            TRANSITION[70][69] = 71;
            TRANSITION[70][101] = 71;
            TRANSITION[71] = ai4;
            TRANSITION[72] = copy(ai3);
            TRANSITION[72][82] = 73;
            TRANSITION[72][114] = 73;
            TRANSITION[73] = copy(ai3);
            TRANSITION[73][68] = 74;
            TRANSITION[73][100] = 74;
            TRANSITION[74] = copy(ai3);
            TRANSITION[74][69] = 75;
            TRANSITION[74][101] = 75;
            TRANSITION[75] = copy(ai3);
            TRANSITION[75][82] = 76;
            TRANSITION[75][114] = 76;
            TRANSITION[76] = copyReplacing(ai4, 57, 77);
            TRANSITION[76][47] = 80;
            TRANSITION[76][45] = 83;
            TRANSITION[77] = copyReplacing(ai4, 57, 77);
            TRANSITION[77][47] = 80;
            TRANSITION[80] = copy(ai4);
            TRANSITION[80][42] = 81;
            TRANSITION[81] = newArray(128, 81);
            TRANSITION[81][42] = 82;
            TRANSITION[82] = newArray(128, 81);
            TRANSITION[82][47] = 77;
            TRANSITION[77][45] = 83;
            TRANSITION[83] = copy(ai4);
            TRANSITION[83][45] = 84;
            TRANSITION[84] = newArray(128, 84);
            TRANSITION[84][10] = 77;
            TRANSITION[77][66] = 78;
            TRANSITION[77][98] = 78;
            TRANSITION[78] = copy(ai3);
            TRANSITION[78][89] = 79;
            TRANSITION[78][121] = 79;
            TRANSITION[79] = ai4;
            TRANSITION[85] = copy(ai4);
            TRANSITION[85][79] = 86;
            TRANSITION[85][111] = 86;
            TRANSITION[86] = copy(ai4);
            TRANSITION[86][82] = 87;
            TRANSITION[86][114] = 87;
            TRANSITION[87] = copyReplacing(ai3, 57, 88);
            TRANSITION[87][47] = 95;
            TRANSITION[87][45] = 98;
            TRANSITION[88] = copyReplacing(ai3, 57, 88);
            TRANSITION[88][47] = 95;
            TRANSITION[95] = copy(ai4);
            TRANSITION[95][42] = 96;
            TRANSITION[96] = newArray(128, 96);
            TRANSITION[96][42] = 97;
            TRANSITION[97] = newArray(128, 96);
            TRANSITION[97][47] = 88;
            TRANSITION[88][45] = 98;
            TRANSITION[98] = copy(ai4);
            TRANSITION[98][45] = 99;
            TRANSITION[99] = newArray(128, 99);
            TRANSITION[99][10] = 88;
            TRANSITION[88][85] = 89;
            TRANSITION[88][117] = 89;
            TRANSITION[89] = copy(ai4);
            TRANSITION[89][80] = 90;
            TRANSITION[89][112] = 90;
            TRANSITION[90] = copy(ai4);
            TRANSITION[90][68] = 91;
            TRANSITION[90][100] = 91;
            TRANSITION[91] = copy(ai4);
            TRANSITION[91][65] = 92;
            TRANSITION[91][97] = 92;
            TRANSITION[92] = copy(ai4);
            TRANSITION[92][84] = 93;
            TRANSITION[92][116] = 93;
            TRANSITION[93] = copy(ai4);
            TRANSITION[93][69] = 94;
            TRANSITION[93][101] = 94;
            TRANSITION[94] = ai4;
            TRANSITION[153] = copy(ai4);
            TRANSITION[153][69] = 154;
            TRANSITION[153][101] = 154;
            TRANSITION[154] = copy(ai4);
            TRANSITION[154][84] = 155;
            TRANSITION[154][116] = 155;
            TRANSITION[155] = copy(ai4);
            TRANSITION[155][85] = 156;
            TRANSITION[155][117] = 156;
            TRANSITION[156] = copy(ai4);
            TRANSITION[156][82] = 157;
            TRANSITION[156][114] = 157;
            TRANSITION[157] = copy(ai4);
            TRANSITION[157][78] = 158;
            TRANSITION[157][110] = 158;
            TRANSITION[158] = copy(ai4);
            TRANSITION[158][73] = 159;
            TRANSITION[158][105] = 159;
            TRANSITION[159] = copy(ai4);
            TRANSITION[159][78] = 160;
            TRANSITION[159][110] = 160;
            TRANSITION[160] = copy(ai4);
            TRANSITION[160][71] = 161;
            TRANSITION[160][103] = 161;
            TRANSITION[161] = ai4;
            TRANSITION[162] = copy(ai4);
            TRANSITION[162][78] = 163;
            TRANSITION[162][110] = 163;
            TRANSITION[163] = copy(ai4);
            TRANSITION[163][84] = 164;
            TRANSITION[163][116] = 164;
            TRANSITION[164] = copy(ai4);
            TRANSITION[164][79] = 165;
            TRANSITION[164][111] = 165;
            TRANSITION[165] = copy(ai4);
            TRANSITION[102] = copy(ai3);
            TRANSITION[102][39] = 103;
            TRANSITION[103] = newArray(128, 103);
            TRANSITION[103][39] = 104;
            TRANSITION[104] = newArray(128, 57);
            TRANSITION[104][39] = 103;
            TRANSITION[110] = copy(ai4);
            TRANSITION[110][39] = 111;
            TRANSITION[111] = newArray(128, 112);
            TRANSITION[112] = newArray(128, 112);
            TRANSITION[113] = newArray(128, 114);
            TRANSITION[114] = newArray(128, 112);
            TRANSITION[114][39] = 57;
            TRANSITION[115] = ai5;
            TRANSITION[116] = ai4;
            TRANSITION[117] = copy(ai4);
            TRANSITION[117][97] = 118;
            TRANSITION[117][65] = 118;
            TRANSITION[118] = copy(ai4);
            TRANSITION[118][108] = 119;
            TRANSITION[118][76] = 119;
            TRANSITION[119] = copy(ai4);
            TRANSITION[119][108] = 120;
            TRANSITION[119][76] = 120;
            TRANSITION[120] = ai4;
            TRANSITION[121] = copy(ai4);
            TRANSITION[121][115] = 122;
            TRANSITION[121][83] = 122;
            TRANSITION[122] = ai4;
            TRANSITION[123] = ai4;
            TRANSITION[124] = copy(ai4);
            TRANSITION[124][115] = 125;
            TRANSITION[124][83] = 125;
            TRANSITION[125] = copy(ai4);
            TRANSITION[125][99] = 126;
            TRANSITION[125][67] = 126;
            TRANSITION[126] = copy(ai4);
            TRANSITION[126][97] = 127;
            TRANSITION[126][65] = 127;
            TRANSITION[127] = copy(ai4);
            TRANSITION[127][112] = 128;
            TRANSITION[127][80] = 128;
            TRANSITION[128] = copy(ai4);
            TRANSITION[128][101] = 129;
            TRANSITION[128][69] = 129;
            TRANSITION[129] = ai4;
            TRANSITION[130] = copy(ai4);
            TRANSITION[130][110] = 131;
            TRANSITION[130][78] = 131;
            TRANSITION[131] = ai4;
            TRANSITION[132] = copy(ai4);
            TRANSITION[132][106] = 133;
            TRANSITION[132][74] = 133;
            TRANSITION[133] = ai4;
            TRANSITION[135] = copy(ai1);
            TRANSITION[135][76] = 136;
            TRANSITION[135][108] = 136;
            TRANSITION[136] = copy(ai1);
            TRANSITION[136][84] = 137;
            TRANSITION[136][116] = 137;
            TRANSITION[137] = copy(ai1);
            TRANSITION[137][69] = 138;
            TRANSITION[137][101] = 138;
            TRANSITION[138] = copy(ai1);
            TRANSITION[138][82] = 139;
            TRANSITION[138][114] = 139;
            TRANSITION[139] = copyReplacing(ai3, 57, 140);
            TRANSITION[139][47] = 148;
            TRANSITION[139][45] = 151;
            TRANSITION[140] = copyReplacing(ai3, 57, 140);
            TRANSITION[140][47] = 148;
            TRANSITION[148] = copy(ai4);
            TRANSITION[148][42] = 149;
            TRANSITION[149] = newArray(128, 149);
            TRANSITION[149][42] = 150;
            TRANSITION[150] = newArray(128, 149);
            TRANSITION[150][47] = 140;
            TRANSITION[140][45] = 151;
            TRANSITION[151] = copy(ai4);
            TRANSITION[151][45] = 152;
            TRANSITION[152] = newArray(128, 152);
            TRANSITION[152][10] = 140;
            TRANSITION[140][83] = 141;
            TRANSITION[140][115] = 141;
            TRANSITION[141] = copy(ai1);
            TRANSITION[141][69] = 142;
            TRANSITION[141][101] = 142;
            TRANSITION[142] = copy(ai1);
            TRANSITION[142][83] = 143;
            TRANSITION[142][115] = 143;
            TRANSITION[143] = copy(ai1);
            TRANSITION[143][83] = 144;
            TRANSITION[143][115] = 144;
            TRANSITION[144] = copy(ai1);
            TRANSITION[144][73] = 145;
            TRANSITION[144][105] = 145;
            TRANSITION[145] = copy(ai1);
            TRANSITION[145][79] = 146;
            TRANSITION[145][111] = 146;
            TRANSITION[146] = copy(ai1);
            TRANSITION[146][78] = 147;
            TRANSITION[146][110] = 147;
            TRANSITION[147] = ai4;
            Object aobj[] = newArray(128, 0);
            Object aobj1[] = copy(((int []) (aobj)));
            aobj1[63] = 14;
            Object aobj2[] = copy(((int []) (aobj1)));
            aobj2[123] = 5;
            Object aobj3[] = new int[128];
            for(int i = 0; i < aobj3.length; i++)
                if(TRANSITION[8][i] == 8)
                    aobj3[i] = 15;
                else
                    aobj3[i] = 16;

            Object aobj4[] = new int[128];
            for(int j = 0; j < aobj4.length; j++)
                if(TRANSITION[65][j] == 65)
                    aobj4[j] = 15;
                else
                    aobj4[j] = 16;

            Object aobj5[] = copy(((int []) (aobj4)));
            aobj5[32] = 0;
            aobj5[10] = 0;
            aobj5[9] = 0;
            aobj5[13] = 0;
            Object aobj6[] = copy(((int []) (aobj)));
            for(int k = 0; k < aobj6.length; k++)
                if(ai3[k] != 66)
                    aobj6[k] = 5;

            Object aobj7[] = copyReplacing(((int []) (aobj6)), 5, 6);
            Object aobj8[] = copyReplacing(((int []) (aobj6)), 5, 1);
            int ai6[] = copyReplacing(((int []) (aobj6)), 5, 2);
            int ai7[] = copyReplacing(((int []) (aobj6)), 5, 3);
            int ai8[] = copyReplacing(((int []) (aobj6)), 5, 4);
            int ai9[] = copyReplacing(((int []) (aobj6)), 5, 7);
            int ai10[] = copyReplacing(((int []) (aobj6)), 5, 8);
            ai10[123] = 6;
            int ai11[] = copyReplacing(((int []) (aobj6)), 5, 10);
            for(int j1 = 0; j1 < ai11.length; j1++)
                if(ai11[j1] == 8)
                    ai11[j1] = 0;

            int ai12[] = copyReplacing(ai11, 10, 11);
            int ai13[] = copyReplacing(ai11, 10, 9);
            int ai14[] = copyReplacing(ai11, 10, 12);
            int ai15[] = copyReplacing(ai11, 10, 13);
            int ai16[] = copyReplacing(ai11, 10, 21);
            int ai17[] = copyReplacing(ai11, 10, 22);
            int ai18[] = copyReplacing(ai11, 10, 23);
            int ai19[] = copy(((int []) (aobj)));
            ai19[39] = 17;
            int ai20[] = copyReplacing(((int []) (aobj)), 0, 18);
            ai20[39] = 0;
            int ai21[] = copyReplacing(((int []) (aobj)), 0, 19);
            int ai22[] = copyReplacing(((int []) (aobj)), 0, 20);
            int ai23[] = copy(ai22);
            ai23[39] = 0;
            ACTION[0] = ((int []) (aobj2));
            ACTION[1] = ((int []) (aobj2));
            ACTION[2] = ((int []) (aobj2));
            ACTION[3] = ((int []) (aobj));
            ACTION[4] = ((int []) (aobj));
            ACTION[5] = ((int []) (aobj));
            ACTION[6] = ((int []) (aobj));
            ACTION[7] = ((int []) (aobj));
            ACTION[8] = ((int []) (aobj3));
            ACTION[134] = ((int []) (aobj5));
            ACTION[100] = ai19;
            ACTION[101] = ai20;
            ACTION[105] = ((int []) (aobj));
            ACTION[106] = ai21;
            ACTION[107] = ai22;
            ACTION[108] = null;
            ACTION[109] = ai23;
            ACTION[9] = ai10;
            ACTION[10] = ai10;
            ACTION[11] = ai10;
            ACTION[12] = ai10;
            ACTION[13] = ai10;
            ACTION[14] = ((int []) (aobj6));
            ACTION[15] = ai10;
            ACTION[16] = ai10;
            ACTION[17] = ai10;
            ACTION[18] = ((int []) (aobj7));
            ACTION[19] = ai10;
            ACTION[20] = ai10;
            ACTION[21] = ai10;
            ACTION[22] = ai10;
            ACTION[23] = ai10;
            ACTION[24] = ai10;
            ACTION[25] = ((int []) (aobj6));
            ACTION[26] = ai10;
            ACTION[27] = ai10;
            ACTION[28] = ai10;
            ACTION[29] = ((int []) (aobj8));
            ACTION[30] = ai10;
            ACTION[31] = ai10;
            ACTION[32] = ai10;
            ACTION[33] = ai10;
            ACTION[34] = ai10;
            ACTION[35] = ai6;
            ACTION[36] = ai10;
            ACTION[37] = ai10;
            ACTION[38] = ai10;
            ACTION[39] = ai10;
            ACTION[40] = ai10;
            ACTION[41] = ai9;
            ACTION[42] = ai10;
            ACTION[43] = ai10;
            ACTION[44] = ai10;
            ACTION[45] = ai10;
            ACTION[46] = ai10;
            ACTION[47] = ai8;
            ACTION[48] = ai10;
            ACTION[49] = ai10;
            ACTION[50] = ai10;
            ACTION[51] = ai10;
            ACTION[52] = ai7;
            ACTION[53] = ai10;
            ACTION[54] = ai10;
            ACTION[55] = ai10;
            ACTION[56] = ai9;
            ACTION[66] = ((int []) (aobj1));
            ACTION[58] = ((int []) (aobj1));
            ACTION[59] = ((int []) (aobj1));
            ACTION[60] = ((int []) (aobj));
            ACTION[61] = ((int []) (aobj));
            ACTION[62] = ((int []) (aobj));
            ACTION[63] = ((int []) (aobj));
            ACTION[64] = ((int []) (aobj));
            ACTION[65] = ((int []) (aobj4));
            ACTION[102] = ai19;
            ACTION[103] = ((int []) (aobj));
            ACTION[104] = ai20;
            ACTION[110] = ((int []) (aobj));
            ACTION[111] = ai21;
            ACTION[112] = ai22;
            ACTION[113] = null;
            ACTION[114] = ai23;
            ACTION[57] = ((int []) (aobj1));
            ACTION[67] = ((int []) (aobj));
            ACTION[68] = ((int []) (aobj));
            ACTION[69] = ((int []) (aobj));
            ACTION[70] = ((int []) (aobj));
            ACTION[71] = ai13;
            ACTION[72] = ((int []) (aobj));
            ACTION[73] = ((int []) (aobj));
            ACTION[74] = ((int []) (aobj));
            ACTION[75] = ((int []) (aobj));
            ACTION[76] = ai11;
            ACTION[77] = ((int []) (aobj));
            ACTION[78] = ((int []) (aobj));
            ACTION[79] = ai12;
            ACTION[80] = ((int []) (aobj));
            ACTION[81] = ((int []) (aobj));
            ACTION[82] = ((int []) (aobj));
            ACTION[83] = ((int []) (aobj));
            ACTION[84] = ((int []) (aobj));
            ACTION[85] = ((int []) (aobj));
            ACTION[86] = ((int []) (aobj));
            ACTION[87] = ai14;
            ACTION[88] = ((int []) (aobj1));
            ACTION[89] = ((int []) (aobj));
            ACTION[90] = ((int []) (aobj));
            ACTION[91] = ((int []) (aobj));
            ACTION[92] = ((int []) (aobj));
            ACTION[93] = ((int []) (aobj));
            ACTION[94] = ai15;
            ACTION[95] = ((int []) (aobj));
            ACTION[96] = ((int []) (aobj));
            ACTION[97] = ((int []) (aobj));
            ACTION[98] = ((int []) (aobj));
            ACTION[99] = ((int []) (aobj));
            ACTION[115] = copy(((int []) (aobj)));
            ACTION[115][63] = 14;
            ACTION[116] = ((int []) (aobj));
            ACTION[117] = ((int []) (aobj));
            ACTION[118] = ((int []) (aobj));
            ACTION[119] = ((int []) (aobj));
            ACTION[120] = ((int []) (aobj));
            ACTION[121] = ((int []) (aobj));
            ACTION[122] = ((int []) (aobj));
            ACTION[123] = ((int []) (aobj));
            ACTION[124] = ((int []) (aobj));
            ACTION[125] = ((int []) (aobj));
            ACTION[126] = ((int []) (aobj));
            ACTION[127] = ((int []) (aobj));
            ACTION[128] = ((int []) (aobj));
            ACTION[129] = ((int []) (aobj));
            ACTION[130] = ((int []) (aobj));
            ACTION[131] = ((int []) (aobj));
            ACTION[132] = ((int []) (aobj));
            ACTION[133] = ((int []) (aobj));
            ACTION[135] = ((int []) (aobj));
            ACTION[136] = ((int []) (aobj));
            ACTION[137] = ((int []) (aobj));
            ACTION[138] = ((int []) (aobj));
            ACTION[139] = ai10;
            ACTION[140] = ((int []) (aobj1));
            ACTION[141] = ((int []) (aobj));
            ACTION[142] = ((int []) (aobj));
            ACTION[143] = ((int []) (aobj));
            ACTION[144] = ((int []) (aobj));
            ACTION[145] = ((int []) (aobj));
            ACTION[146] = ((int []) (aobj));
            ACTION[147] = ai16;
            ACTION[148] = ((int []) (aobj));
            ACTION[149] = ((int []) (aobj));
            ACTION[150] = ((int []) (aobj));
            ACTION[151] = ((int []) (aobj));
            ACTION[152] = ((int []) (aobj));
            ACTION[153] = ((int []) (aobj));
            ACTION[154] = ((int []) (aobj));
            ACTION[155] = ((int []) (aobj));
            ACTION[156] = ((int []) (aobj));
            ACTION[157] = ((int []) (aobj));
            ACTION[158] = ((int []) (aobj));
            ACTION[159] = ((int []) (aobj));
            ACTION[160] = ((int []) (aobj));
            ACTION[161] = ai17;
            ACTION[162] = ((int []) (aobj));
            ACTION[163] = ((int []) (aobj));
            ACTION[164] = ((int []) (aobj));
            ACTION[165] = ai18;
            aobj = newArray(128, ODBCAction.NONE);
            aobj1 = newArray(128, ODBCAction.COPY);
            aobj2 = copy(((ODBCAction []) (aobj1)));
            aobj2[123] = ODBCAction.NONE;
            aobj2[63] = ODBCAction.QUESTION;
            aobj2[125] = ODBCAction.END_ODBC_ESCAPE;
            aobj2[44] = ODBCAction.COMMA;
            aobj2[40] = ODBCAction.OPEN_PAREN;
            aobj2[41] = ODBCAction.CLOSE_PAREN;
            aobj3 = copyReplacing(((ODBCAction []) (aobj1)), ODBCAction.COPY, ODBCAction.SAVE_DELIMITER);
            aobj4 = copyReplacing(((ODBCAction []) (aobj1)), ODBCAction.COPY, ODBCAction.LOOK_FOR_DELIMITER);
            aobj5 = copy(((ODBCAction []) (aobj4)));
            aobj5[39] = ODBCAction.COPY;
            aobj6 = newArray(128, ODBCAction.UNKNOWN_ESCAPE);
            aobj7 = copy(((ODBCAction []) (aobj)));
            for(int l = 0; l < ai.length; l++)
                if(ai[l] == 9)
                    aobj7[l] = ODBCAction.UNKNOWN_ESCAPE;

            l = copy(((ODBCAction []) (aobj2)));
            for(int i1 = 0; i1 < ai.length; i1++)
                if(ai[i1] != 9)
                    l[i1] = ODBCAction.BEGIN;

            ODBC_ACTION[0] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[1] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[2] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[3] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[4] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[5] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[6] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[7] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[8] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[134] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[100] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[101] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[105] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[106] = ((ODBCAction []) (aobj3));
            ODBC_ACTION[107] = ((ODBCAction []) (aobj4));
            ODBC_ACTION[108] = null;
            ODBC_ACTION[109] = ((ODBCAction []) (aobj5));
            ODBC_ACTION[9] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[10] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[11] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[12] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[13] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[14] = l;
            ODBC_ACTION[15] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[16] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[17] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[18] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[19] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[20] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[21] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[22] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[23] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[24] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[25] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[26] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[27] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[28] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[29] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[30] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[31] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[32] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[33] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[34] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[35] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[36] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[37] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[38] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[39] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[40] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[41] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[42] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[43] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[44] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[45] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[46] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[47] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[48] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[49] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[50] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[51] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[52] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[53] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[54] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[55] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[56] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[66] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[58] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[59] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[60] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[61] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[62] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[63] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[64] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[65] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[102] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[103] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[104] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[110] = ((ODBCAction []) (aobj1));
            ODBC_ACTION[111] = ((ODBCAction []) (aobj3));
            ODBC_ACTION[112] = ((ODBCAction []) (aobj4));
            ODBC_ACTION[113] = null;
            ODBC_ACTION[114] = ((ODBCAction []) (aobj5));
            ODBC_ACTION[57] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[67] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[68] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[69] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[70] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[71] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[72] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[73] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[74] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[75] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[76] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[77] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[78] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[79] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[80] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[81] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[82] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[83] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[84] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[85] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[86] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[87] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[88] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[89] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[90] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[91] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[92] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[93] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[94] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[95] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[96] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[97] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[98] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[99] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[115] = copy(((ODBCAction []) (aobj7)));
            ODBC_ACTION[115][63] = ODBCAction.NONE;
            ODBC_ACTION[115][99] = ODBCAction.NONE;
            ODBC_ACTION[115][67] = ODBCAction.NONE;
            ODBC_ACTION[115][116] = ODBCAction.NONE;
            ODBC_ACTION[115][84] = ODBCAction.NONE;
            ODBC_ACTION[115][100] = ODBCAction.NONE;
            ODBC_ACTION[115][68] = ODBCAction.NONE;
            ODBC_ACTION[115][101] = ODBCAction.NONE;
            ODBC_ACTION[115][69] = ODBCAction.NONE;
            ODBC_ACTION[115][102] = ODBCAction.NONE;
            ODBC_ACTION[115][70] = ODBCAction.NONE;
            ODBC_ACTION[115][111] = ODBCAction.NONE;
            ODBC_ACTION[115][79] = ODBCAction.NONE;
            ODBC_ACTION[116] = newArray(128, ODBCAction.FUNCTION);
            ODBC_ACTION[117] = copy(((ODBCAction []) (aobj6)));
            ODBC_ACTION[117][97] = ODBCAction.NONE;
            ODBC_ACTION[117][65] = ODBCAction.NONE;
            ODBC_ACTION[118] = copy(((ODBCAction []) (aobj6)));
            ODBC_ACTION[118][108] = ODBCAction.NONE;
            ODBC_ACTION[118][76] = ODBCAction.NONE;
            ODBC_ACTION[119] = copy(((ODBCAction []) (aobj6)));
            ODBC_ACTION[119][108] = ODBCAction.NONE;
            ODBC_ACTION[119][76] = ODBCAction.NONE;
            ODBC_ACTION[120] = copyReplacing(((ODBCAction []) (aobj7)), ODBCAction.NONE, ODBCAction.CALL);
            ODBC_ACTION[121] = copyReplacing(((ODBCAction []) (aobj7)), ODBCAction.NONE, ODBCAction.TIME);
            ODBC_ACTION[121][115] = ODBCAction.NONE;
            ODBC_ACTION[121][83] = ODBCAction.NONE;
            ODBC_ACTION[122] = copyReplacing(((ODBCAction []) (aobj7)), ODBCAction.NONE, ODBCAction.TIMESTAMP);
            ODBC_ACTION[123] = copyReplacing(((ODBCAction []) (aobj7)), ODBCAction.NONE, ODBCAction.DATE);
            ODBC_ACTION[124] = copy(((ODBCAction []) (aobj6)));
            ODBC_ACTION[124][115] = ODBCAction.NONE;
            ODBC_ACTION[124][83] = ODBCAction.NONE;
            ODBC_ACTION[125] = copy(((ODBCAction []) (aobj6)));
            ODBC_ACTION[125][99] = ODBCAction.NONE;
            ODBC_ACTION[125][67] = ODBCAction.NONE;
            ODBC_ACTION[126] = copy(((ODBCAction []) (aobj6)));
            ODBC_ACTION[126][97] = ODBCAction.NONE;
            ODBC_ACTION[126][65] = ODBCAction.NONE;
            ODBC_ACTION[127] = copy(((ODBCAction []) (aobj6)));
            ODBC_ACTION[127][112] = ODBCAction.NONE;
            ODBC_ACTION[127][80] = ODBCAction.NONE;
            ODBC_ACTION[128] = copy(((ODBCAction []) (aobj6)));
            ODBC_ACTION[128][101] = ODBCAction.NONE;
            ODBC_ACTION[128][69] = ODBCAction.NONE;
            ODBC_ACTION[129] = copyReplacing(((ODBCAction []) (aobj7)), ODBCAction.NONE, ODBCAction.ESCAPE);
            ODBC_ACTION[130] = copy(((ODBCAction []) (aobj6)));
            ODBC_ACTION[130][110] = ODBCAction.NONE;
            ODBC_ACTION[130][78] = ODBCAction.NONE;
            ODBC_ACTION[131] = copyReplacing(((ODBCAction []) (aobj7)), ODBCAction.NONE, ODBCAction.SCALAR_FUNCTION);
            ODBC_ACTION[132] = copy(((ODBCAction []) (aobj6)));
            ODBC_ACTION[132][106] = ODBCAction.NONE;
            ODBC_ACTION[132][74] = ODBCAction.NONE;
            ODBC_ACTION[133] = copyReplacing(((ODBCAction []) (aobj7)), ODBCAction.NONE, ODBCAction.OUTER_JOIN);
            ODBC_ACTION[135] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[136] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[137] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[138] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[139] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[140] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[141] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[142] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[143] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[144] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[145] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[146] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[147] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[148] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[149] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[150] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[151] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[152] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[153] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[154] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[155] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[156] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[157] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[158] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[159] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[160] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[161] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[162] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[163] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[164] = ((ODBCAction []) (aobj2));
            ODBC_ACTION[165] = ((ODBCAction []) (aobj2));
        }
        catch(Throwable throwable)
        {
            throwable.printStackTrace();
        }
    }
}
