// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleResultSetCacheImpl.java

package oracle.jdbc.driver;

import java.util.Vector;

// Referenced classes of package oracle.jdbc.driver:
//            OracleResultSetCache

class OracleResultSetCacheImpl
    implements OracleResultSetCache
{

    private static int DEFAULT_WIDTH = 5;
    private static int DEFAULT_SIZE = 5;
    Vector cachedRows;
    int nbOfColumnsInRow;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleResultSetCacheImpl()
    {
        this(DEFAULT_WIDTH);
    }

    OracleResultSetCacheImpl(int i)
    {
        cachedRows = null;
        if(i > 0)
            nbOfColumnsInRow = i;
        cachedRows = new Vector(DEFAULT_SIZE);
    }

    public void put(int i, int j, Object obj)
    {
        Vector vector = null;
        for(; cachedRows.size() < i; cachedRows.addElement(vector))
            vector = new Vector(nbOfColumnsInRow);

        for(vector = (Vector)cachedRows.elementAt(i - 1); vector.size() < j; vector.addElement(null));
        vector.setElementAt(obj, j - 1);
    }

    public Object get(int i, int j)
    {
        Vector vector = (Vector)cachedRows.elementAt(i - 1);
        return vector.elementAt(j - 1);
    }

    public void remove(int i)
    {
        cachedRows.removeElementAt(i - 1);
    }

    public void remove(int i, int j)
    {
        cachedRows.removeElementAt(i - 1);
    }

    public void clear()
    {
    }

    public void close()
    {
    }

    public int getLength()
    {
        return 0;
    }

}
