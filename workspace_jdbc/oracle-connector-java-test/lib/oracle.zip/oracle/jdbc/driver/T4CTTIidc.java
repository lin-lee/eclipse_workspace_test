// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIidc.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, T4CTTIkscn, T4CTTIqcinv, T4CMAREngine, 
//            T4CConnection

class T4CTTIidc extends T4CTTIMsg
{

    T4CTTIkscn kpdqidcscn;
    T4CTTIqcinv kpdqidccinv[];
    T4CTTIqcinv kpdqidcusr[];
    long kpdqidcflg;

    T4CTTIidc(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)0);
    }

    void unmarshal()
        throws SQLException, IOException
    {
        kpdqidcscn = new T4CTTIkscn(connection);
        kpdqidcscn.unmarshal();
        int i = meg.unmarshalSWORD();
        byte byte0 = (byte)meg.unmarshalUB1();
        if(i > 0)
        {
            kpdqidccinv = new T4CTTIqcinv[i];
            for(int j = 0; j < i; j++)
            {
                kpdqidccinv[j] = new T4CTTIqcinv(connection);
                kpdqidccinv[j].unmarshal();
            }

        } else
        {
            kpdqidccinv = null;
        }
        int k = meg.unmarshalSWORD();
        if(k > 0)
        {
            kpdqidcusr = new T4CTTIqcinv[k];
            for(int l = 0; l < k; l++)
            {
                kpdqidcusr[l] = new T4CTTIqcinv(connection);
                kpdqidcusr[l].unmarshal();
            }

        } else
        {
            kpdqidcusr = null;
        }
        kpdqidcflg = meg.unmarshalUB4();
    }
}
