// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   SQLUtil.java

package oracle.jdbc.driver;

import java.math.BigDecimal;
import java.sql.*;
import java.util.Hashtable;
import java.util.Map;
import oracle.jdbc.OracleData;
import oracle.jdbc.OracleDataFactory;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oracore.*;
import oracle.sql.*;
import oracle.sql.converter.CharacterSetMetaData;

// Referenced classes of package oracle.jdbc.driver:
//            DatabaseError, ClassRef

public class SQLUtil
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;
    private static final int CLASS_NOT_FOUND = -1;
    private static final int CLASS_STRING = 0;
    private static final int CLASS_BOOLEAN = 1;
    private static final int CLASS_INTEGER = 2;
    private static final int CLASS_LONG = 3;
    private static final int CLASS_FLOAT = 4;
    private static final int CLASS_DOUBLE = 5;
    private static final int CLASS_BIGDECIMAL = 6;
    private static final int CLASS_DATE = 7;
    private static final int CLASS_TIME = 8;
    private static final int CLASS_TIMESTAMP = 9;
    private static final int TOTAL_CLASSES = 10;
    private static Hashtable classTable;

    public SQLUtil()
    {
    }

    public static Object SQLToJava(OracleConnection oracleconnection, byte abyte0[], int i, String s, Class class1, Map map)
        throws SQLException
    {
        Datum datum = makeDatum(oracleconnection, abyte0, i, s, 0);
        Object obj = SQLToJava(oracleconnection, datum, class1, map);
        return obj;
    }

    public static CustomDatum SQLToJava(OracleConnection oracleconnection, byte abyte0[], int i, String s, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        Datum datum = makeDatum(oracleconnection, abyte0, i, s, 0);
        CustomDatum customdatum = customdatumfactory.create(datum, i);
        return customdatum;
    }

    public static ORAData SQLToJava(OracleConnection oracleconnection, byte abyte0[], int i, String s, ORADataFactory oradatafactory)
        throws SQLException
    {
        Datum datum = makeDatum(oracleconnection, abyte0, i, s, 0);
        ORAData oradata = oradatafactory.create(datum, i);
        return oradata;
    }

    public static OracleData SQLToJava(OracleConnection oracleconnection, byte abyte0[], int i, String s, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        Datum datum = makeDatum(oracleconnection, abyte0, i, s, 0);
        OracleData oracledata = oracledatafactory.create(datum.toJdbc(), i);
        return oracledata;
    }

    public static Object SQLToJava(OracleConnection oracleconnection, Datum datum, Class class1, Map map)
        throws SQLException
    {
        Object obj = null;
        if(datum instanceof STRUCT)
        {
            if(class1 == null)
                obj = map == null ? datum.toJdbc() : ((STRUCT)datum).toJdbc(map);
            else
                obj = map == null ? ((STRUCT)datum).toClass(class1) : ((STRUCT)datum).toClass(class1, map);
        } else
        if(class1 == null)
        {
            obj = datum.toJdbc();
        } else
        {
            int i = classNumber(class1);
            switch(i)
            {
            case 0: // '\0'
                obj = datum.stringValue();
                break;

            case 1: // '\001'
                obj = Boolean.valueOf(datum.longValue() != 0L);
                break;

            case 2: // '\002'
                obj = Integer.valueOf((int)datum.longValue());
                break;

            case 3: // '\003'
                obj = Long.valueOf(datum.longValue());
                break;

            case 4: // '\004'
                obj = Float.valueOf(datum.bigDecimalValue().floatValue());
                break;

            case 5: // '\005'
                obj = Double.valueOf(datum.bigDecimalValue().doubleValue());
                break;

            case 6: // '\006'
                obj = datum.bigDecimalValue();
                break;

            case 7: // '\007'
                obj = datum.dateValue();
                break;

            case 8: // '\b'
                obj = datum.timeValue();
                break;

            case 9: // '\t'
                obj = datum.timestampValue();
                break;

            case -1: 
            default:
                obj = datum.toJdbc();
                if(!class1.isInstance(obj))
                {
                    SQLException sqlexception = DatabaseError.createSqlException(null, 59, "invalid data conversion");
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                break;
            }
        }
        return obj;
    }

    public static byte[] JavaToSQL(OracleConnection oracleconnection, Object obj, int i, String s)
        throws SQLException
    {
        if(obj == null)
            return null;
        Object obj1 = null;
        if(obj instanceof Datum)
            obj1 = (Datum)obj;
        else
        if(obj instanceof ORAData)
            obj1 = ((ORAData)obj).toDatum(oracleconnection);
        else
        if(obj instanceof CustomDatum)
            obj1 = oracleconnection.toDatum((CustomDatum)obj);
        else
        if(obj instanceof SQLData)
            obj1 = STRUCT.toSTRUCT(obj, oracleconnection);
        if(obj1 != null)
        {
            if(!checkDatumType(((Datum) (obj1)), i, s))
                obj1 = null;
        } else
        {
            obj1 = makeDatum(oracleconnection, obj, i, s);
        }
        byte abyte0[] = null;
        if(obj1 != null)
        {
            if(obj1 instanceof STRUCT)
                abyte0 = ((STRUCT)obj1).toBytes();
            else
            if(obj1 instanceof ARRAY)
                abyte0 = ((ARRAY)obj1).toBytes();
            else
            if(obj1 instanceof OPAQUE)
                abyte0 = ((OPAQUE)obj1).toBytes();
            else
                abyte0 = ((Datum) (obj1)).shareBytes();
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, 1, "attempt to convert a Datum to incompatible SQL type");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return abyte0;
    }

    public static Datum makeDatum(OracleConnection oracleconnection, byte abyte0[], int i, String s, int j)
        throws SQLException
    {
        Object obj = null;
        short word0 = oracleconnection.getDbCsId();
        short word1 = oracleconnection.getJdbcCsId();
        int k = CharacterSetMetaData.getRatio(word1, word0);
        switch(i)
        {
        case 96: // '`'
            if(j != 0 && j < abyte0.length && k == 1)
                obj = new CHAR(abyte0, 0, j, CharacterSet.make(oracleconnection.getJdbcCsId()));
            else
                obj = new CHAR(abyte0, CharacterSet.make(oracleconnection.getJdbcCsId()));
            break;

        case 1: // '\001'
        case 8: // '\b'
            obj = new CHAR(abyte0, CharacterSet.make(oracleconnection.getJdbcCsId()));
            break;

        case 2: // '\002'
        case 6: // '\006'
            obj = new NUMBER(abyte0);
            break;

        case 100: // 'd'
            obj = new BINARY_FLOAT(abyte0);
            break;

        case 101: // 'e'
            obj = new BINARY_DOUBLE(abyte0);
            break;

        case 23: // '\027'
        case 24: // '\030'
            obj = new RAW(abyte0);
            break;

        case 104: // 'h'
            obj = new ROWID(abyte0);
            break;

        case 102: // 'f'
            SQLException sqlexception = DatabaseError.createSqlException(null, 1, "need resolution: do we want to handle ResultSet?");
            sqlexception.fillInStackTrace();
            throw sqlexception;

        case 12: // '\f'
            obj = new DATE(abyte0);
            break;

        case 182: 
            obj = new INTERVALYM(abyte0);
            break;

        case 183: 
            obj = new INTERVALDS(abyte0);
            break;

        case 180: 
            obj = new TIMESTAMP(abyte0);
            break;

        case 181: 
            obj = new TIMESTAMPTZ(abyte0);
            break;

        case 231: 
            obj = new TIMESTAMPLTZ(abyte0);
            break;

        case 113: // 'q'
            obj = oracleconnection.createBlob(abyte0);
            break;

        case 112: // 'p'
            obj = oracleconnection.createClob(abyte0);
            break;

        case 114: // 'r'
            obj = oracleconnection.createBfile(abyte0);
            break;

        case 109: // 'm'
            TypeDescriptor typedescriptor = TypeDescriptor.getTypeDescriptor(s, oracleconnection, abyte0, 0L);
            switch(typedescriptor.getTypeCode())
            {
            case 2002: 
                obj = new STRUCT((StructDescriptor)typedescriptor, abyte0, oracleconnection);
                break;

            case 2008: 
                obj = new JAVA_STRUCT((StructDescriptor)typedescriptor, abyte0, oracleconnection);
                break;

            case 2003: 
                obj = new ARRAY((ArrayDescriptor)typedescriptor, abyte0, oracleconnection);
                break;

            case 2009: 
                obj = ClassRef.XMLTYPE.createXML(new OPAQUE((OpaqueDescriptor)typedescriptor, abyte0, oracleconnection));
                break;

            case 2007: 
                obj = new OPAQUE((OpaqueDescriptor)typedescriptor, abyte0, oracleconnection);
                break;
            }
            break;

        case 111: // 'o'
            Object obj1 = getTypeDescriptor(s, oracleconnection);
            if(obj1 instanceof StructDescriptor)
            {
                obj = new REF((StructDescriptor)obj1, oracleconnection, abyte0);
            } else
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(null, 1, "program error: REF points to a non-STRUCT");
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
            break;

        default:
            SQLException sqlexception1 = DatabaseError.createSqlException(null, 1, "program error: invalid SQL type code");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        return ((Datum) (obj));
    }

    public static Datum makeNDatum(OracleConnection oracleconnection, byte abyte0[], int i, String s, short word0, int j)
        throws SQLException
    {
        Object obj = null;
        switch(i)
        {
        case 96: // '`'
            int k = j * CharacterSetMetaData.getRatio(oracleconnection.getNCharSet(), 1);
            if(j != 0 && k < abyte0.length)
                obj = new CHAR(abyte0, 0, j, CharacterSet.make(oracleconnection.getNCharSet()));
            else
                obj = new CHAR(abyte0, CharacterSet.make(oracleconnection.getNCharSet()));
            break;

        case 1: // '\001'
        case 8: // '\b'
            obj = new CHAR(abyte0, CharacterSet.make(oracleconnection.getNCharSet()));
            break;

        case 112: // 'p'
            obj = oracleconnection.createClob(abyte0, word0);
            break;

        default:
            SQLException sqlexception = DatabaseError.createSqlException(null, 1, "program error: invalid SQL type code");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return ((Datum) (obj));
    }

    public static Datum makeDatum(OracleConnection oracleconnection, Object obj, int i, String s)
        throws SQLException
    {
        return makeDatum(oracleconnection, obj, i, s, false);
    }

    public static Datum makeDatum(OracleConnection oracleconnection, Object obj, int i, String s, boolean flag)
        throws SQLException
    {
        Object obj1 = null;
        switch(i)
        {
        case 1: // '\001'
        case 8: // '\b'
        case 96: // '`'
            obj1 = new CHAR(obj, CharacterSet.make(flag ? ((int) (oracleconnection.getNCharSet())) : ((int) (oracleconnection.getJdbcCsId()))));
            break;

        case 2: // '\002'
        case 6: // '\006'
            obj1 = new NUMBER(obj);
            break;

        case 100: // 'd'
            if(obj instanceof String)
                obj1 = new BINARY_FLOAT((String)obj);
            else
            if(obj instanceof Boolean)
                obj1 = new BINARY_FLOAT((Boolean)obj);
            else
                obj1 = new BINARY_FLOAT((Float)obj);
            break;

        case 101: // 'e'
            if(obj instanceof String)
                obj1 = new BINARY_DOUBLE((String)obj);
            else
            if(obj instanceof Boolean)
                obj1 = new BINARY_DOUBLE((Boolean)obj);
            else
                obj1 = new BINARY_DOUBLE((Double)obj);
            break;

        case 23: // '\027'
        case 24: // '\030'
            obj1 = new RAW(obj);
            break;

        case 104: // 'h'
            if(obj instanceof String)
                obj1 = new ROWID((String)obj);
            else
            if(obj instanceof byte[])
                obj1 = new ROWID((byte[])(byte[])obj);
            break;

        case 102: // 'f'
            SQLException sqlexception = DatabaseError.createSqlException(null, 1, "need resolution: do we want to handle ResultSet");
            sqlexception.fillInStackTrace();
            throw sqlexception;

        case 12: // '\f'
            obj1 = new DATE(obj);
            break;

        case 180: 
            if(obj instanceof TIMESTAMP)
                obj1 = (Datum)obj;
            else
            if(obj instanceof Timestamp)
                obj1 = new TIMESTAMP((Timestamp)obj);
            else
            if(obj instanceof Date)
                obj1 = new TIMESTAMP((Date)obj);
            else
            if(obj instanceof Time)
                obj1 = new TIMESTAMP((Time)obj);
            else
            if(obj instanceof DATE)
                obj1 = new TIMESTAMP((DATE)obj);
            else
            if(obj instanceof String)
                obj1 = new TIMESTAMP((String)obj);
            else
            if(obj instanceof byte[])
                obj1 = new TIMESTAMP((byte[])(byte[])obj);
            break;

        case 181: 
            if(obj instanceof TIMESTAMPTZ)
                obj1 = (Datum)obj;
            else
            if(obj instanceof Timestamp)
                obj1 = new TIMESTAMPTZ(oracleconnection, (Timestamp)obj);
            else
            if(obj instanceof Date)
                obj1 = new TIMESTAMPTZ(oracleconnection, (Date)obj);
            else
            if(obj instanceof Time)
                obj1 = new TIMESTAMPTZ(oracleconnection, (Time)obj);
            else
            if(obj instanceof DATE)
                obj1 = new TIMESTAMPTZ(oracleconnection, (DATE)obj);
            else
            if(obj instanceof String)
                obj1 = new TIMESTAMPTZ(oracleconnection, (String)obj);
            else
            if(obj instanceof byte[])
                obj1 = new TIMESTAMPTZ((byte[])(byte[])obj);
            break;

        case 231: 
            if(obj instanceof TIMESTAMPLTZ)
                obj1 = (Datum)obj;
            else
            if(obj instanceof Timestamp)
                obj1 = new TIMESTAMPLTZ(oracleconnection, (Timestamp)obj);
            else
            if(obj instanceof Date)
                obj1 = new TIMESTAMPLTZ(oracleconnection, (Date)obj);
            else
            if(obj instanceof Time)
                obj1 = new TIMESTAMPLTZ(oracleconnection, (Time)obj);
            else
            if(obj instanceof DATE)
                obj1 = new TIMESTAMPLTZ(oracleconnection, (DATE)obj);
            else
            if(obj instanceof String)
                obj1 = new TIMESTAMPLTZ(oracleconnection, (String)obj);
            else
            if(obj instanceof byte[])
                obj1 = new TIMESTAMPLTZ((byte[])(byte[])obj);
            break;

        case 113: // 'q'
            if(obj instanceof BLOB)
                obj1 = (Datum)obj;
            if(obj instanceof byte[])
                obj1 = new RAW((byte[])(byte[])obj);
            break;

        case 112: // 'p'
            if(obj instanceof CLOB)
                obj1 = (Datum)obj;
            if(obj instanceof String)
            {
                CharacterSet characterset = CharacterSet.make(flag ? ((int) (oracleconnection.getNCharSet())) : ((int) (oracleconnection.getJdbcCsId())));
                obj1 = new CHAR((String)obj, characterset);
            }
            break;

        case 114: // 'r'
            if(obj instanceof BFILE)
                obj1 = (Datum)obj;
            break;

        case 109: // 'm'
            if((obj instanceof STRUCT) || (obj instanceof ARRAY) || (obj instanceof OPAQUE))
                obj1 = (Datum)obj;
            break;

        case 111: // 'o'
            if(obj instanceof REF)
                obj1 = (Datum)obj;
            break;
        }
        if(obj1 == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(null, 1, "Unable to construct a Datum from the specified input");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return ((Datum) (obj1));
        }
    }

    private static int classNumber(Class class1)
    {
        int i = -1;
        Integer integer = (Integer)classTable.get(class1);
        if(integer != null)
            i = integer.intValue();
        return i;
    }

    public static Object getTypeDescriptor(String s, OracleConnection oracleconnection)
        throws SQLException
    {
        Object obj = null;
        SQLName sqlname = new SQLName(s, oracleconnection);
        String s1 = sqlname.getName();
        obj = oracleconnection.getDescriptor(s1);
        if(obj != null)
            return obj;
        OracleTypeADT oracletypeadt = new OracleTypeADT(s1, oracleconnection);
        oracletypeadt.init(oracleconnection);
        OracleNamedType oraclenamedtype = oracletypeadt.cleanup();
        switch(oraclenamedtype.getTypeCode())
        {
        case 2003: 
            obj = new ArrayDescriptor(sqlname, (OracleTypeCOLLECTION)oraclenamedtype, oracleconnection);
            break;

        case 2002: 
        case 2008: 
            obj = new StructDescriptor(sqlname, (OracleTypeADT)oraclenamedtype, oracleconnection);
            break;

        case 2007: 
            obj = new OpaqueDescriptor(sqlname, (OracleTypeOPAQUE)oraclenamedtype, oracleconnection);
            break;

        case 2004: 
        case 2005: 
        case 2006: 
        default:
            SQLException sqlexception = DatabaseError.createSqlException(null, 1, "Unrecognized type code");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        oracleconnection.putDescriptor(s1, obj);
        return obj;
    }

    public static boolean checkDatumType(Datum datum, int i, String s)
        throws SQLException
    {
        boolean flag = false;
        switch(i)
        {
        case 1: // '\001'
        case 8: // '\b'
        case 96: // '`'
            flag = datum instanceof CHAR;
            break;

        case 2: // '\002'
        case 6: // '\006'
            flag = datum instanceof NUMBER;
            break;

        case 100: // 'd'
            flag = datum instanceof BINARY_FLOAT;
            break;

        case 101: // 'e'
            flag = datum instanceof BINARY_DOUBLE;
            break;

        case 23: // '\027'
        case 24: // '\030'
            flag = datum instanceof RAW;
            break;

        case 104: // 'h'
            flag = datum instanceof ROWID;
            break;

        case 12: // '\f'
            flag = datum instanceof DATE;
            break;

        case 180: 
            flag = datum instanceof TIMESTAMP;
            break;

        case 181: 
            flag = datum instanceof TIMESTAMPTZ;
            break;

        case 231: 
            flag = datum instanceof TIMESTAMPLTZ;
            break;

        case 113: // 'q'
            flag = datum instanceof BLOB;
            break;

        case 112: // 'p'
            flag = datum instanceof CLOB;
            break;

        case 114: // 'r'
            flag = datum instanceof BFILE;
            break;

        case 111: // 'o'
            flag = (datum instanceof REF) && ((REF)datum).getBaseTypeName().equals(s);
            break;

        case 109: // 'm'
            if(datum instanceof STRUCT)
            {
                flag = ((STRUCT)datum).isInHierarchyOf(s);
                break;
            }
            if(datum instanceof ARRAY)
            {
                flag = ((ARRAY)datum).getSQLTypeName().equals(s);
                break;
            }
            if(datum instanceof OPAQUE)
                flag = ((OPAQUE)datum).getSQLTypeName().equals(s);
            break;

        case 102: // 'f'
        default:
            flag = false;
            break;
        }
        return flag;
    }

    public static boolean implementsInterface(Class class1, Class class2)
    {
        if(class1 == null)
            return false;
        if(class1 == class2)
            return true;
        Class aclass[] = class1.getInterfaces();
        for(int i = 0; i < aclass.length; i++)
            if(implementsInterface(aclass[i], class2))
                return true;

        return implementsInterface(class1.getSuperclass(), class2);
    }

    public static Datum makeOracleDatum(OracleConnection oracleconnection, Object obj, int i, String s)
        throws SQLException
    {
        return makeOracleDatum(oracleconnection, obj, i, s, false);
    }

    public static Datum makeOracleDatum(OracleConnection oracleconnection, Object obj, int i, String s, boolean flag)
        throws SQLException
    {
        Datum datum = makeDatum(oracleconnection, obj, getInternalType(i), s, flag);
        return datum;
    }

    public static int getInternalType(int i)
        throws SQLException
    {
        char c = '\0';
        switch(i)
        {
        case -7: 
        case -6: 
        case -5: 
        case 2: // '\002'
        case 3: // '\003'
        case 4: // '\004'
        case 5: // '\005'
        case 6: // '\006'
        case 7: // '\007'
        case 8: // '\b'
            c = '\006';
            break;

        case 100: // 'd'
            c = 'd';
            break;

        case 101: // 'e'
            c = 'e';
            break;

        case 999: 
            c = '\u03E7';
            break;

        case 1: // '\001'
            c = '`';
            break;

        case -15: 
            c = '`';
            break;

        case 12: // '\f'
            c = '\001';
            break;

        case -9: 
            c = '\001';
            break;

        case -1: 
            c = '\b';
            break;

        case 91: // '['
        case 92: // '\\'
            c = '\f';
            break;

        case -100: 
        case 93: // ']'
            c = '\264';
            break;

        case -101: 
            c = '\265';
            break;

        case -102: 
            c = '\347';
            break;

        case -104: 
            c = '\267';
            break;

        case -103: 
            c = '\266';
            break;

        case -3: 
        case -2: 
            c = '\027';
            break;

        case -4: 
            c = '\030';
            break;

        case -8: 
            c = 'h';
            break;

        case 2004: 
            c = 'q';
            break;

        case 2005: 
            c = 'p';
            break;

        case 2011: 
            c = 'p';
            break;

        case -13: 
            c = 'r';
            break;

        case -10: 
            c = 'f';
            break;

        case 2002: 
        case 2003: 
        case 2007: 
        case 2008: 
            c = 'm';
            break;

        case 2006: 
            c = 'o';
            break;

        default:
            SQLException sqlexception = DatabaseError.createSqlException(null, 4, "get_internal_type");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return c;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

    static 
    {
        classTable = new Hashtable(10);
        try
        {
            classTable.put(Class.forName("java.lang.String"), Integer.valueOf(0));
            classTable.put(Class.forName("java.lang.Boolean"), Integer.valueOf(1));
            classTable.put(Class.forName("java.lang.Integer"), Integer.valueOf(2));
            classTable.put(Class.forName("java.lang.Long"), Integer.valueOf(3));
            classTable.put(Class.forName("java.lang.Float"), Integer.valueOf(4));
            classTable.put(Class.forName("java.lang.Double"), Integer.valueOf(5));
            classTable.put(Class.forName("java.math.BigDecimal"), Integer.valueOf(6));
            classTable.put(Class.forName("java.sql.Date"), Integer.valueOf(7));
            classTable.put(Class.forName("java.sql.Time"), Integer.valueOf(8));
            classTable.put(Class.forName("java.sql.Timestamp"), Integer.valueOf(9));
        }
        catch(ClassNotFoundException classnotfoundexception) { }
    }
}
