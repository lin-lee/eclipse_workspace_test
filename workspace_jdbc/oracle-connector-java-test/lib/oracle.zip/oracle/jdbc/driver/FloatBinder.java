// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.core.lmx.CoreException;

// Referenced classes of package oracle.jdbc.driver:
//            VarnumBinder, OraclePreparedStatement, DatabaseError

class FloatBinder extends VarnumBinder
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    FloatBinder()
    {
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
        throws SQLException
    {
        byte abyte1[] = abyte0;
        int j2 = j1 + 1;
        double d = oraclepreparedstatement.parameterDouble[k][i];
        int k2 = 0;
        if(d == 0.0D)
        {
            abyte1[j2] = -128;
            k2 = 1;
        } else
        if(d == (1.0D / 0.0D))
        {
            abyte1[j2] = -1;
            abyte1[j2 + 1] = 101;
            k2 = 2;
        } else
        if(d == (-1.0D / 0.0D))
        {
            abyte1[j2] = 0;
            k2 = 1;
        } else
        {
            boolean flag1 = d < 0.0D;
            if(flag1)
                d = -d;
            long l2 = Double.doubleToLongBits(d);
            int i3 = (int)(l2 >> 52 & 2047L);
            int j3 = (i3 <= 1023 ? 127 : 126) - (int)((double)(i3 - 1023) / 6.6438561897747253D);
            if(j3 < 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, (new StringBuilder()).append(CoreException.getMessage((byte)3)).append(" trying to bind ").append(d).toString());
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(j3 > 192)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, (new StringBuilder()).append(CoreException.getMessage((byte)2)).append(" trying to bind ").append(d).toString());
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            if(d > factorTable[j3])
                while(j3 > 0 && d > factorTable[--j3]) ;
            else
                for(; j3 < 193 && d <= factorTable[j3 + 1]; j3++);
            if(d == factorTable[j3])
            {
                if(j3 < 65)
                {
                    SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, (new StringBuilder()).append(CoreException.getMessage((byte)3)).append(" trying to bind ").append(d).toString());
                    sqlexception2.fillInStackTrace();
                    throw sqlexception2;
                }
                if(j3 > 192)
                {
                    SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, (new StringBuilder()).append(CoreException.getMessage((byte)2)).append(" trying to bind ").append(d).toString());
                    sqlexception3.fillInStackTrace();
                    throw sqlexception3;
                }
                if(flag1)
                {
                    abyte1[j2] = (byte)(62 - (127 - j3));
                    abyte1[j2 + 1] = 100;
                    abyte1[j2 + 2] = 102;
                    k2 = 3;
                } else
                {
                    abyte1[j2] = (byte)(192 + (128 - j3));
                    abyte1[j2 + 1] = 2;
                    k2 = 2;
                }
            } else
            {
                if(j3 < 64)
                {
                    SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, (new StringBuilder()).append(CoreException.getMessage((byte)3)).append(" trying to bind ").append(d).toString());
                    sqlexception4.fillInStackTrace();
                    throw sqlexception4;
                }
                if(j3 > 191)
                {
                    SQLException sqlexception5 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, (new StringBuilder()).append(CoreException.getMessage((byte)2)).append(" trying to bind ").append(d).toString());
                    sqlexception5.fillInStackTrace();
                    throw sqlexception5;
                }
                int k3 = Float.floatToIntBits((float)d);
                int l3 = k3 & 0x7fffff;
                int i4 = k3 >> 23 & 0xff;
                char ac1[] = oraclepreparedstatement.digits;
                int j4;
                if(i4 == 0)
                {
                    while((long)(l3 & 0x800000) == 0L) 
                    {
                        l3 <<= 1;
                        i4--;
                    }
                    j4 = 24 + i4;
                    i4++;
                } else
                {
                    l3 |= 0x800000;
                    j4 = 24;
                }
                i4 -= 127;
                k2 = dtoa(abyte1, j2, d, flag1, true, ac1, i4, (long)l3 << 29, j4);
            }
        }
        abyte1[j1] = (byte)k2;
        aword0[i2] = 0;
        aword0[l1] = (short)(k2 + 1);
    }

}
