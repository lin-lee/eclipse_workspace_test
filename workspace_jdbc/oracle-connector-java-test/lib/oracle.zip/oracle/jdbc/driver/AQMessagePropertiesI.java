// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AQMessagePropertiesI.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.sql.Timestamp;
import oracle.jdbc.aq.AQAgent;
import oracle.jdbc.aq.AQMessageProperties;

// Referenced classes of package oracle.jdbc.driver:
//            AQAgentI

class AQMessagePropertiesI
    implements AQMessageProperties
{

    private int attrAttempts;
    private String attrCorrelation;
    private int attrDelay;
    private Timestamp attrEnqTime;
    private String attrExceptionQueue;
    private int attrExpiration;
    private oracle.jdbc.aq.AQMessageProperties.MessageState attrMsgState;
    private int attrPriority;
    private AQAgentI attrRecipientList[];
    private AQAgentI attrSenderId;
    private String attrTransactionGroup;
    private byte attrPreviousQueueMsgId[];
    private oracle.jdbc.aq.AQMessageProperties.DeliveryMode deliveryMode;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    AQMessagePropertiesI()
    {
        attrAttempts = -1;
        attrCorrelation = null;
        attrDelay = 0;
        attrEnqTime = null;
        attrExceptionQueue = null;
        attrExpiration = -1;
        attrMsgState = null;
        attrPriority = 0;
        attrRecipientList = null;
        attrSenderId = null;
        attrTransactionGroup = null;
        attrPreviousQueueMsgId = null;
        deliveryMode = null;
    }

    public int getDequeueAttemptsCount()
    {
        return attrAttempts;
    }

    public void setCorrelation(String s)
        throws SQLException
    {
        attrCorrelation = s;
    }

    public String getCorrelation()
    {
        return attrCorrelation;
    }

    public void setDelay(int i)
        throws SQLException
    {
        attrDelay = i;
    }

    public int getDelay()
    {
        return attrDelay;
    }

    public Timestamp getEnqueueTime()
    {
        return attrEnqTime;
    }

    public void setExceptionQueue(String s)
        throws SQLException
    {
        attrExceptionQueue = s;
    }

    public String getExceptionQueue()
    {
        return attrExceptionQueue;
    }

    public void setExpiration(int i)
        throws SQLException
    {
        attrExpiration = i;
    }

    public int getExpiration()
    {
        return attrExpiration;
    }

    public oracle.jdbc.aq.AQMessageProperties.MessageState getState()
    {
        return attrMsgState;
    }

    public void setPriority(int i)
        throws SQLException
    {
        attrPriority = i;
    }

    public int getPriority()
    {
        return attrPriority;
    }

    public void setRecipientList(AQAgent aaqagent[])
        throws SQLException
    {
        attrRecipientList = new AQAgentI[aaqagent.length];
        for(int i = 0; i < aaqagent.length; i++)
            attrRecipientList[i] = (AQAgentI)aaqagent[i];

    }

    public AQAgent[] getRecipientList()
    {
        return attrRecipientList;
    }

    public void setSender(AQAgent aqagent)
        throws SQLException
    {
        attrSenderId = (AQAgentI)aqagent;
    }

    public AQAgent getSender()
    {
        return attrSenderId;
    }

    public String getTransactionGroup()
    {
        return attrTransactionGroup;
    }

    void setTransactionGroup(String s)
    {
        attrTransactionGroup = s;
    }

    void setPreviousQueueMessageId(byte abyte0[])
    {
        attrPreviousQueueMsgId = abyte0;
    }

    public byte[] getPreviousQueueMessageId()
    {
        return attrPreviousQueueMsgId;
    }

    public oracle.jdbc.aq.AQMessageProperties.DeliveryMode getDeliveryMode()
    {
        return deliveryMode;
    }

    void setDeliveryMode(oracle.jdbc.aq.AQMessageProperties.DeliveryMode deliverymode)
    {
        deliveryMode = deliverymode;
    }

    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append((new StringBuilder()).append("Correlation             : ").append(getCorrelation()).append("\n").toString());
        Timestamp timestamp = getEnqueueTime();
        if(timestamp != null)
            stringbuffer.append((new StringBuilder()).append("Enqueue time            : ").append(timestamp).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Exception Queue         : ").append(getExceptionQueue()).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Sender                  : (").append(getSender()).append(")\n").toString());
        int i = getDequeueAttemptsCount();
        if(i != -1)
            stringbuffer.append((new StringBuilder()).append("Attempts                : ").append(i).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Delay                   : ").append(getDelay()).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Expiration              : ").append(getExpiration()).append("\n").toString());
        oracle.jdbc.aq.AQMessageProperties.MessageState messagestate = getState();
        if(messagestate != null)
            stringbuffer.append((new StringBuilder()).append("State                   : ").append(messagestate).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Priority                : ").append(getPriority()).append("\n").toString());
        oracle.jdbc.aq.AQMessageProperties.DeliveryMode deliverymode = getDeliveryMode();
        if(deliverymode != null)
            stringbuffer.append((new StringBuilder()).append("Delivery Mode           : ").append(deliverymode).append("\n").toString());
        stringbuffer.append("Recipient List          : {");
        AQAgent aaqagent[] = getRecipientList();
        if(aaqagent != null)
        {
            for(int j = 0; j < aaqagent.length; j++)
            {
                stringbuffer.append(aaqagent[j]);
                if(j != aaqagent.length - 1)
                    stringbuffer.append("; ");
            }

        }
        stringbuffer.append("}");
        return stringbuffer.toString();
    }

    void setAttempts(int i)
        throws SQLException
    {
        attrAttempts = i;
    }

    void setEnqueueTime(Timestamp timestamp)
        throws SQLException
    {
        attrEnqTime = timestamp;
    }

    void setMessageState(oracle.jdbc.aq.AQMessageProperties.MessageState messagestate)
        throws SQLException
    {
        attrMsgState = messagestate;
    }

}
