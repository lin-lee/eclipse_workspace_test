// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C7Oversion.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CMAREngine, DatabaseError, T4CConnection

final class T4C7Oversion extends T4CTTIfun
{

    byte rdbmsVersion[] = {
        78, 111, 116, 32, 100, 101, 116, 101, 114, 109, 
        105, 110, 101, 100, 32, 121, 101, 116
    };
    private final boolean rdbmsVersionO2U = true;
    private final int bufLen = 256;
    private final boolean retVerLenO2U = true;
    int retVerLen;
    private final boolean retVerNumO2U = true;
    long retVerNum;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C7Oversion(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        retVerLen = 0;
        retVerNum = 0L;
        setFunCode((short)59);
    }

    void doOVERSION()
        throws SQLException, IOException
    {
        doRPC();
    }

    void readRPA()
        throws IOException, SQLException
    {
        retVerLen = meg.unmarshalUB2();
        rdbmsVersion = meg.unmarshalCHR(retVerLen);
        retVerNum = meg.unmarshalUB4();
    }

    void processRPA()
        throws SQLException
    {
        if(rdbmsVersion == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    byte[] getVersion()
    {
        return rdbmsVersion;
    }

    short getVersionNumber()
    {
        int i = 0;
        i = (int)((long)i + (retVerNum >>> 24 & 255L) * 1000L);
        i = (int)((long)i + (retVerNum >>> 20 & 15L) * 100L);
        i = (int)((long)i + (retVerNum >>> 12 & 15L) * 10L);
        i = (int)((long)i + (retVerNum >>> 8 & 15L));
        return (short)i;
    }

    long getVersionNumberasIs()
    {
        return retVerNum;
    }

    void marshal()
        throws IOException
    {
        meg.marshalO2U(true);
        meg.marshalSWORD(256);
        meg.marshalO2U(true);
        meg.marshalO2U(true);
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
