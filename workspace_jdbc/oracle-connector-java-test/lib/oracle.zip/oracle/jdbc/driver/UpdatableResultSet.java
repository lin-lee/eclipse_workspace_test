// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   UpdatableResultSet.java

package oracle.jdbc.driver;

import java.io.*;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.sql.*;
import java.util.*;
import oracle.jdbc.*;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.proxy.OracleProxy;
import oracle.jdbc.proxy.ProxyFactory;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            BaseResultSet, OracleStatement, OracleResultSetMetaData, OracleResultSetImpl, 
//            ScrollableResultSet, OraclePreparedStatementWrapper, OraclePreparedStatement, DBConversion, 
//            DatabaseError, OracleResultSet, ScrollRsetStatement, LogicalConnection, 
//            PhysicalConnection, SQLUtil, OracleSql

class UpdatableResultSet extends BaseResultSet
{

    static final int concurrencyType = 1008;
    static final int BEGIN_COLUMN_INDEX = 1;
    static final int MAX_CHAR_BUFFER_SIZE = 1024;
    static final int MAX_BYTE_BUFFER_SIZE = 1024;
    PhysicalConnection connection;
    oracle.jdbc.driver.OracleResultSet resultSet;
    boolean isCachedRset;
    ScrollRsetStatement scrollStmt;
    ResultSetMetaData rsetMetaData;
    private int rsetType;
    private int columnCount;
    private OraclePreparedStatement deleteStmt;
    private OraclePreparedStatement insertStmt;
    private OraclePreparedStatement updateStmt;
    private int indexColsChanged[];
    private Object rowBuffer[];
    private boolean m_nullIndicator[];
    private int typeInfo[][];
    private boolean isInserting;
    private boolean isUpdating;
    private int wasNull;
    private static final int VALUE_NULL = 1;
    private static final int VALUE_NOT_NULL = 2;
    private static final int VALUE_UNKNOWN = 3;
    private static final int VALUE_IN_RSET = 4;
    private static final int ASCII_STREAM = 1;
    private static final int BINARY_STREAM = 2;
    private static final int UNICODE_STREAM = 3;
    private static int _MIN_STREAM_SIZE = 4000;
    ArrayList tempClobsToFree;
    ArrayList tempBlobsToFree;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    UpdatableResultSet(ScrollRsetStatement scrollrsetstatement, ScrollableResultSet scrollableresultset, int i, int j)
        throws SQLException
    {
        tempClobsToFree = null;
        tempBlobsToFree = null;
        init(scrollrsetstatement, scrollableresultset, i, j);
        scrollableresultset.resetBeginColumnIndex();
        getInternalMetadata();
        isCachedRset = true;
    }

    UpdatableResultSet(ScrollRsetStatement scrollrsetstatement, OracleResultSetImpl oracleresultsetimpl, int i, int j)
        throws SQLException
    {
        tempClobsToFree = null;
        tempBlobsToFree = null;
        init(scrollrsetstatement, oracleresultsetimpl, i, j);
        getInternalMetadata();
        isCachedRset = false;
    }

    private void init(ScrollRsetStatement scrollrsetstatement, oracle.jdbc.driver.OracleResultSet oracleresultset, int i, int j)
        throws SQLException
    {
        if(scrollrsetstatement == null || oracleresultset == null || j != 1008)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            connection = ((OracleStatement)scrollrsetstatement).connection;
            resultSet = oracleresultset;
            scrollStmt = scrollrsetstatement;
            rsetType = i;
            deleteStmt = null;
            insertStmt = null;
            updateStmt = null;
            indexColsChanged = null;
            rowBuffer = null;
            m_nullIndicator = null;
            typeInfo = (int[][])null;
            isInserting = false;
            isUpdating = false;
            wasNull = -1;
            rsetMetaData = null;
            columnCount = 0;
            return;
        }
    }

    void ensureOpen()
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(resultSet == null || scrollStmt == null || ((OracleStatement)scrollStmt).closed)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return;
        }
    }

    public void close()
        throws SQLException
    {
        if(closed)
            return;
        synchronized(connection)
        {
            super.close();
            if(resultSet != null)
                resultSet.close();
            if(insertStmt != null)
                insertStmt.close();
            if(updateStmt != null)
                updateStmt.close();
            if(deleteStmt != null)
                deleteStmt.close();
            if(scrollStmt != null)
                scrollStmt.notifyCloseRset();
            cancelRowInserts();
            connection = LogicalConnection.closedConnection;
            resultSet = null;
            scrollStmt = null;
            rsetMetaData = null;
            scrollStmt = null;
            deleteStmt = null;
            insertStmt = null;
            updateStmt = null;
            indexColsChanged = null;
            rowBuffer = null;
            m_nullIndicator = null;
            typeInfo = (int[][])null;
        }
    }

    public boolean wasNull()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        wasNull;
        JVM INSTR tableswitch 1 4: default 62
    //                   1 44
    //                   2 48
    //                   3 62
    //                   4 52;
           goto _L1 _L2 _L3 _L1 _L4
_L2:
        return true;
_L3:
        false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L4:
        resultSet.wasNull();
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L1:
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
        sqlexception.fillInStackTrace();
        throw sqlexception;
        Exception exception;
        exception;
        throw exception;
    }

    int getFirstUserColumnIndex()
    {
        return 1;
    }

    public Statement getStatement()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return (Statement)scrollStmt;
        Exception exception;
        exception;
        throw exception;
    }

    public SQLWarning getWarnings()
        throws SQLException
    {
        SQLWarning sqlwarning = resultSet.getWarnings();
        if(sqlWarning == null)
            return sqlwarning;
        SQLWarning sqlwarning1;
        for(sqlwarning1 = sqlWarning; sqlwarning1.getNextWarning() != null; sqlwarning1 = sqlwarning1.getNextWarning());
        sqlwarning1.setNextWarning(sqlwarning);
        return sqlWarning;
    }

    public void clearWarnings()
        throws SQLException
    {
        sqlWarning = null;
        resultSet.clearWarnings();
    }

    public boolean next()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        cancelRowChanges();
        return resultSet.next();
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isBeforeFirst()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return resultSet.isBeforeFirst();
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isAfterLast()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return resultSet.isAfterLast();
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isFirst()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return resultSet.isFirst();
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isLast()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return resultSet.isLast();
        Exception exception;
        exception;
        throw exception;
    }

    public void beforeFirst()
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            cancelRowChanges();
            resultSet.beforeFirst();
        }
    }

    public void afterLast()
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            cancelRowChanges();
            resultSet.afterLast();
        }
    }

    public boolean first()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        cancelRowChanges();
        return resultSet.first();
        Exception exception;
        exception;
        throw exception;
    }

    public boolean last()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        cancelRowChanges();
        return resultSet.last();
        Exception exception;
        exception;
        throw exception;
    }

    public int getRow()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return resultSet.getRow();
        Exception exception;
        exception;
        throw exception;
    }

    public boolean absolute(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        cancelRowChanges();
        return resultSet.absolute(i);
        Exception exception;
        exception;
        throw exception;
    }

    public boolean relative(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        cancelRowChanges();
        return resultSet.relative(i);
        Exception exception;
        exception;
        throw exception;
    }

    public boolean previous()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        cancelRowChanges();
        return resultSet.previous();
        Exception exception;
        exception;
        throw exception;
    }

    public Datum getOracleObject(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        Datum datum = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            setIsNull(datum == null);
            datum = getRowBufferDatumAt(i);
        } else
        {
            setIsNull(4);
            datum = resultSet.getOracleObject(i + 1);
        }
        return datum;
        Exception exception;
        exception;
        throw exception;
    }

    public String getString(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        String s = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                s = datum.stringValue(connection);
        } else
        {
            setIsNull(4);
            s = resultSet.getString(i + 1);
        }
        return s;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean getBoolean(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        boolean flag = false;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                flag = datum.booleanValue();
        } else
        {
            setIsNull(4);
            flag = resultSet.getBoolean(i + 1);
        }
        return flag;
        Exception exception;
        exception;
        throw exception;
    }

    public oracle.jdbc.OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int i)
        throws SQLException
    {
        return resultSet.getAuthorizationIndicator(i + 1);
    }

    public byte getByte(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        byte byte0 = 0;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                byte0 = datum.byteValue();
        } else
        {
            setIsNull(4);
            byte0 = resultSet.getByte(i + 1);
        }
        return byte0;
        Exception exception;
        exception;
        throw exception;
    }

    public short getShort(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        short word0 = 0;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            long l = getLong(i);
            if(l > 0x10001L || l < 0xfffffffffffefffeL)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            word0 = (short)(int)l;
        } else
        {
            setIsNull(4);
            word0 = resultSet.getShort(i + 1);
        }
        return word0;
        Exception exception;
        exception;
        throw exception;
    }

    public int getInt(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        int j = 0;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                j = datum.intValue();
        } else
        {
            setIsNull(4);
            j = resultSet.getInt(i + 1);
        }
        return j;
        Exception exception;
        exception;
        throw exception;
    }

    public long getLong(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        long l = 0L;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                l = datum.longValue();
        } else
        {
            setIsNull(4);
            l = resultSet.getLong(i + 1);
        }
        return l;
        Exception exception;
        exception;
        throw exception;
    }

    public float getFloat(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        float f = 0.0F;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                f = datum.floatValue();
        } else
        {
            setIsNull(4);
            f = resultSet.getFloat(i + 1);
        }
        return f;
        Exception exception;
        exception;
        throw exception;
    }

    public double getDouble(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        double d = 0.0D;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                d = datum.doubleValue();
        } else
        {
            setIsNull(4);
            d = resultSet.getDouble(i + 1);
        }
        return d;
        Exception exception;
        exception;
        throw exception;
    }

    public BigDecimal getBigDecimal(int i, int j)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        BigDecimal bigdecimal = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                bigdecimal = datum.bigDecimalValue();
        } else
        {
            setIsNull(4);
            bigdecimal = resultSet.getBigDecimal(i + 1);
        }
        return bigdecimal;
        Exception exception;
        exception;
        throw exception;
    }

    public byte[] getBytes(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        byte abyte0[] = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                abyte0 = datum.getBytes();
        } else
        {
            setIsNull(4);
            abyte0 = resultSet.getBytes(i + 1);
        }
        return abyte0;
        Exception exception;
        exception;
        throw exception;
    }

    public Date getDate(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        Date date = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                date = datum.dateValue();
        } else
        {
            setIsNull(4);
            date = resultSet.getDate(i + 1);
        }
        return date;
        Exception exception;
        exception;
        throw exception;
    }

    public Time getTime(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        Time time = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                time = datum.timeValue();
        } else
        {
            setIsNull(4);
            time = resultSet.getTime(i + 1);
        }
        return time;
        Exception exception;
        exception;
        throw exception;
    }

    public Timestamp getTimestamp(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        Timestamp timestamp = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                timestamp = datum.timestampValue();
        } else
        {
            setIsNull(4);
            timestamp = resultSet.getTimestamp(i + 1);
        }
        return timestamp;
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getAsciiStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        InputStream inputstream = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Object obj = getRowBufferAt(i);
            setIsNull(obj == null);
            if(obj != null)
                if(obj instanceof InputStream)
                {
                    inputstream = (InputStream)obj;
                } else
                {
                    Datum datum = getRowBufferDatumAt(i);
                    inputstream = datum.asciiStreamValue();
                }
        } else
        {
            setIsNull(4);
            inputstream = resultSet.getAsciiStream(i + 1);
        }
        return inputstream;
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getUnicodeStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        InputStream inputstream = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Object obj = getRowBufferAt(i);
            setIsNull(obj == null);
            if(obj != null)
                if(obj instanceof InputStream)
                {
                    inputstream = (InputStream)obj;
                } else
                {
                    Datum datum = getRowBufferDatumAt(i);
                    DBConversion dbconversion = connection.conversion;
                    byte abyte0[] = datum.shareBytes();
                    if(datum instanceof RAW)
                    {
                        connection;
                        inputstream = dbconversion.ConvertStream(new ByteArrayInputStream(abyte0), 3);
                    } else
                    if(datum instanceof CHAR)
                    {
                        connection;
                        inputstream = dbconversion.ConvertStream(new ByteArrayInputStream(abyte0), 1);
                    } else
                    {
                        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
                        sqlexception.fillInStackTrace();
                        throw sqlexception;
                    }
                }
        } else
        {
            setIsNull(4);
            inputstream = resultSet.getUnicodeStream(i + 1);
        }
        return inputstream;
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getBinaryStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        InputStream inputstream = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Object obj = getRowBufferAt(i);
            setIsNull(obj == null);
            if(obj != null)
                if(obj instanceof InputStream)
                {
                    inputstream = (InputStream)obj;
                } else
                {
                    Datum datum = getRowBufferDatumAt(i);
                    inputstream = datum.binaryStreamValue();
                }
        } else
        {
            setIsNull(4);
            inputstream = resultSet.getBinaryStream(i + 1);
        }
        return inputstream;
        Exception exception;
        exception;
        throw exception;
    }

    public Object getObject(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        Object obj = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getOracleObject(i);
            setIsNull(datum == null);
            if(datum != null)
                obj = datum.toJdbc();
        } else
        {
            setIsNull(4);
            obj = resultSet.getObject(i + 1);
        }
        return obj;
        Exception exception;
        exception;
        throw exception;
    }

    public Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return oracledatafactory.create(getObject(i), 0);
        Exception exception;
        exception;
        throw exception;
    }

    public Reader getCharacterStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        Reader reader = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Object obj = getRowBufferAt(i);
            setIsNull(obj == null);
            if(obj != null)
                if(obj instanceof Reader)
                {
                    reader = (Reader)obj;
                } else
                {
                    Datum datum = getRowBufferDatumAt(i);
                    reader = datum.characterStreamValue();
                }
        } else
        {
            setIsNull(4);
            reader = resultSet.getCharacterStream(i + 1);
        }
        return reader;
        Exception exception;
        exception;
        throw exception;
    }

    public BigDecimal getBigDecimal(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        BigDecimal bigdecimal = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null)
                bigdecimal = datum.bigDecimalValue();
        } else
        {
            setIsNull(4);
            bigdecimal = resultSet.getBigDecimal(i + 1);
        }
        return bigdecimal;
        Exception exception;
        exception;
        throw exception;
    }

    public Object getObject(int i, Map map)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        Object obj = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getOracleObject(i);
            setIsNull(datum == null);
            if(datum != null)
                if(datum instanceof STRUCT)
                    obj = ((STRUCT)datum).toJdbc(map);
                else
                    obj = datum.toJdbc();
        } else
        {
            setIsNull(4);
            obj = resultSet.getObject(i + 1, map);
        }
        return obj;
        Exception exception;
        exception;
        throw exception;
    }

    public Ref getRef(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return getREF(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Blob getBlob(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return getBLOB(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Clob getClob(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return getCLOB(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Array getArray(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return getARRAY(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Date getDate(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        Date date = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getOracleObject(i);
            setIsNull(datum == null);
            if(datum != null)
                if(datum instanceof DATE)
                    date = ((DATE)datum).dateValue(calendar);
                else
                if(datum instanceof TIMESTAMP)
                {
                    Timestamp timestamp = ((TIMESTAMP)datum).timestampValue(calendar);
                    long l = timestamp.getTime();
                    date = new Date(l);
                } else
                {
                    DATE date1 = new DATE(datum.stringValue(connection));
                    if(date1 != null)
                        date = date1.dateValue(calendar);
                }
        } else
        {
            setIsNull(4);
            date = resultSet.getDate(i + 1, calendar);
        }
        return date;
        Exception exception;
        exception;
        throw exception;
    }

    public Time getTime(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        Time time = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getOracleObject(i);
            setIsNull(datum == null);
            if(datum != null)
                if(datum instanceof DATE)
                    time = ((DATE)datum).timeValue(calendar);
                else
                if(datum instanceof TIMESTAMP)
                {
                    Timestamp timestamp = ((TIMESTAMP)datum).timestampValue(calendar);
                    long l = timestamp.getTime();
                    time = new Time(l);
                } else
                {
                    DATE date = new DATE(datum.stringValue(connection));
                    if(date != null)
                        time = date.timeValue(calendar);
                }
        } else
        {
            setIsNull(4);
            time = resultSet.getTime(i + 1, calendar);
        }
        return time;
        Exception exception;
        exception;
        throw exception;
    }

    public Timestamp getTimestamp(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        Timestamp timestamp = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getOracleObject(i);
            setIsNull(datum == null);
            if(datum != null)
                if(datum instanceof DATE)
                    timestamp = ((DATE)datum).timestampValue(calendar);
                else
                if(datum instanceof TIMESTAMP)
                {
                    timestamp = ((TIMESTAMP)datum).timestampValue(calendar);
                } else
                {
                    DATE date = new DATE(datum.stringValue(connection));
                    if(date != null)
                        timestamp = date.timestampValue(calendar);
                }
        } else
        {
            setIsNull(4);
            timestamp = resultSet.getTimestamp(i + 1, calendar);
        }
        return timestamp;
        Exception exception;
        exception;
        throw exception;
    }

    public URL getURL(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        URL url = null;
        int j = getInternalMetadata().getColumnType(i + 1);
        int k = SQLUtil.getInternalType(j);
        if(k == 96 || k == 1 || k == 8)
        {
            try
            {
                String s = getString(i);
                if(s == null)
                    url = null;
                else
                    url = new URL(s);
            }
            catch(MalformedURLException malformedurlexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        } else
        {
            SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return url;
        Exception exception;
        exception;
        throw exception;
    }

    public ResultSet getCursor(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        ResultSet resultset = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getOracleObject(i);
            setIsNull(datum == null);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        setIsNull(4);
        resultset = resultSet.getCursor(i + 1);
        return resultset;
        Exception exception;
        exception;
        throw exception;
    }

    public ROWID getROWID(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        ROWID rowid = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof ROWID))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            rowid = (ROWID)datum;
        } else
        {
            setIsNull(4);
            rowid = resultSet.getROWID(i + 1);
        }
        return rowid;
        Exception exception;
        exception;
        throw exception;
    }

    public NUMBER getNUMBER(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        NUMBER number = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof NUMBER))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            number = (NUMBER)datum;
        } else
        {
            setIsNull(4);
            number = resultSet.getNUMBER(i + 1);
        }
        return number;
        Exception exception;
        exception;
        throw exception;
    }

    public DATE getDATE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        DATE date = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            if(datum != null)
            {
                if(datum instanceof DATE)
                    date = (DATE)datum;
                else
                if(datum instanceof TIMESTAMP)
                {
                    Timestamp timestamp = ((TIMESTAMP)datum).timestampValue();
                    date = new DATE(timestamp);
                } else
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
            } else
            {
                setIsNull(datum == null);
            }
        } else
        {
            setIsNull(4);
            date = resultSet.getDATE(i + 1);
        }
        return date;
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        TIMESTAMP timestamp = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof TIMESTAMP))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            timestamp = (TIMESTAMP)datum;
        } else
        {
            setIsNull(4);
            timestamp = resultSet.getTIMESTAMP(i + 1);
        }
        return timestamp;
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        TIMESTAMPTZ timestamptz = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof TIMESTAMPTZ))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            timestamptz = (TIMESTAMPTZ)datum;
        } else
        {
            setIsNull(4);
            timestamptz = resultSet.getTIMESTAMPTZ(i + 1);
        }
        return timestamptz;
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        TIMESTAMPLTZ timestampltz = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof TIMESTAMPLTZ))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            timestampltz = (TIMESTAMPLTZ)datum;
        } else
        {
            setIsNull(4);
            timestampltz = resultSet.getTIMESTAMPLTZ(i + 1);
        }
        return timestampltz;
        Exception exception;
        exception;
        throw exception;
    }

    public INTERVALDS getINTERVALDS(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        INTERVALDS intervalds = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof INTERVALDS))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALDS");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            intervalds = (INTERVALDS)datum;
        } else
        {
            setIsNull(4);
            intervalds = resultSet.getINTERVALDS(i + 1);
        }
        return intervalds;
        Exception exception;
        exception;
        throw exception;
    }

    public INTERVALYM getINTERVALYM(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        INTERVALYM intervalym = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof INTERVALYM))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALYM");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            intervalym = (INTERVALYM)datum;
        } else
        {
            setIsNull(4);
            intervalym = resultSet.getINTERVALYM(i + 1);
        }
        return intervalym;
        Exception exception;
        exception;
        throw exception;
    }

    public ARRAY getARRAY(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        ARRAY array = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof ARRAY))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            array = (ARRAY)datum;
        } else
        {
            setIsNull(4);
            array = resultSet.getARRAY(i + 1);
        }
        return array;
        Exception exception;
        exception;
        throw exception;
    }

    public STRUCT getSTRUCT(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        STRUCT struct = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof STRUCT))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            struct = (STRUCT)datum;
        } else
        {
            setIsNull(4);
            struct = resultSet.getSTRUCT(i + 1);
        }
        return struct;
        Exception exception;
        exception;
        throw exception;
    }

    public OPAQUE getOPAQUE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        OPAQUE opaque = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof OPAQUE))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            opaque = (OPAQUE)datum;
        } else
        {
            setIsNull(4);
            opaque = resultSet.getOPAQUE(i + 1);
        }
        return opaque;
        Exception exception;
        exception;
        throw exception;
    }

    public REF getREF(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        REF ref = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof REF))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            ref = (REF)datum;
        } else
        {
            setIsNull(4);
            ref = resultSet.getREF(i + 1);
        }
        return ref;
        Exception exception;
        exception;
        throw exception;
    }

    public CHAR getCHAR(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        CHAR char1 = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof CHAR))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            char1 = (CHAR)datum;
        } else
        {
            setIsNull(4);
            char1 = resultSet.getCHAR(i + 1);
        }
        return char1;
        Exception exception;
        exception;
        throw exception;
    }

    public RAW getRAW(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        RAW raw = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof RAW))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            raw = (RAW)datum;
        } else
        {
            setIsNull(4);
            raw = resultSet.getRAW(i + 1);
        }
        return raw;
        Exception exception;
        exception;
        throw exception;
    }

    public BLOB getBLOB(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        BLOB blob = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof BLOB))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            blob = (BLOB)datum;
        } else
        {
            setIsNull(4);
            blob = resultSet.getBLOB(i + 1);
        }
        return blob;
        Exception exception;
        exception;
        throw exception;
    }

    public NCLOB getNCLOB(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        NCLOB nclob = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof NCLOB))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            nclob = (NCLOB)datum;
        } else
        {
            setIsNull(4);
            nclob = (NCLOB)(NCLOB)resultSet.getNClob(i + 1);
        }
        return nclob;
        Exception exception;
        exception;
        throw exception;
    }

    public CLOB getCLOB(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        CLOB clob = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof CLOB))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            clob = (CLOB)datum;
        } else
        {
            setIsNull(4);
            clob = resultSet.getCLOB(i + 1);
        }
        return clob;
        Exception exception;
        exception;
        throw exception;
    }

    public BFILE getBFILE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        BFILE bfile = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof BFILE))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            bfile = (BFILE)datum;
        } else
        {
            setIsNull(4);
            bfile = resultSet.getBFILE(i + 1);
        }
        return bfile;
        Exception exception;
        exception;
        throw exception;
    }

    public BFILE getBfile(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return getBFILE(i);
        Exception exception;
        exception;
        throw exception;
    }

    public CustomDatum getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        if(customdatumfactory == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        CustomDatum customdatum = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            customdatum = customdatumfactory.create(datum, 0);
        } else
        {
            setIsNull(4);
            customdatum = resultSet.getCustomDatum(i + 1, customdatumfactory);
        }
        return customdatum;
        Exception exception;
        exception;
        throw exception;
    }

    public ORAData getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        if(oradatafactory == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        ORAData oradata = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            oradata = oradatafactory.create(datum, 0);
        } else
        {
            setIsNull(4);
            oradata = resultSet.getORAData(i + 1, oradatafactory);
        }
        return oradata;
        Exception exception;
        exception;
        throw exception;
    }

    public NClob getNClob(int i)
        throws SQLException
    {
        ensureOpen();
        NCLOB nclob = getNCLOB(i);
        if(nclob == null)
            return null;
        if(!(nclob instanceof NClob))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 184);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return nclob;
        }
    }

    public String getNString(int i)
        throws SQLException
    {
        ensureOpen();
        return getString(i);
    }

    public Reader getNCharacterStream(int i)
        throws SQLException
    {
        ensureOpen();
        return getCharacterStream(i);
    }

    public RowId getRowId(int i)
        throws SQLException
    {
        ensureOpen();
        return getROWID(i);
    }

    public SQLXML getSQLXML(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        SQLXML sqlxml = null;
        setIsNull(3);
        if(isOnInsertRow() || isUpdatingRow() && isRowBufferUpdatedAt(i))
        {
            Datum datum = getRowBufferDatumAt(i);
            setIsNull(datum == null);
            if(datum != null && !(datum instanceof SQLXML))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSQLXML");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            sqlxml = (SQLXML)datum;
        } else
        {
            setIsNull(4);
            sqlxml = resultSet.getSQLXML(i + 1);
        }
        return sqlxml;
        Exception exception;
        exception;
        throw exception;
    }

    public void updateRowId(int i, RowId rowid)
        throws SQLException
    {
        updateROWID(i, (ROWID)rowid);
    }

    public void updateNCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        updateCharacterStream(i, reader, l);
    }

    public void updateNCharacterStream(int i, Reader reader)
        throws SQLException
    {
        updateCharacterStream(i, reader);
    }

    public void updateSQLXML(int i, SQLXML sqlxml)
        throws SQLException
    {
        updateOracleObject(i, (Datum)sqlxml);
    }

    public void updateNString(int i, String s)
        throws SQLException
    {
        updateString(i, s);
    }

    public void updateNClob(int i, NClob nclob)
        throws SQLException
    {
        updateClob(i, nclob);
    }

    public void updateAsciiStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        updateAsciiStream(i, inputstream, (int)l);
    }

    public void updateAsciiStream(int i, InputStream inputstream)
        throws SQLException
    {
        updateAsciiStream(i, inputstream, 0x7fffffff);
    }

    public void updateBinaryStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        updateBinaryStream(i, inputstream, (int)l);
    }

    public void updateBinaryStream(int i, InputStream inputstream)
        throws SQLException
    {
        updateBinaryStream(i, inputstream, 0x7fffffff);
    }

    public void updateCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        updateCharacterStream(i, reader, (int)l);
    }

    public void updateCharacterStream(int i, Reader reader)
        throws SQLException
    {
        updateCharacterStream(i, reader, 0x7fffffff);
    }

    public void updateBlob(int i, InputStream inputstream)
        throws SQLException
    {
        Blob blob = connection.createBlob();
        addToTempLobsToFree(blob);
        int j = ((BLOB)blob).getBufferSize();
        OutputStream outputstream = blob.setBinaryStream(1L);
        byte abyte0[] = new byte[j];
        try
        {
            do
            {
                int k = inputstream.read(abyte0);
                if(k == -1)
                    break;
                outputstream.write(abyte0, 0, k);
            } while(true);
            outputstream.close();
            updateBlob(i, blob);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public void updateBlob(int i, InputStream inputstream, long l)
        throws SQLException
    {
        Blob blob = connection.createBlob();
        addToTempLobsToFree(blob);
        int j = ((BLOB)blob).getBufferSize();
        OutputStream outputstream = blob.setBinaryStream(1L);
        byte abyte0[] = new byte[j];
        long l1 = l;
        try
        {
            do
            {
                if(l1 <= 0L)
                    break;
                int k = inputstream.read(abyte0, 0, Math.min(j, (int)l1));
                if(k == -1)
                    break;
                outputstream.write(abyte0, 0, k);
                l1 -= k;
            } while(true);
            outputstream.close();
            updateBlob(i, blob);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public void updateClob(int i, Reader reader, long l)
        throws SQLException
    {
        updateClob(i, reader, l, (short)1);
    }

    void updateClob(int i, Reader reader, long l, short word0)
        throws SQLException
    {
        Object obj = word0 != 1 ? ((Object) (connection.createNClob())) : ((Object) (connection.createClob()));
        addToTempLobsToFree(((Clob) (obj)));
        int j = ((CLOB)obj).getBufferSize();
        Writer writer = ((Clob) (obj)).setCharacterStream(1L);
        char ac[] = new char[j];
        long l1 = l;
        try
        {
            do
            {
                if(l1 <= 0L)
                    break;
                int k = reader.read(ac, 0, Math.min(j, (int)l1));
                if(k == -1)
                    break;
                writer.write(ac, 0, k);
                l1 -= k;
            } while(true);
            writer.close();
            updateClob(i, ((Clob) (obj)));
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public void updateClob(int i, Reader reader)
        throws SQLException
    {
        Clob clob = connection.createClob();
        addToTempLobsToFree(clob);
        int j = ((CLOB)clob).getBufferSize();
        Writer writer = clob.setCharacterStream(1L);
        char ac[] = new char[j];
        try
        {
            do
            {
                int k = reader.read(ac);
                if(k == -1)
                    break;
                writer.write(ac, 0, k);
            } while(true);
            writer.close();
            updateClob(i, clob);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    void updateClob(int i, InputStream inputstream, int j)
        throws SQLException
    {
        updateClob(i, inputstream, j, (short)1);
    }

    void updateClob(int i, InputStream inputstream, int j, short word0)
        throws SQLException
    {
        Object obj = word0 != 1 ? ((Object) (connection.createNClob())) : ((Object) (connection.createClob()));
        addToTempLobsToFree(((Clob) (obj)));
        int k = ((CLOB)obj).getBufferSize();
        OutputStream outputstream = ((Clob) (obj)).setAsciiStream(1L);
        byte abyte0[] = new byte[k];
        long l = j;
        try
        {
            do
            {
                if(l <= 0L)
                    break;
                int i1 = inputstream.read(abyte0, 0, Math.min(k, (int)l));
                if(i1 == -1)
                    break;
                outputstream.write(abyte0, 0, i1);
                l -= i1;
            } while(true);
            outputstream.close();
            updateClob(i, ((Clob) (obj)));
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    void updateNClob(int i, InputStream inputstream, int j)
        throws SQLException
    {
        NClob nclob = connection.createNClob();
        addToTempLobsToFree(nclob);
        int k = ((NCLOB)nclob).getBufferSize();
        OutputStream outputstream = nclob.setAsciiStream(1L);
        byte abyte0[] = new byte[k];
        long l = j;
        try
        {
            do
            {
                if(l <= 0L)
                    break;
                int i1 = inputstream.read(abyte0, 0, Math.min(k, (int)l));
                if(i1 == -1)
                    break;
                outputstream.write(abyte0, 0, i1);
                l -= i1;
            } while(true);
            outputstream.close();
            updateNClob(i, nclob);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public void updateNClob(int i, Reader reader, long l)
        throws SQLException
    {
        NClob nclob = connection.createNClob();
        addToTempLobsToFree(nclob);
        int j = ((CLOB)nclob).getBufferSize();
        Writer writer = nclob.setCharacterStream(1L);
        char ac[] = new char[j];
        long l1 = l;
        try
        {
            do
            {
                if(l1 <= 0L)
                    break;
                int k = reader.read(ac, 0, Math.min(j, (int)l1));
                if(k == -1)
                    break;
                writer.write(ac, 0, k);
                l1 -= k;
            } while(true);
            writer.close();
            updateNClob(i, nclob);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public void updateNClob(int i, Reader reader)
        throws SQLException
    {
        NClob nclob = connection.createNClob();
        addToTempLobsToFree(nclob);
        int j = ((CLOB)nclob).getBufferSize();
        Writer writer = nclob.setCharacterStream(1L);
        char ac[] = new char[j];
        try
        {
            do
            {
                int k = reader.read(ac);
                if(k == -1)
                    break;
                writer.write(ac, 0, k);
            } while(true);
            writer.close();
            updateNClob(i, nclob);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    void addToTempLobsToFree(Clob clob)
    {
        if(tempClobsToFree == null)
            tempClobsToFree = new ArrayList();
        tempClobsToFree.add(clob);
    }

    void addToTempLobsToFree(Blob blob)
    {
        if(tempBlobsToFree == null)
            tempBlobsToFree = new ArrayList();
        tempBlobsToFree.add(blob);
    }

    void cleanTempLobs()
    {
        cleanTempClobs(tempClobsToFree);
        cleanTempBlobs(tempBlobsToFree);
        tempClobsToFree = null;
        tempBlobsToFree = null;
    }

    void cleanTempBlobs(ArrayList arraylist)
    {
        if(arraylist != null)
        {
            for(Iterator iterator = arraylist.iterator(); iterator.hasNext();)
                try
                {
                    ((BLOB)(BLOB)iterator.next()).freeTemporary();
                }
                catch(SQLException sqlexception) { }

        }
    }

    void cleanTempClobs(ArrayList arraylist)
    {
        if(arraylist != null)
        {
            for(Iterator iterator = arraylist.iterator(); iterator.hasNext();)
                try
                {
                    ((CLOB)(CLOB)iterator.next()).freeTemporary();
                }
                catch(SQLException sqlexception) { }

        }
    }

    public ResultSetMetaData getMetaData()
        throws SQLException
    {
        if(((OracleStatement)scrollStmt).closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getMetaData");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return new OracleResultSetMetaData(connection, (OracleStatement)scrollStmt, 1);
        Exception exception;
        exception;
        throw exception;
    }

    public int findColumn(String s)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return resultSet.findColumn(s) - 1;
        Exception exception;
        exception;
        throw exception;
    }

    public void setFetchDirection(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            resultSet.setFetchDirection(i);
        }
    }

    public int getFetchDirection()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return resultSet.getFetchDirection();
        Exception exception;
        exception;
        throw exception;
    }

    public void setFetchSize(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            resultSet.setFetchSize(i);
        }
    }

    public int getFetchSize()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        return resultSet.getFetchSize();
        Exception exception;
        exception;
        throw exception;
    }

    public int getType()
        throws SQLException
    {
        return rsetType;
    }

    public int getConcurrency()
        throws SQLException
    {
        return 1008;
    }

    public boolean rowUpdated()
        throws SQLException
    {
        return false;
    }

    public boolean rowInserted()
        throws SQLException
    {
        return false;
    }

    public boolean rowDeleted()
        throws SQLException
    {
        return false;
    }

    public void insertRow()
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            if(!isOnInsertRow())
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 83);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            prepareInsertRowStatement();
            prepareInsertRowBinds();
            executeInsertRow();
        }
    }

    public void updateRow()
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            if(isOnInsertRow())
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            int i = getNumColumnsChanged();
            if(i > 0)
            {
                prepareUpdateRowStatement(i);
                prepareUpdateRowBinds(i);
                executeUpdateRow();
            }
        }
    }

    public void deleteRow()
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            if(isOnInsertRow())
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            prepareDeleteRowStatement();
            prepareDeleteRowBinds();
            executeDeleteRow();
        }
    }

    public void refreshRow()
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            if(isOnInsertRow())
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            resultSet.refreshRow();
        }
    }

    public void cancelRowUpdates()
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            if(isUpdating)
            {
                isUpdating = false;
                clearRowBuffer();
            }
        }
    }

    public void moveToInsertRow()
        throws SQLException
    {
label0:
        {
            synchronized(connection)
            {
                ensureOpen();
                if(!isOnInsertRow())
                    break label0;
            }
            return;
        }
        isInserting = true;
        if(rowBuffer == null)
            rowBuffer = new Object[getColumnCount()];
        if(m_nullIndicator == null)
            m_nullIndicator = new boolean[getColumnCount()];
        clearRowBuffer();
        physicalconnection;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
    }

    public void moveToCurrentRow()
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            cancelRowInserts();
        }
    }

    public void updateString(int i, String s)
        throws SQLException
    {
        synchronized(connection)
        {
            if(s == null || s.length() == 0)
                updateNull(i);
            else
                updateObject(i, s);
        }
    }

    public void updateNull(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            setRowBufferAt(i, null);
        }
    }

    public void updateBoolean(int i, boolean flag)
        throws SQLException
    {
        updateObject(i, Boolean.valueOf(flag));
    }

    public void updateByte(int i, byte byte0)
        throws SQLException
    {
        updateObject(i, Integer.valueOf(byte0));
    }

    public void updateShort(int i, short word0)
        throws SQLException
    {
        updateObject(i, Integer.valueOf(word0));
    }

    public void updateInt(int i, int j)
        throws SQLException
    {
        updateObject(i, Integer.valueOf(j));
    }

    public void updateLong(int i, long l)
        throws SQLException
    {
        updateObject(i, Long.valueOf(l));
    }

    public void updateFloat(int i, float f)
        throws SQLException
    {
        updateObject(i, Float.valueOf(f));
    }

    public void updateDouble(int i, double d)
        throws SQLException
    {
        updateObject(i, Double.valueOf(d));
    }

    public void updateBigDecimal(int i, BigDecimal bigdecimal)
        throws SQLException
    {
        updateObject(i, bigdecimal);
    }

    public void updateBytes(int i, byte abyte0[])
        throws SQLException
    {
        updateObject(i, abyte0);
    }

    public void updateDate(int i, Date date)
        throws SQLException
    {
        updateObject(i, date);
    }

    public void updateTime(int i, Time time)
        throws SQLException
    {
        updateObject(i, time);
    }

    public void updateTimestamp(int i, Timestamp timestamp)
        throws SQLException
    {
        updateObject(i, timestamp);
    }

    public void updateAsciiStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        int k;
        ensureOpen();
        OracleResultSetMetaData oracleresultsetmetadata = (OracleResultSetMetaData)getInternalMetadata();
        k = oracleresultsetmetadata.getColumnType(1 + i);
        if(inputstream == null || j <= 0) goto _L2; else goto _L1
_L1:
        k;
        JVM INSTR lookupswitch 4: default 131
    //                   -1: 107
    //                   2004: 96
    //                   2005: 76
    //                   2011: 86;
           goto _L3 _L4 _L5 _L6 _L7
_L6:
        updateClob(i, inputstream, j);
        break; /* Loop/switch isn't completed */
_L7:
        updateNClob(i, inputstream, j);
        break; /* Loop/switch isn't completed */
_L5:
        updateBlob(i, inputstream, j);
        break; /* Loop/switch isn't completed */
_L4:
        int ai[] = {
            j, 1
        };
        setRowBufferAt(i, inputstream, ai);
        break; /* Loop/switch isn't completed */
_L3:
        StringBuilder stringbuilder;
        try
        {
            boolean flag = false;
            int i1 = j;
            byte abyte0[] = new byte[1024];
            char ac[] = new char[1024];
            stringbuilder = new StringBuilder(1024);
            do
            {
                if(i1 <= 0)
                    break;
                int l;
                if(i1 >= 1024)
                    l = inputstream.read(abyte0);
                else
                    l = inputstream.read(abyte0, 0, i1);
                if(l == -1)
                    break;
                connection.conversion;
                DBConversion.asciiBytesToJavaChars(abyte0, l, ac);
                stringbuilder.append(ac, 0, l);
                i1 -= l;
            } while(true);
            inputstream.close();
            if(i1 == j)
            {
                updateNull(i);
                return;
            }
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        updateString(i, stringbuilder.toString());
        break; /* Loop/switch isn't completed */
_L2:
        setRowBufferAt(i, null);
    }

    public void updateBinaryStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        int k;
        ensureOpen();
        k = getInternalMetadata().getColumnType(1 + i);
        if(inputstream == null || j <= 0) goto _L2; else goto _L1
_L1:
        k;
        JVM INSTR lookupswitch 2: default 91
    //                   -4: 67
    //                   2004: 56;
           goto _L3 _L4 _L5
_L5:
        updateBlob(i, inputstream, j);
        break; /* Loop/switch isn't completed */
_L4:
        int ai[] = {
            j, 2
        };
        setRowBufferAt(i, inputstream, ai);
        break; /* Loop/switch isn't completed */
_L3:
        ByteArrayOutputStream bytearrayoutputstream;
        try
        {
            boolean flag = false;
            int i1 = j;
            byte abyte0[] = new byte[1024];
            bytearrayoutputstream = new ByteArrayOutputStream(1024);
            do
            {
                if(i1 <= 0)
                    break;
                int l;
                if(i1 >= 1024)
                    l = inputstream.read(abyte0);
                else
                    l = inputstream.read(abyte0, 0, i1);
                if(l == -1)
                    break;
                bytearrayoutputstream.write(abyte0, 0, l);
                i1 -= l;
            } while(true);
            inputstream.close();
            if(i1 == j)
            {
                updateNull(i);
                return;
            }
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        updateBytes(i, bytearrayoutputstream.toByteArray());
        break; /* Loop/switch isn't completed */
_L2:
        setRowBufferAt(i, null);
    }

    public void updateCharacterStream(int i, Reader reader, int j)
        throws SQLException
    {
        int l;
        int i1;
        boolean flag = false;
        l = j;
        ensureOpen();
        OracleResultSetMetaData oracleresultsetmetadata = (OracleResultSetMetaData)getInternalMetadata();
        i1 = oracleresultsetmetadata.getColumnType(1 + i);
        if(reader == null || j <= 0) goto _L2; else goto _L1
_L1:
        i1;
        JVM INSTR lookupswitch 3: default 114
    //                   -1: 94
    //                   2005: 72
    //                   2011: 83;
           goto _L3 _L4 _L5 _L6
_L5:
        updateClob(i, reader, j);
        break; /* Loop/switch isn't completed */
_L6:
        updateNClob(i, reader, j);
        break; /* Loop/switch isn't completed */
_L4:
        int ai[] = {
            j
        };
        setRowBufferAt(i, reader, ai);
        break; /* Loop/switch isn't completed */
_L3:
        StringBuilder stringbuilder;
        try
        {
            char ac[] = new char[1024];
            stringbuilder = new StringBuilder(1024);
            do
            {
                if(l <= 0)
                    break;
                int k;
                if(l >= 1024)
                    k = reader.read(ac);
                else
                    k = reader.read(ac, 0, l);
                if(k == -1)
                    break;
                stringbuilder.append(ac, 0, k);
                l -= k;
            } while(true);
            reader.close();
            if(l == j)
            {
                updateNull(i);
                return;
            }
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        updateString(i, stringbuilder.toString());
        break; /* Loop/switch isn't completed */
_L2:
        setRowBufferAt(i, null);
    }

    public void updateObject(int i, Object obj, int j)
        throws SQLException
    {
        updateObject(i, obj);
    }

    public void updateObject(int i, Object obj)
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            Datum datum = null;
            if(obj != null)
            {
                if(obj instanceof OracleData)
                {
                    Object obj1 = ((OracleData)obj).toJDBCObject(connection);
                    if(obj1 instanceof OracleProxy)
                    {
                        final OracleProxy proxiedJDBCObject = (OracleProxy)obj1;
                        obj1 = AccessController.doPrivileged(new PrivilegedAction() {

                            final OracleProxy val$proxiedJDBCObject;
                            final UpdatableResultSet this$0;

                            public Object run()
                            {
                                return ProxyFactory.extractDelegate(proxiedJDBCObject);
                            }

            
            {
                this$0 = UpdatableResultSet.this;
                proxiedJDBCObject = oracleproxy;
                super();
            }
                        }
);
                    }
                    obj = obj1;
                }
                if(obj instanceof Datum)
                {
                    datum = (Datum)obj;
                } else
                {
                    OracleResultSetMetaData oracleresultsetmetadata = (OracleResultSetMetaData)getInternalMetadata();
                    int j = i + 1;
                    if(oracleresultsetmetadata.getColumnType(j) == 96)
                    {
                        int k = oracleresultsetmetadata.getColumnDisplaySize(j);
                        String s = (String)obj;
                        for(int l = s.length(); l < k; l++)
                            s = (new StringBuilder()).append(s).append(" ").toString();

                    }
                    datum = SQLUtil.makeOracleDatum(connection, obj, oracleresultsetmetadata.getColumnType(j), null, oracleresultsetmetadata.isNCHAR(j));
                }
            }
            setRowBufferAt(i, datum);
        }
    }

    public void updateOracleObject(int i, Datum datum)
        throws SQLException
    {
        synchronized(connection)
        {
            setRowBufferAt(i, datum);
        }
    }

    public void updateROWID(int i, ROWID rowid)
        throws SQLException
    {
        updateOracleObject(i, rowid);
    }

    public void updateNUMBER(int i, NUMBER number)
        throws SQLException
    {
        updateOracleObject(i, number);
    }

    public void updateDATE(int i, DATE date)
        throws SQLException
    {
        updateOracleObject(i, date);
    }

    public void updateINTERVALYM(int i, INTERVALYM intervalym)
        throws SQLException
    {
        updateOracleObject(i, intervalym);
    }

    public void updateINTERVALDS(int i, INTERVALDS intervalds)
        throws SQLException
    {
        updateOracleObject(i, intervalds);
    }

    public void updateTIMESTAMP(int i, TIMESTAMP timestamp)
        throws SQLException
    {
        updateOracleObject(i, timestamp);
    }

    public void updateTIMESTAMPTZ(int i, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        updateOracleObject(i, timestamptz);
    }

    public void updateTIMESTAMPLTZ(int i, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        updateOracleObject(i, timestampltz);
    }

    public void updateARRAY(int i, ARRAY array)
        throws SQLException
    {
        updateOracleObject(i, array);
    }

    public void updateSTRUCT(int i, STRUCT struct)
        throws SQLException
    {
        updateOracleObject(i, struct);
    }

    public void updateOPAQUE(int i, OPAQUE opaque)
        throws SQLException
    {
        updateOracleObject(i, opaque);
    }

    public void updateREF(int i, REF ref)
        throws SQLException
    {
        updateOracleObject(i, ref);
    }

    public void updateCHAR(int i, CHAR char1)
        throws SQLException
    {
        updateOracleObject(i, char1);
    }

    public void updateRAW(int i, RAW raw)
        throws SQLException
    {
        updateOracleObject(i, raw);
    }

    public void updateBLOB(int i, BLOB blob)
        throws SQLException
    {
        updateOracleObject(i, blob);
    }

    public void updateCLOB(int i, CLOB clob)
        throws SQLException
    {
        updateOracleObject(i, clob);
    }

    public void updateBFILE(int i, BFILE bfile)
        throws SQLException
    {
        updateOracleObject(i, bfile);
    }

    public void updateBfile(int i, BFILE bfile)
        throws SQLException
    {
        updateOracleObject(i, bfile);
    }

    public void updateCustomDatum(int i, CustomDatum customdatum)
        throws SQLException
    {
        throw new Error("wanna do datum = ((CustomDatum) x).toDatum(m_comm)");
    }

    public void updateORAData(int i, ORAData oradata)
        throws SQLException
    {
        Datum datum = oradata.toDatum(connection);
        updateOracleObject(i, datum);
    }

    public void updateRef(int i, Ref ref)
        throws SQLException
    {
        updateREF(i, (REF)ref);
    }

    public void updateBlob(int i, Blob blob)
        throws SQLException
    {
        updateBLOB(i, (BLOB)blob);
    }

    public void updateClob(int i, Clob clob)
        throws SQLException
    {
        updateCLOB(i, (CLOB)clob);
    }

    public void updateArray(int i, Array array)
        throws SQLException
    {
        updateARRAY(i, (ARRAY)array);
    }

    int getColumnCount()
        throws SQLException
    {
        if(columnCount == 0)
            if(resultSet instanceof OracleResultSetImpl)
            {
                if(((OracleResultSetImpl)resultSet).statement.accessors != null)
                    columnCount = ((OracleResultSetImpl)resultSet).statement.numberOfDefinePositions;
                else
                    columnCount = getInternalMetadata().getColumnCount();
            } else
            {
                columnCount = ((ScrollableResultSet)resultSet).getColumnCount();
            }
        return columnCount;
    }

    ResultSetMetaData getInternalMetadata()
        throws SQLException
    {
        if(rsetMetaData == null)
            rsetMetaData = resultSet.getMetaData();
        return rsetMetaData;
    }

    private void cancelRowChanges()
        throws SQLException
    {
        synchronized(connection)
        {
            if(isInserting)
                cancelRowInserts();
            if(isUpdating)
                cancelRowUpdates();
        }
    }

    boolean isOnInsertRow()
    {
        return isInserting;
    }

    private void cancelRowInserts()
    {
        if(isInserting)
        {
            isInserting = false;
            clearRowBuffer();
        }
    }

    boolean isUpdatingRow()
    {
        return isUpdating;
    }

    private void clearRowBuffer()
    {
        if(rowBuffer != null)
        {
            for(int i = 0; i < rowBuffer.length; i++)
                rowBuffer[i] = null;

        }
        if(m_nullIndicator != null)
        {
            for(int j = 0; j < m_nullIndicator.length; j++)
                m_nullIndicator[j] = false;

        }
        if(typeInfo != null)
        {
            for(int k = 0; k < typeInfo.length; k++)
            {
                if(typeInfo[k] == null)
                    continue;
                for(int l = 0; l < typeInfo[k].length; l++)
                    typeInfo[k][l] = 0;

            }

        }
        cleanTempLobs();
    }

    private void setRowBufferAt(int i, Datum datum)
        throws SQLException
    {
        setRowBufferAt(i, datum, (int[])null);
    }

    private void setRowBufferAt(int i, Object obj, int ai[])
        throws SQLException
    {
        if(!isInserting)
        {
            if(isBeforeFirst() || isAfterLast() || getRow() == 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            isUpdating = true;
        }
        if(i < 1 || i > getColumnCount() - 1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setRowBufferAt");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(rowBuffer == null)
            rowBuffer = new Object[getColumnCount()];
        if(m_nullIndicator == null)
        {
            m_nullIndicator = new boolean[getColumnCount()];
            for(int j = 0; j < getColumnCount(); j++)
                m_nullIndicator[j] = false;

        }
        if(ai != null)
        {
            if(typeInfo == null)
                typeInfo = new int[getColumnCount()][];
            typeInfo[i] = ai;
        }
        rowBuffer[i] = obj;
        m_nullIndicator[i] = obj == null;
    }

    private Datum getRowBufferDatumAt(int i)
        throws SQLException
    {
        if(i < 1 || i > getColumnCount() - 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        Datum datum = null;
        if(rowBuffer != null)
        {
            Object obj = rowBuffer[i];
            if(obj != null)
                if(obj instanceof Datum)
                {
                    datum = (Datum)obj;
                } else
                {
                    OracleResultSetMetaData oracleresultsetmetadata = (OracleResultSetMetaData)getInternalMetadata();
                    int j = i + 1;
                    datum = SQLUtil.makeOracleDatum(connection, obj, oracleresultsetmetadata.getColumnType(j), null, oracleresultsetmetadata.isNCHAR(j));
                    rowBuffer[i] = datum;
                }
        }
        return datum;
    }

    private Object getRowBufferAt(int i)
        throws SQLException
    {
        if(i < 1 || i > getColumnCount() - 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowBuffer != null)
            return rowBuffer[i];
        else
            return null;
    }

    private boolean isRowBufferUpdatedAt(int i)
    {
        if(rowBuffer == null)
            return false;
        else
            return rowBuffer[i] != null || m_nullIndicator[i];
    }

    private void prepareInsertRowStatement()
        throws SQLException
    {
        if(insertStmt == null)
        {
            PreparedStatement preparedstatement = connection.prepareStatement(((OracleStatement)scrollStmt).sqlObject.getInsertSqlForUpdatableResultSet(this));
            insertStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedstatement).preparedStatement;
            insertStmt.setQueryTimeout(((Statement)scrollStmt).getQueryTimeout());
            if(((OracleStatement)scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing())
                insertStmt.setEscapeProcessing(true);
        }
    }

    private void prepareInsertRowBinds()
        throws SQLException
    {
        int i = 1;
        i = prepareSubqueryBinds(insertStmt, i);
        OracleResultSetMetaData oracleresultsetmetadata = (OracleResultSetMetaData)getInternalMetadata();
        for(int j = 1; j < getColumnCount(); j++)
        {
            Object obj = getRowBufferAt(j);
            if(obj != null)
            {
                if(obj instanceof Reader)
                {
                    if(oracleresultsetmetadata.isNCHAR(j + 1))
                        insertStmt.setFormOfUse(i, (short)2);
                    insertStmt.setCharacterStream((i + j) - 1, (Reader)obj, typeInfo[j][0]);
                    continue;
                }
                if(obj instanceof InputStream)
                {
                    if(typeInfo[j][1] == 2)
                    {
                        insertStmt.setBinaryStream((i + j) - 1, (InputStream)obj, typeInfo[j][0]);
                        continue;
                    }
                    if(typeInfo[j][1] == 1)
                        insertStmt.setAsciiStream((i + j) - 1, (InputStream)obj, typeInfo[j][0]);
                    continue;
                }
                Datum datum = getRowBufferDatumAt(j);
                if(oracleresultsetmetadata.isNCHAR(j + 1))
                    insertStmt.setFormOfUse((i + j) - 1, (short)2);
                insertStmt.setOracleObject((i + j) - 1, datum);
                continue;
            }
            int k = getInternalMetadata().getColumnType(j + 1);
            if(k == 2006 || k == 2002 || k == 2008 || k == 2007 || k == 2003 || k == 2009)
                insertStmt.setNull((i + j) - 1, k, getInternalMetadata().getColumnTypeName(j + 1));
            else
                insertStmt.setNull((i + j) - 1, k);
        }

    }

    private void executeInsertRow()
        throws SQLException
    {
        if(insertStmt.executeUpdate() != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    private int getNumColumnsChanged()
        throws SQLException
    {
        int i = 0;
        if(indexColsChanged == null)
            indexColsChanged = new int[getColumnCount()];
        if(rowBuffer != null)
        {
            for(int j = 1; j < getColumnCount(); j++)
                if(rowBuffer[j] != null || rowBuffer[j] == null && m_nullIndicator[j])
                    indexColsChanged[i++] = j;

        }
        return i;
    }

    private void prepareUpdateRowStatement(int i)
        throws SQLException
    {
        if(updateStmt != null)
            updateStmt.close();
        PreparedStatement preparedstatement = connection.prepareStatement(((OracleStatement)scrollStmt).sqlObject.getUpdateSqlForUpdatableResultSet(this, i, rowBuffer, indexColsChanged));
        updateStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedstatement).preparedStatement;
        updateStmt.setQueryTimeout(((Statement)scrollStmt).getQueryTimeout());
        if(((OracleStatement)scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing())
            updateStmt.setEscapeProcessing(true);
    }

    private void prepareUpdateRowBinds(int i)
        throws SQLException
    {
        int j = 1;
        j = prepareSubqueryBinds(updateStmt, j);
        OracleResultSetMetaData oracleresultsetmetadata = (OracleResultSetMetaData)getInternalMetadata();
        for(int k = 0; k < i; k++)
        {
            int l = indexColsChanged[k];
            Object obj = getRowBufferAt(l);
            if(obj != null)
            {
                if(obj instanceof Reader)
                {
                    if(oracleresultsetmetadata.isNCHAR(l + 1))
                        updateStmt.setFormOfUse(j, (short)2);
                    updateStmt.setCharacterStream(j++, (Reader)obj, typeInfo[l][0]);
                    continue;
                }
                if(obj instanceof InputStream)
                {
                    if(typeInfo[l][1] == 2)
                    {
                        updateStmt.setBinaryStream(j++, (InputStream)obj, typeInfo[l][0]);
                        continue;
                    }
                    if(typeInfo[l][1] == 1)
                        updateStmt.setAsciiStream(j++, (InputStream)obj, typeInfo[l][0]);
                    continue;
                }
                Datum datum = getRowBufferDatumAt(l);
                if(oracleresultsetmetadata.isNCHAR(l + 1))
                    updateStmt.setFormOfUse(j, (short)2);
                updateStmt.setOracleObject(j++, datum);
                continue;
            }
            int i1 = getInternalMetadata().getColumnType(l + 1);
            if(i1 == 2006 || i1 == 2002 || i1 == 2008 || i1 == 2007 || i1 == 2003 || i1 == 2009)
            {
                updateStmt.setNull(j++, i1, getInternalMetadata().getColumnTypeName(l + 1));
                continue;
            }
            if(oracleresultsetmetadata.isNCHAR(l + 1))
                updateStmt.setFormOfUse(j, (short)2);
            updateStmt.setNull(j++, i1);
        }

        prepareCompareSelfBinds(updateStmt, j);
    }

    private void executeUpdateRow()
        throws SQLException
    {
        if(updateStmt.executeUpdate() == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(isCachedRset)
        {
            ((ScrollableResultSet)resultSet).refreshRowsInCache(getRow(), 1, 1000);
            cancelRowUpdates();
        }
        if(updateStmt != null)
        {
            updateStmt.close();
            updateStmt = null;
        }
        break MISSING_BLOCK_LABEL_101;
        Exception exception;
        exception;
        if(updateStmt != null)
        {
            updateStmt.close();
            updateStmt = null;
        }
        throw exception;
    }

    private void prepareDeleteRowStatement()
        throws SQLException
    {
        if(deleteStmt == null)
        {
            PreparedStatement preparedstatement = connection.prepareStatement(((OracleStatement)scrollStmt).sqlObject.getDeleteSqlForUpdatableResultSet(this));
            deleteStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedstatement).preparedStatement;
            deleteStmt.setQueryTimeout(((Statement)scrollStmt).getQueryTimeout());
            if(((OracleStatement)scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing())
                deleteStmt.setEscapeProcessing(true);
        }
    }

    private void prepareDeleteRowBinds()
        throws SQLException
    {
        int i = 1;
        i = prepareSubqueryBinds(deleteStmt, i);
        prepareCompareSelfBinds(deleteStmt, i);
    }

    private void executeDeleteRow()
        throws SQLException
    {
        if(deleteStmt.executeUpdate() == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(isCachedRset)
            ((ScrollableResultSet)resultSet).removeRowInCache(getRow());
    }

    private int prepareCompareSelfBinds(OraclePreparedStatement oraclepreparedstatement, int i)
        throws SQLException
    {
        oraclepreparedstatement.setOracleObject(i, resultSet.getOracleObject(1));
        return i + 1;
    }

    private int prepareSubqueryBinds(OraclePreparedStatement oraclepreparedstatement, int i)
        throws SQLException
    {
        int j = scrollStmt.copyBinds(oraclepreparedstatement, i - 1);
        return j + 1;
    }

    private void setIsNull(int i)
    {
        wasNull = i;
    }

    private void setIsNull(boolean flag)
    {
        if(flag)
            wasNull = 1;
        else
            wasNull = 2;
    }

    public String getCursorName()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

    OracleStatement getOracleStatement()
        throws SQLException
    {
        return resultSet != null ? resultSet.getOracleStatement() : null;
    }

}
