// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   XSAttributeI.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.XSAttribute;

// Referenced classes of package oracle.jdbc.driver:
//            T4CMAREngine, DBConversion

class XSAttributeI extends XSAttribute
{

    String attributeName;
    byte attributeNameBytes[];
    String attributeValue;
    byte attributeValueBytes[];
    String attributeDefaultValue;
    byte attributeDefaultValueBytes[];
    long flag;

    XSAttributeI()
    {
        attributeName = null;
        attributeValue = null;
        attributeDefaultValue = null;
        flag = 0L;
    }

    public void setAttributeName(String s)
        throws SQLException
    {
        attributeName = s;
    }

    void doCharConversion(DBConversion dbconversion)
        throws SQLException
    {
        if(attributeName != null)
            attributeNameBytes = dbconversion.StringToCharBytes(attributeName);
        else
            attributeNameBytes = null;
        if(attributeValue != null)
            attributeValueBytes = dbconversion.StringToCharBytes(attributeValue);
        else
            attributeValueBytes = null;
        if(attributeDefaultValue != null)
            attributeDefaultValueBytes = dbconversion.StringToCharBytes(attributeDefaultValue);
        else
            attributeDefaultValueBytes = null;
    }

    public void setAttributeValue(String s)
        throws SQLException
    {
        attributeValue = s;
    }

    public void setAttributeDefaultValue(String s)
        throws SQLException
    {
        attributeDefaultValue = s;
    }

    public void setFlag(long l)
        throws SQLException
    {
        flag = l;
    }

    public String getAttributeName()
    {
        return attributeName;
    }

    public String getAttributeValue()
    {
        return attributeValue;
    }

    public String getAttributeDefaultValue()
    {
        return attributeDefaultValue;
    }

    public long getFlag()
    {
        return flag;
    }

    void marshal(T4CMAREngine t4cmarengine)
        throws IOException
    {
        if(attributeNameBytes != null)
        {
            t4cmarengine.marshalUB4(attributeNameBytes.length);
            t4cmarengine.marshalCLR(attributeNameBytes, attributeNameBytes.length);
        } else
        {
            t4cmarengine.marshalUB4(0L);
        }
        if(attributeValueBytes != null)
        {
            t4cmarengine.marshalUB4(attributeValueBytes.length);
            t4cmarengine.marshalCLR(attributeValueBytes, attributeValueBytes.length);
        } else
        {
            t4cmarengine.marshalUB4(0L);
        }
        if(attributeDefaultValueBytes != null)
        {
            t4cmarengine.marshalUB4(attributeDefaultValueBytes.length);
            t4cmarengine.marshalCLR(attributeDefaultValueBytes, attributeDefaultValueBytes.length);
        } else
        {
            t4cmarengine.marshalUB4(0L);
        }
        t4cmarengine.marshalUB4(flag);
    }

    static XSAttributeI unmarshal(T4CMAREngine t4cmarengine)
        throws SQLException, IOException
    {
        int ai[] = new int[1];
        String s = null;
        String s1 = null;
        String s2 = null;
        int i = (int)t4cmarengine.unmarshalUB4();
        if(i > 0)
        {
            byte abyte0[] = new byte[i];
            t4cmarengine.unmarshalCLR(abyte0, 0, ai);
            s = t4cmarengine.conv.CharBytesToString(abyte0, ai[0]);
        }
        int j = (int)t4cmarengine.unmarshalUB4();
        if(j > 0)
        {
            byte abyte1[] = new byte[j];
            t4cmarengine.unmarshalCLR(abyte1, 0, ai);
            s1 = t4cmarengine.conv.CharBytesToString(abyte1, ai[0]);
        }
        int k = (int)t4cmarengine.unmarshalUB4();
        if(k > 0)
        {
            byte abyte2[] = new byte[k];
            t4cmarengine.unmarshalCLR(abyte2, 0, ai);
            s2 = t4cmarengine.conv.CharBytesToString(abyte2, ai[0]);
        }
        long l = t4cmarengine.unmarshalUB4();
        XSAttributeI xsattributei = new XSAttributeI();
        xsattributei.setAttributeName(s);
        xsattributei.setAttributeValue(s1);
        xsattributei.setAttributeDefaultValue(s2);
        xsattributei.setFlag(l);
        return xsattributei;
    }
}
