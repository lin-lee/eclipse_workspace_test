// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleStatement.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;
import oracle.jdbc.OracleResultSetCache;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.BLOB;
import oracle.sql.CLOB;

// Referenced classes of package oracle.jdbc.driver:
//            CancelLock, OracleSql, OracleResultSetImpl, OraclePreparedStatement, 
//            Accessor, CharAccessor, LongAccessor, VarcharAccessor, 
//            NumberAccessor, VarnumAccessor, LongRawAccessor, OutRawAccessor, 
//            RawAccessor, BinaryFloatAccessor, BinaryDoubleAccessor, RowidAccessor, 
//            ResultSetAccessor, DateAccessor, BlobAccessor, ClobAccessor, 
//            BfileAccessor, NamedTypeAccessor, RefTypeAccessor, TimestampAccessor, 
//            TimestamptzAccessor, TimestampltzAccessor, IntervalymAccessor, IntervaldsAccessor, 
//            OracleResultSetCache, TypeAccessor, OracleReturnResultSet, AutoKeyInfo, 
//            NTFDCNRegistration, ScrollRsetStatement, PhysicalConnection, OracleInputStream, 
//            DatabaseError, ResultSetUtil, OracleTimeout, OracleResultSet, 
//            OracleStatementWrapper, CRC64, T4CTTIoac

abstract class OracleStatement
    implements oracle.jdbc.internal.OracleStatement, ScrollRsetStatement
{

    static final int PLAIN_STMT = 0;
    static final int PREP_STMT = 1;
    static final int CALL_STMT = 2;
    int cursorId;
    int numberOfDefinePositions;
    int definesBatchSize;
    Accessor accessors[];
    int defineByteSubRange;
    int defineCharSubRange;
    int defineIndicatorSubRange;
    int defineLengthSubRange;
    byte defineBytes[];
    char defineChars[];
    short defineIndicators[];
    boolean described;
    boolean describedWithNames;
    byte defineMetaData[];
    int defineMetaDataSubRange;
    static final int METADATALENGTH = 1;
    int rowsProcessed;
    int cachedDefineByteSize;
    int cachedDefineCharSize;
    int cachedDefineIndicatorSize;
    int cachedDefineMetaDataSize;
    OracleStatement children;
    OracleStatement parent;
    OracleStatement nextChild;
    OracleStatement next;
    OracleStatement prev;
    long c_state;
    int numberOfBindPositions;
    byte bindBytes[];
    char bindChars[];
    short bindIndicators[];
    int bindByteOffset;
    int bindCharOffset;
    int bindIndicatorOffset;
    int bindByteSubRange;
    int bindCharSubRange;
    int bindIndicatorSubRange;
    Accessor outBindAccessors[];
    InputStream parameterStream[][];
    Object userStream[][];
    int firstRowInBatch;
    boolean hasIbtBind;
    byte ibtBindBytes[];
    char ibtBindChars[];
    short ibtBindIndicators[];
    int ibtBindByteOffset;
    int ibtBindCharOffset;
    int ibtBindIndicatorOffset;
    int ibtBindIndicatorSize;
    ByteBuffer nioBuffers[];
    Object lobPrefetchMetaData[];
    boolean hasStream;
    byte tmpByteArray[];
    int sizeTmpByteArray;
    byte tmpBindsByteArray[];
    boolean needToSendOalToFetch;
    int definedColumnType[];
    int definedColumnSize[];
    int definedColumnFormOfUse[];
    T4CTTIoac oacdefSent[];
    int nbPostPonedColumns[];
    int indexOfPostPonedColumn[][];
    boolean aFetchWasDoneDuringDescribe;
    boolean implicitDefineForLobPrefetchDone;
    long checkSum;
    boolean checkSumComputationFailure;
    int accessorByteOffset;
    int accessorCharOffset;
    int accessorShortOffset;
    static final int VALID_ROWS_UNINIT = -999;
    PhysicalConnection connection;
    OracleInputStream streamList;
    OracleInputStream nextStream;
    OracleResultSetImpl currentResultSet;
    boolean processEscapes;
    boolean convertNcharLiterals;
    int queryTimeout;
    int batch;
    int numberOfExecutedElementsInBatch;
    int currentRank;
    boolean bsendBatchInProgress;
    int currentRow;
    int validRows;
    int maxFieldSize;
    int maxRows;
    int totalRowsVisited;
    int rowPrefetch;
    int rowPrefetchInLastFetch;
    int defaultRowPrefetch;
    boolean rowPrefetchChanged;
    int defaultLobPrefetchSize;
    boolean gotLastBatch;
    boolean clearParameters;
    boolean closed;
    boolean sqlStringChanged;
    OracleSql sqlObject;
    boolean needToParse;
    boolean needToPrepareDefineBuffer;
    boolean columnsDefinedByUser;
    oracle.jdbc.internal.SqlKind sqlKind;
    byte sqlKindByte;
    int autoRollback;
    int defaultFetchDirection;
    boolean serverCursor;
    boolean fixedString;
    boolean noMoreUpdateCounts;
    protected CancelLock cancelLock;
    OracleStatementWrapper wrapper;
    static final byte EXECUTE_NONE = -1;
    static final byte EXECUTE_QUERY = 1;
    static final byte EXECUTE_UPDATE = 2;
    static final byte EXECUTE_NORMAL = 3;
    byte executionType;
    OracleResultSet scrollRset;
    OracleResultSetCache rsetCache;
    int userRsetType;
    int realRsetType;
    boolean needToAddIdentifier;
    SQLWarning sqlWarning;
    int cacheState;
    int creationState;
    boolean isOpen;
    int statementType;
    boolean columnSetNull;
    int returnParamMeta[];
    static final int DMLR_METADATA_PREFIX_SIZE = 3;
    static final int DMLR_METADATA_NUM_OF_RETURN_PARAMS = 0;
    static final int DMLR_METADATA_ROW_BIND_BYTES = 1;
    static final int DMLR_METADATA_ROW_BIND_CHARS = 2;
    static final int DMLR_METADATA_TYPE_OFFSET = 0;
    static final int DMLR_METADATA_IS_CHAR_TYPE_OFFSET = 1;
    static final int DMLR_METADATA_BIND_SIZE_OFFSET = 2;
    static final int DMLR_METADATA_FORM_OF_USE_OFFSET = 3;
    static final int DMLR_METADATA_PER_POSITION_SIZE = 4;
    Accessor returnParamAccessors[];
    boolean returnParamsFetched;
    int rowsDmlReturned;
    int numReturnParams;
    byte returnParamBytes[];
    char returnParamChars[];
    short returnParamIndicators[];
    int returnParamRowBytes;
    int returnParamRowChars;
    OracleReturnResultSet returnResultSet;
    boolean isAutoGeneratedKey;
    AutoKeyInfo autoKeyInfo;
    TimeZone defaultTimeZone;
    String defaultTimeZoneName;
    Calendar defaultCalendar;
    Calendar gmtCalendar;
    long inScn;
    int lastIndex;
    Vector m_batchItems;
    ArrayList tempClobsToFree;
    ArrayList tempBlobsToFree;
    ArrayList oldTempClobsToFree;
    ArrayList oldTempBlobsToFree;
    NTFDCNRegistration registration;
    String dcnTableName[];
    long dcnQueryId;
    long _checkSum;
    static final byte IS_UNINITIALIZED = 0;
    static final byte IS_SELECT = 1;
    static final byte IS_DELETE = 2;
    static final byte IS_INSERT = 4;
    static final byte IS_MERGE = 8;
    static final byte IS_UPDATE = 16;
    static final byte IS_PLSQL_BLOCK = 32;
    static final byte IS_CALL_BLOCK = 64;
    static final byte IS_OTHER = -128;
    static final byte IS_DML = 30;
    static final byte IS_PLSQL = 96;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    abstract void doDescribe(boolean flag)
        throws SQLException;

    abstract void executeForDescribe()
        throws SQLException;

    abstract void executeForRows(boolean flag)
        throws SQLException;

    abstract void fetch()
        throws SQLException;

    void continueReadRow(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "continueReadRow is only implemented by the T4C statements.");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    abstract void doClose()
        throws SQLException;

    abstract void closeQuery()
        throws SQLException;

    public int cursorIfRefCursor()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "cursorIfRefCursor not implemented");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void closeCursorOnPlainStatement()
        throws SQLException
    {
    }

    public void setSnapshotSCN(long l)
        throws SQLException
    {
        doSetSnapshotSCN(l);
    }

    void doSetSnapshotSCN(long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    OracleStatement(PhysicalConnection physicalconnection, int i, int j)
        throws SQLException
    {
        this(physicalconnection, i, j, -1, -1);
    }

    OracleStatement(PhysicalConnection physicalconnection, int i, int j, int k, int l)
        throws SQLException
    {
        described = false;
        describedWithNames = false;
        cachedDefineByteSize = 0;
        cachedDefineCharSize = 0;
        cachedDefineIndicatorSize = 0;
        cachedDefineMetaDataSize = 0;
        children = null;
        parent = null;
        nextChild = null;
        hasIbtBind = false;
        nioBuffers = null;
        lobPrefetchMetaData = null;
        sizeTmpByteArray = 0;
        needToSendOalToFetch = false;
        definedColumnType = null;
        definedColumnSize = null;
        definedColumnFormOfUse = null;
        oacdefSent = null;
        nbPostPonedColumns = null;
        indexOfPostPonedColumn = (int[][])null;
        aFetchWasDoneDuringDescribe = false;
        implicitDefineForLobPrefetchDone = false;
        checkSum = 0L;
        checkSumComputationFailure = false;
        accessorByteOffset = 0;
        accessorCharOffset = 0;
        accessorShortOffset = 0;
        numberOfExecutedElementsInBatch = -1;
        bsendBatchInProgress = false;
        rowPrefetchInLastFetch = -1;
        sqlKind = oracle.jdbc.internal.SqlKind.SELECT;
        sqlKindByte = 1;
        fixedString = false;
        noMoreUpdateCounts = false;
        cancelLock = new CancelLock();
        executionType = -1;
        cacheState = 3;
        creationState = 0;
        isOpen = false;
        statementType = 0;
        columnSetNull = false;
        defaultTimeZone = null;
        defaultTimeZoneName = null;
        defaultCalendar = null;
        gmtCalendar = null;
        inScn = 0L;
        m_batchItems = null;
        tempClobsToFree = null;
        tempBlobsToFree = null;
        oldTempClobsToFree = null;
        oldTempBlobsToFree = null;
        registration = null;
        dcnTableName = null;
        dcnQueryId = -1L;
        _checkSum = 0L;
        connection = physicalconnection;
        connection.needLine();
        connection.registerHeartbeat();
        connection.addStatement(this);
        sqlObject = new OracleSql(connection.conversion);
        processEscapes = connection.processEscapes;
        convertNcharLiterals = connection.convertNcharLiterals;
        autoRollback = 2;
        gotLastBatch = false;
        closed = false;
        clearParameters = true;
        serverCursor = false;
        needToAddIdentifier = false;
        defaultFetchDirection = 1000;
        fixedString = connection.getDefaultFixedString();
        rowPrefetchChanged = false;
        rowPrefetch = j;
        defaultRowPrefetch = j;
        if(connection.getVersionNumber() >= 11000)
            defaultLobPrefetchSize = connection.defaultLobPrefetchSize;
        else
            defaultLobPrefetchSize = -1;
        batch = i;
        sqlStringChanged = true;
        needToParse = true;
        needToPrepareDefineBuffer = true;
        columnsDefinedByUser = false;
        if(k != -1 || l != -1)
        {
            realRsetType = 0;
            userRsetType = ResultSetUtil.getRsetTypeCode(k, l);
            needToAddIdentifier = ResultSetUtil.needIdentifier(userRsetType);
        } else
        {
            userRsetType = 1;
            realRsetType = 1;
        }
    }

    void initializeDefineSubRanges()
    {
        defineByteSubRange = 0;
        defineCharSubRange = 0;
        defineIndicatorSubRange = 0;
        defineMetaDataSubRange = 0;
    }

    void prepareDefinePreambles()
    {
    }

    void prepareAccessors()
        throws SQLException
    {
        byte abyte0[] = null;
        char ac[] = null;
        short aword0[] = null;
        boolean flag = false;
        Object obj = null;
        if(accessors == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        int i = 0;
        int j = 0;
        int k = 0;
        for(int l = 0; l < numberOfDefinePositions; l++)
        {
            Accessor accessor = accessors[l];
            if(accessor == null)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            switch(accessor.internalType)
            {
            case 8: // '\b'
            case 24: // '\030'
                hasStream = true;
                break;
            }
            i += accessor.byteLength;
            j += accessor.charLength;
            k++;
        }

        if(streamList != null && !connection.useFetchSizeWithLongColumn)
            rowPrefetch = 1;
        int i1 = rowPrefetch;
        definesBatchSize = i1;
        initializeDefineSubRanges();
        int j1 = k * i1;
        if(defineMetaData == null || defineMetaData.length < j1)
        {
            byte abyte1[];
            if(defineMetaData != null)
                abyte1 = defineMetaData;
            defineMetaData = new byte[j1];
        }
        cachedDefineByteSize = defineByteSubRange + i * i1;
        if(defineBytes == null || defineBytes.length < cachedDefineByteSize)
        {
            if(defineBytes != null)
                abyte0 = defineBytes;
            defineBytes = connection.getByteBuffer(cachedDefineByteSize);
        }
        defineByteSubRange += accessorByteOffset;
        cachedDefineCharSize = defineCharSubRange + j * i1;
        if((defineChars == null || defineChars.length < cachedDefineCharSize) && cachedDefineCharSize > 0)
        {
            if(defineChars != null)
                ac = defineChars;
            defineChars = connection.getCharBuffer(cachedDefineCharSize);
        }
        defineCharSubRange += accessorCharOffset;
        int k1 = numberOfDefinePositions * i1;
        int l1 = defineIndicatorSubRange + k1 + k1;
        if(defineIndicators == null || defineIndicators.length < l1)
        {
            if(defineIndicators != null)
                aword0 = defineIndicators;
            defineIndicators = new short[l1];
        } else
        if(defineIndicators.length >= l1)
        {
            flag = true;
            aword0 = defineIndicators;
        }
        defineIndicatorSubRange += accessorShortOffset;
        int i2 = defineIndicatorSubRange + k1;
        for(int j2 = 0; j2 < numberOfDefinePositions; j2++)
        {
            Accessor accessor1 = accessors[j2];
            accessor1.lengthIndexLastRow = accessor1.lengthIndex;
            accessor1.indicatorIndexLastRow = accessor1.indicatorIndex;
            accessor1.columnIndexLastRow = accessor1.columnIndex;
            accessor1.setOffsets(i1);
            accessor1.lengthIndex = i2;
            accessor1.indicatorIndex = defineIndicatorSubRange;
            accessor1.metaDataIndex = defineMetaDataSubRange;
            accessor1.rowSpaceByte = defineBytes;
            accessor1.rowSpaceChar = defineChars;
            accessor1.rowSpaceIndicator = defineIndicators;
            accessor1.rowSpaceMetaData = defineMetaData;
            defineIndicatorSubRange += i1;
            i2 += i1;
            defineMetaDataSubRange += i1 * 1;
        }

        prepareDefinePreambles();
        if(rowPrefetchInLastFetch != -1 && rowPrefetch != rowPrefetchInLastFetch)
        {
            if(ac == null)
                ac = defineChars;
            if(abyte0 == null)
                abyte0 = defineBytes;
            if(aword0 == null)
                aword0 = defineIndicators;
            saveDefineBuffersIfRequired(ac, abyte0, aword0, flag);
        }
    }

    boolean checkAccessorsUsable()
        throws SQLException
    {
        int i = accessors.length;
        if(i < numberOfDefinePositions)
            return false;
        boolean flag = true;
        boolean flag1 = false;
        boolean flag2 = false;
        for(int j = 0; j < numberOfDefinePositions; j++)
        {
            Accessor accessor = accessors[j];
            if(accessor == null || accessor.externalType == 0)
                flag = false;
            else
                flag1 = true;
        }

        if(flag)
        {
            flag2 = true;
        } else
        {
            if(flag1)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            columnsDefinedByUser = false;
        }
        return flag2;
    }

    void executeMaybeDescribe()
        throws SQLException
    {
        boolean flag;
        boolean flag1;
        flag = true;
        if(rowPrefetchChanged)
        {
            if(streamList == null && rowPrefetch != definesBatchSize)
                needToPrepareDefineBuffer = true;
            rowPrefetchChanged = false;
        }
        if(!needToPrepareDefineBuffer)
            if(accessors == null)
                needToPrepareDefineBuffer = true;
            else
            if(columnsDefinedByUser)
                needToPrepareDefineBuffer = !checkAccessorsUsable();
        flag1 = false;
        try
        {
            cancelLock.enterExecuting();
            if(needToPrepareDefineBuffer)
            {
                if(!columnsDefinedByUser)
                {
                    executeForDescribe();
                    flag1 = true;
                    if(aFetchWasDoneDuringDescribe)
                        flag = false;
                }
                if(needToPrepareDefineBuffer)
                    prepareAccessors();
            }
            int i = accessors.length;
            for(int j = numberOfDefinePositions; j < i; j++)
            {
                Accessor accessor = accessors[j];
                if(accessor != null)
                    accessor.rowSpaceIndicator = null;
            }

            if(flag)
                executeForRows(flag1);
        }
        catch(SQLException sqlexception)
        {
            needToParse = true;
            throw sqlexception;
        }
        cancelLock.exitExecuting();
        break MISSING_BLOCK_LABEL_214;
        Exception exception;
        exception;
        cancelLock.exitExecuting();
        throw exception;
    }

    void adjustGotLastBatch()
    {
    }

    void doExecuteWithTimeout()
        throws SQLException
    {
        cleanOldTempLobs();
        connection.registerHeartbeat();
        rowsProcessed = 0;
        if(!sqlKind.isSELECT())
            break MISSING_BLOCK_LABEL_171;
        if(connection.j2ee13Compliant && executionType == 2)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 129);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        connection.needLine();
        if(!isOpen)
        {
            connection.open(this);
            isOpen = true;
        }
        if(queryTimeout == 0)
            break MISSING_BLOCK_LABEL_149;
        connection.getTimeout().setTimeout(queryTimeout * 1000, this);
        executeMaybeDescribe();
        connection.getTimeout().cancelTimeout();
        break MISSING_BLOCK_LABEL_153;
        Exception exception;
        exception;
        connection.getTimeout().cancelTimeout();
        throw exception;
        executeMaybeDescribe();
        checkValidRowsStatus();
        if(serverCursor)
            adjustGotLastBatch();
        break MISSING_BLOCK_LABEL_501;
        if(connection.j2ee13Compliant && !sqlKind.isPlsqlOrCall() && executionType == 1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 128);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        currentRank++;
        if(currentRank < batch)
            break MISSING_BLOCK_LABEL_501;
        try
        {
            connection.needLine();
            cancelLock.enterExecuting();
            if(!isOpen)
            {
                connection.open(this);
                isOpen = true;
            }
            if(queryTimeout != 0)
                connection.getTimeout().setTimeout(queryTimeout * 1000, this);
            executeForRows(false);
        }
        catch(SQLException sqlexception2)
        {
            needToParse = true;
            if(batch > 1)
            {
                clearBatch();
                int ai[];
                if(numberOfExecutedElementsInBatch != -1 && numberOfExecutedElementsInBatch < batch)
                {
                    ai = new int[numberOfExecutedElementsInBatch];
                    for(int i = 0; i < ai.length; i++)
                        ai[i] = -2;

                } else
                {
                    ai = new int[batch];
                    for(int j = 0; j < ai.length; j++)
                        ai[j] = -3;

                }
                BatchUpdateException batchupdateexception = DatabaseError.createBatchUpdateException(sqlexception2, ai.length, ai);
                batchupdateexception.fillInStackTrace();
                throw batchupdateexception;
            } else
            {
                resetCurrentRowBinders();
                throw sqlexception2;
            }
        }
        if(queryTimeout != 0)
            connection.getTimeout().cancelTimeout();
        currentRank = 0;
        cancelLock.exitExecuting();
        checkValidRowsStatus();
        break MISSING_BLOCK_LABEL_501;
        Exception exception1;
        exception1;
        if(queryTimeout != 0)
            connection.getTimeout().cancelTimeout();
        currentRank = 0;
        cancelLock.exitExecuting();
        checkValidRowsStatus();
        throw exception1;
        SQLException sqlexception3;
        sqlexception3;
        resetOnExceptionDuringExecute();
        throw sqlexception3;
        connection.registerHeartbeat();
        return;
    }

    void resetOnExceptionDuringExecute()
    {
        needToParse = true;
    }

    void resetCurrentRowBinders()
    {
    }

    void open()
        throws SQLException
    {
        if(!isOpen)
        {
            connection.needLine();
            connection.open(this);
            isOpen = true;
        }
    }

    public ResultSet executeQuery(String s)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Object obj = null;
        executionType = 1;
        noMoreUpdateCounts = false;
        ensureOpen();
        checkIfJdbcBatchExists();
        sendBatch();
        hasStream = false;
        sqlObject.initialize(s);
        sqlKind = sqlObject.getSqlKind();
        needToParse = true;
        prepareForNewResults(true, true);
        if(userRsetType == 1)
        {
            doExecuteWithTimeout();
            currentResultSet = new OracleResultSetImpl(connection, this);
            obj = currentResultSet;
        } else
        {
            obj = doScrollStmtExecuteQuery();
            if(obj == null)
            {
                currentResultSet = new OracleResultSetImpl(connection, this);
                obj = currentResultSet;
            }
        }
        executionType = -1;
        break MISSING_BLOCK_LABEL_151;
        Exception exception;
        exception;
        executionType = -1;
        throw exception;
        return ((ResultSet) (obj));
        Exception exception1;
        exception1;
        throw exception1;
    }

    public void closeWithKey(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void close()
        throws SQLException
    {
        synchronized(connection)
        {
            closeOrCache(null);
        }
    }

    protected void closeOrCache(String s)
        throws SQLException
    {
        if(closed)
            return;
        if(connection.lifecycle == 2)
            connection.needLineUnchecked();
        else
            connection.needLine();
        if(statementType != 0 && cacheState != 0 && cacheState != 3 && connection.isStatementCacheInitialized())
        {
            if(s == null)
            {
                if(connection.getImplicitCachingEnabled())
                {
                    connection.cacheImplicitStatement((OraclePreparedStatement)this, sqlObject.getOriginalSql(), statementType, userRsetType);
                } else
                {
                    cacheState = 0;
                    hardClose();
                }
            } else
            if(connection.getExplicitCachingEnabled())
            {
                connection.cacheExplicitStatement((OraclePreparedStatement)this, s);
            } else
            {
                cacheState = 0;
                hardClose();
            }
        } else
        {
            hardClose();
        }
    }

    protected void hardClose()
        throws SQLException
    {
        hardClose(true);
    }

    private void hardClose(boolean flag)
        throws SQLException
    {
        alwaysOnClose();
        describedWithNames = false;
        described = false;
        connection.removeStatement(this);
        cleanupDefines();
        if(isOpen && flag && (connection.lifecycle == 1 || connection.lifecycle == 16 || connection.lifecycle == 2))
        {
            connection.registerHeartbeat();
            doClose();
            isOpen = false;
        }
        sqlObject = null;
    }

    protected void alwaysOnClose()
        throws SQLException
    {
        OracleStatement oraclestatement1;
        for(OracleStatement oraclestatement = children; oraclestatement != null; oraclestatement = oraclestatement1)
        {
            oraclestatement1 = oraclestatement.nextChild;
            oraclestatement.close();
        }

        if(parent != null)
            parent.removeChild(this);
        closed = true;
        if(connection.lifecycle == 1 || connection.lifecycle == 2)
        {
            if(currentResultSet != null)
            {
                currentResultSet.internal_close(false);
                currentResultSet = null;
            }
            if(scrollRset != null)
            {
                scrollRset.close();
                scrollRset = null;
            }
            if(returnResultSet != null)
            {
                returnResultSet.close();
                returnResultSet = null;
            }
        }
        clearWarnings();
        m_batchItems = null;
    }

    void closeLeaveCursorOpen()
        throws SQLException
    {
label0:
        {
            synchronized(connection)
            {
                if(!closed)
                    break label0;
            }
            return;
        }
        hardClose(false);
        physicalconnection;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
    }

    public int executeUpdate(String s)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        setNonAutoKey();
        return executeUpdateInternal(s);
        Exception exception;
        exception;
        throw exception;
    }

    int executeUpdateInternal(String s)
        throws SQLException
    {
        int i;
        if(executionType == -1)
            executionType = 2;
        noMoreUpdateCounts = false;
        ensureOpen();
        checkIfJdbcBatchExists();
        sendBatch();
        hasStream = false;
        sqlObject.initialize(s);
        sqlKind = sqlObject.getSqlKind();
        needToParse = true;
        prepareForNewResults(true, true);
        if(userRsetType == 1)
            doExecuteWithTimeout();
        else
            doScrollStmtExecuteQuery();
        i = validRows;
        executionType = -1;
        return i;
        Exception exception;
        exception;
        executionType = -1;
        throw exception;
    }

    public boolean execute(String s)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        setNonAutoKey();
        return executeInternal(s);
        Exception exception;
        exception;
        throw exception;
    }

    boolean executeInternal(String s)
        throws SQLException
    {
        boolean flag;
        executionType = 3;
        checkSum = 0L;
        checkSumComputationFailure = false;
        noMoreUpdateCounts = false;
        ensureOpen();
        checkIfJdbcBatchExists();
        sendBatch();
        hasStream = false;
        sqlObject.initialize(s);
        sqlKind = sqlObject.getSqlKind();
        needToParse = true;
        prepareForNewResults(true, true);
        if(userRsetType == 1)
            doExecuteWithTimeout();
        else
            doScrollStmtExecuteQuery();
        flag = sqlKind.isSELECT();
        executionType = -1;
        return flag;
        Exception exception;
        exception;
        executionType = -1;
        throw exception;
    }

    int getNumberOfColumns()
        throws SQLException
    {
        ensureOpen();
        if(!described)
            synchronized(connection)
            {
                doDescribe(false);
                described = true;
            }
        return numberOfDefinePositions;
    }

    Accessor[] getDescription()
        throws SQLException
    {
        ensureOpen();
        if(!described)
            synchronized(connection)
            {
                doDescribe(false);
                described = true;
            }
        return accessors;
    }

    Accessor[] getDescriptionWithNames()
        throws SQLException
    {
        ensureOpen();
        if(!describedWithNames)
            synchronized(connection)
            {
                doDescribe(true);
                described = true;
                describedWithNames = true;
            }
        return accessors;
    }

    public oracle.jdbc.internal.SqlKind getSqlKind()
        throws SQLException
    {
        return sqlObject.getSqlKind();
    }

    public void clearDefines()
        throws SQLException
    {
        synchronized(connection)
        {
            freeLine();
            streamList = null;
            columnsDefinedByUser = false;
            needToPrepareDefineBuffer = true;
            numberOfDefinePositions = 0;
            definesBatchSize = 0;
            described = false;
            describedWithNames = false;
            cleanupDefines();
        }
    }

    void reparseOnRedefineIfNeeded()
        throws SQLException
    {
    }

    void defineColumnTypeInternal(int i, int j, int k, boolean flag, String s)
        throws SQLException
    {
        defineColumnTypeInternal(i, j, k, (short)1, flag, s);
    }

    void defineColumnTypeInternal(int i, int j, int k, short word0, boolean flag, String s)
        throws SQLException
    {
        if(connection.disableDefinecolumntype)
            return;
        if(i < 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(j == 0)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int l = i - 1;
        int i1 = maxFieldSize <= 0 ? -1 : maxFieldSize;
        if(flag)
        {
            if(j == 1 || j == 12 || j == -15 || j == -9)
                sqlWarning = DatabaseError.addSqlWarning(sqlWarning, 108);
        } else
        {
            if(k < 0)
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
            if(i1 == -1 && k > 0 || i1 > 0 && k < i1)
                i1 = k;
        }
        if(currentResultSet != null && !currentResultSet.closed)
        {
            SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
            sqlexception3.fillInStackTrace();
            throw sqlexception3;
        }
        if(!columnsDefinedByUser)
        {
            clearDefines();
            columnsDefinedByUser = true;
        }
        if(numberOfDefinePositions < i)
        {
            if(accessors == null || accessors.length < i)
            {
                Accessor aaccessor[] = new Accessor[i << 1];
                if(accessors != null)
                    System.arraycopy(accessors, 0, aaccessor, 0, numberOfDefinePositions);
                accessors = aaccessor;
            }
            numberOfDefinePositions = i;
        }
        switch(j)
        {
        case -16: 
        case -15: 
        case -9: 
        case 2011: 
            word0 = 2;
            break;

        case 2009: 
            s = "SYS.XMLTYPE";
            break;
        }
        int j1 = getInternalType(j);
        if((j1 == 109 || j1 == 111) && (s == null || s.equals("")))
        {
            SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Invalid arguments");
            sqlexception4.fillInStackTrace();
            throw sqlexception4;
        }
        Accessor accessor = accessors[l];
        boolean flag1 = true;
        if(accessor != null)
        {
            int k1 = accessor.useForDataAccessIfPossible(j1, j, i1, s);
            if(k1 == 0)
            {
                word0 = accessor.formOfUse;
                accessor = null;
                reparseOnRedefineIfNeeded();
            } else
            if(k1 == 1)
            {
                accessor = null;
                reparseOnRedefineIfNeeded();
            } else
            if(k1 == 2)
                flag1 = false;
        }
        if(flag1)
            needToPrepareDefineBuffer = true;
        if(accessor == null)
        {
            accessors[l] = allocateAccessor(j1, j, i, i1, word0, s, false);
            described = false;
            describedWithNames = false;
        }
    }

    Accessor allocateAccessor(int i, int j, int k, int l, short word0, String s, boolean flag)
        throws SQLException
    {
        switch(i)
        {
        case 96: // '`'
            if(flag && s != null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception.fillInStackTrace();
                throw sqlexception;
            } else
            {
                return new CharAccessor(this, l, word0, j, flag);
            }

        case 8: // '\b'
            if(flag && s != null)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            if(!flag)
                return new LongAccessor(this, k, l, word0, j);
            // fall through

        case 1: // '\001'
            if(flag && s != null)
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            } else
            {
                return new VarcharAccessor(this, l, word0, j, flag);
            }

        case 2: // '\002'
            if(flag && s != null)
            {
                SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception3.fillInStackTrace();
                throw sqlexception3;
            } else
            {
                return new NumberAccessor(this, l, word0, j, flag);
            }

        case 6: // '\006'
            if(flag && s != null)
            {
                SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception4.fillInStackTrace();
                throw sqlexception4;
            } else
            {
                return new VarnumAccessor(this, l, word0, j, flag);
            }

        case 24: // '\030'
            if(flag && s != null)
            {
                SQLException sqlexception5 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception5.fillInStackTrace();
                throw sqlexception5;
            }
            if(!flag)
                return new LongRawAccessor(this, k, l, word0, j);
            // fall through

        case 23: // '\027'
            if(flag && s != null)
            {
                SQLException sqlexception6 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception6.fillInStackTrace();
                throw sqlexception6;
            }
            if(flag)
                return new OutRawAccessor(this, l, word0, j);
            else
                return new RawAccessor(this, l, word0, j, false);

        case 100: // 'd'
            if(flag && s != null)
            {
                SQLException sqlexception7 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception7.fillInStackTrace();
                throw sqlexception7;
            } else
            {
                return new BinaryFloatAccessor(this, l, word0, j, flag);
            }

        case 101: // 'e'
            if(flag && s != null)
            {
                SQLException sqlexception8 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception8.fillInStackTrace();
                throw sqlexception8;
            } else
            {
                return new BinaryDoubleAccessor(this, l, word0, j, flag);
            }

        case 104: // 'h'
            if(flag && s != null)
            {
                SQLException sqlexception9 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception9.fillInStackTrace();
                throw sqlexception9;
            }
            if(sqlKind == oracle.jdbc.internal.SqlKind.CALL_BLOCK)
            {
                l = 18;
                VarcharAccessor varcharaccessor = new VarcharAccessor(this, l, word0, j, flag);
                varcharaccessor.definedColumnType = -8;
                return varcharaccessor;
            } else
            {
                return new RowidAccessor(this, l, word0, j, flag);
            }

        case 102: // 'f'
            if(flag && s != null)
            {
                SQLException sqlexception10 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception10.fillInStackTrace();
                throw sqlexception10;
            } else
            {
                return new ResultSetAccessor(this, l, word0, j, flag);
            }

        case 12: // '\f'
            if(flag && s != null)
            {
                SQLException sqlexception11 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception11.fillInStackTrace();
                throw sqlexception11;
            } else
            {
                return new DateAccessor(this, l, word0, j, flag);
            }

        case 113: // 'q'
            if(flag && s != null)
            {
                SQLException sqlexception12 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception12.fillInStackTrace();
                throw sqlexception12;
            }
            BlobAccessor blobaccessor = new BlobAccessor(this, -1, word0, j, flag);
            if(!flag)
                blobaccessor.lobPrefetchSizeForThisColumn = l;
            return blobaccessor;

        case 112: // 'p'
            if(flag && s != null)
            {
                SQLException sqlexception13 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception13.fillInStackTrace();
                throw sqlexception13;
            }
            ClobAccessor clobaccessor = new ClobAccessor(this, -1, word0, j, flag);
            if(!flag)
                clobaccessor.lobPrefetchSizeForThisColumn = l;
            return clobaccessor;

        case 114: // 'r'
            if(flag && s != null)
            {
                SQLException sqlexception14 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception14.fillInStackTrace();
                throw sqlexception14;
            } else
            {
                BfileAccessor bfileaccessor = new BfileAccessor(this, -1, word0, j, flag);
                return bfileaccessor;
            }

        case 109: // 'm'
            if(s == null)
            {
                if(flag)
                {
                    SQLException sqlexception15 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                    sqlexception15.fillInStackTrace();
                    throw sqlexception15;
                } else
                {
                    SQLException sqlexception16 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
                    sqlexception16.fillInStackTrace();
                    throw sqlexception16;
                }
            } else
            {
                NamedTypeAccessor namedtypeaccessor = new NamedTypeAccessor(this, s, word0, j, flag);
                namedtypeaccessor.initMetadata();
                return namedtypeaccessor;
            }

        case 111: // 'o'
            if(s == null)
            {
                if(flag)
                {
                    SQLException sqlexception17 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                    sqlexception17.fillInStackTrace();
                    throw sqlexception17;
                } else
                {
                    SQLException sqlexception18 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
                    sqlexception18.fillInStackTrace();
                    throw sqlexception18;
                }
            } else
            {
                RefTypeAccessor reftypeaccessor = new RefTypeAccessor(this, s, word0, j, flag);
                reftypeaccessor.initMetadata();
                return reftypeaccessor;
            }

        case 180: 
            if(flag && s != null)
            {
                SQLException sqlexception19 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception19.fillInStackTrace();
                throw sqlexception19;
            } else
            {
                return new TimestampAccessor(this, l, word0, j, flag);
            }

        case 181: 
            if(flag && s != null)
            {
                SQLException sqlexception20 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception20.fillInStackTrace();
                throw sqlexception20;
            } else
            {
                return new TimestamptzAccessor(this, l, word0, j, flag);
            }

        case 231: 
            if(flag && s != null)
            {
                SQLException sqlexception21 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception21.fillInStackTrace();
                throw sqlexception21;
            } else
            {
                return new TimestampltzAccessor(this, l, word0, j, flag);
            }

        case 182: 
            if(flag && s != null)
            {
                SQLException sqlexception22 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception22.fillInStackTrace();
                throw sqlexception22;
            } else
            {
                return new IntervalymAccessor(this, l, word0, j, flag);
            }

        case 183: 
            if(flag && s != null)
            {
                SQLException sqlexception23 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception23.fillInStackTrace();
                throw sqlexception23;
            } else
            {
                return new IntervaldsAccessor(this, l, word0, j, flag);
            }

        case 995: 
            SQLException sqlexception24 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
            sqlexception24.fillInStackTrace();
            throw sqlexception24;

        default:
            SQLException sqlexception25 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception25.fillInStackTrace();
            throw sqlexception25;
        }
    }

    public void defineColumnType(int i, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            defineColumnTypeInternal(i, j, -1, true, null);
        }
    }

    public void defineColumnType(int i, int j, int k)
        throws SQLException
    {
        defineColumnTypeInternal(i, j, k, false, null);
    }

    public void defineColumnType(int i, int j, int k, short word0)
        throws SQLException
    {
        defineColumnTypeInternal(i, j, k, word0, false, null);
    }

    /**
     * @deprecated Method defineColumnTypeBytes is deprecated
     */

    public void defineColumnTypeBytes(int i, int j, int k)
        throws SQLException
    {
        synchronized(connection)
        {
            defineColumnTypeInternal(i, j, k, false, null);
        }
    }

    /**
     * @deprecated Method defineColumnTypeChars is deprecated
     */

    public void defineColumnTypeChars(int i, int j, int k)
        throws SQLException
    {
        defineColumnTypeInternal(i, j, k, false, null);
    }

    public void defineColumnType(int i, int j, String s)
        throws SQLException
    {
        synchronized(connection)
        {
            defineColumnTypeInternal(i, j, -1, true, s);
        }
    }

    void setCursorId(int i)
        throws SQLException
    {
        cursorId = i;
    }

    void setPrefetchInternal(int i, boolean flag, boolean flag1)
        throws SQLException
    {
        if(flag)
        {
            if(i <= 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        {
            if(i < 0)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchSize");
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            if(i == 0)
                i = connection.getDefaultRowPrefetch();
        }
        if(flag1)
        {
            if(i != defaultRowPrefetch)
            {
                defaultRowPrefetch = i;
                if(currentResultSet == null || currentResultSet.closed)
                    rowPrefetchChanged = true;
            }
        } else
        if(i != rowPrefetch && streamList == null)
        {
            rowPrefetch = i;
            rowPrefetchChanged = true;
        }
    }

    public void setRowPrefetch(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            setPrefetchInternal(i, true, true);
        }
    }

    public void setLobPrefetchSize(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            if(i < -1)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            defaultLobPrefetchSize = i;
        }
    }

    public int getLobPrefetchSize()
    {
        return defaultLobPrefetchSize;
    }

    int getPrefetchInternal(boolean flag)
    {
        int i = flag ? defaultRowPrefetch : rowPrefetch;
        return i;
    }

    public int getRowPrefetch()
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getPrefetchInternal(true);
        Exception exception;
        exception;
        throw exception;
    }

    public void setFixedString(boolean flag)
    {
        fixedString = flag;
    }

    public boolean getFixedString()
    {
        return fixedString;
    }

    void check_row_prefetch_changed()
        throws SQLException
    {
        if(rowPrefetchChanged)
        {
            if(streamList == null)
            {
                prepareAccessors();
                needToPrepareDefineBuffer = true;
            }
            rowPrefetchChanged = false;
        }
    }

    void setDefinesInitialized(boolean flag)
    {
    }

    void printState(String s)
        throws SQLException
    {
    }

    void checkValidRowsStatus()
        throws SQLException
    {
        if(validRows == -2)
        {
            validRows = 1;
            connection.holdLine(this);
            for(OracleInputStream oracleinputstream = streamList; oracleinputstream != null; oracleinputstream = oracleinputstream.nextStream)
            {
                if(oracleinputstream.hasBeenOpen)
                    oracleinputstream = oracleinputstream.accessor.initForNewRow();
                oracleinputstream.closed = false;
                oracleinputstream.hasBeenOpen = true;
            }

            nextStream = streamList;
        } else
        if(sqlKind.isSELECT())
        {
            if(validRows < rowPrefetch)
                gotLastBatch = true;
        } else
        if(!sqlKind.isPlsqlOrCall())
            rowsProcessed = validRows;
    }

    void cleanupDefines()
    {
        if(accessors != null)
        {
            for(int i = 0; i < accessors.length; i++)
                accessors[i] = null;

        }
        accessors = null;
        connection.cacheBuffer(defineBytes);
        defineBytes = null;
        connection.cacheBuffer(defineChars);
        defineChars = null;
        defineIndicators = null;
        defineMetaData = null;
    }

    public int getMaxFieldSize()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return maxFieldSize;
        Exception exception;
        exception;
        throw exception;
    }

    public void setMaxFieldSize(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            if(i < 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            maxFieldSize = i;
        }
    }

    public int getMaxRows()
        throws SQLException
    {
        return maxRows;
    }

    public void setMaxRows(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            if(i < 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            maxRows = i;
        }
    }

    public void setEscapeProcessing(boolean flag)
        throws SQLException
    {
        synchronized(connection)
        {
            processEscapes = flag;
        }
    }

    public int getQueryTimeout()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return queryTimeout;
        Exception exception;
        exception;
        throw exception;
    }

    public void setQueryTimeout(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            if(i < 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            queryTimeout = i;
        }
    }

    public void cancel()
        throws SQLException
    {
        doCancel();
    }

    boolean doCancel()
        throws SQLException
    {
        boolean flag;
        flag = false;
        if(closed)
            return flag;
        if(connection.statementHoldingLine != null)
        {
            freeLine();
            break MISSING_BLOCK_LABEL_73;
        }
        if(!cancelLock.enterCanceling())
            break MISSING_BLOCK_LABEL_71;
        flag = true;
        connection.cancelOperationOnServer(true);
        cancelLock.exitCanceling();
        break MISSING_BLOCK_LABEL_73;
        Exception exception;
        exception;
        cancelLock.exitCanceling();
        throw exception;
        return flag;
        for(OracleStatement oraclestatement = children; oraclestatement != null; oraclestatement = oraclestatement.nextChild)
            flag = flag || oraclestatement.doCancel();

        connection.releaseLineForCancel();
        return flag;
    }

    public SQLWarning getWarnings()
        throws SQLException
    {
        return sqlWarning;
    }

    public void clearWarnings()
        throws SQLException
    {
        sqlWarning = null;
    }

    void foundPlsqlCompilerWarning()
        throws SQLException
    {
        SQLWarning sqlwarning = DatabaseError.addSqlWarning(sqlWarning, "Found Plsql compiler warnings.", 24439);
        if(sqlWarning != null)
            sqlWarning.setNextWarning(sqlwarning);
        else
            sqlWarning = sqlwarning;
    }

    public void setCursorName(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSet getResultSet()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(userRsetType != 1) goto _L2; else goto _L1
_L1:
        if(sqlKind.isSELECT())
        {
            if(currentResultSet == null)
                currentResultSet = new OracleResultSetImpl(connection, this);
            return currentResultSet;
        }
          goto _L3
_L2:
        scrollRset;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L3:
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public int getUpdateCount()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        int i = -1;
        static class _cls1
        {

            static final int $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[];

            static 
            {
                $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind = new int[oracle.jdbc.internal.SqlKind.values().length];
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.SqlKind.UNINITIALIZED.ordinal()] = 1;
                }
                catch(NoSuchFieldError nosuchfielderror) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.SqlKind.SELECT_FOR_UPDATE.ordinal()] = 2;
                }
                catch(NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.SqlKind.SELECT.ordinal()] = 3;
                }
                catch(NoSuchFieldError nosuchfielderror2) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.SqlKind.ALTER_SESSION.ordinal()] = 4;
                }
                catch(NoSuchFieldError nosuchfielderror3) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.SqlKind.OTHER.ordinal()] = 5;
                }
                catch(NoSuchFieldError nosuchfielderror4) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.SqlKind.PLSQL_BLOCK.ordinal()] = 6;
                }
                catch(NoSuchFieldError nosuchfielderror5) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.SqlKind.CALL_BLOCK.ordinal()] = 7;
                }
                catch(NoSuchFieldError nosuchfielderror6) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.SqlKind.DELETE.ordinal()] = 8;
                }
                catch(NoSuchFieldError nosuchfielderror7) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.SqlKind.INSERT.ordinal()] = 9;
                }
                catch(NoSuchFieldError nosuchfielderror8) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.SqlKind.MERGE.ordinal()] = 10;
                }
                catch(NoSuchFieldError nosuchfielderror9) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.SqlKind.UPDATE.ordinal()] = 11;
                }
                catch(NoSuchFieldError nosuchfielderror10) { }
            }
        }

        switch(_cls1..SwitchMap.oracle.jdbc.internal.OracleStatement.SqlKind[sqlKind.ordinal()])
        {
        case 4: // '\004'
        case 5: // '\005'
            if(!noMoreUpdateCounts)
                i = rowsProcessed;
            noMoreUpdateCounts = true;
            break;

        case 6: // '\006'
        case 7: // '\007'
            noMoreUpdateCounts = true;
            break;

        case 8: // '\b'
        case 9: // '\t'
        case 10: // '\n'
        case 11: // '\013'
            if(!noMoreUpdateCounts)
                i = rowsProcessed;
            noMoreUpdateCounts = true;
            break;
        }
        return i;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean getMoreResults()
        throws SQLException
    {
        return false;
    }

    public int sendBatch()
        throws SQLException
    {
        return 0;
    }

    void prepareForNewResults(boolean flag, boolean flag1)
        throws SQLException
    {
        clearWarnings();
        if(streamList != null)
        {
            for(; nextStream != null; nextStream = nextStream.nextStream)
                try
                {
                    nextStream.close();
                }
                catch(IOException ioexception)
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }

            if(flag1)
            {
                OracleInputStream oracleinputstream = streamList;
                OracleInputStream oracleinputstream1 = null;
                streamList = null;
                for(; oracleinputstream != null; oracleinputstream = oracleinputstream.nextStream)
                {
                    if(oracleinputstream.hasBeenOpen)
                        continue;
                    if(oracleinputstream1 == null)
                        streamList = oracleinputstream;
                    else
                        oracleinputstream1.nextStream = oracleinputstream;
                    oracleinputstream1 = oracleinputstream;
                }

            }
        }
        if(currentResultSet != null)
        {
            currentResultSet.internal_close(true);
            currentResultSet = null;
        }
        currentRow = -1;
        checkSum = 0L;
        checkSumComputationFailure = false;
        validRows = 0;
        if(flag)
            totalRowsVisited = 0;
        gotLastBatch = false;
        if(needToParse && !columnsDefinedByUser)
        {
            if(flag1 && numberOfDefinePositions != 0)
                numberOfDefinePositions = 0;
            needToPrepareDefineBuffer = true;
        }
        if(flag && rowPrefetch != defaultRowPrefetch && streamList == null)
        {
            rowPrefetch = defaultRowPrefetch;
            rowPrefetchChanged = true;
        }
    }

    void reopenStreams()
        throws SQLException
    {
        for(OracleInputStream oracleinputstream = streamList; oracleinputstream != null; oracleinputstream = oracleinputstream.nextStream)
        {
            if(oracleinputstream.hasBeenOpen)
                oracleinputstream = oracleinputstream.accessor.initForNewRow();
            oracleinputstream.closed = false;
            oracleinputstream.hasBeenOpen = true;
        }

        nextStream = streamList;
    }

    void endOfResultSet(boolean flag)
        throws SQLException
    {
        if(!flag)
            prepareForNewResults(false, false);
        clearDefines();
        rowPrefetchInLastFetch = -1;
    }

    boolean wasNullValue()
        throws SQLException
    {
        if(lastIndex == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(sqlKind.isSELECT())
            return accessors[lastIndex - 1].isNull(currentRow);
        else
            return outBindAccessors[lastIndex - 1].isNull(currentRank);
    }

    int getColumnIndex(String s)
        throws SQLException
    {
        ensureOpen();
        if(!describedWithNames)
            synchronized(connection)
            {
                doDescribe(true);
                described = true;
                describedWithNames = true;
            }
        for(int i = 0; i < numberOfDefinePositions; i++)
            if(accessors[i].columnName.equalsIgnoreCase(s))
                return i + 1;

        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    int getJDBCType(int i)
        throws SQLException
    {
        int j = 0;
        switch(i)
        {
        case 6: // '\006'
            j = 2;
            break;

        case 100: // 'd'
            j = 100;
            break;

        case 101: // 'e'
            j = 101;
            break;

        case 999: 
            j = 999;
            break;

        case 96: // '`'
            j = 1;
            break;

        case 1: // '\001'
            j = 12;
            break;

        case 8: // '\b'
            j = -1;
            break;

        case 12: // '\f'
            j = 91;
            break;

        case 180: 
            j = 93;
            break;

        case 181: 
            j = -101;
            break;

        case 231: 
            j = -102;
            break;

        case 182: 
            j = -103;
            break;

        case 183: 
            j = -104;
            break;

        case 23: // '\027'
            j = -2;
            break;

        case 24: // '\030'
            j = -4;
            break;

        case 104: // 'h'
            j = -8;
            break;

        case 113: // 'q'
            j = 2004;
            break;

        case 112: // 'p'
            j = 2005;
            break;

        case 114: // 'r'
            j = -13;
            break;

        case 102: // 'f'
            j = -10;
            break;

        case 109: // 'm'
            j = 2002;
            break;

        case 111: // 'o'
            j = 2006;
            break;

        case 998: 
            j = -14;
            break;

        case 995: 
            j = 0;
            break;

        default:
            j = i;
            break;
        }
        return j;
    }

    int getInternalType(int i)
        throws SQLException
    {
        char c = '\0';
        switch(i)
        {
        case -7: 
        case -6: 
        case -5: 
        case 2: // '\002'
        case 3: // '\003'
        case 4: // '\004'
        case 5: // '\005'
        case 6: // '\006'
        case 7: // '\007'
        case 8: // '\b'
            c = '\006';
            break;

        case 100: // 'd'
            c = 'd';
            break;

        case 101: // 'e'
            c = 'e';
            break;

        case 999: 
            c = '\u03E7';
            break;

        case 1: // '\001'
            c = '`';
            break;

        case -15: 
        case -9: 
        case 12: // '\f'
            c = '\001';
            break;

        case -16: 
        case -1: 
            c = '\b';
            break;

        case 91: // '['
        case 92: // '\\'
            c = '\f';
            break;

        case -100: 
        case 93: // ']'
            c = '\264';
            break;

        case -101: 
            c = '\265';
            break;

        case -102: 
            c = '\347';
            break;

        case -103: 
            c = '\266';
            break;

        case -104: 
            c = '\267';
            break;

        case -3: 
        case -2: 
            c = '\027';
            break;

        case -4: 
            c = '\030';
            break;

        case -8: 
            c = 'h';
            break;

        case 2004: 
            c = 'q';
            break;

        case 2005: 
        case 2011: 
            c = 'p';
            break;

        case -13: 
            c = 'r';
            break;

        case -10: 
            c = 'f';
            break;

        case 2002: 
        case 2003: 
        case 2007: 
        case 2008: 
        case 2009: 
            c = 'm';
            break;

        case 2006: 
            c = 'o';
            break;

        case -14: 
            c = '\u03E6';
            break;

        case 70: // 'F'
            c = '\001';
            break;

        case 0: // '\0'
            c = '\u03E3';
            break;

        default:
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, Integer.toString(i));
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return c;
    }

    void describe()
        throws SQLException
    {
        synchronized(connection)
        {
            ensureOpen();
            if(!described)
                doDescribe(false);
        }
    }

    void freeLine()
        throws SQLException
    {
        if(streamList != null)
            for(; nextStream != null; nextStream = nextStream.nextStream)
                try
                {
                    nextStream.close();
                }
                catch(IOException ioexception)
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }

    }

    void closeUsedStreams(int i)
        throws SQLException
    {
        for(; nextStream != null && nextStream.columnIndex < i; nextStream = nextStream.nextStream)
            try
            {
                nextStream.close();
            }
            catch(IOException ioexception)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }

    }

    final void ensureOpen()
        throws SQLException
    {
        if(connection.lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(closed)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return;
        }
    }

    void allocateTmpByteArray()
    {
    }

    public void setFetchDirection(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            if(i == 1000)
                defaultFetchDirection = i;
            else
            if(i == 1001 || i == 1002)
            {
                defaultFetchDirection = 1000;
                sqlWarning = DatabaseError.addSqlWarning(sqlWarning, 87);
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
    }

    public int getFetchDirection()
        throws SQLException
    {
        return defaultFetchDirection;
    }

    public void setFetchSize(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            setPrefetchInternal(i, false, true);
        }
    }

    public int getFetchSize()
        throws SQLException
    {
        return getPrefetchInternal(true);
    }

    public int getResultSetConcurrency()
        throws SQLException
    {
        return ResultSetUtil.getUpdateConcurrency(userRsetType);
    }

    public int getResultSetType()
        throws SQLException
    {
        return ResultSetUtil.getScrollType(userRsetType);
    }

    public Connection getConnection()
        throws SQLException
    {
        return connection.getWrapper();
    }

    public void setResultSetCache(OracleResultSetCache oracleresultsetcache)
        throws SQLException
    {
        synchronized(connection)
        {
            try
            {
                if(oracleresultsetcache == null)
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                if(rsetCache != null)
                    rsetCache.close();
                rsetCache = oracleresultsetcache;
            }
            catch(IOException ioexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }
    }

    public void setResultSetCache(oracle.jdbc.driver.OracleResultSetCache oracleresultsetcache)
        throws SQLException
    {
        synchronized(connection)
        {
            setResultSetCache(((OracleResultSetCache) (oracleresultsetcache)));
        }
    }

    public oracle.jdbc.driver.OracleResultSetCache getResultSetCache()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return (oracle.jdbc.driver.OracleResultSetCache)rsetCache;
        Exception exception;
        exception;
        throw exception;
    }

    boolean isOracleBatchStyle()
    {
        return false;
    }

    void initBatch()
    {
    }

    int getBatchSize()
    {
        if(m_batchItems == null)
            return 0;
        else
            return m_batchItems.size();
    }

    void addBatchItem(String s)
    {
        if(m_batchItems == null)
            m_batchItems = new Vector();
        m_batchItems.addElement(s);
    }

    String getBatchItem(int i)
    {
        return (String)m_batchItems.elementAt(i);
    }

    void clearBatchItems()
    {
        m_batchItems.removeAllElements();
    }

    void checkIfJdbcBatchExists()
        throws SQLException
    {
        if(getBatchSize() > 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void addBatch(String s)
        throws SQLException
    {
        synchronized(connection)
        {
            addBatchItem(s);
        }
    }

    public void clearBatch()
        throws SQLException
    {
        synchronized(connection)
        {
            clearBatchItems();
        }
    }

    public int[] executeBatch()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        int i;
        int j;
        cleanOldTempLobs();
        i = 0;
        j = getBatchSize();
        checkSum = 0L;
        checkSumComputationFailure = false;
        if(j <= 0)
            return new int[0];
        int ai[];
        int k;
        String s;
        oracle.jdbc.internal.SqlKind sqlkind;
        int l;
        ai = new int[j];
        ensureOpen();
        prepareForNewResults(true, true);
        k = numberOfDefinePositions;
        s = sqlObject.getOriginalSql();
        sqlkind = sqlKind;
        noMoreUpdateCounts = false;
        l = 0;
        connection.registerHeartbeat();
        connection.needLine();
        i = 0;
_L2:
        if(i >= j)
            break; /* Loop/switch isn't completed */
        sqlObject.initialize(getBatchItem(i));
        sqlKind = sqlObject.getSqlKind();
        needToParse = true;
        numberOfDefinePositions = 0;
        rowsProcessed = 0;
        currentRank = 1;
        if(sqlKind.isSELECT())
        {
            BatchUpdateException batchupdateexception = DatabaseError.createBatchUpdateException(80, (new StringBuilder()).append("invalid SELECT batch command ").append(i).toString(), i, ai);
            batchupdateexception.fillInStackTrace();
            throw batchupdateexception;
        }
        if(!isOpen)
        {
            connection.open(this);
            isOpen = true;
        }
        byte byte0 = -1;
        int i1;
        try
        {
            if(queryTimeout != 0)
                connection.getTimeout().setTimeout(queryTimeout * 1000, this);
            cancelLock.enterExecuting();
            executeForRows(false);
            if(validRows > 0)
                l += validRows;
            i1 = validRows;
        }
        catch(SQLException sqlexception1)
        {
            needToParse = true;
            resetCurrentRowBinders();
            throw sqlexception1;
        }
        if(queryTimeout != 0)
            connection.getTimeout().cancelTimeout();
        validRows = l;
        cancelLock.exitExecuting();
        Exception exception;
        checkValidRowsStatus();
        ai[i] = i1;
        if(ai[i] < 0)
        {
            BatchUpdateException batchupdateexception1 = DatabaseError.createBatchUpdateException(81, (new StringBuilder()).append("command return value ").append(ai[i]).toString(), i, ai);
            batchupdateexception1.fillInStackTrace();
            throw batchupdateexception1;
        }
        i++;
        continue; /* Loop/switch isn't completed */
        exception;
        if(queryTimeout != 0)
            connection.getTimeout().cancelTimeout();
        validRows = l;
        cancelLock.exitExecuting();
        checkValidRowsStatus();
        throw exception;
        if(true) goto _L2; else goto _L1
_L1:
        clearBatchItems();
        numberOfDefinePositions = k;
        if(s != null)
        {
            sqlObject.initialize(s);
            sqlKind = sqlkind;
        }
        currentRank = 0;
        break MISSING_BLOCK_LABEL_545;
        SQLException sqlexception;
        sqlexception;
        if(sqlexception instanceof BatchUpdateException)
        {
            throw sqlexception;
        } else
        {
            BatchUpdateException batchupdateexception2 = DatabaseError.createBatchUpdateException(81, sqlexception.getMessage(), i, ai);
            batchupdateexception2.fillInStackTrace();
            throw batchupdateexception2;
        }
        Exception exception1;
        exception1;
        clearBatchItems();
        numberOfDefinePositions = k;
        if(s != null)
        {
            sqlObject.initialize(s);
            sqlKind = sqlkind;
        }
        currentRank = 0;
        throw exception1;
        connection.registerHeartbeat();
        ai;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception2;
        exception2;
        throw exception2;
    }

    public int copyBinds(Statement statement, int i)
        throws SQLException
    {
        return 0;
    }

    public void notifyCloseRset()
        throws SQLException
    {
        scrollRset = null;
        endOfResultSet(false);
    }

    public String getOriginalSql()
        throws SQLException
    {
        return sqlObject.getOriginalSql();
    }

    void doScrollExecuteCommon()
        throws SQLException
    {
        if(scrollRset != null)
        {
            scrollRset.close();
            scrollRset = null;
        }
        if(!sqlKind.isSELECT())
        {
            doExecuteWithTimeout();
            return;
        }
        if(!needToAddIdentifier)
        {
            doExecuteWithTimeout();
            currentResultSet = new OracleResultSetImpl(connection, this);
            realRsetType = userRsetType;
        } else
        {
            try
            {
                sqlObject.setIncludeRowid(true);
                needToParse = true;
                prepareForNewResults(true, false);
                if(columnsDefinedByUser)
                {
                    Accessor aaccessor[] = accessors;
                    if(accessors == null || accessors.length <= numberOfDefinePositions)
                        accessors = new Accessor[numberOfDefinePositions + 1];
                    if(aaccessor != null)
                    {
                        for(int i = numberOfDefinePositions; i > 0; i--)
                        {
                            Accessor accessor = aaccessor[i - 1];
                            accessors[i] = accessor;
                            if(accessor.isColumnNumberAware)
                                accessor.updateColumnNumber(i);
                        }

                    }
                    allocateRowidAccessor();
                    numberOfDefinePositions++;
                }
                doExecuteWithTimeout();
                currentResultSet = new OracleResultSetImpl(connection, this);
                realRsetType = userRsetType;
            }
            catch(SQLException sqlexception)
            {
                if(userRsetType > 3)
                    realRsetType = 3;
                else
                    realRsetType = 1;
                sqlObject.setIncludeRowid(false);
                needToParse = true;
                prepareForNewResults(true, false);
                if(columnsDefinedByUser)
                {
                    needToPrepareDefineBuffer = true;
                    numberOfDefinePositions--;
                    System.arraycopy(accessors, 1, accessors, 0, numberOfDefinePositions);
                    accessors[numberOfDefinePositions] = null;
                    for(int j = 0; j < numberOfDefinePositions; j++)
                    {
                        Accessor accessor1 = accessors[j];
                        if(accessor1.isColumnNumberAware)
                            accessor1.updateColumnNumber(j);
                    }

                }
                moveAllTempLobsToFree();
                doExecuteWithTimeout();
                currentResultSet = new OracleResultSetImpl(connection, this);
                sqlWarning = DatabaseError.addSqlWarning(sqlWarning, 91, sqlexception.getMessage());
            }
        }
        scrollRset = ResultSetUtil.createScrollResultSet(this, currentResultSet, realRsetType);
    }

    void allocateRowidAccessor()
        throws SQLException
    {
        accessors[0] = new RowidAccessor(this, 128, (short)1, -8, false);
    }

    OracleResultSet doScrollStmtExecuteQuery()
        throws SQLException
    {
        doScrollExecuteCommon();
        return scrollRset;
    }

    void processDmlReturningBind()
        throws SQLException
    {
        if(returnResultSet != null)
            returnResultSet.close();
        returnParamsFetched = false;
        returnParamRowBytes = 0;
        returnParamRowChars = 0;
        int i = 0;
        for(int j = 0; j < numberOfBindPositions; j++)
        {
            Accessor accessor = returnParamAccessors[j];
            if(accessor == null)
                continue;
            i++;
            if(accessor.charLength > 0)
                returnParamRowChars += accessor.charLength;
            else
                returnParamRowBytes += accessor.byteLength;
        }

        if(isAutoGeneratedKey)
        {
            numReturnParams = i;
        } else
        {
            if(numReturnParams <= 0)
                numReturnParams = sqlObject.getReturnParameterCount();
            if(numReturnParams != i)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        returnParamMeta[0] = numReturnParams;
        returnParamMeta[1] = returnParamRowBytes;
        returnParamMeta[2] = returnParamRowChars;
    }

    void allocateDmlReturnStorage()
    {
        if(rowsDmlReturned == 0)
            return;
        int i = returnParamRowBytes * rowsDmlReturned;
        int j = returnParamRowChars * rowsDmlReturned;
        int k = 2 * numReturnParams * rowsDmlReturned;
        returnParamBytes = new byte[i];
        returnParamChars = new char[j];
        returnParamIndicators = new short[k];
        for(int l = 0; l < numberOfBindPositions; l++)
        {
            Accessor accessor = returnParamAccessors[l];
            if(accessor == null || accessor.internalType != 111 && accessor.internalType != 109)
                continue;
            TypeAccessor typeaccessor = (TypeAccessor)accessor;
            if(typeaccessor.pickledBytes == null || typeaccessor.pickledBytes.length < rowsDmlReturned)
                typeaccessor.pickledBytes = new byte[rowsDmlReturned][];
        }

    }

    void fetchDmlReturnParams()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void setupReturnParamAccessors()
    {
        if(rowsDmlReturned == 0)
            return;
        int i = 0;
        int j = 0;
        int k = 0;
        int l = numReturnParams * rowsDmlReturned;
        for(int i1 = 0; i1 < numberOfBindPositions; i1++)
        {
            Accessor accessor = returnParamAccessors[i1];
            if(accessor == null)
                continue;
            if(accessor.charLength > 0)
            {
                accessor.rowSpaceChar = returnParamChars;
                accessor.columnIndex = j;
                j += rowsDmlReturned * accessor.charLength;
            } else
            {
                accessor.rowSpaceByte = returnParamBytes;
                accessor.columnIndex = i;
                i += rowsDmlReturned * accessor.byteLength;
            }
            accessor.rowSpaceIndicator = returnParamIndicators;
            accessor.indicatorIndex = k;
            k += rowsDmlReturned;
            accessor.lengthIndex = l;
            l += rowsDmlReturned;
        }

    }

    void registerReturnParameterInternal(int i, int j, int k, int l, short word0, String s)
        throws SQLException
    {
        if(returnParamAccessors == null)
            returnParamAccessors = new Accessor[numberOfBindPositions];
        if(returnParamMeta == null)
            returnParamMeta = new int[3 + numberOfBindPositions * 4];
        switch(k)
        {
        case -16: 
        case -15: 
        case -9: 
        case 2011: 
            word0 = 2;
            break;

        case 2009: 
            s = "SYS.XMLTYPE";
            break;
        }
        Accessor accessor = allocateAccessor(j, k, i + 1, l, word0, s, true);
        accessor.isDMLReturnedParam = true;
        returnParamAccessors[i] = accessor;
        boolean flag = accessor.charLength > 0;
        returnParamMeta[3 + i * 4 + 0] = accessor.defineType;
        returnParamMeta[3 + i * 4 + 1] = flag ? 1 : 0;
        returnParamMeta[3 + i * 4 + 2] = flag ? accessor.charLength : accessor.byteLength;
        returnParamMeta[3 + i * 4 + 3] = word0;
    }

    /**
     * @deprecated Method creationState is deprecated
     */

    public int creationState()
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return creationState;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isColumnSetNull(int i)
    {
        return columnSetNull;
    }

    public boolean isNCHAR(int i)
        throws SQLException
    {
        if(!described)
            describe();
        int j = i - 1;
        if(j < 0 || j >= numberOfDefinePositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            boolean flag = accessors[j].formOfUse == 2;
            return flag;
        }
    }

    void addChild(OracleStatement oraclestatement)
    {
        oraclestatement.nextChild = children;
        children = oraclestatement;
        oraclestatement.parent = this;
    }

    void removeChild(OracleStatement oraclestatement)
    {
        if(oraclestatement == children)
        {
            children = oraclestatement.nextChild;
        } else
        {
            OracleStatement oraclestatement1;
            for(oraclestatement1 = children; oraclestatement1.nextChild != oraclestatement; oraclestatement1 = oraclestatement1.nextChild);
            oraclestatement1.nextChild = oraclestatement.nextChild;
        }
        oraclestatement.parent = null;
        oraclestatement.nextChild = null;
    }

    public boolean getMoreResults(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSet getGeneratedKeys()
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(!isAutoGeneratedKey)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(returnParamAccessors == null || numReturnParams == 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        if(returnResultSet == null)
            returnResultSet = new OracleReturnResultSet(this);
        return returnResultSet;
    }

    public int executeUpdate(String s, int i)
        throws SQLException
    {
        autoKeyInfo = new AutoKeyInfo(s);
        if(i == 2 || !autoKeyInfo.isInsertSqlStmt())
        {
            autoKeyInfo = null;
            return executeUpdate(s);
        }
        if(i != 1)
        {
            autoKeyInfo = null;
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        isAutoGeneratedKey = true;
        String s1 = autoKeyInfo.getNewSql();
        numberOfBindPositions = 1;
        autoKeyRegisterReturnParams();
        processDmlReturningBind();
        return executeUpdateInternal(s1);
        Exception exception;
        exception;
        throw exception;
    }

    public int executeUpdate(String s, int ai[])
        throws SQLException
    {
        if(ai == null || ai.length == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        autoKeyInfo = new AutoKeyInfo(s, ai);
        if(!autoKeyInfo.isInsertSqlStmt())
        {
            autoKeyInfo = null;
            return executeUpdate(s);
        }
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        isAutoGeneratedKey = true;
        connection.doDescribeTable(autoKeyInfo);
        String s1 = autoKeyInfo.getNewSql();
        numberOfBindPositions = ai.length;
        autoKeyRegisterReturnParams();
        processDmlReturningBind();
        return executeUpdateInternal(s1);
        Exception exception;
        exception;
        throw exception;
    }

    public int executeUpdate(String s, String as[])
        throws SQLException
    {
        if(as == null || as.length == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        autoKeyInfo = new AutoKeyInfo(s, as);
        if(!autoKeyInfo.isInsertSqlStmt())
        {
            autoKeyInfo = null;
            return executeUpdate(s);
        }
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        isAutoGeneratedKey = true;
        connection.doDescribeTable(autoKeyInfo);
        String s1 = autoKeyInfo.getNewSql();
        numberOfBindPositions = as.length;
        autoKeyRegisterReturnParams();
        processDmlReturningBind();
        return executeUpdateInternal(s1);
        Exception exception;
        exception;
        throw exception;
    }

    public boolean execute(String s, int i)
        throws SQLException
    {
        autoKeyInfo = new AutoKeyInfo(s);
        if(i == 2 || !autoKeyInfo.isInsertSqlStmt())
        {
            autoKeyInfo = null;
            return execute(s);
        }
        if(i != 1)
        {
            autoKeyInfo = null;
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        isAutoGeneratedKey = true;
        String s1 = autoKeyInfo.getNewSql();
        numberOfBindPositions = 1;
        autoKeyRegisterReturnParams();
        processDmlReturningBind();
        return executeInternal(s1);
        Exception exception;
        exception;
        throw exception;
    }

    public boolean execute(String s, int ai[])
        throws SQLException
    {
        if(ai == null || ai.length == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        autoKeyInfo = new AutoKeyInfo(s, ai);
        if(!autoKeyInfo.isInsertSqlStmt())
        {
            autoKeyInfo = null;
            return execute(s);
        }
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        isAutoGeneratedKey = true;
        connection.doDescribeTable(autoKeyInfo);
        String s1 = autoKeyInfo.getNewSql();
        numberOfBindPositions = ai.length;
        autoKeyRegisterReturnParams();
        processDmlReturningBind();
        return executeInternal(s1);
        Exception exception;
        exception;
        throw exception;
    }

    public boolean execute(String s, String as[])
        throws SQLException
    {
        if(as == null || as.length == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        autoKeyInfo = new AutoKeyInfo(s, as);
        if(!autoKeyInfo.isInsertSqlStmt())
        {
            autoKeyInfo = null;
            return execute(s);
        }
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        isAutoGeneratedKey = true;
        connection.doDescribeTable(autoKeyInfo);
        String s1 = autoKeyInfo.getNewSql();
        numberOfBindPositions = as.length;
        autoKeyRegisterReturnParams();
        processDmlReturningBind();
        return executeInternal(s1);
        Exception exception;
        exception;
        throw exception;
    }

    public int getResultSetHoldability()
        throws SQLException
    {
        return 1;
    }

    public int getcacheState()
    {
        return cacheState;
    }

    public int getstatementType()
    {
        return statementType;
    }

    public boolean getserverCursor()
    {
        return serverCursor;
    }

    void initializeIndicatorSubRange()
    {
        bindIndicatorSubRange = 0;
    }

    private void autoKeyRegisterReturnParams()
        throws SQLException
    {
        initializeIndicatorSubRange();
        int i = bindIndicatorSubRange + 5 + numberOfBindPositions * 10;
        int j = i + 2 * numberOfBindPositions;
        bindIndicators = new short[j];
        int k = bindIndicatorSubRange;
        bindIndicators[k + 0] = (short)numberOfBindPositions;
        bindIndicators[k + 1] = 0;
        bindIndicators[k + 2] = 1;
        bindIndicators[k + 3] = 0;
        bindIndicators[k + 4] = 1;
        k += 5;
        short aword0[] = autoKeyInfo.tableFormOfUses;
        int ai[] = autoKeyInfo.columnIndexes;
        for(int l = 0; l < numberOfBindPositions; l++)
        {
            bindIndicators[k + 0] = 994;
            short word0 = connection.defaultnchar ? 2 : 1;
            if(aword0 != null && ai != null && aword0[ai[l] - 1] == 2)
            {
                word0 = 2;
                bindIndicators[k + 9] = word0;
            }
            k += 10;
            checkTypeForAutoKey(autoKeyInfo.returnTypes[l]);
            String s = null;
            if(autoKeyInfo.returnTypes[l] == 111)
                s = autoKeyInfo.tableTypeNames[ai[l] - 1];
            registerReturnParameterInternal(l, autoKeyInfo.returnTypes[l], autoKeyInfo.returnTypes[l], -1, word0, s);
        }

    }

    private final void setNonAutoKey()
    {
        isAutoGeneratedKey = false;
        numberOfBindPositions = 0;
        bindIndicators = null;
        returnParamMeta = null;
    }

    void saveDefineBuffersIfRequired(char ac[], byte abyte0[], short aword0[], boolean flag)
        throws SQLException
    {
        if(ac != defineChars)
            connection.cacheBuffer(ac);
        if(abyte0 != defineBytes)
            connection.cacheBuffer(abyte0);
    }

    final void checkTypeForAutoKey(int i)
        throws SQLException
    {
        if(i == 109)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 5);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    void moveAllTempLobsToFree()
    {
        if(oldTempClobsToFree != null)
        {
            if(tempClobsToFree == null)
                tempClobsToFree = oldTempClobsToFree;
            else
                tempClobsToFree.add(oldTempClobsToFree);
            oldTempClobsToFree = null;
        }
        if(oldTempBlobsToFree != null)
        {
            if(tempBlobsToFree == null)
                tempBlobsToFree = oldTempBlobsToFree;
            else
                tempBlobsToFree.add(oldTempBlobsToFree);
            oldTempBlobsToFree = null;
        }
    }

    void moveTempLobsToFree(CLOB clob)
    {
        int i;
        if(oldTempClobsToFree != null && (i = oldTempClobsToFree.indexOf(clob)) != -1)
        {
            addToTempLobsToFree(clob);
            oldTempClobsToFree.remove(i);
        }
    }

    void moveTempLobsToFree(BLOB blob)
    {
        int i;
        if(oldTempBlobsToFree != null && (i = oldTempBlobsToFree.indexOf(blob)) != -1)
        {
            addToTempLobsToFree(blob);
            oldTempBlobsToFree.remove(i);
        }
    }

    void addToTempLobsToFree(CLOB clob)
    {
        if(tempClobsToFree == null)
            tempClobsToFree = new ArrayList();
        tempClobsToFree.add(clob);
    }

    void addToTempLobsToFree(BLOB blob)
    {
        if(tempBlobsToFree == null)
            tempBlobsToFree = new ArrayList();
        tempBlobsToFree.add(blob);
    }

    void addToOldTempLobsToFree(CLOB clob)
    {
        if(oldTempClobsToFree == null)
            oldTempClobsToFree = new ArrayList();
        oldTempClobsToFree.add(clob);
    }

    void addToOldTempLobsToFree(BLOB blob)
    {
        if(oldTempBlobsToFree == null)
            oldTempBlobsToFree = new ArrayList();
        oldTempBlobsToFree.add(blob);
    }

    void cleanAllTempLobs()
    {
        cleanTempClobs(tempClobsToFree);
        tempClobsToFree = null;
        cleanTempBlobs(tempBlobsToFree);
        tempBlobsToFree = null;
        cleanTempClobs(oldTempClobsToFree);
        oldTempClobsToFree = null;
        cleanTempBlobs(oldTempBlobsToFree);
        oldTempBlobsToFree = null;
    }

    void cleanOldTempLobs()
    {
        cleanTempClobs(oldTempClobsToFree);
        cleanTempBlobs(oldTempBlobsToFree);
        oldTempClobsToFree = tempClobsToFree;
        tempClobsToFree = null;
        oldTempBlobsToFree = tempBlobsToFree;
        tempBlobsToFree = null;
    }

    void cleanTempClobs(ArrayList arraylist)
    {
        if(arraylist != null)
        {
            for(Iterator iterator = arraylist.iterator(); iterator.hasNext();)
                try
                {
                    ((CLOB)(CLOB)iterator.next()).freeTemporary();
                }
                catch(SQLException sqlexception) { }

        }
    }

    void cleanTempBlobs(ArrayList arraylist)
    {
        if(arraylist != null)
        {
            for(Iterator iterator = arraylist.iterator(); iterator.hasNext();)
                try
                {
                    ((BLOB)(BLOB)iterator.next()).freeTemporary();
                }
                catch(SQLException sqlexception) { }

        }
    }

    TimeZone getDefaultTimeZone()
        throws SQLException
    {
        return getDefaultTimeZone(false);
    }

    TimeZone getDefaultTimeZone(boolean flag)
        throws SQLException
    {
        if(defaultTimeZone == null)
        {
            try
            {
                defaultTimeZone = connection.getDefaultTimeZone();
            }
            catch(SQLException sqlexception) { }
            if(defaultTimeZone == null)
                defaultTimeZone = TimeZone.getDefault();
        }
        return defaultTimeZone;
    }

    public void setDatabaseChangeRegistration(DatabaseChangeRegistration databasechangeregistration)
        throws SQLException
    {
        registration = (NTFDCNRegistration)databasechangeregistration;
    }

    public String[] getRegisteredTableNames()
        throws SQLException
    {
        return dcnTableName;
    }

    public long getRegisteredQueryId()
        throws SQLException
    {
        return dcnQueryId;
    }

    Calendar getDefaultCalendar()
        throws SQLException
    {
        if(defaultCalendar == null)
            defaultCalendar = Calendar.getInstance(getDefaultTimeZone(), Locale.US);
        return defaultCalendar;
    }

    void releaseBuffers()
    {
        cachedDefineIndicatorSize = defineIndicators == null ? 0 : defineIndicators.length;
        cachedDefineMetaDataSize = defineMetaData == null ? 0 : defineMetaData.length;
        connection.cacheBuffer(defineChars);
        defineChars = null;
        connection.cacheBuffer(defineBytes);
        defineBytes = null;
        defineIndicators = null;
        defineMetaData = null;
    }

    public boolean isClosed()
        throws SQLException
    {
        return false;
    }

    public boolean isPoolable()
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return cacheState != 3;
        }
    }

    public void setPoolable(boolean flag)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(flag)
            cacheState = 1;
        else
            cacheState = 3;
    }

    public boolean isWrapperFor(Class class1)
        throws SQLException
    {
        if(class1.isInterface())
        {
            return class1.isInstance(this);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public Object unwrap(Class class1)
        throws SQLException
    {
        if(class1.isInterface() && class1.isInstance(this))
        {
            return this;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

    Calendar getGMTCalendar()
    {
        if(gmtCalendar == null)
            gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.US);
        return gmtCalendar;
    }

    void extractNioDefineBuffers(int i)
        throws SQLException
    {
    }

    void processLobPrefetchMetaData(Object aobj[])
    {
    }

    void internalClose()
        throws SQLException
    {
        closed = true;
        if(currentResultSet != null)
            currentResultSet.closed = true;
        cleanupDefines();
        bindBytes = null;
        bindChars = null;
        bindIndicators = null;
        outBindAccessors = null;
        parameterStream = (InputStream[][])null;
        userStream = (Object[][])null;
        ibtBindBytes = null;
        ibtBindChars = null;
        ibtBindIndicators = null;
        lobPrefetchMetaData = null;
        tmpByteArray = null;
        definedColumnType = null;
        definedColumnSize = null;
        definedColumnFormOfUse = null;
        if(wrapper != null)
            wrapper.close();
    }

    void calculateCheckSum()
        throws SQLException
    {
        if(!connection.calculateChecksum)
            return;
        _checkSum = checkSum;
        if(accessors != null)
            accessorChecksum(accessors);
        if(outBindAccessors != null)
            accessorChecksum(outBindAccessors);
        if(returnParamAccessors != null && returnParamsFetched)
            accessorChecksum(returnParamAccessors);
        _checkSum = PhysicalConnection.CHECKSUM.updateChecksum(_checkSum, validRows);
        checkSum = _checkSum;
        _checkSum = 0L;
    }

    void accessorChecksum(Accessor aaccessor[])
        throws SQLException
    {
        int i = 0;
        boolean flag = false;
        Accessor aaccessor1[] = aaccessor;
        int j = aaccessor1.length;
label0:
        for(int k = 0; k < j; k++)
        {
            Accessor accessor = aaccessor1[k];
            if(accessor == null)
                continue;
            switch(accessor.internalType)
            {
            case 112: // 'p'
            case 113: // 'q'
            case 114: // 'r'
                if(i == 0)
                    flag = true;
                break;

            case 8: // '\b'
            case 24: // '\030'
                flag = false;
                break label0;

            default:
                flag = false;
                i++;
                for(int l = 0; l < validRows; l++)
                    if(accessor.rowSpaceIndicator != null)
                        _checkSum = accessor.updateChecksum(_checkSum, l);

                break;
            }
        }

        if(flag)
            checkSumComputationFailure = true;
    }

    public long getChecksum()
        throws SQLException
    {
        if(checkSumComputationFailure)
        {
            SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return checkSum;
        }
    }

    static final byte convertSqlKindEnumToByte(oracle.jdbc.internal.SqlKind sqlkind)
    {
        switch(_cls1..SwitchMap.oracle.jdbc.internal.OracleStatement.SqlKind[sqlkind.ordinal()])
        {
        case 8: // '\b'
            return 2;

        case 9: // '\t'
            return 4;

        case 10: // '\n'
            return 8;

        case 11: // '\013'
            return 16;

        case 4: // '\004'
        case 5: // '\005'
            return -128;

        case 6: // '\006'
            return 32;

        case 7: // '\007'
            return 64;

        case 2: // '\002'
        case 3: // '\003'
            return 1;
        }
        if(sqlkind.isPlsqlOrCall())
            return 96;
        return ((byte)(!sqlkind.isDML() ? 0 : 30));
    }

    static final oracle.jdbc.internal.SqlKind convertSqlKindByteToEnum(byte byte0)
    {
        switch(byte0)
        {
        case 2: // '\002'
            return oracle.jdbc.internal.SqlKind.DELETE;

        case 4: // '\004'
            return oracle.jdbc.internal.SqlKind.INSERT;

        case 8: // '\b'
            return oracle.jdbc.internal.SqlKind.MERGE;

        case 16: // '\020'
            return oracle.jdbc.internal.SqlKind.UPDATE;

        case -128: 
            return oracle.jdbc.internal.SqlKind.OTHER;

        case 32: // ' '
            return oracle.jdbc.internal.SqlKind.PLSQL_BLOCK;

        case 64: // '@'
            return oracle.jdbc.internal.SqlKind.CALL_BLOCK;

        case 1: // '\001'
            return oracle.jdbc.internal.SqlKind.SELECT;
        }
        return oracle.jdbc.internal.SqlKind.UNINITIALIZED;
    }

}
