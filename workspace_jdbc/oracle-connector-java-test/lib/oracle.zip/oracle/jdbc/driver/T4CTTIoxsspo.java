// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIoxsspo.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValueLong;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, KeywordValueLongI, T4CMAREngine, T4CConnection

final class T4CTTIoxsspo extends T4CTTIfun
{

    private int functionId;
    private byte sessionId[];
    private KeywordValueLong inKV[];
    private int inFlags;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIoxsspo(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)17);
        setFunCode((short)157);
    }

    void doOXSSPO(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j)
        throws IOException, SQLException
    {
        functionId = i;
        sessionId = abyte0;
        inKV = akeywordvaluelong;
        inFlags = j;
        if(inKV != null)
        {
            for(int k = 0; k < inKV.length; k++)
                ((KeywordValueLongI)inKV[k]).doCharConversion(meg.conv);

        }
        doPigRPC();
    }

    void marshal()
        throws IOException
    {
        meg.marshalUB4(functionId);
        boolean flag = false;
        if(sessionId != null && sessionId.length > 0)
        {
            flag = true;
            meg.marshalPTR();
            meg.marshalUB4(sessionId.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        }
        boolean flag1 = false;
        if(inKV != null && inKV.length > 0)
        {
            flag1 = true;
            meg.marshalPTR();
            meg.marshalUB4(inKV.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        }
        meg.marshalUB4(inFlags);
        if(flag)
            meg.marshalB1Array(sessionId);
        if(flag1)
        {
            for(int i = 0; i < inKV.length; i++)
                ((KeywordValueLongI)inKV[i]).marshal(meg);

        }
    }

}
