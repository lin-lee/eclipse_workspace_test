// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;


// Referenced classes of package oracle.jdbc.driver:
//            Binder, FDBigInt, OraclePreparedStatementReadOnly

abstract class VarnumBinder extends Binder
{

    static final boolean DEBUG = false;
    static final boolean SLOW_CONVERSIONS = true;
    Binder theVarnumCopyingBinder;
    static final int LNXSGNBT = 128;
    static final byte LNXDIGS = 20;
    static final byte LNXEXPBS = 64;
    static final int LNXEXPMX = 127;
    static final double factorTable[] = {
        9.9999999999999994E+253D, 1.0000000000000001E+252D, 9.9999999999999992E+249D, 1E+248D, 1.0000000000000001E+246D, 1.0000000000000001E+244D, 1.0000000000000001E+242D, 1E+240D, 1E+238D, 1.0000000000000001E+236D, 
        1E+234D, 1.0000000000000001E+232D, 1.0000000000000001E+230D, 9.9999999999999992E+227D, 9.9999999999999996E+225D, 9.9999999999999997E+223D, 1E+222D, 1E+220D, 1.0000000000000001E+218D, 1E+216D, 
        9.9999999999999995E+213D, 9.9999999999999991E+211D, 9.9999999999999993E+209D, 9.9999999999999998E+207D, 1E+206D, 9.9999999999999999E+203D, 9.999999999999999E+201D, 9.9999999999999997E+199D, 1E+198D, 9.9999999999999995E+195D, 
        9.9999999999999994E+193D, 1E+192D, 1.0000000000000001E+190D, 1E+188D, 9.9999999999999998E+185D, 1E+184D, 1.0000000000000001E+182D, 1E+180D, 1.0000000000000001E+178D, 1E+176D, 
        1.0000000000000001E+174D, 1.0000000000000001E+172D, 1E+170D, 9.9999999999999993E+167D, 9.9999999999999994E+165D, 1E+164D, 9.9999999999999994E+161D, 1E+160D, 9.9999999999999995E+157D, 9.9999999999999998E+155D, 
        1E+154D, 1E+152D, 9.9999999999999998E+149D, 1E+148D, 9.9999999999999993E+145D, 1E+144D, 1.0000000000000001E+142D, 1.0000000000000001E+140D, 1E+138D, 1.0000000000000001E+136D, 
        9.9999999999999992E+133D, 9.9999999999999999E+131D, 1.0000000000000001E+130D, 1.0000000000000001E+128D, 9.9999999999999992E+125D, 9.9999999999999995E+123D, 1E+122D, 9.9999999999999998E+119D, 9.9999999999999997E+117D, 1E+116D, 
        1E+114D, 9.9999999999999993E+111D, 1E+110D, 1E+108D, 1.0000000000000001E+106D, 1E+104D, 9.9999999999999998E+101D, 1E+100D, 1E+098D, 1E+096D, 
        1E+094D, 1E+092D, 9.9999999999999997E+089D, 9.9999999999999996E+087D, 1E+086D, 1.0000000000000001E+084D, 9.9999999999999996E+081D, 1E+080D, 1E+078D, 1E+076D, 
        9.9999999999999995E+073D, 9.9999999999999994E+071D, 1.0000000000000001E+070D, 9.9999999999999995E+067D, 9.9999999999999995E+065D, 1E+064D, 1E+062D, 9.9999999999999995E+059D, 9.9999999999999994E+057D, 1.0000000000000001E+056D, 
        1.0000000000000001E+054D, 9.9999999999999999E+051D, 1.0000000000000001E+050D, 1E+048D, 9.9999999999999999E+045D, 1.0000000000000001E+044D, 1E+042D, 1E+040D, 9.9999999999999998E+037D, 1E+036D, 
        9.9999999999999995E+033D, 1.0000000000000001E+032D, 1E+030D, 9.9999999999999996E+027D, 1E+026D, 9.9999999999999998E+023D, 1E+022D, 1E+020D, 1E+018D, 10000000000000000D, 
        100000000000000D, 1000000000000D, 10000000000D, 100000000D, 1000000D, 10000D, 100D, 1.0D, 0.01D, 0.0001D, 
        9.9999999999999995E-007D, 1E-008D, 1E-010D, 9.9999999999999998E-013D, 1E-014D, 9.9999999999999998E-017D, 1.0000000000000001E-018D, 9.9999999999999995E-021D, 1E-022D, 9.9999999999999992E-025D, 
        1E-026D, 9.9999999999999997E-029D, 1.0000000000000001E-030D, 1.0000000000000001E-032D, 9.9999999999999993E-035D, 9.9999999999999994E-037D, 9.9999999999999996E-039D, 9.9999999999999993E-041D, 1E-042D, 9.9999999999999995E-045D, 
        1E-046D, 9.9999999999999997E-049D, 1E-050D, 1E-052D, 1E-054D, 1E-056D, 1E-058D, 9.9999999999999997E-061D, 1E-062D, 9.9999999999999997E-065D, 
        9.9999999999999998E-067D, 1.0000000000000001E-068D, 1E-070D, 9.9999999999999997E-073D, 9.9999999999999996E-075D, 9.9999999999999993E-077D, 1E-078D, 9.9999999999999996E-081D, 9.9999999999999996E-083D, 1E-084D, 
        1.0000000000000001E-086D, 9.9999999999999993E-089D, 9.9999999999999999E-091D, 9.9999999999999999E-093D, 9.9999999999999996E-095D, 9.9999999999999991E-097D, 9.9999999999999994E-099D, 1E-100D, 9.9999999999999993E-103D, 9.9999999999999993E-105D, 
        9.9999999999999994E-107D, 1E-108D, 1.0000000000000001E-110D, 9.9999999999999995E-113D, 1.0000000000000001E-114D, 9.9999999999999999E-117D, 9.9999999999999999E-119D, 9.9999999999999998E-121D, 1.0000000000000001E-122D, 9.9999999999999993E-125D, 
        9.9999999999999995E-127D, 1.0000000000000001E-128D, 1.0000000000000001E-130D, 9.9999999999999999E-133D, 1E-134D, 1E-136D, 1.0000000000000001E-138D, 9.9999999999999998E-141D, 1E-142D, 9.9999999999999995E-145D, 
        1E-146D, 9.9999999999999994E-149D, 1E-150D, 1.0000000000000001E-152D, 9.9999999999999997E-155D, 1E-156D, 1.0000000000000001E-158D, 9.9999999999999999E-161D, 9.9999999999999995E-163D, 9.9999999999999996E-165D, 
        1E-166D, 1E-168D, 9.9999999999999998E-171D, 1E-172D, 1E-174D, 1E-176D, 9.9999999999999995E-179D, 1E-180D, 1E-182D, 1.0000000000000001E-184D, 
        9.9999999999999991E-187D, 9.9999999999999995E-189D, 1E-190D, 1.0000000000000001E-192D, 1E-194D, 1E-196D, 9.9999999999999991E-199D, 9.9999999999999998E-201D, 1E-202D, 1E-204D, 
        1E-206D, 1.0000000000000001E-208D, 1E-210D, 9.9999999999999995E-213D, 9.9999999999999991E-215D, 1E-216D, 1E-218D, 9.9999999999999999E-221D, 1E-222D, 1E-224D, 
        9.9999999999999992E-227D, 1E-228D, 1E-230D, 1E-232D, 9.9999999999999996E-235D, 1E-236D, 9.9999999999999999E-239D, 9.9999999999999997E-241D, 9.9999999999999997E-243D, 9.9999999999999993E-245D, 
        9.9999999999999996E-247D, 9.9999999999999998E-249D, 1.0000000000000001E-250D, 9.9999999999999994E-253D, 9.9999999999999991E-255D
    };
    static final int MANTISSA_SIZE = 53;
    static final int expShift = 52;
    static final long fractHOB = 0x10000000000000L;
    static final long fractMask = 0xfffffffffffffL;
    static final int expBias = 1023;
    static final int maxSmallBinExp = 62;
    static final int minSmallBinExp = -21;
    static final long expOne = 0x3ff0000000000000L;
    static final long highbyte = 0xff00000000000000L;
    static final long highbit = 0x8000000000000000L;
    static final long lowbytes = 0xffffffffffffffL;
    static final int small5pow[] = {
        1, 5, 25, 125, 625, 3125, 15625, 0x1312d, 0x5f5e1, 0x1dcd65, 
        0x9502f9, 0x2e90edd, 0xe8d4a51, 0x48c27395
    };
    static final long long5pow[] = {
        1L, 5L, 25L, 125L, 625L, 3125L, 15625L, 0x1312dL, 0x5f5e1L, 0x1dcd65L, 
        0x9502f9L, 0x2e90eddL, 0xe8d4a51L, 0x48c27395L, 0x16bcc41e9L, 0x71afd498dL, 0x2386f26fc1L, 0xb1a2bc2ec5L, 0x3782dace9d9L, 0x1158e460913dL, 
        0x56bc75e2d631L, 0x1b1ae4d6e2ef5L, 0x878678326eac9L, 0x2a5a058fc295edL, 0xd3c21bcecceda1L, 0x422ca8b0a00a425L, 0x14adf4b7320334b9L
    };
    static final int n5bits[] = {
        0, 3, 5, 7, 10, 12, 14, 17, 19, 21, 
        24, 26, 28, 31, 33, 35, 38, 40, 42, 45, 
        47, 49, 52, 54, 56, 59, 61
    };
    static volatile FDBigInt b5p[];
    private static final Object m5Pow = new Object();
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    static void init(Binder binder)
    {
        binder.type = 6;
        binder.bytelen = 22;
    }

    VarnumBinder()
    {
        theVarnumCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarnumCopyingBinder;
        init(this);
    }

    Binder copyingBinder()
    {
        return theVarnumCopyingBinder;
    }

    static int setLongInternal(byte abyte0[], int i, long l)
    {
        if(l == 0L)
        {
            abyte0[i] = -128;
            return 1;
        }
        if(l == 0x8000000000000000L)
        {
            abyte0[i] = 53;
            abyte0[i + 1] = 92;
            abyte0[i + 2] = 79;
            abyte0[i + 3] = 68;
            abyte0[i + 4] = 29;
            abyte0[i + 5] = 98;
            abyte0[i + 6] = 33;
            abyte0[i + 7] = 47;
            abyte0[i + 8] = 24;
            abyte0[i + 9] = 43;
            abyte0[i + 10] = 93;
            abyte0[i + 11] = 102;
            return 12;
        }
        int j = 10;
        int k = 0;
        if(l / 0xde0b6b3a7640000L == 0L)
        {
            j--;
            if(l / 0x2386f26fc10000L == 0L)
            {
                j--;
                if(l / 0x5af3107a4000L == 0L)
                {
                    j--;
                    if(l / 0xe8d4a51000L == 0L)
                    {
                        j--;
                        if(l / 0x2540be400L == 0L)
                        {
                            j--;
                            if(l / 0x5f5e100L == 0L)
                            {
                                j--;
                                if(l / 0xf4240L == 0L)
                                {
                                    j--;
                                    if(l / 10000L == 0L)
                                    {
                                        j--;
                                        if(l / 100L == 0L)
                                            j--;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        int i1 = i + j;
        if(l < 0L)
        {
            l = -l;
            abyte0[i] = (byte)(63 - j);
            do
            {
                int j1 = (int)(l % 100L);
                if(k == 0)
                {
                    if(j1 != 0)
                    {
                        abyte0[i1 + 1] = 102;
                        k = (i1 + 2) - i;
                        abyte0[i1] = (byte)(101 - j1);
                    }
                } else
                {
                    abyte0[i1] = (byte)(101 - j1);
                }
                if(--i1 == i)
                    break;
                l /= 100L;
            } while(true);
        } else
        {
            abyte0[i] = (byte)(192 + j);
            do
            {
                int k1 = (int)(l % 100L);
                if(k == 0)
                {
                    if(k1 != 0)
                    {
                        k = (i1 + 1) - i;
                        abyte0[i1] = (byte)(k1 + 1);
                    }
                } else
                {
                    abyte0[i1] = (byte)(k1 + 1);
                }
                if(--i1 == i)
                    break;
                l /= 100L;
            } while(true);
        }
        return k;
    }

    static int countBits(long l)
    {
        if(l == 0L)
            return 0;
        for(; (l & 0xff00000000000000L) == 0L; l <<= 8);
        for(; l > 0L; l <<= 1);
        int i;
        for(i = 0; (l & 0xffffffffffffffL) != 0L; i += 8)
            l <<= 8;

        while(l != 0L) 
        {
            l <<= 1;
            i++;
        }
        return i;
    }

    boolean roundup(char ac[], int i)
    {
        int j = i - 1;
        char c = ac[j];
        if(c == '9')
        {
            for(; c == '9' && j > 0; c = ac[--j])
                ac[j] = '0';

            if(c == '9')
            {
                ac[0] = '1';
                return true;
            }
        }
        ac[j] = (char)(c + 1);
        return false;
    }

    static FDBigInt big5pow(int i)
    {
        if(i < 0)
            throw new RuntimeException("Assertion botch: negative power of 5");
        if(b5p != null && b5p.length > i && b5p[i] != null)
            return b5p[i];
        Object obj = m5Pow;
        JVM INSTR monitorenter ;
        if(b5p != null && b5p.length > i && b5p[i] != null)
            return b5p[i];
        if(b5p == null)
            b5p = new FDBigInt[i + 1];
        else
        if(b5p.length <= i)
        {
            FDBigInt afdbigint[] = new FDBigInt[i + 1];
            System.arraycopy(b5p, 0, afdbigint, 0, b5p.length);
            b5p = afdbigint;
        }
        if(b5p[i] == null) goto _L2; else goto _L1
_L1:
        b5p[i];
        obj;
        JVM INSTR monitorexit ;
        return;
_L2:
        if(i >= small5pow.length) goto _L4; else goto _L3
_L3:
        b5p[i] = new FDBigInt(small5pow[i]);
        obj;
        JVM INSTR monitorexit ;
        return;
_L4:
        if(i >= long5pow.length) goto _L6; else goto _L5
_L5:
        b5p[i] = new FDBigInt(long5pow[i]);
        obj;
        JVM INSTR monitorexit ;
        return;
_L6:
        int k;
        FDBigInt fdbigint;
        int j = i >> 1;
        k = i - j;
        fdbigint = b5p[j];
        if(fdbigint == null)
            fdbigint = big5pow(j);
        if(k >= small5pow.length) goto _L8; else goto _L7
_L7:
        b5p[i] = fdbigint.mult(small5pow[k]);
        obj;
        JVM INSTR monitorexit ;
        return;
_L8:
        FDBigInt fdbigint1;
        fdbigint1 = b5p[k];
        if(fdbigint1 == null)
            fdbigint1 = big5pow(k);
        b5p[i] = fdbigint.mult(fdbigint1);
        obj;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    static FDBigInt multPow52(FDBigInt fdbigint, int i, int j)
    {
        if(i != 0)
            if(i < small5pow.length)
                fdbigint = fdbigint.mult(small5pow[i]);
            else
                fdbigint = fdbigint.mult(big5pow(i));
        if(j != 0)
            fdbigint.lshiftMe(j);
        return fdbigint;
    }

    static FDBigInt constructPow52(int i, int j)
    {
        FDBigInt fdbigint = new FDBigInt(big5pow(i));
        if(j != 0)
            fdbigint.lshiftMe(j);
        return fdbigint;
    }

    int dtoa(byte abyte0[], int i, double d, boolean flag, boolean flag1, char ac[], 
            int j, long l, int k)
    {
        int i1 = 0x7fffffff;
        int j1 = -1;
        int k1 = countBits(l);
        int l1 = k1 - j - 1;
        boolean flag2 = false;
        if(l1 < 0)
            l1 = 0;
        if(j <= 62 && j >= -21 && l1 < long5pow.length && k1 + n5bits[l1] < 64 && l1 == 0)
        {
            long l2;
            if(j > k)
                l2 = 1L << j - k - 1;
            else
                l2 = 0L;
            if(j >= 52)
                l <<= j - 52;
            else
                l >>>= 52 - j;
            i1 = 0;
            long l3 = l;
            long l4 = l2;
            int l6;
            for(l6 = 0; l4 >= 10L; l6++)
                l4 /= 10L;

            if(l6 != 0)
            {
                long l7 = long5pow[l6] << l6;
                long l8 = l3 % l7;
                l3 /= l7;
                i1 += l6;
                if(l8 >= l7 >> 1)
                    l3++;
            }
            int i5;
            int k5;
            if(l3 <= 0x7fffffffL)
            {
                int j7 = (int)l3;
                i5 = 10;
                k5 = i5 - 1;
                int i6 = j7 % 10;
                for(j7 /= 10; i6 == 0; j7 /= 10)
                {
                    i1++;
                    i6 = j7 % 10;
                }

                for(; j7 != 0; j7 /= 10)
                {
                    ac[k5--] = (char)(i6 + 48);
                    i1++;
                    i6 = j7 % 10;
                }

                ac[k5] = (char)(i6 + 48);
            } else
            {
                i5 = 20;
                k5 = i5 - 1;
                int j6 = (int)(l3 % 10L);
                for(l3 /= 10L; j6 == 0; l3 /= 10L)
                {
                    i1++;
                    j6 = (int)(l3 % 10L);
                }

                for(; l3 != 0L; l3 /= 10L)
                {
                    ac[k5--] = (char)(j6 + 48);
                    i1++;
                    j6 = (int)(l3 % 10L);
                }

                ac[k5] = (char)(j6 + 48);
            }
            i5 -= k5;
            if(k5 != 0)
                System.arraycopy(ac, k5, ac, 0, i5);
            i1++;
            j1 = i5;
            flag2 = true;
        }
        if(!flag2)
        {
            double d1 = Double.longBitsToDouble(0x3ff0000000000000L | l & 0xffefffffffffffffL);
            int i2 = (int)Math.floor((d1 - 1.5D) * 0.28952965400000003D + 0.176091259D + (double)j * 0.30102999566398098D);
            int j3 = Math.max(0, -i2);
            int k2 = j3 + l1 + j;
            int k4 = Math.max(0, i2);
            int i4 = k4 + l1;
            int l5 = j3;
            int j5 = k2 - k;
            l >>>= 53 - k1;
            k2 -= k1 - 1;
            int k7 = Math.min(k2, i4);
            k2 -= k7;
            i4 -= k7;
            j5 -= k7;
            if(k1 == 1)
                j5--;
            if(j5 < 0)
            {
                k2 -= j5;
                i4 -= j5;
                j5 = 0;
            }
            int i8 = 0;
            int k6 = k1 + k2 + (j3 >= n5bits.length ? j3 * 3 : n5bits[j3]);
            int i7 = i4 + 1 + (k4 + 1 >= n5bits.length ? (k4 + 1) * 3 : n5bits[k4 + 1]);
            boolean flag4;
            boolean flag5;
            long l9;
            if(k6 < 64 && i7 < 64)
            {
                if(k6 < 32 && i7 < 32)
                {
                    int j10 = (int)l * small5pow[j3] << k2;
                    int k10 = small5pow[k4] << i4;
                    int j11 = small5pow[l5] << j5;
                    int k11 = k10 * 10;
                    i8 = 0;
                    int j8 = j10 / k10;
                    j10 = 10 * (j10 % k10);
                    j11 *= 10;
                    flag4 = j10 < j11;
                    flag5 = j10 + j11 > k11;
                    if(j8 == 0 && !flag5)
                        i2--;
                    else
                        ac[i8++] = (char)(48 + j8);
                    if(i2 <= -3 || i2 >= 8)
                        flag5 = flag4 = false;
                    while(!flag4 && !flag5) 
                    {
                        int k8 = j10 / k10;
                        j10 = 10 * (j10 % k10);
                        j11 *= 10;
                        if((long)j11 > 0L)
                        {
                            flag4 = j10 < j11;
                            flag5 = j10 + j11 > k11;
                        } else
                        {
                            flag4 = true;
                            flag5 = true;
                        }
                        ac[i8++] = (char)(48 + k8);
                    }
                    l9 = (j10 << 1) - k11;
                } else
                {
                    long l10 = l * long5pow[j3] << k2;
                    long l11 = long5pow[k4] << i4;
                    long l12 = long5pow[l5] << j5;
                    long l13 = l11 * 10L;
                    i8 = 0;
                    int i9 = (int)(l10 / l11);
                    l10 = 10L * (l10 % l11);
                    l12 *= 10L;
                    flag4 = l10 < l12;
                    flag5 = l10 + l12 > l13;
                    if(i9 == 0 && !flag5)
                        i2--;
                    else
                        ac[i8++] = (char)(48 + i9);
                    if(i2 <= -3 || i2 >= 8)
                        flag5 = flag4 = false;
                    while(!flag4 && !flag5) 
                    {
                        int j9 = (int)(l10 / l11);
                        l10 = 10L * (l10 % l11);
                        l12 *= 10L;
                        if(l12 > 0L)
                        {
                            flag4 = l10 < l12;
                            flag5 = l10 + l12 > l13;
                        } else
                        {
                            flag4 = true;
                            flag5 = true;
                        }
                        ac[i8++] = (char)(48 + j9);
                    }
                    l9 = (l10 << 1) - l13;
                }
            } else
            {
                FDBigInt fdbigint1 = multPow52(new FDBigInt(l), j3, k2);
                FDBigInt fdbigint = constructPow52(k4, i4);
                FDBigInt fdbigint2 = constructPow52(l5, j5);
                int i11;
                fdbigint1.lshiftMe(i11 = fdbigint.normalizeMe());
                fdbigint2.lshiftMe(i11);
                FDBigInt fdbigint3 = fdbigint.mult(10);
                i8 = 0;
                int k9 = fdbigint1.quoRemIteration(fdbigint);
                fdbigint2 = fdbigint2.mult(10);
                flag4 = fdbigint1.cmp(fdbigint2) < 0;
                flag5 = fdbigint1.add(fdbigint2).cmp(fdbigint3) > 0;
                if(k9 == 0 && !flag5)
                    i2--;
                else
                    ac[i8++] = (char)(48 + k9);
                if(i2 <= -3 || i2 >= 8)
                    flag5 = flag4 = false;
                while(!flag4 && !flag5) 
                {
                    int i10 = fdbigint1.quoRemIteration(fdbigint);
                    fdbigint2 = fdbigint2.mult(10);
                    flag4 = fdbigint1.cmp(fdbigint2) < 0;
                    flag5 = fdbigint1.add(fdbigint2).cmp(fdbigint3) > 0;
                    ac[i8++] = (char)(48 + i10);
                }
                if(flag5 && flag4)
                {
                    fdbigint1.lshiftMe(1);
                    l9 = fdbigint1.cmp(fdbigint3);
                } else
                {
                    l9 = 0L;
                }
            }
            i1 = i2 + 1;
            j1 = i8;
            if(flag5)
                if(flag4)
                {
                    if(l9 == 0L)
                    {
                        if((ac[j1 - 1] & '\001') != 0 && roundup(ac, j1))
                            i1++;
                    } else
                    if(l9 > 0L && roundup(ac, j1))
                        i1++;
                } else
                if(roundup(ac, j1))
                    i1++;
        }
        for(; j1 - i1 > 0 && ac[j1 - 1] == '0'; j1--);
        boolean flag3 = i1 % 2 != 0;
        int j2;
        if(flag3)
        {
            if(j1 % 2 == 0)
                ac[j1++] = '0';
            j2 = (i1 - 1) / 2;
        } else
        {
            if(j1 % 2 == 1)
                ac[j1++] = '0';
            j2 = (i1 - 2) / 2;
        }
        int i3 = 117 - j2;
        int k3 = 0;
        int j4 = 1;
        if(flag)
        {
            abyte0[i] = (byte)(62 - j2);
            if(flag3)
            {
                abyte0[i + j4] = (byte)(101 - (ac[k3++] - 48));
                j4++;
            }
            while(k3 < j1) 
            {
                abyte0[i + j4] = (byte)(101 - ((ac[k3] - 48) * 10 + (ac[k3 + 1] - 48)));
                k3 += 2;
                j4++;
            }
            abyte0[i + j4++] = 102;
        } else
        {
            abyte0[i] = (byte)(192 + (j2 + 1));
            if(flag3)
            {
                abyte0[i + j4] = (byte)((ac[k3++] - 48) + 1);
                j4++;
            }
            while(k3 < j1) 
            {
                abyte0[i + j4] = (byte)((ac[k3] - 48) * 10 + (ac[k3 + 1] - 48) + 1);
                k3 += 2;
                j4++;
            }
        }
        return j4;
    }

}
