// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   Message11.java

package oracle.jdbc.driver;

import java.util.ResourceBundle;

// Referenced classes of package oracle.jdbc.driver:
//            Message

class Message11
    implements Message
{

    private static ResourceBundle bundle;
    private static final String messageFile = "oracle.jdbc.driver.Messages";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public Message11()
    {
    }

    public String msg(String s, Object obj)
    {
        if(bundle == null)
            try
            {
                bundle = ResourceBundle.getBundle("oracle.jdbc.driver.Messages");
            }
            catch(Exception exception)
            {
                return "Message file 'oracle.jdbc.driver.Messages' is missing.";
            }
        try
        {
            if(obj != null)
                return (new StringBuilder()).append(bundle.getString(s)).append(": ").append(obj).toString();
        }
        catch(Exception exception1)
        {
            return (new StringBuilder()).append("Message [").append(s).append("] not found in '").append("oracle.jdbc.driver.Messages").append("'.").toString();
        }
        return bundle.getString(s);
    }

}
