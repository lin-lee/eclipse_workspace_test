// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   BinaryDoubleAccessor.java

package oracle.jdbc.driver;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.Map;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            Accessor, OracleStatement, DatabaseError

class BinaryDoubleAccessor extends Accessor
{

    static final int MAXLENGTH = 8;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    BinaryDoubleAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 101, 101, word0, flag);
        initForDataAccess(j, i, null);
    }

    BinaryDoubleAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        init(oraclestatement, 101, 101, word0, false);
        initForDescribe(101, i, flag, j, k, l, i1, j1, word0, null);
        int k1 = oraclestatement.maxFieldSize;
        if(k1 > 0 && (i == 0 || k1 < i))
            i = k1;
        initForDataAccess(0, i, null);
    }

    void init(OracleStatement oraclestatement, int i, int j, int k, short word0, int l)
        throws SQLException
    {
        init(oraclestatement, i, j, word0, false);
        initForDataAccess(l, k, null);
    }

    void init(OracleStatement oraclestatement, int i, int j, int k, boolean flag, int l, int i1, 
            int j1, int k1, int l1, short word0)
        throws SQLException
    {
        init(oraclestatement, i, j, word0, false);
        initForDescribe(i, k, flag, l, i1, j1, k1, l1, word0, null);
        int i2 = oraclestatement.maxFieldSize;
        if(i2 > 0 && (k == 0 || i2 < k))
            k = i2;
        initForDataAccess(0, k, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        internalTypeMaxLength = 8;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        byteLength = internalTypeMaxLength;
    }

    double getDouble(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
            return 0.0D;
        int j = columnIndex + byteLength * i;
        int k = rowSpaceByte[j];
        int l = rowSpaceByte[j + 1];
        int i1 = rowSpaceByte[j + 2];
        int j1 = rowSpaceByte[j + 3];
        int k1 = rowSpaceByte[j + 4];
        int l1 = rowSpaceByte[j + 5];
        int i2 = rowSpaceByte[j + 6];
        int j2 = rowSpaceByte[j + 7];
        if((k & 0x80) != 0)
        {
            k &= 0x7f;
            l &= 0xff;
            i1 &= 0xff;
            j1 &= 0xff;
            k1 &= 0xff;
            l1 &= 0xff;
            i2 &= 0xff;
            j2 &= 0xff;
        } else
        {
            k = ~k & 0xff;
            l = ~l & 0xff;
            i1 = ~i1 & 0xff;
            j1 = ~j1 & 0xff;
            k1 = ~k1 & 0xff;
            l1 = ~l1 & 0xff;
            i2 = ~i2 & 0xff;
            j2 = ~j2 & 0xff;
        }
        int k2 = k << 24 | l << 16 | i1 << 8 | j1;
        int l2 = k1 << 24 | l1 << 16 | i2 << 8 | j2;
        long l3 = (long)k2 << 32 | (long)l2 & 0xffffffffL;
        return Double.longBitsToDouble(l3);
    }

    String getString(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            return Double.toString(getDouble(i));
        else
            return null;
    }

    Object getObject(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            return new Double(getDouble(i));
        else
            return null;
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        return new Double(getDouble(i));
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        return getBINARY_DOUBLE(i);
    }

    BINARY_DOUBLE getBINARY_DOUBLE(int i)
        throws SQLException
    {
        BINARY_DOUBLE binary_double = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            short word0 = rowSpaceIndicator[lengthIndex + i];
            int j = columnIndex + byteLength * i;
            byte abyte0[] = new byte[word0];
            System.arraycopy(rowSpaceByte, j, abyte0, 0, word0);
            binary_double = new BINARY_DOUBLE(abyte0);
        }
        return binary_double;
    }

    NUMBER getNUMBER(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            return new NUMBER(getDouble(i));
        else
            return null;
    }

    BigInteger getBigInteger(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            return new BigInteger(getString(i));
        else
            return null;
    }

    BigDecimal getBigDecimal(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            return new BigDecimal(getString(i));
        else
            return null;
    }

    byte getByte(int i)
        throws SQLException
    {
        return (byte)(int)getDouble(i);
    }

    short getShort(int i)
        throws SQLException
    {
        return (short)(int)getDouble(i);
    }

    int getInt(int i)
        throws SQLException
    {
        return (int)getDouble(i);
    }

    long getLong(int i)
        throws SQLException
    {
        return (long)getDouble(i);
    }

    float getFloat(int i)
        throws SQLException
    {
        return (float)getDouble(i);
    }

}
