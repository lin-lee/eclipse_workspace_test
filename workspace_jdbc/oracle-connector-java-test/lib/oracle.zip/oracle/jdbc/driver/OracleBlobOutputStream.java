// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleBlobOutputStream.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.BLOB;

// Referenced classes of package oracle.jdbc.driver:
//            PhysicalConnection, DatabaseError

class OracleBlobOutputStream extends OutputStream
{

    long lobOffset;
    BLOB blob;
    byte buf[];
    int count;
    int bufSize;
    boolean isClosed;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleBlobOutputStream(BLOB blob1, int i)
        throws SQLException
    {
        this(blob1, i, 1L);
    }

    public OracleBlobOutputStream(BLOB blob1, int i, long l)
        throws SQLException
    {
        if(blob1 == null || i <= 0 || l < 1L)
            throw new IllegalArgumentException("Illegal Arguments");
        blob = blob1;
        lobOffset = l;
        PhysicalConnection physicalconnection = (PhysicalConnection)blob1.getInternalConnection();
        synchronized(physicalconnection)
        {
            buf = physicalconnection.getByteBuffer(i);
        }
        count = 0;
        bufSize = i;
        isClosed = false;
    }

    public void write(int i)
        throws IOException
    {
        ensureOpen();
        if(count >= bufSize)
            flushBuffer();
        buf[count++] = (byte)i;
    }

    public void write(byte abyte0[], int i, int j)
        throws IOException
    {
        ensureOpen();
        int k = i;
        int l = Math.min(j, abyte0.length - i);
        if(l >= 2 * bufSize)
        {
            if(count > 0)
                flushBuffer();
            try
            {
                lobOffset += blob.setBytes(lobOffset, abyte0, i, l);
            }
            catch(SQLException sqlexception)
            {
                IOException ioexception = DatabaseError.createIOException(sqlexception);
                ioexception.fillInStackTrace();
                throw ioexception;
            }
        } else
        {
            int i1 = k + l;
            do
            {
                if(k >= i1)
                    break;
                int j1 = Math.min(bufSize - count, i1 - k);
                System.arraycopy(abyte0, k, buf, count, j1);
                k += j1;
                count += j1;
                if(count >= bufSize)
                    flushBuffer();
            } while(true);
        }
    }

    public void flush()
        throws IOException
    {
        ensureOpen();
        flushBuffer();
    }

    public void close()
        throws IOException
    {
        if(isClosed)
            return;
        isClosed = true;
        flushBuffer();
        try
        {
            PhysicalConnection physicalconnection = (PhysicalConnection)blob.getInternalConnection();
            synchronized(physicalconnection)
            {
                if(buf != null)
                {
                    physicalconnection.cacheBuffer(buf);
                    buf = null;
                }
            }
        }
        catch(SQLException sqlexception)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
        break MISSING_BLOCK_LABEL_157;
        Exception exception1;
        exception1;
        try
        {
            PhysicalConnection physicalconnection2 = (PhysicalConnection)blob.getInternalConnection();
            synchronized(physicalconnection2)
            {
                if(buf != null)
                {
                    physicalconnection2.cacheBuffer(buf);
                    buf = null;
                }
            }
        }
        catch(SQLException sqlexception1)
        {
            IOException ioexception1 = DatabaseError.createIOException(sqlexception1);
            ioexception1.fillInStackTrace();
            throw ioexception1;
        }
        throw exception1;
    }

    private void flushBuffer()
        throws IOException
    {
        try
        {
            if(count > 0)
            {
                lobOffset += blob.setBytes(lobOffset, buf, 0, count);
                count = 0;
            }
        }
        catch(SQLException sqlexception)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
    }

    void ensureOpen()
        throws IOException
    {
        try
        {
            if(isClosed)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, null);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(SQLException sqlexception1)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception1);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        try
        {
            return blob.getInternalConnection();
        }
        catch(Exception exception)
        {
            return null;
        }
    }

}
