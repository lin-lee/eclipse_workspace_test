// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIoxsscs.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, KeywordValueLongI, T4CMAREngine, DBConversion, 
//            T4CConnection

final class T4CTTIoxsscs extends T4CTTIfun
{

    private String userName;
    private KeywordValueLong inKV[];
    private int inFlags;
    private byte userNameArr[];
    private byte sessionId[];
    private KeywordValueLong outKV[];
    private int outFlags;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIoxsscs(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        userName = null;
        inKV = null;
        userNameArr = null;
        sessionId = null;
        outKV = null;
        outFlags = -1;
        setFunCode((short)155);
    }

    void doOXSSCS(String s, KeywordValueLong akeywordvaluelong[], int i)
        throws IOException, SQLException
    {
        userName = s;
        inKV = akeywordvaluelong;
        inFlags = i;
        if(userName != null && userName.length() > 0)
            userNameArr = meg.conv.StringToCharBytes(userName);
        else
            userNameArr = null;
        sessionId = null;
        outKV = null;
        outFlags = -1;
        if(inKV != null)
        {
            for(int j = 0; j < inKV.length; j++)
                ((KeywordValueLongI)inKV[j]).doCharConversion(meg.conv);

        }
        doRPC();
    }

    void marshal()
        throws IOException
    {
        meg.marshalPTR();
        meg.marshalPTR();
        if(userNameArr != null)
        {
            meg.marshalPTR();
            meg.marshalSB4(userNameArr.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSB4(0);
        }
        boolean flag = false;
        if(inKV != null && inKV.length > 0)
        {
            flag = true;
            meg.marshalPTR();
            meg.marshalSB4(inKV.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSB4(0);
        }
        meg.marshalUB4(inFlags);
        meg.marshalPTR();
        meg.marshalPTR();
        meg.marshalPTR();
        if(userNameArr != null)
            meg.marshalCHR(userNameArr);
        if(flag)
        {
            for(int i = 0; i < inKV.length; i++)
                ((KeywordValueLongI)inKV[i]).marshal(meg);

        }
    }

    byte[] getSessionId()
    {
        return sessionId;
    }

    KeywordValueLong[] getOutKV()
    {
        return outKV;
    }

    int getOutFlags()
    {
        return outFlags;
    }

    void readRPA()
        throws SQLException, IOException
    {
        int i = (int)meg.unmarshalUB4();
        sessionId = meg.unmarshalNBytes(i);
        int j = (int)meg.unmarshalUB4();
        outKV = new KeywordValueLong[j];
        for(int k = 0; k < j; k++)
            outKV[k] = KeywordValueLongI.unmarshal(meg);

        outFlags = (int)meg.unmarshalUB4();
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
