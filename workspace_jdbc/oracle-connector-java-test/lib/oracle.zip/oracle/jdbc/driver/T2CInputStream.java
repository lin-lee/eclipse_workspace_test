// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T2CInputStream.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            OracleInputStream, T2CConnection, Accessor, OracleStatement, 
//            PhysicalConnection

class T2CInputStream extends OracleInputStream
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    native int t2cGetBytes(long l, int i, byte abyte0[], int j, Accessor aaccessor[], byte abyte1[], 
            int k, char ac[], int i1, short aword0[], int j1, Object aobj[], Object aobj1[], 
            long l1);

    T2CInputStream(OracleStatement oraclestatement, int i, Accessor accessor)
    {
        super(oraclestatement, i, accessor);
    }

    public int getBytes(int i)
        throws IOException
    {
        PhysicalConnection physicalconnection = statement.connection;
        JVM INSTR monitorenter ;
        if(i > currentBufferSize)
        {
            currentBufferSize = Math.max(i, initialBufferSize);
            resizableBuffer = new byte[currentBufferSize];
        }
        long l = statement.connection.useNio ? 1 : 0;
        if(statement.connection.useNio)
            if(statement.nioBuffers[3] == null || statement.nioBuffers[3].capacity() < resizableBuffer.length)
                statement.nioBuffers[3] = ByteBuffer.allocateDirect(resizableBuffer.length);
            else
                statement.nioBuffers[3].rewind();
        int j = t2cGetBytes(statement.c_state, columnIndex, resizableBuffer, currentBufferSize, statement.accessors, statement.defineBytes, statement.accessorByteOffset, statement.defineChars, statement.accessorCharOffset, statement.defineIndicators, statement.accessorShortOffset, statement.nioBuffers, statement.lobPrefetchMetaData, l);
        boolean flag = false;
        try
        {
            if(j == -1)
                ((T2CConnection)statement.connection).checkError(j, statement.sqlWarning);
            else
            if(j == -2)
            {
                flag = true;
                accessor.setNull(statement.currentRow != -1 ? statement.currentRow : 0, true);
                j = 0;
            } else
            if(statement.connection.useNio && j >= 0)
                accessor.setNull(statement.currentRow != -1 ? statement.currentRow : 0, false);
        }
        catch(SQLException sqlexception)
        {
            throw new IOException(sqlexception.getMessage());
        }
        if(j <= 0)
        {
            j = -1;
            flag = true;
        }
        if(statement.connection.useNio)
        {
            ByteBuffer bytebuffer = statement.nioBuffers[3];
            if(bytebuffer != null && j > 0)
                bytebuffer.get(resizableBuffer, 0, j);
            if(flag)
                try
                {
                    statement.extractNioDefineBuffers(columnIndex);
                }
                catch(SQLException sqlexception1)
                {
                    throw new IOException(sqlexception1.getMessage());
                }
        }
        if(flag && statement.lobPrefetchMetaData != null)
            statement.processLobPrefetchMetaData(statement.lobPrefetchMetaData);
        return j;
        Exception exception;
        exception;
        throw exception;
    }

}
