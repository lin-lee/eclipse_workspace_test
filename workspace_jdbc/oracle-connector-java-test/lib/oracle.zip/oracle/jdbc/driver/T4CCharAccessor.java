// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CCharAccessor.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.*;
import java.util.Calendar;
import java.util.Properties;
import oracle.jdbc.internal.OracleStatement;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            CharAccessor, OracleStatement, T4CMAREngine, PhysicalConnection, 
//            DBConversion, T4CVarcharAccessor, DatabaseError

class T4CCharAccessor extends CharAccessor
{

    T4CMAREngine mare;
    boolean underlyingLong;
    final int meta[];
    final int tmp[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CCharAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, short word0, int j, boolean flag, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, word0, j, flag);
        underlyingLong = false;
        meta = new int[1];
        tmp = new int[1];
        mare = t4cmarengine;
        calculateSizeTmpByteArray();
    }

    T4CCharAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, int k1, int l1, int i2, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, flag, j, k, l, i1, j1, word0);
        underlyingLong = false;
        meta = new int[1];
        tmp = new int[1];
        mare = t4cmarengine;
        definedColumnType = l1;
        definedColumnSize = i2;
        calculateSizeTmpByteArray();
        oacmxl = k1;
        if(oacmxl == -1)
        {
            underlyingLong = true;
            oacmxl = 4000;
        }
    }

    void processIndicator(int i)
        throws IOException, SQLException
    {
        if(internalType == 1 && describeType == 112 || internalType == 23 && describeType == 113)
        {
            mare.unmarshalUB2();
            mare.unmarshalUB2();
        } else
        if(statement.connection.versionNumber < 9200)
        {
            mare.unmarshalSB2();
            if(!statement.sqlKind.isPlsqlOrCall())
                mare.unmarshalSB2();
        } else
        if(statement.sqlKind.isPlsqlOrCall() || isDMLReturnedParam)
            mare.processIndicator(i <= 0, i);
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        if(isUseLess)
        {
            lastRowProcessed++;
            return false;
        }
        int i = indicatorIndex + lastRowProcessed;
        int j = lengthIndex + lastRowProcessed;
        byte abyte0[] = statement.tmpByteArray;
        int k = columnIndex + lastRowProcessed * charLength;
        if(rowSpaceIndicator == null)
        {
            byte abyte1[] = new byte[16000];
            mare.unmarshalCLR(abyte1, 0, meta);
            processIndicator(meta[0]);
            lastRowProcessed++;
            return false;
        }
        if(isNullByDescribe)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
            lastRowProcessed++;
            if(statement.connection.versionNumber < 9200)
                processIndicator(0);
            return false;
        }
        if(statement.maxFieldSize > 0)
            mare.unmarshalCLR(abyte0, 0, meta, statement.maxFieldSize);
        else
            mare.unmarshalCLR(abyte0, 0, meta);
        tmp[0] = meta[0];
        int l = 0;
        if(formOfUse == 2)
            l = statement.connection.conversion.NCHARBytesToJavaChars(abyte0, 0, rowSpaceChar, k + 1, tmp, charLength - 1);
        else
            l = statement.connection.conversion.CHARBytesToJavaChars(abyte0, 0, rowSpaceChar, k + 1, tmp, charLength - 1);
        rowSpaceChar[k] = (char)(l * 2);
        processIndicator(meta[0]);
        if(meta[0] == 0)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
        } else
        {
            rowSpaceIndicator[j] = (short)(meta[0] * 2);
            rowSpaceIndicator[i] = 0;
        }
        lastRowProcessed++;
        return false;
    }

    void copyRow()
        throws SQLException, IOException
    {
        int i;
        if(lastRowProcessed == 0)
            i = statement.rowPrefetchInLastFetch - 1;
        else
            i = lastRowProcessed - 1;
        int j = columnIndex + lastRowProcessed * charLength;
        int k = columnIndex + i * charLength;
        int l = indicatorIndex + lastRowProcessed;
        int i1 = indicatorIndex + i;
        int j1 = lengthIndex + lastRowProcessed;
        int k1 = lengthIndex + i;
        int l1 = rowSpaceIndicator[k1];
        int i2 = metaDataIndex + lastRowProcessed * 1;
        int j2 = metaDataIndex + i * 1;
        rowSpaceIndicator[j1] = (short)l1;
        rowSpaceIndicator[l] = rowSpaceIndicator[i1];
        if(!isNullByDescribe)
            System.arraycopy(rowSpaceChar, k, rowSpaceChar, j, rowSpaceChar[k] / 2 + 1);
        System.arraycopy(rowSpaceMetaData, j2, rowSpaceMetaData, i2, 1);
        lastRowProcessed++;
    }

    void saveDataFromOldDefineBuffers(byte abyte0[], char ac[], short aword0[], int i, int j)
        throws SQLException
    {
        int k = columnIndex + (j - 1) * charLength;
        int l = columnIndexLastRow + (i - 1) * charLength;
        int i1 = (indicatorIndex + j) - 1;
        int j1 = (indicatorIndexLastRow + i) - 1;
        int k1 = (lengthIndex + j) - 1;
        int l1 = (lengthIndexLastRow + i) - 1;
        int i2 = aword0[l1];
        rowSpaceIndicator[k1] = (short)i2;
        rowSpaceIndicator[i1] = aword0[j1];
        if(i2 != 0)
            System.arraycopy(ac, l, rowSpaceChar, k, ac[l] / 2 + 1);
        else
            rowSpaceChar[k] = '\0';
    }

    void calculateSizeTmpByteArray()
    {
        int i;
        if(formOfUse == 2)
            i = (charLength - 1) * statement.connection.conversion.maxNCharSize;
        else
            i = (charLength - 1) * statement.connection.conversion.cMaxCharSize;
        if(statement.sizeTmpByteArray < i)
            statement.sizeTmpByteArray = i;
    }

    String getString(int i)
        throws SQLException
    {
        String s = super.getString(i);
        if(s != null && definedColumnSize > 0 && s.length() > definedColumnSize)
            s = s.substring(0, definedColumnSize);
        return s;
    }

    NUMBER getNUMBER(int i)
        throws SQLException
    {
        NUMBER number = null;
        if(definedColumnType == 0)
        {
            number = super.getNUMBER(i);
        } else
        {
            String s = getString(i);
            if(s != null)
                return T4CVarcharAccessor.StringToNUMBER(s);
        }
        return number;
    }

    DATE getDATE(int i)
        throws SQLException
    {
        DATE date = null;
        if(definedColumnType == 0)
        {
            date = super.getDATE(i);
        } else
        {
            Date date1 = getDate(i);
            if(date1 != null)
                date = new DATE(date1);
        }
        return date;
    }

    TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        TIMESTAMP timestamp = null;
        if(definedColumnType == 0)
        {
            timestamp = super.getTIMESTAMP(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), ai);
                Timestamp timestamp1 = new Timestamp(calendar.getTimeInMillis());
                timestamp1.setNanos(ai[0]);
                timestamp = new TIMESTAMP(timestamp1);
            }
        }
        return timestamp;
    }

    TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        TIMESTAMPTZ timestamptz = null;
        if(definedColumnType == 0)
        {
            timestamptz = super.getTIMESTAMPTZ(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), ai);
                Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
                timestamp.setNanos(ai[0]);
                timestamptz = new TIMESTAMPTZ(statement.connection, timestamp, calendar);
            }
        }
        return timestamptz;
    }

    TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException
    {
        TIMESTAMPLTZ timestampltz = null;
        if(definedColumnType == 0)
        {
            timestampltz = super.getTIMESTAMPLTZ(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), ai);
                Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
                timestamp.setNanos(ai[0]);
                timestampltz = new TIMESTAMPLTZ(statement.connection, timestamp, calendar);
            }
        }
        return timestampltz;
    }

    RAW getRAW(int i)
        throws SQLException
    {
        RAW raw = null;
        if(definedColumnType == 0)
        {
            raw = super.getRAW(i);
        } else
        {
            if(rowSpaceIndicator == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(rowSpaceIndicator[indicatorIndex + i] != -1)
                if(definedColumnType == -2 || definedColumnType == -3 || definedColumnType == -4)
                    raw = new RAW(getBytesFromHexChars(i));
                else
                    raw = new RAW(super.getBytes(i));
        }
        return raw;
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        if(definedColumnType == 0)
            return super.getOracleObject(i);
        Datum datum = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            switch(definedColumnType)
            {
            case -16: 
            case -15: 
            case -9: 
            case -1: 
            case 1: // '\001'
            case 12: // '\f'
                return super.getOracleObject(i);

            case -7: 
            case -6: 
            case -5: 
            case 2: // '\002'
            case 3: // '\003'
            case 4: // '\004'
            case 5: // '\005'
            case 6: // '\006'
            case 7: // '\007'
            case 8: // '\b'
            case 16: // '\020'
                return getNUMBER(i);

            case 91: // '['
                return getDATE(i);

            case 92: // '\\'
                return getDATE(i);

            case 93: // ']'
                return getTIMESTAMP(i);

            case -101: 
                return getTIMESTAMPTZ(i);

            case -102: 
                return getTIMESTAMPLTZ(i);

            case -4: 
            case -3: 
            case -2: 
                return getRAW(i);

            case -8: 
                return getROWID(i);
            }
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return datum;
        }
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        if(definedColumnType == 0)
            return super.getBytes(i);
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.shareBytes();
        else
            return null;
    }

    boolean getBoolean(int i)
        throws SQLException
    {
        boolean flag = false;
        if(definedColumnType == 0)
            flag = super.getBoolean(i);
        else
            flag = getNUMBER(i).booleanValue();
        return flag;
    }

    byte getByte(int i)
        throws SQLException
    {
        byte byte0 = 0;
        if(definedColumnType == 0)
        {
            byte0 = super.getByte(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                byte0 = number.byteValue();
        }
        return byte0;
    }

    int getInt(int i)
        throws SQLException
    {
        int j = 0;
        if(definedColumnType == 0)
        {
            j = super.getInt(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                j = number.intValue();
        }
        return j;
    }

    short getShort(int i)
        throws SQLException
    {
        short word0 = 0;
        if(definedColumnType == 0)
        {
            word0 = super.getShort(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                word0 = number.shortValue();
        }
        return word0;
    }

    long getLong(int i)
        throws SQLException
    {
        long l = 0L;
        if(definedColumnType == 0)
        {
            l = super.getLong(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                l = number.longValue();
        }
        return l;
    }

    float getFloat(int i)
        throws SQLException
    {
        float f = 0.0F;
        if(definedColumnType == 0)
        {
            f = super.getFloat(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                f = number.floatValue();
        }
        return f;
    }

    double getDouble(int i)
        throws SQLException
    {
        double d = 0.0D;
        if(definedColumnType == 0)
        {
            d = super.getDouble(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                d = number.doubleValue();
        }
        return d;
    }

    Date getDate(int i)
        throws SQLException
    {
        Date date = null;
        if(definedColumnType == 0)
        {
            date = super.getDate(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                date = new Date(T4CVarcharAccessor.DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), ai).getTimeInMillis());
            }
        }
        return date;
    }

    Timestamp getTimestamp(int i)
        throws SQLException
    {
        Timestamp timestamp = null;
        if(definedColumnType == 0)
        {
            timestamp = super.getTimestamp(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), ai);
                timestamp = new Timestamp(calendar.getTimeInMillis());
                timestamp.setNanos(ai[0]);
            }
        }
        return timestamp;
    }

    Time getTime(int i)
        throws SQLException
    {
        Time time = null;
        if(definedColumnType == 0)
        {
            time = super.getTime(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), ai);
                time = new Time(calendar.getTimeInMillis());
            }
        }
        return time;
    }

    Object getObject(int i)
        throws SQLException
    {
        if(definedColumnType == 0)
            return super.getObject(i);
        Object obj = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            switch(definedColumnType)
            {
            case -16: 
            case -15: 
            case -9: 
            case -1: 
            case 1: // '\001'
            case 12: // '\f'
                return getString(i);

            case 2: // '\002'
            case 3: // '\003'
                return getBigDecimal(i);

            case 4: // '\004'
                return Integer.valueOf(getInt(i));

            case -6: 
                return Byte.valueOf(getByte(i));

            case 5: // '\005'
                return Short.valueOf(getShort(i));

            case -7: 
            case 16: // '\020'
                return Boolean.valueOf(getBoolean(i));

            case -5: 
                return Long.valueOf(getLong(i));

            case 7: // '\007'
                return Float.valueOf(getFloat(i));

            case 6: // '\006'
            case 8: // '\b'
                return Double.valueOf(getDouble(i));

            case 91: // '['
                return getDate(i);

            case 92: // '\\'
                return getTime(i);

            case 93: // ']'
                return getTimestamp(i);

            case -4: 
            case -3: 
            case -2: 
                return getBytesFromHexChars(i);
            }
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return obj;
        }
    }

}
