// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIoxssro.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, KeywordValueLongI, T4CMAREngine, T4CConnection

final class T4CTTIoxssro extends T4CTTIfun
{

    private int functionId;
    private byte sessionId[];
    private KeywordValueLong inKV[];
    private int inFlags;
    private KeywordValueLong outKV[];
    private int outFlags;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIoxssro(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        sessionId = null;
        inKV = null;
        outKV = null;
        outFlags = -1;
        setFunCode((short)156);
    }

    void doOXSSRO(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j)
        throws IOException, SQLException
    {
        functionId = i;
        sessionId = abyte0;
        inKV = akeywordvaluelong;
        inFlags = j;
        outKV = null;
        outFlags = -1;
        if(inKV != null)
        {
            for(int k = 0; k < inKV.length; k++)
                ((KeywordValueLongI)inKV[k]).doCharConversion(meg.conv);

        }
        doRPC();
    }

    void marshal()
        throws IOException
    {
        meg.marshalUB4(functionId);
        boolean flag = false;
        if(sessionId != null && sessionId.length > 0)
        {
            flag = true;
            meg.marshalPTR();
            meg.marshalUB4(sessionId.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        }
        boolean flag1 = false;
        if(inKV != null && inKV.length > 0)
        {
            flag1 = true;
            meg.marshalPTR();
            meg.marshalUB4(inKV.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        }
        meg.marshalUB4(inFlags);
        meg.marshalPTR();
        meg.marshalPTR();
        meg.marshalPTR();
        if(flag)
            meg.marshalB1Array(sessionId);
        if(flag1)
        {
            for(int i = 0; i < inKV.length; i++)
                ((KeywordValueLongI)inKV[i]).marshal(meg);

        }
    }

    KeywordValueLong[] getOutKV()
    {
        return outKV;
    }

    int getOutFlags()
    {
        return outFlags;
    }

    void readRPA()
        throws SQLException, IOException
    {
        int i = (int)meg.unmarshalUB4();
        outKV = new KeywordValueLong[i];
        for(int j = 0; j < i; j++)
            outKV[j] = KeywordValueLongI.unmarshal(meg);

        outFlags = (int)meg.unmarshalUB4();
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
