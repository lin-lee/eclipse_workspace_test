// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CInputStream.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            OracleInputStream, T4CConnection, OracleStatement, PhysicalConnection, 
//            Accessor, DatabaseError

class T4CInputStream extends OracleInputStream
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CInputStream(OracleStatement oraclestatement, int i, Accessor accessor)
    {
        super(oraclestatement, i, accessor);
    }

    public boolean isNull()
        throws IOException
    {
        boolean flag;
        if(!statement.connection.useFetchSizeWithLongColumn)
            return super.isNull();
        flag = false;
        int i;
        try
        {
            i = statement.currentRow;
            if(i < 0)
                i = 0;
            if(i >= statement.validRows)
                return true;
        }
        catch(SQLException sqlexception)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
        flag = accessor.isNull(i);
        return flag;
    }

    public int getBytes(int i)
        throws IOException
    {
        PhysicalConnection physicalconnection = statement.connection;
        JVM INSTR monitorenter ;
        int j = -1;
        try
        {
            if(statement.connection.lifecycle == 1 || statement.connection.lifecycle == 2)
                j = accessor.readStream(resizableBuffer, initialBufferSize);
        }
        catch(SQLException sqlexception)
        {
            throw new IOException(sqlexception.getMessage());
        }
        catch(IOException ioexception)
        {
            try
            {
                ((T4CConnection)statement.connection).handleIOException(ioexception);
            }
            catch(SQLException sqlexception1) { }
            throw ioexception;
        }
        return j;
        Exception exception;
        exception;
        throw exception;
    }

}
