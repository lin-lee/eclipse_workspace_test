// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CRowidAccessor.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;

// Referenced classes of package oracle.jdbc.driver:
//            RowidAccessor, T4CMAREngine, OracleStatement, PhysicalConnection, 
//            DatabaseError

class T4CRowidAccessor extends RowidAccessor
{

    T4CMAREngine mare;
    static final int maxLength = 128;
    final int meta[];
    static final int KGRD_EXTENDED_OBJECT = 6;
    static final int KGRD_EXTENDED_BLOCK = 6;
    static final int KGRD_EXTENDED_FILE = 3;
    static final int KGRD_EXTENDED_SLOT = 3;
    static final int kd4_ubridtype_physical = 1;
    static final int kd4_ubridtype_logical = 2;
    static final int kd4_ubridtype_remote = 3;
    static final int kd4_ubridtype_exttab = 4;
    static final int kd4_ubridtype_future2 = 5;
    static final int kd4_ubridtype_max = 5;
    static final int kd4_ubridlen_typeind = 1;
    static final byte kgrd_indbyte_char[] = {
        65, 42, 45, 40, 41
    };
    static final byte kgrd_basis_64[] = {
        65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 
        75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 
        85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
        101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 
        111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 
        121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 
        56, 57, 43, 47
    };
    static final byte kgrd_index_64[] = {
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 
        54, 55, 56, 57, 58, 59, 60, 61, -1, -1, 
        -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 
        5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 
        15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 
        25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 
        29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 
        39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 
        49, 50, 51, -1, -1, -1, -1, -1
    };
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CRowidAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, short word0, int j, boolean flag, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, word0, j, flag);
        meta = new int[1];
        mare = t4cmarengine;
        defineType = 104;
    }

    T4CRowidAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, int k1, int l1, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, flag, j, k, l, i1, j1, word0);
        meta = new int[1];
        mare = t4cmarengine;
        definedColumnType = k1;
        definedColumnSize = l1;
        defineType = 104;
    }

    void processIndicator(int i)
        throws IOException, SQLException
    {
        if(internalType == 1 && describeType == 112 || internalType == 23 && describeType == 113)
        {
            mare.unmarshalUB2();
            mare.unmarshalUB2();
        } else
        if(statement.connection.versionNumber < 9200)
        {
            mare.unmarshalSB2();
            if(!statement.sqlKind.isPlsqlOrCall())
                mare.unmarshalSB2();
        } else
        if(statement.sqlKind.isPlsqlOrCall() || isDMLReturnedParam)
            mare.processIndicator(i <= 0, i);
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        if(isUseLess)
        {
            lastRowProcessed++;
            return false;
        }
        if(rowSpaceIndicator == null)
        {
            short word0 = mare.unmarshalUB1();
            long l = 0L;
            boolean flag = false;
            boolean flag1 = false;
            long l3 = 0L;
            boolean flag2 = false;
            if(word0 > 0)
            {
                long l1 = mare.unmarshalUB4();
                int i1 = mare.unmarshalUB2();
                short word2 = mare.unmarshalUB1();
                long l4 = mare.unmarshalUB4();
                int k1 = mare.unmarshalUB2();
            }
            processIndicator(meta[0]);
            lastRowProcessed++;
            return false;
        }
        int i = indicatorIndex + lastRowProcessed;
        int j = lengthIndex + lastRowProcessed;
        if(isNullByDescribe)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
            lastRowProcessed++;
            if(statement.connection.versionNumber < 9200)
                processIndicator(0);
            return false;
        }
        int k = columnIndex + lastRowProcessed * byteLength;
        if(describeType != 208)
        {
            short word1 = mare.unmarshalUB1();
            long l2 = 0L;
            int j1 = 0;
            short word3 = 0;
            long l5 = 0L;
            int i2 = 0;
            if(word1 > 0)
            {
                l2 = mare.unmarshalUB4();
                j1 = mare.unmarshalUB2();
                word3 = mare.unmarshalUB1();
                l5 = mare.unmarshalUB4();
                i2 = mare.unmarshalUB2();
            }
            if(l2 == 0L && j1 == 0 && word3 == 0 && l5 == 0L && i2 == 0)
            {
                meta[0] = 0;
            } else
            {
                long al[] = {
                    l2, (long)j1, l5, (long)i2
                };
                byte abyte1[] = rowidToString(al);
                int j2 = 18;
                if(byteLength - 2 < 18)
                    j2 = byteLength - 2;
                System.arraycopy(abyte1, 0, rowSpaceByte, k + 2, j2);
                meta[0] = j2;
            }
        } else
        if((meta[0] = (int)mare.unmarshalUB4()) > 0)
        {
            byte abyte0[] = new byte[meta[0]];
            mare.unmarshalCLR(abyte0, 0, meta);
            meta[0] = kgrdub2c(abyte0, meta[0], 0, rowSpaceByte, k + 2);
        }
        rowSpaceByte[k] = (byte)((meta[0] & 0xff00) >> 8);
        rowSpaceByte[k + 1] = (byte)(meta[0] & 0xff);
        processIndicator(meta[0]);
        if(meta[0] == 0)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
        } else
        {
            rowSpaceIndicator[j] = (short)meta[0];
            rowSpaceIndicator[i] = 0;
        }
        lastRowProcessed++;
        return false;
    }

    String getString(int i)
        throws SQLException
    {
        String s = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            int j = columnIndex + byteLength * i;
            short word0 = rowSpaceIndicator[lengthIndex + i];
            if(describeType != 208 || rowSpaceByte[j] == 1)
            {
                s = new String(rowSpaceByte, j + 2, word0);
                long al[] = stringToRowid(s.getBytes(), 0, s.length());
                s = new String(rowidToString(al));
            } else
            {
                s = new String(rowSpaceByte, j + 2, word0);
            }
        }
        return s;
    }

    Object getObject(int i)
        throws SQLException
    {
        if(definedColumnType == 0)
            return super.getObject(i);
        Object obj = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            switch(definedColumnType)
            {
            case -15: 
            case -9: 
            case -1: 
            case 1: // '\001'
            case 12: // '\f'
                return getString(i);

            case -8: 
                return getROWID(i);
            }
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return obj;
        }
    }

    void copyRow()
        throws SQLException, IOException
    {
        int i;
        if(lastRowProcessed == 0)
            i = statement.rowPrefetchInLastFetch - 1;
        else
            i = lastRowProcessed - 1;
        int j = columnIndex + lastRowProcessed * byteLength;
        int k = columnIndex + i * byteLength;
        int l = indicatorIndex + lastRowProcessed;
        int i1 = indicatorIndex + i;
        int j1 = lengthIndex + lastRowProcessed;
        int k1 = lengthIndex + i;
        int l1 = rowSpaceIndicator[k1];
        int i2 = metaDataIndex + lastRowProcessed * 1;
        int j2 = metaDataIndex + i * 1;
        rowSpaceIndicator[j1] = (short)l1;
        rowSpaceIndicator[l] = rowSpaceIndicator[i1];
        System.arraycopy(rowSpaceByte, k, rowSpaceByte, j, l1 + 2);
        System.arraycopy(rowSpaceMetaData, j2, rowSpaceMetaData, i2, 1);
        lastRowProcessed++;
    }

    void saveDataFromOldDefineBuffers(byte abyte0[], char ac[], short aword0[], int i, int j)
        throws SQLException
    {
        int k = columnIndex + (j - 1) * byteLength;
        int l = columnIndexLastRow + (i - 1) * byteLength;
        int i1 = (indicatorIndex + j) - 1;
        int j1 = (indicatorIndexLastRow + i) - 1;
        int k1 = (lengthIndex + j) - 1;
        int l1 = (lengthIndexLastRow + i) - 1;
        int i2 = aword0[l1];
        rowSpaceIndicator[k1] = (short)i2;
        rowSpaceIndicator[i1] = aword0[j1];
        if(i2 != 0)
            System.arraycopy(abyte0, l, rowSpaceByte, k, i2 + 2);
    }

    static final byte[] rowidToString(long al[])
    {
        long l = al[0];
        long l1 = al[1];
        long l2 = al[2];
        long l3 = al[3];
        byte byte0 = 18;
        byte abyte0[] = new byte[byte0];
        int i = 0;
        i = kgrd42b(abyte0, l, 6, i);
        i = kgrd42b(abyte0, l1, 3, i);
        i = kgrd42b(abyte0, l2, 6, i);
        i = kgrd42b(abyte0, l3, 3, i);
        return abyte0;
    }

    static final long[] rcToRowid(byte abyte0[], int i, int j)
        throws SQLException
    {
        byte byte0 = 18;
        if(j != byte0)
        {
            throw new SQLException("Rowid size incorrect.");
        } else
        {
            long al[] = new long[3];
            String s = new String(abyte0, i, j);
            long l = Long.parseLong(s.substring(0, 8), 16);
            long l1 = Long.parseLong(s.substring(9, 13), 16);
            long l2 = Long.parseLong(s.substring(14, 8), 16);
            al[0] = l2;
            al[1] = l;
            al[2] = l1;
            return al;
        }
    }

    static final void kgrdr2rc(int i, int j, int k, int l, int i1, byte abyte0[], int j1)
        throws SQLException
    {
        j1 = lmx42h(abyte0, l, 8, j1);
        abyte0[j1++] = 46;
        j1 = lmx42h(abyte0, i1, 4, j1);
        abyte0[j1++] = 46;
        j1 = lmx42h(abyte0, j, 4, j1);
    }

    static final int lmx42h(byte abyte0[], long l, int i, int j)
    {
        String s = Long.toHexString(l).toUpperCase();
        int k = i;
        int i1 = 0;
        do
            if(i1 < s.length())
            {
                abyte0[(j + i) - 1] = (byte)s.charAt(s.length() - i1 - 1);
                i1++;
            } else
            {
                abyte0[(j + i) - 1] = 48;
            }
        while(--i > 0);
        return k + j;
    }

    static final int kgrdc2ub(byte abyte0[], int i, byte abyte1[], int j, int k)
        throws SQLException
    {
        byte byte0 = getRowidType(abyte0, i);
        byte abyte2[] = abyte1;
        int l = k - 1;
        int i1 = 0;
        byte abyte3[] = kgrd_index_64;
        int k1 = 1 + (3 * ((k - 1) / 4) + ((k - 1) % 4 == 0 ? 0 : (k - 1) % 4 - 1));
        if(l == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, 132);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        abyte2[j + 0] = byte0;
        i1 = i + 1;
        int j1 = 1;
        do
        {
            if(l <= 0)
                break;
            if(l == 1)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(null, 132);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            byte byte1 = abyte3[abyte0[i1]];
            if(byte1 == -1)
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(null, 132);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
            i1++;
            byte byte2 = abyte3[abyte0[i1]];
            if(byte2 == -1)
            {
                SQLException sqlexception3 = DatabaseError.createSqlException(null, 132);
                sqlexception3.fillInStackTrace();
                throw sqlexception3;
            }
            abyte2[j + j1] = (byte)((byte1 & 0xff) << 2 | (byte2 & 0x30) >> 4);
            if(l == 2)
                break;
            j1++;
            byte1 = byte2;
            i1++;
            byte2 = abyte3[abyte0[i1]];
            if(byte2 == -1)
            {
                SQLException sqlexception4 = DatabaseError.createSqlException(null, 132);
                sqlexception4.fillInStackTrace();
                throw sqlexception4;
            }
            abyte2[j + j1] = (byte)((byte1 & 0xff) << 4 | (byte2 & 0x3c) >> 2);
            if(l == 3)
                break;
            j1++;
            byte1 = byte2;
            i1++;
            byte2 = abyte3[abyte0[i1]];
            if(byte2 == -1)
            {
                SQLException sqlexception5 = DatabaseError.createSqlException(null, 132);
                sqlexception5.fillInStackTrace();
                throw sqlexception5;
            }
            abyte2[j + j1] = (byte)((byte1 & 3) << 6 | byte2);
            l -= 4;
            i1++;
            j1++;
        } while(true);
        return k1;
    }

    static final long[] stringToRowid(byte abyte0[], int i, int j)
        throws SQLException
    {
        byte byte0 = 18;
        if(j != byte0)
            throw new SQLException("Rowid size incorrect.");
        long al[] = new long[4];
        try
        {
            al[0] = kgrdb42(abyte0, 6, i);
            i += 6;
            al[1] = kgrdb42(abyte0, 3, i);
            i += 3;
            al[2] = kgrdb42(abyte0, 6, i);
            i += 6;
            al[3] = kgrdb42(abyte0, 3, i);
            i += 3;
        }
        catch(Exception exception)
        {
            al[0] = 0L;
            al[1] = 0L;
            al[2] = 0L;
            al[3] = 0L;
        }
        return al;
    }

    static final int kgrd42b(byte abyte0[], long l, int i, int j)
    {
        int k = i;
        long l1 = l;
        for(; i > 0; i--)
        {
            abyte0[(j + i) - 1] = kgrd_basis_64[(int)l1 & 0x3f];
            l1 = l1 >>> 6 & 0x3ffffffL;
        }

        return k + j;
    }

    static final long kgrdb42(byte abyte0[], int i, int j)
        throws SQLException
    {
        long l = 0L;
        for(int k = 0; k < i; k++)
        {
            int i1 = abyte0[j + k];
            i1 = kgrd_index_64[i1];
            if(i1 == -1)
                throw new SQLException("Char data to rowid conversion failed.");
            l <<= 6;
            l |= i1;
        }

        return l;
    }

    static final void kgrdr2ec(int i, int j, int k, int l, int i1, byte abyte0[], int j1)
        throws SQLException
    {
        j1 = kgrd42b(i, abyte0, j1, 6);
        j1 = kgrd42b(j, abyte0, j1, 3);
        j1 = kgrd42b(l, abyte0, j1, 6);
        j1 = kgrd42b(i1, abyte0, j1, 3);
    }

    static final int kgrd42b(int i, byte abyte0[], int j, int k)
        throws SQLException
    {
        int l = k;
        while(k > 0) 
        {
            k--;
            abyte0[j + k] = kgrd_basis_64[i & 0x3f];
            i >>= 6;
        }
        return j + l;
    }

    static final int kgrdub2c(byte abyte0[], int i, int j, byte abyte1[], int k)
        throws SQLException
    {
        int l = -1;
        byte byte0 = abyte0[j];
        if(byte0 == 1)
        {
            int ai[] = new int[abyte0.length];
            for(int j1 = 0; j1 < abyte0.length; j1++)
                ai[j1] = abyte0[j1] & 0xff;

            int k1 = j + 1;
            int i2 = (((ai[k1 + 0] << 8) + ai[k1 + 1] << 8) + ai[k1 + 2] << 8) + ai[k1 + 3];
            k1 = j + 5;
            int k2 = (ai[k1 + 0] << 8) + ai[k1 + 1];
            int i3 = 0;
            k1 = j + 7;
            int k3 = (((ai[k1 + 0] << 8) + ai[k1 + 1] << 8) + ai[k1 + 2] << 8) + ai[k1 + 3];
            k1 = j + 11;
            int l3 = (ai[k1 + 0] << 8) + ai[k1 + 1];
            if(i2 == 0)
                kgrdr2rc(i2, k2, i3, k3, l3, abyte1, k);
            else
                kgrdr2ec(i2, k2, i3, k3, l3, abyte1, k);
            l = 18;
        } else
        {
            int i1 = 0;
            int l1 = i - 1;
            int j2 = 4 * (i / 3) + (i % 3 != 0 ? 0 : i % 3 + 1);
            int l2 = (1 + j2) - 1;
            if(l2 != 0)
            {
                abyte1[k + 0] = kgrd_indbyte_char[byte0 - 1];
                int j3 = j + 1;
                i1 = 1;
                boolean flag = false;
                do
                {
                    if(l1 <= 0)
                        break;
                    abyte1[k + i1++] = kgrd_basis_64[(abyte0[j3] & 0xff) >> 2];
                    if(l1 == 1)
                    {
                        abyte1[k + i1++] = kgrd_basis_64[(abyte0[j3] & 3) << 4];
                        break;
                    }
                    byte byte1 = (byte)(abyte0[j3 + 1] & 0xff);
                    abyte1[k + i1++] = kgrd_basis_64[(abyte0[j3] & 3) << 4 | (byte1 & 0xf0) >> 4];
                    if(l1 == 2)
                    {
                        abyte1[k + i1++] = kgrd_basis_64[(byte1 & 0xf) << 2];
                        break;
                    }
                    j3 += 2;
                    abyte1[k + i1++] = kgrd_basis_64[(byte1 & 0xf) << 2 | (abyte0[j3] & 0xc0) >> 6];
                    abyte1[k + i1] = kgrd_basis_64[abyte0[j3] & 0x3f];
                    l1 -= 3;
                    j3++;
                    i1++;
                } while(true);
            }
            l = i1;
        }
        return l;
    }

    static final boolean isUROWID(byte abyte0[], int i)
    {
        return getRowidType(abyte0, i) == 2;
    }

    static final byte getRowidType(byte abyte0[], int i)
    {
        byte byte0 = 5;
        switch(abyte0[i])
        {
        case 65: // 'A'
            byte0 = 1;
            break;

        case 42: // '*'
            byte0 = 2;
            break;

        case 45: // '-'
            byte0 = 3;
            break;

        case 40: // '('
            byte0 = 4;
            break;

        case 41: // ')'
            byte0 = 5;
            break;
        }
        return byte0;
    }

}
