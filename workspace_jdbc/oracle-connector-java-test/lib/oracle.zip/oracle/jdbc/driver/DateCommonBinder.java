// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.TimeZone;

// Referenced classes of package oracle.jdbc.driver:
//            Binder, OraclePreparedStatement, DatabaseError

abstract class DateCommonBinder extends Binder
{

    static final int GREGORIAN_CUTOVER_YEAR = 1582;
    static final long GREGORIAN_CUTOVER = 0xfffff4e2f964ac00L;
    static final int JAN_1_1_JULIAN_DAY = 0x1a4452;
    static final int EPOCH_JULIAN_DAY = 0x253d8c;
    static final int ONE_SECOND = 1000;
    static final int ONE_MINUTE = 60000;
    static final int ONE_HOUR = 0x36ee80;
    static final long ONE_DAY = 0x5265c00L;
    static final int NUM_DAYS[] = {
        0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 
        304, 334
    };
    static final int LEAP_NUM_DAYS[] = {
        0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 
        305, 335
    };
    static final int MONTH_LENGTH[] = {
        31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 
        30, 31
    };
    static final int LEAP_MONTH_LENGTH[] = {
        31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 
        30, 31
    };
    static final int ORACLE_DATE_CENTURY = 0;
    static final int ORACLE_DATE_YEAR = 1;
    static final int ORACLE_DATE_MONTH = 2;
    static final int ORACLE_DATE_DAY = 3;
    static final int ORACLE_DATE_HOUR = 4;
    static final int ORACLE_DATE_MIN = 5;
    static final int ORACLE_DATE_SEC = 6;
    static final int ORACLE_DATE_NANO1 = 7;
    static final int ORACLE_DATE_NANO2 = 8;
    static final int ORACLE_DATE_NANO3 = 9;
    static final int ORACLE_DATE_NANO4 = 10;
    private static int HOUR_MILLISECOND = 0x36ee80;
    private static int MINUTE_MILLISECOND = 60000;
    private static int SECOND_MILLISECOND = 1000;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    DateCommonBinder()
    {
    }

    static final long floorDivide(long l, long l1)
    {
        return l < 0L ? (l + 1L) / l1 - 1L : l / l1;
    }

    static final int floorDivide(int i, int j)
    {
        return i < 0 ? (i + 1) / j - 1 : i / j;
    }

    static final int floorDivide(int i, int j, int ai[])
    {
        if(i >= 0)
        {
            ai[0] = i % j;
            return i / j;
        } else
        {
            int k = (i + 1) / j - 1;
            ai[0] = i - k * j;
            return k;
        }
    }

    static final int floorDivide(long l, int i, int ai[])
    {
        if(l >= 0L)
        {
            ai[0] = (int)(l % (long)i);
            return (int)(l / (long)i);
        } else
        {
            int j = (int)((l + 1L) / (long)i - 1L);
            ai[0] = (int)(l - (long)(j * i));
            return j;
        }
    }

    static final long zoneOffset(TimeZone timezone, int i, int j, int k, int l, int i1)
    {
        return (long)timezone.getOffset(i >= 0 ? 1 : 0, i, j, k, l, i1);
    }

    static void setOracleNanos(long l, byte abyte0[], int i)
    {
        abyte0[10 + i] = (byte)(int)(l & 255L);
        abyte0[9 + i] = (byte)(int)(l >> 8 & 255L);
        abyte0[8 + i] = (byte)(int)(l >> 16 & 255L);
        abyte0[7 + i] = (byte)(int)(l >> 24 & 255L);
    }

    static void setOracleHMS(int i, byte abyte0[], int j)
    {
        if(i < 0)
        {
            throw new RuntimeException("Assertion botch: negative time");
        } else
        {
            i /= 1000;
            abyte0[6 + j] = (byte)(i % 60 + 1);
            i /= 60;
            abyte0[5 + j] = (byte)(i % 60 + 1);
            i /= 60;
            abyte0[4 + j] = (byte)(i + 1);
            return;
        }
    }

    static final int setOracleCYMD(long l, byte abyte0[], int i, OraclePreparedStatement oraclepreparedstatement)
        throws SQLException
    {
        TimeZone timezone = oraclepreparedstatement.getDefaultTimeZone(true);
        Calendar calendar = oraclepreparedstatement.cachedUTCUSCalendar;
        calendar.setTimeInMillis(l);
        Calendar calendar1 = oraclepreparedstatement.getDefaultCalendar();
        calendar1.setTimeInMillis(l);
        int l1 = calendar1.get(15);
        long l2 = l + (long)l1;
        int j;
        int j1;
        int k1;
        boolean flag;
        if(l2 >= 0xfffff4e2f964ac00L)
        {
            long l3 = (0x253d8cL + floorDivide(l2, 0x5265c00L)) - 0x1a4452L;
            int i2;
            int j2;
            int k2;
            int j3;
            if(l3 > 0L)
            {
                i2 = (int)(l3 / 0x23ab1L);
                k1 = (int)(l3 % 0x23ab1L);
                j2 = k1 / 36524;
                k1 %= 36524;
                k2 = k1 / 1461;
                k1 %= 1461;
                j3 = k1 / 365;
                k1 %= 365;
            } else
            {
                int ai[] = new int[1];
                i2 = floorDivide(l3, 0x23ab1, ai);
                j2 = floorDivide(ai[0], 36524, ai);
                k2 = floorDivide(ai[0], 1461, ai);
                j3 = floorDivide(ai[0], 365, ai);
                k1 = ai[0];
            }
            j = 400 * i2 + 100 * j2 + 4 * k2 + j3;
            if(j2 == 4 || j3 == 4)
                k1 = 365;
            else
                j++;
            flag = (j & 3) == 0 && (j % 100 != 0 || j % 400 == 0);
            j1 = (int)((l3 + 1L) % 7L);
        } else
        {
            long l4 = (0x253d8cL + floorDivide(l2, 0x5265c00L)) - 0x1a4450L;
            j = (int)floorDivide(4L * l4 + 1464L, 1461L);
            long l5 = 365 * (j - 1) + floorDivide(j - 1, 4);
            k1 = (int)(l4 - l5);
            flag = (j & 3) == 0;
            j1 = (int)((l4 - 1L) % 7L);
        }
        byte byte0 = 0;
        byte byte1 = ((byte)(flag ? 60 : 59));
        if(k1 >= byte1)
            byte0 = ((byte)(flag ? 1 : 2));
        int k = (12 * (k1 + byte0) + 6) / 367;
        int i1 = (k1 - (flag ? LEAP_NUM_DAYS[k] : NUM_DAYS[k])) + 1;
        j1 += j1 >= 0 ? 1 : 8;
        long l6 = l2 / 0x5265c00L;
        int i3 = (int)(l2 - l6 * 0x5265c00L);
        if(i3 < 0)
            i3 = (int)((long)i3 + 0x5265c00L);
        long l7 = zoneOffset(timezone, j, k, i1, j1, i3);
        l7 -= l1;
        i3 = (int)((long)i3 + l7);
        if((long)i3 >= 0x5265c00L)
        {
            i3 = (int)((long)i3 - 0x5265c00L);
            if(++i1 > (flag ? LEAP_MONTH_LENGTH[k] : MONTH_LENGTH[k]))
            {
                i1 = 1;
                if(++k == 12)
                {
                    k = 0;
                    j++;
                }
            }
        }
        if(j <= 0)
            j--;
        if(j > 9999 || j < -4712)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, 268);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            abyte0[0 + i] = (byte)(j / 100 + 100);
            abyte0[1 + i] = (byte)(j % 100 + 100);
            abyte0[2 + i] = (byte)(k + 1);
            abyte0[3 + i] = (byte)i1;
            return i3;
        }
    }

}
