// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.sql.Array;
import java.sql.BatchUpdateException;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import oracle.jdbc.OracleData;
import oracle.jdbc.OracleParameterMetaData;
import oracle.jdbc.internal.ObjectData;
import oracle.jdbc.internal.OracleStatement;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.oracore.OracleTypeNUMBER;
import oracle.jdbc.proxy.OracleProxy;
import oracle.jdbc.proxy.ProxyFactory;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.BFILE;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BLOB;
import oracle.sql.CHAR;
import oracle.sql.CLOB;
import oracle.sql.CharacterSet;
import oracle.sql.CustomDatum;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.NUMBER;
import oracle.sql.OPAQUE;
import oracle.sql.ORAData;
import oracle.sql.OpaqueDescriptor;
import oracle.sql.RAW;
import oracle.sql.REF;
import oracle.sql.ROWID;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;

// Referenced classes of package oracle.jdbc.driver:
//            OracleStatement, Binder, PlsqlIbtBindInfo, Accessor, 
//            PlsqlIndexTableAccessor, OracleResultSetImpl, OracleResultSetMetaData, OracleClobWriter, 
//            OracleBlobOutputStream, CopiedNullBinder, CopiedByteBinder, CopiedCharBinder, 
//            OracleParameterMetaData, OracleReturnResultSet, ScrollRsetStatement, PhysicalConnection, 
//            OracleSql, DBConversion, DatabaseError, ResultSetUtil, 
//            T4CRowidAccessor, OracleTimeout, CancelLock, AutoKeyInfo, 
//            OraclePreparedStatementReadOnly

abstract class OraclePreparedStatement extends oracle.jdbc.driver.OracleStatement
    implements oracle.jdbc.internal.OraclePreparedStatement, ScrollRsetStatement
{
    class PushedBatch
    {

        int currentBatchCharLens[];
        int lastBoundCharLens[];
        Accessor currentBatchBindAccessors[];
        boolean lastBoundNeeded;
        boolean need_to_parse;
        boolean current_batch_need_to_prepare_binds;
        int first_row_in_batch;
        int number_of_rows_to_be_bound;
        PushedBatch next;
        final OraclePreparedStatement this$0;

        PushedBatch()
        {
            this$0 = OraclePreparedStatement.this;
            super();
        }
    }


    int numberOfBindRowsAllocated;
    static Binder theStaticVarnumCopyingBinder;
    static Binder theStaticVarnumNullBinder;
    Binder theVarnumNullBinder;
    static Binder theStaticBooleanBinder;
    Binder theBooleanBinder;
    static Binder theStaticByteBinder;
    Binder theByteBinder;
    static Binder theStaticShortBinder;
    Binder theShortBinder;
    static Binder theStaticIntBinder;
    Binder theIntBinder;
    static Binder theStaticLongBinder;
    Binder theLongBinder;
    static Binder theStaticFloatBinder;
    Binder theFloatBinder;
    static Binder theStaticDoubleBinder;
    Binder theDoubleBinder;
    static Binder theStaticBigDecimalBinder;
    Binder theBigDecimalBinder;
    static Binder theStaticVarcharCopyingBinder;
    static Binder theStaticVarcharNullBinder;
    Binder theVarcharNullBinder;
    static Binder theStaticStringBinder;
    Binder theStringBinder;
    static Binder theStaticSetCHARCopyingBinder;
    static Binder theStaticSetCHARBinder;
    static Binder theStaticLittleEndianSetCHARBinder;
    static Binder theStaticSetCHARNullBinder;
    Binder theSetCHARBinder;
    Binder theSetCHARNullBinder;
    static Binder theStaticFixedCHARCopyingBinder;
    static Binder theStaticFixedCHARBinder;
    static Binder theStaticFixedCHARNullBinder;
    Binder theFixedCHARBinder;
    Binder theFixedCHARNullBinder;
    static Binder theStaticDateCopyingBinder;
    static Binder theStaticDateBinder;
    static Binder theStaticDateNullBinder;
    Binder theDateBinder;
    Binder theDateNullBinder;
    static Binder theStaticTimeCopyingBinder;
    static Binder theStaticTimeBinder;
    Binder theTimeBinder;
    static Binder theStaticTimestampCopyingBinder;
    static Binder theStaticTimestampBinder;
    static Binder theStaticTimestampNullBinder;
    Binder theTimestampBinder;
    Binder theTimestampNullBinder;
    static Binder theStaticOracleNumberBinder;
    Binder theOracleNumberBinder;
    static Binder theStaticOracleDateBinder;
    Binder theOracleDateBinder;
    static Binder theStaticOracleTimestampBinder;
    Binder theOracleTimestampBinder;
    static Binder theStaticTSTZCopyingBinder;
    static Binder theStaticTSTZBinder;
    static Binder theStaticTSTZNullBinder;
    Binder theTSTZBinder;
    Binder theTSTZNullBinder;
    static Binder theStaticTSLTZCopyingBinder;
    static Binder theStaticTSLTZBinder;
    static Binder theStaticTSLTZNullBinder;
    Binder theTSLTZBinder;
    Binder theTSLTZNullBinder;
    static Binder theStaticRowidCopyingBinder;
    static Binder theStaticRowidBinder;
    static Binder theStaticLittleEndianRowidBinder;
    static Binder theStaticRowidNullBinder;
    static Binder theStaticURowidNullBinder;
    Binder theRowidBinder;
    Binder theRowidNullBinder;
    Binder theURowidBinder;
    Binder theURowidNullBinder;
    static Binder theStaticIntervalDSCopyingBinder;
    static Binder theStaticIntervalDSBinder;
    static Binder theStaticIntervalDSNullBinder;
    Binder theIntervalDSBinder;
    Binder theIntervalDSNullBinder;
    static Binder theStaticIntervalYMCopyingBinder;
    static Binder theStaticIntervalYMBinder;
    static Binder theStaticIntervalYMNullBinder;
    Binder theIntervalYMBinder;
    Binder theIntervalYMNullBinder;
    static Binder theStaticBfileCopyingBinder;
    static Binder theStaticBfileBinder;
    static Binder theStaticBfileNullBinder;
    Binder theBfileBinder;
    Binder theBfileNullBinder;
    static Binder theStaticBlobCopyingBinder;
    static Binder theStaticBlobBinder;
    static Binder theStaticBlobNullBinder;
    Binder theBlobBinder;
    Binder theBlobNullBinder;
    static Binder theStaticClobCopyingBinder;
    static Binder theStaticClobBinder;
    static Binder theStaticClobNullBinder;
    Binder theClobBinder;
    Binder theClobNullBinder;
    static Binder theStaticRawCopyingBinder;
    static Binder theStaticRawBinder;
    static Binder theStaticRawNullBinder;
    Binder theRawBinder;
    Binder theRawNullBinder;
    static Binder theStaticPlsqlRawCopyingBinder;
    static Binder theStaticPlsqlRawBinder;
    Binder thePlsqlRawBinder;
    static Binder theStaticBinaryFloatCopyingBinder;
    static Binder theStaticBinaryFloatBinder;
    static Binder theStaticBinaryFloatNullBinder;
    Binder theBinaryFloatBinder;
    Binder theBinaryFloatNullBinder;
    static Binder theStaticBINARY_FLOATCopyingBinder;
    static Binder theStaticBINARY_FLOATBinder;
    static Binder theStaticBINARY_FLOATNullBinder;
    Binder theBINARY_FLOATBinder;
    Binder theBINARY_FLOATNullBinder;
    static Binder theStaticBinaryDoubleCopyingBinder;
    static Binder theStaticBinaryDoubleBinder;
    static Binder theStaticBinaryDoubleNullBinder;
    Binder theBinaryDoubleBinder;
    Binder theBinaryDoubleNullBinder;
    static Binder theStaticBINARY_DOUBLECopyingBinder;
    static Binder theStaticBINARY_DOUBLEBinder;
    static Binder theStaticBINARY_DOUBLENullBinder;
    Binder theBINARY_DOUBLEBinder;
    Binder theBINARY_DOUBLENullBinder;
    static Binder theStaticLongStreamBinder;
    Binder theLongStreamBinder;
    static Binder theStaticLongStreamForStringBinder;
    Binder theLongStreamForStringBinder;
    static Binder theStaticLongStreamForStringCopyingBinder;
    static Binder theStaticLongRawStreamBinder;
    Binder theLongRawStreamBinder;
    static Binder theStaticLongRawStreamForBytesBinder;
    Binder theLongRawStreamForBytesBinder;
    static Binder theStaticLongRawStreamForBytesCopyingBinder;
    static Binder theStaticNamedTypeCopyingBinder;
    static Binder theStaticNamedTypeBinder;
    static Binder theStaticNamedTypeNullBinder;
    Binder theNamedTypeBinder;
    Binder theNamedTypeNullBinder;
    static Binder theStaticRefTypeCopyingBinder;
    static Binder theStaticRefTypeBinder;
    static Binder theStaticRefTypeNullBinder;
    Binder theRefTypeBinder;
    Binder theRefTypeNullBinder;
    static Binder theStaticPlsqlIbtCopyingBinder;
    static Binder theStaticPlsqlIbtBinder;
    static Binder theStaticPlsqlIbtNullBinder;
    Binder thePlsqlIbtBinder;
    Binder thePlsqlNullBinder;
    static Binder theStaticOutBinder;
    Binder theOutBinder;
    static Binder theStaticReturnParamBinder;
    Binder theReturnParamBinder;
    static Binder theStaticT4CRowidBinder;
    static Binder theStaticT4CURowidBinder;
    static Binder theStaticT4CRowidNullBinder;
    static Binder theStaticT4CURowidNullBinder;
    private static final TimeZone UTC_TIME_ZONE;
    private static final Calendar UTC_US_CALENDAR;
    protected Calendar cachedUTCUSCalendar;
    public static final int TypeBinder_BYTELEN = 24;
    char digits[];
    Binder binders[][];
    int parameterInt[][];
    long parameterLong[][];
    float parameterFloat[][];
    double parameterDouble[][];
    BigDecimal parameterBigDecimal[][];
    String parameterString[][];
    Date parameterDate[][];
    Time parameterTime[][];
    Timestamp parameterTimestamp[][];
    byte parameterDatum[][][];
    OracleTypeADT parameterOtype[][];
    CLOB lastBoundClobs[];
    BLOB lastBoundBlobs[];
    PlsqlIbtBindInfo parameterPlsqlIbt[][];
    Binder currentRowBinders[];
    int currentRowCharLens[];
    Accessor currentRowBindAccessors[];
    short currentRowFormOfUse[];
    boolean currentRowNeedToPrepareBinds;
    int currentBatchCharLens[];
    Accessor currentBatchBindAccessors[];
    short currentBatchFormOfUse[];
    boolean currentBatchNeedToPrepareBinds;
    PushedBatch pushedBatches;
    PushedBatch pushedBatchesTail;
    int cachedBindByteSize;
    int cachedBindCharSize;
    int cachedBindIndicatorSize;
    int totalBindByteLength;
    int totalBindCharLength;
    int totalBindIndicatorLength;
    static final int BIND_METADATA_NUMBER_OF_BIND_POSITIONS_OFFSET = 0;
    static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_HI = 1;
    static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_LO = 2;
    static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_HI = 3;
    static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_LO = 4;
    static final int BIND_METADATA_PER_POSITION_DATA_OFFSET = 5;
    static final int BIND_METADATA_TYPE_OFFSET = 0;
    static final int BIND_METADATA_BYTE_PITCH_OFFSET = 1;
    static final int BIND_METADATA_CHAR_PITCH_OFFSET = 2;
    static final int BIND_METADATA_VALUE_DATA_OFFSET_HI = 3;
    static final int BIND_METADATA_VALUE_DATA_OFFSET_LO = 4;
    static final int BIND_METADATA_NULL_INDICATORS_OFFSET_HI = 5;
    static final int BIND_METADATA_NULL_INDICATORS_OFFSET_LO = 6;
    static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_HI = 7;
    static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_LO = 8;
    static final int BIND_METADATA_FORM_OF_USE_OFFSET = 9;
    static final int BIND_METADATA_PER_POSITION_SIZE = 10;
    static final int SETLOB_NO_LENGTH = -1;
    int bindBufferCapacity;
    int numberOfBoundRows;
    int indicatorsOffset;
    int valueLengthsOffset;
    boolean preparedAllBinds;
    boolean preparedCharBinds;
    Binder lastBinders[];
    byte lastBoundBytes[];
    int lastBoundByteOffset;
    char lastBoundChars[];
    int lastBoundCharOffset;
    int lastBoundByteOffsets[];
    int lastBoundCharOffsets[];
    int lastBoundByteLens[];
    int lastBoundCharLens[];
    short lastBoundInds[];
    short lastBoundLens[];
    boolean lastBoundNeeded;
    byte lastBoundTypeBytes[][];
    OracleTypeADT lastBoundTypeOtypes[];
    InputStream lastBoundStream[];
    private static final int STREAM_MAX_BYTES_SQL = 0x7fffffff;
    int maxRawBytesSql;
    int maxRawBytesPlsql;
    int maxVcsCharsSql;
    int maxVcsNCharsSql;
    int maxVcsBytesPlsql;
    private int maxCharSize;
    private int maxNCharSize;
    private int charMaxCharsSql;
    private int charMaxNCharsSql;
    private int maxVcsCharsPlsql;
    private int maxVcsNCharsPlsql;
    int maxIbtVarcharElementLength;
    private int maxStreamCharsSql;
    private int maxStreamNCharsSql;
    protected boolean isServerCharSetFixedWidth;
    private boolean isServerNCharSetFixedWidth;
    int minVcsBindSize;
    int prematureBatchCount;
    boolean checkBindTypes;
    boolean scrollRsetTypeSolved;
    private static final double MIN_NUMBER = 1.0000000000000001E-130D;
    private static final double MAX_NUMBER = 9.9999999999999992E+125D;
    int SetBigStringTryClob;
    static final int BSTYLE_UNKNOWN = 0;
    static final int BSTYLE_ORACLE = 1;
    static final int BSTYLE_JDBC = 2;
    int m_batchStyle;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OraclePreparedStatement(PhysicalConnection physicalconnection, String s, int i, int j)
        throws SQLException
    {
        this(physicalconnection, s, i, j, 1003, 1007);
        cacheState = 1;
    }

    OraclePreparedStatement(PhysicalConnection physicalconnection, String s, int i, int j, int k, int l)
        throws SQLException
    {
        super(physicalconnection, i, j, k, l);
        theVarnumNullBinder = theStaticVarnumNullBinder;
        theBooleanBinder = theStaticBooleanBinder;
        theByteBinder = theStaticByteBinder;
        theShortBinder = theStaticShortBinder;
        theIntBinder = theStaticIntBinder;
        theLongBinder = theStaticLongBinder;
        theFloatBinder = null;
        theDoubleBinder = null;
        theBigDecimalBinder = theStaticBigDecimalBinder;
        theVarcharNullBinder = theStaticVarcharNullBinder;
        theStringBinder = theStaticStringBinder;
        theSetCHARNullBinder = theStaticSetCHARNullBinder;
        theFixedCHARBinder = theStaticFixedCHARBinder;
        theFixedCHARNullBinder = theStaticFixedCHARNullBinder;
        theDateBinder = theStaticDateBinder;
        theDateNullBinder = theStaticDateNullBinder;
        theTimeBinder = theStaticTimeBinder;
        theTimestampBinder = theStaticTimestampBinder;
        theTimestampNullBinder = theStaticTimestampNullBinder;
        theOracleNumberBinder = theStaticOracleNumberBinder;
        theOracleDateBinder = theStaticOracleDateBinder;
        theOracleTimestampBinder = theStaticOracleTimestampBinder;
        theTSTZBinder = theStaticTSTZBinder;
        theTSTZNullBinder = theStaticTSTZNullBinder;
        theTSLTZBinder = theStaticTSLTZBinder;
        theTSLTZNullBinder = theStaticTSLTZNullBinder;
        theRowidNullBinder = theStaticRowidNullBinder;
        theURowidNullBinder = theStaticURowidNullBinder;
        theIntervalDSBinder = theStaticIntervalDSBinder;
        theIntervalDSNullBinder = theStaticIntervalDSNullBinder;
        theIntervalYMBinder = theStaticIntervalYMBinder;
        theIntervalYMNullBinder = theStaticIntervalYMNullBinder;
        theBfileBinder = theStaticBfileBinder;
        theBfileNullBinder = theStaticBfileNullBinder;
        theBlobBinder = theStaticBlobBinder;
        theBlobNullBinder = theStaticBlobNullBinder;
        theClobBinder = theStaticClobBinder;
        theClobNullBinder = theStaticClobNullBinder;
        theRawBinder = theStaticRawBinder;
        theRawNullBinder = theStaticRawNullBinder;
        thePlsqlRawBinder = theStaticPlsqlRawBinder;
        theBinaryFloatBinder = theStaticBinaryFloatBinder;
        theBinaryFloatNullBinder = theStaticBinaryFloatNullBinder;
        theBINARY_FLOATBinder = theStaticBINARY_FLOATBinder;
        theBINARY_FLOATNullBinder = theStaticBINARY_FLOATNullBinder;
        theBinaryDoubleBinder = theStaticBinaryDoubleBinder;
        theBinaryDoubleNullBinder = theStaticBinaryDoubleNullBinder;
        theBINARY_DOUBLEBinder = theStaticBINARY_DOUBLEBinder;
        theBINARY_DOUBLENullBinder = theStaticBINARY_DOUBLENullBinder;
        theLongStreamBinder = theStaticLongStreamBinder;
        theLongStreamForStringBinder = theStaticLongStreamForStringBinder;
        theLongRawStreamBinder = theStaticLongRawStreamBinder;
        theLongRawStreamForBytesBinder = theStaticLongRawStreamForBytesBinder;
        theNamedTypeBinder = theStaticNamedTypeBinder;
        theNamedTypeNullBinder = theStaticNamedTypeNullBinder;
        theRefTypeBinder = theStaticRefTypeBinder;
        theRefTypeNullBinder = theStaticRefTypeNullBinder;
        thePlsqlIbtBinder = theStaticPlsqlIbtBinder;
        thePlsqlNullBinder = theStaticPlsqlIbtNullBinder;
        theOutBinder = theStaticOutBinder;
        theReturnParamBinder = theStaticReturnParamBinder;
        cachedUTCUSCalendar = (Calendar)UTC_US_CALENDAR.clone();
        digits = new char[20];
        currentRowNeedToPrepareBinds = true;
        cachedBindByteSize = 0;
        cachedBindCharSize = 0;
        cachedBindIndicatorSize = 0;
        lastBoundNeeded = false;
        maxCharSize = 0;
        maxNCharSize = 0;
        charMaxCharsSql = 0;
        charMaxNCharsSql = 0;
        maxVcsCharsPlsql = 0;
        maxVcsNCharsPlsql = 0;
        maxIbtVarcharElementLength = 0;
        maxStreamCharsSql = 0;
        maxStreamNCharsSql = 0;
        isServerCharSetFixedWidth = false;
        isServerNCharSetFixedWidth = false;
        checkBindTypes = true;
        SetBigStringTryClob = 0;
        m_batchStyle = 0;
        cacheState = 1;
        if(i > 1)
            setOracleBatchStyle();
        theSetCHARBinder = physicalconnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianSetCHARBinder : theStaticSetCHARBinder;
        theURowidBinder = theRowidBinder = physicalconnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianRowidBinder : theStaticRowidBinder;
        statementType = 1;
        currentRow = -1;
        needToParse = true;
        processEscapes = physicalconnection.processEscapes;
        sqlObject.initialize(s);
        sqlKind = sqlObject.getSqlKind();
        clearParameters = true;
        scrollRsetTypeSolved = false;
        prematureBatchCount = 0;
        initializeBinds();
        minVcsBindSize = physicalconnection.minVcsBindSize;
        maxRawBytesSql = physicalconnection.maxRawBytesSql;
        maxRawBytesPlsql = physicalconnection.maxRawBytesPlsql;
        maxVcsCharsSql = physicalconnection.maxVcsCharsSql;
        maxVcsNCharsSql = physicalconnection.maxVcsNCharsSql;
        maxVcsBytesPlsql = physicalconnection.maxVcsBytesPlsql;
        maxIbtVarcharElementLength = physicalconnection.maxIbtVarcharElementLength;
        maxCharSize = connection.conversion.sMaxCharSize;
        maxNCharSize = connection.conversion.maxNCharSize;
        maxVcsCharsPlsql = maxVcsBytesPlsql / maxCharSize;
        maxVcsNCharsPlsql = maxVcsBytesPlsql / maxNCharSize;
        maxStreamCharsSql = 0x7fffffff / maxCharSize;
        maxStreamNCharsSql = maxRawBytesSql / maxNCharSize;
        isServerCharSetFixedWidth = connection.conversion.isServerCharSetFixedWidth;
        isServerNCharSetFixedWidth = connection.conversion.isServerNCharSetFixedWidth;
    }

    void allocBinds(int i)
        throws SQLException
    {
        boolean flag = i > numberOfBindRowsAllocated;
        initializeIndicatorSubRange();
        int j = bindIndicatorSubRange + 5 + numberOfBindPositions * 10;
        int k = i * numberOfBindPositions;
        int l = j + 2 * k;
        if(l > totalBindIndicatorLength)
        {
            short aword0[] = bindIndicators;
            int j1 = bindIndicatorOffset;
            bindIndicatorOffset = 0;
            bindIndicators = new short[l];
            totalBindIndicatorLength = l;
            if(aword0 != null && flag)
                System.arraycopy(aword0, j1, bindIndicators, bindIndicatorOffset, j);
        }
        bindIndicatorSubRange += bindIndicatorOffset;
        bindIndicators[bindIndicatorSubRange + 0] = (short)numberOfBindPositions;
        indicatorsOffset = bindIndicatorOffset + j;
        valueLengthsOffset = indicatorsOffset + k;
        int i1 = indicatorsOffset;
        int k1 = valueLengthsOffset;
        int l1 = bindIndicatorSubRange + 5;
        for(int i2 = 0; i2 < numberOfBindPositions; i2++)
        {
            bindIndicators[l1 + 5] = (short)(i1 >> 16);
            bindIndicators[l1 + 6] = (short)(i1 & 0xffff);
            bindIndicators[l1 + 7] = (short)(k1 >> 16);
            bindIndicators[l1 + 8] = (short)(k1 & 0xffff);
            i1 += i;
            k1 += i;
            l1 += 10;
        }

    }

    void initializeBinds()
        throws SQLException
    {
        numberOfBindPositions = sqlObject.getParameterCount();
        numReturnParams = sqlObject.getReturnParameterCount();
        if(numberOfBindPositions == 0)
        {
            currentRowNeedToPrepareBinds = false;
            return;
        }
        numberOfBindRowsAllocated = batch;
        binders = new Binder[numberOfBindRowsAllocated][numberOfBindPositions];
        currentRowBinders = binders[0];
        currentRowCharLens = new int[numberOfBindPositions];
        currentBatchCharLens = new int[numberOfBindPositions];
        currentRowFormOfUse = new short[numberOfBindPositions];
        currentBatchFormOfUse = new short[numberOfBindPositions];
        lastBoundClobs = new CLOB[numberOfBindPositions];
        lastBoundBlobs = new BLOB[numberOfBindPositions];
        short word0 = 1;
        if(connection.defaultnchar)
            word0 = 2;
        for(int i = 0; i < numberOfBindPositions; i++)
        {
            currentRowFormOfUse[i] = word0;
            currentBatchFormOfUse[i] = word0;
        }

        lastBinders = new Binder[numberOfBindPositions];
        lastBoundCharLens = new int[numberOfBindPositions];
        lastBoundByteOffsets = new int[numberOfBindPositions];
        lastBoundCharOffsets = new int[numberOfBindPositions];
        lastBoundByteLens = new int[numberOfBindPositions];
        lastBoundInds = new short[numberOfBindPositions];
        lastBoundLens = new short[numberOfBindPositions];
        lastBoundTypeBytes = new byte[numberOfBindPositions][];
        lastBoundTypeOtypes = new OracleTypeADT[numberOfBindPositions];
        allocBinds(numberOfBindRowsAllocated);
    }

    void growBinds(int i)
        throws SQLException
    {
        Binder abinder[][] = binders;
        binders = new Binder[i][];
        if(abinder != null)
            System.arraycopy(abinder, 0, binders, 0, numberOfBindRowsAllocated);
        for(int j = numberOfBindRowsAllocated; j < i; j++)
            binders[j] = new Binder[numberOfBindPositions];

        allocBinds(i);
        if(parameterInt != null)
        {
            int ai[][] = parameterInt;
            parameterInt = new int[i][];
            System.arraycopy(ai, 0, parameterInt, 0, numberOfBindRowsAllocated);
            for(int k = numberOfBindRowsAllocated; k < i; k++)
                parameterInt[k] = new int[numberOfBindPositions];

        }
        if(parameterLong != null)
        {
            long al[][] = parameterLong;
            parameterLong = new long[i][];
            System.arraycopy(al, 0, parameterLong, 0, numberOfBindRowsAllocated);
            for(int l = numberOfBindRowsAllocated; l < i; l++)
                parameterLong[l] = new long[numberOfBindPositions];

        }
        if(parameterFloat != null)
        {
            float af[][] = parameterFloat;
            parameterFloat = new float[i][];
            System.arraycopy(af, 0, parameterFloat, 0, numberOfBindRowsAllocated);
            for(int i1 = numberOfBindRowsAllocated; i1 < i; i1++)
                parameterFloat[i1] = new float[numberOfBindPositions];

        }
        if(parameterDouble != null)
        {
            double ad[][] = parameterDouble;
            parameterDouble = new double[i][];
            System.arraycopy(ad, 0, parameterDouble, 0, numberOfBindRowsAllocated);
            for(int j1 = numberOfBindRowsAllocated; j1 < i; j1++)
                parameterDouble[j1] = new double[numberOfBindPositions];

        }
        if(parameterBigDecimal != null)
        {
            BigDecimal abigdecimal[][] = parameterBigDecimal;
            parameterBigDecimal = new BigDecimal[i][];
            System.arraycopy(abigdecimal, 0, parameterBigDecimal, 0, numberOfBindRowsAllocated);
            for(int k1 = numberOfBindRowsAllocated; k1 < i; k1++)
                parameterBigDecimal[k1] = new BigDecimal[numberOfBindPositions];

        }
        if(parameterString != null)
        {
            String as[][] = parameterString;
            parameterString = new String[i][];
            System.arraycopy(as, 0, parameterString, 0, numberOfBindRowsAllocated);
            for(int l1 = numberOfBindRowsAllocated; l1 < i; l1++)
                parameterString[l1] = new String[numberOfBindPositions];

        }
        if(parameterDate != null)
        {
            Date adate[][] = parameterDate;
            parameterDate = new Date[i][];
            System.arraycopy(adate, 0, parameterDate, 0, numberOfBindRowsAllocated);
            for(int i2 = numberOfBindRowsAllocated; i2 < i; i2++)
                parameterDate[i2] = new Date[numberOfBindPositions];

        }
        if(parameterTime != null)
        {
            Time atime[][] = parameterTime;
            parameterTime = new Time[i][];
            System.arraycopy(atime, 0, parameterTime, 0, numberOfBindRowsAllocated);
            for(int j2 = numberOfBindRowsAllocated; j2 < i; j2++)
                parameterTime[j2] = new Time[numberOfBindPositions];

        }
        if(parameterTimestamp != null)
        {
            Timestamp atimestamp[][] = parameterTimestamp;
            parameterTimestamp = new Timestamp[i][];
            System.arraycopy(atimestamp, 0, parameterTimestamp, 0, numberOfBindRowsAllocated);
            for(int k2 = numberOfBindRowsAllocated; k2 < i; k2++)
                parameterTimestamp[k2] = new Timestamp[numberOfBindPositions];

        }
        if(parameterDatum != null)
        {
            byte abyte0[][][] = parameterDatum;
            parameterDatum = new byte[i][][];
            System.arraycopy(abyte0, 0, parameterDatum, 0, numberOfBindRowsAllocated);
            for(int l2 = numberOfBindRowsAllocated; l2 < i; l2++)
                parameterDatum[l2] = new byte[numberOfBindPositions][];

        }
        if(parameterOtype != null)
        {
            OracleTypeADT aoracletypeadt[][] = parameterOtype;
            parameterOtype = new OracleTypeADT[i][];
            System.arraycopy(aoracletypeadt, 0, parameterOtype, 0, numberOfBindRowsAllocated);
            for(int i3 = numberOfBindRowsAllocated; i3 < i; i3++)
                parameterOtype[i3] = new OracleTypeADT[numberOfBindPositions];

        }
        if(parameterStream != null)
        {
            InputStream ainputstream[][] = parameterStream;
            parameterStream = new InputStream[i][];
            System.arraycopy(ainputstream, 0, parameterStream, 0, numberOfBindRowsAllocated);
            for(int j3 = numberOfBindRowsAllocated; j3 < i; j3++)
                parameterStream[j3] = new InputStream[numberOfBindPositions];

        }
        if(userStream != null)
        {
            Object aobj[][] = userStream;
            userStream = new Object[i][];
            System.arraycopy(((Object) (aobj)), 0, ((Object) (userStream)), 0, numberOfBindRowsAllocated);
            for(int k3 = numberOfBindRowsAllocated; k3 < i; k3++)
                userStream[k3] = new Object[numberOfBindPositions];

        }
        if(parameterPlsqlIbt != null)
        {
            PlsqlIbtBindInfo aplsqlibtbindinfo[][] = parameterPlsqlIbt;
            parameterPlsqlIbt = new PlsqlIbtBindInfo[i][];
            System.arraycopy(aplsqlibtbindinfo, 0, parameterPlsqlIbt, 0, numberOfBindRowsAllocated);
            for(int l3 = numberOfBindRowsAllocated; l3 < i; l3++)
                parameterPlsqlIbt[l3] = new PlsqlIbtBindInfo[numberOfBindPositions];

        }
        numberOfBindRowsAllocated = i;
        currentRowNeedToPrepareBinds = true;
    }

    void processCompletedBindRow(int i, boolean flag)
        throws SQLException
    {
        if(numberOfBindPositions == 0)
            return;
        boolean flag1 = false;
        boolean flag2 = false;
        boolean flag3 = false;
        boolean flag4 = currentRank == firstRowInBatch;
        Binder abinder[] = currentRank != 0 ? binders[currentRank - 1] : lastBinders[0] != null ? lastBinders : null;
        if(currentRowBindAccessors == null)
        {
            boolean flag5 = isAutoGeneratedKey && clearParameters;
            if(abinder == null)
            {
                for(int j = 0; j < numberOfBindPositions; j++)
                    if(currentRowBinders[j] == null)
                        if(flag5)
                        {
                            registerReturnParamsForAutoKey();
                            flag5 = false;
                        } else
                        {
                            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(j + 1));
                            sqlexception1.fillInStackTrace();
                            throw sqlexception1;
                        }

            } else
            if(checkBindTypes)
            {
                OracleTypeADT aoracletypeadt1[] = currentRank != 0 ? parameterOtype != null ? parameterOtype[currentRank - 1] : null : lastBoundTypeOtypes;
                for(int k = 0; k < numberOfBindPositions; k++)
                {
                    if(currentRowBinders[k] == null && flag5)
                    {
                        registerReturnParamsForAutoKey();
                        flag5 = false;
                    }
                    Binder binder5 = currentRowBinders[k];
                    if(binder5 == null)
                    {
                        if(clearParameters)
                        {
                            SQLException sqlexception5 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(k + 1));
                            sqlexception5.fillInStackTrace();
                            throw sqlexception5;
                        }
                        currentRowBinders[k] = abinder[k].copyingBinder();
                        if(currentRank == 0)
                            currentRowBinders[k].lastBoundValueCleanup(this, k);
                        currentRowCharLens[k] = -1;
                        flag2 = true;
                    } else
                    {
                        short word0 = binder5.type;
                        if(word0 != abinder[k].type || (word0 == 109 || word0 == 111) && !parameterOtype[currentRank][k].isInHierarchyOf(aoracletypeadt1[k]) || word0 == 9 && (binder5.bytelen == 0) != (abinder[k].bytelen == 0))
                            flag1 = true;
                    }
                    if(currentBatchFormOfUse[k] != currentRowFormOfUse[k])
                        flag1 = true;
                }

            } else
            {
                for(int l = 0; l < numberOfBindPositions; l++)
                {
                    Binder binder3 = currentRowBinders[l];
                    if(binder3 != null)
                        continue;
                    if(clearParameters)
                    {
                        SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(l + 1));
                        sqlexception3.fillInStackTrace();
                        throw sqlexception3;
                    }
                    currentRowBinders[l] = abinder[l].copyingBinder();
                    if(currentRank == 0)
                        currentRowBinders[l].lastBoundValueCleanup(this, l);
                    currentRowCharLens[l] = -1;
                    flag2 = true;
                }

            }
            if(flag2 && (flag4 || m_batchStyle == 2))
                lastBoundNeeded = true;
        } else
        {
            if(abinder == null)
            {
                for(int i1 = 0; i1 < numberOfBindPositions; i1++)
                {
                    Binder binder = currentRowBinders[i1];
                    Accessor accessor = currentRowBindAccessors[i1];
                    if(binder == null)
                    {
                        if(accessor == null)
                        {
                            SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(i1 + 1));
                            sqlexception4.fillInStackTrace();
                            throw sqlexception4;
                        }
                        currentRowBinders[i1] = theOutBinder;
                    } else
                    if(accessor != null && accessor.defineType != binder.type && (!connection.permitTimestampDateMismatch || binder.type != 180 || accessor.defineType != 12))
                        flag3 = true;
                }

            } else
            if(checkBindTypes)
            {
                OracleTypeADT aoracletypeadt[] = currentRank != 0 ? parameterOtype != null ? parameterOtype[currentRank - 1] : null : lastBoundTypeOtypes;
                for(int j1 = 0; j1 < numberOfBindPositions; j1++)
                {
                    Binder binder4 = currentRowBinders[j1];
                    Accessor accessor1 = currentRowBindAccessors[j1];
                    if(binder4 == null)
                    {
                        if(clearParameters && abinder[j1] != theOutBinder)
                        {
                            SQLException sqlexception6 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(j1 + 1));
                            sqlexception6.fillInStackTrace();
                            throw sqlexception6;
                        }
                        binder4 = abinder[j1];
                        currentRowBinders[j1] = binder4;
                        currentRowCharLens[j1] = -1;
                        if(binder4 != theOutBinder)
                            flag2 = true;
                    } else
                    {
                        short word1 = binder4.type;
                        if(word1 != abinder[j1].type || (word1 == 109 || word1 == 111) && !parameterOtype[currentRank][j1].isInHierarchyOf(aoracletypeadt[j1]) || word1 == 9 && (binder4.bytelen == 0) != (abinder[j1].bytelen == 0))
                            flag1 = true;
                    }
                    if(currentBatchFormOfUse[j1] != currentRowFormOfUse[j1])
                        flag1 = true;
                    Accessor accessor2 = currentBatchBindAccessors[j1];
                    if(accessor1 == null)
                    {
                        accessor1 = accessor2;
                        currentRowBindAccessors[j1] = accessor1;
                    } else
                    if(accessor2 != null && accessor1.defineType != accessor2.defineType)
                        flag1 = true;
                    if(accessor1 != null && binder4 != theOutBinder && accessor1.defineType != binder4.type && (!connection.permitTimestampDateMismatch || binder4.type != 180 || accessor1.defineType != 12))
                        flag3 = true;
                }

            } else
            {
                for(int k1 = 0; k1 < numberOfBindPositions; k1++)
                {
                    Binder binder1 = currentRowBinders[k1];
                    if(binder1 == null)
                    {
                        if(clearParameters && abinder[k1] != theOutBinder)
                        {
                            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 41, Integer.valueOf(k1 + 1));
                            sqlexception2.fillInStackTrace();
                            throw sqlexception2;
                        }
                        Binder binder2 = abinder[k1];
                        currentRowBinders[k1] = binder2;
                        currentRowCharLens[k1] = -1;
                        if(binder2 != theOutBinder)
                            flag2 = true;
                    }
                    if(currentRowBindAccessors[k1] == null)
                        currentRowBindAccessors[k1] = currentBatchBindAccessors[k1];
                }

            }
            if(flag2 && flag4)
                lastBoundNeeded = true;
        }
        if(flag1)
        {
            if(!flag4)
                if(m_batchStyle == 2)
                {
                    pushBatch(false);
                } else
                {
                    int k2 = validRows;
                    prematureBatchCount = sendBatch();
                    validRows = k2;
                    for(int l1 = 0; l1 < numberOfBindPositions; l1++)
                        currentRowBinders[l1].lastBoundValueCleanup(this, l1);

                    if(flag2)
                        lastBoundNeeded = true;
                }
            needToParse = true;
            currentRowNeedToPrepareBinds = true;
            needToPrepareDefineBuffer = true;
        } else
        if(flag)
        {
            pushBatch(false);
            needToParse = false;
            currentBatchNeedToPrepareBinds = false;
        }
        if(flag3)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        for(int i2 = 0; i2 < numberOfBindPositions; i2++)
        {
            int l2 = currentRowCharLens[i2];
            if(l2 == -1 && currentRank == firstRowInBatch)
                l2 = lastBoundCharLens[i2];
            if(currentBatchCharLens[i2] < l2)
                currentBatchCharLens[i2] = l2;
            currentRowCharLens[i2] = 0;
            currentBatchFormOfUse[i2] = currentRowFormOfUse[i2];
        }

        if(currentRowNeedToPrepareBinds)
            currentBatchNeedToPrepareBinds = true;
        if(currentRowBindAccessors != null)
        {
            Accessor aaccessor[] = currentBatchBindAccessors;
            currentBatchBindAccessors = currentRowBindAccessors;
            if(aaccessor == null)
            {
                aaccessor = new Accessor[numberOfBindPositions];
            } else
            {
                for(int j2 = 0; j2 < numberOfBindPositions; j2++)
                    aaccessor[j2] = null;

            }
            currentRowBindAccessors = aaccessor;
        }
        int i3 = currentRank + 1;
        if(i3 < i)
        {
            if(i3 >= numberOfBindRowsAllocated)
            {
                int j3 = numberOfBindRowsAllocated << 1;
                if(j3 <= i3)
                    j3 = i3 + 1;
                growBinds(j3);
                currentBatchNeedToPrepareBinds = true;
                if(pushedBatches != null)
                    pushedBatches.current_batch_need_to_prepare_binds = true;
            }
            currentRowBinders = binders[i3];
        } else
        {
            setupBindBuffers(0, i);
            currentRowBinders = binders[0];
        }
        currentRowNeedToPrepareBinds = false;
        clearParameters = false;
    }

    void processPlsqlIndexTabBinds(int i)
        throws SQLException
    {
        int j = 0;
        int k = 0;
        int l = 0;
        int i1 = 0;
        Binder abinder[] = binders[i];
        PlsqlIbtBindInfo aplsqlibtbindinfo[] = parameterPlsqlIbt != null ? parameterPlsqlIbt[i] : null;
        for(int j1 = 0; j1 < numberOfBindPositions; j1++)
        {
            Binder binder = abinder[j1];
            Accessor accessor = currentBatchBindAccessors != null ? currentBatchBindAccessors[j1] : null;
            PlsqlIndexTableAccessor plsqlindextableaccessor = accessor != null && accessor.defineType == 998 ? (PlsqlIndexTableAccessor)accessor : null;
            if(binder.type == 998)
            {
                PlsqlIbtBindInfo plsqlibtbindinfo = aplsqlibtbindinfo[j1];
                if(plsqlindextableaccessor != null)
                {
                    if(plsqlibtbindinfo.element_internal_type != plsqlindextableaccessor.elementInternalType)
                    {
                        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12);
                        sqlexception.fillInStackTrace();
                        throw sqlexception;
                    }
                    if(plsqlibtbindinfo.maxLen < plsqlindextableaccessor.maxNumberOfElements)
                        plsqlibtbindinfo.maxLen = plsqlindextableaccessor.maxNumberOfElements;
                    if(plsqlibtbindinfo.elemMaxLen < plsqlindextableaccessor.elementMaxLen)
                        plsqlibtbindinfo.elemMaxLen = plsqlindextableaccessor.elementMaxLen;
                    if(plsqlibtbindinfo.ibtByteLength > 0)
                        plsqlibtbindinfo.ibtByteLength = plsqlibtbindinfo.elemMaxLen * plsqlibtbindinfo.maxLen;
                    else
                        plsqlibtbindinfo.ibtCharLength = plsqlibtbindinfo.elemMaxLen * plsqlibtbindinfo.maxLen;
                }
                j++;
                l += plsqlibtbindinfo.ibtByteLength;
                i1 += plsqlibtbindinfo.ibtCharLength;
                k += plsqlibtbindinfo.maxLen;
                continue;
            }
            if(plsqlindextableaccessor != null)
            {
                j++;
                l += plsqlindextableaccessor.ibtByteLength;
                i1 += plsqlindextableaccessor.ibtCharLength;
                k += plsqlindextableaccessor.maxNumberOfElements;
            }
        }

        if(j == 0)
            return;
        ibtBindIndicatorSize = 6 + j * 8 + k * 2;
        ibtBindIndicators = new short[ibtBindIndicatorSize];
        ibtBindIndicatorOffset = 0;
        if(l > 0)
            ibtBindBytes = new byte[l];
        ibtBindByteOffset = 0;
        if(i1 > 0)
            ibtBindChars = new char[i1];
        ibtBindCharOffset = 0;
        int k1 = ibtBindByteOffset;
        int l1 = ibtBindCharOffset;
        int k2 = ibtBindIndicatorOffset;
        int l2 = k2 + 6 + j * 8;
        ibtBindIndicators[k2++] = (short)(j >> 16);
        ibtBindIndicators[k2++] = (short)(j & 0xffff);
        ibtBindIndicators[k2++] = (short)(l >> 16);
        ibtBindIndicators[k2++] = (short)(l & 0xffff);
        ibtBindIndicators[k2++] = (short)(i1 >> 16);
        ibtBindIndicators[k2++] = (short)(i1 & 0xffff);
        for(int i3 = 0; i3 < numberOfBindPositions; i3++)
        {
            Binder binder1 = abinder[i3];
            Accessor accessor1 = currentBatchBindAccessors != null ? currentBatchBindAccessors[i3] : null;
            PlsqlIndexTableAccessor plsqlindextableaccessor1 = accessor1 != null && accessor1.defineType == 998 ? (PlsqlIndexTableAccessor)accessor1 : null;
            if(binder1.type == 998)
            {
                PlsqlIbtBindInfo plsqlibtbindinfo1 = aplsqlibtbindinfo[i3];
                int k3 = plsqlibtbindinfo1.maxLen;
                ibtBindIndicators[k2++] = (short)plsqlibtbindinfo1.element_internal_type;
                ibtBindIndicators[k2++] = (short)plsqlibtbindinfo1.elemMaxLen;
                ibtBindIndicators[k2++] = (short)(k3 >> 16);
                ibtBindIndicators[k2++] = (short)(k3 & 0xffff);
                ibtBindIndicators[k2++] = (short)(plsqlibtbindinfo1.curLen >> 16);
                ibtBindIndicators[k2++] = (short)(plsqlibtbindinfo1.curLen & 0xffff);
                int i2;
                if(plsqlibtbindinfo1.ibtByteLength > 0)
                {
                    i2 = k1;
                    k1 += plsqlibtbindinfo1.ibtByteLength;
                } else
                {
                    i2 = l1;
                    l1 += plsqlibtbindinfo1.ibtCharLength;
                }
                ibtBindIndicators[k2++] = (short)(i2 >> 16);
                ibtBindIndicators[k2++] = (short)(i2 & 0xffff);
                plsqlibtbindinfo1.ibtValueIndex = i2;
                plsqlibtbindinfo1.ibtIndicatorIndex = l2;
                plsqlibtbindinfo1.ibtLengthIndex = l2 + k3;
                if(plsqlindextableaccessor1 != null)
                {
                    plsqlindextableaccessor1.ibtIndicatorIndex = plsqlibtbindinfo1.ibtIndicatorIndex;
                    plsqlindextableaccessor1.ibtLengthIndex = plsqlibtbindinfo1.ibtLengthIndex;
                    plsqlindextableaccessor1.ibtMetaIndex = k2 - 8;
                    plsqlindextableaccessor1.ibtValueIndex = i2;
                }
                l2 += 2 * k3;
                continue;
            }
            if(plsqlindextableaccessor1 == null)
                continue;
            int j3 = plsqlindextableaccessor1.maxNumberOfElements;
            ibtBindIndicators[k2++] = (short)plsqlindextableaccessor1.elementInternalType;
            ibtBindIndicators[k2++] = (short)plsqlindextableaccessor1.elementMaxLen;
            ibtBindIndicators[k2++] = (short)(j3 >> 16);
            ibtBindIndicators[k2++] = (short)(j3 & 0xffff);
            ibtBindIndicators[k2++] = 0;
            ibtBindIndicators[k2++] = 0;
            int j2;
            if(plsqlindextableaccessor1.ibtByteLength > 0)
            {
                j2 = k1;
                k1 += plsqlindextableaccessor1.ibtByteLength;
            } else
            {
                j2 = l1;
                l1 += plsqlindextableaccessor1.ibtCharLength;
            }
            ibtBindIndicators[k2++] = (short)(j2 >> 16);
            ibtBindIndicators[k2++] = (short)(j2 & 0xffff);
            plsqlindextableaccessor1.ibtValueIndex = j2;
            plsqlindextableaccessor1.ibtIndicatorIndex = l2;
            plsqlindextableaccessor1.ibtLengthIndex = l2 + j3;
            plsqlindextableaccessor1.ibtMetaIndex = k2 - 8;
            l2 += 2 * j3;
        }

    }

    void initializeBindSubRanges(int i, int j)
    {
        bindByteSubRange = 0;
        bindCharSubRange = 0;
    }

    int calculateIndicatorSubRangeSize()
    {
        return 0;
    }

    short getInoutIndicator(int i)
    {
        return 0;
    }

    void initializeIndicatorSubRange()
    {
        bindIndicatorSubRange = calculateIndicatorSubRangeSize();
    }

    void prepareBindPreambles(int i, int j)
    {
    }

    void setupBindBuffers(int i, int j)
        throws SQLException
    {
        int j2;
        int k2;
        int i3;
        int j3;
        int k3;
        int l4;
        int j5;
        int k5;
        int j6;
        int i7;
        int l7;
        int k8;
        Binder abinder1[];
        boolean flag1;
        int ai[];
        try
        {
            if(numberOfBindPositions == 0)
            {
                if(j != 0)
                {
                    if(bindIndicators == null)
                        allocBinds(j);
                    numberOfBoundRows = j;
                    bindIndicators[bindIndicatorSubRange + 3] = (short)((numberOfBoundRows & 0xffff0000) >> 16);
                    bindIndicators[bindIndicatorSubRange + 4] = (short)(numberOfBoundRows & 0xffff);
                }
                return;
            }
        }
        catch(NullPointerException nullpointerexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        preparedAllBinds = currentBatchNeedToPrepareBinds;
        preparedCharBinds = false;
        currentBatchNeedToPrepareBinds = false;
        numberOfBoundRows = j;
        bindIndicators[bindIndicatorSubRange + 3] = (short)((numberOfBoundRows & 0xffff0000) >> 16);
        bindIndicators[bindIndicatorSubRange + 4] = (short)(numberOfBoundRows & 0xffff);
        j2 = bindBufferCapacity;
        if(numberOfBoundRows > bindBufferCapacity)
        {
            j2 = numberOfBoundRows;
            preparedAllBinds = true;
        }
        if(currentBatchBindAccessors != null)
        {
            if(outBindAccessors == null)
                outBindAccessors = new Accessor[numberOfBindPositions];
            for(int k = 0; k < numberOfBindPositions; k++)
            {
                Accessor accessor = currentBatchBindAccessors[k];
                outBindAccessors[k] = accessor;
                if(accessor == null)
                    continue;
                int l2 = accessor.charLength;
                if(l2 == 0 || currentBatchCharLens[k] < l2)
                    currentBatchCharLens[k] = l2;
            }

        }
        k2 = 0;
        i3 = 0;
        j3 = bindIndicatorSubRange + 5;
        k3 = j3;
        if(preparedAllBinds)
        {
            preparedCharBinds = true;
            Binder abinder[] = binders[i];
            for(int l = 0; l < numberOfBindPositions; l++)
            {
                Binder binder = abinder[l];
                int k6 = currentBatchCharLens[l];
                short word0;
                int l5;
                if(binder == theOutBinder)
                {
                    Accessor accessor1 = currentBatchBindAccessors[l];
                    l5 = accessor1.byteLength;
                    word0 = (short)accessor1.defineType;
                } else
                {
                    l5 = binder.bytelen;
                    word0 = binder.type;
                }
                if(binder == theRawNullBinder && sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.PLSQL_BLOCK)
                    l5 = 32767;
                i3 += l5;
                k2 += k6;
                bindIndicators[k3 + 0] = word0;
                bindIndicators[k3 + 1] = (short)l5;
                bindIndicators[k3 + 2] = (short)k6;
                bindIndicators[k3 + 9] = currentBatchFormOfUse[l];
                k3 += 10;
            }

        } else
        if(preparedCharBinds)
        {
            for(int i1 = 0; i1 < numberOfBindPositions; i1++)
            {
                int l3 = currentBatchCharLens[i1];
                k2 += l3;
                bindIndicators[k3 + 2] = (short)l3;
                k3 += 10;
            }

        } else
        {
            for(int j1 = 0; j1 < numberOfBindPositions; j1++)
            {
                int i4 = k3 + 2;
                int i5 = currentBatchCharLens[j1];
                short word1 = bindIndicators[i4];
                int i6 = (bindIndicators[k3 + 5] << 16) + (bindIndicators[k3 + 6] & 0xffff);
                boolean flag = bindIndicators[i6] == -1;
                if(flag && i5 > 1)
                    preparedCharBinds = true;
                if(word1 >= i5 && !preparedCharBinds)
                {
                    currentBatchCharLens[j1] = word1;
                    k2 += word1;
                } else
                {
                    bindIndicators[i4] = (short)i5;
                    k2 += i5;
                    preparedCharBinds = true;
                }
                k3 += 10;
            }

        }
        if(preparedCharBinds)
            initializeBindSubRanges(numberOfBoundRows, j2);
        if(preparedAllBinds)
        {
            int j4 = bindByteSubRange + i3 * j2;
            if(lastBoundNeeded || j4 > totalBindByteLength)
            {
                bindByteOffset = 0;
                bindBytes = connection.getByteBuffer(j4);
                totalBindByteLength = j4;
            }
            bindBufferCapacity = j2;
            bindIndicators[bindIndicatorSubRange + 1] = (short)((bindBufferCapacity & 0xffff0000) >> 16);
            bindIndicators[bindIndicatorSubRange + 2] = (short)(bindBufferCapacity & 0xffff);
        }
        if(preparedCharBinds)
        {
            int k4 = bindCharSubRange + k2 * bindBufferCapacity;
            if(lastBoundNeeded || k4 > totalBindCharLength)
            {
                bindCharOffset = 0;
                bindChars = connection.getCharBuffer(k4);
                totalBindCharLength = k4;
            }
            bindByteSubRange += bindByteOffset;
            bindCharSubRange += bindCharOffset;
        }
        l4 = bindByteSubRange;
        j5 = bindCharSubRange;
        k5 = indicatorsOffset;
        j6 = valueLengthsOffset;
        k3 = j3;
        if(preparedCharBinds)
        {
            if(currentBatchBindAccessors == null)
            {
                for(int k1 = 0; k1 < numberOfBindPositions; k1++)
                {
                    short word2 = bindIndicators[k3 + 1];
                    int j7 = currentBatchCharLens[k1];
                    int i8 = j7 != 0 ? j5 : l4;
                    bindIndicators[k3 + 3] = (short)(i8 >> 16);
                    bindIndicators[k3 + 4] = (short)(i8 & 0xffff);
                    l4 += word2 * bindBufferCapacity;
                    j5 += j7 * bindBufferCapacity;
                    k3 += 10;
                }

            } else
            {
                for(int l1 = 0; l1 < numberOfBindPositions; l1++)
                {
                    int l6 = bindIndicators[k3 + 1];
                    int k7 = currentBatchCharLens[l1];
                    int j8 = k7 != 0 ? j5 : l4;
                    bindIndicators[k3 + 3] = (short)(j8 >> 16);
                    bindIndicators[k3 + 4] = (short)(j8 & 0xffff);
                    Accessor accessor2 = currentBatchBindAccessors[l1];
                    if(accessor2 != null)
                    {
                        if(k7 > 0)
                        {
                            accessor2.columnIndex = j5;
                            accessor2.charLength = k7;
                        } else
                        {
                            accessor2.columnIndex = l4;
                            accessor2.byteLength = l6;
                        }
                        accessor2.lengthIndex = j6;
                        accessor2.indicatorIndex = k5;
                        accessor2.rowSpaceByte = bindBytes;
                        accessor2.rowSpaceChar = bindChars;
                        accessor2.rowSpaceIndicator = bindIndicators;
                        if(accessor2.defineType == 109 || accessor2.defineType == 111)
                            accessor2.setOffsets(bindBufferCapacity);
                    }
                    l4 += l6 * bindBufferCapacity;
                    j5 += k7 * bindBufferCapacity;
                    k5 += numberOfBindRowsAllocated;
                    j6 += numberOfBindRowsAllocated;
                    k3 += 10;
                }

            }
            l4 = bindByteSubRange;
            j5 = bindCharSubRange;
            k5 = indicatorsOffset;
            j6 = valueLengthsOffset;
            k3 = j3;
        }
        i7 = bindBufferCapacity - numberOfBoundRows;
        l7 = numberOfBoundRows - 1;
        k8 = l7 + i;
        abinder1 = binders[k8];
        if(parameterOtype != null)
        {
            System.arraycopy(parameterDatum[k8], 0, lastBoundTypeBytes, 0, numberOfBindPositions);
            System.arraycopy(parameterOtype[k8], 0, lastBoundTypeOtypes, 0, numberOfBindPositions);
        }
        if(hasIbtBind)
            processPlsqlIndexTabBinds(i);
        if(numReturnParams > 0 && (returnParamAccessors == null || returnParamAccessors.length < numReturnParams))
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(returnParamAccessors != null)
            processDmlReturningBind();
        flag1 = !sqlKind.isPlsqlOrCall() || currentRowBindAccessors == null;
        for(int i2 = 0; i2 < numberOfBindPositions; i2++)
        {
            short word3 = bindIndicators[k3 + 1];
            int l8 = currentBatchCharLens[i2];
            lastBinders[i2] = abinder1[i2];
            lastBoundByteLens[i2] = word3;
            for(int i9 = 0; i9 < numberOfBoundRows; i9++)
            {
                int j9 = i + i9;
                binders[j9][i2].bind(this, i2, i9, j9, bindBytes, bindChars, bindIndicators, word3, l8, l4, j5, j6 + i9, k5 + i9, flag1);
                binders[j9][i2] = null;
                if(userStream != null)
                    userStream[i9][i2] = null;
                l4 += word3;
                j5 += l8;
            }

            lastBoundByteOffsets[i2] = l4 - word3;
            lastBoundCharOffsets[i2] = j5 - l8;
            lastBoundInds[i2] = bindIndicators[k5 + l7];
            lastBoundLens[i2] = bindIndicators[j6 + l7];
            lastBoundCharLens[i2] = 0;
            l4 += i7 * word3;
            j5 += i7 * l8;
            k5 += numberOfBindRowsAllocated;
            j6 += numberOfBindRowsAllocated;
            k3 += 10;
        }

        lastBoundBytes = bindBytes;
        lastBoundByteOffset = bindByteOffset;
        lastBoundChars = bindChars;
        lastBoundCharOffset = bindCharOffset;
        if(parameterStream != null)
            lastBoundStream = parameterStream[(i + numberOfBoundRows) - 1];
        ai = currentBatchCharLens;
        currentBatchCharLens = lastBoundCharLens;
        lastBoundCharLens = ai;
        lastBoundNeeded = false;
        prepareBindPreambles(numberOfBoundRows, bindBufferCapacity);
    }

    void releaseBuffers()
    {
        cachedBindCharSize = bindChars == null ? 0 : bindChars.length;
        if(bindChars != lastBoundChars)
            connection.cacheBuffer(lastBoundChars);
        lastBoundChars = null;
        connection.cacheBuffer(bindChars);
        bindChars = null;
        cachedBindByteSize = bindBytes == null ? 0 : bindBytes.length;
        if(bindBytes != lastBoundBytes)
            connection.cacheBuffer(lastBoundBytes);
        lastBoundBytes = null;
        connection.cacheBuffer(bindBytes);
        bindBytes = null;
        super.releaseBuffers();
    }

    public void enterImplicitCache()
        throws SQLException
    {
        alwaysOnClose();
        if(!connection.isClosed())
            cleanAllTempLobs();
        if(connection.clearStatementMetaData)
        {
            lastBoundBytes = null;
            lastBoundChars = null;
        }
        clearParameters();
        cacheState = 2;
        creationState = 1;
        currentResultSet = null;
        lastIndex = 0;
        queryTimeout = 0;
        autoRollback = 2;
        rowPrefetchChanged = false;
        currentRank = 0;
        currentRow = -1;
        validRows = 0;
        maxRows = 0;
        totalRowsVisited = 0;
        maxFieldSize = 0;
        gotLastBatch = false;
        clearParameters = true;
        scrollRset = null;
        defaultFetchDirection = 1000;
        defaultTimeZone = null;
        defaultCalendar = null;
        checkSum = 0L;
        checkSumComputationFailure = false;
        if(sqlKind.isOTHER())
        {
            needToParse = true;
            needToPrepareDefineBuffer = true;
            columnsDefinedByUser = false;
        }
        releaseBuffers();
        definedColumnType = null;
        definedColumnSize = null;
        definedColumnFormOfUse = null;
        if(accessors != null)
        {
            int i = accessors.length;
            for(int j = 0; j < i; j++)
            {
                if(accessors[j] == null)
                    continue;
                accessors[j].rowSpaceByte = null;
                accessors[j].rowSpaceChar = null;
                accessors[j].rowSpaceIndicator = null;
                if(columnsDefinedByUser)
                    accessors[j].externalType = 0;
            }

        }
        fixedString = connection.getDefaultFixedString();
        defaultRowPrefetch = rowPrefetch;
        rowPrefetchInLastFetch = -1;
        if(connection.clearStatementMetaData)
        {
            sqlStringChanged = true;
            needToParse = true;
            needToPrepareDefineBuffer = true;
            columnsDefinedByUser = false;
            if(userRsetType == 0)
            {
                userRsetType = 1;
                realRsetType = 1;
            }
            currentRowNeedToPrepareBinds = true;
        }
    }

    public void enterExplicitCache()
        throws SQLException
    {
        cacheState = 2;
        creationState = 2;
        defaultTimeZone = null;
        alwaysOnClose();
    }

    public void exitImplicitCacheToActive()
        throws SQLException
    {
        cacheState = 1;
        closed = false;
        if(rowPrefetch != connection.getDefaultRowPrefetch() && streamList == null)
        {
            rowPrefetch = connection.getDefaultRowPrefetch();
            defaultRowPrefetch = rowPrefetch;
            rowPrefetchChanged = true;
        }
        if(batch != connection.getDefaultExecuteBatch())
            resetBatch();
        processEscapes = connection.processEscapes;
        if(cachedDefineIndicatorSize != 0)
        {
            defineBytes = connection.getByteBuffer(cachedDefineByteSize);
            defineChars = connection.getCharBuffer(cachedDefineCharSize);
            defineIndicators = new short[cachedDefineIndicatorSize];
            if(accessors != null)
            {
                int i = accessors.length;
                for(int j = 0; j < i; j++)
                    if(accessors[j] != null)
                    {
                        accessors[j].rowSpaceByte = defineBytes;
                        accessors[j].rowSpaceChar = defineChars;
                        accessors[j].rowSpaceIndicator = defineIndicators;
                    }

                doInitializationAfterDefineBufferRestore();
            }
        }
        if(cachedBindCharSize != 0 || cachedBindByteSize != 0)
        {
            if(cachedBindByteSize > 0)
                bindBytes = connection.getByteBuffer(cachedBindByteSize);
            if(cachedBindCharSize > 0)
                bindChars = connection.getCharBuffer(cachedBindCharSize);
            doLocalInitialization();
        }
    }

    void doLocalInitialization()
    {
    }

    void doInitializationAfterDefineBufferRestore()
    {
    }

    public void exitExplicitCacheToActive()
        throws SQLException
    {
        cacheState = 1;
        closed = false;
    }

    public void exitImplicitCacheToClose()
        throws SQLException
    {
        cacheState = 0;
        closed = false;
        synchronized(connection)
        {
            hardClose();
        }
    }

    public void exitExplicitCacheToClose()
        throws SQLException
    {
        cacheState = 0;
        closed = false;
        synchronized(connection)
        {
            hardClose();
        }
    }

    public void closeWithKey(String s)
        throws SQLException
    {
        synchronized(connection)
        {
            closeOrCache(s);
        }
    }

    int executeInternal()
        throws SQLException
    {
        noMoreUpdateCounts = false;
        checkSum = 0L;
        checkSumComputationFailure = false;
        ensureOpen();
        if(currentRank > 0 && m_batchStyle == 2)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        boolean flag = userRsetType == 1;
        prepareForNewResults(true, false);
        processCompletedBindRow(sqlKind.isSELECT() ? 1 : batch, false);
        if(!flag && !scrollRsetTypeSolved)
            return doScrollPstmtExecuteUpdate() + prematureBatchCount;
        doExecuteWithTimeout();
        boolean flag1 = prematureBatchCount != 0 && validRows > 0;
        if(!flag)
        {
            currentResultSet = new OracleResultSetImpl(connection, this);
            scrollRset = ResultSetUtil.createScrollResultSet(this, currentResultSet, realRsetType);
            if(!connection.accumulateBatchResult)
                flag1 = false;
        }
        if(flag1)
        {
            validRows += prematureBatchCount;
            prematureBatchCount = 0;
        }
        if(sqlKind.isOTHER())
            needToParse = true;
        return validRows;
    }

    public ResultSet executeQuery()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        executionType = 1;
        executeInternal();
        if(userRsetType == 1)
        {
            currentResultSet = new OracleResultSetImpl(connection, this);
            return currentResultSet;
        }
        if(scrollRset == null)
        {
            currentResultSet = new OracleResultSetImpl(connection, this);
            scrollRset = currentResultSet;
        }
        scrollRset;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public int executeUpdate()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        executionType = 2;
        return executeInternal();
        Exception exception;
        exception;
        throw exception;
    }

    public boolean execute()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        executionType = 3;
        executeInternal();
        return sqlKind.isSELECT();
        Exception exception;
        exception;
        throw exception;
    }

    void slideDownCurrentRow(int i)
    {
        if(binders != null)
        {
            binders[i] = binders[0];
            binders[0] = currentRowBinders;
        }
        if(parameterInt != null)
        {
            int ai[] = parameterInt[0];
            parameterInt[0] = parameterInt[i];
            parameterInt[i] = ai;
        }
        if(parameterLong != null)
        {
            long al[] = parameterLong[0];
            parameterLong[0] = parameterLong[i];
            parameterLong[i] = al;
        }
        if(parameterFloat != null)
        {
            float af[] = parameterFloat[0];
            parameterFloat[0] = parameterFloat[i];
            parameterFloat[i] = af;
        }
        if(parameterDouble != null)
        {
            double ad[] = parameterDouble[0];
            parameterDouble[0] = parameterDouble[i];
            parameterDouble[i] = ad;
        }
        if(parameterBigDecimal != null)
        {
            BigDecimal abigdecimal[] = parameterBigDecimal[0];
            parameterBigDecimal[0] = parameterBigDecimal[i];
            parameterBigDecimal[i] = abigdecimal;
        }
        if(parameterString != null)
        {
            String as[] = parameterString[0];
            parameterString[0] = parameterString[i];
            parameterString[i] = as;
        }
        if(parameterDate != null)
        {
            Date adate[] = parameterDate[0];
            parameterDate[0] = parameterDate[i];
            parameterDate[i] = adate;
        }
        if(parameterTime != null)
        {
            Time atime[] = parameterTime[0];
            parameterTime[0] = parameterTime[i];
            parameterTime[i] = atime;
        }
        if(parameterTimestamp != null)
        {
            Timestamp atimestamp[] = parameterTimestamp[0];
            parameterTimestamp[0] = parameterTimestamp[i];
            parameterTimestamp[i] = atimestamp;
        }
        if(parameterDatum != null)
        {
            byte abyte0[][] = parameterDatum[0];
            parameterDatum[0] = parameterDatum[i];
            parameterDatum[i] = abyte0;
        }
        if(parameterOtype != null)
        {
            OracleTypeADT aoracletypeadt[] = parameterOtype[0];
            parameterOtype[0] = parameterOtype[i];
            parameterOtype[i] = aoracletypeadt;
        }
        if(parameterStream != null)
        {
            InputStream ainputstream[] = parameterStream[0];
            parameterStream[0] = parameterStream[i];
            parameterStream[i] = ainputstream;
        }
        if(userStream != null)
        {
            Object aobj[] = userStream[0];
            userStream[0] = userStream[i];
            userStream[i] = aobj;
        }
    }

    void resetBatch()
    {
        batch = connection.getDefaultExecuteBatch();
    }

    public int sendBatch()
        throws SQLException
    {
        if(isJdbcBatchStyle())
            return 0;
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(!connection.isUsable() || bsendBatchInProgress)
        {
            clearBatch();
            bsendBatchInProgress = false;
            return 0;
        }
        int i;
        ensureOpen();
        if(currentRank > 0)
            break MISSING_BLOCK_LABEL_90;
        i = connection.accumulateBatchResult ? 0 : validRows;
        currentRank = 0;
        bsendBatchInProgress = false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return i;
        i = batch;
        bsendBatchInProgress = true;
        int j = currentRank;
        if(batch != currentRank)
            batch = currentRank;
        setupBindBuffers(0, currentRank);
        currentRank--;
        doExecuteWithTimeout();
        slideDownCurrentRow(j);
        if(batch != i)
            batch = i;
        break MISSING_BLOCK_LABEL_186;
        Exception exception;
        exception;
        if(batch != i)
            batch = i;
        throw exception;
        int k;
        if(connection.accumulateBatchResult)
        {
            validRows += prematureBatchCount;
            prematureBatchCount = 0;
        }
        k = validRows;
        currentRank = 0;
        bsendBatchInProgress = false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return k;
        Exception exception1;
        exception1;
        currentRank = 0;
        bsendBatchInProgress = false;
        throw exception1;
        Exception exception2;
        exception2;
        throw exception2;
    }

    public void setExecuteBatch(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            setOracleBatchStyle();
            set_execute_batch(i);
        }
    }

    void set_execute_batch(int i)
        throws SQLException
    {
label0:
        {
            synchronized(connection)
            {
                if(i <= 0)
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                if(i != batch)
                    break label0;
            }
            return;
        }
        if(currentRank > 0)
        {
            int j = validRows;
            prematureBatchCount = sendBatch();
            validRows = j;
        }
        int k = batch;
        batch = i;
        if(numberOfBindRowsAllocated < batch)
            growBinds(batch);
        physicalconnection;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
    }

    public final int getExecuteBatch()
    {
        return batch;
    }

    public void defineParameterTypeBytes(int i, int j, int k)
        throws SQLException
    {
        synchronized(connection)
        {
            if(k < 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(i < 1)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            switch(j)
            {
            case -7: 
            case -6: 
            case -5: 
            case 2: // '\002'
            case 3: // '\003'
            case 4: // '\004'
            case 5: // '\005'
            case 6: // '\006'
            case 7: // '\007'
            case 8: // '\b'
                j = 6;
                break;

            case 1: // '\001'
                j = 96;
                break;

            case 12: // '\f'
                j = 1;
                break;

            case 91: // '['
            case 92: // '\\'
                j = 12;
                break;

            case -103: 
                j = 182;
                break;

            case -104: 
                j = 183;
                break;

            case -100: 
            case 93: // ']'
                j = 180;
                break;

            case -101: 
                j = 181;
                break;

            case -102: 
                j = 231;
                break;

            case -3: 
            case -2: 
                j = 23;
                break;

            case 100: // 'd'
                j = 100;
                break;

            case 101: // 'e'
                j = 101;
                break;

            case -8: 
                j = 104;
                break;

            case 2004: 
                j = 113;
                break;

            case 2005: 
                j = 112;
                break;

            case -13: 
                j = 114;
                break;

            case -10: 
                j = 102;
                break;

            case 0: // '\0'
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;

            default:
                SQLException sqlexception3 = DatabaseError.createUnsupportedFeatureSqlException();
                sqlexception3.fillInStackTrace();
                throw sqlexception3;
            }
        }
    }

    public void defineParameterTypeChars(int i, int j, int k)
        throws SQLException
    {
        synchronized(connection)
        {
            int l = connection.getNlsRatio();
            if(j == 1 || j == 12)
                defineParameterTypeBytes(i, j, k * l);
            else
                defineParameterTypeBytes(i, j, k);
        }
    }

    public void defineParameterType(int i, int j, int k)
        throws SQLException
    {
        synchronized(connection)
        {
            defineParameterTypeBytes(i, j, k);
        }
    }

    public ResultSetMetaData getMetaData()
        throws SQLException
    {
        if(sqlObject.getSqlKind().isSELECT())
            return new OracleResultSetMetaData(connection, this);
        else
            return null;
    }

    public void setNull(int i, int j, String s)
        throws SQLException
    {
        setNullInternal(i, j, s);
    }

    void setNullInternal(int i, int j, String s)
        throws SQLException
    {
        int k = i - 1;
        if(k < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(j == 2002 || j == 2008 || j == 2003 || j == 2007 || j == 2009 || j == 2006)
        {
            synchronized(connection)
            {
                setNullCritical(k, j, s);
                currentRowCharLens[k] = 0;
            }
        } else
        {
            setNullInternal(i, j);
            return;
        }
    }

    void setNullInternal(int i, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            setNullCritical(i, j);
        }
    }

    void setNullCritical(int i, int j, String s)
        throws SQLException
    {
        Object obj = null;
        Binder binder = theNamedTypeNullBinder;
        switch(j)
        {
        case 2006: 
            binder = theRefTypeNullBinder;
            // fall through

        case 2002: 
        case 2008: 
            StructDescriptor structdescriptor = StructDescriptor.createDescriptor(s, connection);
            obj = structdescriptor.getOracleTypeADT();
            break;

        case 2003: 
            ArrayDescriptor arraydescriptor = ArrayDescriptor.createDescriptor(s, connection);
            obj = arraydescriptor.getOracleTypeCOLLECTION();
            break;

        case 2007: 
        case 2009: 
            OpaqueDescriptor opaquedescriptor = OpaqueDescriptor.createDescriptor(s, connection);
            obj = (OracleTypeADT)opaquedescriptor.getPickler();
            break;
        }
        currentRowBinders[i] = binder;
        if(parameterDatum == null)
            parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
        parameterDatum[currentRank][i] = null;
        if(obj != null)
            ((OracleTypeADT) (obj)).getTOID();
        if(parameterOtype == null)
            parameterOtype = new OracleTypeADT[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterOtype[currentRank][i] = ((OracleTypeADT) (obj));
    }

    public void setNullAtName(String s, int i, String s1)
        throws SQLException
    {
        String s2 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int j = Math.min(sqlObject.getParameterCount(), as.length);
        for(int k = 0; k < j; k++)
            if(as[k] == s2)
            {
                setNullInternal(k + 1, i, s1);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setNull(int i, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            setNullCritical(i, j);
        }
    }

    void setNullCritical(int i, int j)
        throws SQLException
    {
        int k = i - 1;
        if(k < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        Binder binder = null;
        int l = getInternalType(j);
        switch(l)
        {
        case 6: // '\006'
            binder = theVarnumNullBinder;
            break;

        case 1: // '\001'
        case 8: // '\b'
        case 96: // '`'
        case 995: 
            binder = theVarcharNullBinder;
            currentRowCharLens[k] = 1;
            break;

        case 999: 
            binder = theFixedCHARNullBinder;
            break;

        case 12: // '\f'
            binder = theDateNullBinder;
            break;

        case 180: 
            binder = theTimestampNullBinder;
            break;

        case 181: 
            binder = theTSTZNullBinder;
            break;

        case 231: 
            binder = theTSLTZNullBinder;
            break;

        case 104: // 'h'
            binder = getRowidNullBinder(k);
            break;

        case 183: 
            binder = theIntervalDSNullBinder;
            break;

        case 182: 
            binder = theIntervalYMNullBinder;
            break;

        case 23: // '\027'
        case 24: // '\030'
            binder = theRawNullBinder;
            break;

        case 100: // 'd'
            binder = theBinaryFloatNullBinder;
            break;

        case 101: // 'e'
            binder = theBinaryDoubleNullBinder;
            break;

        case 113: // 'q'
            binder = theBlobNullBinder;
            break;

        case 112: // 'p'
            binder = theClobNullBinder;
            break;

        case 114: // 'r'
            binder = theBfileNullBinder;
            break;

        case 109: // 'm'
        case 111: // 'o'
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, (new StringBuilder()).append("sqlType=").append(j).toString());
            sqlexception1.fillInStackTrace();
            throw sqlexception1;

        case 102: // 'f'
        case 998: 
        default:
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, (new StringBuilder()).append("sqlType=").append(j).toString());
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        currentRowBinders[k] = binder;
    }

    Binder getRowidNullBinder(int i)
    {
        return theRowidNullBinder;
    }

    public void setNullAtName(String s, int i)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int j = Math.min(sqlObject.getParameterCount(), as.length);
        for(int k = 0; k < j; k++)
            if(as[k] == s1)
            {
                setNull(k + 1, i);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBoolean(int i, boolean flag)
        throws SQLException
    {
        synchronized(connection)
        {
            setBooleanInternal(i, flag);
        }
    }

    void setBooleanInternal(int i, boolean flag)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowCharLens[j] = 0;
        currentRowBinders[j] = theBooleanBinder;
        if(parameterInt == null)
            parameterInt = new int[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterInt[currentRank][j] = flag ? 1 : 0;
    }

    public void setByte(int i, byte byte0)
        throws SQLException
    {
        synchronized(connection)
        {
            setByteInternal(i, byte0);
        }
    }

    void setByteInternal(int i, byte byte0)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowCharLens[j] = 0;
        currentRowBinders[j] = theByteBinder;
        if(parameterInt == null)
            parameterInt = new int[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterInt[currentRank][j] = byte0;
    }

    public void setShort(int i, short word0)
        throws SQLException
    {
        synchronized(connection)
        {
            setShortInternal(i, word0);
        }
    }

    void setShortInternal(int i, short word0)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowCharLens[j] = 0;
        currentRowBinders[j] = theShortBinder;
        if(parameterInt == null)
            parameterInt = new int[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterInt[currentRank][j] = word0;
    }

    public void setInt(int i, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            setIntInternal(i, j);
        }
    }

    void setIntInternal(int i, int j)
        throws SQLException
    {
        int k = i - 1;
        if(k < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowCharLens[k] = 0;
        currentRowBinders[k] = theIntBinder;
        if(parameterInt == null)
            parameterInt = new int[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterInt[currentRank][k] = j;
    }

    public void setLong(int i, long l)
        throws SQLException
    {
        synchronized(connection)
        {
            setLongInternal(i, l);
        }
    }

    void setLongInternal(int i, long l)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowCharLens[j] = 0;
        currentRowBinders[j] = theLongBinder;
        if(parameterLong == null)
            parameterLong = new long[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterLong[currentRank][j] = l;
    }

    public void setFloat(int i, float f)
        throws SQLException
    {
        synchronized(connection)
        {
            setFloatInternal(i, f);
        }
    }

    void setFloatInternal(int i, float f)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(!connection.setFloatAndDoubleUseBinary && Float.isNaN(f))
            throw new IllegalArgumentException("NaN");
        if(theFloatBinder == null)
        {
            theFloatBinder = theStaticFloatBinder;
            if(connection.setFloatAndDoubleUseBinary)
                theFloatBinder = theStaticBinaryFloatBinder;
        }
        currentRowCharLens[j] = 0;
        currentRowBinders[j] = theFloatBinder;
        if(theFloatBinder == theStaticFloatBinder)
        {
            if(parameterDouble == null)
                parameterDouble = new double[numberOfBindRowsAllocated][numberOfBindPositions];
            parameterDouble[currentRank][j] = f;
        } else
        {
            if(parameterFloat == null)
                parameterFloat = new float[numberOfBindRowsAllocated][numberOfBindPositions];
            parameterFloat[currentRank][j] = f;
        }
    }

    public void setBinaryFloat(int i, float f)
        throws SQLException
    {
        synchronized(connection)
        {
            setBinaryFloatInternal(i, f);
        }
    }

    void setBinaryFloatInternal(int i, float f)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowCharLens[j] = 0;
        currentRowBinders[j] = theBinaryFloatBinder;
        if(parameterFloat == null)
            parameterFloat = new float[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterFloat[currentRank][j] = f;
    }

    public void setBinaryFloat(int i, BINARY_FLOAT binary_float)
        throws SQLException
    {
        synchronized(connection)
        {
            setBinaryFloatInternal(i, binary_float);
        }
    }

    void setBinaryFloatInternal(int i, BINARY_FLOAT binary_float)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(binary_float == null)
        {
            currentRowBinders[j] = theBINARY_FLOATNullBinder;
        } else
        {
            currentRowBinders[j] = theBINARY_FLOATBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = binary_float.getBytes();
        }
        currentRowCharLens[j] = 0;
    }

    public void setBinaryDouble(int i, double d)
        throws SQLException
    {
        synchronized(connection)
        {
            setBinaryDoubleInternal(i, d);
        }
    }

    void setBinaryDoubleInternal(int i, double d)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowBinders[j] = theBinaryDoubleBinder;
        if(parameterDouble == null)
            parameterDouble = new double[numberOfBindRowsAllocated][numberOfBindPositions];
        currentRowCharLens[j] = 0;
        parameterDouble[currentRank][j] = d;
    }

    public void setBinaryDouble(int i, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        synchronized(connection)
        {
            setBinaryDoubleInternal(i, binary_double);
        }
    }

    void setBinaryDoubleInternal(int i, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(binary_double == null)
        {
            currentRowBinders[j] = theBINARY_DOUBLENullBinder;
        } else
        {
            currentRowBinders[j] = theBINARY_DOUBLEBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = binary_double.getBytes();
        }
        currentRowCharLens[j] = 0;
    }

    public void setDouble(int i, double d)
        throws SQLException
    {
        synchronized(connection)
        {
            setDoubleInternal(i, d);
        }
    }

    void setDoubleInternal(int i, double d)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(!connection.setFloatAndDoubleUseBinary)
        {
            if(Double.isNaN(d))
                throw new IllegalArgumentException("NaN");
            double d1 = Math.abs(d);
            if(d1 != 0.0D && d1 < 1.0000000000000001E-130D)
                throw new IllegalArgumentException("Underflow");
            if(d1 >= 9.9999999999999992E+125D)
                throw new IllegalArgumentException("Overflow");
        }
        if(theDoubleBinder == null)
        {
            theDoubleBinder = theStaticDoubleBinder;
            if(connection.setFloatAndDoubleUseBinary)
                theDoubleBinder = theStaticBinaryDoubleBinder;
        }
        currentRowCharLens[j] = 0;
        currentRowBinders[j] = theDoubleBinder;
        if(parameterDouble == null)
            parameterDouble = new double[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterDouble[currentRank][j] = d;
    }

    public void setBigDecimal(int i, BigDecimal bigdecimal)
        throws SQLException
    {
        synchronized(connection)
        {
            setBigDecimalInternal(i, bigdecimal);
        }
    }

    void setBigDecimalInternal(int i, BigDecimal bigdecimal)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(bigdecimal == null)
        {
            currentRowBinders[j] = theVarnumNullBinder;
        } else
        {
            currentRowBinders[j] = theBigDecimalBinder;
            if(parameterBigDecimal == null)
                parameterBigDecimal = new BigDecimal[numberOfBindRowsAllocated][numberOfBindPositions];
            parameterBigDecimal[currentRank][j] = bigdecimal;
        }
        currentRowCharLens[j] = 0;
    }

    public void setString(int i, String s)
        throws SQLException
    {
        setStringInternal(i, s);
    }

    void setStringInternal(int i, String s)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        int k = s == null ? 0 : s.length();
        if(k == 0)
            setNull(i, 12);
        else
        if(currentRowFormOfUse[i - 1] == 1)
        {
            if(sqlKind.isPlsqlOrCall())
            {
                if(k > maxVcsBytesPlsql || k > maxVcsCharsPlsql && isServerCharSetFixedWidth)
                    setStringForClobCritical(i, s);
                else
                if(k > maxVcsCharsPlsql)
                {
                    int l = connection.conversion.encodedByteLength(s, false);
                    if(l > maxVcsBytesPlsql)
                        setStringForClobCritical(i, s);
                    else
                        basicBindString(i, s);
                } else
                {
                    basicBindString(i, s);
                }
            } else
            if(k <= maxVcsCharsSql)
                basicBindString(i, s);
            else
            if(k <= maxStreamCharsSql)
                basicBindCharacterStream(i, new StringReader(s), k, true);
            else
                setStringForClobCritical(i, s);
        } else
        if(sqlKind.isPlsqlOrCall())
        {
            if(k > maxVcsBytesPlsql || k > maxVcsNCharsPlsql && isServerNCharSetFixedWidth)
                setStringForClobCritical(i, s);
            else
            if(k > maxVcsNCharsPlsql)
            {
                int i1 = connection.conversion.encodedByteLength(s, true);
                if(i1 > maxVcsBytesPlsql)
                    setStringForClobCritical(i, s);
                else
                    basicBindString(i, s);
            } else
            {
                basicBindString(i, s);
            }
        } else
        if(k <= maxVcsCharsSql)
            basicBindString(i, s);
        else
            setStringForClobCritical(i, s);
    }

    void basicBindNullString(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            int j = i - 1;
            currentRowBinders[j] = theVarcharNullBinder;
            if(sqlKind.isPlsqlOrCall())
                currentRowCharLens[j] = minVcsBindSize;
            else
                currentRowCharLens[j] = 1;
        }
    }

    void basicBindString(int i, String s)
        throws SQLException
    {
        synchronized(connection)
        {
            int j = i - 1;
            currentRowBinders[j] = theStringBinder;
            int k = s.length();
            if(sqlKind.isPlsqlOrCall())
            {
                int l = connection.minVcsBindSize;
                int i1 = k + 1;
                currentRowCharLens[j] = i1 >= l ? i1 : l;
            } else
            {
                currentRowCharLens[j] = k + 1;
            }
            if(parameterString == null)
                parameterString = new String[numberOfBindRowsAllocated][numberOfBindPositions];
            parameterString[currentRank][j] = s;
        }
    }

    public void setStringForClob(int i, String s)
        throws SQLException
    {
        if(s == null)
        {
            setNull(i, 1);
            return;
        }
        int j = s.length();
        if(j == 0)
        {
            setNull(i, 1);
            return;
        }
        if(sqlKind.isPlsqlOrCall())
        {
            if(j <= maxVcsCharsPlsql)
                setStringInternal(i, s);
            else
                setStringForClobCritical(i, s);
        } else
        if(j <= maxVcsCharsSql)
            setStringInternal(i, s);
        else
            setStringForClobCritical(i, s);
    }

    void setStringForClobCritical(int i, String s)
        throws SQLException
    {
        synchronized(connection)
        {
            CLOB clob = CLOB.createTemporary(connection, true, 10, currentRowFormOfUse[i - 1]);
            clob.setString(1L, s);
            addToTempLobsToFree(clob);
            lastBoundClobs[i - 1] = clob;
            setCLOBInternal(i, clob);
        }
    }

    void setReaderContentsForClobCritical(int i, Reader reader, long l, boolean flag)
        throws SQLException
    {
        physicalconnection = connection;
        JVM INSTR monitorenter ;
        synchronized(connection)
        {
            if((reader = isReaderEmpty(reader)) != null)
                break MISSING_BLOCK_LABEL_86;
            if(flag)
                throw new IOException((new StringBuilder()).append(l).append(" char of CLOB data cannot be read").toString());
            setCLOBInternal(i, null);
        }
        return;
        IOException ioexception;
        ioexception;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
        sqlexception.fillInStackTrace();
        throw sqlexception;
        CLOB clob = CLOB.createTemporary(connection, true, 10, currentRowFormOfUse[i - 1]);
        OracleClobWriter oracleclobwriter = (OracleClobWriter)(OracleClobWriter)clob.setCharacterStream(1L);
        int j = clob.getBufferSize();
        char ac[] = new char[j];
        long l1 = 0L;
        boolean flag1 = false;
        l1 = flag ? l : 0x7fffffffffffffffL;
        try
        {
            do
            {
                if(l1 <= 0L)
                    break;
                int k;
                if(l1 >= (long)j)
                    k = reader.read(ac);
                else
                    k = reader.read(ac, 0, (int)l1);
                if(k == -1)
                {
                    if(flag)
                        throw new IOException((new StringBuilder()).append(l1).append(" char of CLOB data cannot be read").toString());
                    break;
                }
                oracleclobwriter.write(ac, 0, k);
                l1 -= k;
            } while(true);
            oracleclobwriter.flush();
        }
        catch(IOException ioexception1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception1);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        addToTempLobsToFree(clob);
        lastBoundClobs[i - 1] = clob;
        setCLOBInternal(i, clob);
        physicalconnection;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
    }

    void setAsciiStreamContentsForClobCritical(int i, InputStream inputstream, long l, boolean flag)
        throws SQLException
    {
        physicalconnection = connection;
        JVM INSTR monitorenter ;
        synchronized(connection)
        {
            if((inputstream = isInputStreamEmpty(inputstream)) != null)
                break MISSING_BLOCK_LABEL_86;
            if(flag)
                throw new IOException((new StringBuilder()).append(l).append(" byte of CLOB data cannot be read").toString());
            setCLOBInternal(i, null);
        }
        return;
        IOException ioexception;
        ioexception;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
        sqlexception.fillInStackTrace();
        throw sqlexception;
        CLOB clob = CLOB.createTemporary(connection, true, 10, currentRowFormOfUse[i - 1]);
        OracleClobWriter oracleclobwriter = (OracleClobWriter)(OracleClobWriter)clob.setCharacterStream(1L);
        int j = clob.getBufferSize();
        byte abyte0[] = new byte[j];
        char ac[] = new char[j];
        boolean flag1 = false;
        long l1 = flag ? l : 0x7fffffffffffffffL;
        try
        {
            do
            {
                if(l1 <= 0L)
                    break;
                int k;
                if(l1 >= (long)j)
                    k = inputstream.read(abyte0);
                else
                    k = inputstream.read(abyte0, 0, (int)l1);
                if(k == -1)
                {
                    if(flag)
                        throw new IOException((new StringBuilder()).append(l1).append(" byte of CLOB data cannot be read").toString());
                    break;
                }
                connection.conversion;
                DBConversion.asciiBytesToJavaChars(abyte0, k, ac);
                oracleclobwriter.write(ac, 0, k);
                l1 -= k;
            } while(true);
            oracleclobwriter.flush();
        }
        catch(IOException ioexception1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception1);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        addToTempLobsToFree(clob);
        lastBoundClobs[i - 1] = clob;
        setCLOBInternal(i, clob);
        physicalconnection;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
    }

    public void setStringForClobAtName(String s, String s1)
        throws SQLException
    {
        String s2 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s2)
            {
                setStringForClob(j + 1, s1);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setFixedCHAR(int i, String s)
        throws SQLException
    {
        synchronized(connection)
        {
            setFixedCHARInternal(i, s);
        }
    }

    void setFixedCHARInternal(int i, String s)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        int k = 0;
        if(s != null)
            k = s.length();
        if(k > 32766)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 157);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(s == null)
        {
            currentRowBinders[j] = theFixedCHARNullBinder;
            currentRowCharLens[j] = 1;
        } else
        {
            currentRowBinders[j] = theFixedCHARBinder;
            currentRowCharLens[j] = k + 1;
            if(parameterString == null)
                parameterString = new String[numberOfBindRowsAllocated][numberOfBindPositions];
            parameterString[currentRank][j] = s;
        }
    }

    /**
     * @deprecated Method setCursor is deprecated
     */

    public void setCursor(int i, ResultSet resultset)
        throws SQLException
    {
        synchronized(connection)
        {
            setCursorInternal(i, resultset);
        }
    }

    void setCursorInternal(int i, ResultSet resultset)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setROWID(int i, ROWID rowid)
        throws SQLException
    {
        synchronized(connection)
        {
            setROWIDInternal(i, rowid);
        }
    }

    void setROWIDInternal(int i, ROWID rowid)
        throws SQLException
    {
        if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.CALL_BLOCK)
        {
            if(rowid == null)
                setNull(i, 12);
            else
                setStringInternal(i, rowid.stringValue());
            return;
        }
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowid == null || rowid.shareBytes() == null)
        {
            currentRowBinders[j] = theRowidNullBinder;
        } else
        {
            currentRowBinders[j] = T4CRowidAccessor.isUROWID(rowid.shareBytes(), 0) ? theURowidBinder : theRowidBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = rowid.getBytes();
        }
        currentRowCharLens[j] = 0;
    }

    public void setArray(int i, Array array)
        throws SQLException
    {
        setARRAYInternal(i, (ARRAY)array);
    }

    void setArrayInternal(int i, Array array)
        throws SQLException
    {
        setARRAYInternal(i, (ARRAY)array);
    }

    public void setARRAY(int i, ARRAY array)
        throws SQLException
    {
        setARRAYInternal(i, array);
    }

    void setARRAYInternal(int i, ARRAY array)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(array == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        synchronized(connection)
        {
            setArrayCritical(j, array);
            currentRowCharLens[j] = 0;
        }
    }

    void setArrayCritical(int i, ARRAY array)
        throws SQLException
    {
        ArrayDescriptor arraydescriptor = array.getDescriptor();
        if(arraydescriptor == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowBinders[i] = theNamedTypeBinder;
        if(parameterDatum == null)
            parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
        parameterDatum[currentRank][i] = array.toBytes();
        oracle.jdbc.oracore.OracleTypeCOLLECTION oracletypecollection = arraydescriptor.getOracleTypeCOLLECTION();
        oracletypecollection.getTOID();
        if(parameterOtype == null)
            parameterOtype = new OracleTypeADT[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterOtype[currentRank][i] = oracletypecollection;
    }

    public void setOPAQUE(int i, OPAQUE opaque)
        throws SQLException
    {
        setOPAQUEInternal(i, opaque);
    }

    void setOPAQUEInternal(int i, OPAQUE opaque)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(opaque == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        synchronized(connection)
        {
            setOPAQUECritical(j, opaque);
            currentRowCharLens[j] = 0;
        }
    }

    void setOPAQUECritical(int i, OPAQUE opaque)
        throws SQLException
    {
        OpaqueDescriptor opaquedescriptor = opaque.getDescriptor();
        if(opaquedescriptor == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowBinders[i] = theNamedTypeBinder;
        if(parameterDatum == null)
            parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
        parameterDatum[currentRank][i] = opaque.toBytes();
        OracleTypeADT oracletypeadt = (OracleTypeADT)opaquedescriptor.getPickler();
        oracletypeadt.getTOID();
        if(parameterOtype == null)
            parameterOtype = new OracleTypeADT[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterOtype[currentRank][i] = oracletypeadt;
    }

    void setSQLXMLInternal(int i, SQLXML sqlxml)
        throws SQLException
    {
        if(sqlxml == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            setOPAQUEInternal(i, (OPAQUE)sqlxml);
            return;
        }
    }

    public void setStructDescriptor(int i, StructDescriptor structdescriptor)
        throws SQLException
    {
        setStructDescriptorInternal(i, structdescriptor);
    }

    void setStructDescriptorInternal(int i, StructDescriptor structdescriptor)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(structdescriptor == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        synchronized(connection)
        {
            setStructDescriptorCritical(j, structdescriptor);
            currentRowCharLens[j] = 0;
        }
    }

    void setStructDescriptorCritical(int i, StructDescriptor structdescriptor)
        throws SQLException
    {
        currentRowBinders[i] = theNamedTypeBinder;
        if(parameterDatum == null)
            parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
        OracleTypeADT oracletypeadt = structdescriptor.getOracleTypeADT();
        oracletypeadt.getTOID();
        if(parameterOtype == null)
            parameterOtype = new OracleTypeADT[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterOtype[currentRank][i] = oracletypeadt;
    }

    public void setStructDescriptorAtName(String s, StructDescriptor structdescriptor)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setStructDescriptorInternal(j + 1, structdescriptor);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    void setPreBindsCompelete()
        throws SQLException
    {
    }

    public void setSTRUCT(int i, STRUCT struct)
        throws SQLException
    {
        setSTRUCTInternal(i, struct);
    }

    void setSTRUCTInternal(int i, STRUCT struct)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(struct == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        synchronized(connection)
        {
            setSTRUCTCritical(j, struct);
            currentRowCharLens[j] = 0;
        }
    }

    void setSTRUCTCritical(int i, STRUCT struct)
        throws SQLException
    {
        StructDescriptor structdescriptor = struct.getDescriptor();
        if(structdescriptor == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowBinders[i] = theNamedTypeBinder;
        if(parameterDatum == null)
            parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
        parameterDatum[currentRank][i] = struct.toBytes();
        OracleTypeADT oracletypeadt = structdescriptor.getOracleTypeADT();
        oracletypeadt.getTOID();
        if(parameterOtype == null)
            parameterOtype = new OracleTypeADT[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterOtype[currentRank][i] = oracletypeadt;
    }

    public void setRAW(int i, RAW raw)
        throws SQLException
    {
        setRAWInternal(i, raw);
    }

    void setRAWInternal(int i, RAW raw)
        throws SQLException
    {
        boolean flag = false;
        synchronized(connection)
        {
            int j = i - 1;
            if(j < 0 || i > numberOfBindPositions)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            currentRowCharLens[j] = 0;
            if(raw == null)
                currentRowBinders[j] = theRawNullBinder;
            else
                flag = true;
        }
        if(flag)
            setBytesInternal(i, raw.getBytes());
    }

    public void setCHAR(int i, CHAR char1)
        throws SQLException
    {
        synchronized(connection)
        {
            setCHARInternal(i, char1);
        }
    }

    void setCHARInternal(int i, CHAR char1)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(char1 == null || char1.getLength() == 0L)
        {
            currentRowBinders[j] = theSetCHARNullBinder;
            currentRowCharLens[j] = 1;
        } else
        {
            short word0 = (short)char1.oracleId();
            currentRowBinders[j] = theSetCHARBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            CharacterSet characterset = currentRowFormOfUse[j] != 2 ? connection.setCHARCharSetObj : connection.setCHARNCharSetObj;
            byte abyte0[];
            if(characterset != null && characterset.getOracleId() != word0)
            {
                byte abyte1[] = char1.shareBytes();
                abyte0 = characterset.convert(char1.getCharacterSet(), abyte1, 0, abyte1.length);
            } else
            {
                abyte0 = char1.getBytes();
            }
            parameterDatum[currentRank][j] = abyte0;
            currentRowCharLens[j] = (abyte0.length + 1 >> 1) + 1;
        }
        if(sqlKind.isPlsqlOrCall() && currentRowCharLens[j] < minVcsBindSize)
            currentRowCharLens[j] = minVcsBindSize;
    }

    public void setDATE(int i, DATE date)
        throws SQLException
    {
        synchronized(connection)
        {
            setDATEInternal(i, date);
        }
    }

    void setDATEInternal(int i, DATE date)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowCharLens[j] = 0;
        if(date == null)
        {
            currentRowBinders[j] = theDateNullBinder;
        } else
        {
            currentRowBinders[j] = theOracleDateBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = date.getBytes();
        }
    }

    public void setNUMBER(int i, NUMBER number)
        throws SQLException
    {
        synchronized(connection)
        {
            setNUMBERInternal(i, number);
        }
    }

    void setNUMBERInternal(int i, NUMBER number)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowCharLens[j] = 0;
        if(number == null)
        {
            currentRowBinders[j] = theVarnumNullBinder;
        } else
        {
            currentRowBinders[j] = theOracleNumberBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = number.getBytes();
        }
    }

    public void setBLOB(int i, BLOB blob)
        throws SQLException
    {
        synchronized(connection)
        {
            setBLOBInternal(i, blob);
        }
    }

    void setBLOBInternal(int i, BLOB blob)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowCharLens[j] = 0;
        if(blob == null)
        {
            currentRowBinders[j] = theBlobNullBinder;
        } else
        {
            currentRowBinders[j] = theBlobBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = blob.getBytes();
        }
    }

    public void setBlob(int i, Blob blob)
        throws SQLException
    {
        synchronized(connection)
        {
            setBLOBInternal(i, (BLOB)blob);
        }
    }

    void setBlobInternal(int i, Blob blob)
        throws SQLException
    {
        setBLOBInternal(i, (BLOB)blob);
    }

    public void setCLOB(int i, CLOB clob)
        throws SQLException
    {
        synchronized(connection)
        {
            setCLOBInternal(i, clob);
        }
    }

    void setCLOBInternal(int i, CLOB clob)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowCharLens[j] = 0;
        if(clob == null)
        {
            currentRowBinders[j] = theClobNullBinder;
        } else
        {
            currentRowBinders[j] = theClobBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = clob.getBytes();
        }
    }

    public void setClob(int i, Clob clob)
        throws SQLException
    {
        synchronized(connection)
        {
            setCLOBInternal(i, (CLOB)clob);
        }
    }

    void setClobInternal(int i, Clob clob)
        throws SQLException
    {
        setCLOBInternal(i, (CLOB)clob);
    }

    public void setBFILE(int i, BFILE bfile)
        throws SQLException
    {
        synchronized(connection)
        {
            setBFILEInternal(i, bfile);
        }
    }

    void setBFILEInternal(int i, BFILE bfile)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowCharLens[j] = 0;
        if(bfile == null)
        {
            currentRowBinders[j] = theBfileNullBinder;
        } else
        {
            currentRowBinders[j] = theBfileBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = bfile.getBytes();
        }
    }

    public void setBfile(int i, BFILE bfile)
        throws SQLException
    {
        synchronized(connection)
        {
            setBFILEInternal(i, bfile);
        }
    }

    void setBfileInternal(int i, BFILE bfile)
        throws SQLException
    {
        setBFILEInternal(i, bfile);
    }

    public void setBytes(int i, byte abyte0[])
        throws SQLException
    {
        setBytesInternal(i, abyte0);
    }

    void setBytesInternal(int i, byte abyte0[])
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        int k = abyte0 == null ? 0 : abyte0.length;
        if(k == 0)
            setNullInternal(i, -2);
        else
        if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.PLSQL_BLOCK)
        {
            if(k > maxRawBytesPlsql)
                setBytesForBlobCritical(i, abyte0);
            else
                basicBindBytes(i, abyte0);
        } else
        if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.CALL_BLOCK)
        {
            if(k > maxRawBytesPlsql)
                setBytesForBlobCritical(i, abyte0);
            else
                basicBindBytes(i, abyte0);
        } else
        if(k > maxRawBytesSql)
            bindBytesAsStream(i, abyte0);
        else
            basicBindBytes(i, abyte0);
    }

    void bindBytesAsStream(int i, byte abyte0[])
        throws SQLException
    {
        int j = abyte0.length;
        byte abyte1[] = new byte[j];
        System.arraycopy(abyte0, 0, abyte1, 0, j);
        set_execute_batch(1);
        basicBindBinaryStream(i, new ByteArrayInputStream(abyte1), j, true);
    }

    void basicBindBytes(int i, byte abyte0[])
        throws SQLException
    {
        synchronized(connection)
        {
            int j = i - 1;
            Binder binder = sqlKind.isPlsqlOrCall() ? thePlsqlRawBinder : theRawBinder;
            currentRowBinders[j] = binder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = abyte0;
            currentRowCharLens[j] = 0;
        }
    }

    void basicBindBinaryStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        basicBindBinaryStream(i, inputstream, j, false);
    }

    void basicBindBinaryStream(int i, InputStream inputstream, int j, boolean flag)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        int k;
        k = i - 1;
        if(flag)
            currentRowBinders[k] = theLongRawStreamForBytesBinder;
        else
            currentRowBinders[k] = theLongRawStreamBinder;
        if(parameterStream == null)
            parameterStream = new InputStream[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterStream[currentRank];
        k;
        if(!flag) goto _L2; else goto _L1
_L1:
        connection;
        connection.conversion.ConvertStreamInternal(inputstream, 6, j);
          goto _L3
_L2:
        connection;
        connection.conversion.ConvertStream(inputstream, 6, j);
_L3:
        JVM INSTR aastore ;
        currentRowCharLens[k] = 0;
        break MISSING_BLOCK_LABEL_146;
        Exception exception;
        exception;
        throw exception;
    }

    public void setBytesForBlob(int i, byte abyte0[])
        throws SQLException
    {
        if(abyte0 == null)
        {
            setNull(i, -2);
            return;
        }
        int j = abyte0.length;
        if(j == 0)
        {
            setNull(i, -2);
            return;
        }
        if(sqlKind.isPlsqlOrCall())
        {
            if(j <= maxRawBytesPlsql)
                setBytes(i, abyte0);
            else
                setBytesForBlobCritical(i, abyte0);
        } else
        if(j <= maxRawBytesSql)
            setBytes(i, abyte0);
        else
            setBytesForBlobCritical(i, abyte0);
    }

    void setBytesForBlobCritical(int i, byte abyte0[])
        throws SQLException
    {
        BLOB blob = BLOB.createTemporary(connection, true, 10);
        blob.putBytes(1L, abyte0);
        addToTempLobsToFree(blob);
        lastBoundBlobs[i - 1] = blob;
        setBLOBInternal(i, blob);
    }

    void setBinaryStreamContentsForBlobCritical(int i, InputStream inputstream, long l, boolean flag)
        throws SQLException
    {
        physicalconnection = connection;
        JVM INSTR monitorenter ;
        synchronized(connection)
        {
            if((inputstream = isInputStreamEmpty(inputstream)) != null)
                break MISSING_BLOCK_LABEL_86;
            if(flag)
                throw new IOException((new StringBuilder()).append(l).append(" byte of BLOB data cannot be read").toString());
            setBLOBInternal(i, null);
        }
        return;
        IOException ioexception;
        ioexception;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
        sqlexception.fillInStackTrace();
        throw sqlexception;
        BLOB blob = BLOB.createTemporary(connection, true, 10);
        OracleBlobOutputStream oraclebloboutputstream = (OracleBlobOutputStream)(OracleBlobOutputStream)blob.setBinaryStream(1L);
        int j = blob.getBufferSize();
        byte abyte0[] = new byte[j];
        long l1 = 0L;
        boolean flag1 = false;
        l1 = flag ? l : 0x7fffffffffffffffL;
        try
        {
            do
            {
                if(l1 <= 0L)
                    break;
                int k;
                if(l1 >= (long)j)
                    k = inputstream.read(abyte0);
                else
                    k = inputstream.read(abyte0, 0, (int)l1);
                if(k == -1)
                {
                    if(flag)
                        throw new IOException((new StringBuilder()).append(l1).append(" byte of BLOB data cannot be read").toString());
                    break;
                }
                oraclebloboutputstream.write(abyte0, 0, k);
                l1 -= k;
            } while(true);
            oraclebloboutputstream.flush();
        }
        catch(IOException ioexception1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception1);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        addToTempLobsToFree(blob);
        lastBoundBlobs[i - 1] = blob;
        setBLOBInternal(i, blob);
        physicalconnection;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
    }

    public void setBytesForBlobAtName(String s, byte abyte0[])
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBytesForBlob(j + 1, abyte0);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setInternalBytes(int i, byte abyte0[], int j)
        throws SQLException
    {
        synchronized(connection)
        {
            setInternalBytesInternal(i, abyte0, j);
        }
    }

    void setInternalBytesInternal(int i, byte abyte0[], int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDate(int i, Date date)
        throws SQLException
    {
        synchronized(connection)
        {
            setDATEInternal(i, date != null ? new DATE(date, getDefaultCalendar()) : null);
        }
    }

    void setDateInternal(int i, Date date)
        throws SQLException
    {
        setDATEInternal(i, date != null ? new DATE(date, getDefaultCalendar()) : null);
    }

    public void setTime(int i, Time time)
        throws SQLException
    {
        synchronized(connection)
        {
            setTimeInternal(i, time);
        }
    }

    void setTimeInternal(int i, Time time)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(time == null)
        {
            currentRowBinders[j] = theDateNullBinder;
        } else
        {
            currentRowBinders[j] = theTimeBinder;
            if(parameterTime == null)
                parameterTime = new Time[numberOfBindRowsAllocated][numberOfBindPositions];
            parameterTime[currentRank][j] = time;
        }
        currentRowCharLens[j] = 0;
    }

    public void setTimestamp(int i, Timestamp timestamp)
        throws SQLException
    {
        synchronized(connection)
        {
            setTimestampInternal(i, timestamp);
        }
    }

    void setTimestampInternal(int i, Timestamp timestamp)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(timestamp == null)
        {
            currentRowBinders[j] = theTimestampNullBinder;
        } else
        {
            currentRowBinders[j] = theTimestampBinder;
            if(parameterTimestamp == null)
                parameterTimestamp = new Timestamp[numberOfBindRowsAllocated][numberOfBindPositions];
            parameterTimestamp[currentRank][j] = timestamp;
        }
        currentRowCharLens[j] = 0;
    }

    public void setINTERVALYM(int i, INTERVALYM intervalym)
        throws SQLException
    {
        synchronized(connection)
        {
            setINTERVALYMInternal(i, intervalym);
        }
    }

    void setINTERVALYMInternal(int i, INTERVALYM intervalym)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(intervalym == null)
        {
            currentRowBinders[j] = theIntervalYMNullBinder;
        } else
        {
            currentRowBinders[j] = theIntervalYMBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = intervalym.getBytes();
        }
        currentRowCharLens[j] = 0;
    }

    public void setINTERVALDS(int i, INTERVALDS intervalds)
        throws SQLException
    {
        synchronized(connection)
        {
            setINTERVALDSInternal(i, intervalds);
        }
    }

    void setINTERVALDSInternal(int i, INTERVALDS intervalds)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(intervalds == null)
        {
            currentRowBinders[j] = theIntervalDSNullBinder;
        } else
        {
            currentRowBinders[j] = theIntervalDSBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = intervalds.getBytes();
        }
        currentRowCharLens[j] = 0;
    }

    public void setTIMESTAMP(int i, TIMESTAMP timestamp)
        throws SQLException
    {
        synchronized(connection)
        {
            setTIMESTAMPInternal(i, timestamp);
        }
    }

    void setTIMESTAMPInternal(int i, TIMESTAMP timestamp)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(timestamp == null)
        {
            currentRowBinders[j] = theTimestampNullBinder;
        } else
        {
            currentRowBinders[j] = theOracleTimestampBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = timestamp.getBytes();
        }
        currentRowCharLens[j] = 0;
    }

    public void setTIMESTAMPTZ(int i, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        synchronized(connection)
        {
            setTIMESTAMPTZInternal(i, timestamptz);
        }
    }

    void setTIMESTAMPTZInternal(int i, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(timestamptz == null)
        {
            currentRowBinders[j] = theTSTZNullBinder;
        } else
        {
            currentRowBinders[j] = theTSTZBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = timestamptz.getBytes();
        }
        currentRowCharLens[j] = 0;
    }

    public void setTIMESTAMPLTZ(int i, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        synchronized(connection)
        {
            setTIMESTAMPLTZInternal(i, timestampltz);
        }
    }

    void setTIMESTAMPLTZInternal(int i, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        if(connection.getSessionTimeZone() == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 105);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(timestampltz == null)
        {
            currentRowBinders[j] = theTSLTZNullBinder;
        } else
        {
            currentRowBinders[j] = theTSLTZBinder;
            if(parameterDatum == null)
                parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
            parameterDatum[currentRank][j] = timestampltz.getBytes();
        }
        currentRowCharLens[j] = 0;
    }

    private Reader isReaderEmpty(Reader reader)
        throws IOException
    {
        if(!reader.markSupported())
            reader = new BufferedReader(reader, 5);
        reader.mark(100);
        int i;
        if((i = reader.read()) == -1)
        {
            return null;
        } else
        {
            reader.reset();
            return reader;
        }
    }

    private InputStream isInputStreamEmpty(InputStream inputstream)
        throws IOException
    {
        if(!inputstream.markSupported())
            inputstream = new BufferedInputStream(inputstream, 5);
        inputstream.mark(100);
        int i;
        if((i = inputstream.read()) == -1)
        {
            return null;
        } else
        {
            inputstream.reset();
            return inputstream;
        }
    }

    public void setAsciiStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            setAsciiStreamInternal(i, inputstream, j);
        }
    }

    void setAsciiStreamInternal(int i, InputStream inputstream, int j)
        throws SQLException
    {
        setAsciiStreamInternal(i, inputstream, j, true);
    }

    void setAsciiStreamInternal(int i, InputStream inputstream, long l, boolean flag)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        set_execute_batch(1);
        checkUserStreamForDuplicates(inputstream, j);
        if(inputstream == null)
        {
            basicBindNullString(i);
        } else
        {
            if(userRsetType != 1 && (l > (long)maxVcsCharsSql || !flag))
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            if(!flag)
                setAsciiStreamContentsForClobCritical(i, inputstream, l, flag);
            else
            if(currentRowFormOfUse[j] == 1)
            {
                if(sqlKind.isPlsqlOrCall())
                {
                    if(l <= (long)maxVcsCharsPlsql && !connection.retainV9BindBehavior)
                        setAsciiStreamContentsForStringInternal(i, inputstream, (int)l);
                    else
                        setAsciiStreamContentsForClobCritical(i, inputstream, l, flag);
                } else
                if(l <= (long)maxVcsCharsSql && !connection.retainV9BindBehavior)
                    setAsciiStreamContentsForStringInternal(i, inputstream, (int)l);
                else
                if(l > 0x7fffffffL)
                    setAsciiStreamContentsForClobCritical(i, inputstream, l, flag);
                else
                    basicBindAsciiStream(i, inputstream, (int)l);
            } else
            if(sqlKind.isPlsqlOrCall())
            {
                if(l <= (long)maxVcsNCharsPlsql && !connection.retainV9BindBehavior)
                    setAsciiStreamContentsForStringInternal(i, inputstream, (int)l);
                else
                    setAsciiStreamContentsForClobCritical(i, inputstream, l, flag);
            } else
            if(l <= (long)maxVcsNCharsSql && !connection.retainV9BindBehavior)
                setAsciiStreamContentsForStringInternal(i, inputstream, (int)l);
            else
                setAsciiStreamContentsForClobCritical(i, inputstream, l, flag);
        }
    }

    void basicBindAsciiStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            if(userRsetType != 1)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            int k = i - 1;
            currentRowBinders[k] = theLongStreamBinder;
            if(parameterStream == null)
                parameterStream = new InputStream[numberOfBindRowsAllocated][numberOfBindPositions];
            PhysicalConnection _tmp = connection;
            parameterStream[currentRank][k] = connection.conversion.ConvertStream(inputstream, 5, j);
            currentRowCharLens[k] = 0;
        }
    }

    void setAsciiStreamContentsForStringInternal(int i, InputStream inputstream, int j)
        throws SQLException
    {
        byte abyte0[] = new byte[j];
        int k = 0;
        int l = j;
        int i1;
        try
        {
            while(l > 0 && (i1 = inputstream.read(abyte0, k, l)) != -1) 
            {
                k += i1;
                l -= i1;
            }
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        char ac[] = new char[j];
        DBConversion _tmp = connection.conversion;
        DBConversion.asciiBytesToJavaChars(abyte0, k, ac);
        basicBindString(i, new String(ac));
    }

    public void setBinaryStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        setBinaryStreamInternal(i, inputstream, j);
    }

    void setBinaryStreamInternal(int i, InputStream inputstream, int j)
        throws SQLException
    {
        setBinaryStreamInternal(i, inputstream, j, true);
    }

    void checkUserStreamForDuplicates(Object obj, int i)
        throws SQLException
    {
        if(obj == null)
            return;
        if(userStream != null)
        {
            Object aobj[][] = userStream;
            int j = aobj.length;
            for(int k = 0; k < j; k++)
            {
                Object aobj1[] = aobj[k];
                Object aobj2[] = aobj1;
                int l = aobj2.length;
                for(int i1 = 0; i1 < l; i1++)
                {
                    Object obj1 = aobj2[i1];
                    if(obj1 == obj)
                    {
                        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 270, Integer.valueOf(i + 1));
                        sqlexception.fillInStackTrace();
                        throw sqlexception;
                    }
                }

            }

        } else
        {
            userStream = new Object[numberOfBindRowsAllocated][numberOfBindPositions];
        }
        userStream[currentRank][i] = obj;
    }

    void setBinaryStreamInternal(int i, InputStream inputstream, long l, boolean flag)
        throws SQLException
    {
        synchronized(connection)
        {
            int j = i - 1;
            if(j < 0 || i > numberOfBindPositions)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            set_execute_batch(1);
            checkUserStreamForDuplicates(inputstream, j);
            if(inputstream == null)
            {
                setRAWInternal(i, null);
            } else
            {
                if(userRsetType != 1 && (l > (long)maxRawBytesSql || !flag))
                {
                    SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
                    sqlexception1.fillInStackTrace();
                    throw sqlexception1;
                }
                if(!flag)
                    setBinaryStreamContentsForBlobCritical(i, inputstream, l, flag);
                else
                if(sqlKind.isPlsqlOrCall())
                {
                    if(l > (long)maxRawBytesPlsql)
                        setBinaryStreamContentsForBlobCritical(i, inputstream, l, flag);
                    else
                        setBinaryStreamContentsForByteArrayInternal(i, inputstream, (int)l);
                } else
                if(l > 0x7fffffffL)
                    setBinaryStreamContentsForBlobCritical(i, inputstream, l, flag);
                else
                if(l > (long)maxRawBytesSql)
                    basicBindBinaryStream(i, inputstream, (int)l);
                else
                    setBinaryStreamContentsForByteArrayInternal(i, inputstream, (int)l);
            }
        }
    }

    void setBinaryStreamContentsForByteArrayInternal(int i, InputStream inputstream, int j)
        throws SQLException
    {
        byte abyte0[] = new byte[j];
        int k = 0;
        int l = j;
        int i1;
        try
        {
            while(l > 0 && (i1 = inputstream.read(abyte0, k, l)) != -1) 
            {
                k += i1;
                l -= i1;
            }
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(k != j)
        {
            byte abyte1[] = new byte[k];
            System.arraycopy(abyte0, 0, abyte1, 0, k);
            abyte0 = abyte1;
        }
        setBytesInternal(i, abyte0);
    }

    /**
     * @deprecated Method setUnicodeStream is deprecated
     */

    public void setUnicodeStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        setUnicodeStreamInternal(i, inputstream, j);
    }

    void setUnicodeStreamInternal(int i, InputStream inputstream, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            int k = i - 1;
            if(k < 0 || i > numberOfBindPositions)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            set_execute_batch(1);
            checkUserStreamForDuplicates(inputstream, k);
            if(inputstream == null)
            {
                setStringInternal(i, null);
            } else
            {
                if(userRsetType != 1 && j > maxVcsCharsSql)
                {
                    SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
                    sqlexception1.fillInStackTrace();
                    throw sqlexception1;
                }
                if(sqlKind.isPlsqlOrCall() || j <= maxVcsCharsSql)
                {
                    byte abyte0[] = new byte[j];
                    int l = 0;
                    int i1 = j;
                    int j1;
                    try
                    {
                        while(i1 > 0 && (j1 = inputstream.read(abyte0, l, i1)) != -1) 
                        {
                            l += j1;
                            i1 -= j1;
                        }
                    }
                    catch(IOException ioexception)
                    {
                        SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                        sqlexception2.fillInStackTrace();
                        throw sqlexception2;
                    }
                    char ac[] = new char[l >> 1];
                    DBConversion _tmp = connection.conversion;
                    DBConversion.ucs2BytesToJavaChars(abyte0, l, ac);
                    setStringInternal(i, new String(ac));
                } else
                {
                    currentRowBinders[k] = theLongStreamBinder;
                    if(parameterStream == null)
                        parameterStream = new InputStream[numberOfBindRowsAllocated][numberOfBindPositions];
                    PhysicalConnection _tmp1 = connection;
                    parameterStream[currentRank][k] = connection.conversion.ConvertStream(inputstream, 4, j);
                    currentRowCharLens[k] = 0;
                }
            }
        }
    }

    /**
     * @deprecated Method setCustomDatum is deprecated
     */

    public void setCustomDatum(int i, CustomDatum customdatum)
        throws SQLException
    {
        synchronized(connection)
        {
            setObjectInternal(i, connection.toDatum(customdatum));
        }
    }

    void setCustomDatumInternal(int i, CustomDatum customdatum)
        throws SQLException
    {
        synchronized(connection)
        {
            Datum datum = connection.toDatum(customdatum);
            int j = sqlTypeForObject(datum);
            setObjectCritical(i, datum, j, 0);
        }
    }

    public void setORAData(int i, ORAData oradata)
        throws SQLException
    {
        setORADataInternal(i, oradata);
    }

    void setORADataInternal(int i, ORAData oradata)
        throws SQLException
    {
        synchronized(connection)
        {
            Datum datum = oradata.toDatum(connection);
            int j = sqlTypeForObject(datum);
            setObjectCritical(i, datum, j, 0);
            if(j == 2002 || j == 2008 || j == 2003)
                currentRowCharLens[i - 1] = 0;
        }
    }

    void setOracleDataInternal(int i, OracleData oracledata)
        throws SQLException
    {
        synchronized(connection)
        {
            Object obj = oracledata.toJDBCObject(connection);
            if(obj instanceof OracleProxy)
            {
                final OracleProxy proxiedJDBCObject = (OracleProxy)obj;
                obj = AccessController.doPrivileged(new PrivilegedAction() {

                    final OracleProxy val$proxiedJDBCObject;
                    final OraclePreparedStatement this$0;

                    public Object run()
                    {
                        return ProxyFactory.extractDelegate(proxiedJDBCObject);
                    }

            
            {
                this$0 = OraclePreparedStatement.this;
                proxiedJDBCObject = oracleproxy;
                super();
            }
                }
);
            }
            int j = sqlTypeForObject(obj);
            setObjectCritical(i, obj, j, 0);
            if(j == 2002 || j == 2008 || j == 2003)
                currentRowCharLens[i - 1] = 0;
        }
    }

    public void setObject(int i, Object obj, int j, int k)
        throws SQLException
    {
        synchronized(connection)
        {
            setObjectInternal(i, obj, j, k);
        }
    }

    void setObjectInternal(int i, Object obj, int j, int k)
        throws SQLException
    {
        if(obj == null && j != 2002 && j != 2008 && j != 2003 && j != 2007 && j != 2006 && j != 2009)
            setNullInternal(i, j);
        else
        if(j == 2002 || j == 2008 || j == 2003 || j == 2009)
        {
            setObjectCritical(i, obj, j, k);
            currentRowCharLens[i - 1] = 0;
        } else
        {
            setObjectCritical(i, obj, j, k);
        }
    }

    void setObjectCritical(int i, Object obj, int j, int k)
        throws SQLException
    {
        switch(j)
        {
        case -15: 
            setFormOfUse(i, (short)2);
            // fall through

        case 1: // '\001'
            if(obj instanceof CHAR)
            {
                setCHARInternal(i, (CHAR)obj);
                break;
            }
            if(obj instanceof String)
            {
                setStringInternal(i, (String)obj);
                break;
            }
            if(obj instanceof Boolean)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Boolean)obj).booleanValue() ? 1 : 0).toString());
                break;
            }
            if(obj instanceof Integer)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Integer)obj).intValue()).toString());
                break;
            }
            if(obj instanceof Long)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Long)obj).longValue()).toString());
                break;
            }
            if(obj instanceof Float)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Float)obj).floatValue()).toString());
                break;
            }
            if(obj instanceof Double)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Double)obj).doubleValue()).toString());
                break;
            }
            if(obj instanceof BigDecimal)
            {
                setStringInternal(i, ((BigDecimal)obj).toString());
                break;
            }
            if(obj instanceof Date)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Date)obj).toString()).toString());
                break;
            }
            if(obj instanceof Time)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Time)obj).toString()).toString());
                break;
            }
            if(obj instanceof Timestamp)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Timestamp)obj).toString()).toString());
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            break;

        case -9: 
            setFormOfUse(i, (short)2);
            // fall through

        case 12: // '\f'
            if(obj instanceof String)
            {
                setStringInternal(i, (String)obj);
                break;
            }
            if(obj instanceof Boolean)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Boolean)obj).booleanValue() ? 1 : 0).toString());
                break;
            }
            if(obj instanceof Integer)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Integer)obj).intValue()).toString());
                break;
            }
            if(obj instanceof Long)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Long)obj).longValue()).toString());
                break;
            }
            if(obj instanceof Float)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Float)obj).floatValue()).toString());
                break;
            }
            if(obj instanceof Double)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Double)obj).doubleValue()).toString());
                break;
            }
            if(obj instanceof BigDecimal)
            {
                setStringInternal(i, ((BigDecimal)obj).toString());
                break;
            }
            if(obj instanceof Date)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Date)obj).toString()).toString());
                break;
            }
            if(obj instanceof Time)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Time)obj).toString()).toString());
                break;
            }
            if(obj instanceof Timestamp)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Timestamp)obj).toString()).toString());
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            break;

        case 999: 
            setFixedCHARInternal(i, (String)obj);
            break;

        case -16: 
            setFormOfUse(i, (short)2);
            // fall through

        case -1: 
            if(obj instanceof String)
            {
                setStringInternal(i, (String)obj);
                break;
            }
            if(obj instanceof Boolean)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Boolean)obj).booleanValue() ? 1 : 0).toString());
                break;
            }
            if(obj instanceof Integer)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Integer)obj).intValue()).toString());
                break;
            }
            if(obj instanceof Long)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Long)obj).longValue()).toString());
                break;
            }
            if(obj instanceof Float)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Float)obj).floatValue()).toString());
                break;
            }
            if(obj instanceof Double)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Double)obj).doubleValue()).toString());
                break;
            }
            if(obj instanceof BigDecimal)
            {
                setStringInternal(i, ((BigDecimal)obj).toString());
                break;
            }
            if(obj instanceof Date)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Date)obj).toString()).toString());
                break;
            }
            if(obj instanceof Time)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Time)obj).toString()).toString());
                break;
            }
            if(obj instanceof Timestamp)
            {
                setStringInternal(i, (new StringBuilder()).append("").append(((Timestamp)obj).toString()).toString());
            } else
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
            break;

        case 2: // '\002'
            if(obj instanceof NUMBER)
            {
                setNUMBERInternal(i, (NUMBER)obj);
                break;
            }
            if(obj instanceof Integer)
            {
                setIntInternal(i, ((Integer)obj).intValue());
                break;
            }
            if(obj instanceof Long)
            {
                setLongInternal(i, ((Long)obj).longValue());
                break;
            }
            if(obj instanceof Float)
            {
                setFloatInternal(i, ((Float)obj).floatValue());
                break;
            }
            if(obj instanceof Double)
            {
                setDoubleInternal(i, ((Double)obj).doubleValue());
                break;
            }
            if(obj instanceof BigDecimal)
            {
                setBigDecimalInternal(i, (BigDecimal)obj);
                break;
            }
            if(obj instanceof BigInteger)
            {
                setBigDecimalInternal(i, new BigDecimal((BigInteger)obj));
                break;
            }
            if(obj instanceof String)
            {
                setNUMBERInternal(i, new NUMBER((String)obj, k));
                break;
            }
            if(obj instanceof Boolean)
            {
                setIntInternal(i, ((Boolean)obj).booleanValue() ? 1 : 0);
                break;
            }
            if(obj instanceof Short)
            {
                setShortInternal(i, ((Short)obj).shortValue());
                break;
            }
            if(obj instanceof Byte)
            {
                setByteInternal(i, ((Byte)obj).byteValue());
            } else
            {
                SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception3.fillInStackTrace();
                throw sqlexception3;
            }
            break;

        case 3: // '\003'
            if(obj instanceof BigDecimal)
            {
                setBigDecimalInternal(i, (BigDecimal)obj);
                break;
            }
            if(obj instanceof Number)
            {
                setBigDecimalInternal(i, new BigDecimal(((Number)obj).doubleValue()));
                break;
            }
            if(obj instanceof NUMBER)
            {
                setBigDecimalInternal(i, ((NUMBER)obj).bigDecimalValue());
                break;
            }
            if(obj instanceof String)
            {
                setBigDecimalInternal(i, new BigDecimal((String)obj));
                break;
            }
            if(obj instanceof Boolean)
            {
                setBigDecimalInternal(i, new BigDecimal(((Boolean)obj).booleanValue() ? 1.0D : 0.0D));
            } else
            {
                SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception4.fillInStackTrace();
                throw sqlexception4;
            }
            break;

        case -7: 
            if(obj instanceof Boolean)
            {
                setByteInternal(i, (byte)(((Boolean)obj).booleanValue() ? 1 : 0));
                break;
            }
            if(obj instanceof String)
            {
                setByteInternal(i, (byte)(!"true".equalsIgnoreCase((String)obj) && !"1".equals(obj) ? 0 : 1));
                break;
            }
            if(obj instanceof Number)
            {
                setIntInternal(i, ((Number)obj).byteValue() == 0 ? 0 : 1);
            } else
            {
                SQLException sqlexception5 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception5.fillInStackTrace();
                throw sqlexception5;
            }
            break;

        case -6: 
            if(obj instanceof Number)
            {
                setByteInternal(i, ((Number)obj).byteValue());
                break;
            }
            if(obj instanceof String)
            {
                setByteInternal(i, Byte.parseByte((String)obj));
                break;
            }
            if(obj instanceof Boolean)
            {
                setByteInternal(i, (byte)(((Boolean)obj).booleanValue() ? 1 : 0));
            } else
            {
                SQLException sqlexception6 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception6.fillInStackTrace();
                throw sqlexception6;
            }
            break;

        case 5: // '\005'
            if(obj instanceof Number)
            {
                setShortInternal(i, ((Number)obj).shortValue());
                break;
            }
            if(obj instanceof String)
            {
                setShortInternal(i, Short.parseShort((String)obj));
                break;
            }
            if(obj instanceof Boolean)
            {
                setShortInternal(i, (short)(((Boolean)obj).booleanValue() ? 1 : 0));
            } else
            {
                SQLException sqlexception7 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception7.fillInStackTrace();
                throw sqlexception7;
            }
            break;

        case 4: // '\004'
            if(obj instanceof Number)
            {
                setIntInternal(i, ((Number)obj).intValue());
                break;
            }
            if(obj instanceof String)
            {
                setIntInternal(i, Integer.parseInt((String)obj));
                break;
            }
            if(obj instanceof Boolean)
            {
                setIntInternal(i, ((Boolean)obj).booleanValue() ? 1 : 0);
            } else
            {
                SQLException sqlexception8 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception8.fillInStackTrace();
                throw sqlexception8;
            }
            break;

        case -5: 
            if(obj instanceof Number)
            {
                setLongInternal(i, ((Number)obj).longValue());
                break;
            }
            if(obj instanceof String)
            {
                setLongInternal(i, Long.parseLong((String)obj));
                break;
            }
            if(obj instanceof Boolean)
            {
                setLongInternal(i, ((Boolean)obj).booleanValue() ? 1L : 0L);
            } else
            {
                SQLException sqlexception9 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception9.fillInStackTrace();
                throw sqlexception9;
            }
            break;

        case 7: // '\007'
            if(obj instanceof Number)
            {
                setFloatInternal(i, ((Number)obj).floatValue());
                break;
            }
            if(obj instanceof String)
            {
                setFloatInternal(i, Float.valueOf((String)obj).floatValue());
                break;
            }
            if(obj instanceof Boolean)
            {
                setFloatInternal(i, ((Boolean)obj).booleanValue() ? 1.0F : 0.0F);
            } else
            {
                SQLException sqlexception10 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception10.fillInStackTrace();
                throw sqlexception10;
            }
            break;

        case 6: // '\006'
        case 8: // '\b'
            if(obj instanceof Number)
            {
                setDoubleInternal(i, ((Number)obj).doubleValue());
                break;
            }
            if(obj instanceof String)
            {
                setDoubleInternal(i, Double.valueOf((String)obj).doubleValue());
                break;
            }
            if(obj instanceof Boolean)
            {
                setDoubleInternal(i, ((Boolean)obj).booleanValue() ? 1.0D : 0.0D);
            } else
            {
                SQLException sqlexception11 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception11.fillInStackTrace();
                throw sqlexception11;
            }
            break;

        case -2: 
            if(obj instanceof RAW)
                setRAWInternal(i, (RAW)obj);
            else
                setBytesInternal(i, (byte[])(byte[])obj);
            break;

        case -3: 
            setBytesInternal(i, (byte[])(byte[])obj);
            break;

        case -4: 
            setBytesInternal(i, (byte[])(byte[])obj);
            break;

        case 91: // '['
            if(obj instanceof DATE)
            {
                setDATEInternal(i, (DATE)obj);
                break;
            }
            if(obj instanceof Date)
            {
                setDATEInternal(i, new DATE(obj, getDefaultCalendar()));
                break;
            }
            if(obj instanceof Timestamp)
            {
                setDATEInternal(i, new DATE((Timestamp)obj));
                break;
            }
            if(obj instanceof String)
            {
                setDateInternal(i, Date.valueOf((String)obj));
            } else
            {
                SQLException sqlexception12 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception12.fillInStackTrace();
                throw sqlexception12;
            }
            break;

        case 92: // '\\'
            if(obj instanceof Time)
            {
                setTimeInternal(i, (Time)obj);
                break;
            }
            if(obj instanceof Timestamp)
            {
                setTimeInternal(i, new Time(((Timestamp)obj).getTime()));
                break;
            }
            if(obj instanceof Date)
            {
                setTimeInternal(i, new Time(((Date)obj).getTime()));
                break;
            }
            if(obj instanceof String)
            {
                setTimeInternal(i, Time.valueOf((String)obj));
            } else
            {
                SQLException sqlexception13 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception13.fillInStackTrace();
                throw sqlexception13;
            }
            break;

        case 93: // ']'
            if(obj instanceof TIMESTAMP)
            {
                setTIMESTAMPInternal(i, (TIMESTAMP)obj);
                break;
            }
            if(obj instanceof Timestamp)
            {
                setTimestampInternal(i, (Timestamp)obj);
                break;
            }
            if(obj instanceof Date)
            {
                setTIMESTAMPInternal(i, new TIMESTAMP((Date)obj));
                break;
            }
            if(obj instanceof DATE)
            {
                setTIMESTAMPInternal(i, new TIMESTAMP(((DATE)obj).timestampValue()));
                break;
            }
            if(obj instanceof String)
            {
                setTimestampInternal(i, Timestamp.valueOf((String)obj));
            } else
            {
                SQLException sqlexception14 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
                sqlexception14.fillInStackTrace();
                throw sqlexception14;
            }
            break;

        case -100: 
            setTIMESTAMPInternal(i, (TIMESTAMP)obj);
            break;

        case -101: 
            setTIMESTAMPTZInternal(i, (TIMESTAMPTZ)obj);
            break;

        case -102: 
            setTIMESTAMPLTZInternal(i, (TIMESTAMPLTZ)obj);
            break;

        case -103: 
            setINTERVALYMInternal(i, (INTERVALYM)obj);
            break;

        case -104: 
            setINTERVALDSInternal(i, (INTERVALDS)obj);
            break;

        case -8: 
            setROWIDInternal(i, (ROWID)obj);
            break;

        case 100: // 'd'
            setBinaryFloatInternal(i, (BINARY_FLOAT)obj);
            break;

        case 101: // 'e'
            setBinaryDoubleInternal(i, (BINARY_DOUBLE)obj);
            break;

        case 2004: 
            setBLOBInternal(i, (BLOB)obj);
            break;

        case 2005: 
        case 2011: 
            setCLOBInternal(i, (CLOB)obj);
            if(((CLOB)obj).isNCLOB())
                setFormOfUse(i, (short)2);
            break;

        case -13: 
            setBFILEInternal(i, (BFILE)obj);
            break;

        case 2002: 
        case 2008: 
            setSTRUCTInternal(i, STRUCT.toSTRUCT(obj, connection));
            break;

        case 2003: 
            setARRAYInternal(i, ARRAY.toARRAY(obj, connection));
            break;

        case 2007: 
            setOPAQUEInternal(i, (OPAQUE)obj);
            break;

        case 2006: 
            setREFInternal(i, (REF)obj);
            break;

        case 2009: 
            setSQLXMLInternal(i, (SQLXML)obj);
            break;

        default:
            SQLException sqlexception15 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception15.fillInStackTrace();
            throw sqlexception15;
        }
    }

    public void setObjectAtName(String s, Object obj, int i, int j)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int k = Math.min(sqlObject.getParameterCount(), as.length);
        for(int l = 0; l < k; l++)
            if(as[l] == s1)
            {
                setObjectInternal(l + 1, obj);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setObject(int i, Object obj, int j)
        throws SQLException
    {
        setObjectInternal(i, obj, j, 0);
    }

    void setObjectInternal(int i, Object obj, int j)
        throws SQLException
    {
        setObjectInternal(i, obj, j, 0);
    }

    public void setRefType(int i, REF ref)
        throws SQLException
    {
        setREFInternal(i, ref);
    }

    void setRefTypeInternal(int i, REF ref)
        throws SQLException
    {
        setREFInternal(i, ref);
    }

    public void setRef(int i, Ref ref)
        throws SQLException
    {
        setREFInternal(i, (REF)ref);
    }

    void setRefInternal(int i, Ref ref)
        throws SQLException
    {
        setREFInternal(i, (REF)ref);
    }

    public void setREF(int i, REF ref)
        throws SQLException
    {
        setREFInternal(i, ref);
    }

    void setREFInternal(int i, REF ref)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(ref == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            setREFCritical(j, ref);
            currentRowCharLens[j] = 0;
            return;
        }
    }

    void setREFCritical(int i, REF ref)
        throws SQLException
    {
        StructDescriptor structdescriptor = ref.getDescriptor();
        if(structdescriptor == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 52);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        currentRowBinders[i] = theRefTypeBinder;
        if(parameterDatum == null)
            parameterDatum = new byte[numberOfBindRowsAllocated][numberOfBindPositions][];
        parameterDatum[currentRank][i] = ref.getBytes();
        OracleTypeADT oracletypeadt = structdescriptor.getOracleTypeADT();
        oracletypeadt.getTOID();
        if(parameterOtype == null)
            parameterOtype = new OracleTypeADT[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterOtype[currentRank][i] = oracletypeadt;
    }

    public void setObject(int i, Object obj)
        throws SQLException
    {
        setObjectInternal(i, obj);
    }

    void setObjectInternal(int i, Object obj)
        throws SQLException
    {
        if(obj instanceof ORAData)
            setORADataInternal(i, (ORAData)obj);
        else
        if(obj instanceof CustomDatum)
            setCustomDatumInternal(i, (CustomDatum)obj);
        else
        if(obj instanceof OracleData)
        {
            setOracleDataInternal(i, (OracleData)obj);
        } else
        {
            int j = sqlTypeForObject(obj);
            setObjectInternal(i, obj, j, 0);
        }
    }

    public void setOracleObject(int i, Datum datum)
        throws SQLException
    {
        setObjectInternal(i, datum);
    }

    void setOracleObjectInternal(int i, Datum datum)
        throws SQLException
    {
        setObjectInternal(i, datum);
    }

    public void setPlsqlIndexTable(int i, Object obj, int j, int k, int l, int i1)
        throws SQLException
    {
        synchronized(connection)
        {
            setPlsqlIndexTableInternal(i, obj, j, k, l, i1);
        }
    }

    void setPlsqlIndexTableInternal(int i, Object obj, int j, int k, int l, int i1)
        throws SQLException
    {
        int j1 = i - 1;
        if(j1 < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(obj == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 271);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int k1 = getInternalType(l);
        Object aobj[] = null;
        switch(k1)
        {
        case 1: // '\001'
        case 96: // '`'
            String as[] = null;
            int l1 = 0;
            if(obj instanceof CHAR[])
            {
                CHAR achar[] = (CHAR[])(CHAR[])obj;
                l1 = achar.length;
                as = new String[l1];
                for(int j2 = 0; j2 < l1; j2++)
                {
                    CHAR char1 = achar[j2];
                    if(char1 != null)
                        as[j2] = char1.getString();
                }

            } else
            if(obj instanceof String[])
            {
                as = (String[])(String[])obj;
                l1 = as.length;
            } else
            {
                SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
                sqlexception4.fillInStackTrace();
                throw sqlexception4;
            }
            if(i1 == 0 && as != null)
            {
                for(int i2 = 0; i2 < l1; i2++)
                {
                    String s = as[i2];
                    if(s != null && i1 < s.length())
                        i1 = s.length();
                }

            }
            aobj = as;
            break;

        case 2: // '\002'
        case 6: // '\006'
            aobj = OracleTypeNUMBER.toNUMBERArray(obj, connection, 1L, k);
            if(i1 == 0 && aobj != null)
                i1 = 22;
            currentRowCharLens[j1] = 0;
            break;

        default:
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        if(aobj.length == 0 && j == 0)
        {
            SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 272);
            sqlexception3.fillInStackTrace();
            throw sqlexception3;
        }
        currentRowBinders[j1] = thePlsqlIbtBinder;
        if(parameterPlsqlIbt == null)
            parameterPlsqlIbt = new PlsqlIbtBindInfo[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterPlsqlIbt[currentRank][j1] = new PlsqlIbtBindInfo(aobj, j, k, k1, i1);
        hasIbtBind = true;
    }

    public void setPlsqlIndexTableAtName(String s, Object obj, int i, int j, int k, int l)
        throws SQLException
    {
        synchronized(connection)
        {
            String s1 = s.intern();
            String as[] = sqlObject.getParameterList();
            boolean flag = false;
            int i1 = Math.min(sqlObject.getParameterCount(), as.length);
            for(int j1 = 0; j1 < i1; j1++)
                if(as[j1] == s1)
                {
                    setPlsqlIndexTableInternal(j1 + 1, obj, i, j, k, l);
                    flag = true;
                }

            if(!flag)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
    }

    void endOfResultSet(boolean flag)
        throws SQLException
    {
        if(!flag)
            prepareForNewResults(false, false);
        rowPrefetchInLastFetch = -1;
    }

    int sqlTypeForObject(Object obj)
    {
        if(obj == null)
            return 0;
        if(!(obj instanceof Datum))
        {
            if(obj instanceof String)
                return fixedString ? 999 : 12;
            if(obj instanceof BigDecimal)
                return 2;
            if(obj instanceof BigInteger)
                return 2;
            if(obj instanceof Boolean)
                return -7;
            if(obj instanceof Integer)
                return 4;
            if(obj instanceof Long)
                return -5;
            if(obj instanceof Float)
                return 7;
            if(obj instanceof Double)
                return 8;
            if(obj instanceof byte[])
                return -3;
            if(obj instanceof Short)
                return 5;
            if(obj instanceof Byte)
                return -6;
            if(obj instanceof Date)
                return 91;
            if(obj instanceof Time)
                return 92;
            if(obj instanceof Timestamp)
                return 93;
            if(obj instanceof SQLData)
                return 2002;
            if(obj instanceof ObjectData)
                return 2002;
        } else
        {
            if(obj instanceof BINARY_FLOAT)
                return 100;
            if(obj instanceof BINARY_DOUBLE)
                return 101;
            if(obj instanceof BLOB)
                return 2004;
            if(obj instanceof CLOB)
                return 2005;
            if(obj instanceof BFILE)
                return -13;
            if(obj instanceof ROWID)
                return -8;
            if(obj instanceof NUMBER)
                return 2;
            if(obj instanceof DATE)
                return 91;
            if(obj instanceof TIMESTAMP)
                return 93;
            if(obj instanceof TIMESTAMPTZ)
                return -101;
            if(obj instanceof TIMESTAMPLTZ)
                return -102;
            if(obj instanceof REF)
                return 2006;
            if(obj instanceof CHAR)
                return 1;
            if(obj instanceof RAW)
                return -2;
            if(obj instanceof ARRAY)
                return 2003;
            if(obj instanceof STRUCT)
                return 2002;
            if(obj instanceof OPAQUE)
                return 2007;
            if(obj instanceof INTERVALYM)
                return -103;
            if(obj instanceof INTERVALDS)
                return -104;
            if(obj instanceof SQLXML)
                return 2009;
        }
        return 1111;
    }

    public void clearParameters()
        throws SQLException
    {
        synchronized(connection)
        {
            clearParameters = true;
            for(int i = 0; i < numberOfBindPositions; i++)
                currentRowBinders[i] = null;

        }
    }

    void printByteArray(byte abyte0[])
    {
        if(abyte0 != null)
        {
            int j = abyte0.length;
            for(int i = 0; i < j; i++)
            {
                int k = abyte0[i] & 0xff;
                if(k >= 16);
            }

        }
    }

    public void setCharacterStream(int i, Reader reader, int j)
        throws SQLException
    {
        setCharacterStreamInternal(i, reader, j);
    }

    void setCharacterStreamInternal(int i, Reader reader, int j)
        throws SQLException
    {
        setCharacterStreamInternal(i, reader, j, true);
    }

    void setCharacterStreamInternal(int i, Reader reader, long l, boolean flag)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        set_execute_batch(1);
        checkUserStreamForDuplicates(reader, j);
        if(reader == null)
        {
            basicBindNullString(i);
        } else
        {
            if(userRsetType != 1 && (l > (long)maxVcsCharsSql || !flag))
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            if(!flag)
                setReaderContentsForClobCritical(i, reader, l, flag);
            else
            if(currentRowFormOfUse[j] == 1)
            {
                if(sqlKind.isPlsqlOrCall())
                {
                    if(l > (long)maxVcsBytesPlsql || l > (long)maxVcsCharsPlsql && isServerCharSetFixedWidth)
                        setReaderContentsForClobCritical(i, reader, l, flag);
                    else
                    if(l <= (long)maxVcsCharsPlsql && !connection.retainV9BindBehavior)
                        setReaderContentsForStringInternal(i, reader, (int)l);
                    else
                        setReaderContentsForStringOrClobInVariableWidthCase(i, reader, (int)l, false);
                } else
                if(l <= (long)maxVcsCharsSql && !connection.retainV9BindBehavior)
                    setReaderContentsForStringInternal(i, reader, (int)l);
                else
                if(l > 0x7fffffffL)
                    setReaderContentsForClobCritical(i, reader, l, flag);
                else
                    basicBindCharacterStream(i, reader, (int)l, false);
            } else
            if(sqlKind.isPlsqlOrCall())
            {
                if(l > (long)maxVcsBytesPlsql || l > (long)maxVcsNCharsPlsql && isServerCharSetFixedWidth)
                    setReaderContentsForClobCritical(i, reader, l, flag);
                else
                if(l <= (long)maxVcsNCharsPlsql && !connection.retainV9BindBehavior)
                    setReaderContentsForStringInternal(i, reader, (int)l);
                else
                    setReaderContentsForStringOrClobInVariableWidthCase(i, reader, (int)l, true);
            } else
            if(l <= (long)maxVcsNCharsSql && !connection.retainV9BindBehavior)
                setReaderContentsForStringInternal(i, reader, (int)l);
            else
                setReaderContentsForClobCritical(i, reader, l, flag);
        }
    }

    void basicBindCharacterStream(int i, Reader reader, int j, boolean flag)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        int k;
        k = i - 1;
        if(flag)
            currentRowBinders[k] = theLongStreamForStringBinder;
        else
            currentRowBinders[k] = theLongStreamBinder;
        if(parameterStream == null)
            parameterStream = new InputStream[numberOfBindRowsAllocated][numberOfBindPositions];
        parameterStream[currentRank];
        k;
        if(!flag) goto _L2; else goto _L1
_L1:
        connection;
        connection.conversion.ConvertStreamInternal(reader, 7, j, currentRowFormOfUse[k]);
          goto _L3
_L2:
        connection;
        connection.conversion.ConvertStream(reader, 7, j, currentRowFormOfUse[k]);
_L3:
        JVM INSTR aastore ;
        currentRowCharLens[k] = 0;
        break MISSING_BLOCK_LABEL_160;
        Exception exception;
        exception;
        throw exception;
    }

    void setReaderContentsForStringOrClobInVariableWidthCase(int i, Reader reader, int j, boolean flag)
        throws SQLException
    {
        char ac[] = new char[j];
        int k = 0;
        int l = j;
        int i1;
        try
        {
            while(l > 0 && (i1 = reader.read(ac, k, l)) != -1) 
            {
                k += i1;
                l -= i1;
            }
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(k != j)
        {
            char ac1[] = new char[k];
            System.arraycopy(ac, 0, ac1, 0, k);
            ac = ac1;
        }
        int j1 = connection.conversion.encodedByteLength(ac, flag);
        if(j1 < maxVcsBytesPlsql && !connection.retainV9BindBehavior)
            setStringInternal(i, new String(ac));
        else
            setStringForClobCritical(i, new String(ac));
    }

    void setReaderContentsForStringInternal(int i, Reader reader, int j)
        throws SQLException
    {
        char ac[] = new char[j];
        int k = 0;
        int l = j;
        int i1;
        try
        {
            while(l > 0 && (i1 = reader.read(ac, k, l)) != -1) 
            {
                k += i1;
                l -= i1;
            }
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(k != j)
        {
            char ac1[] = new char[k];
            System.arraycopy(ac, 0, ac1, 0, k);
            ac = ac1;
        }
        setStringInternal(i, new String(ac));
    }

    public void setDate(int i, Date date, Calendar calendar)
        throws SQLException
    {
        setDATEInternal(i, date != null ? new DATE(date, calendar) : null);
    }

    void setDateInternal(int i, Date date, Calendar calendar)
        throws SQLException
    {
        setDATEInternal(i, date != null ? new DATE(date, calendar) : null);
    }

    public void setTime(int i, Time time, Calendar calendar)
        throws SQLException
    {
        setDATEInternal(i, time != null ? new DATE(time, calendar) : null);
    }

    void setTimeInternal(int i, Time time, Calendar calendar)
        throws SQLException
    {
        setDATEInternal(i, time != null ? new DATE(time, calendar) : null);
    }

    public void setTimestamp(int i, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        setTimestampInternal(i, timestamp, calendar);
    }

    void setTimestampInternal(int i, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        setTIMESTAMPInternal(i, timestamp != null ? new TIMESTAMP(timestamp, calendar) : null);
    }

    public void setCheckBindTypes(boolean flag)
    {
        checkBindTypes = flag;
    }

    final void setOracleBatchStyle()
        throws SQLException
    {
        if(m_batchStyle == 2)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with JDBC-2.0-style batching");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            if(m_batchStyle != 0);
            m_batchStyle = 1;
            return;
        }
    }

    boolean isOracleBatchStyle()
    {
        return m_batchStyle == 1;
    }

    final void setJdbcBatchStyle()
        throws SQLException
    {
        if(m_batchStyle == 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with Oracle-style batching");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            m_batchStyle = 2;
            return;
        }
    }

    final void checkIfJdbcBatchExists()
        throws SQLException
    {
        if(doesJdbcBatchExist())
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    boolean doesJdbcBatchExist()
    {
        return currentRank > 0 && m_batchStyle == 2;
    }

    boolean isJdbcBatchStyle()
    {
        return m_batchStyle == 2;
    }

    public void addBatch()
        throws SQLException
    {
        synchronized(connection)
        {
            setJdbcBatchStyle();
            processCompletedBindRow(currentRank + 2, currentRank > 0 && sqlKind.isPlsqlOrCall());
            currentRank++;
        }
    }

    public void addBatch(String s)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void clearBatch()
        throws SQLException
    {
        synchronized(connection)
        {
            for(int i = currentRank - 1; i >= 0; i--)
            {
                for(int j = 0; j < numberOfBindPositions; j++)
                    binders[i][j] = null;

            }

            currentRank = 0;
            if(binders != null)
                currentRowBinders = binders[0];
            pushedBatches = null;
            pushedBatchesTail = null;
            firstRowInBatch = 0;
            clearParameters = true;
        }
    }

    void executeForRowsWithTimeout(boolean flag)
        throws SQLException
    {
        if(queryTimeout <= 0)
            break MISSING_BLOCK_LABEL_82;
        connection.getTimeout().setTimeout(queryTimeout * 1000, this);
        cancelLock.enterExecuting();
        executeForRows(flag);
        connection.getTimeout().cancelTimeout();
        cancelLock.exitExecuting();
        break MISSING_BLOCK_LABEL_114;
        Exception exception;
        exception;
        connection.getTimeout().cancelTimeout();
        cancelLock.exitExecuting();
        throw exception;
        cancelLock.enterExecuting();
        executeForRows(flag);
        cancelLock.exitExecuting();
        break MISSING_BLOCK_LABEL_114;
        Exception exception1;
        exception1;
        cancelLock.exitExecuting();
        throw exception1;
    }

    public int[] executeBatch()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        int ai[];
        int i;
        int l;
        ai = new int[currentRank];
        checkSum = 0L;
        checkSumComputationFailure = false;
        i = 0;
        cleanOldTempLobs();
        setJdbcBatchStyle();
        if(currentRank <= 0)
            break MISSING_BLOCK_LABEL_614;
        ensureOpen();
        prepareForNewResults(true, true);
        if(sqlKind.isSELECT())
        {
            BatchUpdateException batchupdateexception = DatabaseError.createBatchUpdateException(80, 0, null);
            batchupdateexception.fillInStackTrace();
            throw batchupdateexception;
        }
        noMoreUpdateCounts = false;
        l = 0;
        try
        {
            connection.registerHeartbeat();
            connection.needLine();
            if(!isOpen)
            {
                connection.open(this);
                isOpen = true;
            }
            int i1 = currentRank;
            if(pushedBatches == null)
            {
                setupBindBuffers(0, currentRank);
                executeForRowsWithTimeout(false);
            } else
            {
                if(currentRank > firstRowInBatch)
                    pushBatch(true);
                boolean flag = needToParse;
                do
                {
                    PushedBatch pushedbatch = pushedBatches;
                    currentBatchCharLens = pushedbatch.currentBatchCharLens;
                    lastBoundCharLens = pushedbatch.lastBoundCharLens;
                    lastBoundNeeded = pushedbatch.lastBoundNeeded;
                    currentBatchBindAccessors = pushedbatch.currentBatchBindAccessors;
                    needToParse = pushedbatch.need_to_parse;
                    currentBatchNeedToPrepareBinds = pushedbatch.current_batch_need_to_prepare_binds;
                    firstRowInBatch = pushedbatch.first_row_in_batch;
                    setupBindBuffers(pushedbatch.first_row_in_batch, pushedbatch.number_of_rows_to_be_bound);
                    currentRank = pushedbatch.number_of_rows_to_be_bound;
                    executeForRowsWithTimeout(false);
                    l += validRows;
                    if(sqlKind.isPlsqlOrCall())
                        ai[i++] = validRows;
                    pushedBatches = pushedbatch.next;
                } while(pushedBatches != null);
                pushedBatchesTail = null;
                firstRowInBatch = 0;
                needToParse = flag;
            }
            slideDownCurrentRow(i1);
        }
        catch(SQLException sqlexception)
        {
            int j1 = currentRank;
            clearBatch();
            needToParse = true;
            if(!sqlKind.isPlsqlOrCall())
                if(numberOfExecutedElementsInBatch != -1 && numberOfExecutedElementsInBatch != j1)
                {
                    ai = new int[numberOfExecutedElementsInBatch];
                    for(i = 0; i < numberOfExecutedElementsInBatch; i++)
                        ai[i] = -2;

                } else
                {
                    for(i = 0; i < ai.length; i++)
                        ai[i] = -3;

                }
            resetCurrentRowBinders();
            BatchUpdateException batchupdateexception2 = DatabaseError.createBatchUpdateException(sqlexception, sqlKind.isPlsqlOrCall() ? i : ai.length, ai);
            batchupdateexception2.fillInStackTrace();
            throw batchupdateexception2;
        }
        if(sqlKind.isPlsqlOrCall() || l > validRows)
            validRows = l;
        checkValidRowsStatus();
        currentRank = 0;
        break MISSING_BLOCK_LABEL_541;
        Exception exception;
        exception;
        if(sqlKind.isPlsqlOrCall() || l > validRows)
            validRows = l;
        checkValidRowsStatus();
        currentRank = 0;
        throw exception;
        if(validRows < 0)
        {
            for(int j = 0; j < ai.length; j++)
                ai[j] = -3;

            BatchUpdateException batchupdateexception1 = DatabaseError.createBatchUpdateException(81, 0, ai);
            batchupdateexception1.fillInStackTrace();
            throw batchupdateexception1;
        }
        if(!sqlKind.isPlsqlOrCall())
        {
            for(int k = 0; k < ai.length; k++)
                ai[k] = -2;

        }
        connection.registerHeartbeat();
        return ai;
        Exception exception1;
        exception1;
        throw exception1;
    }

    void pushBatch(boolean flag)
    {
        PushedBatch pushedbatch = new PushedBatch();
        pushedbatch.currentBatchCharLens = new int[numberOfBindPositions];
        System.arraycopy(currentBatchCharLens, 0, pushedbatch.currentBatchCharLens, 0, numberOfBindPositions);
        pushedbatch.lastBoundCharLens = new int[numberOfBindPositions];
        System.arraycopy(lastBoundCharLens, 0, pushedbatch.lastBoundCharLens, 0, numberOfBindPositions);
        if(currentBatchBindAccessors != null)
        {
            pushedbatch.currentBatchBindAccessors = new Accessor[numberOfBindPositions];
            System.arraycopy(currentBatchBindAccessors, 0, pushedbatch.currentBatchBindAccessors, 0, numberOfBindPositions);
        }
        pushedbatch.lastBoundNeeded = lastBoundNeeded;
        pushedbatch.need_to_parse = needToParse;
        pushedbatch.current_batch_need_to_prepare_binds = currentBatchNeedToPrepareBinds;
        pushedbatch.first_row_in_batch = firstRowInBatch;
        pushedbatch.number_of_rows_to_be_bound = currentRank - firstRowInBatch;
        if(pushedBatches == null)
            pushedBatches = pushedbatch;
        else
            pushedBatchesTail.next = pushedbatch;
        pushedBatchesTail = pushedbatch;
        if(!flag)
        {
            int ai[] = currentBatchCharLens;
            currentBatchCharLens = lastBoundCharLens;
            lastBoundCharLens = ai;
            lastBoundNeeded = false;
            for(int i = 0; i < numberOfBindPositions; i++)
                currentBatchCharLens[i] = 0;

            firstRowInBatch = currentRank;
        }
    }

    int doScrollPstmtExecuteUpdate()
        throws SQLException
    {
        doScrollExecuteCommon();
        if(sqlKind.isSELECT())
            scrollRsetTypeSolved = true;
        return validRows;
    }

    public int copyBinds(Statement statement, int i)
        throws SQLException
    {
        if(numberOfBindPositions > 0)
        {
            OraclePreparedStatement oraclepreparedstatement = (OraclePreparedStatement)statement;
            int j = bindIndicatorSubRange + 5;
            int k = bindByteSubRange;
            int l = bindCharSubRange;
            int i1 = indicatorsOffset;
            int j1 = valueLengthsOffset;
            for(int k1 = 0; k1 < numberOfBindPositions; k1++)
            {
                short word0 = bindIndicators[j + 0];
                short word1 = bindIndicators[j + 1];
                short word2 = bindIndicators[j + 2];
                int l1 = k1 + i;
                if(oraclepreparedstatement.parameterDatum == null)
                    oraclepreparedstatement.parameterDatum = new byte[oraclepreparedstatement.numberOfBindRowsAllocated][oraclepreparedstatement.numberOfBindPositions][];
                if(oraclepreparedstatement.parameterOtype == null)
                    oraclepreparedstatement.parameterOtype = new OracleTypeADT[oraclepreparedstatement.numberOfBindRowsAllocated][oraclepreparedstatement.numberOfBindPositions];
                if(bindIndicators[i1] == -1)
                {
                    oraclepreparedstatement.currentRowBinders[l1] = copiedNullBinder(word0, word1);
                    if(word2 > 0)
                        oraclepreparedstatement.currentRowCharLens[l1] = 1;
                } else
                if(word0 == 109 || word0 == 111)
                {
                    oraclepreparedstatement.currentRowBinders[l1] = word0 != 109 ? theRefTypeBinder : theNamedTypeBinder;
                    byte abyte0[] = parameterDatum[0][k1];
                    int i2 = abyte0.length;
                    byte abyte1[] = new byte[i2];
                    oraclepreparedstatement.parameterDatum[0][l1] = abyte1;
                    System.arraycopy(abyte0, 0, abyte1, 0, i2);
                    oraclepreparedstatement.parameterOtype[0][l1] = parameterOtype[0][k1];
                } else
                if(word1 > 0)
                    oraclepreparedstatement.currentRowBinders[l1] = copiedByteBinder(word0, bindBytes, k, word1, bindIndicators[j1]);
                else
                if(word2 > 0)
                {
                    oraclepreparedstatement.currentRowBinders[l1] = copiedCharBinder(word0, bindChars, l, word2, bindIndicators[j1], getInoutIndicator(k1));
                    oraclepreparedstatement.currentRowCharLens[l1] = word2;
                } else
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, (new StringBuilder()).append("copyBinds doesn't understand type ").append(word0).toString());
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                k += bindBufferCapacity * word1;
                l += bindBufferCapacity * word2;
                i1 += numberOfBindRowsAllocated;
                j1 += numberOfBindRowsAllocated;
                j += 10;
            }

        }
        return numberOfBindPositions;
    }

    Binder copiedNullBinder(short word0, int i)
        throws SQLException
    {
        return new CopiedNullBinder(word0, i);
    }

    Binder copiedByteBinder(short word0, byte abyte0[], int i, int j, short word1)
        throws SQLException
    {
        byte abyte1[] = new byte[j];
        System.arraycopy(abyte0, i, abyte1, 0, j);
        return new CopiedByteBinder(word0, j, abyte1, word1);
    }

    Binder copiedCharBinder(short word0, char ac[], int i, int j, short word1, short word2)
        throws SQLException
    {
        char ac1[] = new char[j];
        System.arraycopy(ac, i, ac1, 0, j);
        return new CopiedCharBinder(word0, ac1, word1, word2);
    }

    protected void hardClose()
        throws SQLException
    {
        super.hardClose();
        connection.cacheBuffer(bindBytes);
        bindBytes = null;
        connection.cacheBuffer(bindChars);
        bindChars = null;
        bindIndicators = null;
        if(!connection.isClosed())
            cleanAllTempLobs();
        lastBoundBytes = null;
        lastBoundChars = null;
        clearParameters();
    }

    protected void alwaysOnClose()
        throws SQLException
    {
        if(currentRank > 0)
            if(m_batchStyle == 2)
            {
                clearBatch();
            } else
            {
                int i = validRows;
                prematureBatchCount = sendBatch();
                validRows = i;
            }
        if(sqlKind.isSELECT())
        {
            oracle.jdbc.driver.OracleStatement oraclestatement1;
            for(oracle.jdbc.driver.OracleStatement oraclestatement = children; oraclestatement != null; oraclestatement = oraclestatement1)
            {
                oraclestatement1 = oraclestatement.nextChild;
                if(oraclestatement.serverCursor)
                    oraclestatement.cursorId = 0;
            }

        }
        super.alwaysOnClose();
    }

    public void setDisableStmtCaching(boolean flag)
    {
        synchronized(connection)
        {
            if(flag)
                cacheState = 3;
        }
    }

    public void setFormOfUse(int i, short word0)
    {
        synchronized(connection)
        {
            int j = i - 1;
            if(currentRowFormOfUse[j] != word0)
            {
                currentRowFormOfUse[j] = word0;
                if(currentRowBindAccessors != null)
                {
                    Accessor accessor = currentRowBindAccessors[j];
                    if(accessor != null)
                        accessor.setFormOfUse(word0);
                }
                if(returnParamAccessors != null)
                {
                    Accessor accessor1 = returnParamAccessors[j];
                    if(accessor1 != null)
                        accessor1.setFormOfUse(word0);
                }
            }
        }
    }

    public void setURL(int i, URL url)
        throws SQLException
    {
        setURLInternal(i, url);
    }

    void setURLInternal(int i, URL url)
        throws SQLException
    {
        setStringInternal(i, url.toString());
    }

    public ParameterMetaData getParameterMetaData()
        throws SQLException
    {
        return new oracle.jdbc.driver.OracleParameterMetaData(sqlObject.getParameterCount());
    }

    public OracleParameterMetaData OracleGetParameterMetaData()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerReturnParameter(int i, int j)
        throws SQLException
    {
        if(numberOfBindPositions <= 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(numReturnParams <= 0)
        {
            numReturnParams = sqlObject.getReturnParameterCount();
            if(numReturnParams <= 0)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }
        int k = i - 1;
        if(k < numberOfBindPositions - numReturnParams || i > numberOfBindPositions)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        int l = getInternalTypeForDmlReturning(j);
        short word0 = 0;
        if(currentRowFormOfUse != null && currentRowFormOfUse[k] != 0)
            word0 = currentRowFormOfUse[k];
        registerReturnParameterInternal(k, l, j, -1, word0, null);
        currentRowBinders[k] = theReturnParamBinder;
    }

    public void registerReturnParameter(int i, int j, int k)
        throws SQLException
    {
        if(numberOfBindPositions <= 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        int l = i - 1;
        if(l < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(j != 1 && j != 12 && j != -1 && j != -2 && j != -3 && j != -4 && j != 12)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        if(k <= 0)
        {
            SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception3.fillInStackTrace();
            throw sqlexception3;
        }
        int i1 = getInternalTypeForDmlReturning(j);
        short word0 = 0;
        if(currentRowFormOfUse != null && currentRowFormOfUse[l] != 0)
            word0 = currentRowFormOfUse[l];
        registerReturnParameterInternal(l, i1, j, k, word0, null);
        currentRowBinders[l] = theReturnParamBinder;
    }

    public void registerReturnParameter(int i, int j, String s)
        throws SQLException
    {
        if(numberOfBindPositions <= 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        int k = i - 1;
        if(k < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int l = getInternalTypeForDmlReturning(j);
        if(l != 111 && l != 109)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        } else
        {
            registerReturnParameterInternal(k, l, j, -1, (short)0, s);
            currentRowBinders[k] = theReturnParamBinder;
            return;
        }
    }

    public ResultSet getReturnResultSet()
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(returnParamAccessors == null || numReturnParams == 0)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(returnResultSet == null || numReturnParams == 0 || !isOpen)
            returnResultSet = new OracleReturnResultSet(this);
        return returnResultSet;
    }

    int getInternalTypeForDmlReturning(int i)
        throws SQLException
    {
        char c = '\0';
        switch(i)
        {
        case -7: 
        case -6: 
        case -5: 
        case 2: // '\002'
        case 3: // '\003'
        case 4: // '\004'
        case 5: // '\005'
        case 6: // '\006'
        case 7: // '\007'
        case 8: // '\b'
            c = '\006';
            break;

        case 100: // 'd'
            c = 'd';
            break;

        case 101: // 'e'
            c = 'e';
            break;

        case -15: 
        case 1: // '\001'
            c = '`';
            break;

        case -9: 
        case 12: // '\f'
            c = '\001';
            break;

        case -16: 
        case -1: 
            c = '\b';
            break;

        case 91: // '['
        case 92: // '\\'
            c = '\f';
            break;

        case 93: // ']'
            c = '\264';
            break;

        case -101: 
            c = '\265';
            break;

        case -102: 
            c = '\347';
            break;

        case -103: 
            c = '\266';
            break;

        case -104: 
            c = '\267';
            break;

        case -3: 
        case -2: 
            c = '\027';
            break;

        case -4: 
            c = '\030';
            break;

        case -8: 
            c = 'h';
            break;

        case 2004: 
            c = 'q';
            break;

        case 2005: 
        case 2011: 
            c = 'p';
            break;

        case -13: 
            c = 'r';
            break;

        case 2002: 
        case 2003: 
        case 2007: 
        case 2008: 
        case 2009: 
            c = 'm';
            break;

        case 2006: 
            c = 'o';
            break;

        case 70: // 'F'
            c = '\001';
            break;

        default:
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return c;
    }

    void registerReturnParamsForAutoKey()
        throws SQLException
    {
        int ai[] = autoKeyInfo.returnTypes;
        short aword0[] = autoKeyInfo.tableFormOfUses;
        int ai1[] = autoKeyInfo.columnIndexes;
        int i = ai.length;
        int j = numberOfBindPositions - i;
        for(int k = 0; k < i; k++)
        {
            int l = j + k;
            currentRowBinders[l] = theReturnParamBinder;
            short word0 = connection.defaultnchar ? 2 : 1;
            if(aword0 != null && ai1 != null && aword0[ai1[k] - 1] == 2)
            {
                word0 = 2;
                setFormOfUse(l + 1, word0);
            }
            checkTypeForAutoKey(ai[k]);
            String s = null;
            if(ai[k] == 111)
                s = autoKeyInfo.tableTypeNames[ai1[k] - 1];
            registerReturnParameterInternal(l, ai[k], ai[k], -1, word0, s);
        }

    }

    void cleanOldTempLobs()
    {
        if(m_batchStyle != 1 || currentRank == batch - 1)
            super.cleanOldTempLobs();
    }

    void resetOnExceptionDuringExecute()
    {
        super.resetOnExceptionDuringExecute();
        currentRank = 0;
        currentBatchNeedToPrepareBinds = true;
    }

    void resetCurrentRowBinders()
    {
        Binder abinder[] = currentRowBinders;
        if(binders != null && currentRowBinders != null && abinder != binders[0])
        {
            currentRowBinders = binders[0];
            binders[numberOfBoundRows] = abinder;
        }
    }

    public void setAsciiStream(int i, InputStream inputstream)
        throws SQLException
    {
        setAsciiStreamInternal(i, inputstream);
    }

    public void setAsciiStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        setAsciiStreamInternal(i, inputstream, l);
    }

    public void setBinaryStream(int i, InputStream inputstream)
        throws SQLException
    {
        setBinaryStreamInternal(i, inputstream);
    }

    public void setBinaryStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        setBinaryStreamInternal(i, inputstream, l);
    }

    public void setBlob(int i, InputStream inputstream)
        throws SQLException
    {
        setBlobInternal(i, inputstream);
    }

    public void setBlob(int i, InputStream inputstream, long l)
        throws SQLException
    {
        if(l < 0L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            setBlobInternal(i, inputstream, l);
            return;
        }
    }

    public void setCharacterStream(int i, Reader reader)
        throws SQLException
    {
        setCharacterStreamInternal(i, reader);
    }

    public void setCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        setCharacterStreamInternal(i, reader, l);
    }

    public void setClob(int i, Reader reader, long l)
        throws SQLException
    {
        if(l < 0L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            setClobInternal(i, reader, l);
            return;
        }
    }

    public void setClob(int i, Reader reader)
        throws SQLException
    {
        setClobInternal(i, reader);
    }

    public void setRowId(int i, RowId rowid)
        throws SQLException
    {
        setRowIdInternal(i, rowid);
    }

    public void setNCharacterStream(int i, Reader reader)
        throws SQLException
    {
        setNCharacterStreamInternal(i, reader);
    }

    public void setNCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        setNCharacterStreamInternal(i, reader, l);
    }

    public void setNClob(int i, NClob nclob)
        throws SQLException
    {
        setNClobInternal(i, nclob);
    }

    public void setNClob(int i, Reader reader, long l)
        throws SQLException
    {
        setNClobInternal(i, reader, l);
    }

    public void setNClob(int i, Reader reader)
        throws SQLException
    {
        setNClobInternal(i, reader);
    }

    public void setSQLXML(int i, SQLXML sqlxml)
        throws SQLException
    {
        setSQLXMLInternal(i, sqlxml);
    }

    public void setNString(int i, String s)
        throws SQLException
    {
        setNStringInternal(i, s);
    }

    void setAsciiStreamInternal(int i, InputStream inputstream)
        throws SQLException
    {
        setAsciiStreamInternal(i, inputstream, 0L, false);
    }

    void setAsciiStreamInternal(int i, InputStream inputstream, long l)
        throws SQLException
    {
        setAsciiStreamInternal(i, inputstream, l, true);
    }

    void setBinaryStreamInternal(int i, InputStream inputstream)
        throws SQLException
    {
        setBinaryStreamInternal(i, inputstream, 0L, false);
    }

    void setBinaryStreamInternal(int i, InputStream inputstream, long l)
        throws SQLException
    {
        setBinaryStreamInternal(i, inputstream, l, true);
    }

    void setBlobInternal(int i, InputStream inputstream, long l)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(inputstream == null)
            setNullInternal(i, 2004);
        else
            setBinaryStreamContentsForBlobCritical(i, inputstream, l, l != -1L);
    }

    void setBlobInternal(int i, InputStream inputstream)
        throws SQLException
    {
        setBlobInternal(i, inputstream, -1L);
    }

    void setCharacterStreamInternal(int i, Reader reader)
        throws SQLException
    {
        setCharacterStreamInternal(i, reader, 0L, false);
    }

    void setCharacterStreamInternal(int i, Reader reader, long l)
        throws SQLException
    {
        setCharacterStreamInternal(i, reader, l, true);
    }

    void setClobInternal(int i, Reader reader)
        throws SQLException
    {
        setClobInternal(i, reader, -1L);
    }

    void setClobInternal(int i, Reader reader, long l)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(reader == null)
            setNullInternal(i, 2005);
        else
            setReaderContentsForClobCritical(i, reader, l, l != -1L);
    }

    void setNCharacterStreamInternal(int i, Reader reader)
        throws SQLException
    {
        setFormOfUse(i, (short)2);
        setCharacterStreamInternal(i, reader, 0L, false);
    }

    void setNCharacterStreamInternal(int i, Reader reader, long l)
        throws SQLException
    {
        setFormOfUse(i, (short)2);
        setCharacterStreamInternal(i, reader, l);
    }

    void setNClobInternal(int i, NClob nclob)
        throws SQLException
    {
        setFormOfUse(i, (short)2);
        setClobInternal(i, nclob);
    }

    void setNClobInternal(int i, Reader reader)
        throws SQLException
    {
        setFormOfUse(i, (short)2);
        setClobInternal(i, reader);
    }

    void setNClobInternal(int i, Reader reader, long l)
        throws SQLException
    {
        setFormOfUse(i, (short)2);
        setClobInternal(i, reader, l);
    }

    void setNStringInternal(int i, String s)
        throws SQLException
    {
        setFormOfUse(i, (short)2);
        setStringInternal(i, s);
    }

    void setRowIdInternal(int i, RowId rowid)
        throws SQLException
    {
        setROWIDInternal(i, (ROWID)rowid);
    }

    public void setArrayAtName(String s, Array array)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setArray(j + 1, array);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBigDecimalAtName(String s, BigDecimal bigdecimal)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBigDecimal(j + 1, bigdecimal);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBlobAtName(String s, Blob blob)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBlob(j + 1, blob);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBooleanAtName(String s, boolean flag)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag1 = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBoolean(j + 1, flag);
                flag1 = true;
            }

        if(!flag1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setByteAtName(String s, byte byte0)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setByte(j + 1, byte0);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBytesAtName(String s, byte abyte0[])
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBytes(j + 1, abyte0);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setClobAtName(String s, Clob clob)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setClob(j + 1, clob);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setDateAtName(String s, Date date)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setDate(j + 1, date);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setDateAtName(String s, Date date, Calendar calendar)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setDate(j + 1, date, calendar);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setDoubleAtName(String s, double d)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setDouble(j + 1, d);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setFloatAtName(String s, float f)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setFloat(j + 1, f);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setIntAtName(String s, int i)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int j = Math.min(sqlObject.getParameterCount(), as.length);
        for(int k = 0; k < j; k++)
            if(as[k] == s1)
            {
                setInt(k + 1, i);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setLongAtName(String s, long l)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setLong(j + 1, l);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setNClobAtName(String s, NClob nclob)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setNClob(j + 1, nclob);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setNStringAtName(String s, String s1)
        throws SQLException
    {
        String s2 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s2)
            {
                setNString(j + 1, s1);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setObjectAtName(String s, Object obj)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setObject(j + 1, obj);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setObjectAtName(String s, Object obj, int i)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int j = Math.min(sqlObject.getParameterCount(), as.length);
        for(int k = 0; k < j; k++)
            if(as[k] == s1)
            {
                setObject(k + 1, obj, i);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setRefAtName(String s, Ref ref)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setRef(j + 1, ref);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setRowIdAtName(String s, RowId rowid)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setRowId(j + 1, rowid);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setShortAtName(String s, short word0)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setShort(j + 1, word0);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setSQLXMLAtName(String s, SQLXML sqlxml)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setSQLXML(j + 1, sqlxml);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setStringAtName(String s, String s1)
        throws SQLException
    {
        String s2 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s2)
            {
                setString(j + 1, s1);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setTimeAtName(String s, Time time)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setTime(j + 1, time);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setTimeAtName(String s, Time time, Calendar calendar)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setTime(j + 1, time, calendar);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setTimestampAtName(String s, Timestamp timestamp)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setTimestamp(j + 1, timestamp);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setTimestampAtName(String s, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setTimestamp(j + 1, timestamp, calendar);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setURLAtName(String s, URL url)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setURL(j + 1, url);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setARRAYAtName(String s, ARRAY array)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setARRAY(j + 1, array);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBFILEAtName(String s, BFILE bfile)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBFILE(j + 1, bfile);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBfileAtName(String s, BFILE bfile)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBfile(j + 1, bfile);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBinaryFloatAtName(String s, float f)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBinaryFloat(j + 1, f);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBinaryFloatAtName(String s, BINARY_FLOAT binary_float)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBinaryFloat(j + 1, binary_float);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBinaryDoubleAtName(String s, double d)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBinaryDouble(j + 1, d);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBinaryDoubleAtName(String s, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBinaryDouble(j + 1, binary_double);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBLOBAtName(String s, BLOB blob)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setBLOB(j + 1, blob);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setCHARAtName(String s, CHAR char1)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setCHAR(j + 1, char1);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setCLOBAtName(String s, CLOB clob)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setCLOB(j + 1, clob);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setCursorAtName(String s, ResultSet resultset)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setCursor(j + 1, resultset);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setCustomDatumAtName(String s, CustomDatum customdatum)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setCustomDatum(j + 1, customdatum);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setDATEAtName(String s, DATE date)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setDATE(j + 1, date);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setFixedCHARAtName(String s, String s1)
        throws SQLException
    {
        String s2 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s2)
            {
                setFixedCHAR(j + 1, s1);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setINTERVALDSAtName(String s, INTERVALDS intervalds)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setINTERVALDS(j + 1, intervalds);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setINTERVALYMAtName(String s, INTERVALYM intervalym)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setINTERVALYM(j + 1, intervalym);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setNUMBERAtName(String s, NUMBER number)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setNUMBER(j + 1, number);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setOPAQUEAtName(String s, OPAQUE opaque)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setOPAQUE(j + 1, opaque);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setOracleObjectAtName(String s, Datum datum)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setOracleObject(j + 1, datum);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setORADataAtName(String s, ORAData oradata)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setORAData(j + 1, oradata);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setRAWAtName(String s, RAW raw)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setRAW(j + 1, raw);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setREFAtName(String s, REF ref)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setREF(j + 1, ref);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setRefTypeAtName(String s, REF ref)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setRefType(j + 1, ref);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setROWIDAtName(String s, ROWID rowid)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setROWID(j + 1, rowid);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setSTRUCTAtName(String s, STRUCT struct)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setSTRUCT(j + 1, struct);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setTIMESTAMPLTZAtName(String s, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setTIMESTAMPLTZ(j + 1, timestampltz);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setTIMESTAMPTZAtName(String s, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setTIMESTAMPTZ(j + 1, timestamptz);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setTIMESTAMPAtName(String s, TIMESTAMP timestamp)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        boolean flag = false;
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        for(int j = 0; j < i; j++)
            if(as[j] == s1)
            {
                setTIMESTAMP(j + 1, timestamp);
                flag = true;
            }

        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBlobAtName(String s, InputStream inputstream)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setBlob(j + 1, inputstream);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBlobAtName(String s, InputStream inputstream, long l)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setBlob(j + 1, inputstream, l);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setClobAtName(String s, Reader reader)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setClob(j + 1, reader);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setClobAtName(String s, Reader reader, long l)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setClob(j + 1, reader, l);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setNClobAtName(String s, Reader reader)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setNClob(j + 1, reader);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setNClobAtName(String s, Reader reader, long l)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setNClob(j + 1, reader, l);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setAsciiStreamAtName(String s, InputStream inputstream)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setAsciiStream(j + 1, inputstream);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setAsciiStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int j = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int k = 0; k < j; k++)
        {
            if(as[k] != s1)
                continue;
            if(flag)
            {
                setAsciiStream(k + 1, inputstream, i);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setAsciiStreamAtName(String s, InputStream inputstream, long l)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setAsciiStream(j + 1, inputstream, l);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBinaryStreamAtName(String s, InputStream inputstream)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setBinaryStream(j + 1, inputstream);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBinaryStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int j = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int k = 0; k < j; k++)
        {
            if(as[k] != s1)
                continue;
            if(flag)
            {
                setBinaryStream(k + 1, inputstream, i);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setBinaryStreamAtName(String s, InputStream inputstream, long l)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setBinaryStream(j + 1, inputstream, l);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setCharacterStreamAtName(String s, Reader reader)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setCharacterStream(j + 1, reader);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setCharacterStreamAtName(String s, Reader reader, int i)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int j = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int k = 0; k < j; k++)
        {
            if(as[k] != s1)
                continue;
            if(flag)
            {
                setCharacterStream(k + 1, reader, i);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setCharacterStreamAtName(String s, Reader reader, long l)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setCharacterStream(j + 1, reader, l);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setNCharacterStreamAtName(String s, Reader reader)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setNCharacterStream(j + 1, reader);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setNCharacterStreamAtName(String s, Reader reader, long l)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int i = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            if(as[j] != s1)
                continue;
            if(flag)
            {
                setNCharacterStream(j + 1, reader, l);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setUnicodeStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException
    {
        String s1 = s.intern();
        String as[] = sqlObject.getParameterList();
        int j = Math.min(sqlObject.getParameterCount(), as.length);
        boolean flag = true;
        for(int k = 0; k < j; k++)
        {
            if(as[k] != s1)
                continue;
            if(flag)
            {
                setUnicodeStream(k + 1, inputstream, i);
                flag = false;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }

        if(flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    static 
    {
        theStaticVarnumCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarnumCopyingBinder;
        theStaticVarnumNullBinder = OraclePreparedStatementReadOnly.theStaticVarnumNullBinder;
        theStaticBooleanBinder = OraclePreparedStatementReadOnly.theStaticBooleanBinder;
        theStaticByteBinder = OraclePreparedStatementReadOnly.theStaticByteBinder;
        theStaticShortBinder = OraclePreparedStatementReadOnly.theStaticShortBinder;
        theStaticIntBinder = OraclePreparedStatementReadOnly.theStaticIntBinder;
        theStaticLongBinder = OraclePreparedStatementReadOnly.theStaticLongBinder;
        theStaticFloatBinder = OraclePreparedStatementReadOnly.theStaticFloatBinder;
        theStaticDoubleBinder = OraclePreparedStatementReadOnly.theStaticDoubleBinder;
        theStaticBigDecimalBinder = OraclePreparedStatementReadOnly.theStaticBigDecimalBinder;
        theStaticVarcharCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarcharCopyingBinder;
        theStaticVarcharNullBinder = OraclePreparedStatementReadOnly.theStaticVarcharNullBinder;
        theStaticStringBinder = OraclePreparedStatementReadOnly.theStaticStringBinder;
        theStaticSetCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticSetCHARCopyingBinder;
        theStaticSetCHARBinder = OraclePreparedStatementReadOnly.theStaticSetCHARBinder;
        theStaticLittleEndianSetCHARBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianSetCHARBinder;
        theStaticSetCHARNullBinder = OraclePreparedStatementReadOnly.theStaticSetCHARNullBinder;
        theStaticFixedCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARCopyingBinder;
        theStaticFixedCHARBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARBinder;
        theStaticFixedCHARNullBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARNullBinder;
        theStaticDateCopyingBinder = OraclePreparedStatementReadOnly.theStaticDateCopyingBinder;
        theStaticDateBinder = OraclePreparedStatementReadOnly.theStaticDateBinder;
        theStaticDateNullBinder = OraclePreparedStatementReadOnly.theStaticDateNullBinder;
        theStaticTimeCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimeCopyingBinder;
        theStaticTimeBinder = OraclePreparedStatementReadOnly.theStaticTimeBinder;
        theStaticTimestampCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimestampCopyingBinder;
        theStaticTimestampBinder = OraclePreparedStatementReadOnly.theStaticTimestampBinder;
        theStaticTimestampNullBinder = OraclePreparedStatementReadOnly.theStaticTimestampNullBinder;
        theStaticOracleNumberBinder = OraclePreparedStatementReadOnly.theStaticOracleNumberBinder;
        theStaticOracleDateBinder = OraclePreparedStatementReadOnly.theStaticOracleDateBinder;
        theStaticOracleTimestampBinder = OraclePreparedStatementReadOnly.theStaticOracleTimestampBinder;
        theStaticTSTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSTZCopyingBinder;
        theStaticTSTZBinder = OraclePreparedStatementReadOnly.theStaticTSTZBinder;
        theStaticTSTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSTZNullBinder;
        theStaticTSLTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSLTZCopyingBinder;
        theStaticTSLTZBinder = OraclePreparedStatementReadOnly.theStaticTSLTZBinder;
        theStaticTSLTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSLTZNullBinder;
        theStaticRowidCopyingBinder = OraclePreparedStatementReadOnly.theStaticRowidCopyingBinder;
        theStaticRowidBinder = OraclePreparedStatementReadOnly.theStaticRowidBinder;
        theStaticLittleEndianRowidBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianRowidBinder;
        theStaticRowidNullBinder = OraclePreparedStatementReadOnly.theStaticRowidNullBinder;
        theStaticURowidNullBinder = OraclePreparedStatementReadOnly.theStaticURowidNullBinder;
        theStaticIntervalDSCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSCopyingBinder;
        theStaticIntervalDSBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSBinder;
        theStaticIntervalDSNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSNullBinder;
        theStaticIntervalYMCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMCopyingBinder;
        theStaticIntervalYMBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMBinder;
        theStaticIntervalYMNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMNullBinder;
        theStaticBfileCopyingBinder = OraclePreparedStatementReadOnly.theStaticBfileCopyingBinder;
        theStaticBfileBinder = OraclePreparedStatementReadOnly.theStaticBfileBinder;
        theStaticBfileNullBinder = OraclePreparedStatementReadOnly.theStaticBfileNullBinder;
        theStaticBlobCopyingBinder = OraclePreparedStatementReadOnly.theStaticBlobCopyingBinder;
        theStaticBlobBinder = OraclePreparedStatementReadOnly.theStaticBlobBinder;
        theStaticBlobNullBinder = OraclePreparedStatementReadOnly.theStaticBlobNullBinder;
        theStaticClobCopyingBinder = OraclePreparedStatementReadOnly.theStaticClobCopyingBinder;
        theStaticClobBinder = OraclePreparedStatementReadOnly.theStaticClobBinder;
        theStaticClobNullBinder = OraclePreparedStatementReadOnly.theStaticClobNullBinder;
        theStaticRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticRawCopyingBinder;
        theStaticRawBinder = OraclePreparedStatementReadOnly.theStaticRawBinder;
        theStaticRawNullBinder = OraclePreparedStatementReadOnly.theStaticRawNullBinder;
        theStaticPlsqlRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawCopyingBinder;
        theStaticPlsqlRawBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawBinder;
        theStaticBinaryFloatCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatCopyingBinder;
        theStaticBinaryFloatBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatBinder;
        theStaticBinaryFloatNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatNullBinder;
        theStaticBINARY_FLOATCopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATCopyingBinder;
        theStaticBINARY_FLOATBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATBinder;
        theStaticBINARY_FLOATNullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATNullBinder;
        theStaticBinaryDoubleCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleCopyingBinder;
        theStaticBinaryDoubleBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleBinder;
        theStaticBinaryDoubleNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleNullBinder;
        theStaticBINARY_DOUBLECopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLECopyingBinder;
        theStaticBINARY_DOUBLEBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLEBinder;
        theStaticBINARY_DOUBLENullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLENullBinder;
        theStaticLongStreamBinder = OraclePreparedStatementReadOnly.theStaticLongStreamBinder;
        theStaticLongStreamForStringBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringBinder;
        theStaticLongStreamForStringCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringCopyingBinder;
        theStaticLongRawStreamBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamBinder;
        theStaticLongRawStreamForBytesBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesBinder;
        theStaticLongRawStreamForBytesCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesCopyingBinder;
        theStaticNamedTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeCopyingBinder;
        theStaticNamedTypeBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeBinder;
        theStaticNamedTypeNullBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeNullBinder;
        theStaticRefTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticRefTypeCopyingBinder;
        theStaticRefTypeBinder = OraclePreparedStatementReadOnly.theStaticRefTypeBinder;
        theStaticRefTypeNullBinder = OraclePreparedStatementReadOnly.theStaticRefTypeNullBinder;
        theStaticPlsqlIbtCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtCopyingBinder;
        theStaticPlsqlIbtBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtBinder;
        theStaticPlsqlIbtNullBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtNullBinder;
        theStaticOutBinder = OraclePreparedStatementReadOnly.theStaticOutBinder;
        theStaticReturnParamBinder = OraclePreparedStatementReadOnly.theStaticReturnParamBinder;
        theStaticT4CRowidBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidBinder;
        theStaticT4CURowidBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidBinder;
        theStaticT4CRowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidNullBinder;
        theStaticT4CURowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidNullBinder;
        UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");
        UTC_US_CALENDAR = Calendar.getInstance(UTC_TIME_ZONE, Locale.US);
    }
}
