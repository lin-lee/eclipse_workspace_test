// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CXAResource.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import javax.sql.XAConnection;
import javax.transaction.xa.*;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.xa.*;
import oracle.jdbc.xa.client.OracleXADataSource;
import oracle.jdbc.xa.client.OracleXAResource;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIOtxse, T4CTTIOtxen, T4CTTIk2rpc, T4CConnection, 
//            DatabaseError

class T4CXAResource extends OracleXAResource
{

    T4CConnection physicalConn;
    int applicationValueArr[];
    boolean isTransLoose;
    byte context[];
    int errorNumber;
    private String password;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CXAResource(T4CConnection t4cconnection, OracleXAConnection oraclexaconnection, boolean flag)
        throws XAException
    {
        super(t4cconnection, oraclexaconnection);
        applicationValueArr = new int[1];
        isTransLoose = false;
        physicalConn = t4cconnection;
        isTransLoose = flag;
    }

    protected int doStart(Xid xid, int i)
        throws XAException
    {
        T4CConnection t4cconnection = physicalConn;
        JVM INSTR monitorenter ;
        byte byte0 = -1;
        if(isTransLoose)
            i |= 0x10000;
        int k = i & 0x8200000;
        if(k == 0x8000000 && OracleXid.isLocalTransaction(xid))
            return 0;
        int j;
        applicationValueArr[0] = 0;
        try
        {
            try
            {
                T4CTTIOtxse t4cttiotxse = physicalConn.otxse;
                byte abyte0[] = null;
                byte abyte1[] = xid.getGlobalTransactionId();
                byte abyte2[] = xid.getBranchQualifier();
                int l = 0;
                int i1 = 0;
                if(abyte1 != null && abyte2 != null)
                {
                    l = Math.min(abyte1.length, 64);
                    i1 = Math.min(abyte2.length, 64);
                    abyte0 = new byte[128];
                    System.arraycopy(abyte1, 0, abyte0, 0, l);
                    System.arraycopy(abyte2, 0, abyte0, l, i1);
                }
                int j1 = 0;
                if((i & 0x200000) != 0 || (i & 0x8000000) != 0)
                    j1 |= 4;
                else
                    j1 |= 1;
                if((i & 0x100) != 0)
                    j1 |= 0x100;
                if((i & 0x200) != 0)
                    j1 |= 0x200;
                if((i & 0x400) != 0)
                    j1 |= 0x400;
                if((i & 0x10000) != 0)
                    j1 |= 0x10000;
                physicalConn.needLine();
                physicalConn.sendPiggyBackedMessages();
                t4cttiotxse.doOTXSE(1, null, abyte0, xid.getFormatId(), l, i1, timeout, j1, applicationValueArr);
                applicationValueArr[0] = t4cttiotxse.getApplicationValue();
                byte abyte3[] = t4cttiotxse.getContext();
                if(abyte3 != null)
                    context = abyte3;
                j = 0;
            }
            catch(IOException ioexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }
        catch(SQLException sqlexception)
        {
            j = sqlexception.getErrorCode();
            if(j == 0)
                throw new XAException(-6);
        }
        j;
        t4cconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    protected int doEnd(Xid xid, int i, boolean flag)
        throws XAException
    {
        T4CConnection t4cconnection = physicalConn;
        JVM INSTR monitorenter ;
        int j = -1;
        T4CTTIOtxse t4cttiotxse;
        byte abyte0[];
        int k;
        int l;
        t4cttiotxse = physicalConn.otxse;
        abyte0 = null;
        byte abyte1[] = xid.getGlobalTransactionId();
        byte abyte2[] = xid.getBranchQualifier();
        k = 0;
        l = 0;
        if(abyte1 != null && abyte2 != null)
        {
            k = Math.min(abyte1.length, 64);
            l = Math.min(abyte2.length, 64);
            abyte0 = new byte[128];
            System.arraycopy(abyte1, 0, abyte0, 0, k);
            System.arraycopy(abyte2, 0, abyte0, k, l);
        }
        if(context != null)
            break MISSING_BLOCK_LABEL_132;
        j = doStart(xid, 0x8000000);
        if(j != 0)
            return j;
        try
        {
            try
            {
                byte abyte3[] = context;
                int i1 = 0;
                if((i & 2) == 2)
                    i1 = 0x100000;
                else
                if((i & 0x2000000) == 0x2000000 && (i & 0x100000) != 0x100000)
                    i1 = 0x100000;
                applicationValueArr[0] >>= 16;
                physicalConn.needLine();
                physicalConn.sendPiggyBackedMessages();
                t4cttiotxse.doOTXSE(2, abyte3, abyte0, xid.getFormatId(), k, l, timeout, i1, applicationValueArr);
                applicationValueArr[0] = t4cttiotxse.getApplicationValue();
                byte abyte4[] = t4cttiotxse.getContext();
                if(abyte4 != null)
                    context = abyte4;
                j = 0;
            }
            catch(IOException ioexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }
        catch(SQLException sqlexception)
        {
            j = sqlexception.getErrorCode();
            if(j == 0)
                throw new XAException(-6);
        }
        j;
        t4cconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    protected void doCommit(Xid xid, boolean flag)
        throws SQLException, XAException
    {
        T4CConnection t4cconnection = physicalConn;
        JVM INSTR monitorenter ;
        byte byte0 = ((byte)(flag ? 4 : 2));
        int i = doTransaction(xid, 1, byte0);
        if((!flag || i != 2 && i != 4) && (flag || i != 5))
            if(i == 8)
                throw new XAException(106);
            else
                throw new XAException(-6);
        break MISSING_BLOCK_LABEL_306;
        SQLException sqlexception;
        sqlexception;
        OracleXADataSource oraclexadatasource;
        XAConnection xaconnection;
        int j = sqlexception.getErrorCode();
        if(j == 24756)
        {
            kputxrec(xid, 1, timeout + 120, sqlexception);
            break MISSING_BLOCK_LABEL_306;
        }
        if(j != 24780)
            break MISSING_BLOCK_LABEL_303;
        oraclexadatasource = null;
        xaconnection = null;
        try
        {
            oraclexadatasource = new OracleXADataSource();
            oraclexadatasource.setURL(physicalConn.url);
            oraclexadatasource.setUser(physicalConn.userName);
            physicalConn.getPasswordInternal(this);
            oraclexadatasource.setPassword(password);
            xaconnection = oraclexadatasource.getXAConnection();
            XAResource xaresource = xaconnection.getXAResource();
            xaresource.commit(xid, flag);
        }
        catch(SQLException sqlexception1)
        {
            XAException xaexception = new XAException(-6);
            xaexception.initCause(sqlexception1);
            throw xaexception;
        }
        try
        {
            if(xaconnection != null)
                xaconnection.close();
            if(oraclexadatasource != null)
                oraclexadatasource.close();
        }
        catch(Exception exception) { }
        break MISSING_BLOCK_LABEL_306;
        Exception exception1;
        exception1;
        try
        {
            if(xaconnection != null)
                xaconnection.close();
            if(oraclexadatasource != null)
                oraclexadatasource.close();
        }
        catch(Exception exception2) { }
        throw exception1;
        throw sqlexception;
        Exception exception3;
        exception3;
        throw exception3;
    }

    protected int doPrepare(Xid xid)
        throws XAException, SQLException
    {
        T4CConnection t4cconnection = physicalConn;
        JVM INSTR monitorenter ;
        byte byte0 = -1;
        try
        {
            int i = doTransaction(xid, 3, 0);
            if(i == 8)
                throw new XAException(106);
            if(i == 4)
                byte0 = 3;
            else
            if(i == 1)
                byte0 = 0;
            else
            if(i == 3)
                throw new XAException(100);
            else
                throw new XAException(-6);
        }
        catch(SQLException sqlexception)
        {
            int j = sqlexception.getErrorCode();
            if(j == 25351)
            {
                XAException xaexception = new XAException(-6);
                xaexception.initCause(sqlexception);
                throw xaexception;
            } else
            {
                throw sqlexception;
            }
        }
        return byte0;
        Exception exception;
        exception;
        throw exception;
    }

    protected int doForget(Xid xid)
        throws XAException, SQLException
    {
        T4CConnection t4cconnection = physicalConn;
        JVM INSTR monitorenter ;
        int i;
        i = 0;
        if(OracleXid.isLocalTransaction(xid))
            return 24771;
        int j = doStart(xid, 0x8000000);
        if(j == 24756) goto _L2; else goto _L1
_L1:
        if(j != 0) goto _L4; else goto _L3
_L3:
        doEnd(xid, 0, false);
          goto _L4
        Exception exception;
        exception;
_L4:
        if(j != 0 && j != 2079 && j != 24754 && j != 24761 && j != 24774 && j != 24776 && j != 25351) goto _L6; else goto _L5
_L5:
        24769;
        t4cconnection;
        JVM INSTR monitorexit ;
        return;
_L6:
        if(j != 24752) goto _L8; else goto _L7
_L7:
        24771;
        t4cconnection;
        JVM INSTR monitorexit ;
        return;
_L8:
        j;
        t4cconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        kputxrec(xid, 4, 1, null);
        i;
        t4cconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception1;
        exception1;
        throw exception1;
    }

    protected void doRollback(Xid xid)
        throws XAException, SQLException
    {
        T4CConnection t4cconnection = physicalConn;
        JVM INSTR monitorenter ;
        int i = doTransaction(xid, 2, 3);
        if(i == 8)
            throw new XAException(106);
        if(i != 3)
            throw new XAException(-6);
        break MISSING_BLOCK_LABEL_274;
        SQLException sqlexception;
        sqlexception;
        int j;
        OracleXADataSource oraclexadatasource;
        XAConnection xaconnection;
        j = sqlexception.getErrorCode();
        if(j == 24756)
        {
            kputxrec(xid, 2, timeout + 120, sqlexception);
            break MISSING_BLOCK_LABEL_274;
        }
        if(j != 24780)
            break MISSING_BLOCK_LABEL_261;
        oraclexadatasource = null;
        xaconnection = null;
        try
        {
            oraclexadatasource = new OracleXADataSource();
            oraclexadatasource.setURL(physicalConn.url);
            oraclexadatasource.setUser(physicalConn.userName);
            physicalConn.getPasswordInternal(this);
            oraclexadatasource.setPassword(password);
            xaconnection = oraclexadatasource.getXAConnection();
            XAResource xaresource = xaconnection.getXAResource();
            xaresource.rollback(xid);
        }
        catch(SQLException sqlexception1)
        {
            XAException xaexception = new XAException(-6);
            xaexception.initCause(sqlexception1);
            throw xaexception;
        }
        try
        {
            if(xaconnection != null)
                xaconnection.close();
            if(oraclexadatasource != null)
                oraclexadatasource.close();
        }
        catch(Exception exception) { }
        break MISSING_BLOCK_LABEL_274;
        Exception exception1;
        exception1;
        try
        {
            if(xaconnection != null)
                xaconnection.close();
            if(oraclexadatasource != null)
                oraclexadatasource.close();
        }
        catch(Exception exception2) { }
        throw exception1;
        if(j != 25402)
            throw sqlexception;
        break MISSING_BLOCK_LABEL_286;
        Exception exception3;
        exception3;
        throw exception3;
    }

    int doTransaction(Xid xid, int i, int j)
        throws SQLException
    {
        int k = -1;
        try
        {
            T4CTTIOtxen t4cttiotxen = physicalConn.otxen;
            byte abyte0[] = null;
            byte abyte1[] = xid.getGlobalTransactionId();
            byte abyte2[] = xid.getBranchQualifier();
            int l = 0;
            int i1 = 0;
            if(abyte1 != null && abyte2 != null)
            {
                l = Math.min(abyte1.length, 64);
                i1 = Math.min(abyte2.length, 64);
                abyte0 = new byte[128];
                System.arraycopy(abyte1, 0, abyte0, 0, l);
                System.arraycopy(abyte2, 0, abyte0, l, i1);
            }
            byte abyte3[] = context;
            physicalConn.needLine();
            physicalConn.sendPiggyBackedMessages();
            t4cttiotxen.doOTXEN(i, abyte3, abyte0, xid.getFormatId(), l, i1, timeout, j, 0);
            k = t4cttiotxen.getOutStateFromServer();
        }
        catch(IOException ioexception)
        {
            physicalConn.handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return k;
    }

    protected void kputxrec(Xid xid, int i, int j, SQLException sqlexception)
        throws XAException, SQLException
    {
        byte byte0;
        switch(i)
        {
        case 1: // '\001'
            byte0 = 3;
            break;

        case 4: // '\004'
            byte0 = 2;
            break;

        default:
            byte0 = 0;
            break;
        }
        int k = 0;
        do
        {
            if(j-- <= 0)
                break;
            k = doTransaction(xid, 5, byte0);
            if(k != 7)
                break;
            try
            {
                Thread.sleep(1000L);
            }
            catch(Exception exception) { }
        } while(true);
        if(k == 7)
            throw new XAException(-6);
        byte byte2 = -1;
        byte byte1;
        switch(k)
        {
        case 3: // '\003'
            if(i == 1)
            {
                byte1 = 7;
            } else
            {
                byte1 = 8;
                byte2 = -3;
            }
            break;

        case 0: // '\0'
            if(i == 4)
            {
                byte1 = 8;
                byte2 = -3;
                break;
            }
            byte1 = 7;
            if(i == 1)
                byte2 = -4;
            break;

        case 2: // '\002'
            if(i == 4)
            {
                byte1 = 8;
                byte2 = -6;
                break;
            }
            // fall through

        case 5: // '\005'
            if(i == 4)
            {
                byte1 = 7;
            } else
            {
                byte2 = 7;
                byte1 = 8;
            }
            break;

        case 4: // '\004'
            if(i == 4)
            {
                byte1 = 7;
            } else
            {
                byte2 = 6;
                byte1 = 8;
            }
            break;

        case 6: // '\006'
            if(i == 4)
            {
                byte1 = 7;
            } else
            {
                byte2 = 5;
                byte1 = 8;
            }
            break;

        case 1: // '\001'
        default:
            byte2 = -3;
            byte1 = 8;
            break;
        }
        T4CTTIk2rpc t4cttik2rpc = physicalConn.k2rpc;
        try
        {
            t4cttik2rpc.doOK2RPC(3, byte1);
        }
        catch(IOException ioexception)
        {
            XAException xaexception = new XAException(-7);
            xaexception.initCause(ioexception);
            throw xaexception;
        }
        catch(SQLException sqlexception1)
        {
            XAException xaexception1 = new XAException(-6);
            xaexception1.initCause(sqlexception1);
            throw xaexception1;
        }
        if(byte2 != -1)
        {
            OracleXAException oraclexaexception = null;
            if(sqlexception != null)
            {
                oraclexaexception = new OracleXAException(sqlexception.getErrorCode(), byte2);
                oraclexaexception.initCause(sqlexception);
            } else
            {
                oraclexaexception = new OracleXAException(0, byte2);
            }
            throw oraclexaexception;
        } else
        {
            return;
        }
    }

    final void setPasswordInternal(String s)
    {
        password = s;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return physicalConn;
    }

}
