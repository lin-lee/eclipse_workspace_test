// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.sql.Time;

// Referenced classes of package oracle.jdbc.driver:
//            DateCommonBinder, Binder, OraclePreparedStatementReadOnly, OraclePreparedStatement, 
//            PhysicalConnection

class TimeBinder extends DateCommonBinder
{

    Binder theTimeCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    static void init(Binder binder)
    {
        binder.type = 12;
        binder.bytelen = 7;
    }

    TimeBinder()
    {
        theTimeCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimeCopyingBinder;
        init(this);
    }

    Binder copyingBinder()
    {
        return theTimeCopyingBinder;
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
        throws SQLException
    {
        Time atime[] = oraclepreparedstatement.parameterTime[k];
        Time time = atime[i];
        if(flag)
            atime[i] = null;
        if(time == null)
        {
            aword0[i2] = -1;
        } else
        {
            aword0[i2] = 0;
            setOracleHMS(setOracleCYMD(time.getTime(), abyte0, j1, oraclepreparedstatement), abyte0, j1);
            abyte0[0 + j1] = 119;
            abyte0[2 + j1] = 1;
            abyte0[3 + j1] = 1;
            if(oraclepreparedstatement.connection.use1900AsYearForTime)
                abyte0[1 + j1] = 100;
            else
                abyte0[1 + j1] = -86;
            aword0[l1] = (short)l;
        }
    }

}
