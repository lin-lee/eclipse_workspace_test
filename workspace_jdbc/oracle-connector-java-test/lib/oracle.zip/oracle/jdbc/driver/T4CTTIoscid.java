// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIoscid.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CMAREngine, DBConversion, T4CConnection

final class T4CTTIoscid extends T4CTTIfun
{

    static final int KPDUSR_CID_RESET = 1;
    static final int KPDUSR_PROXY_RESET = 2;
    static final int KPDUSR_PROXY_TKTSENT = 4;
    static final int KPDUSR_MODULE_RESET = 8;
    static final int KPDUSR_ACTION_RESET = 16;
    static final int KPDUSR_EXECID_RESET = 32;
    static final int KPDUSR_EXECSQ_RESET = 64;
    static final int KPDUSR_COLLCT_RESET = 128;
    static final int KPDUSR_CLINFO_RESET = 256;
    private byte cidcid[];
    private byte cidmod[];
    private byte cidact[];
    private byte cideci[];
    private boolean endToEndHasChanged[];
    private String endToEndValues[];
    private int endToEndECIDSequenceNumber;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIoscid(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)17);
        cidcid = null;
        cidmod = null;
        cidact = null;
        cideci = null;
        endToEndHasChanged = null;
        endToEndValues = null;
        setFunCode((short)135);
    }

    void doOSCID(boolean aflag[], String as[], int i)
        throws IOException, SQLException
    {
        endToEndHasChanged = aflag;
        endToEndValues = as;
        endToEndECIDSequenceNumber = i;
        if(endToEndValues[1] != null)
            cidcid = meg.conv.StringToCharBytes(endToEndValues[1]);
        else
            cidcid = null;
        if(endToEndValues[3] != null)
            cidmod = meg.conv.StringToCharBytes(endToEndValues[3]);
        else
            cidmod = null;
        if(endToEndValues[0] != null)
            cidact = meg.conv.StringToCharBytes(endToEndValues[0]);
        else
            cidact = null;
        if(endToEndValues[2] != null)
            cideci = meg.conv.StringToCharBytes(endToEndValues[2]);
        else
            cideci = null;
        doPigRPC();
    }

    void marshal()
        throws IOException
    {
        int i = 64;
        if(endToEndHasChanged[0])
            i |= 0x10;
        if(endToEndHasChanged[1])
            i |= 1;
        if(endToEndHasChanged[2])
            i |= 0x20;
        if(endToEndHasChanged[3])
            i |= 8;
        meg.marshalNULLPTR();
        meg.marshalNULLPTR();
        meg.marshalUB4(i);
        boolean flag = false;
        boolean flag1 = false;
        boolean flag2 = false;
        boolean flag3 = false;
        if(endToEndHasChanged[1])
        {
            meg.marshalPTR();
            if(cidcid != null)
                meg.marshalUB4(cidcid.length);
            else
                meg.marshalUB4(0L);
            flag = true;
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        }
        if(endToEndHasChanged[3])
        {
            meg.marshalPTR();
            if(cidmod != null)
                meg.marshalUB4(cidmod.length);
            else
                meg.marshalUB4(0L);
            flag1 = true;
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        }
        if(endToEndHasChanged[0])
        {
            meg.marshalPTR();
            if(cidact != null)
                meg.marshalUB4(cidact.length);
            else
                meg.marshalUB4(0L);
            flag2 = true;
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        }
        if(endToEndHasChanged[2])
        {
            meg.marshalPTR();
            if(cideci != null)
                meg.marshalUB4(cideci.length);
            else
                meg.marshalUB4(0L);
            flag3 = true;
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        }
        meg.marshalUB2(0);
        meg.marshalUB2(endToEndECIDSequenceNumber);
        meg.marshalNULLPTR();
        meg.marshalUB4(0L);
        meg.marshalNULLPTR();
        meg.marshalUB4(0L);
        meg.marshalNULLPTR();
        meg.marshalUB4(0L);
        if(flag && cidcid != null)
            meg.marshalCHR(cidcid);
        if(flag1 && cidmod != null)
            meg.marshalCHR(cidmod);
        if(flag2 && cidact != null)
            meg.marshalCHR(cidact);
        if(flag3 && cideci != null)
            meg.marshalCHR(cideci);
    }

}
