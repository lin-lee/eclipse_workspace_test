// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   RowidAccessor.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.Map;
import oracle.sql.Datum;
import oracle.sql.ROWID;

// Referenced classes of package oracle.jdbc.driver:
//            Accessor, DatabaseError, OracleStatement

class RowidAccessor extends Accessor
{

    static final int maxLength = 128;
    static final int EXTENDED_ROWID_MAX_LENGTH = 18;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    RowidAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 104, 9, word0, flag);
        initForDataAccess(j, i, null);
    }

    RowidAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        init(oraclestatement, 104, 9, word0, false);
        initForDescribe(104, i, flag, j, k, l, i1, j1, word0, null);
        initForDataAccess(0, i, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        internalTypeMaxLength = 128;
        byteLength = internalTypeMaxLength + 2;
    }

    String getString(int i)
        throws SQLException
    {
        String s = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            int j = columnIndex + byteLength * i;
            short word0 = rowSpaceIndicator[lengthIndex + i];
            s = new String(rowSpaceByte, j + 2, word0);
        }
        return s;
    }

    Object getObject(int i)
        throws SQLException
    {
        return getROWID(i);
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        return getROWID(i);
    }

    ROWID getROWID(int i)
        throws SQLException
    {
        byte abyte0[] = getBytes(i);
        return abyte0 != null ? new ROWID(abyte0) : null;
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        byte abyte0[] = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            short word0 = rowSpaceIndicator[lengthIndex + i];
            int j = columnIndex + byteLength * i;
            abyte0 = new byte[word0];
            System.arraycopy(rowSpaceByte, j + 2, abyte0, 0, word0);
        }
        return abyte0;
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        return getROWID(i);
    }

}
