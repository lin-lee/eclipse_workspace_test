// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   LogicalConnection.java

package oracle.jdbc.driver;

import java.net.SocketException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.EnumSet;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;
import javax.transaction.xa.XAResource;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.jdbc.internal.OracleStatement;
import oracle.jdbc.internal.XSEventListener;
import oracle.jdbc.internal.XSNamespace;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.oracore.OracleTypeCLOB;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import oracle.jdbc.pool.OraclePooledConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.BFILE;
import oracle.sql.BLOB;
import oracle.sql.BfileDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.sql.CLOB;
import oracle.sql.ClobDBAccess;
import oracle.sql.CustomDatum;
import oracle.sql.Datum;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMEZONETAB;

// Referenced classes of package oracle.jdbc.driver:
//            OracleConnection, ClosedConnection, PhysicalConnection, DatabaseError, 
//            OracleCloseCallback

class LogicalConnection extends oracle.jdbc.driver.OracleConnection
{

    static final ClosedConnection closedConnection = new ClosedConnection();
    PhysicalConnection internalConnection;
    OraclePooledConnection pooledConnection;
    boolean closed;
    OracleCloseCallback closeCallback;
    Object privateData;
    long startTime;
    OracleConnectionCacheCallback connectionCacheCallback;
    Object connectionCacheCallbackUserObj;
    int callbackFlag;
    int releasePriority;
    int heartbeatCount;
    int heartbeatLastCount;
    int heartbeatNoChangeCount;
    boolean isAbandonedTimeoutEnabled;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    LogicalConnection(OraclePooledConnection oraclepooledconnection, PhysicalConnection physicalconnection, boolean flag)
        throws SQLException
    {
        closeCallback = null;
        privateData = null;
        startTime = 0L;
        connectionCacheCallback = null;
        connectionCacheCallbackUserObj = null;
        callbackFlag = 0;
        releasePriority = 0;
        heartbeatCount = 0;
        heartbeatLastCount = 0;
        heartbeatNoChangeCount = 0;
        isAbandonedTimeoutEnabled = false;
        internalConnection = physicalconnection;
        pooledConnection = oraclepooledconnection;
        connection = internalConnection;
        connection.setWrapper(this);
        closed = false;
        internalConnection.setAutoCommit(flag);
    }

    void registerHeartbeat()
        throws SQLException
    {
        if(isAbandonedTimeoutEnabled)
            try
            {
                heartbeatCount++;
            }
            catch(ArithmeticException arithmeticexception)
            {
                heartbeatCount = 0;
            }
    }

    public int getHeartbeatNoChangeCount()
        throws SQLException
    {
        if(heartbeatCount == heartbeatLastCount)
        {
            heartbeatNoChangeCount++;
        } else
        {
            heartbeatLastCount = heartbeatCount;
            heartbeatNoChangeCount = 0;
        }
        return heartbeatNoChangeCount;
    }

    public oracle.jdbc.internal.OracleConnection physicalConnectionWithin()
    {
        return internalConnection;
    }

    public synchronized void registerCloseCallback(OracleCloseCallback oracleclosecallback, Object obj)
    {
        closeCallback = oracleclosecallback;
        privateData = obj;
    }

    public Connection _getPC()
    {
        return internalConnection;
    }

    public synchronized boolean isLogicalConnection()
    {
        return true;
    }

    public oracle.jdbc.internal.OracleConnection getPhysicalConnection()
    {
        return internalConnection;
    }

    public Connection getLogicalConnection(OraclePooledConnection oraclepooledconnection, boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 153);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void getPropertyForPooledConnection(OraclePooledConnection oraclepooledconnection)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 153);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized void close()
        throws SQLException
    {
        closeInternal(true);
    }

    public void closeInternal(boolean flag)
        throws SQLException
    {
        if(closed)
            return;
        if(closeCallback != null)
            closeCallback.beforeClose(this, privateData);
        internalConnection.closeLogicalConnection();
        startTime = 0L;
        closed = true;
        if(pooledConnection != null && flag)
            pooledConnection.logicalClose();
        internalConnection = closedConnection;
        connection = closedConnection;
        if(closeCallback != null)
            closeCallback.afterClose(privateData);
    }

    public void cleanupAndClose(boolean flag)
        throws SQLException
    {
        if(closed)
            return;
        closed = true;
        PhysicalConnection physicalconnection = internalConnection;
        OraclePooledConnection oraclepooledconnection = pooledConnection;
        internalConnection = closedConnection;
        connection = closedConnection;
        startTime = 0L;
        if(closeCallback != null)
            closeCallback.beforeClose(this, privateData);
        physicalconnection.cleanupAndClose();
        physicalconnection.closeLogicalConnection();
        if(oraclepooledconnection != null && flag)
            oraclepooledconnection.logicalClose();
        if(closeCallback != null)
            closeCallback.afterClose(privateData);
    }

    public void abort()
        throws SQLException
    {
        if(closed)
        {
            return;
        } else
        {
            internalConnection.abort();
            closed = true;
            internalConnection = closedConnection;
            connection = closedConnection;
            return;
        }
    }

    public synchronized void close(Properties properties)
        throws SQLException
    {
        if(pooledConnection != null)
        {
            pooledConnection.cachedConnectionAttributes.clear();
            pooledConnection.cachedConnectionAttributes.putAll(properties);
        }
        close();
    }

    public synchronized void close(int i)
        throws SQLException
    {
        if((i & 0x1000) != 0)
        {
            if(pooledConnection != null)
                pooledConnection.closeOption = i;
            close();
            return;
        }
        if((i & 1) != 0)
            internalConnection.close(1);
    }

    public synchronized void applyConnectionAttributes(Properties properties)
        throws SQLException
    {
        if(pooledConnection != null)
            pooledConnection.cachedConnectionAttributes.putAll(properties);
    }

    public synchronized Properties getConnectionAttributes()
        throws SQLException
    {
        if(pooledConnection != null)
            return pooledConnection.cachedConnectionAttributes;
        else
            return null;
    }

    public synchronized Properties getUnMatchedConnectionAttributes()
        throws SQLException
    {
        if(pooledConnection != null)
            return pooledConnection.unMatchedCachedConnAttr;
        else
            return null;
    }

    public synchronized void setAbandonedTimeoutEnabled(boolean flag)
        throws SQLException
    {
        isAbandonedTimeoutEnabled = true;
    }

    public synchronized void registerConnectionCacheCallback(OracleConnectionCacheCallback oracleconnectioncachecallback, Object obj, int i)
        throws SQLException
    {
        connectionCacheCallback = oracleconnectioncachecallback;
        connectionCacheCallbackUserObj = obj;
        callbackFlag = i;
    }

    public OracleConnectionCacheCallback getConnectionCacheCallbackObj()
        throws SQLException
    {
        return connectionCacheCallback;
    }

    public Object getConnectionCacheCallbackPrivObj()
        throws SQLException
    {
        return connectionCacheCallbackUserObj;
    }

    public int getConnectionCacheCallbackFlag()
        throws SQLException
    {
        return callbackFlag;
    }

    public synchronized void setConnectionReleasePriority(int i)
        throws SQLException
    {
        releasePriority = i;
    }

    public int getConnectionReleasePriority()
        throws SQLException
    {
        return releasePriority;
    }

    public synchronized boolean isClosed()
        throws SQLException
    {
        return closed;
    }

    public void setStartTime(long l)
        throws SQLException
    {
        if(l <= 0L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            startTime = l;
            return;
        }
    }

    public long getStartTime()
        throws SQLException
    {
        return startTime;
    }

    public String getDatabaseTimeZone()
        throws SQLException
    {
        return internalConnection.getDatabaseTimeZone();
    }

    public Properties getServerSessionInfo()
        throws SQLException
    {
        return internalConnection.getServerSessionInfo();
    }

    public Object getClientData(Object obj)
    {
        return internalConnection.getClientData(obj);
    }

    public Object setClientData(Object obj, Object obj1)
    {
        return internalConnection.setClientData(obj, obj1);
    }

    public Object removeClientData(Object obj)
    {
        return internalConnection.removeClientData(obj);
    }

    public void setClientIdentifier(String s)
        throws SQLException
    {
        internalConnection.setClientIdentifier(s);
    }

    public void clearClientIdentifier(String s)
        throws SQLException
    {
        internalConnection.clearClientIdentifier(s);
    }

    public short getStructAttrNCsId()
        throws SQLException
    {
        return internalConnection.getStructAttrNCsId();
    }

    public Map getTypeMap()
        throws SQLException
    {
        return internalConnection.getTypeMap();
    }

    public Properties getDBAccessProperties()
        throws SQLException
    {
        return internalConnection.getDBAccessProperties();
    }

    public Properties getOCIHandles()
        throws SQLException
    {
        return internalConnection.getOCIHandles();
    }

    public String getDatabaseProductVersion()
        throws SQLException
    {
        return internalConnection.getDatabaseProductVersion();
    }

    public void cancel()
        throws SQLException
    {
        registerHeartbeat();
        internalConnection.cancel();
    }

    public String getURL()
        throws SQLException
    {
        return internalConnection.getURL();
    }

    public boolean getIncludeSynonyms()
    {
        return internalConnection.getIncludeSynonyms();
    }

    public boolean getRemarksReporting()
    {
        return internalConnection.getRemarksReporting();
    }

    public boolean getRestrictGetTables()
    {
        return internalConnection.getRestrictGetTables();
    }

    public short getVersionNumber()
        throws SQLException
    {
        return internalConnection.getVersionNumber();
    }

    public Map getJavaObjectTypeMap()
    {
        return internalConnection.getJavaObjectTypeMap();
    }

    public void setJavaObjectTypeMap(Map map)
    {
        internalConnection.setJavaObjectTypeMap(map);
    }

    public BfileDBAccess createBfileDBAccess()
        throws SQLException
    {
        return internalConnection.createBfileDBAccess();
    }

    public BlobDBAccess createBlobDBAccess()
        throws SQLException
    {
        return internalConnection.createBlobDBAccess();
    }

    public ClobDBAccess createClobDBAccess()
        throws SQLException
    {
        return internalConnection.createClobDBAccess();
    }

    public void setDefaultFixedString(boolean flag)
    {
        internalConnection.setDefaultFixedString(flag);
    }

    public boolean getTimestamptzInGmt()
    {
        return internalConnection.getTimestamptzInGmt();
    }

    public boolean getUse1900AsYearForTime()
    {
        return internalConnection.getUse1900AsYearForTime();
    }

    public boolean getDefaultFixedString()
    {
        return internalConnection.getDefaultFixedString();
    }

    public OracleConnection getWrapper()
    {
        return this;
    }

    public Class classForNameAndSchema(String s, String s1)
        throws ClassNotFoundException
    {
        return internalConnection.classForNameAndSchema(s, s1);
    }

    public void setFDO(byte abyte0[])
        throws SQLException
    {
        internalConnection.setFDO(abyte0);
    }

    public byte[] getFDO(boolean flag)
        throws SQLException
    {
        return internalConnection.getFDO(flag);
    }

    public boolean getBigEndian()
        throws SQLException
    {
        return internalConnection.getBigEndian();
    }

    public Object getDescriptor(byte abyte0[])
    {
        return internalConnection.getDescriptor(abyte0);
    }

    public void putDescriptor(byte abyte0[], Object obj)
        throws SQLException
    {
        internalConnection.putDescriptor(abyte0, obj);
    }

    public void removeDescriptor(String s)
    {
        internalConnection.removeDescriptor(s);
    }

    public void removeAllDescriptor()
    {
        internalConnection.removeAllDescriptor();
    }

    public int numberOfDescriptorCacheEntries()
    {
        return internalConnection.numberOfDescriptorCacheEntries();
    }

    public Enumeration descriptorCacheKeys()
    {
        return internalConnection.descriptorCacheKeys();
    }

    public void getOracleTypeADT(OracleTypeADT oracletypeadt)
        throws SQLException
    {
        internalConnection.getOracleTypeADT(oracletypeadt);
    }

    public short getDbCsId()
        throws SQLException
    {
        return internalConnection.getDbCsId();
    }

    public short getJdbcCsId()
        throws SQLException
    {
        return internalConnection.getJdbcCsId();
    }

    public short getNCharSet()
    {
        return internalConnection.getNCharSet();
    }

    public ResultSet newArrayDataResultSet(Datum adatum[], long l, int i, Map map)
        throws SQLException
    {
        return internalConnection.newArrayDataResultSet(adatum, l, i, map);
    }

    public ResultSet newArrayDataResultSet(ARRAY array, long l, int i, Map map)
        throws SQLException
    {
        return internalConnection.newArrayDataResultSet(array, l, i, map);
    }

    public ResultSet newArrayLocatorResultSet(ArrayDescriptor arraydescriptor, byte abyte0[], long l, int i, Map map)
        throws SQLException
    {
        return internalConnection.newArrayLocatorResultSet(arraydescriptor, abyte0, l, i, map);
    }

    public ResultSetMetaData newStructMetaData(StructDescriptor structdescriptor)
        throws SQLException
    {
        return internalConnection.newStructMetaData(structdescriptor);
    }

    public void getForm(OracleTypeADT oracletypeadt, OracleTypeCLOB oracletypeclob, int i)
        throws SQLException
    {
        internalConnection.getForm(oracletypeadt, oracletypeclob, i);
    }

    public int CHARBytesToJavaChars(byte abyte0[], int i, char ac[])
        throws SQLException
    {
        return internalConnection.CHARBytesToJavaChars(abyte0, i, ac);
    }

    public int NCHARBytesToJavaChars(byte abyte0[], int i, char ac[])
        throws SQLException
    {
        return internalConnection.NCHARBytesToJavaChars(abyte0, i, ac);
    }

    public boolean IsNCharFixedWith()
    {
        return internalConnection.IsNCharFixedWith();
    }

    public short getDriverCharSet()
    {
        return internalConnection.getDriverCharSet();
    }

    public int getC2SNlsRatio()
    {
        return internalConnection.getC2SNlsRatio();
    }

    public int getMaxCharSize()
        throws SQLException
    {
        return internalConnection.getMaxCharSize();
    }

    public int getMaxCharbyteSize()
    {
        return internalConnection.getMaxCharbyteSize();
    }

    public int getMaxNCharbyteSize()
    {
        return internalConnection.getMaxNCharbyteSize();
    }

    public boolean isCharSetMultibyte(short word0)
    {
        return internalConnection.isCharSetMultibyte(word0);
    }

    public int javaCharsToCHARBytes(char ac[], int i, byte abyte0[])
        throws SQLException
    {
        return internalConnection.javaCharsToCHARBytes(ac, i, abyte0);
    }

    public int javaCharsToNCHARBytes(char ac[], int i, byte abyte0[])
        throws SQLException
    {
        return internalConnection.javaCharsToNCHARBytes(ac, i, abyte0);
    }

    public int getStmtCacheSize()
    {
        return internalConnection.getStmtCacheSize();
    }

    public int getStatementCacheSize()
        throws SQLException
    {
        return internalConnection.getStatementCacheSize();
    }

    public boolean getImplicitCachingEnabled()
        throws SQLException
    {
        return internalConnection.getImplicitCachingEnabled();
    }

    public boolean getExplicitCachingEnabled()
        throws SQLException
    {
        return internalConnection.getExplicitCachingEnabled();
    }

    public void purgeImplicitCache()
        throws SQLException
    {
        internalConnection.purgeImplicitCache();
    }

    public void purgeExplicitCache()
        throws SQLException
    {
        internalConnection.purgeExplicitCache();
    }

    public PreparedStatement getStatementWithKey(String s)
        throws SQLException
    {
        return internalConnection.getStatementWithKey(s);
    }

    public CallableStatement getCallWithKey(String s)
        throws SQLException
    {
        return internalConnection.getCallWithKey(s);
    }

    public boolean isStatementCacheInitialized()
    {
        return internalConnection.isStatementCacheInitialized();
    }

    public void setTypeMap(Map map)
    {
        internalConnection.setTypeMap(map);
    }

    public String getProtocolType()
    {
        return internalConnection.getProtocolType();
    }

    public void setTxnMode(int i)
    {
        internalConnection.setTxnMode(i);
    }

    public int getTxnMode()
    {
        return internalConnection.getTxnMode();
    }

    public int getHeapAllocSize()
        throws SQLException
    {
        return internalConnection.getHeapAllocSize();
    }

    public int getOCIEnvHeapAllocSize()
        throws SQLException
    {
        return internalConnection.getOCIEnvHeapAllocSize();
    }

    public CLOB createClob(byte abyte0[])
        throws SQLException
    {
        registerHeartbeat();
        return internalConnection.createClob(abyte0);
    }

    public CLOB createClobWithUnpickledBytes(byte abyte0[])
        throws SQLException
    {
        registerHeartbeat();
        return internalConnection.createClobWithUnpickledBytes(abyte0);
    }

    public CLOB createClob(byte abyte0[], short word0)
        throws SQLException
    {
        registerHeartbeat();
        return internalConnection.createClob(abyte0, word0);
    }

    public BLOB createBlob(byte abyte0[])
        throws SQLException
    {
        registerHeartbeat();
        return internalConnection.createBlob(abyte0);
    }

    public BLOB createBlobWithUnpickledBytes(byte abyte0[])
        throws SQLException
    {
        registerHeartbeat();
        return internalConnection.createBlobWithUnpickledBytes(abyte0);
    }

    public BFILE createBfile(byte abyte0[])
        throws SQLException
    {
        registerHeartbeat();
        return internalConnection.createBfile(abyte0);
    }

    public boolean isDescriptorSharable(oracle.jdbc.internal.OracleConnection oracleconnection)
        throws SQLException
    {
        return internalConnection.isDescriptorSharable(oracleconnection);
    }

    public OracleStatement refCursorCursorToStatement(int i)
        throws SQLException
    {
        return internalConnection.refCursorCursorToStatement(i);
    }

    public long getTdoCState(String s, String s1)
        throws SQLException
    {
        return internalConnection.getTdoCState(s, s1);
    }

    public Datum toDatum(CustomDatum customdatum)
        throws SQLException
    {
        return internalConnection.toDatum(customdatum);
    }

    public XAResource getXAResource()
        throws SQLException
    {
        return pooledConnection.getXAResource();
    }

    public void setApplicationContext(String s, String s1, String s2)
        throws SQLException
    {
        internalConnection.setApplicationContext(s, s1, s2);
    }

    public void clearAllApplicationContext(String s)
        throws SQLException
    {
        internalConnection.clearAllApplicationContext(s);
    }

    /**
     * @deprecated Method isV8Compatible is deprecated
     */

    public boolean isV8Compatible()
        throws SQLException
    {
        return getMapDateToTimestamp();
    }

    public boolean getMapDateToTimestamp()
    {
        return internalConnection.getMapDateToTimestamp();
    }

    public byte[] createLightweightSession(String s, KeywordValueLong akeywordvaluelong[], int i, KeywordValueLong akeywordvaluelong1[][], int ai[])
        throws SQLException
    {
        return internalConnection.createLightweightSession(s, akeywordvaluelong, i, akeywordvaluelong1, ai);
    }

    public void executeLightweightSessionRoundtrip(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j, KeywordValueLong akeywordvaluelong1[][], int ai[])
        throws SQLException
    {
        internalConnection.executeLightweightSessionRoundtrip(i, abyte0, akeywordvaluelong, j, akeywordvaluelong1, ai);
    }

    public void executeLightweightSessionPiggyback(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j)
        throws SQLException
    {
        internalConnection.executeLightweightSessionPiggyback(i, abyte0, akeywordvaluelong, j);
    }

    public void doXSNamespaceOp(oracle.jdbc.internal.OracleConnection.XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[], XSNamespace axsnamespace1[][])
        throws SQLException
    {
        internalConnection.doXSNamespaceOp(xsoperationcode, abyte0, axsnamespace, axsnamespace1);
    }

    public void doXSNamespaceOp(oracle.jdbc.internal.OracleConnection.XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[])
        throws SQLException
    {
        internalConnection.doXSNamespaceOp(xsoperationcode, abyte0, axsnamespace);
    }

    public BLOB createTemporaryBlob(Connection connection, boolean flag, int i)
        throws SQLException
    {
        registerHeartbeat();
        return internalConnection.createTemporaryBlob(connection, flag, i);
    }

    public CLOB createTemporaryClob(Connection connection, boolean flag, int i, short word0)
        throws SQLException
    {
        registerHeartbeat();
        return internalConnection.createTemporaryClob(connection, flag, i, word0);
    }

    public String getDefaultSchemaNameForNamedTypes()
        throws SQLException
    {
        return internalConnection.getDefaultSchemaNameForNamedTypes();
    }

    public boolean isUsable()
    {
        return !closed && internalConnection.isUsable();
    }

    public byte getInstanceProperty(oracle.jdbc.internal.OracleConnection.InstanceProperty instanceproperty)
        throws SQLException
    {
        return internalConnection.getInstanceProperty(instanceproperty);
    }

    public void setUsable(boolean flag)
    {
        internalConnection.setUsable(flag);
    }

    public int getTimezoneVersionNumber()
        throws SQLException
    {
        return internalConnection.getTimezoneVersionNumber();
    }

    public TIMEZONETAB getTIMEZONETAB()
        throws SQLException
    {
        return internalConnection.getTIMEZONETAB();
    }

    public void addXSEventListener(XSEventListener xseventlistener)
        throws SQLException
    {
        internalConnection.addXSEventListener(xseventlistener);
    }

    public void addXSEventListener(XSEventListener xseventlistener, Executor executor)
        throws SQLException
    {
        internalConnection.addXSEventListener(xseventlistener, executor);
    }

    public void removeXSEventListener(XSEventListener xseventlistener)
        throws SQLException
    {
        internalConnection.removeXSEventListener(xseventlistener);
    }

    public oracle.jdbc.internal.OracleConnection.BufferCacheStatistics getByteBufferCacheStatistics()
    {
        return internalConnection.getByteBufferCacheStatistics();
    }

    public oracle.jdbc.internal.OracleConnection.BufferCacheStatistics getCharBufferCacheStatistics()
    {
        return internalConnection.getCharBufferCacheStatistics();
    }

    public boolean isDataInLocatorEnabled()
        throws SQLException
    {
        return internalConnection.isDataInLocatorEnabled();
    }

    public boolean isLobStreamPosStandardCompliant()
        throws SQLException
    {
        return internalConnection.isLobStreamPosStandardCompliant();
    }

    public long getCurrentSCN()
        throws SQLException
    {
        return internalConnection.getCurrentSCN();
    }

    public EnumSet getTransactionState()
        throws SQLException
    {
        return internalConnection.getTransactionState();
    }

    public boolean isConnectionSocketKeepAlive()
        throws SocketException, SQLException
    {
        return internalConnection.isConnectionSocketKeepAlive();
    }

}
