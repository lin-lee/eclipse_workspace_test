// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CVarcharAccessor.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.sql.*;
import java.text.DateFormatSymbols;
import java.util.*;
import oracle.jdbc.internal.OracleStatement;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            VarcharAccessor, T4CConnection, OracleStatement, T4CMAREngine, 
//            PhysicalConnection, T4CLongAccessor, CRC64, DBConversion, 
//            DatabaseError

class T4CVarcharAccessor extends VarcharAccessor
{

    T4CMAREngine mare;
    static final int t4MaxLength = 4000;
    static final int t4CallMaxLength = 4001;
    static final int t4PlsqlMaxLength = 32766;
    static final int t4SqlMinLength = 32;
    boolean underlyingLong;
    final int meta[];
    final int tmp[];
    final int escapeSequenceArr[];
    final boolean readHeaderArr[];
    final boolean readAsNonStreamArr[];
    static final int NONE = -1;
    static final int DAY = 1;
    static final int MM_MONTH = 2;
    static final int FULL_MONTH = 3;
    static final int MON_MONTH = 4;
    static final int YY_YEAR = 5;
    static final int RR_YEAR = 6;
    static final int HH_HOUR = 7;
    static final int HH24_HOUR = 8;
    static final int MINUTE = 9;
    static final int SECOND = 10;
    static final int NSECOND = 11;
    static final int AM = 12;
    static final int TZR = 13;
    static final int TZH = 14;
    static final int TZM = 15;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CVarcharAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, short word0, int j, boolean flag, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, word0, j, flag);
        underlyingLong = false;
        meta = new int[1];
        tmp = new int[1];
        escapeSequenceArr = new int[1];
        readHeaderArr = new boolean[1];
        readAsNonStreamArr = new boolean[1];
        mare = t4cmarengine;
        calculateSizeTmpByteArray();
    }

    T4CVarcharAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, int k1, int l1, int i2, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, flag, j, k, l, i1, j1, word0);
        underlyingLong = false;
        meta = new int[1];
        tmp = new int[1];
        escapeSequenceArr = new int[1];
        readHeaderArr = new boolean[1];
        readAsNonStreamArr = new boolean[1];
        mare = t4cmarengine;
        definedColumnType = l1;
        definedColumnSize = i2;
        calculateSizeTmpByteArray();
        oacmxl = k1;
        if(oacmxl == -1)
        {
            underlyingLong = true;
            oacmxl = 4000;
        }
    }

    void processIndicator(int i)
        throws IOException, SQLException
    {
        if(internalType == 1 && describeType == 112 || internalType == 23 && describeType == 113)
        {
            mare.unmarshalUB2();
            mare.unmarshalUB2();
        } else
        if(statement.connection.versionNumber < 9200)
        {
            mare.unmarshalSB2();
            if(!statement.sqlKind.isPlsqlOrCall())
                mare.unmarshalSB2();
        } else
        if(statement.sqlKind.isPlsqlOrCall() || isDMLReturnedParam)
            mare.processIndicator(i <= 0, i);
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        if(isUseLess)
        {
            lastRowProcessed++;
            return false;
        }
        int i = indicatorIndex + lastRowProcessed;
        int j = lengthIndex + lastRowProcessed;
        byte abyte0[] = statement.tmpByteArray;
        int k = columnIndex + lastRowProcessed * charLength;
        if(!underlyingLong)
        {
            if(rowSpaceIndicator == null)
            {
                byte abyte1[] = new byte[16000];
                mare.unmarshalCLR(abyte1, 0, meta);
                processIndicator(meta[0]);
                lastRowProcessed++;
                return false;
            }
            if(isNullByDescribe)
            {
                rowSpaceIndicator[i] = -1;
                rowSpaceIndicator[j] = 0;
                lastRowProcessed++;
                if(statement.connection.versionNumber < 9200)
                    processIndicator(0);
                return false;
            }
            if(statement.maxFieldSize > 0)
                mare.unmarshalCLR(abyte0, 0, meta, statement.maxFieldSize);
            else
                mare.unmarshalCLR(abyte0, 0, meta);
        } else
        {
            escapeSequenceArr[0] = mare.unmarshalUB1();
            if(mare.escapeSequenceNull(escapeSequenceArr[0]))
            {
                meta[0] = 0;
                mare.processIndicator(false, 0);
                int l = mare.unmarshalUB2();
            } else
            {
                int i1 = 0;
                int k1 = 0;
                byte abyte2[] = abyte0;
                boolean flag = false;
                readHeaderArr[0] = true;
                readAsNonStreamArr[0] = false;
                do
                {
                    if(i1 == -1)
                        break;
                    if(abyte2 == abyte0 && k1 + 255 > abyte0.length)
                        abyte2 = new byte[255];
                    int l1;
                    if(abyte2 == abyte0)
                        l1 = k1;
                    else
                        l1 = 0;
                    i1 = T4CLongAccessor.readStreamFromWire(abyte2, l1, 255, escapeSequenceArr, readHeaderArr, readAsNonStreamArr, mare, ((T4CConnection)statement.connection).oer);
                    if(statement.connection.calculateChecksum && i1 != -1)
                    {
                        CRC64 _tmp = PhysicalConnection.CHECKSUM;
                        long l2 = CRC64.updateChecksum(statement.checkSum, abyte2, l1, i1);
                        statement.checkSum = l2;
                    }
                    if(i1 != -1)
                        if(abyte2 == abyte0)
                            k1 += i1;
                        else
                        if(abyte0.length - k1 > 0)
                        {
                            int i2 = abyte0.length - k1;
                            System.arraycopy(abyte2, 0, abyte0, k1, i2);
                            k1 += i2;
                        }
                } while(true);
                if(abyte2 != abyte0)
                    abyte2 = null;
                meta[0] = k1;
            }
        }
        tmp[0] = meta[0];
        int j1 = 0;
        if(formOfUse == 2)
            j1 = statement.connection.conversion.NCHARBytesToJavaChars(abyte0, 0, rowSpaceChar, k + 1, tmp, charLength - 1);
        else
            j1 = statement.connection.conversion.CHARBytesToJavaChars(abyte0, 0, rowSpaceChar, k + 1, tmp, charLength - 1);
        rowSpaceChar[k] = (char)(j1 * 2);
        if(!underlyingLong)
            processIndicator(meta[0]);
        if(meta[0] == 0)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
        } else
        {
            rowSpaceIndicator[j] = (short)(meta[0] * 2);
            rowSpaceIndicator[i] = 0;
        }
        lastRowProcessed++;
        return false;
    }

    void copyRow()
        throws SQLException, IOException
    {
        int i;
        if(lastRowProcessed == 0)
            i = statement.rowPrefetchInLastFetch - 1;
        else
            i = lastRowProcessed - 1;
        int j = columnIndex + lastRowProcessed * charLength;
        int k = columnIndex + i * charLength;
        int l = indicatorIndex + lastRowProcessed;
        int i1 = indicatorIndex + i;
        int j1 = lengthIndex + lastRowProcessed;
        int k1 = lengthIndex + i;
        int l1 = rowSpaceIndicator[k1];
        int i2 = metaDataIndex + lastRowProcessed * 1;
        int j2 = metaDataIndex + i * 1;
        rowSpaceIndicator[j1] = (short)l1;
        rowSpaceIndicator[l] = rowSpaceIndicator[i1];
        if(!isNullByDescribe)
            System.arraycopy(rowSpaceChar, k, rowSpaceChar, j, rowSpaceChar[k] / 2 + 1);
        System.arraycopy(rowSpaceMetaData, j2, rowSpaceMetaData, i2, 1);
        lastRowProcessed++;
    }

    void saveDataFromOldDefineBuffers(byte abyte0[], char ac[], short aword0[], int i, int j)
        throws SQLException
    {
        int k = columnIndex + (j - 1) * charLength;
        int l = columnIndexLastRow + (i - 1) * charLength;
        int i1 = (indicatorIndex + j) - 1;
        int j1 = (indicatorIndexLastRow + i) - 1;
        int k1 = (lengthIndex + j) - 1;
        int l1 = (lengthIndexLastRow + i) - 1;
        int i2 = aword0[l1];
        rowSpaceIndicator[k1] = (short)i2;
        rowSpaceIndicator[i1] = aword0[j1];
        if(i2 != 0)
            System.arraycopy(ac, l, rowSpaceChar, k, ac[l] / 2 + 1);
        else
            rowSpaceChar[k] = '\0';
    }

    void calculateSizeTmpByteArray()
    {
        int i;
        if(formOfUse == 2)
            i = (charLength - 1) * statement.connection.conversion.maxNCharSize;
        else
            i = (charLength - 1) * statement.connection.conversion.cMaxCharSize;
        if(statement.sizeTmpByteArray < i)
            statement.sizeTmpByteArray = i;
    }

    String getString(int i)
        throws SQLException
    {
        String s = super.getString(i);
        if(s != null && definedColumnSize > 0 && s.length() > definedColumnSize)
            s = s.substring(0, definedColumnSize);
        return s;
    }

    NUMBER getNUMBER(int i)
        throws SQLException
    {
        NUMBER number = null;
        if(definedColumnType == 0)
        {
            number = super.getNUMBER(i);
        } else
        {
            String s = getString(i);
            if(s != null)
                return StringToNUMBER(s);
        }
        return number;
    }

    DATE getDATE(int i)
        throws SQLException
    {
        DATE date = null;
        if(definedColumnType == 0)
        {
            date = super.getDATE(i);
        } else
        {
            Date date1 = getDate(i);
            if(date1 != null)
                date = new DATE(date1);
        }
        return date;
    }

    TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        TIMESTAMP timestamp = null;
        if(definedColumnType == 0)
        {
            timestamp = super.getTIMESTAMP(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                Calendar calendar = DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), ai);
                Timestamp timestamp1 = new Timestamp(calendar.getTimeInMillis());
                timestamp1.setNanos(ai[0]);
                timestamp = new TIMESTAMP(timestamp1);
            }
        }
        return timestamp;
    }

    TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        TIMESTAMPTZ timestamptz = null;
        if(definedColumnType == 0)
        {
            timestamptz = super.getTIMESTAMPTZ(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                Calendar calendar = DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), ai);
                Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
                timestamp.setNanos(ai[0]);
                timestamptz = new TIMESTAMPTZ(statement.connection, timestamp, calendar);
            }
        }
        return timestamptz;
    }

    TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException
    {
        TIMESTAMPLTZ timestampltz = null;
        if(definedColumnType == 0)
        {
            timestampltz = super.getTIMESTAMPLTZ(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                Calendar calendar = DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), ai);
                Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
                timestamp.setNanos(ai[0]);
                timestampltz = new TIMESTAMPLTZ(statement.connection, timestamp, calendar);
            }
        }
        return timestampltz;
    }

    RAW getRAW(int i)
        throws SQLException
    {
        RAW raw = null;
        if(definedColumnType == 0)
        {
            raw = super.getRAW(i);
        } else
        {
            if(rowSpaceIndicator == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(rowSpaceIndicator[indicatorIndex + i] != -1)
                if(definedColumnType == -2 || definedColumnType == -3 || definedColumnType == -4)
                    raw = new RAW(getBytesFromHexChars(i));
                else
                    raw = new RAW(super.getBytes(i));
        }
        return raw;
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        if(definedColumnType == 0)
            return super.getOracleObject(i);
        Datum datum = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            switch(definedColumnType)
            {
            case -16: 
            case -15: 
            case -9: 
            case -1: 
            case 1: // '\001'
            case 12: // '\f'
                return super.getOracleObject(i);

            case -7: 
            case -6: 
            case -5: 
            case 2: // '\002'
            case 3: // '\003'
            case 4: // '\004'
            case 5: // '\005'
            case 6: // '\006'
            case 7: // '\007'
            case 8: // '\b'
            case 16: // '\020'
                return getNUMBER(i);

            case 91: // '['
                return getDATE(i);

            case 92: // '\\'
                return getDATE(i);

            case 93: // ']'
                return getTIMESTAMP(i);

            case -101: 
                return getTIMESTAMPTZ(i);

            case -102: 
                return getTIMESTAMPLTZ(i);

            case -4: 
            case -3: 
            case -2: 
                return getRAW(i);

            case -8: 
                return getROWID(i);
            }
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return datum;
        }
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        if(definedColumnType == 0)
            return super.getBytes(i);
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.shareBytes();
        else
            return null;
    }

    boolean getBoolean(int i)
        throws SQLException
    {
        boolean flag = false;
        if(definedColumnType == 0)
            flag = super.getBoolean(i);
        else
            flag = getNUMBER(i).booleanValue();
        return flag;
    }

    byte getByte(int i)
        throws SQLException
    {
        byte byte0 = 0;
        if(definedColumnType == 0)
        {
            byte0 = super.getByte(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                byte0 = number.byteValue();
        }
        return byte0;
    }

    int getInt(int i)
        throws SQLException
    {
        int j = 0;
        if(definedColumnType == 0)
        {
            j = super.getInt(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                j = number.intValue();
        }
        return j;
    }

    short getShort(int i)
        throws SQLException
    {
        short word0 = 0;
        if(definedColumnType == 0)
        {
            word0 = super.getShort(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                word0 = number.shortValue();
        }
        return word0;
    }

    long getLong(int i)
        throws SQLException
    {
        long l = 0L;
        if(definedColumnType == 0)
        {
            l = super.getLong(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                l = number.longValue();
        }
        return l;
    }

    float getFloat(int i)
        throws SQLException
    {
        float f = 0.0F;
        if(definedColumnType == 0)
        {
            f = super.getFloat(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                f = number.floatValue();
        }
        return f;
    }

    double getDouble(int i)
        throws SQLException
    {
        double d = 0.0D;
        if(definedColumnType == 0)
        {
            d = super.getDouble(i);
        } else
        {
            NUMBER number = getNUMBER(i);
            if(number != null)
                d = number.doubleValue();
        }
        return d;
    }

    Date getDate(int i)
        throws SQLException
    {
        Date date = null;
        if(definedColumnType == 0)
        {
            date = super.getDate(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                date = new Date(DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), ai).getTimeInMillis());
            }
        }
        return date;
    }

    Timestamp getTimestamp(int i)
        throws SQLException
    {
        Timestamp timestamp = null;
        if(definedColumnType == 0)
        {
            timestamp = super.getTimestamp(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                Calendar calendar = DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), ai);
                timestamp = new Timestamp(calendar.getTimeInMillis());
                timestamp.setNanos(ai[0]);
            }
        }
        return timestamp;
    }

    Time getTime(int i)
        throws SQLException
    {
        Time time = null;
        if(definedColumnType == 0)
        {
            time = super.getTime(i);
        } else
        {
            String s = getString(i);
            if(s != null)
            {
                int ai[] = new int[1];
                Calendar calendar = DATEStringToCalendar(s, (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), ai);
                time = new Time(calendar.getTimeInMillis());
            }
        }
        return time;
    }

    Object getObject(int i)
        throws SQLException
    {
        if(definedColumnType == 0)
            return super.getObject(i);
        Object obj = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            switch(definedColumnType)
            {
            case -16: 
            case -15: 
            case -9: 
            case -1: 
            case 1: // '\001'
            case 12: // '\f'
                return getString(i);

            case 2: // '\002'
            case 3: // '\003'
                return getBigDecimal(i);

            case 4: // '\004'
                return Integer.valueOf(getInt(i));

            case -6: 
                return Byte.valueOf(getByte(i));

            case 5: // '\005'
                return Short.valueOf(getShort(i));

            case -7: 
            case 16: // '\020'
                return Boolean.valueOf(getBoolean(i));

            case -5: 
                return Long.valueOf(getLong(i));

            case 7: // '\007'
                return Float.valueOf(getFloat(i));

            case 6: // '\006'
            case 8: // '\b'
                return Double.valueOf(getDouble(i));

            case 91: // '['
                return getDate(i);

            case 92: // '\\'
                return getTime(i);

            case 93: // ']'
                return getTimestamp(i);

            case -101: 
                return getTIMESTAMPTZ(i);

            case -102: 
                return getTIMESTAMPLTZ(i);

            case -4: 
            case -3: 
            case -2: 
                return getBytesFromHexChars(i);

            case -8: 
                return getROWID(i);
            }
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return obj;
        }
    }

    static final NUMBER StringToNUMBER(String s)
        throws SQLException
    {
        return new NUMBER(new BigDecimal(s));
    }

    static final Calendar DATEStringToCalendar(String s, String s1, int ai[])
        throws SQLException
    {
        char ac[] = (new StringBuilder()).append(s1).append(" ").toString().toCharArray();
        s = (new StringBuilder()).append(s).append(" ").toString();
        int i = Math.min(s.length(), ac.length);
        byte byte0 = -1;
        byte byte1 = -1;
        int j = 0;
        int k = 0;
        boolean flag = false;
        int i1 = 0;
        int j1 = 0;
        int k1 = 0;
        int l1 = 0;
        int i2 = 0;
        int j2 = 0;
        int k2 = 0;
        int l2 = 0;
        String s2 = null;
        String s3 = null;
        boolean flag1 = false;
        String as[] = null;
        String as1[] = null;
        for(int i3 = 0; i3 < i; i3++)
        {
            switch(ac[i3])
            {
            case 82: // 'R'
            case 114: // 'r'
                if(byte0 != 6)
                {
                    byte0 = 6;
                    j = i3;
                }
                break;

            case 89: // 'Y'
            case 121: // 'y'
                if(byte0 != 5)
                {
                    byte0 = 5;
                    j = i3;
                }
                break;

            case 68: // 'D'
            case 100: // 'd'
                if(byte0 != 1)
                {
                    byte0 = 1;
                    j = i3;
                }
                break;

            case 77: // 'M'
            case 109: // 'm'
                if(byte0 != 2 || byte0 != 4 || byte0 != 3 || byte0 != 9)
                {
                    j = i3;
                    if(i3 + 4 < i && (ac[i3 + 1] == 'O' || ac[i3 + 1] == 'o') && (ac[i3 + 2] == 'N' || ac[i3 + 2] == 'n') && (ac[i3 + 3] == 'T' || ac[i3 + 3] == 't') && (ac[i3 + 4] == 'H' || ac[i3 + 4] == 'h'))
                    {
                        byte0 = 3;
                        i3 += 4;
                    } else
                    if(i3 + 2 < i && (ac[i3 + 1] == 'O' || ac[i3 + 1] == 'o') && (ac[i3 + 2] == 'N' || ac[i3 + 2] == 'n'))
                    {
                        byte0 = 4;
                        i3 += 2;
                    } else
                    if(i3 + 1 < i && (ac[i3 + 1] == 'M' || ac[i3 + 1] == 'm'))
                    {
                        byte0 = 2;
                        i3++;
                    } else
                    if(i3 + 1 < i && (ac[i3 + 1] == 'I' || ac[i3 + 1] == 'i'))
                    {
                        byte0 = 9;
                        i3++;
                    }
                }
                break;

            case 72: // 'H'
            case 104: // 'h'
                if(byte0 != 7)
                {
                    byte0 = 7;
                    j = i3;
                } else
                if(i3 + 2 < i && (ac[i3 + 1] == '2' || ac[i3 + 4] == '4'))
                {
                    byte0 = 8;
                    i3 += 2;
                }
                break;

            case 83: // 'S'
            case 115: // 's'
                if(i3 + 1 < i && (ac[i3 + 1] == 'S' || ac[i3 + 1] == 's'))
                {
                    byte0 = 10;
                    j = i3;
                    i3++;
                }
                break;

            case 70: // 'F'
            case 102: // 'f'
                if(byte0 != 11)
                {
                    byte0 = 11;
                    j = i3;
                }
                break;

            case 65: // 'A'
            case 97: // 'a'
                if(i3 + 1 < i && (ac[i3 + 1] == 'M' || ac[i3 + 1] == 'm'))
                {
                    byte0 = 12;
                    j = i3;
                    i3++;
                }
                break;

            case 84: // 'T'
            case 116: // 't'
                if(i3 + 2 < i && (ac[i3 + 1] == 'Z' || ac[i3 + 1] == 'z') && (ac[i3 + 2] == 'R' || ac[i3 + 2] == 'r'))
                {
                    byte0 = 13;
                    j = i3;
                    i3 += 2;
                }
                break;

            case 66: // 'B'
            case 67: // 'C'
            case 69: // 'E'
            case 71: // 'G'
            case 73: // 'I'
            case 74: // 'J'
            case 75: // 'K'
            case 76: // 'L'
            case 78: // 'N'
            case 79: // 'O'
            case 80: // 'P'
            case 81: // 'Q'
            case 85: // 'U'
            case 86: // 'V'
            case 87: // 'W'
            case 88: // 'X'
            case 90: // 'Z'
            case 91: // '['
            case 92: // '\\'
            case 93: // ']'
            case 94: // '^'
            case 95: // '_'
            case 96: // '`'
            case 98: // 'b'
            case 99: // 'c'
            case 101: // 'e'
            case 103: // 'g'
            case 105: // 'i'
            case 106: // 'j'
            case 107: // 'k'
            case 108: // 'l'
            case 110: // 'n'
            case 111: // 'o'
            case 112: // 'p'
            case 113: // 'q'
            case 117: // 'u'
            case 118: // 'v'
            case 119: // 'w'
            case 120: // 'x'
            default:
                flag1 = true;
                break;
            }
            if(!flag1 || byte0 == -1)
                continue;
            int j3 = i3 - j;
            int k3 = j - k;
            int l = i1 + k3;
            i1 = l + j3;
            switch(byte0)
            {
            case 1: // '\001'
                j1 = Integer.parseInt(s.substring(l, i1));
                break;

            case 2: // '\002'
                k1 = Integer.parseInt(s.substring(l, i1));
                break;

            case 3: // '\003'
                int i4 = l;
                i1 = l;
                for(i4 = l; i4 < s.length() && s.charAt(i4) != ac[i3]; i4++);
                i1 = i4;
                String s5 = null;
                if(i1 == l)
                    break;
                s5 = s.substring(l, i1);
                s5 = s5.trim();
                if(as1 == null)
                    as1 = (new DateFormatSymbols()).getMonths();
                for(k1 = 0; k1 < as1.length && !s5.equalsIgnoreCase(as1[k1]); k1++);
                if(k1 >= 12)
                {
                    SQLException sqlexception1 = DatabaseError.createSqlException(null, 59);
                    sqlexception1.fillInStackTrace();
                    throw sqlexception1;
                }
                break;

            case 4: // '\004'
                int l3 = l;
                i1 = l;
                for(l3 = l; l3 < s.length() && s.charAt(l3) != ac[i3]; l3++);
                i1 = l3;
                String s4 = null;
                if(i1 == l)
                    break;
                s4 = s.substring(l, i1);
                s4 = s4.trim();
                if(as == null)
                    as = (new DateFormatSymbols()).getShortMonths();
                for(k1 = 0; k1 < as.length && !s4.equalsIgnoreCase(as[k1]); k1++);
                if(k1 >= 12)
                {
                    SQLException sqlexception = DatabaseError.createSqlException(null, 59);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                break;

            case 5: // '\005'
                l1 = Integer.parseInt(s.substring(l, i1));
                if(j3 == 2)
                    l1 += 2000;
                break;

            case 6: // '\006'
                l1 = Integer.parseInt(s.substring(l, i1));
                if(j3 == 2 && l1 < 50)
                    l1 += 2000;
                else
                    l1 += 1900;
                break;

            case 7: // '\007'
            case 8: // '\b'
                i1 = l + 2;
                i2 = Integer.parseInt(s.substring(l, i1));
                break;

            case 9: // '\t'
                j2 = Integer.parseInt(s.substring(l, i1));
                break;

            case 10: // '\n'
                k2 = Integer.parseInt(s.substring(l, i1));
                break;

            case 11: // '\013'
                int j4 = l;
                i1 = l;
                char c;
                for(j4 = l; j4 < s.length() && (c = s.charAt(j4)) >= '0' && c <= '9'; j4++);
                i1 += j4 - l;
                if(i1 != l)
                    l2 = Integer.parseInt(s.substring(l, i1));
                break;

            case 12: // '\f'
                if(i1 > 0)
                    s2 = s.substring(l, i1);
                break;

            case 13: // '\r'
                int k4 = l;
                i1 = l;
                char c1;
                for(int l4 = l; l4 < s.length() && ((c1 = s.charAt(l4)) >= '0' && c1 <= '9' || c1 >= 'a' && c1 <= 'z' || c1 >= 'A' && c1 <= 'Z'); l4++)
                    i1 = l4;

                if(i1 != l)
                    s3 = s.substring(l, i1);
                break;

            default:
                System.out.println("\n\n\n             ***** ERROR(1) ****\n");
                break;
            }
            k = i3;
            byte0 = -1;
            flag1 = false;
        }

        GregorianCalendar gregoriancalendar = new GregorianCalendar(l1, k1, j1, i2, j2, k2);
        if(s2 != null)
            gregoriancalendar.set(9, s2.equalsIgnoreCase("AM") ? 0 : 1);
        if(s3 == null);
        if(l2 != 0)
            ai[0] = l2;
        return gregoriancalendar;
    }

}
