// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConversionInputStream.java

package oracle.jdbc.driver;

import java.io.*;

// Referenced classes of package oracle.jdbc.driver:
//            OracleConversionInputStream, DBConversion

class OracleConversionInputStreamInternal extends OracleConversionInputStream
{

    boolean needReset;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleConversionInputStreamInternal(DBConversion dbconversion, InputStream inputstream, int i, int j)
    {
        super(dbconversion, inputstream, i, j);
        needReset = false;
    }

    public OracleConversionInputStreamInternal(DBConversion dbconversion, Reader reader, int i, int j, short word0)
    {
        super(dbconversion, reader, i, j, word0);
        needReset = false;
    }

    public int read(byte abyte0[], int i, int j)
        throws IOException
    {
        if(needReset)
            if(istream != null && istream.markSupported())
            {
                istream.reset();
                endOfStream = false;
                totalSize = 0;
                needReset = false;
            } else
            if(reader != null && reader.markSupported())
            {
                reader.reset();
                endOfStream = false;
                totalSize = 0;
                needReset = false;
            }
        int k = super.read(abyte0, i, j);
        if(k == -1)
            needReset = true;
        return k;
    }

}
