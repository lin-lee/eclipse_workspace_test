// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CSocketOutputStreamWrapper.java

package oracle.jdbc.driver;

import java.io.IOException;
import oracle.net.ns.*;

class T4CSocketOutputStreamWrapper extends NetOutputStream
{

    static final int MAX_BUFFER_SIZE = 2048;
    NetOutputStream os;
    byte buffer[];
    int bIndex;

    T4CSocketOutputStreamWrapper(NetOutputStream netoutputstream)
        throws IOException
    {
        os = null;
        buffer = new byte[2048];
        bIndex = 0;
        os = netoutputstream;
    }

    public void write(int i)
        throws IOException
    {
        if(bIndex + 1 >= 2048)
            flush();
        buffer[bIndex++] = (byte)(i & 0xff);
    }

    public void write(byte abyte0[], int i, int j)
        throws IOException
    {
        if(j > 2048)
        {
            flush();
            os.write(abyte0, i, j);
        } else
        if(bIndex + j < 2048)
        {
            System.arraycopy(abyte0, i, buffer, bIndex, j);
            bIndex += j;
        } else
        {
            flush();
            System.arraycopy(abyte0, i, buffer, bIndex, j);
            bIndex += j;
        }
    }

    public void flush()
        throws IOException
    {
        flush(false);
    }

    public void flush(boolean flag)
        throws IOException
    {
        if(bIndex > 0)
        {
            os.write(buffer, 0, bIndex);
            bIndex = 0;
        }
        if(flag)
            os.flush();
    }

    public void close()
        throws IOException
    {
        os.close();
        super.close();
    }

    public void writeZeroCopyIO(byte abyte0[], int i, int j)
        throws IOException, NetException, BreakNetException
    {
        flush(true);
        os.writeZeroCopyIO(abyte0, i, j);
    }
}
