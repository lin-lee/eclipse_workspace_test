// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFAQRegistration.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.Executor;
import oracle.jdbc.aq.AQNotificationListener;
import oracle.jdbc.aq.AQNotificationRegistration;

// Referenced classes of package oracle.jdbc.driver:
//            NTFRegistration, NTFEventListener

class NTFAQRegistration extends NTFRegistration
    implements AQNotificationRegistration
{

    private final String name;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFAQRegistration(int i, boolean flag, String s, String s1, String s2, int j, Properties properties, 
            String s3, short word0)
    {
        super(i, 1, flag, s, s2, j, properties, s1, word0);
        name = s3;
    }

    public void addListener(AQNotificationListener aqnotificationlistener, Executor executor)
        throws SQLException
    {
        NTFEventListener ntfeventlistener = new NTFEventListener(aqnotificationlistener);
        ntfeventlistener.setExecutor(executor);
        addListener(ntfeventlistener);
    }

    public void addListener(AQNotificationListener aqnotificationlistener)
        throws SQLException
    {
        NTFEventListener ntfeventlistener = new NTFEventListener(aqnotificationlistener);
        addListener(ntfeventlistener);
    }

    public void removeListener(AQNotificationListener aqnotificationlistener)
        throws SQLException
    {
        super.removeListener(aqnotificationlistener);
    }

    public String getQueueName()
    {
        return name;
    }

}
