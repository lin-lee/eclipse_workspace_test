// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CXAConnection.java

package oracle.jdbc.driver;

import java.sql.Connection;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import oracle.jdbc.xa.OracleXAResource;
import oracle.jdbc.xa.client.OracleXAConnection;

// Referenced classes of package oracle.jdbc.driver:
//            T4CConnection, T4CXAResource, T4CTTIOtxen, T4CTTIOtxse

public class T4CXAConnection extends OracleXAConnection
{

    T4CTTIOtxen otxen;
    T4CTTIOtxse otxse;
    T4CConnection physicalConnection;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public T4CXAConnection(Connection connection)
        throws XAException
    {
        super(connection);
        physicalConnection = (T4CConnection)connection;
        xaResource = null;
    }

    public synchronized XAResource getXAResource()
    {
        try
        {
            if(xaResource == null)
            {
                xaResource = new T4CXAResource(physicalConnection, this, isXAResourceTransLoose);
                if(logicalHandle != null)
                    ((OracleXAResource)xaResource).setLogicalConnection(logicalHandle);
            }
        }
        catch(Exception exception)
        {
            xaResource = null;
        }
        return xaResource;
    }

}
