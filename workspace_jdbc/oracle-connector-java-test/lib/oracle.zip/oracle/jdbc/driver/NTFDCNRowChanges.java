// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFDCNRowChanges.java

package oracle.jdbc.driver;

import oracle.jdbc.dcn.RowChangeDescription;
import oracle.sql.ROWID;

class NTFDCNRowChanges
    implements RowChangeDescription
{

    oracle.jdbc.dcn.RowChangeDescription.RowOperation opcode;
    int rowidLength;
    byte rowid[];
    ROWID rowidObj;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFDCNRowChanges(oracle.jdbc.dcn.RowChangeDescription.RowOperation rowoperation, int i, byte abyte0[])
    {
        opcode = rowoperation;
        rowidLength = i;
        rowid = abyte0;
        rowidObj = null;
    }

    public ROWID getRowid()
    {
        if(rowidObj == null)
            rowidObj = new ROWID(rowid);
        return rowidObj;
    }

    public oracle.jdbc.dcn.RowChangeDescription.RowOperation getRowOperation()
    {
        return opcode;
    }

    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append((new StringBuilder()).append("      ROW:  operation=").append(getRowOperation()).append(", ROWID=").append(new String(rowid)).append("\n").toString());
        return stringbuffer.toString();
    }

}
