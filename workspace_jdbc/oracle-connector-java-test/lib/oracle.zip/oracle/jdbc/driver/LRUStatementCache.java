// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   LRUStatementCache.java

package oracle.jdbc.driver;

import java.io.PrintStream;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            OracleStatementCacheEntry, DatabaseError, OraclePreparedStatement, OracleStatement

class LRUStatementCache
{

    private int cacheSize;
    private int numElements;
    private OracleStatementCacheEntry applicationCacheStart;
    private OracleStatementCacheEntry applicationCacheEnd;
    private OracleStatementCacheEntry implicitCacheStart;
    private OracleStatementCacheEntry explicitCacheStart;
    boolean implicitCacheEnabled;
    boolean explicitCacheEnabled;
    private boolean debug;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected LRUStatementCache(int i)
        throws SQLException
    {
        debug = false;
        if(i < 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 123);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            cacheSize = i;
            numElements = 0;
            implicitCacheStart = null;
            explicitCacheStart = null;
            implicitCacheEnabled = false;
            explicitCacheEnabled = false;
            return;
        }
    }

    protected void resize(int i)
        throws SQLException
    {
        if(i < 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 123);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i >= cacheSize || i >= numElements)
        {
            cacheSize = i;
        } else
        {
            for(OracleStatementCacheEntry oraclestatementcacheentry = applicationCacheEnd; numElements > i; oraclestatementcacheentry = oraclestatementcacheentry.applicationPrev)
                purgeCacheEntry(oraclestatementcacheentry);

            cacheSize = i;
        }
    }

    public void setImplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        if(!flag)
            purgeImplicitCache();
        implicitCacheEnabled = flag;
    }

    public boolean getImplicitCachingEnabled()
        throws SQLException
    {
        boolean flag;
        if(cacheSize == 0)
            flag = false;
        else
            flag = implicitCacheEnabled;
        return flag;
    }

    public void setExplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        if(!flag)
            purgeExplicitCache();
        explicitCacheEnabled = flag;
    }

    public boolean getExplicitCachingEnabled()
        throws SQLException
    {
        boolean flag;
        if(cacheSize == 0)
            flag = false;
        else
            flag = explicitCacheEnabled;
        return flag;
    }

    protected void addToImplicitCache(OraclePreparedStatement oraclepreparedstatement, String s, int i, int j)
        throws SQLException
    {
        if(!implicitCacheEnabled || cacheSize == 0 || oraclepreparedstatement.cacheState == 2)
            return;
        if(numElements == cacheSize)
            purgeCacheEntry(applicationCacheEnd);
        oraclepreparedstatement.enterImplicitCache();
        OracleStatementCacheEntry oraclestatementcacheentry = new OracleStatementCacheEntry();
        oraclestatementcacheentry.statement = oraclepreparedstatement;
        oraclestatementcacheentry.onImplicit = true;
        oraclestatementcacheentry.sql = s;
        oraclestatementcacheentry.statementType = i;
        oraclestatementcacheentry.scrollType = j;
        oraclestatementcacheentry.applicationNext = applicationCacheStart;
        oraclestatementcacheentry.applicationPrev = null;
        if(applicationCacheStart != null)
            applicationCacheStart.applicationPrev = oraclestatementcacheentry;
        applicationCacheStart = oraclestatementcacheentry;
        oraclestatementcacheentry.implicitNext = implicitCacheStart;
        oraclestatementcacheentry.implicitPrev = null;
        if(implicitCacheStart != null)
            implicitCacheStart.implicitPrev = oraclestatementcacheentry;
        implicitCacheStart = oraclestatementcacheentry;
        if(applicationCacheEnd == null)
            applicationCacheEnd = oraclestatementcacheentry;
        numElements++;
    }

    protected void addToExplicitCache(OraclePreparedStatement oraclepreparedstatement, String s)
        throws SQLException
    {
        if(!explicitCacheEnabled || cacheSize == 0 || oraclepreparedstatement.cacheState == 2)
            return;
        if(numElements == cacheSize)
            purgeCacheEntry(applicationCacheEnd);
        oraclepreparedstatement.enterExplicitCache();
        OracleStatementCacheEntry oraclestatementcacheentry = new OracleStatementCacheEntry();
        oraclestatementcacheentry.statement = oraclepreparedstatement;
        oraclestatementcacheentry.sql = s;
        oraclestatementcacheentry.onImplicit = false;
        oraclestatementcacheentry.applicationNext = applicationCacheStart;
        oraclestatementcacheentry.applicationPrev = null;
        if(applicationCacheStart != null)
            applicationCacheStart.applicationPrev = oraclestatementcacheentry;
        applicationCacheStart = oraclestatementcacheentry;
        oraclestatementcacheentry.explicitNext = explicitCacheStart;
        oraclestatementcacheentry.explicitPrev = null;
        if(explicitCacheStart != null)
            explicitCacheStart.explicitPrev = oraclestatementcacheentry;
        explicitCacheStart = oraclestatementcacheentry;
        if(applicationCacheEnd == null)
            applicationCacheEnd = oraclestatementcacheentry;
        numElements++;
    }

    protected OracleStatement searchImplicitCache(String s, int i, int j)
        throws SQLException
    {
        if(!implicitCacheEnabled)
            return null;
        OracleStatementCacheEntry oraclestatementcacheentry = null;
        for(oraclestatementcacheentry = implicitCacheStart; oraclestatementcacheentry != null && (oraclestatementcacheentry.statementType != i || oraclestatementcacheentry.scrollType != j || !oraclestatementcacheentry.sql.equals(s)); oraclestatementcacheentry = oraclestatementcacheentry.implicitNext);
        if(oraclestatementcacheentry != null)
        {
            if(oraclestatementcacheentry.applicationPrev != null)
                oraclestatementcacheentry.applicationPrev.applicationNext = oraclestatementcacheentry.applicationNext;
            if(oraclestatementcacheentry.applicationNext != null)
                oraclestatementcacheentry.applicationNext.applicationPrev = oraclestatementcacheentry.applicationPrev;
            if(applicationCacheStart == oraclestatementcacheentry)
                applicationCacheStart = oraclestatementcacheentry.applicationNext;
            if(applicationCacheEnd == oraclestatementcacheentry)
                applicationCacheEnd = oraclestatementcacheentry.applicationPrev;
            if(oraclestatementcacheentry.implicitPrev != null)
                oraclestatementcacheentry.implicitPrev.implicitNext = oraclestatementcacheentry.implicitNext;
            if(oraclestatementcacheentry.implicitNext != null)
                oraclestatementcacheentry.implicitNext.implicitPrev = oraclestatementcacheentry.implicitPrev;
            if(implicitCacheStart == oraclestatementcacheentry)
                implicitCacheStart = oraclestatementcacheentry.implicitNext;
            numElements--;
            oraclestatementcacheentry.statement.exitImplicitCacheToActive();
            return oraclestatementcacheentry.statement;
        } else
        {
            return null;
        }
    }

    protected OracleStatement searchExplicitCache(String s)
        throws SQLException
    {
        if(!explicitCacheEnabled)
            return null;
        OracleStatementCacheEntry oraclestatementcacheentry = null;
        for(oraclestatementcacheentry = explicitCacheStart; oraclestatementcacheentry != null && !oraclestatementcacheentry.sql.equals(s); oraclestatementcacheentry = oraclestatementcacheentry.explicitNext);
        if(oraclestatementcacheentry != null)
        {
            if(oraclestatementcacheentry.applicationPrev != null)
                oraclestatementcacheentry.applicationPrev.applicationNext = oraclestatementcacheentry.applicationNext;
            if(oraclestatementcacheentry.applicationNext != null)
                oraclestatementcacheentry.applicationNext.applicationPrev = oraclestatementcacheentry.applicationPrev;
            if(applicationCacheStart == oraclestatementcacheentry)
                applicationCacheStart = oraclestatementcacheentry.applicationNext;
            if(applicationCacheEnd == oraclestatementcacheentry)
                applicationCacheEnd = oraclestatementcacheentry.applicationPrev;
            if(oraclestatementcacheentry.explicitPrev != null)
                oraclestatementcacheentry.explicitPrev.explicitNext = oraclestatementcacheentry.explicitNext;
            if(oraclestatementcacheentry.explicitNext != null)
                oraclestatementcacheentry.explicitNext.explicitPrev = oraclestatementcacheentry.explicitPrev;
            if(explicitCacheStart == oraclestatementcacheentry)
                explicitCacheStart = oraclestatementcacheentry.explicitNext;
            numElements--;
            oraclestatementcacheentry.statement.exitExplicitCacheToActive();
            return oraclestatementcacheentry.statement;
        } else
        {
            return null;
        }
    }

    protected void purgeImplicitCache()
        throws SQLException
    {
        for(OracleStatementCacheEntry oraclestatementcacheentry = implicitCacheStart; oraclestatementcacheentry != null; oraclestatementcacheentry = oraclestatementcacheentry.implicitNext)
            purgeCacheEntry(oraclestatementcacheentry);

        implicitCacheStart = null;
    }

    protected void purgeExplicitCache()
        throws SQLException
    {
        for(OracleStatementCacheEntry oraclestatementcacheentry = explicitCacheStart; oraclestatementcacheentry != null; oraclestatementcacheentry = oraclestatementcacheentry.explicitNext)
            purgeCacheEntry(oraclestatementcacheentry);

        explicitCacheStart = null;
    }

    private void purgeCacheEntry(OracleStatementCacheEntry oraclestatementcacheentry)
        throws SQLException
    {
        if(oraclestatementcacheentry.applicationNext != null)
            oraclestatementcacheentry.applicationNext.applicationPrev = oraclestatementcacheentry.applicationPrev;
        if(oraclestatementcacheentry.applicationPrev != null)
            oraclestatementcacheentry.applicationPrev.applicationNext = oraclestatementcacheentry.applicationNext;
        if(applicationCacheStart == oraclestatementcacheentry)
            applicationCacheStart = oraclestatementcacheentry.applicationNext;
        if(applicationCacheEnd == oraclestatementcacheentry)
            applicationCacheEnd = oraclestatementcacheentry.applicationPrev;
        if(oraclestatementcacheentry.onImplicit)
        {
            if(oraclestatementcacheentry.implicitNext != null)
                oraclestatementcacheentry.implicitNext.implicitPrev = oraclestatementcacheentry.implicitPrev;
            if(oraclestatementcacheentry.implicitPrev != null)
                oraclestatementcacheentry.implicitPrev.implicitNext = oraclestatementcacheentry.implicitNext;
            if(implicitCacheStart == oraclestatementcacheentry)
                implicitCacheStart = oraclestatementcacheentry.implicitNext;
        } else
        {
            if(oraclestatementcacheentry.explicitNext != null)
                oraclestatementcacheentry.explicitNext.explicitPrev = oraclestatementcacheentry.explicitPrev;
            if(oraclestatementcacheentry.explicitPrev != null)
                oraclestatementcacheentry.explicitPrev.explicitNext = oraclestatementcacheentry.explicitNext;
            if(explicitCacheStart == oraclestatementcacheentry)
                explicitCacheStart = oraclestatementcacheentry.explicitNext;
        }
        numElements--;
        if(oraclestatementcacheentry.onImplicit)
            oraclestatementcacheentry.statement.exitImplicitCacheToClose();
        else
            oraclestatementcacheentry.statement.exitExplicitCacheToClose();
    }

    public int getCacheSize()
    {
        return cacheSize;
    }

    public void printCache(String s)
        throws SQLException
    {
        System.out.println((new StringBuilder()).append("*** Start of Statement Cache Dump (").append(s).append(") ***").toString());
        System.out.println((new StringBuilder()).append("cache size: ").append(cacheSize).append(" num elements: ").append(numElements).append(" implicit enabled: ").append(implicitCacheEnabled).append(" explicit enabled: ").append(explicitCacheEnabled).toString());
        System.out.println((new StringBuilder()).append("applicationStart: ").append(applicationCacheStart).append("  applicationEnd: ").append(applicationCacheEnd).toString());
        for(OracleStatementCacheEntry oraclestatementcacheentry = applicationCacheStart; oraclestatementcacheentry != null; oraclestatementcacheentry = oraclestatementcacheentry.applicationNext)
            oraclestatementcacheentry.print();

        System.out.println((new StringBuilder()).append("implicitStart: ").append(implicitCacheStart).toString());
        for(OracleStatementCacheEntry oraclestatementcacheentry1 = implicitCacheStart; oraclestatementcacheentry1 != null; oraclestatementcacheentry1 = oraclestatementcacheentry1.implicitNext)
            oraclestatementcacheentry1.print();

        System.out.println((new StringBuilder()).append("explicitStart: ").append(explicitCacheStart).toString());
        for(OracleStatementCacheEntry oraclestatementcacheentry2 = explicitCacheStart; oraclestatementcacheentry2 != null; oraclestatementcacheentry2 = oraclestatementcacheentry2.explicitNext)
            oraclestatementcacheentry2.print();

        System.out.println((new StringBuilder()).append("*** End of Statement Cache Dump (").append(s).append(") ***").toString());
    }

    public void close()
        throws SQLException
    {
        for(OracleStatementCacheEntry oraclestatementcacheentry = applicationCacheStart; oraclestatementcacheentry != null; oraclestatementcacheentry = oraclestatementcacheentry.applicationNext)
            if(oraclestatementcacheentry.onImplicit)
                oraclestatementcacheentry.statement.exitImplicitCacheToClose();
            else
                oraclestatementcacheentry.statement.exitExplicitCacheToClose();

        applicationCacheStart = null;
        applicationCacheEnd = null;
        implicitCacheStart = null;
        explicitCacheStart = null;
        numElements = 0;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
