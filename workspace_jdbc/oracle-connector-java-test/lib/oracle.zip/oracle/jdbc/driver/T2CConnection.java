// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T2CConnection.java

package oracle.jdbc.driver;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.CharBuffer;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.EnumSet;
import java.util.Enumeration;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.concurrent.Executor;
import javax.transaction.xa.XAResource;
import oracle.jdbc.OracleOCIFailover;
import oracle.jdbc.OracleSavepoint;
import oracle.jdbc.aq.AQDequeueOptions;
import oracle.jdbc.aq.AQEnqueueOptions;
import oracle.jdbc.aq.AQMessage;
import oracle.jdbc.aq.AQNotificationRegistration;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleStatement;
import oracle.jdbc.internal.XSEventListener;
import oracle.jdbc.internal.XSNamespace;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.oracore.OracleTypeCLOB;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import oracle.jdbc.pool.OracleOCIConnectionPool;
import oracle.jdbc.pool.OraclePooledConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.BFILE;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BLOB;
import oracle.sql.BfileDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.sql.CLOB;
import oracle.sql.ClobDBAccess;
import oracle.sql.CustomDatum;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.LobPlsqlUtil;
import oracle.sql.NCLOB;
import oracle.sql.NUMBER;
import oracle.sql.SQLName;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMEZONETAB;
import oracle.sql.TypeDescriptor;
import oracle.sql.ZONEIDMAP;
import oracle.sql.converter.CharacterSetMetaData;

// Referenced classes of package oracle.jdbc.driver:
//            PhysicalConnection, DBConversion, T2CError, T2CStatement, 
//            OracleBlobInputStream, OracleConversionInputStream, OracleConversionReader, OracleBlobOutputStream, 
//            OracleClobInputStream, OracleClobOutputStream, OracleClobReader, OracleClobWriter, 
//            AutoKeyInfo, DatabaseError, ClassRef, OracleStatement, 
//            OracleSql, OracleDriverExtension, OracleCloseCallback, OraclePreparedStatement

public class T2CConnection extends PhysicalConnection
    implements BfileDBAccess, BlobDBAccess, ClobDBAccess
{

    static final long JDBC_OCI_LIBRARY_VERSION = Long.parseLong("11.2.0.4.0".replaceAll("\\.", ""));
    short queryMetaData1[];
    byte queryMetaData2[];
    int queryMetaData1Offset;
    int queryMetaData2Offset;
    private String password;
    int fatalErrorNumber;
    String fatalErrorMessage;
    static final int QMD_dbtype = 0;
    static final int QMD_dbsize = 1;
    static final int QMD_nullok = 2;
    static final int QMD_precision = 3;
    static final int QMD_scale = 4;
    static final int QMD_formOfUse = 5;
    static final int QMD_columnNameLength = 6;
    static final int QMD_tdo0 = 7;
    static final int QMD_tdo1 = 8;
    static final int QMD_tdo2 = 9;
    static final int QMD_tdo3 = 10;
    static final int QMD_charLength = 11;
    static final int QMD_typeNameLength = 12;
    static final int T2C_LOCATOR_MAX_LEN = 16;
    static final int T2C_LINEARIZED_LOCATOR_MAX_LEN = 4000;
    static final int T2C_LINEARIZED_BFILE_LOCATOR_MAX_LEN = 530;
    static final int METADATA1_INDICES_PER_COLUMN = 13;
    protected static final int SIZEOF_QUERYMETADATA2 = 8;
    static final String defaultDriverNameAttribute = "jdbcoci";
    int queryMetaData1Size;
    int queryMetaData2Size;
    long m_nativeState;
    short m_clientCharacterSet;
    byte byteAlign;
    private static final int EOJ_SUCCESS = 0;
    private static final int EOJ_ERROR = -1;
    private static final int EOJ_WARNING = 1;
    private static final int EOJ_GET_STORAGE_ERROR = -4;
    private static final int EOJ_ORA3113_SERVER_NORMAL = -6;
    private static final String OCILIBRARY = "ocijdbc11";
    private int logon_mode;
    static final int LOGON_MODE_DEFAULT = 0;
    static final int LOGON_MODE_SYSDBA = 2;
    static final int LOGON_MODE_SYSOPER = 4;
    static final int LOGON_MODE_SYSASM = 32768;
    static final int LOGON_MODE_SYSBKP = 0x20000;
    static final int LOGON_MODE_SYSDGD = 0x40000;
    static final int LOGON_MODE_SYSKMT = 0x80000;
    static final int LOGON_MODE_CONNECTION_POOL = 5;
    static final int LOGON_MODE_CONNPOOL_CONNECTION = 6;
    static final int LOGON_MODE_CONNPOOL_PROXY_CONNECTION = 7;
    static final int LOGON_MODE_CONNPOOL_ALIASED_CONNECTION = 8;
    static final int T2C_PROXYTYPE_NONE = 0;
    static final int T2C_PROXYTYPE_USER_NAME = 1;
    static final int T2C_PROXYTYPE_DISTINGUISHED_NAME = 2;
    static final int T2C_PROXYTYPE_CERTIFICATE = 3;
    static final int T2C_CONNECTION_FLAG_DEFAULT_LOB_PREFETCH = 0;
    static final int T2C_CONNECTION_FLAG_PRELIM_AUTH = 1;
    private static boolean isLibraryLoaded;
    OracleOCIFailover appCallback;
    Object appCallbackObject;
    private Properties nativeInfo;
    ByteBuffer nioBufferForLob;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected T2CConnection(String s, Properties properties, OracleDriverExtension oracledriverextension)
        throws SQLException
    {
        super(s, properties, oracledriverextension);
        queryMetaData1 = null;
        queryMetaData2 = null;
        queryMetaData1Offset = 0;
        queryMetaData2Offset = 0;
        fatalErrorNumber = 0;
        fatalErrorMessage = null;
        queryMetaData1Size = 100;
        queryMetaData2Size = 800;
        logon_mode = 0;
        appCallback = null;
        appCallbackObject = null;
        initialize();
    }

    final void initializePassword(String s)
        throws SQLException
    {
        password = s;
    }

    protected void initialize()
    {
        allocQueryMetaDataBuffers();
    }

    private void allocQueryMetaDataBuffers()
    {
        queryMetaData1Offset = 0;
        queryMetaData1 = new short[queryMetaData1Size * 13];
        queryMetaData2Offset = 0;
        queryMetaData2 = new byte[queryMetaData2Size];
        namedTypeAccessorByteLen = 0;
        refTypeAccessorByteLen = 0;
    }

    void reallocateQueryMetaData(int i, int j)
    {
        queryMetaData1 = null;
        queryMetaData2 = null;
        queryMetaData1Size = Math.max(i, queryMetaData1Size);
        queryMetaData2Size = Math.max(j, queryMetaData2Size);
        allocQueryMetaDataBuffers();
    }

    protected void logon()
        throws SQLException
    {
        if(database == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 64);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(!isLibraryLoaded)
            loadNativeLibrary();
        if(ociConnectionPoolIsPooling)
        {
            processOCIConnectionPooling();
        } else
        {
            long l = ociSvcCtxHandle;
            long l1 = ociEnvHandle;
            long l2 = ociErrHandle;
            if(l != 0L && l1 != 0L)
            {
                if(ociDriverCharset != null)
                {
                    m_clientCharacterSet = (new Integer(ociDriverCharset)).shortValue();
                } else
                {
                    SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
                    sqlexception1.fillInStackTrace();
                    throw sqlexception1;
                }
                conversion = new DBConversion(m_clientCharacterSet, m_clientCharacterSet, m_clientCharacterSet);
                short aword0[] = new short[5];
                long al[] = {
                    (long)defaultLobPrefetchSize
                };
                sqlWarning = checkError(t2cUseConnection(m_nativeState, l1, l, l2, aword0, al), sqlWarning);
                conversion = new DBConversion(aword0[0], m_clientCharacterSet, aword0[1]);
                byteAlign = (byte)(aword0[2] & 0xff);
                timeZoneVersionNumber = (aword0[3] << 16) + (aword0[4] & 0xffff);
                return;
            }
            if(internalLogon == null)
                logon_mode = 0;
            else
            if(internalLogon.equalsIgnoreCase("SYSDBA"))
                logon_mode = 2;
            else
            if(internalLogon.equalsIgnoreCase("SYSOPER"))
                logon_mode = 4;
            else
            if(internalLogon.equalsIgnoreCase("SYSASM"))
                logon_mode = 32768;
            else
            if(internalLogon.equalsIgnoreCase("SYSBACKUP"))
                logon_mode = 0x20000;
            else
            if(internalLogon.equalsIgnoreCase("SYSDG"))
                logon_mode = 0x40000;
            else
            if(internalLogon.equalsIgnoreCase("SYSKM"))
                logon_mode = 0x80000;
            byte abyte0[] = null;
            byte abyte1[] = null;
            byte abyte2[] = null;
            String s = setNewPassword;
            byte abyte3[] = new byte[0];
            byte abyte4[] = new byte[0];
            byte abyte5[] = new byte[0];
            if(nlsLangBackdoor)
                m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG();
            else
                m_clientCharacterSet = getClientCharSetId();
            if(s != null)
                abyte3 = DBConversion.stringToDriverCharBytes(s, m_clientCharacterSet);
            if(editionName != null)
                abyte4 = DBConversion.stringToDriverCharBytes(editionName, m_clientCharacterSet);
            if(driverNameAttribute == null)
                abyte5 = DBConversion.stringToDriverCharBytes("jdbcoci", m_clientCharacterSet);
            else
                abyte5 = DBConversion.stringToDriverCharBytes(driverNameAttribute, m_clientCharacterSet);
            abyte0 = userName != null ? DBConversion.stringToDriverCharBytes(userName, m_clientCharacterSet) : new byte[0];
            abyte1 = proxyClientName != null ? DBConversion.stringToDriverCharBytes(proxyClientName, m_clientCharacterSet) : new byte[0];
            abyte2 = password != null ? DBConversion.stringToDriverCharBytes(password, m_clientCharacterSet) : new byte[0];
            byte abyte6[] = DBConversion.stringToDriverCharBytes(database, m_clientCharacterSet);
            short aword1[] = new short[5];
            String s1 = null;
            byte abyte7[] = (s1 = CharacterSetMetaData.getNLSLanguage(ClassRef.LOCALE.getDefault())) == null ? null : s1.getBytes();
            byte abyte8[] = (s1 = CharacterSetMetaData.getNLSTerritory(ClassRef.LOCALE.getDefault())) == null ? null : s1.getBytes();
            if(abyte7 == null || abyte8 == null)
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
            TimeZone timezone = TimeZone.getDefault();
            String s2 = timezone.getID();
            if(!ZONEIDMAP.isValidRegion(s2) || !timezoneAsRegion)
            {
                int i = timezone.getOffset(System.currentTimeMillis());
                int j = i / 0x36ee80;
                int k = (i / 60000) % 60;
                s2 = (new StringBuilder()).append(j >= 0 ? (new StringBuilder()).append("+").append(j).toString() : (new StringBuilder()).append("").append(j).toString()).append(k >= 10 ? (new StringBuilder()).append(":").append(k).toString() : (new StringBuilder()).append(":0").append(k).toString()).toString();
            }
            doSetSessionTimeZone(s2);
            sessionTimeZone = s2;
            conversion = new DBConversion(m_clientCharacterSet, m_clientCharacterSet, m_clientCharacterSet);
            long al1[] = {
                (long)defaultLobPrefetchSize, (long)(prelimAuth ? 1 : 0)
            };
            if(m_nativeState == 0L)
                sqlWarning = checkError(t2cCreateState(abyte0, abyte0.length, abyte1, abyte1.length, abyte2, abyte2.length, abyte3, abyte3.length, abyte4, abyte4.length, abyte5, abyte5.length, abyte6, abyte6.length, m_clientCharacterSet, logon_mode, aword1, abyte7, abyte8, retainV9BindBehavior, al1), sqlWarning);
            else
                sqlWarning = checkError(t2cLogon(m_nativeState, abyte0, abyte0.length, abyte1, abyte1.length, abyte2, abyte2.length, abyte3, abyte3.length, abyte4, abyte4.length, abyte5, abyte5.length, abyte6, abyte6.length, logon_mode, aword1, abyte7, abyte8, al1), sqlWarning);
            conversion = new DBConversion(aword1[0], m_clientCharacterSet, aword1[1]);
            byteAlign = (byte)(aword1[2] & 0xff);
            timeZoneVersionNumber = (aword1[3] << 16) + (aword1[4] & 0xffff);
        }
    }

    protected void logoff()
        throws SQLException
    {
        try
        {
            if(lifecycle == 2)
                checkError(t2cLogoff(m_nativeState));
        }
        catch(NullPointerException nullpointerexception) { }
        m_nativeState = 0L;
    }

    public void open(oracle.jdbc.driver.OracleStatement oraclestatement)
        throws SQLException
    {
        byte abyte0[] = oraclestatement.sqlObject.getSql(oraclestatement.processEscapes, oraclestatement.convertNcharLiterals).getBytes();
        checkError(t2cCreateStatement(m_nativeState, 0L, abyte0, abyte0.length, oraclestatement, false, oraclestatement.rowPrefetch));
    }

    void cancelOperationOnServer(boolean flag)
        throws SQLException
    {
        checkError(t2cCancel(m_nativeState));
    }

    native int t2cAbort(long l);

    void doAbort()
        throws SQLException
    {
        checkError(t2cAbort(m_nativeState));
    }

    protected void doSetAutoCommit(boolean flag)
        throws SQLException
    {
        checkError(t2cSetAutoCommit(m_nativeState, flag));
        autocommit = flag;
    }

    protected void doCommit(int i)
        throws SQLException
    {
        checkError(t2cCommit(m_nativeState, i));
    }

    protected void doRollback()
        throws SQLException
    {
        checkError(t2cRollback(m_nativeState));
    }

    synchronized int doPingDatabase()
        throws SQLException
    {
        return t2cPingDatabase(m_nativeState) != 0 ? -1 : 0;
    }

    protected String doGetDatabaseProductVersion()
        throws SQLException
    {
        byte abyte0[] = t2cGetProductionVersion(m_nativeState);
        return conversion.CharBytesToString(abyte0, abyte0.length);
    }

    protected short doGetVersionNumber()
        throws SQLException
    {
        short word0 = 0;
        StringTokenizer stringtokenizer;
        int i;
        String s = doGetDatabaseProductVersion();
        stringtokenizer = new StringTokenizer(s.trim(), " .", false);
        Object obj = null;
        i = 0;
        boolean flag = false;
_L2:
        String s1;
        if(!stringtokenizer.hasMoreTokens())
            break; /* Loop/switch isn't completed */
        s1 = stringtokenizer.nextToken();
        short word1 = Integer.decode(s1).shortValue();
        word0 = (short)(word0 * 10 + word1);
        if(++i == 4)
            break; /* Loop/switch isn't completed */
        continue; /* Loop/switch isn't completed */
        NumberFormatException numberformatexception;
        numberformatexception;
        if(true) goto _L2; else goto _L1
        NoSuchElementException nosuchelementexception;
        nosuchelementexception;
_L1:
        if(word0 == -1)
            word0 = 0;
        return word0;
    }

    public ClobDBAccess createClobDBAccess()
    {
        return this;
    }

    public BlobDBAccess createBlobDBAccess()
    {
        return this;
    }

    public BfileDBAccess createBfileDBAccess()
    {
        return this;
    }

    protected SQLWarning checkError(int i)
        throws SQLException
    {
        return checkError(i, null);
    }

    protected SQLWarning checkError(int i, SQLWarning sqlwarning)
        throws SQLException
    {
        switch(i)
        {
        case -4: 
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 254);
            sqlexception.fillInStackTrace();
            throw sqlexception;

        case -1: 
        case 1: // '\001'
            T2CError t2cerror = new T2CError();
            int j = -1;
            if(lifecycle == 1 || lifecycle == 16)
                j = t2cDescribeError(m_nativeState, t2cerror, t2cerror.m_errorMessage);
            else
            if(fatalErrorNumber != 0)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 269);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            } else
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
            String s = null;
            if(j != -1)
            {
                int k;
                for(k = 0; k < t2cerror.m_errorMessage.length && t2cerror.m_errorMessage[k] != 0; k++);
                if(conversion == null)
                    throw new Error("conversion == null");
                if(t2cerror == null)
                    throw new Error("l_error == null");
                s = conversion.CharBytesToString(t2cerror.m_errorMessage, k, true);
            }
            switch(t2cerror.m_errorNumber)
            {
            case 28: // '\034'
            case 600: 
            case 1012: 
            case 1041: 
                internalClose();
                break;

            case 902: 
                removeAllDescriptor();
                break;

            case 3113: 
            case 3114: 
                setUsable(false);
                close();
                break;

            case -6: 
                t2cerror.m_errorNumber = 3113;
                break;
            }
            if(j == -1)
            {
                SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Fetch error message failed!");
                sqlexception3.fillInStackTrace();
                throw sqlexception3;
            }
            if(i == -1)
            {
                SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), s, t2cerror.m_errorNumber);
                sqlexception4.fillInStackTrace();
                throw sqlexception4;
            }
            sqlwarning = DatabaseError.addSqlWarning(sqlwarning, s, t2cerror.m_errorNumber);
            // fall through

        case -3: 
        case -2: 
        case 0: // '\0'
        default:
            return sqlwarning;
        }
    }

    oracle.jdbc.driver.OracleStatement RefCursorBytesToStatement(byte abyte0[], oracle.jdbc.driver.OracleStatement oraclestatement)
        throws SQLException
    {
        T2CStatement t2cstatement = new T2CStatement(this, 1, defaultRowPrefetch, -1, -1);
        t2cstatement.needToParse = false;
        t2cstatement.serverCursor = true;
        t2cstatement.isOpen = true;
        t2cstatement.processEscapes = false;
        t2cstatement.prepareForNewResults(true, false);
        t2cstatement.sqlObject.initialize("select unknown as ref cursor from whatever");
        t2cstatement.sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.SELECT;
        checkError(t2cCreateStatement(m_nativeState, oraclestatement.c_state, abyte0, abyte0.length, t2cstatement, true, defaultRowPrefetch));
        oraclestatement.addChild(t2cstatement);
        return t2cstatement;
    }

    public void getForm(OracleTypeADT oracletypeadt, OracleTypeCLOB oracletypeclob, int i)
        throws SQLException
    {
        boolean flag = false;
        if(oracletypeclob != null)
        {
            String as[] = new String[1];
            String as1[] = new String[1];
            SQLName.parse(oracletypeadt.getFullName(), as, as1, true);
            String s = (new StringBuilder()).append("\"").append(as[0]).append("\".\"").append(as1[0]).append("\"").toString();
            byte abyte0[] = conversion.StringToCharBytes(s);
            int j = t2cGetFormOfUse(m_nativeState, oracletypeclob, abyte0, abyte0.length, i);
            if(j < 0)
                checkError(j);
            oracletypeclob.setForm(j);
        }
    }

    public long getTdoCState(String s, String s1)
        throws SQLException
    {
        String s2 = (new StringBuilder()).append("\"").append(s).append("\".\"").append(s1).append("\"").toString();
        byte abyte0[] = conversion.StringToCharBytes(s2);
        int ai[] = new int[1];
        long l = t2cGetTDO(m_nativeState, abyte0, abyte0.length, ai);
        if(l == 0L)
            checkError(ai[0]);
        return l;
    }

    /**
     * @deprecated Method getDBAccessProperties is deprecated
     */

    public Properties getDBAccessProperties()
        throws SQLException
    {
        return getOCIHandles();
    }

    public synchronized Properties getOCIHandles()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(nativeInfo == null)
        {
            long al[] = new long[3];
            checkError(t2cGetHandles(m_nativeState, al));
            nativeInfo = new Properties();
            nativeInfo.put("OCIEnvHandle", String.valueOf(al[0]));
            nativeInfo.put("OCISvcCtxHandle", String.valueOf(al[1]));
            nativeInfo.put("OCIErrHandle", String.valueOf(al[2]));
            nativeInfo.put("ClientCharSet", String.valueOf(m_clientCharacterSet));
        }
        return nativeInfo;
    }

    public Properties getServerSessionInfo()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(sessionProperties == null)
            sessionProperties = new Properties();
        if(getVersionNumber() < 10200)
            queryFCFProperties(sessionProperties);
        else
            checkError(t2cGetServerSessionInfo(m_nativeState, sessionProperties));
        return sessionProperties;
    }

    public byte getInstanceProperty(oracle.jdbc.internal.OracleConnection.InstanceProperty instanceproperty)
        throws SQLException
    {
        byte byte0 = 0;
        if(instanceproperty == oracle.jdbc.internal.OracleConnection.InstanceProperty.ASM_VOLUME_SUPPORTED)
            byte0 = t2cGetAsmVolProperty(m_nativeState);
        else
        if(instanceproperty == oracle.jdbc.internal.OracleConnection.InstanceProperty.INSTANCE_TYPE)
            byte0 = t2cGetInstanceType(m_nativeState);
        return byte0;
    }

    public Properties getConnectionPoolInfo()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            Properties properties = new Properties();
            checkError(t2cGetConnPoolInfo(m_nativeState, properties));
            return properties;
        }
    }

    public void setConnectionPoolInfo(int i, int j, int k, int l, int i1, int j1)
        throws SQLException
    {
        checkError(t2cSetConnPoolInfo(m_nativeState, i, j, k, l, i1, j1));
    }

    public void ociPasswordChange(String s, String s1, String s2)
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            byte abyte0[] = s != null ? DBConversion.stringToDriverCharBytes(s, m_clientCharacterSet) : new byte[0];
            byte abyte1[] = s1 != null ? DBConversion.stringToDriverCharBytes(s1, m_clientCharacterSet) : new byte[0];
            byte abyte2[] = s2 != null ? DBConversion.stringToDriverCharBytes(s2, m_clientCharacterSet) : new byte[0];
            sqlWarning = checkError(t2cPasswordChange(m_nativeState, abyte0, abyte0.length, abyte1, abyte1.length, abyte2, abyte2.length), sqlWarning);
            return;
        }
    }

    private void processOCIConnectionPooling()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        T2CConnection t2cconnection = null;
        if(ociConnectionPoolLogonMode == "connection_pool")
        {
            if(nlsLangBackdoor)
                m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG();
            else
                m_clientCharacterSet = getClientCharSetId();
        } else
        {
            t2cconnection = (T2CConnection)ociConnectionPoolObject;
            m_clientCharacterSet = t2cconnection.m_clientCharacterSet;
        }
        Object obj = null;
        byte abyte4[] = password != null ? DBConversion.stringToDriverCharBytes(password, m_clientCharacterSet) : new byte[0];
        byte abyte5[] = editionName != null ? DBConversion.stringToDriverCharBytes(editionName, m_clientCharacterSet) : new byte[0];
        byte abyte6[] = DBConversion.stringToDriverCharBytes(driverNameAttribute != null ? driverNameAttribute : "jdbcoci", m_clientCharacterSet);
        byte abyte7[] = DBConversion.stringToDriverCharBytes(database, m_clientCharacterSet);
        byte abyte8[] = CharacterSetMetaData.getNLSLanguage(ClassRef.LOCALE.getDefault()).getBytes();
        byte abyte9[] = CharacterSetMetaData.getNLSTerritory(ClassRef.LOCALE.getDefault()).getBytes();
        if(abyte8 == null || abyte9 == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        short aword0[] = new short[5];
        long al[] = {
            (long)defaultLobPrefetchSize
        };
        if(ociConnectionPoolLogonMode == "connection_pool")
        {
            byte abyte0[] = userName != null ? DBConversion.stringToDriverCharBytes(userName, m_clientCharacterSet) : new byte[0];
            conversion = new DBConversion(m_clientCharacterSet, m_clientCharacterSet, m_clientCharacterSet);
            logon_mode = 5;
            if(lifecycle == 1)
            {
                int ai[] = new int[6];
                OracleOCIConnectionPool.readPoolConfig(ociConnectionPoolMinLimit, ociConnectionPoolMaxLimit, ociConnectionPoolIncrement, ociConnectionPoolTimeout, ociConnectionPoolNoWait, ociConnectionPoolTransactionDistributed, ai);
                sqlWarning = checkError(t2cCreateConnPool(abyte0, abyte0.length, abyte4, abyte4.length, abyte7, abyte7.length, m_clientCharacterSet, logon_mode, ai[0], ai[1], ai[2], ai[3], ai[4], ai[5]), sqlWarning);
                versionNumber = 10000;
            } else
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 0, "Internal Error: ");
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        } else
        if(ociConnectionPoolLogonMode == "connpool_connection")
        {
            logon_mode = 6;
            byte abyte1[] = userName != null ? DBConversion.stringToDriverCharBytes(userName, m_clientCharacterSet) : new byte[0];
            conversion = new DBConversion(m_clientCharacterSet, m_clientCharacterSet, m_clientCharacterSet);
            sqlWarning = checkError(t2cConnPoolLogon(t2cconnection.m_nativeState, abyte1, abyte1.length, abyte4, abyte4.length, abyte5, abyte5.length, abyte6, abyte6.length, abyte7, abyte7.length, logon_mode, 0, 0, null, null, 0, null, 0, null, 0, null, 0, null, 0, aword0, abyte8, abyte9, al), sqlWarning);
        } else
        if(ociConnectionPoolLogonMode == "connpool_alias_connection")
        {
            logon_mode = 8;
            byte abyte10[] = null;
            abyte10 = (byte[])(byte[])ociConnectionPoolConnID;
            byte abyte2[] = userName != null ? DBConversion.stringToDriverCharBytes(userName, m_clientCharacterSet) : new byte[0];
            conversion = new DBConversion(m_clientCharacterSet, m_clientCharacterSet, m_clientCharacterSet);
            sqlWarning = checkError(t2cConnPoolLogon(t2cconnection.m_nativeState, abyte2, abyte2.length, abyte4, abyte4.length, abyte5, abyte5.length, abyte6, abyte6.length, abyte7, abyte7.length, logon_mode, 0, 0, null, null, 0, null, 0, null, 0, null, 0, abyte10, abyte10 != null ? abyte10.length : 0, aword0, abyte8, abyte9, al), sqlWarning);
        } else
        if(ociConnectionPoolLogonMode == "connpool_proxy_connection")
        {
            logon_mode = 7;
            String s = ociConnectionPoolProxyType;
            int i = ociConnectionPoolProxyNumRoles.intValue();
            String as[] = null;
            if(i > 0)
                as = (String[])(String[])ociConnectionPoolProxyRoles;
            byte abyte11[] = null;
            byte abyte12[] = null;
            byte abyte13[] = null;
            byte abyte14[] = null;
            byte byte0 = 0;
            if(s == "proxytype_user_name")
            {
                byte0 = 1;
                String s1 = ociConnectionPoolProxyUserName;
                if(s1 != null)
                    abyte11 = s1.getBytes();
                s1 = ociConnectionPoolProxyPassword;
                if(s1 != null)
                    abyte12 = s1.getBytes();
            } else
            if(s == "proxytype_distinguished_name")
            {
                byte0 = 2;
                String s2 = ociConnectionPoolProxyDistinguishedName;
                if(s2 != null)
                    abyte13 = s2.getBytes();
            } else
            if(s == "proxytype_certificate")
            {
                byte0 = 3;
                abyte14 = (byte[])(byte[])ociConnectionPoolProxyCertificate;
            } else
            {
                SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 107);
                sqlexception4.fillInStackTrace();
                throw sqlexception4;
            }
            byte abyte3[] = userName != null ? DBConversion.stringToDriverCharBytes(userName, m_clientCharacterSet) : new byte[0];
            conversion = new DBConversion(m_clientCharacterSet, m_clientCharacterSet, m_clientCharacterSet);
            sqlWarning = checkError(t2cConnPoolLogon(t2cconnection.m_nativeState, abyte3, abyte3.length, abyte4, abyte4.length, abyte5, abyte5.length, abyte6, abyte6.length, abyte7, abyte7.length, logon_mode, byte0, i, as, abyte11, abyte11 != null ? abyte11.length : 0, abyte12, abyte12 != null ? abyte12.length : 0, abyte13, abyte13 != null ? abyte13.length : 0, abyte14, abyte14 != null ? abyte14.length : 0, null, 0, aword0, abyte8, abyte9, al), sqlWarning);
        } else
        {
            SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "connection-pool-logon");
            sqlexception3.fillInStackTrace();
            throw sqlexception3;
        }
        conversion = new DBConversion(aword0[0], m_clientCharacterSet, aword0[1]);
        byteAlign = (byte)(aword0[2] & 0xff);
        timeZoneVersionNumber = (aword0[3] << 16) + (aword0[4] & 0xffff);
    }

    public boolean isDescriptorSharable(OracleConnection oracleconnection)
        throws SQLException
    {
        T2CConnection t2cconnection = this;
        PhysicalConnection physicalconnection = (PhysicalConnection)(PhysicalConnection)oracleconnection.getPhysicalConnection();
        return t2cconnection == physicalconnection;
    }

    native int t2cBlobRead(long l, byte abyte0[], int i, long l1, int j, 
            byte abyte1[], int k, boolean flag, ByteBuffer bytebuffer);

    native int t2cClobRead(long l, byte abyte0[], int i, long l1, int j, 
            char ac[], int k, boolean flag, boolean flag1, ByteBuffer bytebuffer);

    native int t2cBlobWrite(long l, byte abyte0[], int i, long l1, int j, 
            byte abyte1[], int k, byte abyte2[][]);

    native int t2cClobWrite(long l, byte abyte0[], int i, long l1, int j, 
            char ac[], int k, byte abyte1[][], boolean flag);

    native long t2cLobGetLength(long l, byte abyte0[], int i);

    native int t2cBfileOpen(long l, byte abyte0[], int i, byte abyte1[][]);

    native int t2cBfileIsOpen(long l, byte abyte0[], int i, boolean aflag[]);

    native int t2cBfileExists(long l, byte abyte0[], int i, boolean aflag[]);

    native String t2cBfileGetName(long l, byte abyte0[], int i);

    native String t2cBfileGetDirAlias(long l, byte abyte0[], int i);

    native int t2cBfileClose(long l, byte abyte0[], int i, byte abyte1[][]);

    native int t2cLobGetChunkSize(long l, byte abyte0[], int i);

    native int t2cLobTrim(long l, int i, long l1, byte abyte0[], int j, 
            byte abyte1[][]);

    native int t2cLobCreateTemporary(long l, int i, boolean flag, int j, short word0, byte abyte0[][]);

    native int t2cLobFreeTemporary(long l, int i, byte abyte0[], int j, byte abyte1[][]);

    native int t2cLobIsTemporary(long l, int i, byte abyte0[], int j, boolean aflag[]);

    native int t2cLobOpen(long l, int i, byte abyte0[], int j, int k, byte abyte1[][]);

    native int t2cLobIsOpen(long l, int i, byte abyte0[], int j, boolean aflag[]);

    native int t2cLobClose(long l, int i, byte abyte0[], int j, byte abyte1[][]);

    private long lobLength(byte abyte0[])
        throws SQLException
    {
        long l = 0L;
        l = t2cLobGetLength(m_nativeState, abyte0, abyte0.length);
        checkError((int)l);
        return l;
    }

    private int blobRead(byte abyte0[], long l, int i, byte abyte1[], boolean flag, ByteBuffer bytebuffer)
        throws SQLException
    {
        int j = 0;
        j = t2cBlobRead(m_nativeState, abyte0, abyte0.length, l, i, abyte1, abyte1.length, flag, bytebuffer);
        checkError(j);
        return j;
    }

    private int blobWrite(byte abyte0[], long l, byte abyte1[], byte abyte2[][], int i, int j)
        throws SQLException
    {
        int k = 0;
        k = t2cBlobWrite(m_nativeState, abyte0, abyte0.length, l, j, abyte1, i, abyte2);
        checkError(k);
        return k;
    }

    private int clobWrite(byte abyte0[], long l, char ac[], byte abyte1[][], boolean flag, int i, 
            int j)
        throws SQLException
    {
        int k = 0;
        k = t2cClobWrite(m_nativeState, abyte0, abyte0.length, l, j, ac, i, abyte1, flag);
        checkError(k);
        return k;
    }

    private int lobGetChunkSize(byte abyte0[])
        throws SQLException
    {
        int i = 0;
        i = t2cLobGetChunkSize(m_nativeState, abyte0, abyte0.length);
        checkError(i);
        return i;
    }

    public synchronized long length(BFILE bfile)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(bfile != null && (abyte0 = bfile.getLocator()) != null, 54);
        return lobLength(abyte0);
    }

    public synchronized long position(BFILE bfile, byte abyte0[], long l)
        throws SQLException
    {
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            long l1 = LobPlsqlUtil.hasPattern(bfile, abyte0, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public synchronized long position(BFILE bfile, BFILE bfile1, long l)
        throws SQLException
    {
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            long l1 = LobPlsqlUtil.isSubLob(bfile, bfile1, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public synchronized int getBytes(BFILE bfile, long l, int i, byte abyte0[])
        throws SQLException
    {
        byte abyte1[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(bfile != null && (abyte1 = bfile.getLocator()) != null, 54);
        if(i <= 0 || abyte0 == null)
            return 0;
        if(i > abyte0.length)
            i = abyte0.length;
        if(useNio)
        {
            int j = abyte0.length;
            if(nioBufferForLob == null || nioBufferForLob.capacity() < j)
                nioBufferForLob = ByteBuffer.allocateDirect(j);
            else
                nioBufferForLob.rewind();
        }
        int k = blobRead(abyte1, l, i, abyte0, useNio, nioBufferForLob);
        if(useNio)
            nioBufferForLob.get(abyte0);
        return k;
    }

    public synchronized String getName(BFILE bfile)
        throws SQLException
    {
        byte abyte0[] = null;
        String s = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(bfile != null && (abyte0 = bfile.getLocator()) != null, 54);
        s = t2cBfileGetName(m_nativeState, abyte0, abyte0.length);
        checkError(s.length());
        return s;
    }

    public synchronized String getDirAlias(BFILE bfile)
        throws SQLException
    {
        byte abyte0[] = null;
        String s = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(bfile != null && (abyte0 = bfile.getLocator()) != null, 54);
        s = t2cBfileGetDirAlias(m_nativeState, abyte0, abyte0.length);
        checkError(s.length());
        return s;
    }

    public synchronized void openFile(BFILE bfile)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(bfile != null && (abyte0 = bfile.getLocator()) != null, 54);
        byte abyte1[][] = new byte[1][];
        checkError(t2cBfileOpen(m_nativeState, abyte0, abyte0.length, abyte1));
        bfile.setLocator(abyte1[0]);
    }

    public synchronized boolean isFileOpen(BFILE bfile)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(bfile != null && (abyte0 = bfile.getLocator()) != null, 54);
        boolean aflag[] = new boolean[1];
        checkError(t2cBfileIsOpen(m_nativeState, abyte0, abyte0.length, aflag));
        return aflag[0];
    }

    public synchronized boolean fileExists(BFILE bfile)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(bfile != null && (abyte0 = bfile.getLocator()) != null, 54);
        boolean aflag[] = new boolean[1];
        checkError(t2cBfileExists(m_nativeState, abyte0, abyte0.length, aflag));
        return aflag[0];
    }

    public synchronized void closeFile(BFILE bfile)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(bfile != null && (abyte0 = bfile.getLocator()) != null, 54);
        byte abyte1[][] = new byte[1][];
        checkError(t2cBfileClose(m_nativeState, abyte0, abyte0.length, abyte1));
        bfile.setLocator(abyte1[0]);
    }

    public synchronized void open(BFILE bfile, int i)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(bfile != null && (abyte0 = bfile.shareBytes()) != null, 54);
        byte abyte1[][] = new byte[1][];
        checkError(t2cLobOpen(m_nativeState, 114, abyte0, abyte0.length, i, abyte1));
        bfile.setShareBytes(abyte1[0]);
    }

    public synchronized void close(BFILE bfile)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(bfile != null && (abyte0 = bfile.shareBytes()) != null, 54);
        byte abyte1[][] = new byte[1][];
        checkError(t2cLobClose(m_nativeState, 114, abyte0, abyte0.length, abyte1));
        bfile.setShareBytes(abyte1[0]);
    }

    public synchronized boolean isOpen(BFILE bfile)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(bfile != null && (abyte0 = bfile.shareBytes()) != null, 54);
        boolean aflag[] = new boolean[1];
        checkError(t2cLobIsOpen(m_nativeState, 114, abyte0, abyte0.length, aflag));
        return aflag[0];
    }

    public InputStream newInputStream(BFILE bfile, int i, long l)
        throws SQLException
    {
        if(l == 0L)
            return new OracleBlobInputStream(bfile, i);
        else
            return new OracleBlobInputStream(bfile, i, l);
    }

    public InputStream newConversionInputStream(BFILE bfile, int i)
        throws SQLException
    {
        checkTrue(bfile != null && bfile.shareBytes() != null, 54);
        OracleConversionInputStream oracleconversioninputstream = new OracleConversionInputStream(conversion, bfile.getBinaryStream(), i);
        return oracleconversioninputstream;
    }

    public Reader newConversionReader(BFILE bfile, int i)
        throws SQLException
    {
        checkTrue(bfile != null && bfile.shareBytes() != null, 54);
        OracleConversionReader oracleconversionreader = new OracleConversionReader(conversion, bfile.getBinaryStream(), i);
        return oracleconversionreader;
    }

    public synchronized long length(BLOB blob)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(blob != null && (abyte0 = blob.getLocator()) != null, 54);
        return lobLength(abyte0);
    }

    public synchronized long position(BLOB blob, byte abyte0[], long l)
        throws SQLException
    {
        checkTrue(lifecycle == 1, 8);
        checkTrue(blob != null && blob.shareBytes() != null, 54);
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            long l1 = LobPlsqlUtil.hasPattern(blob, abyte0, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public synchronized long position(BLOB blob, BLOB blob1, long l)
        throws SQLException
    {
        checkTrue(lifecycle == 1, 8);
        checkTrue(blob != null && blob.shareBytes() != null, 54);
        checkTrue(blob1 != null && blob1.shareBytes() != null, 54);
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            long l1 = LobPlsqlUtil.isSubLob(blob, blob1, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public synchronized int getBytes(BLOB blob, long l, int i, byte abyte0[])
        throws SQLException
    {
        byte abyte1[] = null;
        int j = 0;
        checkTrue(lifecycle == 1, 8);
        checkTrue(blob != null && (abyte1 = blob.getLocator()) != null, 54);
        if(i <= 0 || abyte0 == null)
            return 0;
        if(i > abyte0.length)
            i = abyte0.length;
        long l1 = -1L;
        if(blob.isActivePrefetch())
        {
            byte abyte2[] = blob.getPrefetchedData();
            l1 = blob.length();
            if(abyte2 != null && abyte2 != null && l <= (long)abyte2.length)
            {
                int k = Math.min((abyte2.length - (int)l) + 1, i);
                System.arraycopy(abyte2, (int)l - 1, abyte0, 0, k);
                j += k;
            }
        }
        if(j < i && (l1 == -1L || (l - 1L) + (long)j < l1))
        {
            byte abyte3[] = abyte0;
            int i1 = j;
            int j1 = (l1 <= 0L || l1 >= (long)i ? i : (int)l1) - j;
            if(j > 0)
                abyte3 = new byte[j1];
            if(useNio)
            {
                int k1 = abyte0.length;
                if(nioBufferForLob == null || nioBufferForLob.capacity() < k1)
                    nioBufferForLob = ByteBuffer.allocateDirect(k1);
                else
                    nioBufferForLob.rewind();
            }
            j += blobRead(abyte1, l + (long)j, j1, abyte3, useNio, nioBufferForLob);
            if(useNio)
                nioBufferForLob.get(abyte3);
            if(i1 > 0)
                System.arraycopy(abyte3, 0, abyte0, i1, abyte3.length);
        }
        return j;
    }

    public synchronized int putBytes(BLOB blob, long l, byte abyte0[], int i, int j)
        throws SQLException
    {
        checkTrue(l != 0L || j > 0, 68);
        checkTrue(l >= 0L, 68);
        if(abyte0 == null || j <= 0)
            return 0;
        int k = 0;
        if(abyte0 == null || abyte0.length == 0 || j <= 0)
        {
            k = 0;
        } else
        {
            byte abyte1[] = null;
            checkTrue(lifecycle == 1, 8);
            checkTrue(blob != null && (abyte1 = blob.getLocator()) != null, 54);
            byte abyte2[][] = new byte[1][];
            blob.setActivePrefetch(false);
            blob.clearCachedData();
            k = blobWrite(abyte1, l, abyte0, abyte2, i, j);
            blob.setLocator(abyte2[0]);
        }
        return k;
    }

    public synchronized int getChunkSize(BLOB blob)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(blob != null && (abyte0 = blob.getLocator()) != null, 54);
        return lobGetChunkSize(abyte0);
    }

    public synchronized void trim(BLOB blob, long l)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(blob != null && (abyte0 = blob.shareBytes()) != null, 54);
        byte abyte1[][] = new byte[1][];
        blob.setActivePrefetch(false);
        blob.clearCachedData();
        checkError(t2cLobTrim(m_nativeState, 113, l, abyte0, abyte0.length, abyte1));
        blob.setShareBytes(abyte1[0]);
    }

    public synchronized BLOB createTemporaryBlob(Connection connection, boolean flag, int i)
        throws SQLException
    {
        BLOB blob = null;
        checkTrue(lifecycle == 1, 8);
        blob = new BLOB((PhysicalConnection)connection);
        byte abyte0[][] = new byte[1][];
        checkError(t2cLobCreateTemporary(m_nativeState, 113, flag, i, (short)0, abyte0));
        blob.setShareBytes(abyte0[0]);
        return blob;
    }

    public synchronized void freeTemporary(BLOB blob, boolean flag)
        throws SQLException
    {
        try
        {
            byte abyte0[] = null;
            checkTrue(lifecycle == 1, 8);
            checkTrue(blob != null && (abyte0 = blob.shareBytes()) != null, 54);
            byte abyte1[][] = new byte[1][];
            checkError(t2cLobFreeTemporary(m_nativeState, 113, abyte0, abyte0.length, abyte1));
            blob.setShareBytes(abyte1[0]);
        }
        catch(SQLException sqlexception)
        {
            if(flag & (sqlexception.getErrorCode() == 64201))
                LobPlsqlUtil.freeTemporaryLob(this, blob, 2004);
            else
                throw sqlexception;
        }
    }

    public synchronized boolean isTemporary(BLOB blob)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(blob != null && (abyte0 = blob.shareBytes()) != null, 54);
        boolean aflag[] = new boolean[1];
        checkError(t2cLobIsTemporary(m_nativeState, 113, abyte0, abyte0.length, aflag));
        return aflag[0];
    }

    public synchronized void open(BLOB blob, int i)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(blob != null && (abyte0 = blob.shareBytes()) != null, 54);
        byte abyte1[][] = new byte[1][];
        checkError(t2cLobOpen(m_nativeState, 113, abyte0, abyte0.length, i, abyte1));
        blob.setShareBytes(abyte1[0]);
    }

    public synchronized void close(BLOB blob)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(blob != null && (abyte0 = blob.shareBytes()) != null, 54);
        byte abyte1[][] = new byte[1][];
        checkError(t2cLobClose(m_nativeState, 113, abyte0, abyte0.length, abyte1));
        blob.setShareBytes(abyte1[0]);
    }

    public synchronized boolean isOpen(BLOB blob)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(blob != null && (abyte0 = blob.shareBytes()) != null, 54);
        boolean aflag[] = new boolean[1];
        checkError(t2cLobIsOpen(m_nativeState, 113, abyte0, abyte0.length, aflag));
        return aflag[0];
    }

    public InputStream newInputStream(BLOB blob, int i, long l)
        throws SQLException
    {
        if(l == 0L)
            return new OracleBlobInputStream(blob, i);
        else
            return new OracleBlobInputStream(blob, i, l);
    }

    public InputStream newInputStream(BLOB blob, int i, long l, long l1)
        throws SQLException
    {
        return new OracleBlobInputStream(blob, i, l, l1);
    }

    public OutputStream newOutputStream(BLOB blob, int i, long l, boolean flag)
        throws SQLException
    {
        if(l == 0L)
        {
            if(flag & lobStreamPosStandardCompliant)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            } else
            {
                return new OracleBlobOutputStream(blob, i);
            }
        } else
        {
            return new OracleBlobOutputStream(blob, i, l);
        }
    }

    public InputStream newConversionInputStream(BLOB blob, int i)
        throws SQLException
    {
        checkTrue(blob != null && blob.shareBytes() != null, 54);
        OracleConversionInputStream oracleconversioninputstream = new OracleConversionInputStream(conversion, blob.getBinaryStream(), i);
        return oracleconversioninputstream;
    }

    public Reader newConversionReader(BLOB blob, int i)
        throws SQLException
    {
        checkTrue(blob != null && blob.shareBytes() != null, 54);
        OracleConversionReader oracleconversionreader = new OracleConversionReader(conversion, blob.getBinaryStream(), i);
        return oracleconversionreader;
    }

    public synchronized long length(CLOB clob)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(clob != null && (abyte0 = clob.getLocator()) != null, 54);
        return lobLength(abyte0);
    }

    public synchronized long position(CLOB clob, String s, long l)
        throws SQLException
    {
        if(s == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        checkTrue(lifecycle == 1, 8);
        checkTrue(clob != null && clob.shareBytes() != null, 54);
        if(l < 1L)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            char ac[] = new char[s.length()];
            s.getChars(0, ac.length, ac, 0);
            long l1 = LobPlsqlUtil.hasPattern(clob, ac, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public synchronized long position(CLOB clob, CLOB clob1, long l)
        throws SQLException
    {
        checkTrue(lifecycle == 1, 8);
        checkTrue(clob != null && clob.shareBytes() != null, 54);
        checkTrue(clob1 != null && clob1.shareBytes() != null, 54);
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            long l1 = LobPlsqlUtil.isSubLob(clob, clob1, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public synchronized int getChars(CLOB clob, long l, int i, char ac[])
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(clob != null && (abyte0 = clob.getLocator()) != null, 54);
        if(i <= 0 || ac == null)
            return 0;
        if(i > ac.length)
            i = ac.length;
        int j = 0;
        long l1 = -1L;
        if(clob.isActivePrefetch())
        {
            l1 = clob.length();
            char ac1[] = clob.getPrefetchedData();
            if(ac1 != null && l <= (long)ac1.length)
            {
                int k = Math.min((ac1.length - (int)l) + 1, i);
                System.arraycopy(ac1, (int)l - 1, ac, 0, k);
                j += k;
            }
        }
        if(j < i && (l1 == -1L || (l - 1L) + (long)j < l1))
        {
            char ac2[] = ac;
            int i1 = j;
            int j1 = (l1 <= 0L || l1 >= (long)i ? i : (int)l1) - j;
            if(j > 0)
                ac2 = new char[j1];
            if(useNio)
            {
                int k1 = ac.length * 2;
                if(nioBufferForLob == null || nioBufferForLob.capacity() < k1)
                    nioBufferForLob = ByteBuffer.allocateDirect(k1);
                else
                    nioBufferForLob.rewind();
            }
            j += t2cClobRead(m_nativeState, abyte0, abyte0.length, l + (long)j, j1, ac2, ac2.length, clob.isNCLOB(), useNio, nioBufferForLob);
            if(useNio)
            {
                ByteBuffer bytebuffer = nioBufferForLob.order(ByteOrder.LITTLE_ENDIAN);
                CharBuffer charbuffer = bytebuffer.asCharBuffer();
                charbuffer.get(ac2);
            }
            if(i1 > 0)
                System.arraycopy(ac2, 0, ac, i1, ac2.length);
            checkError(j);
        }
        return j;
    }

    public synchronized int putChars(CLOB clob, long l, char ac[], int i, int j)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(l >= 0L, 68);
        checkTrue(clob != null && (abyte0 = clob.getLocator()) != null, 54);
        if(ac == null)
        {
            return 0;
        } else
        {
            byte abyte1[][] = new byte[1][];
            clob.setActivePrefetch(false);
            clob.clearCachedData();
            int k = clobWrite(abyte0, l, ac, abyte1, clob.isNCLOB(), i, j);
            clob.setLocator(abyte1[0]);
            return k;
        }
    }

    public synchronized int getChunkSize(CLOB clob)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(clob != null && (abyte0 = clob.getLocator()) != null, 54);
        return lobGetChunkSize(abyte0);
    }

    public synchronized void trim(CLOB clob, long l)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(clob != null && (abyte0 = clob.shareBytes()) != null, 54);
        byte abyte1[][] = new byte[1][];
        clob.setActivePrefetch(false);
        clob.clearCachedData();
        checkError(t2cLobTrim(m_nativeState, 112, l, abyte0, abyte0.length, abyte1));
        clob.setShareBytes(abyte1[0]);
    }

    public synchronized CLOB createTemporaryClob(Connection connection, boolean flag, int i, short word0)
        throws SQLException
    {
        Object obj = null;
        checkTrue(lifecycle == 1, 8);
        if(word0 == 1)
            obj = new CLOB((PhysicalConnection)connection);
        else
            obj = new NCLOB((PhysicalConnection)connection);
        byte abyte0[][] = new byte[1][];
        checkError(t2cLobCreateTemporary(m_nativeState, 112, flag, i, word0, abyte0));
        ((CLOB) (obj)).setShareBytes(abyte0[0]);
        return ((CLOB) (obj));
    }

    public synchronized void freeTemporary(CLOB clob, boolean flag)
        throws SQLException
    {
        try
        {
            byte abyte0[] = null;
            checkTrue(lifecycle == 1, 8);
            checkTrue(clob != null && (abyte0 = clob.shareBytes()) != null, 54);
            byte abyte1[][] = new byte[1][];
            checkError(t2cLobFreeTemporary(m_nativeState, 112, abyte0, abyte0.length, abyte1));
            clob.setShareBytes(abyte1[0]);
        }
        catch(SQLException sqlexception)
        {
            if(flag & (sqlexception.getErrorCode() == 64201))
                LobPlsqlUtil.freeTemporaryLob(this, clob, 2005);
            else
                throw sqlexception;
        }
    }

    public synchronized boolean isTemporary(CLOB clob)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(clob != null && (abyte0 = clob.shareBytes()) != null, 54);
        boolean aflag[] = new boolean[1];
        checkError(t2cLobIsTemporary(m_nativeState, 112, abyte0, abyte0.length, aflag));
        return aflag[0];
    }

    public synchronized void open(CLOB clob, int i)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(clob != null && (abyte0 = clob.shareBytes()) != null, 54);
        byte abyte1[][] = new byte[1][];
        checkError(t2cLobOpen(m_nativeState, 112, abyte0, abyte0.length, i, abyte1));
        clob.setShareBytes(abyte1[0]);
    }

    public synchronized void close(CLOB clob)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(clob != null && (abyte0 = clob.shareBytes()) != null, 54);
        byte abyte1[][] = new byte[1][];
        checkError(t2cLobClose(m_nativeState, 112, abyte0, abyte0.length, abyte1));
        clob.setShareBytes(abyte1[0]);
    }

    public synchronized boolean isOpen(CLOB clob)
        throws SQLException
    {
        byte abyte0[] = null;
        checkTrue(lifecycle == 1, 8);
        checkTrue(clob != null && (abyte0 = clob.shareBytes()) != null, 54);
        boolean aflag[] = new boolean[1];
        checkError(t2cLobIsOpen(m_nativeState, 112, abyte0, abyte0.length, aflag));
        return aflag[0];
    }

    public InputStream newInputStream(CLOB clob, int i, long l)
        throws SQLException
    {
        if(l == 0L)
            return new OracleClobInputStream(clob, i);
        else
            return new OracleClobInputStream(clob, i, l);
    }

    public OutputStream newOutputStream(CLOB clob, int i, long l, boolean flag)
        throws SQLException
    {
        if(l == 0L)
        {
            if(flag & lobStreamPosStandardCompliant)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            } else
            {
                return new OracleClobOutputStream(clob, i);
            }
        } else
        {
            return new OracleClobOutputStream(clob, i, l);
        }
    }

    public Reader newReader(CLOB clob, int i, long l)
        throws SQLException
    {
        if(l == 0L)
            return new OracleClobReader(clob, i);
        else
            return new OracleClobReader(clob, i, l);
    }

    public Reader newReader(CLOB clob, int i, long l, long l1)
        throws SQLException
    {
        return new OracleClobReader(clob, i, l, l1);
    }

    public Writer newWriter(CLOB clob, int i, long l, boolean flag)
        throws SQLException
    {
        if(l == 0L)
        {
            if(flag & lobStreamPosStandardCompliant)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            } else
            {
                return new OracleClobWriter(clob, i);
            }
        } else
        {
            return new OracleClobWriter(clob, i, l);
        }
    }

    public synchronized void registerTAFCallback(OracleOCIFailover oracleocifailover, Object obj)
        throws SQLException
    {
        appCallback = oracleocifailover;
        appCallbackObject = obj;
        checkError(t2cRegisterTAFCallback(m_nativeState));
    }

    synchronized int callTAFCallbackMethod(int i, int j)
    {
        int k = 0;
        if(appCallback != null)
            k = appCallback.callbackFn(this, appCallbackObject, i, j);
        return k;
    }

    public int getHeapAllocSize()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        int i = t2cGetHeapAllocSize(m_nativeState);
        if(i < 0)
        {
            if(i == -999)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            } else
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        } else
        {
            return i;
        }
    }

    public int getOCIEnvHeapAllocSize()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        int i = t2cGetOciEnvHeapAllocSize(m_nativeState);
        if(i < 0)
        {
            if(i == -999)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            } else
            {
                checkError(i);
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        } else
        {
            return i;
        }
    }

    public static final short getClientCharSetId()
    {
        return 871;
    }

    public static short getDriverCharSetIdFromNLS_LANG()
        throws SQLException
    {
        if(!isLibraryLoaded)
            loadNativeLibrary();
        short word0 = t2cGetDriverCharSetFromNlsLang();
        if(word0 < 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return word0;
        }
    }

    void doProxySession(int i, Properties properties)
        throws SQLException
    {
        byte abyte4[][] = (byte[][])null;
        int j = 0;
        savedUser = userName;
        userName = null;
        byte abyte1[];
        byte abyte2[];
        byte abyte3[];
        byte abyte0[] = abyte1 = abyte2 = abyte3 = new byte[0];
        switch(i)
        {
        default:
            break;

        case 1: // '\001'
            userName = properties.getProperty("PROXY_USER_NAME");
            String s = properties.getProperty("PROXY_USER_PASSWORD");
            if(userName != null)
                abyte0 = DBConversion.stringToDriverCharBytes(userName, m_clientCharacterSet);
            if(s != null)
                abyte1 = DBConversion.stringToDriverCharBytes(s, m_clientCharacterSet);
            break;

        case 2: // '\002'
            String s1 = properties.getProperty("PROXY_DISTINGUISHED_NAME");
            if(s1 != null)
                abyte2 = DBConversion.stringToDriverCharBytes(s1, m_clientCharacterSet);
            break;

        case 3: // '\003'
            Object obj = properties.get("PROXY_CERTIFICATE");
            abyte3 = (byte[])(byte[])obj;
            break;
        }
        String as[] = (String[])(String[])properties.get("PROXY_ROLES");
        if(as != null)
        {
            j = as.length;
            abyte4 = new byte[j][];
            for(int k = 0; k < j; k++)
            {
                if(as[k] == null)
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                abyte4[k] = DBConversion.stringToDriverCharBytes(as[k], m_clientCharacterSet);
            }

        }
        sqlWarning = checkError(t2cDoProxySession(m_nativeState, i, abyte0, abyte0.length, abyte1, abyte1.length, abyte2, abyte2.length, abyte3, abyte3.length, j, abyte4), sqlWarning);
        isProxy = true;
    }

    void closeProxySession()
        throws SQLException
    {
        checkError(t2cCloseProxySession(m_nativeState));
        userName = savedUser;
    }

    protected void doDescribeTable(AutoKeyInfo autokeyinfo)
        throws SQLException
    {
        String s = autokeyinfo.getTableName();
        byte abyte0[] = DBConversion.stringToDriverCharBytes(s, m_clientCharacterSet);
        boolean flag;
        int i;
        do
        {
            flag = false;
            i = t2cDescribeTable(m_nativeState, abyte0, abyte0.length, queryMetaData1, queryMetaData2, queryMetaData1Offset, queryMetaData2Offset, queryMetaData1Size, queryMetaData2Size);
            if(i == -1)
                checkError(i);
            if(i == T2CStatement.T2C_EXTEND_BUFFER)
            {
                flag = true;
                reallocateQueryMetaData(queryMetaData1Size * 2, queryMetaData2Size * 2);
            }
        } while(flag);
        processDescribeTableData(i, autokeyinfo);
    }

    private void processDescribeTableData(int i, AutoKeyInfo autokeyinfo)
        throws SQLException
    {
        short aword0[] = queryMetaData1;
        byte abyte0[] = queryMetaData2;
        int j = queryMetaData1Offset;
        int k = queryMetaData2Offset;
        autokeyinfo.allocateSpaceForDescribedData(i);
        for(int l = 0; l < i; l++)
        {
            short word1 = aword0[j + 0];
            short word0 = aword0[j + 6];
            String s = bytes2String(abyte0, k, word0, conversion);
            short word2 = aword0[j + 1];
            short word3 = aword0[j + 11];
            boolean flag = aword0[j + 2] != 0;
            short word4 = aword0[j + 5];
            short word5 = aword0[j + 3];
            short word6 = aword0[j + 4];
            short word7 = aword0[j + 12];
            k += word0;
            j += 13;
            String s1 = null;
            if(word7 > 0)
            {
                s1 = bytes2String(abyte0, k, word7, conversion);
                k += word7;
            }
            autokeyinfo.fillDescribedData(l, s, word1, word3 <= 0 ? ((int) (word2)) : ((int) (word3)), flag, word4, word5, word6, s1);
        }

    }

    void doSetApplicationContext(String s, String s1, String s2)
        throws SQLException
    {
        checkError(t2cSetApplicationContext(m_nativeState, s, s1, s2));
    }

    void doClearAllApplicationContext(String s)
        throws SQLException
    {
        checkError(t2cClearAllApplicationContext(m_nativeState, s));
    }

    void doStartup(int i)
        throws SQLException
    {
        checkError(t2cStartupDatabase(m_nativeState, i));
    }

    void doShutdown(int i)
        throws SQLException
    {
        checkError(t2cShutdownDatabase(m_nativeState, i));
    }

    private static final void loadNativeLibrary()
        throws SQLException
    {
        synchronized(oracle/jdbc/driver/T2CConnection)
        {
            if(!isLibraryLoaded)
            {
                AccessController.doPrivileged(new PrivilegedAction() {

                    public Object run()
                    {
                        System.loadLibrary("ocijdbc11");
                        int i = T2CConnection.getLibraryVersionNumber();
                        if((long)i != T2CConnection.JDBC_OCI_LIBRARY_VERSION)
                            throw new Error((new StringBuilder()).append("Incompatible version of libocijdbc[Jdbc:").append(T2CConnection.JDBC_OCI_LIBRARY_VERSION).append(", Jdbc-OCI:").append(i).toString());
                        else
                            return null;
                    }

                }
);
                isLibraryLoaded = true;
            }
        }
    }

    private final void checkTrue(boolean flag, int i)
        throws SQLException
    {
        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), i);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    boolean useLittleEndianSetCHARBinder()
        throws SQLException
    {
        return t2cPlatformIsLittleEndian(m_nativeState);
    }

    public void getPropertyForPooledConnection(OraclePooledConnection oraclepooledconnection)
        throws SQLException
    {
        super.getPropertyForPooledConnection(oraclepooledconnection, password);
    }

    static final char[] getCharArray(String s)
    {
        char ac[] = null;
        if(s == null)
        {
            ac = new char[0];
        } else
        {
            ac = new char[s.length()];
            s.getChars(0, s.length(), ac, 0);
        }
        return ac;
    }

    static String bytes2String(byte abyte0[], int i, int j, DBConversion dbconversion)
        throws SQLException
    {
        byte abyte1[] = new byte[j];
        System.arraycopy(abyte0, i, abyte1, 0, j);
        return dbconversion.CharBytesToString(abyte1, j);
    }

    void disableNio()
    {
        useNio = false;
    }

    private static synchronized void doSetSessionTimeZone(String s)
        throws SQLException
    {
        t2cSetSessionTimeZone(s);
    }

    static native int getLibraryVersionNumber();

    static native short t2cGetServerSessionInfo(long l, Properties properties);

    static native short t2cGetDriverCharSetFromNlsLang();

    native int t2cDescribeError(long l, T2CError t2cerror, byte abyte0[]);

    native int t2cCreateState(byte abyte0[], int i, byte abyte1[], int j, byte abyte2[], int k, byte abyte3[], 
            int l, byte abyte4[], int i1, byte abyte5[], int j1, byte abyte6[], int k1, 
            short word0, int l1, short aword0[], byte abyte7[], byte abyte8[], boolean flag, long al[]);

    native int t2cLogon(long l, byte abyte0[], int i, byte abyte1[], int j, byte abyte2[], 
            int k, byte abyte3[], int i1, byte abyte4[], int j1, byte abyte5[], int k1, 
            byte abyte6[], int l1, int i2, short aword0[], byte abyte7[], byte abyte8[], long al[]);

    private native int t2cLogoff(long l);

    private native int t2cCancel(long l);

    private native byte t2cGetAsmVolProperty(long l);

    private native byte t2cGetInstanceType(long l);

    private native int t2cCreateStatement(long l, long l1, byte abyte0[], int i, oracle.jdbc.driver.OracleStatement oraclestatement, 
            boolean flag, int j);

    private native int t2cSetAutoCommit(long l, boolean flag);

    private native int t2cCommit(long l, int i);

    private native int t2cRollback(long l);

    private native int t2cPingDatabase(long l);

    private native byte[] t2cGetProductionVersion(long l);

    private native int t2cGetVersionNumber(long l);

    private native int t2cGetDefaultStreamChunkSize(long l);

    native int t2cGetFormOfUse(long l, OracleTypeCLOB oracletypeclob, byte abyte0[], int i, int j);

    native long t2cGetTDO(long l, byte abyte0[], int i, int ai[]);

    native int t2cCreateConnPool(byte abyte0[], int i, byte abyte1[], int j, byte abyte2[], int k, short word0, 
            int l, int i1, int j1, int k1, int l1, int i2, int j2);

    native int t2cConnPoolLogon(long l, byte abyte0[], int i, byte abyte1[], int j, byte abyte2[], 
            int k, byte abyte3[], int i1, byte abyte4[], int j1, int k1, int l1, 
            int i2, String as[], byte abyte5[], int j2, byte abyte6[], int k2, byte abyte7[], 
            int l2, byte abyte8[], int i3, byte abyte9[], int j3, short aword0[], byte abyte10[], 
            byte abyte11[], long al[]);

    native int t2cGetConnPoolInfo(long l, Properties properties);

    native int t2cSetConnPoolInfo(long l, int i, int j, int k, int i1, int j1, 
            int k1);

    native int t2cPasswordChange(long l, byte abyte0[], int i, byte abyte1[], int j, byte abyte2[], 
            int k);

    protected native byte[] t2cGetConnectionId(long l);

    native int t2cGetHandles(long l, long al[]);

    native int t2cUseConnection(long l, long l1, long l2, long l3, short aword0[], long al[]);

    native boolean t2cPlatformIsLittleEndian(long l);

    native int t2cRegisterTAFCallback(long l);

    native int t2cGetHeapAllocSize(long l);

    native int t2cGetOciEnvHeapAllocSize(long l);

    native int t2cDoProxySession(long l, int i, byte abyte0[], int j, byte abyte1[], int k, 
            byte abyte2[], int i1, byte abyte3[], int j1, int k1, byte abyte4[][]);

    native int t2cCloseProxySession(long l);

    static native int t2cDescribeTable(long l, byte abyte0[], int i, short aword0[], byte abyte1[], int j, int k, 
            int i1, int j1);

    native int t2cSetApplicationContext(long l, String s, String s1, String s2);

    native int t2cClearAllApplicationContext(long l, String s);

    native int t2cStartupDatabase(long l, int i);

    native int t2cShutdownDatabase(long l, int i);

    static native void t2cSetSessionTimeZone(String s);

    public void incrementTempLobReferenceCount(byte abyte0[])
        throws SQLException
    {
    }

    public int decrementTempLobReferenceCount(byte abyte0[])
        throws SQLException
    {
        return 0;
    }

    public volatile boolean isConnectionSocketKeepAlive()
        throws SocketException, SQLException
    {
        return super.isConnectionSocketKeepAlive();
    }

    public volatile EnumSet getTransactionState()
        throws SQLException
    {
        return super.getTransactionState();
    }

    public volatile long getCurrentSCN()
        throws SQLException
    {
        return super.getCurrentSCN();
    }

    public volatile boolean isLobStreamPosStandardCompliant()
        throws SQLException
    {
        return super.isLobStreamPosStandardCompliant();
    }

    public volatile boolean isDataInLocatorEnabled()
        throws SQLException
    {
        return super.isDataInLocatorEnabled();
    }

    public volatile TIMEZONETAB getTIMEZONETAB()
        throws SQLException
    {
        return super.getTIMEZONETAB();
    }

    public volatile int getTimezoneVersionNumber()
        throws SQLException
    {
        return super.getTimezoneVersionNumber();
    }

    public volatile TimeZone getDefaultTimeZone()
        throws SQLException
    {
        return super.getDefaultTimeZone();
    }

    public volatile void setDefaultTimeZone(TimeZone timezone)
        throws SQLException
    {
        super.setDefaultTimeZone(timezone);
    }

    public volatile void setUsable(boolean flag)
    {
        super.setUsable(flag);
    }

    public volatile boolean isUsable()
    {
        return super.isUsable();
    }

    public volatile TypeDescriptor[] getTypeDescriptorsFromList(String as[][])
        throws SQLException
    {
        return super.getTypeDescriptorsFromList(as);
    }

    public volatile TypeDescriptor[] getTypeDescriptorsFromListInCurrentSchema(String as[])
        throws SQLException
    {
        return super.getTypeDescriptorsFromListInCurrentSchema(as);
    }

    public volatile TypeDescriptor[] getAllTypeDescriptorsInCurrentSchema()
        throws SQLException
    {
        return super.getAllTypeDescriptorsInCurrentSchema();
    }

    public volatile void removeXSEventListener(XSEventListener xseventlistener)
        throws SQLException
    {
        super.removeXSEventListener(xseventlistener);
    }

    public volatile void addXSEventListener(XSEventListener xseventlistener, Executor executor)
        throws SQLException
    {
        super.addXSEventListener(xseventlistener, executor);
    }

    public volatile void addXSEventListener(XSEventListener xseventlistener)
        throws SQLException
    {
        super.addXSEventListener(xseventlistener);
    }

    public volatile void unregisterDatabaseChangeNotification(long l, String s)
        throws SQLException
    {
        super.unregisterDatabaseChangeNotification(l, s);
    }

    public volatile void unregisterDatabaseChangeNotification(int i, String s, int j)
        throws SQLException
    {
        super.unregisterDatabaseChangeNotification(i, s, j);
    }

    public volatile void unregisterDatabaseChangeNotification(int i)
        throws SQLException
    {
        super.unregisterDatabaseChangeNotification(i);
    }

    public volatile void unregisterDatabaseChangeNotification(DatabaseChangeRegistration databasechangeregistration)
        throws SQLException
    {
        super.unregisterDatabaseChangeNotification(databasechangeregistration);
    }

    public volatile DatabaseChangeRegistration getDatabaseChangeRegistration(int i)
        throws SQLException
    {
        return super.getDatabaseChangeRegistration(i);
    }

    public volatile DatabaseChangeRegistration registerDatabaseChangeNotification(Properties properties)
        throws SQLException
    {
        return super.registerDatabaseChangeNotification(properties);
    }

    public volatile void unregisterAQNotification(AQNotificationRegistration aqnotificationregistration)
        throws SQLException
    {
        super.unregisterAQNotification(aqnotificationregistration);
    }

    public volatile AQNotificationRegistration[] registerAQNotification(String as[], Properties aproperties[], Properties properties)
        throws SQLException
    {
        return super.registerAQNotification(as, aproperties, properties);
    }

    public volatile boolean getMapDateToTimestamp()
    {
        return super.getMapDateToTimestamp();
    }

    public volatile boolean isV8Compatible()
        throws SQLException
    {
        return super.isV8Compatible();
    }

    public volatile AQMessage dequeue(String s, AQDequeueOptions aqdequeueoptions, String s1)
        throws SQLException
    {
        return super.dequeue(s, aqdequeueoptions, s1);
    }

    public volatile AQMessage dequeue(String s, AQDequeueOptions aqdequeueoptions, byte abyte0[])
        throws SQLException
    {
        return super.dequeue(s, aqdequeueoptions, abyte0);
    }

    public volatile void enqueue(String s, AQEnqueueOptions aqenqueueoptions, AQMessage aqmessage)
        throws SQLException
    {
        super.enqueue(s, aqenqueueoptions, aqmessage);
    }

    public volatile void doXSNamespaceOp(oracle.jdbc.internal.OracleConnection.XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[])
        throws SQLException
    {
        super.doXSNamespaceOp(xsoperationcode, abyte0, axsnamespace);
    }

    public volatile void doXSNamespaceOp(oracle.jdbc.internal.OracleConnection.XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[], XSNamespace axsnamespace1[][])
        throws SQLException
    {
        super.doXSNamespaceOp(xsoperationcode, abyte0, axsnamespace, axsnamespace1);
    }

    public volatile void executeLightweightSessionPiggyback(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j)
        throws SQLException
    {
        super.executeLightweightSessionPiggyback(i, abyte0, akeywordvaluelong, j);
    }

    public volatile void executeLightweightSessionRoundtrip(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j, KeywordValueLong akeywordvaluelong1[][], int ai[])
        throws SQLException
    {
        super.executeLightweightSessionRoundtrip(i, abyte0, akeywordvaluelong, j, akeywordvaluelong1, ai);
    }

    public volatile byte[] createLightweightSession(String s, KeywordValueLong akeywordvaluelong[], int i, KeywordValueLong akeywordvaluelong1[][], int ai[])
        throws SQLException
    {
        return super.createLightweightSession(s, akeywordvaluelong, i, akeywordvaluelong1, ai);
    }

    public volatile void clearAllApplicationContext(String s)
        throws SQLException
    {
        super.clearAllApplicationContext(s);
    }

    public volatile void setApplicationContext(String s, String s1, String s2)
        throws SQLException
    {
        super.setApplicationContext(s, s1, s2);
    }

    public volatile XAResource getXAResource()
        throws SQLException
    {
        return super.getXAResource();
    }

    public volatile void setPlsqlWarnings(String s)
        throws SQLException
    {
        super.setPlsqlWarnings(s);
    }

    public volatile SQLXML createSQLXML()
        throws SQLException
    {
        return super.createSQLXML();
    }

    public volatile NClob createNClob()
        throws SQLException
    {
        return super.createNClob();
    }

    public volatile Clob createClob()
        throws SQLException
    {
        return super.createClob();
    }

    public volatile Blob createBlob()
        throws SQLException
    {
        return super.createBlob();
    }

    public volatile TIMESTAMPLTZ createTIMESTAMPLTZ(DATE date, Calendar calendar)
        throws SQLException
    {
        return super.createTIMESTAMPLTZ(date, calendar);
    }

    public volatile TIMESTAMPLTZ createTIMESTAMPLTZ(String s, Calendar calendar)
        throws SQLException
    {
        return super.createTIMESTAMPLTZ(s, calendar);
    }

    public volatile TIMESTAMPLTZ createTIMESTAMPLTZ(Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        return super.createTIMESTAMPLTZ(timestamp, calendar);
    }

    public volatile TIMESTAMPLTZ createTIMESTAMPLTZ(Time time, Calendar calendar)
        throws SQLException
    {
        return super.createTIMESTAMPLTZ(time, calendar);
    }

    public volatile TIMESTAMPLTZ createTIMESTAMPLTZ(Date date, Calendar calendar)
        throws SQLException
    {
        return super.createTIMESTAMPLTZ(date, calendar);
    }

    public volatile TIMESTAMPTZ createTIMESTAMPTZ(DATE date)
        throws SQLException
    {
        return super.createTIMESTAMPTZ(date);
    }

    public volatile TIMESTAMPTZ createTIMESTAMPTZ(String s, Calendar calendar)
        throws SQLException
    {
        return super.createTIMESTAMPTZ(s, calendar);
    }

    public volatile TIMESTAMPTZ createTIMESTAMPTZ(String s)
        throws SQLException
    {
        return super.createTIMESTAMPTZ(s);
    }

    public volatile TIMESTAMPTZ createTIMESTAMPTZ(Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        return super.createTIMESTAMPTZ(timestamp, calendar);
    }

    public volatile TIMESTAMPTZ createTIMESTAMPTZ(Timestamp timestamp)
        throws SQLException
    {
        return super.createTIMESTAMPTZ(timestamp);
    }

    public volatile TIMESTAMPTZ createTIMESTAMPTZ(Time time, Calendar calendar)
        throws SQLException
    {
        return super.createTIMESTAMPTZ(time, calendar);
    }

    public volatile TIMESTAMPTZ createTIMESTAMPTZ(Time time)
        throws SQLException
    {
        return super.createTIMESTAMPTZ(time);
    }

    public volatile TIMESTAMPTZ createTIMESTAMPTZ(Date date, Calendar calendar)
        throws SQLException
    {
        return super.createTIMESTAMPTZ(date, calendar);
    }

    public volatile TIMESTAMPTZ createTIMESTAMPTZ(Date date)
        throws SQLException
    {
        return super.createTIMESTAMPTZ(date);
    }

    public volatile TIMESTAMP createTIMESTAMP(String s)
        throws SQLException
    {
        return super.createTIMESTAMP(s);
    }

    public volatile TIMESTAMP createTIMESTAMP(Timestamp timestamp)
        throws SQLException
    {
        return super.createTIMESTAMP(timestamp);
    }

    public volatile TIMESTAMP createTIMESTAMP(Time time)
        throws SQLException
    {
        return super.createTIMESTAMP(time);
    }

    public volatile TIMESTAMP createTIMESTAMP(DATE date)
        throws SQLException
    {
        return super.createTIMESTAMP(date);
    }

    public volatile TIMESTAMP createTIMESTAMP(Date date)
        throws SQLException
    {
        return super.createTIMESTAMP(date);
    }

    public volatile Struct createStruct(String s, Object aobj[])
        throws SQLException
    {
        return super.createStruct(s, aobj);
    }

    public volatile Array createArrayOf(String s, Object aobj[])
        throws SQLException
    {
        return super.createArrayOf(s, aobj);
    }

    public volatile NUMBER createNUMBER(String s, int i)
        throws SQLException
    {
        return super.createNUMBER(s, i);
    }

    public volatile NUMBER createNUMBER(BigInteger biginteger)
        throws SQLException
    {
        return super.createNUMBER(biginteger);
    }

    public volatile NUMBER createNUMBER(BigDecimal bigdecimal)
        throws SQLException
    {
        return super.createNUMBER(bigdecimal);
    }

    public volatile NUMBER createNUMBER(double d)
        throws SQLException
    {
        return super.createNUMBER(d);
    }

    public volatile NUMBER createNUMBER(float f)
        throws SQLException
    {
        return super.createNUMBER(f);
    }

    public volatile NUMBER createNUMBER(long l)
        throws SQLException
    {
        return super.createNUMBER(l);
    }

    public volatile NUMBER createNUMBER(int i)
        throws SQLException
    {
        return super.createNUMBER(i);
    }

    public volatile NUMBER createNUMBER(short word0)
        throws SQLException
    {
        return super.createNUMBER(word0);
    }

    public volatile NUMBER createNUMBER(byte byte0)
        throws SQLException
    {
        return super.createNUMBER(byte0);
    }

    public volatile NUMBER createNUMBER(boolean flag)
        throws SQLException
    {
        return super.createNUMBER(flag);
    }

    public volatile INTERVALYM createINTERVALYM(String s)
        throws SQLException
    {
        return super.createINTERVALYM(s);
    }

    public volatile INTERVALDS createINTERVALDS(String s)
        throws SQLException
    {
        return super.createINTERVALDS(s);
    }

    public volatile DATE createDATE(String s)
        throws SQLException
    {
        return super.createDATE(s);
    }

    public volatile DATE createDATE(Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        return super.createDATE(timestamp, calendar);
    }

    public volatile DATE createDATE(Time time, Calendar calendar)
        throws SQLException
    {
        return super.createDATE(time, calendar);
    }

    public volatile DATE createDATE(Date date, Calendar calendar)
        throws SQLException
    {
        return super.createDATE(date, calendar);
    }

    public volatile DATE createDATE(Timestamp timestamp)
        throws SQLException
    {
        return super.createDATE(timestamp);
    }

    public volatile DATE createDATE(Time time)
        throws SQLException
    {
        return super.createDATE(time);
    }

    public volatile DATE createDATE(Date date)
        throws SQLException
    {
        return super.createDATE(date);
    }

    public volatile BINARY_FLOAT createBINARY_FLOAT(float f)
        throws SQLException
    {
        return super.createBINARY_FLOAT(f);
    }

    public volatile BINARY_DOUBLE createBINARY_DOUBLE(double d)
        throws SQLException
    {
        return super.createBINARY_DOUBLE(d);
    }

    public volatile Array createOracleArray(String s, Object obj)
        throws SQLException
    {
        return super.createOracleArray(s, obj);
    }

    public volatile ARRAY createARRAY(String s, Object obj)
        throws SQLException
    {
        return super.createARRAY(s, obj);
    }

    public volatile BFILE createBfile(byte abyte0[])
        throws SQLException
    {
        return super.createBfile(abyte0);
    }

    public volatile BLOB createBlobWithUnpickledBytes(byte abyte0[])
        throws SQLException
    {
        return super.createBlobWithUnpickledBytes(abyte0);
    }

    public volatile BLOB createBlob(byte abyte0[])
        throws SQLException
    {
        return super.createBlob(abyte0);
    }

    public volatile CLOB createClob(byte abyte0[], short word0)
        throws SQLException
    {
        return super.createClob(abyte0, word0);
    }

    public volatile CLOB createClobWithUnpickledBytes(byte abyte0[])
        throws SQLException
    {
        return super.createClobWithUnpickledBytes(abyte0);
    }

    public volatile CLOB createClob(byte abyte0[])
        throws SQLException
    {
        return super.createClob(abyte0);
    }

    public volatile Connection getLogicalConnection(OraclePooledConnection oraclepooledconnection, boolean flag)
        throws SQLException
    {
        return super.getLogicalConnection(oraclepooledconnection, flag);
    }

    public volatile OracleStatement refCursorCursorToStatement(int i)
        throws SQLException
    {
        return super.refCursorCursorToStatement(i);
    }

    public volatile int javaCharsToNCHARBytes(char ac[], int i, byte abyte0[])
        throws SQLException
    {
        return super.javaCharsToNCHARBytes(ac, i, abyte0);
    }

    public volatile int javaCharsToCHARBytes(char ac[], int i, byte abyte0[])
        throws SQLException
    {
        return super.javaCharsToCHARBytes(ac, i, abyte0);
    }

    public volatile boolean isCharSetMultibyte(short word0)
    {
        return super.isCharSetMultibyte(word0);
    }

    public volatile int getMaxNCharbyteSize()
    {
        return super.getMaxNCharbyteSize();
    }

    public volatile int getMaxCharbyteSize()
    {
        return super.getMaxCharbyteSize();
    }

    public volatile int getMaxCharSize()
        throws SQLException
    {
        return super.getMaxCharSize();
    }

    public volatile short getDriverCharSet()
    {
        return super.getDriverCharSet();
    }

    public volatile boolean IsNCharFixedWith()
    {
        return super.IsNCharFixedWith();
    }

    public volatile int NCHARBytesToJavaChars(byte abyte0[], int i, char ac[])
        throws SQLException
    {
        return super.NCHARBytesToJavaChars(abyte0, i, ac);
    }

    public volatile int CHARBytesToJavaChars(byte abyte0[], int i, char ac[])
        throws SQLException
    {
        return super.CHARBytesToJavaChars(abyte0, i, ac);
    }

    public volatile ResultSetMetaData newStructMetaData(StructDescriptor structdescriptor)
        throws SQLException
    {
        return super.newStructMetaData(structdescriptor);
    }

    public volatile ResultSet newArrayLocatorResultSet(ArrayDescriptor arraydescriptor, byte abyte0[], long l, int i, Map map)
        throws SQLException
    {
        return super.newArrayLocatorResultSet(arraydescriptor, abyte0, l, i, map);
    }

    public volatile ResultSet newArrayDataResultSet(ARRAY array, long l, int i, Map map)
        throws SQLException
    {
        return super.newArrayDataResultSet(array, l, i, map);
    }

    public volatile ResultSet newArrayDataResultSet(Datum adatum[], long l, int i, Map map)
        throws SQLException
    {
        return super.newArrayDataResultSet(adatum, l, i, map);
    }

    public volatile short getNCharSet()
    {
        return super.getNCharSet();
    }

    public volatile Datum toDatum(CustomDatum customdatum)
        throws SQLException
    {
        return super.toDatum(customdatum);
    }

    public volatile void getOracleTypeADT(OracleTypeADT oracletypeadt)
        throws SQLException
    {
        super.getOracleTypeADT(oracletypeadt);
    }

    public volatile OracleConnection physicalConnectionWithin()
    {
        return super.physicalConnectionWithin();
    }

    public volatile oracle.jdbc.OracleConnection getWrapper()
    {
        return super.getWrapper();
    }

    public volatile oracle.jdbc.OracleConnection unwrap()
    {
        return super.unwrap();
    }

    public volatile void setWrapper(oracle.jdbc.OracleConnection oracleconnection)
    {
        super.setWrapper(oracleconnection);
    }

    public volatile Class safelyGetClassForName(String s)
        throws ClassNotFoundException
    {
        return super.safelyGetClassForName(s);
    }

    public volatile Class classForNameAndSchema(String s, String s1)
        throws ClassNotFoundException
    {
        return super.classForNameAndSchema(s, s1);
    }

    public volatile boolean getJ2EE13Compliant()
    {
        return super.getJ2EE13Compliant();
    }

    public volatile void setJ2EE13Compliant(boolean flag)
    {
        super.setJ2EE13Compliant(flag);
    }

    public volatile boolean isAccumulateBatchResult()
    {
        return super.isAccumulateBatchResult();
    }

    public volatile void setAccumulateBatchResult(boolean flag)
    {
        super.setAccumulateBatchResult(flag);
    }

    public volatile Calendar getDbTzCalendar()
        throws SQLException
    {
        return super.getDbTzCalendar();
    }

    public volatile String getSessionTimeZoneOffset()
        throws SQLException
    {
        return super.getSessionTimeZoneOffset();
    }

    public volatile String tzToOffset(String s)
    {
        return super.tzToOffset(s);
    }

    public volatile String getSessionTimeZone()
    {
        return super.getSessionTimeZone();
    }

    public volatile String getDatabaseTimeZone()
        throws SQLException
    {
        return super.getDatabaseTimeZone();
    }

    public volatile void setSessionTimeZone(String s)
        throws SQLException
    {
        super.setSessionTimeZone(s);
    }

    public volatile void setClientIdentifier(String s)
        throws SQLException
    {
        super.setClientIdentifier(s);
    }

    public volatile void clearClientIdentifier(String s)
        throws SQLException
    {
        super.clearClientIdentifier(s);
    }

    public volatile void setJavaObjectTypeMap(Map map)
    {
        super.setJavaObjectTypeMap(map);
    }

    public volatile Map getJavaObjectTypeMap()
    {
        return super.getJavaObjectTypeMap();
    }

    public volatile int pingDatabase(int i)
        throws SQLException
    {
        return super.pingDatabase(i);
    }

    public volatile int pingDatabase()
        throws SQLException
    {
        return super.pingDatabase();
    }

    public volatile boolean getCreateStatementAsRefCursor()
    {
        return super.getCreateStatementAsRefCursor();
    }

    public volatile void setCreateStatementAsRefCursor(boolean flag)
    {
        super.setCreateStatementAsRefCursor(flag);
    }

    public volatile void registerCloseCallback(OracleCloseCallback oracleclosecallback, Object obj)
    {
        super.registerCloseCallback(oracleclosecallback, obj);
    }

    public volatile short getVersionNumber()
        throws SQLException
    {
        return super.getVersionNumber();
    }

    public volatile boolean getReportRemarks()
    {
        return super.getReportRemarks();
    }

    public volatile String getDatabaseProductVersion()
        throws SQLException
    {
        return super.getDatabaseProductVersion();
    }

    public volatile oracle.jdbc.internal.OracleConnection.BufferCacheStatistics getCharBufferCacheStatistics()
    {
        return super.getCharBufferCacheStatistics();
    }

    public volatile oracle.jdbc.internal.OracleConnection.BufferCacheStatistics getByteBufferCacheStatistics()
    {
        return super.getByteBufferCacheStatistics();
    }

    public volatile char[] getCharBufferSync(int i)
    {
        return super.getCharBufferSync(i);
    }

    public volatile void cacheBufferSync(char ac[])
    {
        super.cacheBufferSync(ac);
    }

    public volatile boolean isStatementCacheInitialized()
    {
        return super.isStatementCacheInitialized();
    }

    public volatile void cacheExplicitStatement(OraclePreparedStatement oraclepreparedstatement, String s)
        throws SQLException
    {
        super.cacheExplicitStatement(oraclepreparedstatement, s);
    }

    public volatile void cacheImplicitStatement(OraclePreparedStatement oraclepreparedstatement, String s, int i, int j)
        throws SQLException
    {
        super.cacheImplicitStatement(oraclepreparedstatement, s, i, j);
    }

    public volatile CallableStatement getCallWithKey(String s)
        throws SQLException
    {
        return super.getCallWithKey(s);
    }

    public volatile PreparedStatement getStatementWithKey(String s)
        throws SQLException
    {
        return super.getStatementWithKey(s);
    }

    public volatile void purgeExplicitCache()
        throws SQLException
    {
        super.purgeExplicitCache();
    }

    public volatile void purgeImplicitCache()
        throws SQLException
    {
        super.purgeImplicitCache();
    }

    public volatile boolean getExplicitCachingEnabled()
        throws SQLException
    {
        return super.getExplicitCachingEnabled();
    }

    public volatile void setExplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        super.setExplicitCachingEnabled(flag);
    }

    public volatile boolean getImplicitCachingEnabled()
        throws SQLException
    {
        return super.getImplicitCachingEnabled();
    }

    public volatile void setImplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        super.setImplicitCachingEnabled(flag);
    }

    public volatile int getStatementCacheSize()
        throws SQLException
    {
        return super.getStatementCacheSize();
    }

    public volatile void setStatementCacheSize(int i)
        throws SQLException
    {
        super.setStatementCacheSize(i);
    }

    public volatile int getStmtCacheSize()
    {
        return super.getStmtCacheSize();
    }

    public volatile void setStmtCacheSize(int i, boolean flag)
        throws SQLException
    {
        super.setStmtCacheSize(i, flag);
    }

    public volatile void setStmtCacheSize(int i)
        throws SQLException
    {
        super.setStmtCacheSize(i);
    }

    public volatile String getURL()
    {
        return super.getURL();
    }

    public volatile String getProtocolType()
    {
        return super.getProtocolType();
    }

    public volatile void printState()
    {
        super.printState();
    }

    public volatile Object removeClientData(Object obj)
    {
        return super.removeClientData(obj);
    }

    public volatile Object setClientData(Object obj, Object obj1)
    {
        return super.setClientData(obj, obj1);
    }

    public volatile Object getClientData(Object obj)
    {
        return super.getClientData(obj);
    }

    public volatile int getTxnMode()
    {
        return super.getTxnMode();
    }

    public volatile void setTxnMode(int i)
    {
        super.setTxnMode(i);
    }

    public volatile void oracleReleaseSavepoint(OracleSavepoint oraclesavepoint)
        throws SQLException
    {
        super.oracleReleaseSavepoint(oraclesavepoint);
    }

    public volatile void oracleRollback(OracleSavepoint oraclesavepoint)
        throws SQLException
    {
        super.oracleRollback(oraclesavepoint);
    }

    public volatile OracleSavepoint oracleSetSavepoint(String s)
        throws SQLException
    {
        return super.oracleSetSavepoint(s);
    }

    public volatile OracleSavepoint oracleSetSavepoint()
        throws SQLException
    {
        return super.oracleSetSavepoint();
    }

    public volatile PreparedStatement prepareStatement(String s, String as[])
        throws SQLException
    {
        return super.prepareStatement(s, as);
    }

    public volatile PreparedStatement prepareStatement(String s, int ai[])
        throws SQLException
    {
        return super.prepareStatement(s, ai);
    }

    public volatile PreparedStatement prepareStatement(String s, int i)
        throws SQLException
    {
        return super.prepareStatement(s, i);
    }

    public volatile CallableStatement prepareCall(String s, int i, int j, int k)
        throws SQLException
    {
        return super.prepareCall(s, i, j, k);
    }

    public volatile PreparedStatement prepareStatement(String s, int i, int j, int k)
        throws SQLException
    {
        return super.prepareStatement(s, i, j, k);
    }

    public volatile Statement createStatement(int i, int j, int k)
        throws SQLException
    {
        return super.createStatement(i, j, k);
    }

    public volatile void releaseSavepoint(Savepoint savepoint)
        throws SQLException
    {
        super.releaseSavepoint(savepoint);
    }

    public volatile void rollback(Savepoint savepoint)
        throws SQLException
    {
        super.rollback(savepoint);
    }

    public volatile Savepoint setSavepoint(String s)
        throws SQLException
    {
        return super.setSavepoint(s);
    }

    public volatile Savepoint setSavepoint()
        throws SQLException
    {
        return super.setSavepoint();
    }

    public volatile int getHoldability()
        throws SQLException
    {
        return super.getHoldability();
    }

    public volatile void setHoldability(int i)
        throws SQLException
    {
        super.setHoldability(i);
    }

    public volatile boolean getBigEndian()
        throws SQLException
    {
        return super.getBigEndian();
    }

    public volatile void setFDO(byte abyte0[])
        throws SQLException
    {
        super.setFDO(abyte0);
    }

    public volatile byte[] getFDO(boolean flag)
        throws SQLException
    {
        return super.getFDO(flag);
    }

    public volatile int getHeartbeatNoChangeCount()
        throws SQLException
    {
        return super.getHeartbeatNoChangeCount();
    }

    public volatile long getStartTime()
        throws SQLException
    {
        return super.getStartTime();
    }

    public volatile void setStartTime(long l)
        throws SQLException
    {
        super.setStartTime(l);
    }

    public volatile String getDefaultSchemaNameForNamedTypes()
        throws SQLException
    {
        return super.getDefaultSchemaNameForNamedTypes();
    }

    public volatile String getCurrentSchema()
        throws SQLException
    {
        return super.getCurrentSchema();
    }

    public volatile String getUserName()
        throws SQLException
    {
        return super.getUserName();
    }

    public volatile boolean getXAErrorFlag()
    {
        return super.getXAErrorFlag();
    }

    public volatile void setXAErrorFlag(boolean flag)
    {
        super.setXAErrorFlag(flag);
    }

    public volatile boolean getUsingXAFlag()
    {
        return super.getUsingXAFlag();
    }

    public volatile void setUsingXAFlag(boolean flag)
    {
        super.setUsingXAFlag(flag);
    }

    public volatile void setTypeMap(Map map)
    {
        super.setTypeMap(map);
    }

    public volatile Map getTypeMap()
    {
        return super.getTypeMap();
    }

    public volatile short getStructAttrNCsId()
        throws SQLException
    {
        return super.getStructAttrNCsId();
    }

    public volatile short getStructAttrCsId()
        throws SQLException
    {
        return super.getStructAttrCsId();
    }

    public volatile short getNCsId()
        throws SQLException
    {
        return super.getNCsId();
    }

    public volatile short getDbCsId()
        throws SQLException
    {
        return super.getDbCsId();
    }

    public volatile short getJdbcCsId()
        throws SQLException
    {
        return super.getJdbcCsId();
    }

    public volatile void removeDecriptor(byte abyte0[])
    {
        super.removeDecriptor(abyte0);
    }

    public volatile Object getDescriptor(byte abyte0[])
    {
        return super.getDescriptor(abyte0);
    }

    public volatile void putDescriptor(byte abyte0[], Object obj)
        throws SQLException
    {
        super.putDescriptor(abyte0, obj);
    }

    public volatile Enumeration descriptorCacheKeys()
    {
        return super.descriptorCacheKeys();
    }

    public volatile int numberOfDescriptorCacheEntries()
    {
        return super.numberOfDescriptorCacheEntries();
    }

    public volatile void removeAllDescriptor()
    {
        super.removeAllDescriptor();
    }

    public volatile void removeDescriptor(String s)
    {
        super.removeDescriptor(s);
    }

    public volatile void removeDecriptor(String s)
    {
        super.removeDecriptor(s);
    }

    public volatile Object getDescriptor(String s)
    {
        return super.getDescriptor(s);
    }

    public volatile void putDescriptor(String s, Object obj)
        throws SQLException
    {
        super.putDescriptor(s, obj);
    }

    public volatile Object getJavaObject(String s)
        throws SQLException
    {
        return super.getJavaObject(s);
    }

    public volatile String getSQLType(Object obj)
        throws SQLException
    {
        return super.getSQLType(obj);
    }

    public volatile void registerSQLType(String s, Class class1)
        throws SQLException
    {
        super.registerSQLType(s, class1);
    }

    public volatile void registerSQLType(String s, String s1)
        throws SQLException
    {
        super.registerSQLType(s, s1);
    }

    public volatile void archive(int i, int j, String s)
        throws SQLException
    {
        super.archive(i, j, s);
    }

    public volatile void shutdown(oracle.jdbc.OracleConnection.DatabaseShutdownMode databaseshutdownmode)
        throws SQLException
    {
        super.shutdown(databaseshutdownmode);
    }

    public volatile void startup(oracle.jdbc.OracleConnection.DatabaseStartupMode databasestartupmode)
        throws SQLException
    {
        super.startup(databasestartupmode);
    }

    public volatile void startup(String s, int i)
        throws SQLException
    {
        super.startup(s, i);
    }

    public volatile int getC2SNlsRatio()
    {
        return super.getC2SNlsRatio();
    }

    public volatile int getNlsRatio()
    {
        return super.getNlsRatio();
    }

    public volatile boolean getDefaultFixedString()
    {
        return super.getDefaultFixedString();
    }

    public volatile void setDefaultNChar(boolean flag)
    {
        super.setDefaultNChar(flag);
    }

    public volatile void setDefaultFixedString(boolean flag)
    {
        super.setDefaultFixedString(flag);
    }

    public volatile boolean getRestrictGetTables()
    {
        return super.getRestrictGetTables();
    }

    public volatile void setRestrictGetTables(boolean flag)
    {
        super.setRestrictGetTables(flag);
    }

    public volatile boolean getIncludeSynonyms()
    {
        return super.getIncludeSynonyms();
    }

    public volatile void setEndToEndMetrics(String as[], short word0)
        throws SQLException
    {
        super.setEndToEndMetrics(as, word0);
    }

    public volatile short getEndToEndECIDSequenceNumber()
        throws SQLException
    {
        return super.getEndToEndECIDSequenceNumber();
    }

    public volatile String[] getEndToEndMetrics()
        throws SQLException
    {
        return super.getEndToEndMetrics();
    }

    public volatile void setIncludeSynonyms(boolean flag)
    {
        super.setIncludeSynonyms(flag);
    }

    public volatile boolean getRemarksReporting()
    {
        return super.getRemarksReporting();
    }

    public volatile void setRemarksReporting(boolean flag)
    {
        super.setRemarksReporting(flag);
    }

    public volatile int getDefaultExecuteBatch()
    {
        return super.getDefaultExecuteBatch();
    }

    public volatile void setDefaultExecuteBatch(int i)
        throws SQLException
    {
        super.setDefaultExecuteBatch(i);
    }

    public volatile boolean getUse1900AsYearForTime()
    {
        return super.getUse1900AsYearForTime();
    }

    public volatile boolean getTimestamptzInGmt()
    {
        return super.getTimestamptzInGmt();
    }

    public volatile int getDefaultRowPrefetch()
    {
        return super.getDefaultRowPrefetch();
    }

    public volatile void setDefaultRowPrefetch(int i)
        throws SQLException
    {
        super.setDefaultRowPrefetch(i);
    }

    public volatile void setWarnings(SQLWarning sqlwarning)
    {
        super.setWarnings(sqlwarning);
    }

    public volatile void clearWarnings()
        throws SQLException
    {
        super.clearWarnings();
    }

    public volatile SQLWarning getWarnings()
        throws SQLException
    {
        return super.getWarnings();
    }

    public volatile boolean getAutoClose()
        throws SQLException
    {
        return super.getAutoClose();
    }

    public volatile void setAutoClose(boolean flag)
        throws SQLException
    {
        super.setAutoClose(flag);
    }

    public volatile int getTransactionIsolation()
        throws SQLException
    {
        return super.getTransactionIsolation();
    }

    public volatile void setTransactionIsolation(int i)
        throws SQLException
    {
        super.setTransactionIsolation(i);
    }

    public volatile String getCatalog()
        throws SQLException
    {
        return super.getCatalog();
    }

    public volatile void setCatalog(String s)
        throws SQLException
    {
        super.setCatalog(s);
    }

    public volatile boolean isReadOnly()
        throws SQLException
    {
        return super.isReadOnly();
    }

    public volatile void setReadOnly(boolean flag)
        throws SQLException
    {
        super.setReadOnly(flag);
    }

    public volatile DatabaseMetaData getMetaData()
        throws SQLException
    {
        return super.getMetaData();
    }

    public volatile void openProxySession(int i, Properties properties)
        throws SQLException
    {
        super.openProxySession(i, properties);
    }

    public volatile boolean isProxySession()
    {
        return super.isProxySession();
    }

    public volatile boolean isClosed()
        throws SQLException
    {
        return super.isClosed();
    }

    public volatile int getConnectionReleasePriority()
        throws SQLException
    {
        return super.getConnectionReleasePriority();
    }

    public volatile void setConnectionReleasePriority(int i)
        throws SQLException
    {
        super.setConnectionReleasePriority(i);
    }

    public volatile int getConnectionCacheCallbackFlag()
        throws SQLException
    {
        return super.getConnectionCacheCallbackFlag();
    }

    public volatile Object getConnectionCacheCallbackPrivObj()
        throws SQLException
    {
        return super.getConnectionCacheCallbackPrivObj();
    }

    public volatile OracleConnectionCacheCallback getConnectionCacheCallbackObj()
        throws SQLException
    {
        return super.getConnectionCacheCallbackObj();
    }

    public volatile void registerConnectionCacheCallback(OracleConnectionCacheCallback oracleconnectioncachecallback, Object obj, int i)
        throws SQLException
    {
        super.registerConnectionCacheCallback(oracleconnectioncachecallback, obj, i);
    }

    public volatile void setAbandonedTimeoutEnabled(boolean flag)
        throws SQLException
    {
        super.setAbandonedTimeoutEnabled(flag);
    }

    public volatile Properties getUnMatchedConnectionAttributes()
        throws SQLException
    {
        return super.getUnMatchedConnectionAttributes();
    }

    public volatile Properties getConnectionAttributes()
        throws SQLException
    {
        return super.getConnectionAttributes();
    }

    public volatile void applyConnectionAttributes(Properties properties)
        throws SQLException
    {
        super.applyConnectionAttributes(properties);
    }

    public volatile void abort()
        throws SQLException
    {
        super.abort();
    }

    public volatile void close(int i)
        throws SQLException
    {
        super.close(i);
    }

    public volatile void close(Properties properties)
        throws SQLException
    {
        super.close(properties);
    }

    public volatile void cleanupAndClose(boolean flag)
        throws SQLException
    {
        super.cleanupAndClose(flag);
    }

    public volatile void closeInternal(boolean flag)
        throws SQLException
    {
        super.closeInternal(flag);
    }

    public volatile String getAuthenticationAdaptorName()
        throws SQLException
    {
        return super.getAuthenticationAdaptorName();
    }

    public volatile String getEncryptionAlgorithmName()
        throws SQLException
    {
        return super.getEncryptionAlgorithmName();
    }

    public volatile String getDataIntegrityAlgorithmName()
        throws SQLException
    {
        return super.getDataIntegrityAlgorithmName();
    }

    public volatile void close()
        throws SQLException
    {
        super.close();
    }

    public volatile void rollback()
        throws SQLException
    {
        super.rollback();
    }

    public volatile void commit()
        throws SQLException
    {
        super.commit();
    }

    public volatile void commit(EnumSet enumset)
        throws SQLException
    {
        super.commit(enumset);
    }

    public volatile void cancel()
        throws SQLException
    {
        super.cancel();
    }

    public volatile boolean getAutoCommit()
        throws SQLException
    {
        return super.getAutoCommit();
    }

    public volatile void setAutoCommit(boolean flag)
        throws SQLException
    {
        super.setAutoCommit(flag);
    }

    public volatile String nativeSQL(String s)
        throws SQLException
    {
        return super.nativeSQL(s);
    }

    public volatile CallableStatement prepareCallWithKey(String s)
        throws SQLException
    {
        return super.prepareCallWithKey(s);
    }

    public volatile CallableStatement prepareCall(String s, int i, int j)
        throws SQLException
    {
        return super.prepareCall(s, i, j);
    }

    public volatile CallableStatement prepareCall(String s)
        throws SQLException
    {
        return super.prepareCall(s);
    }

    public volatile PreparedStatement prepareStatement(String s, int i, int j)
        throws SQLException
    {
        return super.prepareStatement(s, i, j);
    }

    public volatile PreparedStatement prepareStatementWithKey(String s)
        throws SQLException
    {
        return super.prepareStatementWithKey(s);
    }

    public volatile PreparedStatement prepareStatement(String s)
        throws SQLException
    {
        return super.prepareStatement(s);
    }

    public volatile Statement createStatement(int i, int j)
        throws SQLException
    {
        return super.createStatement(i, j);
    }

    public volatile Statement createStatement()
        throws SQLException
    {
        return super.createStatement();
    }

    public volatile boolean isLogicalConnection()
    {
        return super.isLogicalConnection();
    }

    public volatile OracleConnection getPhysicalConnection()
    {
        return super.getPhysicalConnection();
    }

    public volatile Connection _getPC()
    {
        return super._getPC();
    }

    public volatile Properties getProperties()
    {
        return super.getProperties();
    }

}
