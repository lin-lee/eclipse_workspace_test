// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C8TTIBlob.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import oracle.sql.BLOB;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.driver:
//            T4C8TTILob, DatabaseError, T4CConnection

final class T4C8TTIBlob extends T4C8TTILob
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C8TTIBlob(T4CConnection t4cconnection)
    {
        super(t4cconnection);
    }

    Datum createTemporaryLob(Connection connection, boolean flag, int i)
        throws SQLException, IOException
    {
        if(i == 12)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 158);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        BLOB blob = null;
        initializeLobdef();
        lobops = 272L;
        sourceLobLocator = new byte[40];
        sourceLobLocator[1] = 84;
        characterSet = 1;
        destinationOffset = 113L;
        destinationLength = i;
        lobamt = i;
        sendLobamt = true;
        nullO2U = true;
        if(this.connection.versionNumber >= 9000)
        {
            lobscn = new int[1];
            lobscn[0] = flag ? 1 : 0;
            lobscnl = 1;
        }
        doRPC();
        if(sourceLobLocator != null)
            blob = new BLOB((OracleConnection)connection, sourceLobLocator);
        return blob;
    }

    boolean open(byte abyte0[], int i)
        throws SQLException, IOException
    {
        boolean flag = false;
        byte byte0 = 2;
        if(i == 0)
            byte0 = 1;
        flag = _open(abyte0, byte0, 32768);
        return flag;
    }

    boolean close(byte abyte0[])
        throws SQLException, IOException
    {
        boolean flag = false;
        flag = _close(abyte0, 0x10000);
        return flag;
    }

    boolean isOpen(byte abyte0[])
        throws SQLException, IOException
    {
        boolean flag = false;
        flag = _isOpen(abyte0, 0x11000);
        return flag;
    }

}
