// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleCallableStatementWrapper.java

package oracle.jdbc.driver;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.OracleDataFactory;
import oracle.jdbc.internal.OracleCallableStatement;
import oracle.sql.ARRAY;
import oracle.sql.BFILE;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BLOB;
import oracle.sql.CHAR;
import oracle.sql.CLOB;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.NUMBER;
import oracle.sql.OPAQUE;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.RAW;
import oracle.sql.REF;
import oracle.sql.ROWID;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;

// Referenced classes of package oracle.jdbc.driver:
//            OraclePreparedStatementWrapper, OracleCallableStatement

class OracleCallableStatementWrapper extends OraclePreparedStatementWrapper
    implements OracleCallableStatement
{

    protected OracleCallableStatement callableStatement;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleCallableStatementWrapper(oracle.jdbc.OracleCallableStatement oraclecallablestatement)
        throws SQLException
    {
        super(oraclecallablestatement);
        callableStatement = null;
        callableStatement = (OracleCallableStatement)oraclecallablestatement;
    }

    public void setArray(String s, Array array)
        throws SQLException
    {
        callableStatement.setArray(s, array);
    }

    public void setBigDecimal(String s, BigDecimal bigdecimal)
        throws SQLException
    {
        callableStatement.setBigDecimal(s, bigdecimal);
    }

    public void setBlob(String s, Blob blob)
        throws SQLException
    {
        callableStatement.setBlob(s, blob);
    }

    public void setBoolean(String s, boolean flag)
        throws SQLException
    {
        callableStatement.setBoolean(s, flag);
    }

    public void setByte(String s, byte byte0)
        throws SQLException
    {
        callableStatement.setByte(s, byte0);
    }

    public void setBytes(String s, byte abyte0[])
        throws SQLException
    {
        callableStatement.setBytes(s, abyte0);
    }

    public void setClob(String s, Clob clob)
        throws SQLException
    {
        callableStatement.setClob(s, clob);
    }

    public void setDate(String s, Date date)
        throws SQLException
    {
        callableStatement.setDate(s, date);
    }

    public void setDate(String s, Date date, Calendar calendar)
        throws SQLException
    {
        callableStatement.setDate(s, date, calendar);
    }

    public void setDouble(String s, double d)
        throws SQLException
    {
        callableStatement.setDouble(s, d);
    }

    public void setFloat(String s, float f)
        throws SQLException
    {
        callableStatement.setFloat(s, f);
    }

    public void setInt(String s, int i)
        throws SQLException
    {
        callableStatement.setInt(s, i);
    }

    public void setLong(String s, long l)
        throws SQLException
    {
        callableStatement.setLong(s, l);
    }

    public void setNClob(String s, NClob nclob)
        throws SQLException
    {
        callableStatement.setNClob(s, nclob);
    }

    public void setNString(String s, String s1)
        throws SQLException
    {
        callableStatement.setNString(s, s1);
    }

    public void setObject(String s, Object obj)
        throws SQLException
    {
        callableStatement.setObject(s, obj);
    }

    public void setObject(String s, Object obj, int i)
        throws SQLException
    {
        callableStatement.setObject(s, obj, i);
    }

    public void setRef(String s, Ref ref)
        throws SQLException
    {
        callableStatement.setRef(s, ref);
    }

    public void setRowId(String s, RowId rowid)
        throws SQLException
    {
        callableStatement.setRowId(s, rowid);
    }

    public void setShort(String s, short word0)
        throws SQLException
    {
        callableStatement.setShort(s, word0);
    }

    public void setSQLXML(String s, SQLXML sqlxml)
        throws SQLException
    {
        callableStatement.setSQLXML(s, sqlxml);
    }

    public void setString(String s, String s1)
        throws SQLException
    {
        callableStatement.setString(s, s1);
    }

    public void setTime(String s, Time time)
        throws SQLException
    {
        callableStatement.setTime(s, time);
    }

    public void setTime(String s, Time time, Calendar calendar)
        throws SQLException
    {
        callableStatement.setTime(s, time, calendar);
    }

    public void setTimestamp(String s, Timestamp timestamp)
        throws SQLException
    {
        callableStatement.setTimestamp(s, timestamp);
    }

    public void setTimestamp(String s, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        callableStatement.setTimestamp(s, timestamp, calendar);
    }

    public void setURL(String s, URL url)
        throws SQLException
    {
        callableStatement.setURL(s, url);
    }

    public void setARRAY(String s, ARRAY array)
        throws SQLException
    {
        callableStatement.setARRAY(s, array);
    }

    public void setBFILE(String s, BFILE bfile)
        throws SQLException
    {
        callableStatement.setBFILE(s, bfile);
    }

    public void setBfile(String s, BFILE bfile)
        throws SQLException
    {
        callableStatement.setBfile(s, bfile);
    }

    public void setBinaryFloat(String s, float f)
        throws SQLException
    {
        callableStatement.setBinaryFloat(s, f);
    }

    public void setBinaryFloat(String s, BINARY_FLOAT binary_float)
        throws SQLException
    {
        callableStatement.setBinaryFloat(s, binary_float);
    }

    public void setBinaryDouble(String s, double d)
        throws SQLException
    {
        callableStatement.setBinaryDouble(s, d);
    }

    public void setBinaryDouble(String s, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        callableStatement.setBinaryDouble(s, binary_double);
    }

    public void setBLOB(String s, BLOB blob)
        throws SQLException
    {
        callableStatement.setBLOB(s, blob);
    }

    public void setCHAR(String s, CHAR char1)
        throws SQLException
    {
        callableStatement.setCHAR(s, char1);
    }

    public void setCLOB(String s, CLOB clob)
        throws SQLException
    {
        callableStatement.setCLOB(s, clob);
    }

    public void setCursor(String s, ResultSet resultset)
        throws SQLException
    {
        callableStatement.setCursor(s, resultset);
    }

    public void setCustomDatum(String s, CustomDatum customdatum)
        throws SQLException
    {
        callableStatement.setCustomDatum(s, customdatum);
    }

    public void setDATE(String s, DATE date)
        throws SQLException
    {
        callableStatement.setDATE(s, date);
    }

    public void setFixedCHAR(String s, String s1)
        throws SQLException
    {
        callableStatement.setFixedCHAR(s, s1);
    }

    public void setINTERVALDS(String s, INTERVALDS intervalds)
        throws SQLException
    {
        callableStatement.setINTERVALDS(s, intervalds);
    }

    public void setINTERVALYM(String s, INTERVALYM intervalym)
        throws SQLException
    {
        callableStatement.setINTERVALYM(s, intervalym);
    }

    public void setNUMBER(String s, NUMBER number)
        throws SQLException
    {
        callableStatement.setNUMBER(s, number);
    }

    public void setOPAQUE(String s, OPAQUE opaque)
        throws SQLException
    {
        callableStatement.setOPAQUE(s, opaque);
    }

    public void setOracleObject(String s, Datum datum)
        throws SQLException
    {
        callableStatement.setOracleObject(s, datum);
    }

    public void setORAData(String s, ORAData oradata)
        throws SQLException
    {
        callableStatement.setORAData(s, oradata);
    }

    public void setRAW(String s, RAW raw)
        throws SQLException
    {
        callableStatement.setRAW(s, raw);
    }

    public void setREF(String s, REF ref)
        throws SQLException
    {
        callableStatement.setREF(s, ref);
    }

    public void setRefType(String s, REF ref)
        throws SQLException
    {
        callableStatement.setRefType(s, ref);
    }

    public void setROWID(String s, ROWID rowid)
        throws SQLException
    {
        callableStatement.setROWID(s, rowid);
    }

    public void setSTRUCT(String s, STRUCT struct)
        throws SQLException
    {
        callableStatement.setSTRUCT(s, struct);
    }

    public void setTIMESTAMPLTZ(String s, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        callableStatement.setTIMESTAMPLTZ(s, timestampltz);
    }

    public void setTIMESTAMPTZ(String s, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        callableStatement.setTIMESTAMPTZ(s, timestamptz);
    }

    public void setTIMESTAMP(String s, TIMESTAMP timestamp)
        throws SQLException
    {
        callableStatement.setTIMESTAMP(s, timestamp);
    }

    public void setBlob(String s, InputStream inputstream)
        throws SQLException
    {
        callableStatement.setBlob(s, inputstream);
    }

    public void setBlob(String s, InputStream inputstream, long l)
        throws SQLException
    {
        callableStatement.setBlob(s, inputstream, l);
    }

    public void setClob(String s, Reader reader)
        throws SQLException
    {
        callableStatement.setClob(s, reader);
    }

    public void setClob(String s, Reader reader, long l)
        throws SQLException
    {
        callableStatement.setClob(s, reader, l);
    }

    public void setNClob(String s, Reader reader)
        throws SQLException
    {
        callableStatement.setNClob(s, reader);
    }

    public void setNClob(String s, Reader reader, long l)
        throws SQLException
    {
        callableStatement.setNClob(s, reader, l);
    }

    public void setAsciiStream(String s, InputStream inputstream)
        throws SQLException
    {
        callableStatement.setAsciiStream(s, inputstream);
    }

    public void setAsciiStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        callableStatement.setAsciiStream(s, inputstream, i);
    }

    public void setAsciiStream(String s, InputStream inputstream, long l)
        throws SQLException
    {
        callableStatement.setAsciiStream(s, inputstream, l);
    }

    public void setBinaryStream(String s, InputStream inputstream)
        throws SQLException
    {
        callableStatement.setBinaryStream(s, inputstream);
    }

    public void setBinaryStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        callableStatement.setBinaryStream(s, inputstream, i);
    }

    public void setBinaryStream(String s, InputStream inputstream, long l)
        throws SQLException
    {
        callableStatement.setBinaryStream(s, inputstream, l);
    }

    public void setCharacterStream(String s, Reader reader)
        throws SQLException
    {
        callableStatement.setCharacterStream(s, reader);
    }

    public void setCharacterStream(String s, Reader reader, int i)
        throws SQLException
    {
        callableStatement.setCharacterStream(s, reader, i);
    }

    public void setCharacterStream(String s, Reader reader, long l)
        throws SQLException
    {
        callableStatement.setCharacterStream(s, reader, l);
    }

    public void setNCharacterStream(String s, Reader reader)
        throws SQLException
    {
        callableStatement.setNCharacterStream(s, reader);
    }

    public void setNCharacterStream(String s, Reader reader, long l)
        throws SQLException
    {
        callableStatement.setNCharacterStream(s, reader, l);
    }

    public void setUnicodeStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        callableStatement.setUnicodeStream(s, inputstream, i);
    }

    public void setNull(String s, int i, String s1)
        throws SQLException
    {
        callableStatement.setNull(s, i, s1);
    }

    public void setNull(String s, int i)
        throws SQLException
    {
        callableStatement.setNull(s, i);
    }

    public Array getArray(int i)
        throws SQLException
    {
        return callableStatement.getArray(i);
    }

    public BigDecimal getBigDecimal(int i)
        throws SQLException
    {
        return callableStatement.getBigDecimal(i);
    }

    public BigDecimal getBigDecimal(int i, int j)
        throws SQLException
    {
        return callableStatement.getBigDecimal(i, j);
    }

    public Blob getBlob(int i)
        throws SQLException
    {
        return callableStatement.getBlob(i);
    }

    public boolean getBoolean(int i)
        throws SQLException
    {
        return callableStatement.getBoolean(i);
    }

    public byte getByte(int i)
        throws SQLException
    {
        return callableStatement.getByte(i);
    }

    public byte[] getBytes(int i)
        throws SQLException
    {
        return callableStatement.getBytes(i);
    }

    public Clob getClob(int i)
        throws SQLException
    {
        return callableStatement.getClob(i);
    }

    public Date getDate(int i)
        throws SQLException
    {
        return callableStatement.getDate(i);
    }

    public Date getDate(int i, Calendar calendar)
        throws SQLException
    {
        return callableStatement.getDate(i, calendar);
    }

    public double getDouble(int i)
        throws SQLException
    {
        return callableStatement.getDouble(i);
    }

    public float getFloat(int i)
        throws SQLException
    {
        return callableStatement.getFloat(i);
    }

    public int getInt(int i)
        throws SQLException
    {
        return callableStatement.getInt(i);
    }

    public long getLong(int i)
        throws SQLException
    {
        return callableStatement.getLong(i);
    }

    public NClob getNClob(int i)
        throws SQLException
    {
        return callableStatement.getNClob(i);
    }

    public String getNString(int i)
        throws SQLException
    {
        return callableStatement.getNString(i);
    }

    public Object getObject(int i)
        throws SQLException
    {
        return callableStatement.getObject(i);
    }

    public Object getObject(int i, Map map)
        throws SQLException
    {
        return callableStatement.getObject(i, map);
    }

    public Ref getRef(int i)
        throws SQLException
    {
        return callableStatement.getRef(i);
    }

    public RowId getRowId(int i)
        throws SQLException
    {
        return callableStatement.getRowId(i);
    }

    public short getShort(int i)
        throws SQLException
    {
        return callableStatement.getShort(i);
    }

    public SQLXML getSQLXML(int i)
        throws SQLException
    {
        return callableStatement.getSQLXML(i);
    }

    public String getString(int i)
        throws SQLException
    {
        return callableStatement.getString(i);
    }

    public Time getTime(int i)
        throws SQLException
    {
        return callableStatement.getTime(i);
    }

    public Time getTime(int i, Calendar calendar)
        throws SQLException
    {
        return callableStatement.getTime(i, calendar);
    }

    public Timestamp getTimestamp(int i)
        throws SQLException
    {
        return callableStatement.getTimestamp(i);
    }

    public Timestamp getTimestamp(int i, Calendar calendar)
        throws SQLException
    {
        return callableStatement.getTimestamp(i, calendar);
    }

    public URL getURL(int i)
        throws SQLException
    {
        return callableStatement.getURL(i);
    }

    public ARRAY getARRAY(int i)
        throws SQLException
    {
        return callableStatement.getARRAY(i);
    }

    public BFILE getBFILE(int i)
        throws SQLException
    {
        return callableStatement.getBFILE(i);
    }

    public BFILE getBfile(int i)
        throws SQLException
    {
        return callableStatement.getBfile(i);
    }

    public BLOB getBLOB(int i)
        throws SQLException
    {
        return callableStatement.getBLOB(i);
    }

    public CHAR getCHAR(int i)
        throws SQLException
    {
        return callableStatement.getCHAR(i);
    }

    public CLOB getCLOB(int i)
        throws SQLException
    {
        return callableStatement.getCLOB(i);
    }

    public ResultSet getCursor(int i)
        throws SQLException
    {
        return callableStatement.getCursor(i);
    }

    public Object getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        return callableStatement.getCustomDatum(i, customdatumfactory);
    }

    public DATE getDATE(int i)
        throws SQLException
    {
        return callableStatement.getDATE(i);
    }

    public INTERVALDS getINTERVALDS(int i)
        throws SQLException
    {
        return callableStatement.getINTERVALDS(i);
    }

    public INTERVALYM getINTERVALYM(int i)
        throws SQLException
    {
        return callableStatement.getINTERVALYM(i);
    }

    public NUMBER getNUMBER(int i)
        throws SQLException
    {
        return callableStatement.getNUMBER(i);
    }

    public OPAQUE getOPAQUE(int i)
        throws SQLException
    {
        return callableStatement.getOPAQUE(i);
    }

    public Datum getOracleObject(int i)
        throws SQLException
    {
        return callableStatement.getOracleObject(i);
    }

    public Object getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException
    {
        return callableStatement.getORAData(i, oradatafactory);
    }

    public Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        return callableStatement.getObject(i, oracledatafactory);
    }

    public RAW getRAW(int i)
        throws SQLException
    {
        return callableStatement.getRAW(i);
    }

    public REF getREF(int i)
        throws SQLException
    {
        return callableStatement.getREF(i);
    }

    public ROWID getROWID(int i)
        throws SQLException
    {
        return callableStatement.getROWID(i);
    }

    public STRUCT getSTRUCT(int i)
        throws SQLException
    {
        return callableStatement.getSTRUCT(i);
    }

    public TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException
    {
        return callableStatement.getTIMESTAMPLTZ(i);
    }

    public TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        return callableStatement.getTIMESTAMPTZ(i);
    }

    public TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        return callableStatement.getTIMESTAMP(i);
    }

    public InputStream getAsciiStream(int i)
        throws SQLException
    {
        return callableStatement.getAsciiStream(i);
    }

    public InputStream getBinaryStream(int i)
        throws SQLException
    {
        return callableStatement.getBinaryStream(i);
    }

    public Reader getCharacterStream(int i)
        throws SQLException
    {
        return callableStatement.getCharacterStream(i);
    }

    public Reader getNCharacterStream(int i)
        throws SQLException
    {
        return callableStatement.getNCharacterStream(i);
    }

    public InputStream getUnicodeStream(int i)
        throws SQLException
    {
        return callableStatement.getUnicodeStream(i);
    }

    public Array getArray(String s)
        throws SQLException
    {
        return callableStatement.getArray(s);
    }

    public BigDecimal getBigDecimal(String s)
        throws SQLException
    {
        return callableStatement.getBigDecimal(s);
    }

    public BigDecimal getBigDecimal(String s, int i)
        throws SQLException
    {
        return callableStatement.getBigDecimal(s, i);
    }

    public Blob getBlob(String s)
        throws SQLException
    {
        return callableStatement.getBlob(s);
    }

    public boolean getBoolean(String s)
        throws SQLException
    {
        return callableStatement.getBoolean(s);
    }

    public byte getByte(String s)
        throws SQLException
    {
        return callableStatement.getByte(s);
    }

    public byte[] getBytes(String s)
        throws SQLException
    {
        return callableStatement.getBytes(s);
    }

    public Clob getClob(String s)
        throws SQLException
    {
        return callableStatement.getClob(s);
    }

    public Date getDate(String s)
        throws SQLException
    {
        return callableStatement.getDate(s);
    }

    public Date getDate(String s, Calendar calendar)
        throws SQLException
    {
        return callableStatement.getDate(s, calendar);
    }

    public double getDouble(String s)
        throws SQLException
    {
        return callableStatement.getDouble(s);
    }

    public float getFloat(String s)
        throws SQLException
    {
        return callableStatement.getFloat(s);
    }

    public int getInt(String s)
        throws SQLException
    {
        return callableStatement.getInt(s);
    }

    public long getLong(String s)
        throws SQLException
    {
        return callableStatement.getLong(s);
    }

    public NClob getNClob(String s)
        throws SQLException
    {
        return callableStatement.getNClob(s);
    }

    public String getNString(String s)
        throws SQLException
    {
        return callableStatement.getNString(s);
    }

    public Object getObject(String s)
        throws SQLException
    {
        return callableStatement.getObject(s);
    }

    public Object getObject(String s, Map map)
        throws SQLException
    {
        return callableStatement.getObject(s, map);
    }

    public Ref getRef(String s)
        throws SQLException
    {
        return callableStatement.getRef(s);
    }

    public RowId getRowId(String s)
        throws SQLException
    {
        return callableStatement.getRowId(s);
    }

    public short getShort(String s)
        throws SQLException
    {
        return callableStatement.getShort(s);
    }

    public SQLXML getSQLXML(String s)
        throws SQLException
    {
        return callableStatement.getSQLXML(s);
    }

    public String getString(String s)
        throws SQLException
    {
        return callableStatement.getString(s);
    }

    public Time getTime(String s)
        throws SQLException
    {
        return callableStatement.getTime(s);
    }

    public Time getTime(String s, Calendar calendar)
        throws SQLException
    {
        return callableStatement.getTime(s, calendar);
    }

    public Timestamp getTimestamp(String s)
        throws SQLException
    {
        return callableStatement.getTimestamp(s);
    }

    public Timestamp getTimestamp(String s, Calendar calendar)
        throws SQLException
    {
        return callableStatement.getTimestamp(s, calendar);
    }

    public URL getURL(String s)
        throws SQLException
    {
        return callableStatement.getURL(s);
    }

    public InputStream getAsciiStream(String s)
        throws SQLException
    {
        return callableStatement.getAsciiStream(s);
    }

    public InputStream getBinaryStream(String s)
        throws SQLException
    {
        return callableStatement.getBinaryStream(s);
    }

    public Reader getCharacterStream(String s)
        throws SQLException
    {
        return callableStatement.getCharacterStream(s);
    }

    public Reader getNCharacterStream(String s)
        throws SQLException
    {
        return callableStatement.getNCharacterStream(s);
    }

    public InputStream getUnicodeStream(String s)
        throws SQLException
    {
        return callableStatement.getUnicodeStream(s);
    }

    public void setObject(String s, Object obj, int i, int j)
        throws SQLException
    {
        callableStatement.setObject(s, obj, i, j);
    }

    public Object getAnyDataEmbeddedObject(int i)
        throws SQLException
    {
        return callableStatement.getAnyDataEmbeddedObject(i);
    }

    public void setStructDescriptor(int i, StructDescriptor structdescriptor)
        throws SQLException
    {
        callableStatement.setStructDescriptor(i, structdescriptor);
    }

    public void setStructDescriptor(String s, StructDescriptor structdescriptor)
        throws SQLException
    {
        callableStatement.setStructDescriptor(s, structdescriptor);
    }

    public void close()
        throws SQLException
    {
        super.close();
    }

    public void closeWithKey(String s)
        throws SQLException
    {
        callableStatement.closeWithKey(s);
        statement = preparedStatement = callableStatement = closedStatement;
    }

    public void registerOutParameter(int i, int j, int k, int l)
        throws SQLException
    {
        callableStatement.registerOutParameter(i, j, k, l);
    }

    public void registerOutParameterBytes(int i, int j, int k, int l)
        throws SQLException
    {
        callableStatement.registerOutParameterBytes(i, j, k, l);
    }

    public void registerOutParameterChars(int i, int j, int k, int l)
        throws SQLException
    {
        callableStatement.registerOutParameterChars(i, j, k, l);
    }

    public void registerIndexTableOutParameter(int i, int j, int k, int l)
        throws SQLException
    {
        callableStatement.registerIndexTableOutParameter(i, j, k, l);
    }

    public void registerOutParameter(String s, int i, int j, int k)
        throws SQLException
    {
        callableStatement.registerOutParameter(s, i, j, k);
    }

    public void registerOutParameter(String s, int i, String s1)
        throws SQLException
    {
        callableStatement.registerOutParameter(s, i, s1);
    }

    public int sendBatch()
        throws SQLException
    {
        return callableStatement.sendBatch();
    }

    public void setExecuteBatch(int i)
        throws SQLException
    {
        callableStatement.setExecuteBatch(i);
    }

    public Object getPlsqlIndexTable(int i)
        throws SQLException
    {
        return callableStatement.getPlsqlIndexTable(i);
    }

    public Object getPlsqlIndexTable(int i, Class class1)
        throws SQLException
    {
        return callableStatement.getPlsqlIndexTable(i, class1);
    }

    public Datum[] getOraclePlsqlIndexTable(int i)
        throws SQLException
    {
        return callableStatement.getOraclePlsqlIndexTable(i);
    }

    public void setStringForClob(String s, String s1)
        throws SQLException
    {
        callableStatement.setStringForClob(s, s1);
    }

    public void setBytesForBlob(String s, byte abyte0[])
        throws SQLException
    {
        callableStatement.setBytesForBlob(s, abyte0);
    }

    public boolean wasNull()
        throws SQLException
    {
        return callableStatement.wasNull();
    }

    public void registerOutParameter(int i, int j)
        throws SQLException
    {
        callableStatement.registerOutParameter(i, j);
    }

    public void registerOutParameter(int i, int j, int k)
        throws SQLException
    {
        callableStatement.registerOutParameter(i, j, k);
    }

    public void registerOutParameter(int i, int j, String s)
        throws SQLException
    {
        callableStatement.registerOutParameter(i, j, s);
    }

    public void registerOutParameter(String s, int i)
        throws SQLException
    {
        callableStatement.registerOutParameter(s, i);
    }

    public void registerOutParameter(String s, int i, int j)
        throws SQLException
    {
        callableStatement.registerOutParameter(s, i, j);
    }

    public byte[] privateGetBytes(int i)
        throws SQLException
    {
        return ((oracle.jdbc.driver.OracleCallableStatement)callableStatement).privateGetBytes(i);
    }

}
