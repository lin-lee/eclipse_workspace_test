// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;


class FDBigInt
{

    int nWords;
    int data[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    FDBigInt(int i)
    {
        nWords = 1;
        data = new int[1];
        data[0] = i;
    }

    FDBigInt(long l)
    {
        data = new int[2];
        data[0] = (int)l;
        data[1] = (int)(l >>> 32);
        nWords = data[1] != 0 ? 2 : 1;
    }

    FDBigInt(FDBigInt fdbigint)
    {
        data = new int[nWords = fdbigint.nWords];
        System.arraycopy(fdbigint.data, 0, data, 0, nWords);
    }

    FDBigInt(int ai[], int i)
    {
        data = ai;
        nWords = i;
    }

    void lshiftMe(int i)
        throws IllegalArgumentException
    {
        if(i <= 0)
            if(i == 0)
                return;
            else
                throw new IllegalArgumentException("negative shift count");
        int j = i >> 5;
        int k = i & 0x1f;
        int l = 32 - k;
        int ai[] = data;
        int ai1[] = data;
        if(nWords + j + 1 > ai.length)
            ai = new int[nWords + j + 1];
        int i1 = nWords + j;
        int j1 = nWords - 1;
        if(k == 0)
        {
            System.arraycopy(ai1, 0, ai, j, nWords);
            i1 = j - 1;
        } else
        {
            for(ai[i1--] = ai1[j1] >>> l; j1 >= 1; ai[i1--] = ai1[j1] << k | ai1[--j1] >>> l);
            ai[i1--] = ai1[j1] << k;
        }
        while(i1 >= 0) 
            ai[i1--] = 0;
        data = ai;
        for(nWords += j + 1; nWords > 1 && data[nWords - 1] == 0; nWords--);
    }

    int normalizeMe()
        throws IllegalArgumentException
    {
        int j = 0;
        int k = 0;
        int l = 0;
        int i;
        for(i = nWords - 1; i >= 0 && (l = data[i]) == 0; i--)
            j++;

        if(i < 0)
            throw new IllegalArgumentException("zero value");
        nWords -= j;
        if((l & 0xf0000000) != 0)
        {
            for(k = 32; (l & 0xf0000000) != 0; k--)
                l >>>= 1;

        } else
        {
            while(l <= 0xfffff) 
            {
                l <<= 8;
                k += 8;
            }
            while(l <= 0x7ffffff) 
            {
                l <<= 1;
                k++;
            }
        }
        if(k != 0)
            lshiftMe(k);
        return k;
    }

    FDBigInt mult(int i)
    {
        long l = i;
        int ai[] = new int[l * ((long)data[nWords - 1] & 0xffffffffL) <= 0xfffffffL ? nWords : nWords + 1];
        long l1 = 0L;
        for(int j = 0; j < nWords; j++)
        {
            l1 += l * ((long)data[j] & 0xffffffffL);
            ai[j] = (int)l1;
            l1 >>>= 32;
        }

        if(l1 == 0L)
        {
            return new FDBigInt(ai, nWords);
        } else
        {
            ai[nWords] = (int)l1;
            return new FDBigInt(ai, nWords + 1);
        }
    }

    FDBigInt mult(FDBigInt fdbigint)
    {
        int ai[] = new int[nWords + fdbigint.nWords];
        for(int i = 0; i < nWords; i++)
        {
            long l = (long)data[i] & 0xffffffffL;
            long l1 = 0L;
            int k;
            for(k = 0; k < fdbigint.nWords; k++)
            {
                l1 += ((long)ai[i + k] & 0xffffffffL) + l * ((long)fdbigint.data[k] & 0xffffffffL);
                ai[i + k] = (int)l1;
                l1 >>>= 32;
            }

            ai[i + k] = (int)l1;
        }

        int j;
        for(j = ai.length - 1; j > 0 && ai[j] == 0; j--);
        return new FDBigInt(ai, j + 1);
    }

    FDBigInt add(FDBigInt fdbigint)
    {
        long l = 0L;
        int ai[];
        int ai1[];
        int j;
        int k;
        if(nWords >= fdbigint.nWords)
        {
            ai = data;
            j = nWords;
            ai1 = fdbigint.data;
            k = fdbigint.nWords;
        } else
        {
            ai = fdbigint.data;
            j = fdbigint.nWords;
            ai1 = data;
            k = nWords;
        }
        int ai2[] = new int[j];
        int i;
        for(i = 0; i < j; i++)
        {
            l += (long)ai[i] & 0xffffffffL;
            if(i < k)
                l += (long)ai1[i] & 0xffffffffL;
            ai2[i] = (int)l;
            l >>= 32;
        }

        if(l != 0L)
        {
            int ai3[] = new int[ai2.length + 1];
            System.arraycopy(ai2, 0, ai3, 0, ai2.length);
            ai3[i++] = (int)l;
            return new FDBigInt(ai3, i);
        } else
        {
            return new FDBigInt(ai2, i);
        }
    }

    int cmp(FDBigInt fdbigint)
    {
        int i;
        if(nWords > fdbigint.nWords)
        {
            int j = fdbigint.nWords - 1;
            for(i = nWords - 1; i > j; i--)
                if(data[i] != 0)
                    return 1;

        } else
        if(nWords < fdbigint.nWords)
        {
            int k = nWords - 1;
            for(i = fdbigint.nWords - 1; i > k; i--)
                if(fdbigint.data[i] != 0)
                    return -1;

        } else
        {
            i = nWords - 1;
        }
        for(; i > 0 && data[i] == fdbigint.data[i]; i--);
        int l = data[i];
        int i1 = fdbigint.data[i];
        if(l < 0)
            if(i1 < 0)
                return l - i1;
            else
                return 1;
        if(i1 < 0)
            return -1;
        else
            return l - i1;
    }

    int quoRemIteration(FDBigInt fdbigint)
        throws IllegalArgumentException
    {
        if(nWords != fdbigint.nWords)
            throw new IllegalArgumentException("disparate values");
        int i = nWords - 1;
        long l = ((long)data[i] & 0xffffffffL) / (long)fdbigint.data[i];
        long l1 = 0L;
        for(int j = 0; j <= i; j++)
        {
            l1 += ((long)data[j] & 0xffffffffL) - l * ((long)fdbigint.data[j] & 0xffffffffL);
            data[j] = (int)l1;
            l1 >>= 32;
        }

        if(l1 != 0L)
        {
            for(long l2 = 0L; l2 == 0L;)
            {
                l2 = 0L;
                for(int k = 0; k <= i; k++)
                {
                    l2 += ((long)data[k] & 0xffffffffL) + ((long)fdbigint.data[k] & 0xffffffffL);
                    data[k] = (int)l2;
                    l2 >>= 32;
                }

                if(l2 != 0L && l2 != 1L)
                    throw new RuntimeException((new StringBuilder()).append("Assertion botch: ").append(l2).append(" carry out of division correction").toString());
                l--;
            }

        }
        long l3 = 0L;
        for(int i1 = 0; i1 <= i; i1++)
        {
            l3 += 10L * ((long)data[i1] & 0xffffffffL);
            data[i1] = (int)l3;
            l3 >>= 32;
        }

        if(l3 != 0L)
            throw new RuntimeException("Assertion botch: carry out of *10");
        else
            return (int)l;
    }

}
