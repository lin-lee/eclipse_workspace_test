// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ResultSetAccessor.java

package oracle.jdbc.driver;

import java.sql.ResultSet;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            Accessor, OracleResultSetImpl, OracleStatement, PhysicalConnection

class ResultSetAccessor extends Accessor
{

    static final int maxLength = 16;
    OracleStatement currentStmt;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    ResultSetAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 102, 116, word0, flag);
        initForDataAccess(j, i, null);
    }

    ResultSetAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        init(oraclestatement, 102, 116, word0, false);
        initForDescribe(102, i, flag, j, k, l, i1, j1, word0, null);
        initForDataAccess(0, i, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        internalTypeMaxLength = 16;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        byteLength = internalTypeMaxLength;
    }

    ResultSet getCursor(int i)
        throws SQLException
    {
        byte abyte0[] = getBytes(i);
        OracleStatement oraclestatement = statement.connection.RefCursorBytesToStatement(abyte0, statement);
        if(currentStmt != null && currentStmt.cursorId == oraclestatement.cursorId && currentStmt.currentResultSet != null)
        {
            return currentStmt.currentResultSet;
        } else
        {
            oraclestatement.doDescribe(false);
            oraclestatement.prepareAccessors();
            oraclestatement.setPrefetchInternal(statement.getFetchSize(), false, false);
            OracleResultSetImpl oracleresultsetimpl = new OracleResultSetImpl(oraclestatement.connection, oraclestatement);
            oracleresultsetimpl.close_statement_on_close = true;
            oraclestatement.currentResultSet = oracleresultsetimpl;
            currentStmt = oraclestatement;
            return oracleresultsetimpl;
        }
    }

    Object getObject(int i)
        throws SQLException
    {
        return getCursor(i);
    }

}
