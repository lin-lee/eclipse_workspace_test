// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   RefTypeAccessor.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.oracore.OracleType;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            TypeAccessor, OracleStatement, PhysicalConnection, DatabaseError

class RefTypeAccessor extends TypeAccessor
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    RefTypeAccessor(OracleStatement oraclestatement, String s, short word0, int i, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 111, 111, word0, flag);
        initForDataAccess(i, 0, s);
    }

    RefTypeAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, String s)
        throws SQLException
    {
        init(oraclestatement, 111, 111, word0, false);
        initForDescribe(111, i, flag, j, k, l, i1, j1, word0, s);
        initForDataAccess(0, i, s);
    }

    RefTypeAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, String s, OracleType oracletype)
        throws SQLException
    {
        init(oraclestatement, 111, 111, word0, false);
        describeOtype = oracletype;
        initForDescribe(111, i, flag, j, k, l, i1, j1, word0, s);
        internalOtype = oracletype;
        initForDataAccess(0, i, s);
    }

    OracleType otypeFromName(String s)
        throws SQLException
    {
        if(!outBind)
            return TypeDescriptor.getTypeDescriptor(s, statement.connection).getPickler();
        else
            return StructDescriptor.createDescriptor(s, statement.connection).getOracleTypeADT();
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        super.initForDataAccess(i, j, s);
        byteLength = statement.connection.refTypeAccessorByteLen;
    }

    REF getREF(int i)
        throws SQLException
    {
        REF ref = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            byte abyte0[] = pickledBytes(i);
            OracleTypeADT oracletypeadt = (OracleTypeADT)internalOtype;
            ref = new REF(oracletypeadt.getFullName(), statement.connection, abyte0);
        }
        return ref;
    }

    Object getObject(int i)
        throws SQLException
    {
        return getREF(i);
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        return getREF(i);
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        return getREF(i);
    }

}
