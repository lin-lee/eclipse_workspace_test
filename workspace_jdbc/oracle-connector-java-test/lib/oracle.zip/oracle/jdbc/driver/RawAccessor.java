// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   RawAccessor.java

package oracle.jdbc.driver;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            RawCommonAccessor, OracleStatement, PhysicalConnection, DatabaseError

class RawAccessor extends RawCommonAccessor
{

    static final int MAXLENGTH_NEW = 2000;
    static final int MAXLENGTH_OLD = 255;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    RawAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 23, 15, word0, flag);
        initForDataAccess(j, i, null);
    }

    RawAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        init(oraclestatement, 23, 15, word0, false);
        initForDescribe(23, i, flag, j, k, l, i1, j1, word0, null);
        int k1 = oraclestatement.maxFieldSize;
        if(k1 > 0 && (i == 0 || k1 < i))
            i = k1;
        initForDataAccess(0, i, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        if(statement.connection.getVersionNumber() >= 8000)
            internalTypeMaxLength = 2000;
        else
            internalTypeMaxLength = 255;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        byteLength = internalTypeMaxLength + 2;
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        byte abyte0[] = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            short word0 = rowSpaceIndicator[lengthIndex + i];
            int j = columnIndex + byteLength * i;
            abyte0 = new byte[word0];
            System.arraycopy(rowSpaceByte, j + 2, abyte0, 0, word0);
        }
        return abyte0;
    }

}
