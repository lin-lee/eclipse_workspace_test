// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleResultSetImpl.java

package oracle.jdbc.driver;

import java.io.*;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.OracleDataFactory;
import oracle.jdbc.OracleResultSet;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleStatement;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            BaseResultSet, OracleResultSetMetaData, PhysicalConnection, DatabaseError, 
//            OracleStatement, OracleInputStream, CancelLock, Accessor

class OracleResultSetImpl extends BaseResultSet
{

    PhysicalConnection connection;
    oracle.jdbc.driver.OracleStatement statement;
    boolean explicitly_closed;
    boolean m_emptyRset;
    boolean isServerCursorPeeked;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleResultSetImpl(PhysicalConnection physicalconnection, oracle.jdbc.driver.OracleStatement oraclestatement)
        throws SQLException
    {
        isServerCursorPeeked = false;
        connection = physicalconnection;
        statement = oraclestatement;
        close_statement_on_close = false;
        explicitly_closed = false;
        m_emptyRset = false;
    }

    public String getCursorName()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void close()
        throws SQLException
    {
        synchronized(connection)
        {
            internal_close(false);
            statement.totalRowsVisited = 0;
            statement.closeCursorOnPlainStatement();
            if(close_statement_on_close)
                try
                {
                    statement.close();
                }
                catch(SQLException sqlexception) { }
            explicitly_closed = true;
        }
    }

    public boolean wasNull()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(explicitly_closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "wasNull");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(statement.closed)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "wasNull");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        return statement.wasNullValue();
        Exception exception;
        exception;
        throw exception;
    }

    public ResultSetMetaData getMetaData()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(explicitly_closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getMetaData");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(statement.closed)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getMetaData");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(!statement.isOpen)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144, "getMetaData");
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        return new OracleResultSetMetaData(connection, statement);
        Exception exception;
        exception;
        throw exception;
    }

    public Statement getStatement()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return ((Statement) (statement.wrapper != null ? statement.wrapper : statement));
        Exception exception;
        exception;
        throw exception;
    }

    oracle.jdbc.driver.OracleStatement getOracleStatement()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return statement;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean next()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        boolean flag;
        PhysicalConnection physicalconnection1;
        flag = true;
        isServerCursorPeeked = true;
        physicalconnection1 = statement.connection;
        if(explicitly_closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "next");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(physicalconnection1 == null || physicalconnection1.lifecycle != 1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "next");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(statement.closed)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "next");
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        if(statement.sqlKind.isPlsqlOrCall())
        {
            SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 166, "next");
            sqlexception3.fillInStackTrace();
            throw sqlexception3;
        }
        if(closed)
            return false;
        statement.currentRow++;
        statement.totalRowsVisited++;
        if(statement.maxRows == 0 || statement.totalRowsVisited <= statement.maxRows) goto _L2; else goto _L1
_L1:
        internal_close(false);
        statement.currentRow--;
        statement.totalRowsVisited = 0;
        sqlWarning = DatabaseError.addSqlWarning(sqlWarning, 275);
        false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        if(statement.currentRow >= statement.validRows)
            flag = close_or_fetch_from_next(false);
        if(flag && physicalconnection1.useFetchSizeWithLongColumn)
            statement.reopenStreams();
        if(!flag)
        {
            statement.currentRow--;
            statement.totalRowsVisited = 0;
        }
        flag;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    private boolean close_or_fetch_from_next(boolean flag)
        throws SQLException
    {
        PhysicalConnection physicalconnection;
        if(flag)
        {
            internal_close(false);
            return false;
        }
        if(statement.gotLastBatch)
        {
            internal_close(false);
            return false;
        }
        statement.check_row_prefetch_changed();
        physicalconnection = statement.connection;
        if(physicalconnection.protocolId == 3)
        {
            sqlWarning = null;
        } else
        {
            if(statement.streamList != null)
                for(; statement.nextStream != null; statement.nextStream = statement.nextStream.nextStream)
                    try
                    {
                        statement.nextStream.close();
                    }
                    catch(IOException ioexception)
                    {
                        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                        sqlexception.fillInStackTrace();
                        throw sqlexception;
                    }

            clearWarnings();
            physicalconnection.registerHeartbeat();
            physicalconnection.needLine();
        }
        PhysicalConnection physicalconnection1 = physicalconnection;
        JVM INSTR monitorenter ;
        statement.cancelLock.enterExecuting();
        statement.fetch();
        statement.cancelLock.exitExecuting();
        break MISSING_BLOCK_LABEL_193;
        Exception exception;
        exception;
        statement.cancelLock.exitExecuting();
        throw exception;
        Exception exception1;
        exception1;
        throw exception1;
        if(statement.validRows == 0)
        {
            internal_close(false);
            return false;
        } else
        {
            statement.currentRow = 0;
            statement.checkValidRowsStatus();
            return true;
        }
    }

    public boolean isBeforeFirst()
        throws SQLException
    {
        if(explicitly_closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(statement.connection.protocolId == 3 && statement.serverCursor)
        {
            SQLException sqlexception1 = DatabaseError.createUnsupportedFeatureSqlException();
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return !isEmptyResultSet() && statement.currentRow == -1 && !closed;
        }
    }

    public boolean isAfterLast()
        throws SQLException
    {
        if(explicitly_closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return !isEmptyResultSet() && closed;
        }
    }

    public boolean isFirst()
        throws SQLException
    {
        if(explicitly_closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return getRow() == 1;
        }
    }

    public boolean isLast()
        throws SQLException
    {
        if(explicitly_closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "isLast");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public int getRow()
        throws SQLException
    {
        if(explicitly_closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return statement.totalRowsVisited;
        }
    }

    public Array getArray(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getARRAY(i);
        Exception exception;
        exception;
        throw exception;
    }

    public BigDecimal getBigDecimal(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getBigDecimal(j);
        Exception exception;
        exception;
        throw exception;
    }

    public BigDecimal getBigDecimal(int i, int j)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int k = statement.currentRow;
        if(k < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getBigDecimal(k, j);
        Exception exception;
        exception;
        throw exception;
    }

    public Blob getBlob(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getBLOB(i);
        Exception exception;
        exception;
        throw exception;
    }

    public boolean getBoolean(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getBoolean(j);
        Exception exception;
        exception;
        throw exception;
    }

    public byte getByte(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getByte(j);
        Exception exception;
        exception;
        throw exception;
    }

    public byte[] getBytes(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getBytes(j);
        Exception exception;
        exception;
        throw exception;
    }

    public Clob getClob(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getCLOB(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Date getDate(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getDate(j);
        Exception exception;
        exception;
        throw exception;
    }

    public Date getDate(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getDate(j, calendar);
        Exception exception;
        exception;
        throw exception;
    }

    public double getDouble(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getDouble(j);
        Exception exception;
        exception;
        throw exception;
    }

    public float getFloat(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getFloat(j);
        Exception exception;
        exception;
        throw exception;
    }

    public int getInt(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getInt(j);
        Exception exception;
        exception;
        throw exception;
    }

    public long getLong(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getLong(j);
        Exception exception;
        exception;
        throw exception;
    }

    public NClob getNClob(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getNClob(j);
        Exception exception;
        exception;
        throw exception;
    }

    public String getNString(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getNString(j);
        Exception exception;
        exception;
        throw exception;
    }

    public Object getObject(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getObject(j);
        Exception exception;
        exception;
        throw exception;
    }

    public Object getObject(int i, Map map)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getObject(j, map);
        Exception exception;
        exception;
        throw exception;
    }

    public Ref getRef(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getREF(i);
        Exception exception;
        exception;
        throw exception;
    }

    public RowId getRowId(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getROWID(i);
        Exception exception;
        exception;
        throw exception;
    }

    public short getShort(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getShort(j);
        Exception exception;
        exception;
        throw exception;
    }

    public SQLXML getSQLXML(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getSQLXML(j);
        Exception exception;
        exception;
        throw exception;
    }

    public String getString(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getString(j);
        Exception exception;
        exception;
        throw exception;
    }

    public Time getTime(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getTime(j);
        Exception exception;
        exception;
        throw exception;
    }

    public Time getTime(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getTime(j, calendar);
        Exception exception;
        exception;
        throw exception;
    }

    public Timestamp getTimestamp(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getTimestamp(j);
        Exception exception;
        exception;
        throw exception;
    }

    public Timestamp getTimestamp(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getTimestamp(j, calendar);
        Exception exception;
        exception;
        throw exception;
    }

    public URL getURL(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getURL(j);
        Exception exception;
        exception;
        throw exception;
    }

    public ARRAY getARRAY(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getARRAY(j);
        Exception exception;
        exception;
        throw exception;
    }

    public BFILE getBFILE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getBFILE(j);
        Exception exception;
        exception;
        throw exception;
    }

    public BFILE getBfile(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getBFILE(i);
        Exception exception;
        exception;
        throw exception;
    }

    public BLOB getBLOB(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getBLOB(j);
        Exception exception;
        exception;
        throw exception;
    }

    public CHAR getCHAR(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getCHAR(j);
        Exception exception;
        exception;
        throw exception;
    }

    public CLOB getCLOB(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getCLOB(j);
        Exception exception;
        exception;
        throw exception;
    }

    public ResultSet getCursor(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getCursor(j);
        Exception exception;
        exception;
        throw exception;
    }

    public CustomDatum getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getCustomDatum(j, customdatumfactory);
        Exception exception;
        exception;
        throw exception;
    }

    public DATE getDATE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getDATE(j);
        Exception exception;
        exception;
        throw exception;
    }

    public INTERVALDS getINTERVALDS(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getINTERVALDS(j);
        Exception exception;
        exception;
        throw exception;
    }

    public INTERVALYM getINTERVALYM(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getINTERVALYM(j);
        Exception exception;
        exception;
        throw exception;
    }

    public NUMBER getNUMBER(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getNUMBER(j);
        Exception exception;
        exception;
        throw exception;
    }

    public OPAQUE getOPAQUE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getOPAQUE(j);
        Exception exception;
        exception;
        throw exception;
    }

    public Datum getOracleObject(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getOracleObject(j);
        Exception exception;
        exception;
        throw exception;
    }

    public ORAData getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getORAData(j, oradatafactory);
        Exception exception;
        exception;
        throw exception;
    }

    public Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getObject(j, oracledatafactory);
        Exception exception;
        exception;
        throw exception;
    }

    public RAW getRAW(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getRAW(j);
        Exception exception;
        exception;
        throw exception;
    }

    public REF getREF(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getREF(j);
        Exception exception;
        exception;
        throw exception;
    }

    public ROWID getROWID(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getROWID(j);
        Exception exception;
        exception;
        throw exception;
    }

    public STRUCT getSTRUCT(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getSTRUCT(j);
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getTIMESTAMPLTZ(j);
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getTIMESTAMPTZ(j);
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getTIMESTAMP(j);
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getAsciiStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getAsciiStream(j);
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getBinaryStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getBinaryStream(j);
        Exception exception;
        exception;
        throw exception;
    }

    public Reader getCharacterStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getCharacterStream(j);
        Exception exception;
        exception;
        throw exception;
    }

    public Reader getNCharacterStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getNCharacterStream(j);
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getUnicodeStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getUnicodeStream(j);
        Exception exception;
        exception;
        throw exception;
    }

    public oracle.jdbc.OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].getAuthorizationIndicator(j);
        Exception exception;
        exception;
        throw exception;
    }

    byte[] privateGetBytes(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(closed)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(i <= 0 || i > statement.numberOfDefinePositions)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        int j = statement.currentRow;
        if(j < 0)
        {
            SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
            sqlexception3.fillInStackTrace();
            throw sqlexception3;
        }
        statement.lastIndex = i;
        if(statement.streamList != null)
            statement.closeUsedStreams(i);
        return statement.accessors[i - 1].privateGetBytes(j);
        Exception exception;
        exception;
        throw exception;
    }

    public void setFetchSize(int i)
        throws SQLException
    {
        statement.setPrefetchInternal(i, false, false);
    }

    public int getFetchSize()
        throws SQLException
    {
        return statement.getPrefetchInternal(false);
    }

    void internal_close(boolean flag)
        throws SQLException
    {
        if(closed)
            return;
        super.close();
        if(statement.gotLastBatch && statement.validRows == 0)
            m_emptyRset = true;
        PhysicalConnection physicalconnection = statement.connection;
        try
        {
            physicalconnection.registerHeartbeat();
            physicalconnection.needLine();
            synchronized(physicalconnection)
            {
                statement.closeQuery();
            }
        }
        catch(SQLException sqlexception) { }
        statement.endOfResultSet(flag);
    }

    public int findColumn(String s)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return statement.getColumnIndex(s);
        Exception exception;
        exception;
        throw exception;
    }

    boolean isEmptyResultSet()
        throws SQLException
    {
        if(statement != null && !statement.closed && statement.serverCursor && statement.connection.protocolId != 3 && !isServerCursorPeeked && !closed)
        {
            close_or_fetch_from_next(false);
            if(statement.validRows > 0)
                statement.currentRow = -1;
            else
                m_emptyRset = true;
            isServerCursorPeeked = true;
        }
        return m_emptyRset || !m_emptyRset && statement.gotLastBatch && statement.validRows == 0;
    }

    int getValidRows()
    {
        return statement.validRows;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
