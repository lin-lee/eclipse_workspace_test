// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   SensitiveScrollableResultSet.java

package oracle.jdbc.driver;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            ScrollableResultSet, ScrollRsetStatement, OracleResultSetImpl, DatabaseError

class SensitiveScrollableResultSet extends ScrollableResultSet
{

    int beginLastFetchedIndex;
    int endLastFetchedIndex;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    SensitiveScrollableResultSet(ScrollRsetStatement scrollrsetstatement, OracleResultSetImpl oracleresultsetimpl, int i, int j)
        throws SQLException
    {
        super(scrollrsetstatement, oracleresultsetimpl, i, j);
        int k = oracleresultsetimpl.getValidRows();
        if(k > 0)
        {
            beginLastFetchedIndex = 1;
            endLastFetchedIndex = k;
        } else
        {
            beginLastFetchedIndex = 0;
            endLastFetchedIndex = 0;
        }
    }

    public boolean next()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(super.next())
        {
            handle_refetch();
            return true;
        }
        false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean first()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(super.first())
        {
            handle_refetch();
            return true;
        }
        false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean last()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(super.last())
        {
            handle_refetch();
            return true;
        }
        false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean absolute(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(super.absolute(i))
        {
            handle_refetch();
            return true;
        }
        false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean relative(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(super.relative(i))
        {
            handle_refetch();
            return true;
        }
        false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean previous()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(super.previous())
        {
            handle_refetch();
            return true;
        }
        false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void refreshRow()
        throws SQLException
    {
        synchronized(connection)
        {
            if(!isValidRow(currentRow))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            int i = getFetchDirection();
            int j = 0;
            try
            {
                j = refreshRowsInCache(currentRow, getFetchSize(), i);
            }
            catch(SQLException sqlexception1)
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), sqlexception1, 90, "Unsupported syntax for refreshRow()");
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
            if(j != 0)
            {
                beginLastFetchedIndex = currentRow;
                endLastFetchedIndex = (currentRow + j) - 1;
            }
        }
    }

    int removeRowInCache(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        int j = super.removeRowInCache(i);
        if(j != 0)
            if(i >= beginLastFetchedIndex && i <= endLastFetchedIndex && beginLastFetchedIndex != endLastFetchedIndex)
                endLastFetchedIndex--;
            else
                beginLastFetchedIndex = endLastFetchedIndex = 0;
        return j;
        Exception exception;
        exception;
        throw exception;
    }

    private boolean handle_refetch()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(currentRow >= beginLastFetchedIndex && currentRow <= endLastFetchedIndex || currentRow >= endLastFetchedIndex && currentRow <= beginLastFetchedIndex)
            return false;
        refreshRow();
        true;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

}
