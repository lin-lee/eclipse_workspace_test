// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConversionInputStream.java

package oracle.jdbc.driver;

import java.io.*;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            OracleBufferedStream, DBConversion, DatabaseError

class OracleConversionInputStream extends OracleBufferedStream
{

    static final int CHUNK_SIZE = 4096;
    DBConversion converter;
    int conversion;
    InputStream istream;
    Reader reader;
    byte convbuf[];
    char javaChars[];
    int maxSize;
    int totalSize;
    int numUnconvertedBytes;
    boolean endOfStream;
    private short csform;
    int nbytes[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleConversionInputStream(DBConversion dbconversion, InputStream inputstream, int i)
    {
        this(dbconversion, inputstream, i, (short)1);
    }

    public OracleConversionInputStream(DBConversion dbconversion, InputStream inputstream, int i, short word0)
    {
        super(4096);
        istream = inputstream;
        conversion = i;
        converter = dbconversion;
        maxSize = 0;
        totalSize = 0;
        numUnconvertedBytes = 0;
        endOfStream = false;
        nbytes = new int[1];
        csform = word0;
        currentBufferSize = initialBufferSize;
        resizableBuffer = new byte[currentBufferSize];
        switch(i)
        {
        case 0: // '\0'
            javaChars = new char[4096];
            convbuf = new byte[4096];
            break;

        case 1: // '\001'
            convbuf = new byte[2048];
            javaChars = new char[2048];
            break;

        case 2: // '\002'
            convbuf = new byte[2048];
            javaChars = new char[4096];
            break;

        case 3: // '\003'
            convbuf = new byte[1024];
            javaChars = new char[2048];
            break;

        case 4: // '\004'
            int j = 4096 / converter.getMaxCharbyteSize();
            convbuf = new byte[j * 2];
            javaChars = new char[j];
            break;

        case 5: // '\005'
            if(converter.isUcs2CharSet())
            {
                convbuf = new byte[2048];
                javaChars = new char[2048];
            } else
            {
                convbuf = new byte[4096];
                javaChars = new char[4096];
            }
            break;

        case 7: // '\007'
            int k = 4096 / (word0 != 2 ? converter.getMaxCharbyteSize() : converter.getMaxNCharbyteSize());
            javaChars = new char[k];
            break;

        case 6: // '\006'
        default:
            convbuf = new byte[4096];
            javaChars = new char[4096];
            break;
        }
    }

    public OracleConversionInputStream(DBConversion dbconversion, InputStream inputstream, int i, int j)
    {
        this(dbconversion, inputstream, i, (short)1);
        maxSize = j;
        totalSize = 0;
    }

    public OracleConversionInputStream(DBConversion dbconversion, Reader reader1, int i, int j, short word0)
    {
        this(dbconversion, (InputStream)null, i, word0);
        reader = reader1;
        maxSize = j;
        totalSize = 0;
    }

    public void setFormOfUse(short word0)
    {
        csform = word0;
    }

    public boolean needBytes(int i)
        throws IOException
    {
        return needBytes();
    }

    public boolean needBytes()
        throws IOException
    {
        if(closed)
            return false;
        if(pos < count)
            return true;
        if(istream != null)
            return needBytesFromStream();
        if(reader != null)
            return needBytesFromReader();
        else
            return false;
    }

    public boolean needBytesFromReader()
        throws IOException
    {
        int i;
        int j;
        try
        {
            i = 0;
            if(maxSize == 0)
                i = javaChars.length;
            else
                i = Math.min(maxSize - totalSize, javaChars.length);
            if(i <= 0)
                return false;
        }
        catch(SQLException sqlexception)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
        j = reader.read(javaChars, 0, i);
        if(j == -1)
            return false;
        totalSize += j;
        switch(conversion)
        {
        case 7: // '\007'
            if(csform == 2)
                count = converter.javaCharsToNCHARBytes(javaChars, j, resizableBuffer);
            else
                count = converter.javaCharsToCHARBytes(javaChars, j, resizableBuffer);
            break;

        default:
            System.arraycopy(convbuf, 0, resizableBuffer, 0, j);
            count = j;
            break;
        }
        pos = 0;
        return true;
    }

    public boolean needBytesFromStream()
        throws IOException
    {
        if(endOfStream)
            break MISSING_BLOCK_LABEL_698;
        int j;
        int k;
        int l;
        try
        {
            int i = 0;
            if(maxSize == 0)
                i = convbuf.length;
            else
                i = Math.min(maxSize - totalSize, convbuf.length);
            j = 0;
            if(i <= 0)
            {
                endOfStream = true;
                istream.close();
                if(numUnconvertedBytes != 0)
                {
                    SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 55);
                    sqlexception1.fillInStackTrace();
                    throw sqlexception1;
                }
            } else
            {
                j = istream.read(convbuf, numUnconvertedBytes, i - numUnconvertedBytes);
            }
            if(j == -1)
            {
                endOfStream = true;
                istream.close();
                if(numUnconvertedBytes != 0)
                {
                    SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 55);
                    sqlexception2.fillInStackTrace();
                    throw sqlexception2;
                }
            } else
            {
                j += numUnconvertedBytes;
                totalSize += j;
            }
            if(j <= 0)
                return false;
        }
        catch(SQLException sqlexception)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
        switch(conversion)
        {
        case 0: // '\0'
            nbytes[0] = j;
            k = converter.CHARBytesToJavaChars(convbuf, 0, javaChars, 0, nbytes, javaChars.length);
            numUnconvertedBytes = nbytes[0];
            for(l = 0; l < numUnconvertedBytes; l++)
                convbuf[l] = convbuf[j - numUnconvertedBytes];

            count = converter.javaCharsToAsciiBytes(javaChars, k, resizableBuffer);
            break;

        case 1: // '\001'
            nbytes[0] = j;
            k = converter.CHARBytesToJavaChars(convbuf, 0, javaChars, 0, nbytes, javaChars.length);
            numUnconvertedBytes = nbytes[0];
            for(l = 0; l < numUnconvertedBytes; l++)
                convbuf[l] = convbuf[j - numUnconvertedBytes];

            count = converter.javaCharsToUcs2Bytes(javaChars, k, resizableBuffer);
            break;

        case 2: // '\002'
            converter;
            k = DBConversion.RAWBytesToHexChars(convbuf, j, javaChars);
            count = converter.javaCharsToAsciiBytes(javaChars, k, resizableBuffer);
            break;

        case 3: // '\003'
            converter;
            k = DBConversion.RAWBytesToHexChars(convbuf, j, javaChars);
            count = converter.javaCharsToUcs2Bytes(javaChars, k, resizableBuffer);
            break;

        case 4: // '\004'
            converter;
            k = DBConversion.ucs2BytesToJavaChars(convbuf, j, javaChars);
            count = converter.javaCharsToCHARBytes(javaChars, k, resizableBuffer);
            break;

        case 12: // '\f'
            converter;
            k = DBConversion.ucs2BytesToJavaChars(convbuf, j, javaChars);
            count = converter.javaCharsToAsciiBytes(javaChars, k, resizableBuffer);
            break;

        case 5: // '\005'
            converter;
            DBConversion.asciiBytesToJavaChars(convbuf, j, javaChars);
            count = converter.javaCharsToCHARBytes(javaChars, j, resizableBuffer);
            break;

        case 6: // '\006'
        case 7: // '\007'
        case 8: // '\b'
        case 9: // '\t'
        case 10: // '\n'
        case 11: // '\013'
        default:
            System.arraycopy(convbuf, 0, resizableBuffer, 0, j);
            count = j;
            break;
        }
        pos = 0;
        return true;
        return false;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
