// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIoac.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.oracore.OracleTypeADT;

// Referenced classes of package oracle.jdbc.driver:
//            T4CConnection, T4CMAREngine

class T4CTTIoac
{

    static final short UACFIND = 1;
    static final short UACFALN = 2;
    static final short UACFRCP = 4;
    static final short UACFBBV = 8;
    static final short UACFNCP = 16;
    static final short UACFBLP = 32;
    static final short UACFARR = 64;
    static final short UACFIGN = 128;
    static final int UACFNSCL = 1;
    static final int UACFBUC = 2;
    static final int UACFSKP = 4;
    static final int UACFCHRCNT = 8;
    static final int UACFNOADJ = 16;
    static final int UACFCUS = 4096;
    static final int UACFLSZ = 0x2000000;
    static final int UACFVFSP = 0x8000000;
    static final byte NO_BYTES[] = new byte[0];
    int oaccsi;
    short oaccsfrm;
    static int maxBindArrayLength;
    T4CMAREngine meg;
    T4CConnection connection;
    short oacdty;
    short oacflg;
    short oacpre;
    short oacscl;
    int oacmxl;
    int oacmxlc;
    int oacmal;
    int oacfl2;
    byte oactoid[];
    int oactoidl;
    int oacvsn;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIoac(T4CConnection t4cconnection)
    {
        connection = t4cconnection;
        meg = connection.mare;
        oactoid = NO_BYTES;
    }

    void init(short word0, int i)
    {
        if(word0 == 9 || word0 == 1 || word0 == 996)
            oacdty = 1;
        else
        if(word0 == 104)
            oacdty = 11;
        else
        if(word0 == 6 || word0 == 2)
            oacdty = 2;
        else
        if(word0 == 15)
            oacdty = 23;
        else
        if(word0 == 116)
            oacdty = 102;
        else
            oacdty = word0;
        if(oacdty == 1 || oacdty == 96)
            oacfl2 = 16;
        if(oacdty == 102)
            oacmxl = 1;
        else
            oacmxl = i;
        oacflg = 3;
    }

    boolean isOldSufficient(T4CTTIoac t4cttioac)
    {
        boolean flag = false;
        if(oactoidl != 0 || t4cttioac.oactoidl != 0)
            return false;
        if(oaccsi == t4cttioac.oaccsi && oaccsfrm == t4cttioac.oaccsfrm && oacdty == t4cttioac.oacdty && oacflg == t4cttioac.oacflg && oacpre == t4cttioac.oacpre && oacscl <= t4cttioac.oacscl && (oacmxl == t4cttioac.oacmxl || t4cttioac.oacmxl > oacmxl && t4cttioac.oacmxl < 4000) && oacmxlc == t4cttioac.oacmxlc && oacmal == t4cttioac.oacmal && oacfl2 == t4cttioac.oacfl2 && oacvsn == t4cttioac.oacvsn)
            flag = true;
        return flag;
    }

    boolean isNType()
    {
        boolean flag = oaccsfrm == 2;
        return flag;
    }

    void unmarshal()
        throws IOException, SQLException
    {
        oacdty = meg.unmarshalUB1();
        oacflg = meg.unmarshalUB1();
        oacpre = meg.unmarshalUB1();
        oacscl = meg.unmarshalSB1();
        oacmxl = meg.unmarshalSB4();
        oacmal = meg.unmarshalSB4();
        oacfl2 = meg.unmarshalSB4();
        oactoid = meg.unmarshalDALC();
        oactoidl = oactoid != null ? oactoid.length : 0;
        oacvsn = meg.unmarshalUB2();
        oaccsi = meg.unmarshalUB2();
        oaccsfrm = meg.unmarshalUB1();
        if(connection.getTTCVersion() >= 2)
            oacmxlc = (int)meg.unmarshalUB4();
        if(oacmxl > 0)
            switch(oacdty)
            {
            case 2: // '\002'
                oacmxl = 22;
                break;

            case 12: // '\f'
                oacmxl = 7;
                break;

            case 181: 
                oacmxl = 13;
                break;
            }
    }

    void setMal(int i)
    {
        oacmal = i;
    }

    void addFlg(short word0)
    {
        oacflg |= word0;
    }

    void addFlg2(int i)
    {
        oacfl2 |= i;
    }

    void setFormOfUse(short word0)
    {
        oaccsfrm = word0;
    }

    void setCharset(int i)
    {
        oaccsi = i;
    }

    void setMxlc(int i)
    {
        oacmxlc = i;
    }

    void setPrecision(short word0)
    {
        oacpre = word0;
    }

    void setTimestampFractionalSecondsPrecision(short word0)
    {
        oacscl = word0;
    }

    void setADT(OracleTypeADT oracletypeadt)
    {
        oactoid = oracletypeadt.getTOID();
        oacvsn = oracletypeadt.getTypeVersion();
        oaccsi = 2;
        oaccsfrm = (short)oracletypeadt.getCharSetForm();
    }

    void marshal()
        throws IOException
    {
        meg.marshalUB1(oacdty);
        meg.marshalUB1(oacflg);
        meg.marshalUB1(oacpre);
        if(oacdty == 2 || oacdty == 180 || oacdty == 181 || oacdty == 231 || oacdty == 183)
            meg.marshalUB2(oacscl);
        else
            meg.marshalUB1(oacscl);
        meg.marshalUB4(oacmxl);
        meg.marshalSB4(oacmal);
        meg.marshalSB4(oacfl2);
        meg.marshalDALC(oactoid);
        meg.marshalUB2(oacvsn);
        meg.marshalUB2(oaccsi);
        meg.marshalUB1(oaccsfrm);
        if(connection.getTTCVersion() >= 2)
            meg.marshalUB4(oacmxlc);
    }

}
