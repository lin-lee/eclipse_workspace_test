// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T2CPreparedStatement.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.nio.*;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;
import oracle.jdbc.oracore.OracleTypeADT;

// Referenced classes of package oracle.jdbc.driver:
//            OraclePreparedStatement, Accessor, VarcharAccessor, CharAccessor, 
//            NumberAccessor, RawAccessor, BinaryFloatAccessor, BinaryDoubleAccessor, 
//            LongAccessor, LongRawAccessor, RowidAccessor, T2CResultSetAccessor, 
//            DateAccessor, TimestampAccessor, TimestamptzAccessor, TimestampltzAccessor, 
//            IntervalymAccessor, IntervaldsAccessor, ClobAccessor, BlobAccessor, 
//            BfileAccessor, NamedTypeAccessor, RefTypeAccessor, T2CConnection, 
//            Binder, DBConversion, DatabaseError, OracleSql, 
//            T2CStatement, OracleInputStream, OracleResultSetImpl, PhysicalConnection

class T2CPreparedStatement extends OraclePreparedStatement
{

    T2CConnection connection;
    int userResultSetType;
    int userResultSetConcur;
    static int T2C_EXTEND_BUFFER = -3;
    long t2cOutput[];
    static final int T2C_OUTPUT_USE_NIO = 5;
    static final int T2C_OUTPUT_STMT_LOB_PREFETCH_SIZE = 6;
    int extractedCharOffset;
    int extractedByteOffset;
    static final byte T2C_LOB_PREFETCH_SIZE_THIS_COLUMN_OFFSET = 0;
    static final byte T2C_LOB_PREFETCH_LOB_LENGTH_OFFSET = 1;
    static final byte T2C_LOB_PREFETCH_FORM_OFFSET = 2;
    static final byte T2C_LOB_PREFETCH_CHUNK_OFFSET = 3;
    static final byte T2C_LOB_PREFETCH_DATA_OFFSET = 4;
    static int PREAMBLE_PER_POSITION = 5;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T2CPreparedStatement(T2CConnection t2cconnection, String s, int i, int j, int k, int l)
        throws SQLException
    {
        super(t2cconnection, s, i, j, k, l);
        connection = null;
        userResultSetType = -1;
        userResultSetConcur = -1;
        t2cOutput = new long[10];
        userResultSetType = k;
        userResultSetConcur = l;
        connection = t2cconnection;
    }

    String bytes2String(byte abyte0[], int i, int j)
        throws SQLException
    {
        byte abyte1[] = new byte[j];
        System.arraycopy(abyte0, i, abyte1, 0, j);
        return connection.conversion.CharBytesToString(abyte1, j);
    }

    void processDescribeData()
        throws SQLException
    {
        described = true;
        describedWithNames = true;
        if(accessors == null || numberOfDefinePositions > accessors.length)
            accessors = new Accessor[numberOfDefinePositions];
        int i = connection.queryMetaData1Offset;
        int j = connection.queryMetaData2Offset;
        short aword0[] = connection.queryMetaData1;
        byte abyte0[] = connection.queryMetaData2;
        for(int k = 0; k < numberOfDefinePositions;)
        {
            T2CConnection _tmp = connection;
            short word0 = aword0[i + 0];
            T2CConnection _tmp1 = connection;
            short word1 = aword0[i + 1];
            T2CConnection _tmp2 = connection;
            short word2 = aword0[i + 11];
            T2CConnection _tmp3 = connection;
            boolean flag = aword0[i + 2] != 0;
            T2CConnection _tmp4 = connection;
            short word3 = aword0[i + 3];
            T2CConnection _tmp5 = connection;
            short word4 = aword0[i + 4];
            int l = 0;
            int i1 = 0;
            int j1 = 0;
            T2CConnection _tmp6 = connection;
            short word5 = aword0[i + 5];
            T2CConnection _tmp7 = connection;
            short word6 = aword0[i + 6];
            String s = bytes2String(abyte0, j, word6);
            T2CConnection _tmp8 = connection;
            short word7 = aword0[i + 12];
            String s1 = null;
            OracleTypeADT oracletypeadt = null;
            j += word6;
            if(word7 > 0)
            {
                s1 = bytes2String(abyte0, j, word7);
                j += word7;
                oracletypeadt = new OracleTypeADT(s1, connection);
                T2CConnection _tmp9 = connection;
                T2CConnection _tmp10 = connection;
                T2CConnection _tmp11 = connection;
                T2CConnection _tmp12 = connection;
                oracletypeadt.tdoCState = ((long)aword0[i + 7] & 65535L) << 48 | ((long)aword0[i + 8] & 65535L) << 32 | ((long)aword0[i + 9] & 65535L) << 16 | (long)aword0[i + 10] & 65535L;
            }
            Object obj = accessors[k];
            if(obj != null && !((Accessor) (obj)).useForDescribeIfPossible(word0, word1, flag, l, word3, word4, i1, j1, word5, s1))
                obj = null;
            if(obj == null)
            {
                switch(word0)
                {
                case 1: // '\001'
                    obj = new VarcharAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    if(word2 > 0)
                        ((Accessor) (obj)).setDisplaySize(word2);
                    break;

                case 96: // '`'
                    obj = new CharAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    if(word2 > 0)
                        ((Accessor) (obj)).setDisplaySize(word2);
                    break;

                case 2: // '\002'
                    obj = new NumberAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 23: // '\027'
                    obj = new RawAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 100: // 'd'
                    obj = new BinaryFloatAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 101: // 'e'
                    obj = new BinaryDoubleAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 8: // '\b'
                    obj = new LongAccessor(this, k + 1, word1, flag, l, word3, word4, i1, j1, word5);
                    rowPrefetch = 1;
                    break;

                case 24: // '\030'
                    obj = new LongRawAccessor(this, k + 1, word1, flag, l, word3, word4, i1, j1, word5);
                    rowPrefetch = 1;
                    break;

                case 104: // 'h'
                    obj = new RowidAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 102: // 'f'
                case 116: // 't'
                    obj = new T2CResultSetAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 12: // '\f'
                    obj = new DateAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 180: 
                    obj = new TimestampAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 181: 
                    obj = new TimestamptzAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 231: 
                    obj = new TimestampltzAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 182: 
                    obj = new IntervalymAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 183: 
                    obj = new IntervaldsAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 112: // 'p'
                    obj = new ClobAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 113: // 'q'
                    obj = new BlobAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 114: // 'r'
                    obj = new BfileAccessor(this, word1, flag, l, word3, word4, i1, j1, word5);
                    break;

                case 109: // 'm'
                    obj = new NamedTypeAccessor(this, word1, flag, l, word3, word4, i1, j1, word5, s1, oracletypeadt);
                    break;

                case 111: // 'o'
                    obj = new RefTypeAccessor(this, word1, flag, l, word3, word4, i1, j1, word5, s1, oracletypeadt);
                    break;

                default:
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, (new StringBuilder()).append("Unknown or unimplemented accessor type: ").append(word0).toString());
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                accessors[k] = ((Accessor) (obj));
            } else
            if(oracletypeadt != null)
            {
                obj.describeOtype = oracletypeadt;
                ((Accessor) (obj)).initMetadata();
            }
            obj.columnName = s;
            k++;
            i += 13;
        }

    }

    void executeForDescribe()
        throws SQLException
    {
        t2cOutput[0] = 0L;
        t2cOutput[2] = 0L;
        lobPrefetchMetaData = null;
        boolean flag = !described;
        boolean flag1 = false;
        boolean flag2;
        do
        {
            flag2 = false;
            if(connection.endToEndAnyChanged)
            {
                pushEndToEndValues();
                connection.endToEndAnyChanged = false;
            }
            byte abyte0[] = sqlObject.getSqlBytes(processEscapes, convertNcharLiterals);
            int i = 0;
            try
            {
                i = T2CStatement.t2cParseExecuteDescribe(this, c_state, numberOfBindPositions, numberOfBindRowsAllocated, firstRowInBatch, false, needToParse, flag, flag1, abyte0, abyte0.length, T2CStatement.convertSqlKindEnumToByte(sqlKind), rowPrefetch, batch, bindIndicators, bindIndicatorOffset, bindBytes, bindChars, bindByteOffset, bindCharOffset, ibtBindIndicators, ibtBindIndicatorOffset, ibtBindIndicatorSize, ibtBindBytes, ibtBindChars, ibtBindByteOffset, ibtBindCharOffset, returnParamMeta, connection.queryMetaData1, connection.queryMetaData2, connection.queryMetaData1Offset, connection.queryMetaData2Offset, connection.queryMetaData1Size, connection.queryMetaData2Size, preparedAllBinds, preparedCharBinds, accessors, parameterDatum, t2cOutput, defineBytes, accessorByteOffset, defineChars, accessorCharOffset, defineIndicators, accessorShortOffset, connection.plsqlCompilerWarnings);
            }
            catch(IOException ioexception)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 266);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            validRows = (int)t2cOutput[1];
            if(i == -1 || i == -4)
                connection.checkError(i);
            else
            if(i == T2C_EXTEND_BUFFER)
                i = connection.queryMetaData1Size * 2;
            if(t2cOutput[3] != 0L)
                foundPlsqlCompilerWarning();
            else
            if(t2cOutput[2] != 0L)
                sqlWarning = connection.checkError(1, sqlWarning);
            connection.endToEndECIDSequenceNumber = (short)(int)t2cOutput[4];
            needToParse = false;
            flag1 = true;
            if(sqlKind.isSELECT())
            {
                numberOfDefinePositions = i;
                if(numberOfDefinePositions > connection.queryMetaData1Size)
                {
                    flag2 = true;
                    flag1 = true;
                    connection.reallocateQueryMetaData(numberOfDefinePositions, numberOfDefinePositions * 8);
                }
            } else
            {
                numberOfDefinePositions = 0;
                validRows = i;
            }
        } while(flag2);
        processDescribeData();
    }

    void pushEndToEndValues()
        throws SQLException
    {
        T2CConnection t2cconnection = connection;
        byte abyte0[] = new byte[0];
        byte abyte1[] = new byte[0];
        byte abyte2[] = new byte[0];
        byte abyte3[] = new byte[0];
        if(t2cconnection.endToEndValues != null)
        {
            T2CConnection _tmp = t2cconnection;
            if(t2cconnection.endToEndHasChanged[0])
            {
                T2CConnection _tmp1 = t2cconnection;
                String s = t2cconnection.endToEndValues[0];
                if(s != null)
                    abyte0 = DBConversion.stringToDriverCharBytes(s, t2cconnection.m_clientCharacterSet);
                T2CConnection _tmp2 = t2cconnection;
                t2cconnection.endToEndHasChanged[0] = false;
            }
            T2CConnection _tmp3 = t2cconnection;
            if(t2cconnection.endToEndHasChanged[1])
            {
                T2CConnection _tmp4 = t2cconnection;
                String s1 = t2cconnection.endToEndValues[1];
                if(s1 != null)
                    abyte1 = DBConversion.stringToDriverCharBytes(s1, t2cconnection.m_clientCharacterSet);
                T2CConnection _tmp5 = t2cconnection;
                t2cconnection.endToEndHasChanged[1] = false;
            }
            T2CConnection _tmp6 = t2cconnection;
            if(t2cconnection.endToEndHasChanged[2])
            {
                T2CConnection _tmp7 = t2cconnection;
                String s2 = t2cconnection.endToEndValues[2];
                if(s2 != null)
                    abyte2 = DBConversion.stringToDriverCharBytes(s2, t2cconnection.m_clientCharacterSet);
                T2CConnection _tmp8 = t2cconnection;
                t2cconnection.endToEndHasChanged[2] = false;
            }
            T2CConnection _tmp9 = t2cconnection;
            if(t2cconnection.endToEndHasChanged[3])
            {
                T2CConnection _tmp10 = t2cconnection;
                String s3 = t2cconnection.endToEndValues[3];
                if(s3 != null)
                    abyte3 = DBConversion.stringToDriverCharBytes(s3, t2cconnection.m_clientCharacterSet);
                T2CConnection _tmp11 = t2cconnection;
                t2cconnection.endToEndHasChanged[3] = false;
            }
            T2CStatement.t2cEndToEndUpdate(c_state, abyte0, abyte0.length, abyte1, abyte1.length, abyte2, abyte2.length, abyte3, abyte3.length, t2cconnection.endToEndECIDSequenceNumber);
        }
    }

    void executeForRows(boolean flag)
        throws SQLException
    {
        if(connection.endToEndAnyChanged)
        {
            pushEndToEndValues();
            connection.endToEndAnyChanged = false;
        }
        if(!flag)
        {
            if(numberOfDefinePositions > 0)
                doDefineExecuteFetch();
            else
                executeForDescribe();
        } else
        if(numberOfDefinePositions > 0)
            doDefineFetch();
        needToPrepareDefineBuffer = false;
    }

    void setupForDefine()
        throws SQLException
    {
        if(numberOfDefinePositions > connection.queryMetaData1Size)
        {
            int i = numberOfDefinePositions / 100 + 1;
            connection.reallocateQueryMetaData(connection.queryMetaData1Size * i, connection.queryMetaData2Size * i * 8);
        }
        short aword0[] = connection.queryMetaData1;
        int j = connection.queryMetaData1Offset;
        int k = 0;
        do
        {
            if(k >= numberOfDefinePositions)
                break;
            Accessor accessor = accessors[k];
            if(accessor == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            T2CConnection _tmp = connection;
            aword0[j + 0] = (short)accessor.defineType;
            T2CConnection _tmp1 = connection;
            aword0[j + 11] = (short)accessor.charLength;
            T2CConnection _tmp2 = connection;
            aword0[j + 1] = (short)accessor.byteLength;
            T2CConnection _tmp3 = connection;
            aword0[j + 5] = accessor.formOfUse;
            if(accessor.internalOtype != null)
            {
                long l = ((OracleTypeADT)accessor.internalOtype).getTdoCState();
                T2CConnection _tmp4 = connection;
                aword0[j + 7] = (short)(int)((l & 0xffff000000000000L) >> 48);
                T2CConnection _tmp5 = connection;
                aword0[j + 8] = (short)(int)((l & 0xffff00000000L) >> 32);
                T2CConnection _tmp6 = connection;
                aword0[j + 9] = (short)(int)((l & 0xffff0000L) >> 16);
                T2CConnection _tmp7 = connection;
                aword0[j + 10] = (short)(int)(l & 65535L);
            }
            switch(accessor.internalType)
            {
            case 112: // 'p'
            case 113: // 'q'
                if(accessor.lobPrefetchSizeForThisColumn == -1)
                    accessor.lobPrefetchSizeForThisColumn = defaultLobPrefetchSize;
                aword0[j + 7] = (short)accessor.lobPrefetchSizeForThisColumn;
                break;
            }
            k++;
            j += 13;
        } while(true);
    }

    Object[] getLobPrefetchMetaData()
    {
        Object aobj[] = null;
        Object obj = null;
        int ai[] = null;
        int i = 0;
        int j = 0;
        if(accessors != null)
        {
            for(int k = 0; k < numberOfDefinePositions; k++)
                switch(accessors[k].internalType)
                {
                default:
                    break;

                case 8: // '\b'
                case 24: // '\030'
                    j = k;
                    break;

                case 112: // 'p'
                case 113: // 'q'
                    if(ai == null)
                        ai = new int[accessors.length];
                    if(accessors[k].lobPrefetchSizeForThisColumn != -1)
                    {
                        i++;
                        ai[k] = accessors[k].lobPrefetchSizeForThisColumn;
                    } else
                    {
                        ai[k] = -1;
                    }
                    break;
                }

        }
        if(i > 0)
        {
            if(aobj == null)
                aobj = (new Object[] {
                    null, new long[rowPrefetch * i], new byte[accessors.length], new int[accessors.length], new Object[rowPrefetch * i]
                });
            int l = 0;
            do
            {
                if(l >= j)
                    break;
                switch(accessors[l].internalType)
                {
                case 112: // 'p'
                case 113: // 'q'
                    accessors[l].lobPrefetchSizeForThisColumn = -1;
                    ai[l] = -1;
                    break;
                }
                l++;
            } while(true);
            aobj[0] = ai;
        }
        return aobj;
    }

    void processLobPrefetchMetaData(Object aobj[])
    {
        int i = 0;
        int j = validRows != -2 ? validRows : 1;
        byte abyte0[] = (byte[])(byte[])aobj[2];
        int ai[] = (int[])(int[])aobj[3];
        long al[] = (long[])(long[])aobj[1];
        Object aobj1[] = (Object[])(Object[])aobj[4];
        int ai1[] = (int[])(int[])aobj[0];
        if(accessors != null)
        {
            for(int k = 0; k < numberOfDefinePositions; k++)
                switch(accessors[k].internalType)
                {
                default:
                    break;

                case 112: // 'p'
                case 113: // 'q'
                    if(accessors[k].lobPrefetchSizeForThisColumn >= 0)
                    {
                        Accessor accessor = accessors[k];
                        if(accessor.prefetchedLobDataL == null || accessor.prefetchedLobDataL.length < rowPrefetch)
                        {
                            if(accessor.internalType == 112)
                                accessor.prefetchedLobCharData = new char[rowPrefetch][];
                            else
                                accessor.prefetchedLobData = new byte[rowPrefetch][];
                            accessor.prefetchedLobChunkSize = new int[rowPrefetch];
                            accessor.prefetchedClobFormOfUse = new byte[rowPrefetch];
                            accessor.prefetchedLobDataL = new int[rowPrefetch];
                            accessor.prefetchedLobSize = new long[rowPrefetch];
                        }
                        int l = j * i;
                        for(int i1 = 0; i1 < j; i1++)
                        {
                            accessor.prefetchedLobChunkSize[i1] = ai[k];
                            accessor.prefetchedClobFormOfUse[i1] = abyte0[k];
                            accessor.prefetchedLobSize[i1] = al[l + i1];
                            accessor.prefetchedLobDataL[i1] = 0;
                            if(ai1[k] <= 0 || al[l + i1] <= 0L)
                                continue;
                            if(accessor.internalType == 112)
                            {
                                accessor.prefetchedLobCharData[i1] = (char[])(char[])aobj1[l + i1];
                                if(accessor.prefetchedLobCharData[i1] != null)
                                    accessor.prefetchedLobDataL[i1] = accessor.prefetchedLobCharData[i1].length;
                                continue;
                            }
                            accessor.prefetchedLobData[i1] = (byte[])(byte[])aobj1[l + i1];
                            if(accessor.prefetchedLobData[i1] != null)
                                accessor.prefetchedLobDataL[i1] = accessor.prefetchedLobData[i1].length;
                        }

                        i++;
                    }
                    break;
                }

        }
    }

    void doDefineFetch()
        throws SQLException
    {
        if(!needToPrepareDefineBuffer)
            throw new Error((new StringBuilder()).append("doDefineFetch called when needToPrepareDefineBuffer=false ").append(sqlObject.getSql(processEscapes, convertNcharLiterals)).toString());
        setupForDefine();
        t2cOutput[2] = 0L;
        t2cOutput[5] = connection.useNio ? 1 : 0;
        t2cOutput[6] = defaultLobPrefetchSize;
        if(connection.useNio)
        {
            resetNioAttributesBeforeFetch();
            allocateNioBuffersIfRequired(defineChars != null ? defineChars.length : 0, defineBytes != null ? defineBytes.length : 0, defineIndicators != null ? defineIndicators.length : 0);
        }
        if(lobPrefetchMetaData == null)
            lobPrefetchMetaData = getLobPrefetchMetaData();
        validRows = T2CStatement.t2cDefineFetch(this, c_state, rowPrefetch, connection.queryMetaData1, connection.queryMetaData2, connection.queryMetaData1Offset, connection.queryMetaData2Offset, accessors, defineBytes, accessorByteOffset, defineChars, accessorCharOffset, defineIndicators, accessorShortOffset, t2cOutput, nioBuffers, lobPrefetchMetaData);
        if(validRows == -1 || validRows == -4)
            connection.checkError(validRows);
        if(t2cOutput[2] != 0L)
            sqlWarning = connection.checkError(1, sqlWarning);
        if(connection.useNio && (validRows > 0 || validRows == -2))
            extractNioDefineBuffers(0);
        if(lobPrefetchMetaData != null)
            processLobPrefetchMetaData(lobPrefetchMetaData);
    }

    void allocateNioBuffersIfRequired(int i, int j, int k)
        throws SQLException
    {
        if(nioBuffers == null)
            nioBuffers = new ByteBuffer[4];
        if(j > 0)
            if(nioBuffers[0] == null || nioBuffers[0].capacity() < j)
                nioBuffers[0] = ByteBuffer.allocateDirect(j);
            else
            if(nioBuffers[0] != null)
                nioBuffers[0].rewind();
        i *= 2;
        if(i > 0)
            if(nioBuffers[1] == null || nioBuffers[1].capacity() < i)
                nioBuffers[1] = ByteBuffer.allocateDirect(i);
            else
            if(nioBuffers[1] != null)
                nioBuffers[1].rewind();
        k *= 2;
        if(k > 0)
            if(nioBuffers[2] == null || nioBuffers[2].capacity() < k)
                nioBuffers[2] = ByteBuffer.allocateDirect(k);
            else
            if(nioBuffers[2] != null)
                nioBuffers[2].rewind();
    }

    void doDefineExecuteFetch()
        throws SQLException
    {
        short aword0[] = null;
        if(needToPrepareDefineBuffer || needToParse)
        {
            setupForDefine();
            aword0 = connection.queryMetaData1;
        }
        t2cOutput[0] = 0L;
        t2cOutput[2] = 0L;
        byte abyte0[] = sqlObject.getSqlBytes(processEscapes, convertNcharLiterals);
        t2cOutput[5] = connection.useNio ? 1 : 0;
        t2cOutput[6] = defaultLobPrefetchSize;
        if(connection.useNio)
        {
            resetNioAttributesBeforeFetch();
            allocateNioBuffersIfRequired(defineChars != null ? defineChars.length : 0, defineBytes != null ? defineBytes.length : 0, defineIndicators != null ? defineIndicators.length : 0);
        }
        if(lobPrefetchMetaData == null)
            lobPrefetchMetaData = getLobPrefetchMetaData();
        try
        {
            validRows = T2CStatement.t2cDefineExecuteFetch(this, c_state, numberOfDefinePositions, numberOfBindPositions, numberOfBindRowsAllocated, firstRowInBatch, false, needToParse, abyte0, abyte0.length, T2CStatement.convertSqlKindEnumToByte(sqlKind), rowPrefetch, batch, bindIndicators, bindIndicatorOffset, bindBytes, bindChars, bindByteOffset, bindCharOffset, aword0, connection.queryMetaData2, connection.queryMetaData1Offset, connection.queryMetaData2Offset, preparedAllBinds, preparedCharBinds, accessors, parameterDatum, t2cOutput, defineBytes, accessorByteOffset, defineChars, accessorCharOffset, defineIndicators, accessorShortOffset, nioBuffers, lobPrefetchMetaData);
        }
        catch(IOException ioexception)
        {
            validRows = 0;
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(validRows == -1)
            connection.checkError(validRows);
        if(t2cOutput[2] != 0L)
            sqlWarning = connection.checkError(1, sqlWarning);
        connection.endToEndECIDSequenceNumber = (short)(int)t2cOutput[4];
        if(connection.useNio && (validRows > 0 || validRows == -2))
            extractNioDefineBuffers(0);
        if(lobPrefetchMetaData != null)
            processLobPrefetchMetaData(lobPrefetchMetaData);
        needToParse = false;
    }

    void fetch()
        throws SQLException
    {
        if(numberOfDefinePositions > 0)
            if(needToPrepareDefineBuffer)
            {
                doDefineFetch();
            } else
            {
                t2cOutput[2] = 0L;
                t2cOutput[5] = connection.useNio ? 1 : 0;
                t2cOutput[6] = defaultLobPrefetchSize;
                if(connection.useNio)
                {
                    resetNioAttributesBeforeFetch();
                    allocateNioBuffersIfRequired(defineChars != null ? defineChars.length : 0, defineBytes != null ? defineBytes.length : 0, defineIndicators != null ? defineIndicators.length : 0);
                }
                if(lobPrefetchMetaData == null)
                    lobPrefetchMetaData = getLobPrefetchMetaData();
                validRows = T2CStatement.t2cFetch(c_state, needToPrepareDefineBuffer, rowPrefetch, accessors, defineBytes, accessorByteOffset, defineChars, accessorCharOffset, defineIndicators, accessorShortOffset, t2cOutput, nioBuffers, lobPrefetchMetaData);
                if(validRows == -1 || validRows == -4)
                    connection.checkError(validRows);
                if(t2cOutput[2] != 0L)
                    sqlWarning = connection.checkError(1, sqlWarning);
                if(lobPrefetchMetaData != null)
                    processLobPrefetchMetaData(lobPrefetchMetaData);
                if(connection.useNio && (validRows > 0 || validRows == -2))
                    extractNioDefineBuffers(0);
            }
    }

    void resetNioAttributesBeforeFetch()
    {
        extractedCharOffset = 0;
        extractedByteOffset = 0;
    }

    void extractNioDefineBuffers(int i)
        throws SQLException
    {
        if(accessors == null || defineIndicators == null || i == numberOfDefinePositions)
            return;
        int j = 0;
        int k = 0;
        int l = 0;
        int i1 = 0;
        int j1 = 0;
        if(!hasStream)
        {
            j = defineBytes == null ? 0 : defineBytes.length;
            k = defineChars == null ? 0 : defineChars.length;
            l = defineIndicators.length;
        } else
        {
            if(numberOfDefinePositions > i)
            {
                j1 = accessors[i].indicatorIndex;
                i1 = accessors[i].lengthIndex;
            }
            int k1 = i;
label0:
            do
            {
                if(k1 >= numberOfDefinePositions)
                    break;
                switch(accessors[k1].internalType)
                {
                case 8: // '\b'
                case 24: // '\030'
                    break label0;

                default:
                    j += accessors[k1].byteLength;
                    k += accessors[k1].charLength;
                    l++;
                    k1++;
                    break;
                }
            } while(true);
        }
        ByteBuffer bytebuffer = nioBuffers[0];
        if(bytebuffer != null && defineBytes != null && j > 0)
        {
            bytebuffer.position(extractedByteOffset);
            bytebuffer.get(defineBytes, extractedByteOffset, j);
            extractedByteOffset += j;
        }
        if(nioBuffers[1] != null && defineChars != null)
        {
            ByteBuffer bytebuffer1 = nioBuffers[1].order(ByteOrder.LITTLE_ENDIAN);
            CharBuffer charbuffer = bytebuffer1.asCharBuffer();
            if(k > 0)
            {
                charbuffer.position(extractedCharOffset);
                charbuffer.get(defineChars, extractedCharOffset, k);
                extractedCharOffset += k;
            }
        }
        if(nioBuffers[2] != null)
        {
            ByteBuffer bytebuffer2 = nioBuffers[2].order(ByteOrder.LITTLE_ENDIAN);
            ShortBuffer shortbuffer = bytebuffer2.asShortBuffer();
            if(hasStream)
            {
                if(l > 0)
                {
                    shortbuffer.position(j1);
                    shortbuffer.get(defineIndicators, j1, l);
                    shortbuffer.position(i1);
                    shortbuffer.get(defineIndicators, i1, l);
                }
            } else
            {
                shortbuffer.get(defineIndicators);
            }
        }
    }

    void doClose()
        throws SQLException
    {
        if(defineBytes != null)
        {
            defineBytes = null;
            accessorByteOffset = 0;
        }
        if(defineChars != null)
        {
            defineChars = null;
            accessorCharOffset = 0;
        }
        if(defineIndicators != null)
        {
            defineIndicators = null;
            accessorShortOffset = 0;
        }
        int i = T2CStatement.t2cCloseStatement(c_state);
        nioBuffers = null;
        if(i != 0)
            connection.checkError(i);
        t2cOutput = null;
    }

    void closeQuery()
        throws SQLException
    {
        if(streamList != null)
            for(; nextStream != null; nextStream = nextStream.nextStream)
                try
                {
                    nextStream.close();
                }
                catch(IOException ioexception)
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }

    }

    Accessor allocateAccessor(int i, int j, int k, int l, short word0, String s, boolean flag)
        throws SQLException
    {
        if(i == 116 || i == 102)
        {
            if(flag && s != null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception.fillInStackTrace();
                throw sqlexception;
            } else
            {
                T2CResultSetAccessor t2cresultsetaccessor = new T2CResultSetAccessor(this, l, word0, j, flag);
                return t2cresultsetaccessor;
            }
        } else
        {
            return super.allocateAccessor(i, j, k, l, word0, s, flag);
        }
    }

    void closeUsedStreams(int i)
        throws SQLException
    {
        for(; nextStream != null && nextStream.columnIndex < i; nextStream = nextStream.nextStream)
            try
            {
                nextStream.close();
            }
            catch(IOException ioexception)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }

        if(nextStream != null)
            try
            {
                nextStream.needBytes();
            }
            catch(IOException ioexception1)
            {
                interalCloseOnIOException(ioexception1);
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception1);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
    }

    void interalCloseOnIOException(IOException ioexception)
        throws SQLException
    {
        closed = true;
        if(currentResultSet != null)
            currentResultSet.closed = true;
        doClose();
    }

    void fetchDmlReturnParams()
        throws SQLException
    {
        rowsDmlReturned = T2CStatement.t2cGetRowsDmlReturned(c_state);
        if(rowsDmlReturned != 0)
        {
            allocateDmlReturnStorage();
            int i = T2CStatement.t2cFetchDmlReturnParams(c_state, returnParamAccessors, returnParamBytes, returnParamChars, returnParamIndicators);
            if(i == -1 || i == -4)
                connection.checkError(i);
            if(t2cOutput[2] != 0L)
                sqlWarning = connection.checkError(1, sqlWarning);
            if(connection.useNio && (i > 0 || i == -2))
                extractNioDefineBuffers(0);
        }
        returnParamsFetched = true;
    }

    void initializeIndicatorSubRange()
    {
        bindIndicatorSubRange = numberOfBindPositions * PREAMBLE_PER_POSITION;
    }

    int calculateIndicatorSubRangeSize()
    {
        return numberOfBindPositions * PREAMBLE_PER_POSITION;
    }

    short getInoutIndicator(int i)
    {
        return bindIndicators[i * PREAMBLE_PER_POSITION];
    }

    void prepareBindPreambles(int i, int j)
    {
        int k = calculateIndicatorSubRangeSize();
        int l = bindIndicatorSubRange - k;
        OracleTypeADT aoracletypeadt[] = parameterOtype != null ? parameterOtype[firstRowInBatch] : null;
        for(int i1 = 0; i1 < numberOfBindPositions; i1++)
        {
            Binder binder = lastBinders[i1];
            short word0;
            OracleTypeADT oracletypeadt;
            if(binder == theReturnParamBinder)
            {
                oracletypeadt = (OracleTypeADT)returnParamAccessors[i1].internalOtype;
                word0 = 0;
            } else
            {
                oracletypeadt = aoracletypeadt != null ? aoracletypeadt[i1] : null;
                if(outBindAccessors == null)
                {
                    word0 = 0;
                } else
                {
                    Accessor accessor = outBindAccessors[i1];
                    if(accessor == null)
                        word0 = 0;
                    else
                    if(binder == theOutBinder)
                    {
                        word0 = 1;
                        if(oracletypeadt == null)
                            oracletypeadt = (OracleTypeADT)accessor.internalOtype;
                    } else
                    {
                        word0 = 2;
                    }
                }
                word0 = binder.updateInoutIndicatorValue(word0);
            }
            bindIndicators[l++] = word0;
            if(oracletypeadt != null)
            {
                long l1 = oracletypeadt.getTdoCState();
                bindIndicators[l + 0] = (short)(int)(l1 >> 48 & 65535L);
                bindIndicators[l + 1] = (short)(int)(l1 >> 32 & 65535L);
                bindIndicators[l + 2] = (short)(int)(l1 >> 16 & 65535L);
                bindIndicators[l + 3] = (short)(int)(l1 & 65535L);
            }
            l += 4;
        }

    }

    void releaseBuffers()
    {
        super.releaseBuffers();
    }

    void doDescribe(boolean flag)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(described)
            return;
        if(!isOpen)
        {
            connection.open(this);
            isOpen = true;
        }
        boolean flag1;
        do
        {
            flag1 = false;
            boolean flag2 = sqlKind.isSELECT() && needToParse && (!described || !serverCursor);
            byte abyte0[] = flag2 ? sqlObject.getSqlBytes(processEscapes, convertNcharLiterals) : PhysicalConnection.EMPTY_BYTE_ARRAY;
            numberOfDefinePositions = T2CStatement.t2cDescribe(c_state, connection.queryMetaData1, connection.queryMetaData2, connection.queryMetaData1Offset, connection.queryMetaData2Offset, connection.queryMetaData1Size, connection.queryMetaData2Size, abyte0, abyte0.length, flag2);
            if(!described)
                described = true;
            if(numberOfDefinePositions == -1)
                connection.checkError(numberOfDefinePositions);
            if(numberOfDefinePositions == T2C_EXTEND_BUFFER)
            {
                flag1 = true;
                connection.reallocateQueryMetaData(connection.queryMetaData1Size * 2, connection.queryMetaData2Size * 2);
            }
        } while(flag1);
        processDescribeData();
    }

}
