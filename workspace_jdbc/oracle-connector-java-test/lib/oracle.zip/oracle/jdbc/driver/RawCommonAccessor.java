// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   RawCommonAccessor.java

package oracle.jdbc.driver;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.util.RepConversion;
import oracle.sql.Datum;
import oracle.sql.RAW;

// Referenced classes of package oracle.jdbc.driver:
//            Accessor, OracleStatement, PhysicalConnection, DBConversion

class RawCommonAccessor extends Accessor
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    RawCommonAccessor()
    {
    }

    void init(OracleStatement oraclestatement, int i, int j, int k, short word0, int l)
        throws SQLException
    {
        init(oraclestatement, i, j, word0, false);
        initForDataAccess(l, k, null);
    }

    void init(OracleStatement oraclestatement, int i, int j, int k, boolean flag, int l, int i1, 
            int j1, int k1, int l1, short word0)
        throws SQLException
    {
        init(oraclestatement, i, j, word0, false);
        initForDescribe(i, k, flag, l, i1, j1, k1, l1, word0, null);
        int i2 = oraclestatement.maxFieldSize;
        if(i2 > 0 && (k == 0 || i2 < k))
            k = i2;
        initForDataAccess(0, k, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        internalTypeMaxLength = 0x7fffffff;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
    }

    String getString(int i)
        throws SQLException
    {
        byte abyte0[] = getBytes(i);
        if(abyte0 == null)
            return null;
        int j = abyte0.length;
        if(j == 0)
            return null;
        else
            return RepConversion.bArray2String(abyte0);
    }

    InputStream getAsciiStream(int i)
        throws SQLException
    {
        byte abyte0[] = getBytes(i);
        if(abyte0 == null)
        {
            return null;
        } else
        {
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            return physicalconnection.conversion.ConvertStream(new ByteArrayInputStream(abyte0), 2);
        }
    }

    InputStream getUnicodeStream(int i)
        throws SQLException
    {
        byte abyte0[] = getBytes(i);
        if(abyte0 == null)
        {
            return null;
        } else
        {
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            return physicalconnection.conversion.ConvertStream(new ByteArrayInputStream(abyte0), 3);
        }
    }

    Reader getCharacterStream(int i)
        throws SQLException
    {
        byte abyte0[] = getBytes(i);
        if(abyte0 == null)
        {
            return null;
        } else
        {
            int j = abyte0.length;
            char ac[] = new char[j << 1];
            DBConversion _tmp = statement.connection.conversion;
            int k = DBConversion.RAWBytesToHexChars(abyte0, j, ac);
            return new CharArrayReader(ac, 0, k);
        }
    }

    InputStream getBinaryStream(int i)
        throws SQLException
    {
        byte abyte0[] = getBytes(i);
        if(abyte0 == null)
            return null;
        else
            return new ByteArrayInputStream(abyte0);
    }

    Object getObject(int i)
        throws SQLException
    {
        return getBytes(i);
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        return getBytes(i);
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        return getRAW(i);
    }

    RAW getRAW(int i)
        throws SQLException
    {
        byte abyte0[] = getBytes(i);
        if(abyte0 == null)
            return null;
        else
            return new RAW(abyte0);
    }

}
