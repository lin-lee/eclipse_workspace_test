// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C8Oall.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Vector;
import oracle.jdbc.internal.*;
import oracle.jdbc.oracore.OracleTypeADT;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4C8TTIrxh, T4CTTIrxd, T4CTTIdcb, 
//            T4CTTIoac, T4CTTIiov, PlsqlIndexTableAccessor, TypeAccessor, 
//            T4CConnection, DBConversion, OracleStatement, NTFDCNRegistration, 
//            Accessor, DatabaseError, T4CTTIoer, PhysicalConnection, 
//            T4CMAREngine, KeywordValueI

final class T4C8Oall extends T4CTTIfun
{

    Vector nonFatalIOExceptions;
    static final byte EMPTY_BYTES[] = new byte[0];
    static final int UOPF_PRS = 1;
    static final int UOPF_BND = 8;
    static final int UOPF_EXE = 32;
    static final int UOPF_FEX = 512;
    static final int UOPF_FCH = 64;
    static final int UOPF_CAN = 128;
    static final int UOPF_COM = 256;
    static final int UOPF_DSY = 8192;
    static final int UOPF_SIO = 1024;
    static final int UOPF_NPL = 32768;
    static final int UOPF_DFN = 16;
    static final int EXE_COMMIT_ON_SUCCESS = 1;
    static final int EXE_LEAVE_CUR_MAPPED = 2;
    static final int EXE_BATCH_DML_ERRORS = 4;
    static final int EXE_SCROL_READ_ONLY = 8;
    static final int AL8KW_MAXLANG = 63;
    static final int AL8KW_TIMEZONE = 163;
    static final int AL8KW_ERR_OVLAP = 164;
    static final int AL8KW_SESSION_ID = 165;
    static final int AL8KW_SERIAL_NUM = 166;
    static final int AL8KW_TAG_FOUND = 167;
    static final int AL8KW_SCHEMA_NAME = 168;
    static final int AL8KW_SCHEMA_ID = 169;
    static final int AL8KW_ENABLED_ROLES = 170;
    static final int AL8KW_AUX_SESSSTATE = 171;
    static final String NLS_KEYS[] = {
        "AUTH_NLS_LXCCURRENCY", "AUTH_NLS_LXCISOCURR", "AUTH_NLS_LXCNUMERICS", null, null, null, null, "AUTH_NLS_LXCDATEFM", "AUTH_NLS_LXCDATELANG", "AUTH_NLS_LXCTERRITORY", 
        "SESSION_NLS_LXCCHARSET", "AUTH_NLS_LXCSORT", "AUTH_NLS_LXCCALENDAR", null, null, null, "AUTH_NLS_LXLAN", null, null, null, 
        null, null, null, null, null, null, null, null, null, null, 
        null, null, null, null, null, null, null, null, null, null, 
        null, null, null, null, null, null, null, null, null, null, 
        "AUTH_NLS_LXCSORT", null, "AUTH_NLS_LXCUNIONCUR", null, null, null, null, "AUTH_NLS_LXCTIMEFM", "AUTH_NLS_LXCSTMPFM", "AUTH_NLS_LXCTTZNFM", 
        "AUTH_NLS_LXCSTZNFM", "SESSION_NLS_LXCNLSLENSEM", "SESSION_NLS_LXCNCHAREXCP", "SESSION_NLS_LXCNCHARIMP"
    };
    static final int LDIREGIDFLAG = 120;
    static final int LDIREGIDSET = 181;
    static final int LDIMAXTIMEFIELD = 60;
    int rowsProcessed;
    int numberOfDefinePositions;
    long options;
    int cursor;
    byte sqlStmt[];
    final long al8i4[] = new long[13];
    boolean plsql;
    Accessor definesAccessors[];
    int definesLength;
    Accessor outBindAccessors[];
    int numberOfBindPositions;
    InputStream parameterStream[][];
    byte parameterDatum[][][];
    OracleTypeADT parameterOtype[][];
    short bindIndicators[];
    byte bindBytes[];
    char bindChars[];
    int bindIndicatorSubRange;
    byte tmpBindsByteArray[];
    DBConversion conversion;
    byte ibtBindBytes[];
    char ibtBindChars[];
    short ibtBindIndicators[];
    boolean sendBindsDefinition;
    oracle.jdbc.driver.OracleStatement oracleStatement;
    short dbCharSet;
    short NCharSet;
    T4CTTIrxd rxd;
    T4C8TTIrxh rxh;
    T4CTTIdcb dcb;
    oracle.jdbc.internal.OracleStatement.SqlKind typeOfStatement;
    int defCols;
    int rowsToFetch;
    boolean aFetchWasDone;
    T4CTTIoac oacdefBindsSent[];
    T4CTTIoac oacdefDefines[];
    int definedColumnSize[];
    int definedColumnType[];
    int definedColumnFormOfUse[];
    NTFDCNRegistration registration;
    static final int AL8TXCUR = 1;
    static final int AL8TXDON = 2;
    static final int AL8TXRON = 4;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C8Oall(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        nonFatalIOExceptions = null;
        sqlStmt = new byte[0];
        plsql = false;
        sendBindsDefinition = false;
        defCols = 0;
        aFetchWasDone = false;
        registration = null;
        setFunCode((short)94);
        rxh = new T4C8TTIrxh(t4cconnection);
        rxd = new T4CTTIrxd(t4cconnection);
        dcb = new T4CTTIdcb(t4cconnection);
    }

    void doOALL(boolean flag, boolean flag1, boolean flag2, boolean flag3, boolean flag4, oracle.jdbc.internal.OracleStatement.SqlKind sqlkind, int i, 
            byte abyte0[], int j, Accessor aaccessor[], int k, Accessor aaccessor1[], int l, byte abyte1[], 
            char ac[], short aword0[], int i1, DBConversion dbconversion, byte abyte2[], InputStream ainputstream[][], byte abyte3[][][], 
            OracleTypeADT aoracletypeadt[][], oracle.jdbc.driver.OracleStatement oraclestatement, byte abyte4[], char ac1[], short aword1[], T4CTTIoac at4cttioac[], int ai[], 
            int ai1[], int ai2[], NTFDCNRegistration ntfdcnregistration)
        throws SQLException, IOException
    {
        typeOfStatement = sqlkind;
        cursor = i;
        sqlStmt = flag ? abyte0 : EMPTY_BYTES;
        rowsToFetch = j;
        outBindAccessors = aaccessor;
        numberOfBindPositions = k;
        definesAccessors = aaccessor1;
        definesLength = l;
        bindBytes = abyte1;
        bindChars = ac;
        bindIndicators = aword0;
        bindIndicatorSubRange = i1;
        conversion = dbconversion;
        tmpBindsByteArray = abyte2;
        parameterStream = ainputstream;
        parameterDatum = abyte3;
        parameterOtype = aoracletypeadt;
        oracleStatement = oraclestatement;
        ibtBindBytes = abyte4;
        ibtBindChars = ac1;
        ibtBindIndicators = aword1;
        oacdefBindsSent = at4cttioac;
        definedColumnType = ai;
        definedColumnSize = ai1;
        definedColumnFormOfUse = ai2;
        registration = ntfdcnregistration;
        dbCharSet = dbconversion.getServerCharSetId();
        NCharSet = dbconversion.getNCharSetId();
        int j1 = 0;
        if(bindIndicators != null)
            j1 = ((bindIndicators[bindIndicatorSubRange + 3] & 0xffff) << 16) + (bindIndicators[bindIndicatorSubRange + 4] & 0xffff);
        if(abyte0 == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 431);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(!typeOfStatement.isDML() && j1 > 1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        rowsProcessed = 0;
        options = 0L;
        plsql = typeOfStatement.isPlsqlOrCall();
        sendBindsDefinition = false;
        if(receiveState != 0)
            receiveState = 0;
        rxh.init();
        rxd.init();
        oer.init();
        if(flag4)
            initDefinesDefinition();
        if(numberOfBindPositions > 0 && bindIndicators != null)
        {
            if(oacdefBindsSent == null)
                oacdefBindsSent = new T4CTTIoac[numberOfBindPositions];
            sendBindsDefinition = initBindsDefinition(oacdefBindsSent);
        }
        options = setOptions(flag, flag1, flag2, flag4);
        if((options & 1L) > 0L)
            al8i4[0] = 1L;
        else
            al8i4[0] = 0L;
        if(plsql || typeOfStatement.isOTHER())
            al8i4[1] = 1L;
        else
        if(flag3)
        {
            if(flag2 && oracleStatement.connection.useFetchSizeWithLongColumn)
                al8i4[1] = rowsToFetch;
            else
                al8i4[1] = 0L;
        } else
        if(typeOfStatement.isDML())
            al8i4[1] = j1 != 0 ? j1 : oracleStatement.batch;
        else
        if(flag2 && !flag3)
            al8i4[1] = rowsToFetch;
        else
            al8i4[1] = 0L;
        if(typeOfStatement.isSELECT())
            al8i4[7] = 1L;
        else
            al8i4[7] = 0L;
        long l1 = oracleStatement.inScn;
        int k1 = (int)l1;
        int i2 = (int)(l1 >> 32);
        al8i4[5] = k1;
        al8i4[6] = i2;
        rowsProcessed = 0;
        aFetchWasDone = false;
        rxd.setNumberOfColumns(definesLength);
        if((options & 64L) != 0L && (options & 32L) == 0L && (options & 1L) == 0L && (options & 8L) == 0L && (options & 16L) == 0L && !oracleStatement.needToSendOalToFetch)
            setFunCode((short)5);
        else
            setFunCode((short)94);
        nonFatalIOExceptions = null;
        doRPC();
        if((options & 32L) != 0L)
            oracleStatement.inScn = 0L;
        ibtBindIndicators = null;
        ibtBindChars = null;
        ibtBindBytes = null;
        tmpBindsByteArray = null;
        outBindAccessors = null;
        bindBytes = null;
        bindChars = null;
        bindIndicators = null;
        oracleStatement = null;
        if(nonFatalIOExceptions != null)
        {
            IOException ioexception = (IOException)nonFatalIOExceptions.get(0);
            try
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 266);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
            catch(SQLException sqlexception3)
            {
                sqlexception3.initCause(ioexception);
                throw sqlexception3;
            }
        } else
        {
            return;
        }
    }

    void readBVC()
        throws IOException, SQLException
    {
        int i = meg.unmarshalUB2();
        rxd.unmarshalBVC(i);
    }

    void readIOV()
        throws IOException, SQLException
    {
        T4CTTIiov t4cttiiov = new T4CTTIiov(connection, rxh, rxd);
        t4cttiiov.init();
        t4cttiiov.unmarshalV10();
        if(oracleStatement.returnParamAccessors == null && !t4cttiiov.isIOVectorEmpty())
        {
            byte abyte0[] = t4cttiiov.getIOVector();
            outBindAccessors = t4cttiiov.processRXD(outBindAccessors, numberOfBindPositions, bindBytes, bindChars, bindIndicators, bindIndicatorSubRange, conversion, tmpBindsByteArray, abyte0, parameterStream, parameterDatum, parameterOtype, oracleStatement, null, null, null);
        }
    }

    void readRXH()
        throws IOException, SQLException
    {
        rxh.init();
        rxh.unmarshalV10(rxd);
        if(rxh.uacBufLength > 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 405);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if((rxh.rxhflg & 8) == 8)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 449);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if((rxh.rxhflg & 0x10) == 16)
        {
            for(int i = 0; i < definesAccessors.length; i++)
                if(definesAccessors[i].udskpos >= 0 && definesAccessors[i].udskpos != i)
                {
                    SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 450);
                    sqlexception2.fillInStackTrace();
                    throw sqlexception2;
                }

        }
    }

    void processSLG()
        throws IOException, SQLException
    {
        readRXH();
        int ai[] = new int[numberOfBindPositions];
        for(int i = 0; i < numberOfBindPositions; i++)
            ai[i] = oacdefBindsSent[i].oacmxl;

        nonFatalIOExceptions = marshalBinds(ai, true);
    }

    boolean readRXD()
        throws IOException, SQLException
    {
        aFetchWasDone = true;
        if(oracleStatement.returnParamAccessors != null && numberOfBindPositions > 0)
        {
            boolean flag = false;
            for(int i = 0; i < oracleStatement.numberOfBindPositions; i++)
            {
                Accessor accessor = oracleStatement.returnParamAccessors[i];
                if(accessor == null)
                    continue;
                int j = (int)meg.unmarshalUB4();
                if(!flag)
                {
                    oracleStatement.rowsDmlReturned = j;
                    oracleStatement.allocateDmlReturnStorage();
                    oracleStatement.setupReturnParamAccessors();
                    flag = true;
                }
                for(int k = 0; k < j; k++)
                    accessor.unmarshalOneRow();

            }

            oracleStatement.returnParamsFetched = true;
        } else
        if(iovProcessed || outBindAccessors != null && definesAccessors == null)
        {
            if(rxd.unmarshal(outBindAccessors, numberOfBindPositions))
                return true;
        } else
        if(rxd.unmarshal(definesAccessors, definesLength))
            return true;
        return false;
    }

    void readRPA()
        throws IOException, SQLException
    {
        int i = meg.unmarshalUB2();
        int ai[] = new int[i];
        for(int j = 0; j < i; j++)
            ai[j] = (int)meg.unmarshalUB4();

        int k = ai[0];
        int l = ai[1];
        long l1 = (long)k & 0xffffffffL | ((long)l & 0xffffffffL) << 32;
        if(l1 != 0L)
            oracleStatement.connection.outScn = l1;
        cursor = ai[2];
        int i1 = meg.unmarshalUB2();
        byte abyte0[] = null;
        if(i1 > 0)
            abyte0 = meg.unmarshalNBytes(i1);
        int j1 = meg.unmarshalUB2();
        KeywordValue akeywordvalue[] = new KeywordValue[j1];
        for(int k1 = 0; k1 < j1; k1++)
            akeywordvalue[k1] = KeywordValueI.unmarshal(meg);

        connection.updateSessionProperties(akeywordvalue);
        oracleStatement.dcnQueryId = -1L;
        oracleStatement.dcnTableName = null;
        if(connection.getTTCVersion() >= 4)
        {
            int i2 = (int)meg.unmarshalUB4();
            byte abyte1[] = meg.unmarshalNBytes(i2);
            if(i2 > 0 && registration != null)
            {
                boolean flag = false;
                Properties properties = registration.getRegistrationOptions();
                if(properties != null)
                {
                    String s = properties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION");
                    if(s != null && s.compareToIgnoreCase("true") == 0)
                        flag = true;
                }
                int j2 = i2;
                if(flag)
                    j2 = i2 - 8;
                String s1 = new String(abyte1, 0, j2);
                char ac[] = {
                    '\0'
                };
                String as[] = s1.split(new String(ac));
                registration.addTablesName(as, as.length);
                oracleStatement.dcnTableName = as;
                if(flag)
                {
                    int k2 = abyte1[i2 - 1] & 0xff | (abyte1[i2 - 2] & 0xff) << 8 | (abyte1[i2 - 3] & 0xff) << 16 | (abyte1[i2 - 4] & 0xff) << 24;
                    int l2 = abyte1[i2 - 5] & 0xff | (abyte1[i2 - 6] & 0xff) << 8 | (abyte1[i2 - 7] & 0xff) << 16 | (abyte1[i2 - 8] & 0xff) << 24;
                    long l3 = (long)l2 & 0xffffffffL | ((long)k2 & 0xffffffffL) << 32;
                    oracleStatement.dcnQueryId = l3;
                }
            }
        }
    }

    void readDCB()
        throws IOException, SQLException
    {
        dcb.init(oracleStatement, 0);
        definesAccessors = dcb.receive(definesAccessors);
        numberOfDefinePositions = dcb.numuds;
        definesLength = numberOfDefinePositions;
        rxd.setNumberOfColumns(numberOfDefinePositions);
    }

    void processError()
        throws SQLException
    {
        cursor = oer.currCursorID;
        rowsProcessed = oer.getCurRowNumber();
        if(typeOfStatement.isSELECT() && oer.retCode == 1403)
            aFetchWasDone = true;
        if(!typeOfStatement.isSELECT() || typeOfStatement.isSELECT() && oer.retCode != 1403)
        {
            if(oracleStatement.connection.calculateChecksum && oer.retCode != 0)
            {
                long l = oer.updateChecksum(oracleStatement.checkSum);
                oracleStatement.checkSum = l;
            }
            oer.processError(oracleStatement);
        }
    }

    int getCursorId()
    {
        return cursor;
    }

    void continueReadRow(int i, oracle.jdbc.driver.OracleStatement oraclestatement)
        throws SQLException, IOException
    {
        oracleStatement = oraclestatement;
        receiveState = 2;
        if(!rxd.unmarshal(definesAccessors, i, definesLength))
            break MISSING_BLOCK_LABEL_40;
        receiveState = 3;
        oracleStatement = null;
        return;
        resumeReceive();
        oracleStatement = null;
        break MISSING_BLOCK_LABEL_60;
        Exception exception;
        exception;
        oracleStatement = null;
        throw exception;
    }

    int getNumRows()
    {
        int i = 0;
        if(typeOfStatement == null)
            return i;
        static class _cls1
        {

            static final int $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[];

            static 
            {
                $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind = new int[oracle.jdbc.internal.OracleStatement.SqlKind.values().length];
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.OracleStatement.SqlKind.DELETE.ordinal()] = 1;
                }
                catch(NoSuchFieldError nosuchfielderror) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.OracleStatement.SqlKind.INSERT.ordinal()] = 2;
                }
                catch(NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.OracleStatement.SqlKind.MERGE.ordinal()] = 3;
                }
                catch(NoSuchFieldError nosuchfielderror2) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.OracleStatement.SqlKind.UPDATE.ordinal()] = 4;
                }
                catch(NoSuchFieldError nosuchfielderror3) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.OracleStatement.SqlKind.ALTER_SESSION.ordinal()] = 5;
                }
                catch(NoSuchFieldError nosuchfielderror4) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.OracleStatement.SqlKind.OTHER.ordinal()] = 6;
                }
                catch(NoSuchFieldError nosuchfielderror5) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.OracleStatement.SqlKind.PLSQL_BLOCK.ordinal()] = 7;
                }
                catch(NoSuchFieldError nosuchfielderror6) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.OracleStatement.SqlKind.CALL_BLOCK.ordinal()] = 8;
                }
                catch(NoSuchFieldError nosuchfielderror7) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.OracleStatement.SqlKind.SELECT_FOR_UPDATE.ordinal()] = 9;
                }
                catch(NoSuchFieldError nosuchfielderror8) { }
                try
                {
                    $SwitchMap$oracle$jdbc$internal$OracleStatement$SqlKind[oracle.jdbc.internal.OracleStatement.SqlKind.SELECT.ordinal()] = 10;
                }
                catch(NoSuchFieldError nosuchfielderror9) { }
            }
        }

        if(receiveState == 3)
            i = -2;
        else
        if(typeOfStatement != null)
            switch(_cls1..SwitchMap.oracle.jdbc.internal.OracleStatement.SqlKind[typeOfStatement.ordinal()])
            {
            case 1: // '\001'
            case 2: // '\002'
            case 3: // '\003'
            case 4: // '\004'
            case 5: // '\005'
            case 6: // '\006'
            case 7: // '\007'
            case 8: // '\b'
                i = rowsProcessed;
                break;

            case 9: // '\t'
            case 10: // '\n'
                i = definesAccessors == null || definesLength <= 0 ? 0 : definesAccessors[0].lastRowProcessed;
                break;
            }
        return i;
    }

    void marshal()
        throws IOException
    {
        if(getFunCode() == 5)
        {
            meg.marshalSWORD(cursor);
            meg.marshalSWORD((int)al8i4[1]);
        } else
        {
            if(oracleStatement.needToSendOalToFetch)
                oracleStatement.needToSendOalToFetch = false;
            marshalPisdef();
            meg.marshalCHR(sqlStmt);
            meg.marshalUB4Array(al8i4);
            int ai[] = new int[numberOfBindPositions];
            for(int i = 0; i < numberOfBindPositions; i++)
                ai[i] = oacdefBindsSent[i].oacmxl;

            if((options & 8L) != 0L && numberOfBindPositions > 0 && bindIndicators != null && sendBindsDefinition)
                marshalBindsTypes(oacdefBindsSent);
            if(connection.getTTCVersion() >= 2 && (options & 16L) != 0L)
            {
                for(int j = 0; j < defCols; j++)
                    oacdefDefines[j].marshal();

            }
            if((options & 32L) != 0L && numberOfBindPositions > 0 && bindIndicators != null)
                nonFatalIOExceptions = marshalBinds(ai, false);
        }
    }

    void marshalPisdef()
        throws IOException
    {
        meg.marshalUB4(options);
        meg.marshalSWORD(cursor);
        if(sqlStmt.length == 0)
            meg.marshalNULLPTR();
        else
            meg.marshalPTR();
        meg.marshalSWORD(sqlStmt.length);
        if(al8i4.length == 0)
            meg.marshalNULLPTR();
        else
            meg.marshalPTR();
        meg.marshalSWORD(al8i4.length);
        meg.marshalNULLPTR();
        meg.marshalNULLPTR();
        if((options & 64L) == 0L && (options & 32L) != 0L && (options & 1L) != 0L && typeOfStatement.isSELECT())
        {
            meg.marshalUB4(0x7fffffffffffffffL);
            meg.marshalUB4(rowsToFetch);
        } else
        {
            meg.marshalUB4(0L);
            meg.marshalUB4(0L);
        }
        if(!typeOfStatement.isPlsqlOrCall())
            meg.marshalUB4(0x7fffffffL);
        else
            meg.marshalUB4(32760L);
        if((options & 8L) != 0L && numberOfBindPositions > 0 && sendBindsDefinition)
        {
            meg.marshalPTR();
            meg.marshalSWORD(numberOfBindPositions);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        meg.marshalNULLPTR();
        meg.marshalNULLPTR();
        meg.marshalNULLPTR();
        meg.marshalNULLPTR();
        meg.marshalNULLPTR();
        if(connection.getTTCVersion() >= 2)
            if(defCols > 0 && (options & 16L) != 0L)
            {
                meg.marshalPTR();
                meg.marshalSWORD(defCols);
            } else
            {
                meg.marshalNULLPTR();
                meg.marshalSWORD(0);
            }
        if(connection.getTTCVersion() >= 4)
        {
            int i = 0;
            int j = 0;
            if(registration != null)
            {
                long l = registration.getRegId();
                i = (int)(l & -1L);
                j = (int)((l & 0xffffffff00000000L) >> 32);
            }
            meg.marshalUB4(i);
            meg.marshalNULLPTR();
            meg.marshalPTR();
            if(connection.getTTCVersion() >= 5)
            {
                meg.marshalNULLPTR();
                meg.marshalUB4(0L);
                meg.marshalNULLPTR();
                meg.marshalUB4(0L);
                meg.marshalUB4(j);
            }
        }
    }

    boolean initBindsDefinition(T4CTTIoac at4cttioac[])
        throws SQLException, IOException
    {
        boolean flag = false;
        if(at4cttioac.length != numberOfBindPositions)
        {
            flag = true;
            at4cttioac = new T4CTTIoac[numberOfBindPositions];
        }
        short aword0[] = bindIndicators;
        boolean flag1 = false;
        int i2 = 0;
        for(int j2 = 0; j2 < numberOfBindPositions; j2++)
        {
            T4CTTIoac t4cttioac = new T4CTTIoac(connection);
            int i = bindIndicatorSubRange + 5 + 10 * j2;
            short word0 = aword0[i + 9];
            int l1 = aword0[i + 0] & 0xffff;
            switch(l1)
            {
            case 8: // '\b'
            case 24: // '\030'
                int j;
                if(plsql)
                    j = 32760;
                else
                    j = 0x7fffffff;
                t4cttioac.init((short)l1, j);
                t4cttioac.setFormOfUse(word0);
                t4cttioac.setCharset(word0 != 2 ? ((int) (dbCharSet)) : ((int) (NCharSet)));
                break;

            case 998: 
                if(outBindAccessors != null && outBindAccessors[j2] != null)
                {
                    PlsqlIndexTableAccessor plsqlindextableaccessor = (PlsqlIndexTableAccessor)outBindAccessors[j2];
                    t4cttioac.init((short)plsqlindextableaccessor.elementInternalType, plsqlindextableaccessor.elementMaxLen);
                    t4cttioac.setMal(plsqlindextableaccessor.maxNumberOfElements);
                    t4cttioac.addFlg((short)64);
                    i2++;
                } else
                if(ibtBindIndicators[6 + i2 * 8] != 0)
                {
                    int k2 = ibtBindIndicators[6 + i2 * 8];
                    int i3 = (ibtBindIndicators[6 + i2 * 8 + 2] & 0xffff) << 16 | ibtBindIndicators[6 + i2 * 8 + 3] & 0xffff;
                    int k = ibtBindIndicators[6 + i2 * 8 + 1] * conversion.sMaxCharSize;
                    t4cttioac.init((short)k2, k);
                    t4cttioac.setMal(i3);
                    t4cttioac.addFlg((short)64);
                    i2++;
                } else
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding PLSQL index-by table but no type defined", -1);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                break;

            case 109: // 'm'
            case 111: // 'o'
                if(outBindAccessors != null && outBindAccessors[j2] != null)
                {
                    if(outBindAccessors[j2].internalOtype != null)
                    {
                        t4cttioac.init((short)l1, l1 != 109 ? 4000 : 11);
                        t4cttioac.setADT((OracleTypeADT)((TypeAccessor)outBindAccessors[j2]).internalOtype);
                    }
                } else
                if(parameterOtype != null && parameterOtype[oracleStatement.firstRowInBatch] != null)
                {
                    t4cttioac.init((short)l1, l1 != 109 ? 4000 : 11);
                    t4cttioac.setADT(parameterOtype[oracleStatement.firstRowInBatch][j2]);
                } else
                {
                    SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "INTERNAL ERROR: Binding NAMED_TYPE but no type defined", -1);
                    sqlexception1.fillInStackTrace();
                    throw sqlexception1;
                }
                break;

            case 994: 
                int ai[] = oracleStatement.returnParamMeta;
                l1 = ai[3 + j2 * 4 + 0];
                int l = ai[3 + j2 * 4 + 2];
                word0 = (short)ai[3 + j2 * 4 + 3];
                if(l1 == 109 || l1 == 111)
                {
                    TypeAccessor typeaccessor = (TypeAccessor)oracleStatement.returnParamAccessors[j2];
                    t4cttioac.init((short)l1, l1 != 109 ? 4000 : 11);
                    t4cttioac.setADT((OracleTypeADT)typeaccessor.internalOtype);
                } else
                {
                    t4cttioac.init((short)l1, l);
                    t4cttioac.setFormOfUse(word0);
                    t4cttioac.setCharset(word0 != 2 ? ((int) (dbCharSet)) : ((int) (NCharSet)));
                }
                break;

            case 180: 
                int i1 = aword0[i + 1] & 0xffff;
                t4cttioac.init((short)l1, i1);
                t4cttioac.addFlg2(0x8000000);
                t4cttioac.setTimestampFractionalSecondsPrecision((short)9);
                int l2 = ((bindIndicators[bindIndicatorSubRange + 3] & 0xffff) << 16) + (bindIndicators[bindIndicatorSubRange + 4] & 0xffff);
                if(l2 == 1)
                {
                    int j3 = ((aword0[i + 7] & 0xffff) << 16) + (aword0[i + 8] & 0xffff);
                    short word1 = aword0[j3];
                    if(word1 == 7)
                        t4cttioac.setTimestampFractionalSecondsPrecision((short)0);
                }
                break;

            case 182: 
            case 183: 
                int j1 = aword0[i + 1] & 0xffff;
                t4cttioac.init((short)l1, j1);
                t4cttioac.setFormOfUse(word0);
                t4cttioac.setCharset(word0 != 2 ? ((int) (dbCharSet)) : ((int) (NCharSet)));
                t4cttioac.setPrecision((short)9);
                break;

            default:
                int k1 = aword0[i + 1] & 0xffff;
                if(k1 == 0)
                {
                    k1 = aword0[i + 2] & 0xffff;
                    if(l1 == 996)
                        k1 *= 2;
                    else
                    if(k1 > 1)
                        k1--;
                    if(word0 == 2)
                        k1 *= conversion.maxNCharSize;
                    if(typeOfStatement == oracle.jdbc.internal.OracleStatement.SqlKind.PLSQL_BLOCK || connection.versionNumber >= 10200 && typeOfStatement == oracle.jdbc.internal.OracleStatement.SqlKind.CALL_BLOCK)
                    {
                        if(k1 == 0)
                            k1 = 32766;
                        else
                            k1 *= conversion.sMaxCharSize;
                    } else
                    if(typeOfStatement == oracle.jdbc.internal.OracleStatement.SqlKind.CALL_BLOCK)
                    {
                        if(k1 < 4001)
                            k1 = 4001;
                    } else
                    if(word0 != 2)
                        if(((T4CConnection)oracleStatement.connection).retainV9BindBehavior && k1 <= 4000)
                            k1 = Math.min(k1 * conversion.sMaxCharSize, 4000);
                        else
                            k1 *= conversion.sMaxCharSize;
                    if(k1 == 0)
                        k1 = 32;
                }
                t4cttioac.init((short)l1, k1);
                t4cttioac.setFormOfUse(word0);
                t4cttioac.setCharset(word0 != 2 ? ((int) (dbCharSet)) : ((int) (NCharSet)));
                break;
            }
            if(at4cttioac[j2] == null || !t4cttioac.isOldSufficient(at4cttioac[j2]))
            {
                at4cttioac[j2] = t4cttioac;
                flag = true;
            }
        }

        if(flag)
            oracleStatement.nbPostPonedColumns[0] = 0;
        return flag;
    }

    void initDefinesDefinition()
        throws SQLException, IOException
    {
        defCols = 0;
        for(int i = 0; i < definedColumnType.length && definedColumnType[i] != 0; i++)
            defCols++;

        oacdefDefines = new T4CTTIoac[defCols];
        boolean flag = false;
        boolean flag1 = false;
        boolean flag2 = false;
        boolean flag3 = false;
        for(int i1 = 0; i1 < oacdefDefines.length; i1++)
        {
            oacdefDefines[i1] = new T4CTTIoac(connection);
            short word0 = (short)oracleStatement.getInternalType(definedColumnType[i1]);
            int k = 0x7fffffff;
            int j = 0;
            int l = 0;
            short word1 = 1;
            if(definedColumnFormOfUse != null && definedColumnFormOfUse.length > i1 && definedColumnFormOfUse[i1] == 2)
                word1 = 2;
            if(word0 == 8)
                word0 = 1;
            else
            if(word0 == 24)
                word0 = 23;
            else
            if(word0 == 1 || word0 == 96)
            {
                word0 = 1;
                k = 4000 * conversion.sMaxCharSize;
                if(definedColumnSize != null && definedColumnSize.length > i1 && definedColumnSize[i1] > 0)
                    k = definedColumnSize[i1] * conversion.sMaxCharSize;
            } else
            if(connection.useLobPrefetch && (word0 == 113 || word0 == 112 || word0 == 114))
            {
                k = 0;
                j = 0x2000000;
                if(definedColumnSize != null && definedColumnSize.length > i1 && definedColumnSize[i1] > 0)
                    l = definedColumnSize[i1];
            } else
            if(word0 == 23)
                k = 4000;
            oacdefDefines[i1].init(word0, k);
            oacdefDefines[i1].addFlg2(j);
            oacdefDefines[i1].setMxlc(l);
            oacdefDefines[i1].setFormOfUse(word1);
            oacdefDefines[i1].setCharset(word1 != 2 ? ((int) (dbCharSet)) : ((int) (NCharSet)));
        }

    }

    void marshalBindsTypes(T4CTTIoac at4cttioac[])
        throws IOException
    {
        if(at4cttioac == null)
            return;
        for(int i = 0; i < at4cttioac.length; i++)
            at4cttioac[i].marshal();

    }

    Vector marshalBinds(int ai[], boolean flag)
        throws IOException
    {
        Vector vector = null;
        int i = ((bindIndicators[bindIndicatorSubRange + 3] & 0xffff) << 16) + (bindIndicators[bindIndicatorSubRange + 4] & 0xffff);
        int j;
        boolean flag1;
        if(flag)
        {
            j = rxh.iterNum;
            flag1 = true;
        } else
        {
            j = 0;
            flag1 = false;
        }
        for(; j < i; j++)
        {
            int k = oracleStatement.firstRowInBatch + j;
            InputStream ainputstream[] = null;
            if(parameterStream != null)
                ainputstream = parameterStream[k];
            byte abyte0[][] = (byte[][])null;
            if(parameterDatum != null)
                abyte0 = parameterDatum[k];
            OracleTypeADT aoracletypeadt[] = null;
            if(parameterOtype != null)
                aoracletypeadt = parameterOtype[k];
            Vector vector1 = rxd.marshal(bindBytes, bindChars, bindIndicators, bindIndicatorSubRange, tmpBindsByteArray, conversion, ainputstream, abyte0, aoracletypeadt, ibtBindBytes, ibtBindChars, ibtBindIndicators, null, j, ai, plsql, oracleStatement.returnParamMeta, oracleStatement.nbPostPonedColumns, oracleStatement.indexOfPostPonedColumn, flag1);
            flag1 = false;
            if(vector1 == null)
                continue;
            if(vector == null)
                vector = new Vector();
            vector.addAll(vector1);
        }

        return vector;
    }

    long setOptions(boolean flag, boolean flag1, boolean flag2, boolean flag3)
        throws SQLException
    {
        long l = 0L;
        if(flag && !flag1 && !flag2)
            l |= 1L;
        else
        if(flag && flag1 && !flag2)
            l = 32801L;
        else
        if(flag1 && flag2)
        {
            if(flag)
                l |= 1L;
            switch(_cls1..SwitchMap.oracle.jdbc.internal.OracleStatement.SqlKind[typeOfStatement.ordinal()])
            {
            case 9: // '\t'
            case 10: // '\n'
                l |= 32864L;
                break;

            case 7: // '\007'
            case 8: // '\b'
                if(numberOfBindPositions > 0)
                {
                    l |= 1056L | (long)(oracleStatement.connection.autocommit ? 256 : 0);
                    if(sendBindsDefinition)
                        l |= 8L;
                } else
                {
                    l |= 32L | (long)(oracleStatement.connection.autocommit ? 256 : 0);
                }
                break;

            case 1: // '\001'
            case 2: // '\002'
            case 3: // '\003'
            case 4: // '\004'
            case 5: // '\005'
            case 6: // '\006'
                if(oracleStatement.returnParamAccessors != null)
                    l |= 1056L | (long)(oracleStatement.connection.autocommit ? 256 : 0);
                else
                    l |= 32800L | (long)(oracleStatement.connection.autocommit ? 256 : 0);
                break;

            default:
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 432);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        if(!flag && !flag1 && flag2)
        {
            l = 32832L;
        } else
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 432);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(!typeOfStatement.isPlsqlOrCall())
        {
            if((flag || flag1 || !flag2) && numberOfBindPositions > 0 && sendBindsDefinition)
                l |= 8L;
            if(connection.versionNumber >= 9000 && flag3)
                l |= 16L;
        }
        l &= -1L;
        return l;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
