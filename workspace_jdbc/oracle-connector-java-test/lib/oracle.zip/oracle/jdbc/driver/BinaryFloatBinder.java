// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;


// Referenced classes of package oracle.jdbc.driver:
//            Binder, OraclePreparedStatement, OraclePreparedStatementReadOnly

class BinaryFloatBinder extends Binder
{

    Binder theBinaryFloatCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    static void init(Binder binder)
    {
        binder.type = 100;
        binder.bytelen = 4;
    }

    BinaryFloatBinder()
    {
        theBinaryFloatCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatCopyingBinder;
        init(this);
    }

    Binder copyingBinder()
    {
        return theBinaryFloatCopyingBinder;
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
    {
        byte abyte1[] = abyte0;
        int j2 = j1;
        float f = oraclepreparedstatement.parameterFloat[k][i];
        if((double)f == 0.0D)
            f = 0.0F;
        else
        if(f != f)
            f = (0.0F / 0.0F);
        int k2 = Float.floatToIntBits(f);
        int l2 = k2;
        k2 >>= 8;
        int i3 = k2;
        k2 >>= 8;
        int j3 = k2;
        k2 >>= 8;
        int k3 = k2;
        if((k3 & 0x80) == 0)
        {
            k3 |= 0x80;
        } else
        {
            k3 = ~k3;
            j3 = ~j3;
            i3 = ~i3;
            l2 = ~l2;
        }
        abyte1[j2 + 3] = (byte)l2;
        abyte1[j2 + 2] = (byte)i3;
        abyte1[j2 + 1] = (byte)j3;
        abyte1[j2] = (byte)k3;
        aword0[i2] = 0;
        aword0[l1] = 4;
    }

}
