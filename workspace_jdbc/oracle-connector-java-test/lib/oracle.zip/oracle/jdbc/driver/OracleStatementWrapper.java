// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleStatementWrapper.java

package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import oracle.jdbc.OracleResultSetCache;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.jdbc.internal.OracleCallableStatement;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleStatement;

// Referenced classes of package oracle.jdbc.driver:
//            OracleStatement, OracleClosedStatement, DatabaseError

class OracleStatementWrapper
    implements OracleStatement
{

    private Object forEquals;
    protected OracleStatement statement;
    static final OracleCallableStatement closedStatement = new OracleClosedStatement();
    oracle.jdbc.internal.OracleStatement.SqlKind sqlKind;
    long checkSum;
    boolean checkSumComputationFailure;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleStatementWrapper(oracle.jdbc.OracleStatement oraclestatement)
        throws SQLException
    {
        sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED;
        checkSum = 0L;
        checkSumComputationFailure = false;
        forEquals = oraclestatement;
        statement = (OracleStatement)oraclestatement;
        ((oracle.jdbc.driver.OracleStatement)oraclestatement).wrapper = this;
    }

    public void close()
        throws SQLException
    {
        if(statement == closedStatement)
        {
            return;
        } else
        {
            checkSum = ((oracle.jdbc.driver.OracleStatement)statement).checkSum = checkSum;
            checkSumComputationFailure = ((oracle.jdbc.driver.OracleStatement)statement).checkSumComputationFailure;
            sqlKind = ((oracle.jdbc.driver.OracleStatement)statement).sqlKind;
            statement.close();
            statement = closedStatement;
            return;
        }
    }

    public void closeWithKey(String s)
        throws SQLException
    {
        statement.closeWithKey(s);
        statement = closedStatement;
    }

    public boolean equals(Object obj)
    {
        return obj != null && getClass() == obj.getClass() && forEquals == ((OracleStatementWrapper)obj).forEquals;
    }

    public int hashCode()
    {
        return forEquals.hashCode();
    }

    public int getFetchDirection()
        throws SQLException
    {
        return statement.getFetchDirection();
    }

    public int getFetchSize()
        throws SQLException
    {
        return statement.getFetchSize();
    }

    public int getMaxFieldSize()
        throws SQLException
    {
        return statement.getMaxFieldSize();
    }

    public int getMaxRows()
        throws SQLException
    {
        return statement.getMaxRows();
    }

    public int getQueryTimeout()
        throws SQLException
    {
        return statement.getQueryTimeout();
    }

    public int getResultSetConcurrency()
        throws SQLException
    {
        return statement.getResultSetConcurrency();
    }

    public int getResultSetHoldability()
        throws SQLException
    {
        return statement.getResultSetHoldability();
    }

    public int getResultSetType()
        throws SQLException
    {
        return statement.getResultSetType();
    }

    public int getUpdateCount()
        throws SQLException
    {
        return statement.getUpdateCount();
    }

    public void cancel()
        throws SQLException
    {
        statement.cancel();
    }

    public void clearBatch()
        throws SQLException
    {
        statement.clearBatch();
    }

    public void clearWarnings()
        throws SQLException
    {
        statement.clearWarnings();
    }

    public boolean getMoreResults()
        throws SQLException
    {
        return statement.getMoreResults();
    }

    public int[] executeBatch()
        throws SQLException
    {
        return statement.executeBatch();
    }

    public void setFetchDirection(int i)
        throws SQLException
    {
        statement.setFetchDirection(i);
    }

    public void setFetchSize(int i)
        throws SQLException
    {
        statement.setFetchSize(i);
    }

    public void setMaxFieldSize(int i)
        throws SQLException
    {
        statement.setMaxFieldSize(i);
    }

    public void setMaxRows(int i)
        throws SQLException
    {
        statement.setMaxRows(i);
    }

    public void setQueryTimeout(int i)
        throws SQLException
    {
        statement.setQueryTimeout(i);
    }

    public boolean getMoreResults(int i)
        throws SQLException
    {
        return statement.getMoreResults(i);
    }

    public void setEscapeProcessing(boolean flag)
        throws SQLException
    {
        statement.setEscapeProcessing(flag);
    }

    public int executeUpdate(String s)
        throws SQLException
    {
        return statement.executeUpdate(s);
    }

    public void addBatch(String s)
        throws SQLException
    {
        statement.addBatch(s);
    }

    public void setCursorName(String s)
        throws SQLException
    {
        statement.setCursorName(s);
    }

    public boolean execute(String s)
        throws SQLException
    {
        return statement.execute(s);
    }

    public int executeUpdate(String s, int i)
        throws SQLException
    {
        return statement.executeUpdate(s, i);
    }

    public boolean execute(String s, int i)
        throws SQLException
    {
        return statement.execute(s, i);
    }

    public int executeUpdate(String s, int ai[])
        throws SQLException
    {
        return statement.executeUpdate(s, ai);
    }

    public boolean execute(String s, int ai[])
        throws SQLException
    {
        return statement.execute(s, ai);
    }

    public Connection getConnection()
        throws SQLException
    {
        return statement.getConnection();
    }

    public ResultSet getGeneratedKeys()
        throws SQLException
    {
        return statement.getGeneratedKeys();
    }

    public ResultSet getResultSet()
        throws SQLException
    {
        return statement.getResultSet();
    }

    public SQLWarning getWarnings()
        throws SQLException
    {
        return statement.getWarnings();
    }

    public int executeUpdate(String s, String as[])
        throws SQLException
    {
        return statement.executeUpdate(s, as);
    }

    public boolean execute(String s, String as[])
        throws SQLException
    {
        return statement.execute(s, as);
    }

    public ResultSet executeQuery(String s)
        throws SQLException
    {
        return statement.executeQuery(s);
    }

    public void clearDefines()
        throws SQLException
    {
        statement.clearDefines();
    }

    public void defineColumnType(int i, int j)
        throws SQLException
    {
        statement.defineColumnType(i, j);
    }

    public void defineColumnType(int i, int j, int k)
        throws SQLException
    {
        statement.defineColumnType(i, j, k);
    }

    public void defineColumnType(int i, int j, int k, short word0)
        throws SQLException
    {
        statement.defineColumnType(i, j, k, word0);
    }

    public void defineColumnTypeBytes(int i, int j, int k)
        throws SQLException
    {
        statement.defineColumnTypeBytes(i, j, k);
    }

    public void defineColumnTypeChars(int i, int j, int k)
        throws SQLException
    {
        statement.defineColumnTypeChars(i, j, k);
    }

    public void defineColumnType(int i, int j, String s)
        throws SQLException
    {
        statement.defineColumnType(i, j, s);
    }

    public int getRowPrefetch()
    {
        return statement.getRowPrefetch();
    }

    public void setResultSetCache(OracleResultSetCache oracleresultsetcache)
        throws SQLException
    {
        statement.setResultSetCache(oracleresultsetcache);
    }

    public void setRowPrefetch(int i)
        throws SQLException
    {
        statement.setRowPrefetch(i);
    }

    public int getLobPrefetchSize()
    {
        return statement.getLobPrefetchSize();
    }

    public void setLobPrefetchSize(int i)
        throws SQLException
    {
        statement.setLobPrefetchSize(i);
    }

    public int creationState()
    {
        return statement.creationState();
    }

    public boolean isNCHAR(int i)
        throws SQLException
    {
        return statement.isNCHAR(i);
    }

    public void setDatabaseChangeRegistration(DatabaseChangeRegistration databasechangeregistration)
        throws SQLException
    {
        statement.setDatabaseChangeRegistration(databasechangeregistration);
    }

    public boolean isClosed()
        throws SQLException
    {
        return statement.isClosed();
    }

    public boolean isPoolable()
        throws SQLException
    {
        return statement.isPoolable();
    }

    public void setPoolable(boolean flag)
        throws SQLException
    {
        statement.setPoolable(flag);
    }

    public boolean isWrapperFor(Class class1)
        throws SQLException
    {
        if(class1.isInterface())
        {
            return class1.isInstance(this);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public Object unwrap(Class class1)
        throws SQLException
    {
        if(class1.isInterface() && class1.isInstance(this))
        {
            return this;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public void setFixedString(boolean flag)
    {
        statement.setFixedString(flag);
    }

    public boolean getFixedString()
    {
        return statement.getFixedString();
    }

    public int sendBatch()
        throws SQLException
    {
        return statement.sendBatch();
    }

    public boolean getserverCursor()
    {
        return statement.getserverCursor();
    }

    public int getcacheState()
    {
        return statement.getcacheState();
    }

    public int getstatementType()
    {
        return statement.getstatementType();
    }

    public String[] getRegisteredTableNames()
        throws SQLException
    {
        return statement.getRegisteredTableNames();
    }

    public long getRegisteredQueryId()
        throws SQLException
    {
        return statement.getRegisteredQueryId();
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

    public oracle.jdbc.internal.OracleStatement.SqlKind getSqlKind()
        throws SQLException
    {
        return statement != closedStatement ? statement.getSqlKind() : sqlKind;
    }

    public long getChecksum()
        throws SQLException
    {
        if(statement != closedStatement)
            return statement.getChecksum();
        if(checkSumComputationFailure)
        {
            SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return checkSum;
        }
    }

    public void setSnapshotSCN(long l)
        throws SQLException
    {
        statement.setSnapshotSCN(l);
    }

}
