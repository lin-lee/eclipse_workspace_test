// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFDCNEvent.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.nio.ByteBuffer;
import oracle.jdbc.dcn.*;
import oracle.sql.CharacterSet;

// Referenced classes of package oracle.jdbc.driver:
//            NTFDCNTableChanges, NTFDCNQueryChanges, NTFConnection

class NTFDCNEvent extends DatabaseChangeEvent
{

    private int notifVersion;
    private int notifRegid;
    private oracle.jdbc.dcn.DatabaseChangeEvent.EventType eventType;
    private oracle.jdbc.dcn.DatabaseChangeEvent.AdditionalEventType additionalEventType;
    private String databaseName;
    private byte notifXid[];
    private int notifScn1;
    private int notifScn2;
    private int numberOfTables;
    private NTFDCNTableChanges tcdesc[];
    private int numberOfQueries;
    private NTFDCNQueryChanges qdesc[];
    private long registrationId;
    private NTFConnection conn;
    private int csid;
    private boolean isReady;
    private ByteBuffer dataBuffer;
    private boolean isDeregistrationEvent;
    private short databaseVersion;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFDCNEvent(NTFConnection ntfconnection, short word0)
        throws IOException, InterruptedException
    {
        super(ntfconnection);
        notifVersion = 0;
        notifRegid = 0;
        additionalEventType = oracle.jdbc.dcn.DatabaseChangeEvent.AdditionalEventType.NONE;
        databaseName = null;
        notifXid = new byte[8];
        notifScn1 = 0;
        notifScn2 = 0;
        numberOfTables = 0;
        tcdesc = null;
        numberOfQueries = 0;
        qdesc = null;
        isReady = false;
        isDeregistrationEvent = false;
        conn = ntfconnection;
        csid = conn.charset.getOracleId();
        int i = conn.readInt();
        byte abyte0[] = new byte[i];
        conn.readBuffer(abyte0, 0, i);
        dataBuffer = ByteBuffer.wrap(abyte0);
        databaseVersion = word0;
    }

    private void initEvent()
    {
        byte byte0 = dataBuffer.get();
        int i = dataBuffer.getInt();
        byte abyte0[] = new byte[i];
        dataBuffer.get(abyte0, 0, i);
        String s = null;
        try
        {
            s = new String(abyte0, "UTF-8");
        }
        catch(Exception exception) { }
        s = s.replaceFirst("CHNF", "");
        registrationId = Long.parseLong(s);
        byte byte1 = dataBuffer.get();
        int j = dataBuffer.getInt();
        byte abyte1[] = new byte[j];
        dataBuffer.get(abyte1, 0, j);
        byte byte2 = dataBuffer.get();
        int k = dataBuffer.getInt();
        if(dataBuffer.hasRemaining())
        {
            notifVersion = dataBuffer.getShort();
            notifRegid = dataBuffer.getInt();
            eventType = oracle.jdbc.dcn.DatabaseChangeEvent.EventType.getEventType(dataBuffer.getInt());
            short word0 = dataBuffer.getShort();
            byte abyte2[] = new byte[word0];
            dataBuffer.get(abyte2, 0, word0);
            try
            {
                databaseName = new String(abyte2, "UTF-8");
            }
            catch(Exception exception1) { }
            dataBuffer.get(notifXid);
            notifScn1 = dataBuffer.getInt();
            notifScn2 = dataBuffer.getShort();
            if(eventType == oracle.jdbc.dcn.DatabaseChangeEvent.EventType.OBJCHANGE)
            {
                numberOfTables = dataBuffer.getShort();
                tcdesc = new NTFDCNTableChanges[numberOfTables];
                for(int l = 0; l < tcdesc.length; l++)
                    tcdesc[l] = new NTFDCNTableChanges(dataBuffer, csid);

            } else
            if(eventType == oracle.jdbc.dcn.DatabaseChangeEvent.EventType.QUERYCHANGE)
            {
                numberOfQueries = dataBuffer.getShort();
                qdesc = new NTFDCNQueryChanges[numberOfQueries];
                for(int i1 = 0; i1 < numberOfQueries; i1++)
                    qdesc[i1] = new NTFDCNQueryChanges(dataBuffer, csid);

            }
        }
        isReady = true;
    }

    public String getDatabaseName()
    {
        if(!isReady)
            initEvent();
        return databaseName;
    }

    public TableChangeDescription[] getTableChangeDescription()
    {
        if(!isReady)
            initEvent();
        if(eventType == oracle.jdbc.dcn.DatabaseChangeEvent.EventType.OBJCHANGE)
            return tcdesc;
        else
            return null;
    }

    public QueryChangeDescription[] getQueryChangeDescription()
    {
        if(!isReady)
            initEvent();
        if(eventType == oracle.jdbc.dcn.DatabaseChangeEvent.EventType.QUERYCHANGE)
            return qdesc;
        else
            return null;
    }

    public byte[] getTransactionId()
    {
        if(!isReady)
            initEvent();
        return notifXid;
    }

    public String getTransactionId(boolean flag)
    {
        if(!isReady)
            initEvent();
        int i;
        int j;
        long l;
        if(!flag)
        {
            i = (notifXid[0] & 0xff) << 8 | notifXid[1] & 0xff;
            j = (notifXid[2] & 0xff) << 8 | notifXid[3] & 0xff;
            l = ((notifXid[4] & 0xff) << 24 | (notifXid[5] & 0xff) << 16 | (notifXid[6] & 0xff) << 8 | notifXid[7] & 0xff) & -1;
        } else
        {
            i = (notifXid[1] & 0xff) << 8 | notifXid[0] & 0xff;
            j = (notifXid[3] & 0xff) << 8 | notifXid[2] & 0xff;
            l = ((notifXid[7] & 0xff) << 24 | (notifXid[6] & 0xff) << 16 | (notifXid[5] & 0xff) << 8 | notifXid[4] & 0xff) & -1;
        }
        String s = (new StringBuilder()).append("").append(i).append(".").append(j).append(".").append(l).toString();
        return s;
    }

    void setEventType(oracle.jdbc.dcn.DatabaseChangeEvent.EventType eventtype)
        throws IOException
    {
        if(!isReady)
            initEvent();
        eventType = eventtype;
        if(eventType == oracle.jdbc.dcn.DatabaseChangeEvent.EventType.DEREG)
            isDeregistrationEvent = true;
    }

    void setAdditionalEventType(oracle.jdbc.dcn.DatabaseChangeEvent.AdditionalEventType additionaleventtype)
    {
        additionalEventType = additionaleventtype;
    }

    public oracle.jdbc.dcn.DatabaseChangeEvent.EventType getEventType()
    {
        if(!isReady)
            initEvent();
        return eventType;
    }

    public oracle.jdbc.dcn.DatabaseChangeEvent.AdditionalEventType getAdditionalEventType()
    {
        return additionalEventType;
    }

    boolean isDeregistrationEvent()
    {
        return isDeregistrationEvent;
    }

    public String getConnectionInformation()
    {
        return conn.connectionDescription;
    }

    public int getRegistrationId()
    {
        if(!isReady)
            initEvent();
        return (int)registrationId;
    }

    public long getRegId()
    {
        if(!isReady)
            initEvent();
        return registrationId;
    }

    public String toString()
    {
        if(!isReady)
            initEvent();
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append((new StringBuilder()).append("Connection information  : ").append(conn.connectionDescription).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Registration ID         : ").append(registrationId).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Notification version    : ").append(notifVersion).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Event type              : ").append(eventType).append("\n").toString());
        if(additionalEventType != oracle.jdbc.dcn.DatabaseChangeEvent.AdditionalEventType.NONE)
            stringbuffer.append((new StringBuilder()).append("Additional event type   : ").append(additionalEventType).append("\n").toString());
        if(databaseName != null)
            stringbuffer.append((new StringBuilder()).append("Database name           : ").append(databaseName).append("\n").toString());
        TableChangeDescription atablechangedescription[] = getTableChangeDescription();
        if(atablechangedescription != null)
        {
            stringbuffer.append((new StringBuilder()).append("Table Change Description (length=").append(numberOfTables).append(")\n").toString());
            for(int i = 0; i < atablechangedescription.length; i++)
                stringbuffer.append(atablechangedescription[i].toString());

        }
        QueryChangeDescription aquerychangedescription[] = getQueryChangeDescription();
        if(aquerychangedescription != null)
        {
            stringbuffer.append((new StringBuilder()).append("Query Change Description (length=").append(numberOfQueries).append(")\n").toString());
            for(int j = 0; j < aquerychangedescription.length; j++)
                stringbuffer.append(aquerychangedescription[j].toString());

        }
        return stringbuffer.toString();
    }

}
