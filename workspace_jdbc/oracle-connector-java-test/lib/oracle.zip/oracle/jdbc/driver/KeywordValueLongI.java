// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   KeywordValueLongI.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValueLong;

// Referenced classes of package oracle.jdbc.driver:
//            T4CMAREngine, DBConversion, NTFAQEvent

class KeywordValueLongI extends KeywordValueLong
{

    private int keyword;
    private String textValue;
    private byte textValueArr[];
    private byte binaryValue[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    KeywordValueLongI(int i, String s, byte abyte0[])
    {
        keyword = i;
        textValue = s;
        binaryValue = abyte0;
        textValueArr = null;
    }

    void doCharConversion(DBConversion dbconversion)
        throws SQLException
    {
        if(textValue != null)
            textValueArr = dbconversion.StringToCharBytes(textValue);
        else
            textValueArr = null;
    }

    public byte[] getBinaryValue()
        throws SQLException
    {
        return binaryValue;
    }

    public String getTextValue()
        throws SQLException
    {
        return textValue;
    }

    public int getKeyword()
        throws SQLException
    {
        return keyword;
    }

    void marshal(T4CMAREngine t4cmarengine)
        throws IOException
    {
        if(textValueArr != null)
        {
            t4cmarengine.marshalUB4(textValueArr.length);
            t4cmarengine.marshalCLR(textValueArr, textValueArr.length);
            t4cmarengine.marshalUB4(0L);
        } else
        {
            t4cmarengine.marshalUB4(0L);
            if(binaryValue != null)
            {
                t4cmarengine.marshalUB4(binaryValue.length);
                t4cmarengine.marshalCLR(binaryValue, binaryValue.length);
            } else
            {
                t4cmarengine.marshalUB4(0L);
            }
        }
        t4cmarengine.marshalUB2(keyword);
    }

    static KeywordValueLongI unmarshal(T4CMAREngine t4cmarengine)
        throws SQLException, IOException
    {
        int ai[] = new int[1];
        String s = null;
        byte abyte0[] = null;
        int i = (int)t4cmarengine.unmarshalUB4();
        if(i != 0)
        {
            byte abyte1[] = new byte[i];
            t4cmarengine.unmarshalCLR(abyte1, 0, ai);
            s = t4cmarengine.conv.CharBytesToString(abyte1, abyte1.length);
        }
        int j = (int)t4cmarengine.unmarshalUB4();
        if(j != 0)
        {
            abyte0 = new byte[j];
            t4cmarengine.unmarshalCLR(abyte0, 0, ai);
        }
        int k = t4cmarengine.unmarshalUB2();
        return new KeywordValueLongI(k, s, abyte0);
    }

    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append((new StringBuilder()).append("keyword    : ").append(keyword).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("text value : ").append(textValue).append("\n").toString());
        if(binaryValue == null)
            stringbuffer.append("bin value  : null\n");
        else
            stringbuffer.append((new StringBuilder()).append("bin value  : ").append(NTFAQEvent.byteBufferToHexString(binaryValue, 50)).append("\n").toString());
        return stringbuffer.toString();
    }

}
