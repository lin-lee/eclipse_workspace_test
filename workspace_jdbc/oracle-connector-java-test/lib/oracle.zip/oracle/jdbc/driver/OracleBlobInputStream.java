// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleBlobInputStream.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            OracleBufferedStream, PhysicalConnection, DatabaseError

class OracleBlobInputStream extends OracleBufferedStream
{

    long lobOffset;
    Datum lob;
    long markedByte;
    boolean endOfStream;
    long maxPosition;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleBlobInputStream(BLOB blob)
        throws SQLException
    {
        this(blob, ((PhysicalConnection)blob.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
    }

    public OracleBlobInputStream(BLOB blob, int i)
        throws SQLException
    {
        this(blob, i, 1L);
    }

    public OracleBlobInputStream(BLOB blob, int i, long l)
        throws SQLException
    {
        super(i);
        endOfStream = false;
        maxPosition = 0x7fffffffffffffffL;
        if(blob == null || i <= 0 || l < 1L)
        {
            throw new IllegalArgumentException("Illegal Arguments");
        } else
        {
            lob = blob;
            markedByte = -1L;
            lobOffset = l;
            return;
        }
    }

    public OracleBlobInputStream(BLOB blob, int i, long l, long l1)
        throws SQLException
    {
        this(blob, i, l);
        maxPosition = l + l1;
    }

    public OracleBlobInputStream(BFILE bfile)
        throws SQLException
    {
        this(bfile, ((PhysicalConnection)bfile.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
    }

    public OracleBlobInputStream(BFILE bfile, int i)
        throws SQLException
    {
        this(bfile, i, 1L);
    }

    public OracleBlobInputStream(BFILE bfile, int i, long l)
        throws SQLException
    {
        super(i);
        endOfStream = false;
        maxPosition = 0x7fffffffffffffffL;
        if(bfile == null || i <= 0 || l < 1L)
        {
            throw new IllegalArgumentException("Illegal Arguments");
        } else
        {
            lob = bfile;
            markedByte = -1L;
            lobOffset = l;
            return;
        }
    }

    public boolean needBytes(int i)
        throws IOException
    {
        ensureOpen();
        if(pos >= count)
        {
            if(!endOfStream)
            {
                if(i > currentBufferSize)
                {
                    currentBufferSize = Math.max(i, initialBufferSize);
                    resizableBuffer = new byte[currentBufferSize];
                }
                try
                {
                    int j;
                    if((long)currentBufferSize < maxPosition - lobOffset)
                        j = currentBufferSize;
                    else
                        j = (int)(maxPosition - lobOffset);
                    if(lob instanceof BLOB)
                        count = ((BLOB)lob).getBytes(lobOffset, j, resizableBuffer);
                    else
                        count = ((BFILE)lob).getBytes(lobOffset, j, resizableBuffer);
                    if(count < currentBufferSize)
                        endOfStream = true;
                    if(count > 0)
                    {
                        pos = 0;
                        lobOffset += count;
                        if(lobOffset > maxPosition)
                            endOfStream = true;
                        return true;
                    }
                }
                catch(SQLException sqlexception)
                {
                    IOException ioexception = DatabaseError.createIOException(sqlexception);
                    ioexception.fillInStackTrace();
                    throw ioexception;
                }
            }
            return false;
        } else
        {
            return true;
        }
    }

    void ensureOpen()
        throws IOException
    {
        try
        {
            if(closed)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, null);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(SQLException sqlexception1)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception1);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
    }

    public boolean markSupported()
    {
        return true;
    }

    public void mark(int i)
    {
        if(i < 0)
        {
            throw new IllegalArgumentException("Read-ahead limit < 0");
        } else
        {
            markedByte = (lobOffset - (long)count) + (long)pos;
            return;
        }
    }

    public void markInternal(int i)
    {
    }

    public void reset()
        throws IOException
    {
        ensureOpen();
        if(markedByte < 0L)
        {
            throw new IOException("Mark invalid or stream not marked.");
        } else
        {
            lobOffset = markedByte;
            pos = count;
            endOfStream = false;
            return;
        }
    }

    public long skip(long l)
        throws IOException
    {
        ensureOpen();
        long l1 = 0L;
        if((long)(count - pos) >= l)
        {
            pos += l;
            l1 += l;
        } else
        {
            l1 += count - pos;
            pos = count;
            try
            {
                long l2 = 0L;
                if(lob instanceof BLOB)
                    l2 = (((BLOB)lob).length() - lobOffset) + 1L;
                else
                    l2 = (((BFILE)lob).length() - lobOffset) + 1L;
                if(l2 >= l - l1)
                {
                    lobOffset += l - l1;
                    l1 += l - l1;
                } else
                {
                    lobOffset += l2;
                    l1 += l2;
                }
            }
            catch(SQLException sqlexception)
            {
                IOException ioexception = DatabaseError.createIOException(sqlexception);
                ioexception.fillInStackTrace();
                throw ioexception;
            }
        }
        return l1;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        OracleConnection oracleconnection = null;
        if(lob != null)
            try
            {
                if(lob instanceof BLOB)
                    oracleconnection = ((BLOB)lob).getInternalConnection();
                else
                    oracleconnection = ((BFILE)lob).getInternalConnection();
            }
            catch(Exception exception)
            {
                oracleconnection = null;
            }
        return oracleconnection;
    }

}
