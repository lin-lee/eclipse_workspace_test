// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CLongAccessor.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;
import oracle.net.ns.BreakNetException;

// Referenced classes of package oracle.jdbc.driver:
//            LongAccessor, T4CConnection, OracleStatement, T4CMAREngine, 
//            PhysicalConnection, CRC64, DatabaseError, T4CTTIoer

class T4CLongAccessor extends LongAccessor
{

    T4CMAREngine mare;
    static final int t4MaxLength = 0x7fffffff;
    static final int t4PlsqlMaxLength = 32760;
    byte data[][];
    int nbBytesRead[];
    int bytesReadSoFar[];
    final int escapeSequenceArr[];
    final boolean readHeaderArr[];
    final boolean readAsNonStreamArr[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CLongAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, int j, short word0, int k, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, j, word0, k);
        data = (byte[][])null;
        nbBytesRead = null;
        bytesReadSoFar = null;
        escapeSequenceArr = new int[1];
        readHeaderArr = new boolean[1];
        readAsNonStreamArr = new boolean[1];
        mare = t4cmarengine;
        if(oraclestatement.connection.useFetchSizeWithLongColumn)
        {
            data = new byte[oraclestatement.rowPrefetch][];
            for(int l = 0; l < oraclestatement.rowPrefetch; l++)
                data[l] = new byte[4080];

            nbBytesRead = new int[oraclestatement.rowPrefetch];
            bytesReadSoFar = new int[oraclestatement.rowPrefetch];
        }
    }

    T4CLongAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, int j, boolean flag, int k, int l, int i1, 
            int j1, int k1, short word0, int l1, int i2, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, j, flag, k, l, i1, j1, k1, word0);
        data = (byte[][])null;
        nbBytesRead = null;
        bytesReadSoFar = null;
        escapeSequenceArr = new int[1];
        readHeaderArr = new boolean[1];
        readAsNonStreamArr = new boolean[1];
        mare = t4cmarengine;
        definedColumnType = l1;
        definedColumnSize = i2;
        if(oraclestatement.connection.useFetchSizeWithLongColumn)
        {
            data = new byte[oraclestatement.rowPrefetch][];
            for(int j2 = 0; j2 < oraclestatement.rowPrefetch; j2++)
                data[j2] = new byte[4080];

            nbBytesRead = new int[oraclestatement.rowPrefetch];
            bytesReadSoFar = new int[oraclestatement.rowPrefetch];
        }
    }

    void processIndicator(int i)
        throws IOException, SQLException
    {
        if(internalType == 1 && describeType == 112 || internalType == 23 && describeType == 113)
        {
            mare.unmarshalUB2();
            mare.unmarshalUB2();
        } else
        if(statement.connection.versionNumber < 9200)
        {
            mare.unmarshalSB2();
            if(!statement.sqlKind.isPlsqlOrCall())
                mare.unmarshalSB2();
        } else
        if(statement.sqlKind.isPlsqlOrCall() || isDMLReturnedParam)
            mare.processIndicator(i <= 0, i);
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        if(isUseLess)
        {
            lastRowProcessed++;
            return false;
        }
        boolean flag = false;
        int i = indicatorIndex + lastRowProcessed;
        escapeSequenceArr[0] = mare.unmarshalUB1();
        if(mare.escapeSequenceNull(escapeSequenceArr[0]))
        {
            rowSpaceIndicator[i] = -1;
            mare.processIndicator(false, 0);
            int j = (int)mare.unmarshalUB4();
            flag = false;
            escapeSequenceArr[0] = 0;
            lastRowProcessed++;
        } else
        {
            rowSpaceIndicator[i] = 0;
            readHeaderArr[0] = true;
            readAsNonStreamArr[0] = false;
            if(statement.connection.useFetchSizeWithLongColumn)
            {
                int k = 0;
                do
                {
                    if(k == -1)
                        break;
                    if(data[lastRowProcessed].length < nbBytesRead[lastRowProcessed] + 255)
                    {
                        byte abyte0[] = new byte[data[lastRowProcessed].length * 4];
                        System.arraycopy(data[lastRowProcessed], 0, abyte0, 0, nbBytesRead[lastRowProcessed]);
                        data[lastRowProcessed] = abyte0;
                    }
                    k = readStreamFromWire(data[lastRowProcessed], nbBytesRead[lastRowProcessed], 255, escapeSequenceArr, readHeaderArr, readAsNonStreamArr, mare, ((T4CConnection)statement.connection).oer);
                    if(statement.connection.calculateChecksum && k != -1)
                    {
                        CRC64 _tmp = PhysicalConnection.CHECKSUM;
                        long l = CRC64.updateChecksum(statement.checkSum, data[lastRowProcessed], nbBytesRead[lastRowProcessed], k);
                        statement.checkSum = l;
                    }
                    if(k != -1)
                        nbBytesRead[lastRowProcessed] += k;
                } while(true);
                lastRowProcessed++;
            } else
            {
                flag = true;
            }
        }
        return flag;
    }

    void fetchNextColumns()
        throws SQLException
    {
        statement.continueReadRow(columnPosition);
    }

    int readStream(byte abyte0[], int i)
        throws SQLException, IOException
    {
        int j = statement.currentRow;
        if(statement.connection.useFetchSizeWithLongColumn)
        {
            byte abyte1[] = data[j];
            int l = nbBytesRead[j];
            int i1 = bytesReadSoFar[j];
            if(i1 == l)
                return -1;
            int j1 = 0;
            if(i <= l - i1)
                j1 = i;
            else
                j1 = l - i1;
            System.arraycopy(abyte1, i1, abyte0, 0, j1);
            bytesReadSoFar[j] += j1;
            return j1;
        }
        int k = readStreamFromWire(abyte0, 0, i, escapeSequenceArr, readHeaderArr, readAsNonStreamArr, mare, ((T4CConnection)statement.connection).oer);
        if(statement.connection.calculateChecksum && k != -1)
        {
            CRC64 _tmp = PhysicalConnection.CHECKSUM;
            long l1 = CRC64.updateChecksum(statement.checkSum, abyte0, 0, k);
            statement.checkSum = l1;
        }
        return k;
    }

    protected static final int readStreamFromWire(byte abyte0[], int i, int j, int ai[], boolean aflag[], boolean aflag1[], T4CMAREngine t4cmarengine, T4CTTIoer t4cttioer)
        throws SQLException, IOException
    {
        int k = -1;
        try
        {
            if(!aflag1[0])
            {
                if(j > 255 || j < 0)
                {
                    SQLException sqlexception = DatabaseError.createSqlException(null, 433);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                if(aflag[0])
                {
                    if(ai[0] == 254)
                    {
                        k = t4cmarengine.unmarshalUB1();
                    } else
                    {
                        if(ai[0] == 0)
                        {
                            t4cttioer.connection.internalClose();
                            SQLException sqlexception1 = DatabaseError.createSqlException(null, 401);
                            sqlexception1.fillInStackTrace();
                            throw sqlexception1;
                        }
                        aflag1[0] = true;
                        k = ai[0];
                    }
                    aflag[0] = false;
                    ai[0] = 0;
                } else
                {
                    k = t4cmarengine.unmarshalUB1();
                }
            } else
            {
                aflag1[0] = false;
            }
            if(k > 0)
                t4cmarengine.unmarshalNBytes(abyte0, i, k);
            else
                k = -1;
        }
        catch(BreakNetException breaknetexception)
        {
            k = t4cmarengine.unmarshalUB1();
            if(k == 4)
            {
                t4cttioer.init();
                t4cttioer.processError();
            }
        }
        if(k == -1)
        {
            aflag[0] = true;
            t4cmarengine.unmarshalUB2();
            t4cmarengine.unmarshalUB2();
        }
        return k;
    }

    String getString(int i)
        throws SQLException
    {
        String s = super.getString(i);
        if(s != null && definedColumnSize > 0 && s.length() > definedColumnSize)
            s = s.substring(0, definedColumnSize);
        return s;
    }

    long updateChecksum(long l, int i)
        throws SQLException
    {
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            CRC64 _tmp = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
        }
        return l;
    }

}
