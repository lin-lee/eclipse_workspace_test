// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   DiagnosabilityMXBean.java

package oracle.jdbc.driver;


public interface DiagnosabilityMXBean
{

    public abstract boolean stateManageable();

    public abstract boolean statisticsProvider();

    public abstract boolean getLoggingEnabled();

    public abstract void setLoggingEnabled(boolean flag);
}
