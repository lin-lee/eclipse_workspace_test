// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CSocketInputStreamWrapper.java

package oracle.jdbc.driver;

import java.io.IOException;
import oracle.net.ns.*;

// Referenced classes of package oracle.jdbc.driver:
//            T4CSocketOutputStreamWrapper

class T4CSocketInputStreamWrapper extends NetInputStream
{

    static final int MAX_BUFFER_SIZE = 2048;
    NetInputStream is;
    T4CSocketOutputStreamWrapper os;
    boolean eof;
    byte buffer[];
    int bIndex;
    int bytesAvailable;

    T4CSocketInputStreamWrapper(NetInputStream netinputstream, T4CSocketOutputStreamWrapper t4csocketoutputstreamwrapper)
        throws IOException
    {
        is = null;
        os = null;
        eof = false;
        buffer = new byte[2048];
        bIndex = 0;
        is = netinputstream;
        os = t4csocketoutputstreamwrapper;
    }

    public final int read()
        throws IOException
    {
        if(eof)
            return -1;
        if(bytesAvailable < 1)
        {
            readNextPacket();
            if(eof)
                return -1;
        }
        bytesAvailable--;
        return buffer[bIndex++] & 0xff;
    }

    public final int read(byte abyte0[], int i, int j)
        throws IOException
    {
        if(eof)
            return 0;
        if(bytesAvailable < j)
        {
            int k = bytesAvailable;
            System.arraycopy(buffer, bIndex, abyte0, i, k);
            i += k;
            bIndex += k;
            bytesAvailable -= k;
            is.read(abyte0, i, j - k);
        } else
        {
            System.arraycopy(buffer, bIndex, abyte0, i, j);
            bIndex += j;
            bytesAvailable -= j;
        }
        return j;
    }

    void readNextPacket()
        throws IOException
    {
        os.flush();
        int i = is.read();
        if(i == -1)
        {
            eof = true;
            return;
        }
        buffer[0] = (byte)i;
        bytesAvailable = is.available() + 1;
        bytesAvailable = bytesAvailable <= 2048 ? bytesAvailable : 2048;
        if(bytesAvailable > 1)
            is.read(buffer, 1, bytesAvailable - 1);
        bIndex = 0;
    }

    public int readB1()
        throws IOException
    {
        return read();
    }

    public long readLongLSB(int i)
        throws IOException
    {
        long l = 0L;
        boolean flag = false;
        if((i & 0x80) > 0)
        {
            i &= 0x7f;
            flag = true;
        }
        int j = i;
        for(int k = 0; j > 0; k++)
        {
            if(bytesAvailable < 1)
                readNextPacket();
            l |= ((long)buffer[bIndex++] & 255L) << 8 * k;
            bytesAvailable--;
            j--;
        }

        return (long)(flag ? -1 : 1) * l;
    }

    public long readLongMSB(int i)
        throws IOException
    {
        long l = 0L;
        boolean flag = false;
        if((i & 0x80) > 0)
        {
            i &= 0x7f;
            flag = true;
        }
        for(int j = i; j > 0; j--)
        {
            if(bytesAvailable < 1)
                readNextPacket();
            l |= ((long)buffer[bIndex++] & 255L) << 8 * (j - 1);
            bytesAvailable--;
        }

        return (long)(flag ? -1 : 1) * l;
    }

    public boolean readZeroCopyIO(byte abyte0[], int i, int ai[])
        throws IOException, NetException, BreakNetException
    {
        os.flush();
        return is.readZeroCopyIO(abyte0, i, ai);
    }
}
