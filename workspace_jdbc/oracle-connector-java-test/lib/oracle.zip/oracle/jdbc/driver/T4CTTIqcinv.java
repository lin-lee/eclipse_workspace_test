// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIqcinv.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, T4CTTIkscn, T4CMAREngine, T4CConnection

class T4CTTIqcinv extends T4CTTIMsg
{

    long kpdqcqid;
    long kpdqcopflg;
    T4CTTIkscn kpdqcscn;

    T4CTTIqcinv(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)0);
        kpdqcscn = null;
    }

    void unmarshal()
        throws SQLException, IOException
    {
        kpdqcqid = meg.unmarshalSB8();
        kpdqcopflg = meg.unmarshalUB4();
        kpdqcscn = new T4CTTIkscn(connection);
        kpdqcscn.unmarshal();
    }
}
