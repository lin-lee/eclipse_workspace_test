// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C8TTIuds.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, T4CTTIoac, T4CMAREngine, T4CConnection

class T4C8TTIuds extends T4CTTIMsg
{

    T4CTTIoac udsoac;
    boolean udsnull;
    short udscnl;
    byte optimizeOAC;
    byte udscolnm[];
    short udscolnl;
    byte udssnm[];
    long udssnl;
    int snnumchar[];
    byte udstnm[];
    long udstnl;
    int tnnumchar[];
    int numBytes[];
    short udskpos;
    int udsflg;
    static final int UDSFCOLSEC_ENABLED = 1;
    static final int UDSFCOLSEC_UNKNOWN = 2;
    static final int UDSFCOLSEC_UNAUTH_DATA_NULL = 4;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C8TTIuds(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)0);
        udskpos = -1;
        udsoac = new T4CTTIoac(t4cconnection);
    }

    void unmarshal()
        throws IOException, SQLException
    {
        udsoac.unmarshal();
        short word0 = meg.unmarshalUB1();
        udsnull = word0 > 0;
        udscnl = meg.unmarshalUB1();
        numBytes = new int[1];
        udscolnm = meg.unmarshalDALC(numBytes);
        snnumchar = new int[1];
        udssnm = meg.unmarshalDALC(snnumchar);
        udssnl = udssnm.length;
        tnnumchar = new int[1];
        udstnm = meg.unmarshalDALC(tnnumchar);
        udstnl = udstnm.length;
        if(connection.getTTCVersion() >= 3)
        {
            udskpos = (short)meg.unmarshalUB2();
            if(connection.getTTCVersion() >= 6)
                udsflg = (int)meg.unmarshalUB4();
        } else
        {
            udskpos = -1;
        }
    }

    short getKernelPosition()
    {
        return udskpos;
    }

    byte[] getColumName()
    {
        return udscolnm;
    }

    byte[] getTypeName()
    {
        return udstnm;
    }

    byte[] getSchemaName()
    {
        return udssnm;
    }

    short getTypeCharLength()
    {
        return (short)tnnumchar[0];
    }

    short getColumNameByteLength()
    {
        return (short)numBytes[0];
    }

    short getSchemaCharLength()
    {
        return (short)snnumchar[0];
    }

    void print()
    {
    }

}
