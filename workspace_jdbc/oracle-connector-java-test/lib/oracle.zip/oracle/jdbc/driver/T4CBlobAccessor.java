// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CBlobAccessor.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import oracle.jdbc.internal.OracleStatement;
import oracle.sql.BLOB;

// Referenced classes of package oracle.jdbc.driver:
//            BlobAccessor, T4CMAREngine, OracleStatement, PhysicalConnection, 
//            DatabaseError

class T4CBlobAccessor extends BlobAccessor
{

    T4CMAREngine mare;
    final int meta[];
    ArrayList registeredBLOBs;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CBlobAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, short word0, int j, boolean flag, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, 4000, word0, j, flag);
        meta = new int[1];
        registeredBLOBs = new ArrayList(10);
        mare = t4cmarengine;
    }

    T4CBlobAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, int k1, int l1, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, 4000, flag, j, k, l, i1, j1, word0);
        meta = new int[1];
        registeredBLOBs = new ArrayList(10);
        mare = t4cmarengine;
        definedColumnType = k1;
        definedColumnSize = l1;
    }

    void processIndicator(int i)
        throws IOException, SQLException
    {
        if(internalType == 1 && describeType == 112 || internalType == 23 && describeType == 113)
        {
            mare.unmarshalUB2();
            mare.unmarshalUB2();
        } else
        if(statement.connection.versionNumber < 9200)
        {
            mare.unmarshalSB2();
            if(!statement.sqlKind.isPlsqlOrCall())
                mare.unmarshalSB2();
        } else
        if(statement.sqlKind.isPlsqlOrCall() || isDMLReturnedParam)
            mare.processIndicator(i <= 0, i);
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        if(isUseLess)
        {
            lastRowProcessed++;
            return false;
        }
        if(rowSpaceIndicator == null)
        {
            int i = (int)mare.unmarshalUB4();
            if(i == 0)
            {
                meta[0] = -1;
                processIndicator(0);
                lastRowProcessed++;
                return false;
            } else
            {
                byte abyte0[] = new byte[16000];
                mare.unmarshalCLR(abyte0, 0, meta);
                processIndicator(meta[0]);
                lastRowProcessed++;
                return false;
            }
        }
        int j = columnIndex + lastRowProcessed * byteLength;
        int k = indicatorIndex + lastRowProcessed;
        int l = lengthIndex + lastRowProcessed;
        if(isNullByDescribe)
        {
            rowSpaceIndicator[k] = -1;
            rowSpaceIndicator[l] = 0;
            lastRowProcessed++;
            if(statement.connection.versionNumber < 9200)
                processIndicator(0);
            return false;
        }
        int i1 = (int)mare.unmarshalUB4();
        if(i1 == 0)
        {
            meta[0] = -1;
            processIndicator(0);
            rowSpaceIndicator[k] = -1;
            rowSpaceIndicator[l] = 0;
            lastRowProcessed++;
            return false;
        }
        if(lobPrefetchSizeForThisColumn != -1)
            handlePrefetch();
        mare.unmarshalCLR(rowSpaceByte, j, meta, byteLength);
        processIndicator(meta[0]);
        if(meta[0] == 0)
        {
            rowSpaceIndicator[k] = -1;
            rowSpaceIndicator[l] = 0;
        } else
        {
            rowSpaceIndicator[l] = (short)meta[0];
            rowSpaceIndicator[k] = 0;
        }
        lastRowProcessed++;
        return false;
    }

    void copyRow()
        throws SQLException, IOException
    {
        int i;
        if(lastRowProcessed == 0)
            i = statement.rowPrefetchInLastFetch - 1;
        else
            i = lastRowProcessed - 1;
        int j = columnIndex + lastRowProcessed * byteLength;
        int k = columnIndex + i * byteLength;
        int l = indicatorIndex + lastRowProcessed;
        int i1 = indicatorIndex + i;
        int j1 = lengthIndex + lastRowProcessed;
        int k1 = lengthIndex + i;
        int l1 = rowSpaceIndicator[k1];
        int i2 = metaDataIndex + lastRowProcessed * 1;
        int j2 = metaDataIndex + i * 1;
        rowSpaceIndicator[j1] = (short)l1;
        rowSpaceIndicator[l] = rowSpaceIndicator[i1];
        if(!isNullByDescribe)
            System.arraycopy(rowSpaceByte, k, rowSpaceByte, j, l1);
        System.arraycopy(rowSpaceMetaData, j2, rowSpaceMetaData, i2, 1);
        lastRowProcessed++;
    }

    void saveDataFromOldDefineBuffers(byte abyte0[], char ac[], short aword0[], int i, int j)
        throws SQLException
    {
        int k = columnIndex + (j - 1) * byteLength;
        int l = columnIndexLastRow + (i - 1) * byteLength;
        int i1 = (indicatorIndex + j) - 1;
        int j1 = (indicatorIndexLastRow + i) - 1;
        int k1 = (lengthIndex + j) - 1;
        int l1 = (lengthIndexLastRow + i) - 1;
        int i2 = aword0[l1];
        rowSpaceIndicator[k1] = (short)i2;
        rowSpaceIndicator[i1] = aword0[j1];
        if(i2 != 0)
            System.arraycopy(abyte0, l, rowSpaceByte, k, i2);
    }

    byte[][] checkAndAllocateLobPrefetchMemory(byte abyte0[][], int i, int j, int k)
    {
        byte abyte1[][] = abyte0;
        if(abyte1 == null)
        {
            abyte1 = new byte[Math.max(i, j + 1)][];
            abyte1[j] = new byte[k];
        } else
        {
            if(abyte1.length < j + 1)
            {
                byte abyte2[][] = new byte[(j + 1) * 2][];
                System.arraycopy(abyte1, 0, abyte2, 0, abyte1.length);
                abyte1 = abyte2;
            }
            if(abyte1[j] == null || abyte1[j].length < k)
                abyte1[j] = new byte[k];
        }
        return abyte1;
    }

    char[][] checkAndAllocateLobPrefetchMemory(char ac[][], int i, int j, int k)
    {
        char ac1[][] = ac;
        if(ac1 == null)
        {
            ac1 = new char[Math.max(i, j + 1)][];
            ac1[j] = new char[k];
        } else
        {
            if(ac1.length < j + 1)
            {
                char ac2[][] = new char[(j + 1) * 2][];
                System.arraycopy(ac1, 0, ac2, 0, ac1.length);
                ac1 = ac2;
            }
            if(ac1[j] == null || ac1[j].length < k)
                ac1[j] = new char[k];
        }
        return ac1;
    }

    long[] checkAndAllocateLobPrefetchMemory(long al[], int i, int j)
    {
        long al1[] = al;
        if(al1 == null)
            al1 = new long[Math.max(i, j + 1)];
        else
        if(al1.length < j + 1)
        {
            long al2[] = new long[(j + 1) * 2];
            System.arraycopy(al1, 0, al2, 0, al1.length);
            al1 = al2;
        }
        return al1;
    }

    int[] checkAndAllocateLobPrefetchMemory(int ai[], int i, int j)
    {
        int ai1[] = ai;
        if(ai1 == null)
            ai1 = new int[Math.max(i, j + 1)];
        else
        if(ai1.length < j + 1)
        {
            int ai2[] = new int[(j + 1) * 2];
            System.arraycopy(ai1, 0, ai2, 0, ai1.length);
            ai1 = ai2;
        }
        return ai1;
    }

    short[] checkAndAllocateLobPrefetchMemory(short aword0[], int i, int j)
    {
        short aword1[] = aword0;
        if(aword1 == null)
            aword1 = new short[Math.max(i, j + 1)];
        else
        if(aword1.length < j + 1)
        {
            short aword2[] = new short[(j + 1) * 2];
            System.arraycopy(aword1, 0, aword2, 0, aword1.length);
            aword1 = aword2;
        }
        return aword1;
    }

    byte[] checkAndAllocateLobPrefetchMemory(byte abyte0[], int i, int j)
    {
        byte abyte1[] = abyte0;
        if(abyte1 == null)
            abyte1 = new byte[Math.max(i, j + 1)];
        else
        if(abyte1.length < j + 1)
        {
            byte abyte2[] = new byte[(j + 1) * 2];
            System.arraycopy(abyte1, 0, abyte2, 0, abyte1.length);
            abyte1 = abyte2;
        }
        return abyte1;
    }

    boolean[] checkAndAllocateLobPrefetchMemory(boolean aflag[], int i, int j)
    {
        boolean aflag1[] = aflag;
        if(aflag1 == null)
            aflag1 = new boolean[Math.max(i, j + 1)];
        else
        if(aflag1.length < j + 1)
        {
            boolean aflag2[] = new boolean[(j + 1) * 2];
            System.arraycopy(aflag1, 0, aflag2, 0, aflag1.length);
            aflag1 = aflag2;
        }
        return aflag1;
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
            return null;
        if(lobPrefetchSizeForThisColumn != -1 && prefetchedLobSize != null)
        {
            if(prefetchedLobSize[i] > 0x7fffffffL)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(prefetchedLobData != null && (long)lobPrefetchSizeForThisColumn >= prefetchedLobSize[i])
            {
                byte abyte0[] = new byte[(int)prefetchedLobSize[i]];
                System.arraycopy(prefetchedLobData[i], 0, abyte0, 0, (int)prefetchedLobSize[i]);
                return abyte0;
            }
            BLOB blob = getBLOB(i);
            if(blob == null)
                return null;
            else
                return blob.getBytes(1L, (int)prefetchedLobSize[i]);
        } else
        {
            return super.getBytes(i);
        }
    }

    void handlePrefetch()
        throws SQLException, IOException
    {
        prefetchedLobSize = checkAndAllocateLobPrefetchMemory(prefetchedLobSize, statement.rowPrefetchInLastFetch, lastRowProcessed);
        prefetchedLobSize[lastRowProcessed] = mare.unmarshalSB8();
        prefetchedLobChunkSize = checkAndAllocateLobPrefetchMemory(prefetchedLobChunkSize, statement.rowPrefetchInLastFetch, lastRowProcessed);
        prefetchedLobChunkSize[lastRowProcessed] = (int)mare.unmarshalUB4();
        if(lobPrefetchSizeForThisColumn > 0)
        {
            prefetchedLobDataL = checkAndAllocateLobPrefetchMemory(prefetchedLobDataL, statement.rowPrefetchInLastFetch, lastRowProcessed);
            int i = lobPrefetchSizeForThisColumn;
            prefetchedLobData = checkAndAllocateLobPrefetchMemory(prefetchedLobData, statement.rowPrefetchInLastFetch, lastRowProcessed, i);
            disablePrefetchBufferForPreviousBLOBs(lastRowProcessed);
            mare.unmarshalCLR(prefetchedLobData[lastRowProcessed], 0, meta);
            prefetchedLobDataL[lastRowProcessed] = meta[0];
        }
    }

    void initializeBlobForPrefetch(int i, BLOB blob)
        throws SQLException
    {
        if(i >= 0)
        {
            saveBLOBReference(i, blob);
            blob.setPrefetchedData(prefetchedLobData[i], prefetchedLobDataL[i]);
        }
    }

    private void saveBLOBReference(int i, BLOB blob)
    {
        LinkedList linkedlist = null;
        if(registeredBLOBs.size() > i)
        {
            linkedlist = (LinkedList)registeredBLOBs.get(i);
        } else
        {
            linkedlist = new LinkedList();
            for(; registeredBLOBs.size() < i; registeredBLOBs.add(new LinkedList()));
            registeredBLOBs.add(i, linkedlist);
        }
        if(linkedlist == null)
            linkedlist = new LinkedList();
        linkedlist.add(blob);
    }

    private void disablePrefetchBufferForPreviousBLOBs(int i)
    {
        if(registeredBLOBs.size() > i)
        {
            LinkedList linkedlist = (LinkedList)registeredBLOBs.get(i);
            if(linkedlist != null && !linkedlist.isEmpty())
            {
                for(ListIterator listiterator = linkedlist.listIterator(); listiterator.hasNext(); ((BLOB)listiterator.next()).setPrefetchedData(null));
                linkedlist.clear();
            }
        }
    }

    Object getObject(int i)
        throws SQLException
    {
        if(definedColumnType == 0)
            return super.getObject(i);
        Object obj = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            switch(definedColumnType)
            {
            case 2004: 
                return getBLOB(i);
            }
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return obj;
        }
    }

}
