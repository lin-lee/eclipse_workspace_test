// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIoer.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, T4CConnection, T4CMAREngine, OracleStatement, 
//            DBConversion, DatabaseError, PhysicalConnection, CRC64

class T4CTTIoer extends T4CTTIMsg
{

    final int MAXERRBUF = 512;
    long curRowNumber;
    int retCode;
    int arrayElemWError;
    int arrayElemErrno;
    int currCursorID;
    short errorPosition;
    short sqlType;
    byte oerFatal;
    short flags;
    short userCursorOpt;
    short upiParam;
    short warningFlag;
    int osError;
    short stmtNumber;
    short callNumber;
    int pad1;
    long successIters;
    int partitionId;
    int tableId;
    int slotNumber;
    long rba;
    long blockNumber;
    int warnLength;
    int warnFlag;
    int errorLength[];
    byte errorMsg[];
    static final int ORA1403 = 1403;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIoer(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)4);
        warnLength = 0;
        warnFlag = 0;
        errorLength = new int[1];
    }

    void init()
    {
        retCode = 0;
        errorMsg = null;
    }

    int unmarshal()
        throws IOException, SQLException
    {
        if(connection.getTTCVersion() >= 3)
        {
            short word0 = (short)meg.unmarshalUB2();
            connection.endToEndECIDSequenceNumber = word0;
        }
        curRowNumber = meg.unmarshalUB4();
        retCode = meg.unmarshalUB2();
        arrayElemWError = meg.unmarshalUB2();
        arrayElemErrno = meg.unmarshalUB2();
        currCursorID = meg.unmarshalUB2();
        errorPosition = meg.unmarshalSB2();
        sqlType = meg.unmarshalUB1();
        oerFatal = meg.unmarshalSB1();
        flags = meg.unmarshalSB1();
        userCursorOpt = meg.unmarshalSB1();
        upiParam = meg.unmarshalUB1();
        warningFlag = meg.unmarshalUB1();
        rba = meg.unmarshalUB4();
        partitionId = meg.unmarshalUB2();
        tableId = meg.unmarshalUB1();
        blockNumber = meg.unmarshalUB4();
        slotNumber = meg.unmarshalUB2();
        osError = meg.unmarshalSWORD();
        stmtNumber = meg.unmarshalUB1();
        callNumber = meg.unmarshalUB1();
        pad1 = meg.unmarshalUB2();
        successIters = meg.unmarshalUB4();
        byte abyte0[] = meg.unmarshalDALC();
        int i = meg.unmarshalUB2();
        for(int j = 0; j < i; j++)
            meg.unmarshalUB2();

        int k = (int)meg.unmarshalUB4();
        for(int l = 0; l < k; l++)
            meg.unmarshalUB4();

        int i1 = meg.unmarshalUB2();
        if(retCode != 0)
        {
            errorMsg = meg.unmarshalCLRforREFS();
            errorLength[0] = errorMsg.length;
        }
        return currCursorID;
    }

    void unmarshalWarning()
        throws IOException, SQLException
    {
        retCode = meg.unmarshalUB2();
        warnLength = meg.unmarshalUB2();
        warnFlag = meg.unmarshalUB2();
        if(retCode != 0 && warnLength > 0)
        {
            errorMsg = meg.unmarshalCHR(warnLength);
            errorLength[0] = warnLength;
        }
    }

    void print()
        throws SQLException
    {
        if(retCode == 0)
            if(warnFlag == 0);
    }

    void processError()
        throws SQLException
    {
        processError(true);
    }

    void processError(boolean flag)
        throws SQLException
    {
        processError(flag, null);
    }

    void processError(OracleStatement oraclestatement)
        throws SQLException
    {
        processError(true, oraclestatement);
    }

    void processError(boolean flag, OracleStatement oraclestatement)
        throws SQLException
    {
        if(oraclestatement != null)
            oraclestatement.numberOfExecutedElementsInBatch = (int)successIters;
        if(retCode != 0)
        {
            switch(retCode)
            {
            case 28: // '\034'
            case 600: 
            case 1012: 
            case 1041: 
            case 3113: 
            case 3114: 
                connection.internalClose();
                break;

            case 902: 
                connection.removeAllDescriptor();
                break;
            }
            if(flag)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), meg.conv.CharBytesToString(errorMsg, errorLength[0], true), retCode);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            } else
            {
                return;
            }
        }
        if(!flag)
            return;
        if((warningFlag & 1) == 1)
        {
            int i = warningFlag & -2;
            if((i & 0x20) == 32 || (i & 4) == 4)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 110);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }
        if(connection != null && connection.plsqlCompilerWarnings && (flags & 4) == 4)
            oraclestatement.foundPlsqlCompilerWarning();
    }

    void processWarning()
        throws SQLException
    {
        if(retCode != 0)
            throw DatabaseError.newSqlWarning(meg.conv.CharBytesToString(errorMsg, errorLength[0], true), retCode);
        else
            return;
    }

    int getCurRowNumber()
        throws SQLException
    {
        return (int)curRowNumber;
    }

    int getRetCode()
    {
        return retCode;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

    long updateChecksum(long l)
        throws SQLException
    {
        CRC64 _tmp = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, retCode);
        CRC64 _tmp1 = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, curRowNumber);
        CRC64 _tmp2 = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, errorPosition);
        CRC64 _tmp3 = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, sqlType);
        CRC64 _tmp4 = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, oerFatal);
        CRC64 _tmp5 = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, flags);
        CRC64 _tmp6 = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, userCursorOpt);
        CRC64 _tmp7 = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, upiParam);
        CRC64 _tmp8 = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, warningFlag);
        CRC64 _tmp9 = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, osError);
        CRC64 _tmp10 = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, successIters);
        CRC64 _tmp11 = PhysicalConnection.CHECKSUM;
        l = CRC64.updateChecksum(l, errorMsg, 0, errorMsg.length);
        return l;
    }

}
