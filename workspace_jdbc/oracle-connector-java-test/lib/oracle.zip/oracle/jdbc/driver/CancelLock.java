// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   CancelLock.java

package oracle.jdbc.driver;


class CancelLock
{
    private static final class State extends Enum
    {

        public static final State IDLE;
        public static final State EXECUTING;
        public static final State CANCELING;
        private static final State $VALUES[];

        public static State[] values()
        {
            return (State[])$VALUES.clone();
        }

        public static State valueOf(String s)
        {
            return (State)Enum.valueOf(oracle/jdbc/driver/CancelLock$State, s);
        }

        static 
        {
            IDLE = new State("IDLE", 0);
            EXECUTING = new State("EXECUTING", 1);
            CANCELING = new State("CANCELING", 2);
            $VALUES = (new State[] {
                IDLE, EXECUTING, CANCELING
            });
        }

        private State(String s, int i)
        {
            super(s, i);
        }
    }


    private State state;
    static final boolean $assertionsDisabled = !oracle/jdbc/driver/CancelLock.desiredAssertionStatus();

    CancelLock()
    {
        state = State.IDLE;
    }

    synchronized void enterExecuting()
    {
        if(!$assertionsDisabled && state != State.IDLE)
        {
            throw new AssertionError();
        } else
        {
            state = State.EXECUTING;
            return;
        }
    }

    synchronized void exitExecuting()
    {
        while(state != State.EXECUTING) 
        {
            if(!$assertionsDisabled && state != State.CANCELING)
                throw new AssertionError();
            try
            {
                wait();
            }
            catch(InterruptedException interruptedexception) { }
        }
        state = State.IDLE;
    }

    synchronized boolean enterCanceling()
    {
        if(state == State.EXECUTING)
        {
            state = State.CANCELING;
            return true;
        } else
        {
            return false;
        }
    }

    synchronized void exitCanceling()
    {
        if(!$assertionsDisabled && state != State.CANCELING)
        {
            throw new AssertionError();
        } else
        {
            state = State.EXECUTING;
            notify();
            return;
        }
    }

}
