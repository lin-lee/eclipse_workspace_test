// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T2CError.java

package oracle.jdbc.driver;


class T2CError
{

    int m_errorNumber;
    byte m_errorMessage[];
    byte m_sqlState[];

    T2CError()
    {
        m_errorMessage = new byte[1024];
        m_sqlState = new byte[6];
    }
}
