// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConversionReader.java

package oracle.jdbc.driver;

import java.io.*;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            DBConversion, DatabaseError

class OracleConversionReader extends Reader
{

    static final int CHUNK_SIZE = 4096;
    DBConversion dbConversion;
    int conversion;
    InputStream istream;
    char buf[];
    byte byteBuf[];
    int pos;
    int count;
    int numUnconvertedBytes;
    boolean isClosed;
    boolean endOfStream;
    private short csform;
    int nbytes[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleConversionReader(DBConversion dbconversion, InputStream inputstream, int i)
        throws SQLException
    {
        if(dbconversion == null || inputstream == null || i != 8 && i != 9)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        dbConversion = dbconversion;
        conversion = i;
        istream = inputstream;
        pos = count = 0;
        numUnconvertedBytes = 0;
        isClosed = false;
        nbytes = new int[1];
        if(i == 8)
        {
            byteBuf = new byte[2048];
            buf = new char[4096];
        } else
        if(i == 9)
        {
            byteBuf = new byte[4096];
            buf = new char[4096];
        }
    }

    public void setFormOfUse(short word0)
    {
        csform = word0;
    }

    public int read(char ac[], int i, int j)
        throws IOException
    {
        ensureOpen();
        if(!needChars())
            return -1;
        int k = i;
        int l = k + Math.min(j, ac.length - i);
        for(k += writeChars(ac, k, l - k); k < l && needChars(); k += writeChars(ac, k, l - k));
        return k - i;
    }

    protected boolean needChars()
        throws IOException
    {
        ensureOpen();
        if(pos >= count)
        {
            if(!endOfStream)
                try
                {
                    int i = istream.read(byteBuf, numUnconvertedBytes, byteBuf.length - numUnconvertedBytes);
                    if(i == -1)
                    {
                        endOfStream = true;
                        istream.close();
                        if(numUnconvertedBytes != 0)
                        {
                            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 55);
                            sqlexception1.fillInStackTrace();
                            throw sqlexception1;
                        }
                    }
                    i += numUnconvertedBytes;
                    if(i > 0)
                    {
                        switch(conversion)
                        {
                        case 8: // '\b'
                            count = dbConversion.RAWBytesToHexChars(byteBuf, i, buf);
                            break;

                        case 9: // '\t'
                            nbytes[0] = i;
                            if(csform == 2)
                                count = dbConversion.NCHARBytesToJavaChars(byteBuf, 0, buf, 0, nbytes, buf.length);
                            else
                                count = dbConversion.CHARBytesToJavaChars(byteBuf, 0, buf, 0, nbytes, buf.length);
                            numUnconvertedBytes = nbytes[0];
                            for(int j = 0; j < numUnconvertedBytes; j++)
                                byteBuf[j] = byteBuf[(i - numUnconvertedBytes) + j];

                            break;

                        default:
                            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
                            sqlexception2.fillInStackTrace();
                            throw sqlexception2;
                        }
                        if(count > 0)
                        {
                            pos = 0;
                            return true;
                        }
                    }
                }
                catch(SQLException sqlexception)
                {
                    IOException ioexception = DatabaseError.createIOException(sqlexception);
                    ioexception.fillInStackTrace();
                    throw ioexception;
                }
            return false;
        } else
        {
            return true;
        }
    }

    protected int writeChars(char ac[], int i, int j)
    {
        int k = Math.min(j, count - pos);
        System.arraycopy(buf, pos, ac, i, k);
        pos += k;
        return k;
    }

    public boolean ready()
        throws IOException
    {
        ensureOpen();
        return pos < count;
    }

    public void close()
        throws IOException
    {
        if(!isClosed)
        {
            isClosed = true;
            istream.close();
        }
    }

    void ensureOpen()
        throws IOException
    {
        try
        {
            if(isClosed)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, null);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(SQLException sqlexception1)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception1);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
