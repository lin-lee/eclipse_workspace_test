// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDriverExtension.java

package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

// Referenced classes of package oracle.jdbc.driver:
//            PhysicalConnection, OracleStatement, OraclePreparedStatement, OracleCallableStatement, 
//            Accessor, OracleInputStream

abstract class OracleDriverExtension
{

    OracleDriverExtension()
    {
    }

    abstract Connection getConnection(String s, Properties properties)
        throws SQLException;

    abstract OracleStatement allocateStatement(PhysicalConnection physicalconnection, int i, int j)
        throws SQLException;

    abstract OraclePreparedStatement allocatePreparedStatement(PhysicalConnection physicalconnection, String s, int i, int j)
        throws SQLException;

    abstract OracleCallableStatement allocateCallableStatement(PhysicalConnection physicalconnection, String s, int i, int j)
        throws SQLException;

    abstract OracleInputStream createInputStream(OracleStatement oraclestatement, int i, Accessor accessor)
        throws SQLException;
}
