// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIoauthenticate.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.Properties;
import java.util.TimeZone;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.util.RepConversion;
import oracle.net.ano.AuthenticationService;
import oracle.net.ns.Communication;
import oracle.net.ns.SessionAtts;
import oracle.net.nt.TcpsNTAdapter;
import oracle.security.o3logon.O3LoginClientHelper;
import oracle.security.o5logon.O5Logon;
import oracle.sql.ZONEIDMAP;
import oracle.sql.converter.CharacterSetMetaData;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CKvaldfList, T4CConnection, DBConversion, 
//            T4CMAREngine, T4CTTIoer, DatabaseError, ClassRef

final class T4CTTIoauthenticate extends T4CTTIfun
{

    byte terminal[];
    byte enableTempLobRefCnt[];
    byte machine[];
    byte sysUserName[];
    byte processID[];
    byte programName[];
    byte encryptedSK[];
    byte internalName[];
    byte externalName[];
    byte alterSession[];
    byte aclValue[];
    byte clientname[];
    byte editionName[];
    byte driverName[];
    String ressourceManagerId;
    boolean bUseO5Logon;
    int verifierType;
    static final int ZTVT_ORCL_7 = 2361;
    static final int ZTVT_SSH1 = 6949;
    static final int ZTVT_NTV = 7809;
    static final int ZTVT_SMD5 = 59694;
    static final int ZTVT_MD5 = 40674;
    static final int ZTVT_SH1 = 45394;
    byte salt[];
    byte encryptedKB[];
    boolean isSessionTZ;
    static final int SERVER_VERSION_81 = 8100;
    static final int KPZ_LOGON = 1;
    static final int KPZ_CPW = 2;
    static final int KPZ_SRVAUTH = 4;
    static final int KPZ_ENCRYPTED_PASSWD = 256;
    static final int KPZ_LOGON_MIGRATE = 16;
    static final int KPZ_LOGON_SYSDBA = 32;
    static final int KPZ_LOGON_SYSOPER = 64;
    static final int KPZ_LOGON_PRELIMAUTH = 128;
    static final int KPZ_PASSWD_ENCRYPTED = 256;
    static final int KPZ_LOGON_DBCONC = 512;
    static final int KPZ_PROXY_AUTH = 1024;
    static final int KPZ_SESSION_CACHE = 2048;
    static final int KPZ_PASSWD_IS_VFR = 4096;
    static final int KPZ_LOGON_SYSASM = 0x400000;
    static final int KPZ_SESSION_QCACHE = 0x800000;
    static final int KPZ_LOGON_SYSBKP = 0x1000000;
    static final int KPZ_LOGON_SYSDGD = 0x2000000;
    static final int KPZ_LOGON_SYSKMT = 0x4000000;
    static final String AUTH_TERMINAL = "AUTH_TERMINAL";
    static final String AUTH_PROGRAM_NM = "AUTH_PROGRAM_NM";
    static final String AUTH_MACHINE = "AUTH_MACHINE";
    static final String AUTH_PID = "AUTH_PID";
    static final String AUTH_SID = "AUTH_SID";
    static final String AUTH_SESSKEY = "AUTH_SESSKEY";
    static final String AUTH_VFR_DATA = "AUTH_VFR_DATA";
    static final String AUTH_PASSWORD = "AUTH_PASSWORD";
    static final String AUTH_INTERNALNAME = "AUTH_INTERNALNAME_";
    static final String AUTH_EXTERNALNAME = "AUTH_EXTERNALNAME_";
    static final String AUTH_ACL = "AUTH_ACL";
    static final String AUTH_ALTER_SESSION = "AUTH_ALTER_SESSION";
    static final String AUTH_INITIAL_CLIENT_ROLE = "INITIAL_CLIENT_ROLE";
    static final String AUTH_VERSION_SQL = "AUTH_VERSION_SQL";
    static final String AUTH_VERSION_NO = "AUTH_VERSION_NO";
    static final String AUTH_XACTION_TRAITS = "AUTH_XACTION_TRAITS";
    static final String AUTH_VERSION_STATUS = "AUTH_VERSION_STATUS";
    static final String AUTH_SERIAL_NUM = "AUTH_SERIAL_NUM";
    static final String AUTH_SESSION_ID = "AUTH_SESSION_ID";
    static final String AUTH_CLIENT_CERTIFICATE = "AUTH_CLIENT_CERTIFICATE";
    static final String AUTH_PROXY_CLIENT_NAME = "PROXY_CLIENT_NAME";
    static final String AUTH_CLIENT_DN = "AUTH_CLIENT_DISTINGUISHED_NAME";
    static final String AUTH_INSTANCENAME = "AUTH_INSTANCENAME";
    static final String AUTH_DBNAME = "AUTH_DBNAME";
    static final String AUTH_INSTANCE_NO = "AUTH_INSTANCE_NO";
    static final String AUTH_SC_SERVER_HOST = "AUTH_SC_SERVER_HOST";
    static final String AUTH_SC_INSTANCE_NAME = "AUTH_SC_INSTANCE_NAME";
    static final String AUTH_SC_INSTANCE_ID = "AUTH_SC_INSTANCE_ID";
    static final String AUTH_SC_INSTANCE_START_TIME = "AUTH_SC_INSTANCE_START_TIME";
    static final String AUTH_SC_DBUNIQUE_NAME = "AUTH_SC_DBUNIQUE_NAME";
    static final String AUTH_SC_SERVICE_NAME = "AUTH_SC_SERVICE_NAME";
    static final String AUTH_SC_SVC_FLAGS = "AUTH_SC_SVC_FLAGS";
    static final String AUTH_SESSION_CLIENT_CSET = "SESSION_CLIENT_CHARSET";
    static final String AUTH_SESSION_CLIENT_LTYPE = "SESSION_CLIENT_LIB_TYPE";
    static final String AUTH_SESSION_CLIENT_DRVNM = "SESSION_CLIENT_DRIVER_NAME";
    static final String AUTH_SESSION_CLIENT_VSN = "SESSION_CLIENT_VERSION";
    static final String AUTH_NLS_LXLAN = "AUTH_NLS_LXLAN";
    static final String AUTH_NLS_LXCTERRITORY = "AUTH_NLS_LXCTERRITORY";
    static final String AUTH_NLS_LXCCURRENCY = "AUTH_NLS_LXCCURRENCY";
    static final String AUTH_NLS_LXCISOCURR = "AUTH_NLS_LXCISOCURR";
    static final String AUTH_NLS_LXCNUMERICS = "AUTH_NLS_LXCNUMERICS";
    static final String AUTH_NLS_LXCDATEFM = "AUTH_NLS_LXCDATEFM";
    static final String AUTH_NLS_LXCDATELANG = "AUTH_NLS_LXCDATELANG";
    static final String AUTH_NLS_LXCSORT = "AUTH_NLS_LXCSORT";
    static final String AUTH_NLS_LXCCALENDAR = "AUTH_NLS_LXCCALENDAR";
    static final String AUTH_NLS_LXCUNIONCUR = "AUTH_NLS_LXCUNIONCUR";
    static final String AUTH_NLS_LXCTIMEFM = "AUTH_NLS_LXCTIMEFM";
    static final String AUTH_NLS_LXCSTMPFM = "AUTH_NLS_LXCSTMPFM";
    static final String AUTH_NLS_LXCTTZNFM = "AUTH_NLS_LXCTTZNFM";
    static final String AUTH_NLS_LXCSTZNFM = "AUTH_NLS_LXCSTZNFM";
    static final String SESSION_CLIENT_LOBATTR = "SESSION_CLIENT_LOBATTR";
    static final String DRIVER_NAME_DEFAULT = "jdbcthin";
    static final int KPU_LIB_UNKN = 0;
    static final int KPU_LIB_DEF = 1;
    static final int KPU_LIB_EI = 2;
    static final int KPU_LIB_XE = 3;
    static final int KPU_LIB_ICUS = 4;
    static final int KPU_LIB_OCI = 5;
    static final int KPU_LIB_THIN = 10;
    static final String AUTH_ORA_EDITION = "AUTH_ORA_EDITION";
    static final String AUTH_COPYRIGHT = "AUTH_COPYRIGHT";
    static final String COPYRIGHT_STR = "\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation.";
    static final String SESSION_TIME_ZONE = "SESSION_TIME_ZONE";
    static final String SESSION_NLS_LXCCHARSET = "SESSION_NLS_LXCCHARSET";
    static final String SESSION_NLS_LXCNLSLENSEM = "SESSION_NLS_LXCNLSLENSEM";
    static final String SESSION_NLS_LXCNCHAREXCP = "SESSION_NLS_LXCNCHAREXCP";
    static final String SESSION_NLS_LXCNCHARIMP = "SESSION_NLS_LXCNCHARIMP";
    String sessionTimeZone;
    byte serverCompileTimeCapabilities[];
    private T4CKvaldfList keyValList;
    private byte user[];
    private long logonMode;
    private byte outKeys[][];
    private byte outValues[][];
    private int outFlags[];
    private int outNbPairs;
    O5Logon o5logonHelper;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIoauthenticate(T4CConnection t4cconnection, String s, byte abyte0[])
        throws SQLException
    {
        super(t4cconnection, (byte)3);
        editionName = null;
        isSessionTZ = true;
        sessionTimeZone = null;
        serverCompileTimeCapabilities = null;
        keyValList = null;
        user = null;
        outKeys = (byte[][])null;
        outValues = (byte[][])null;
        outFlags = new int[0];
        outNbPairs = 0;
        o5logonHelper = new O5Logon();
        ressourceManagerId = s;
        serverCompileTimeCapabilities = abyte0;
        setSessionFields(t4cconnection);
        isSessionTZ = true;
        bUseO5Logon = false;
    }

    void marshal()
        throws IOException
    {
        if(user != null && user.length > 0)
        {
            meg.marshalPTR();
            meg.marshalSB4(user.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSB4(0);
        }
        meg.marshalUB4(logonMode);
        meg.marshalPTR();
        meg.marshalUB4(keyValList.size());
        meg.marshalPTR();
        meg.marshalPTR();
        if(user != null && user.length > 0)
            meg.marshalCHR(user);
        meg.marshalKEYVAL(keyValList.getKeys(), keyValList.getValues(), keyValList.getFlags(), keyValList.size());
    }

    private void doOAUTH(byte abyte0[], byte abyte1[], long l, String s, boolean flag, byte abyte2[], 
            byte abyte3[], byte abyte4[][], int i, int j)
        throws IOException, SQLException
    {
        setFunCode((short)115);
        user = abyte0;
        logonMode = l | 1L;
        if(flag)
            logonMode |= 1024L;
        if(abyte0 != null && abyte0.length != 0 && abyte1 != null && s != "RADIUS")
            logonMode |= 256L;
        keyValList = new T4CKvaldfList(meg.conv);
        if(abyte1 != null)
            keyValList.add("AUTH_PASSWORD", abyte1);
        if(abyte4 != null)
        {
            for(int k = 0; k < abyte4.length; k++)
                keyValList.add("INITIAL_CLIENT_ROLE", abyte4[k]);

        }
        if(abyte2 != null)
            keyValList.add("AUTH_CLIENT_DISTINGUISHED_NAME", abyte2);
        if(abyte3 != null)
            keyValList.add("AUTH_CLIENT_CERTIFICATE", abyte3);
        keyValList.add("AUTH_TERMINAL", terminal);
        if(bUseO5Logon && encryptedKB != null)
            keyValList.add("AUTH_SESSKEY", encryptedKB, (byte)1);
        if(programName != null)
            keyValList.add("AUTH_PROGRAM_NM", programName);
        if(clientname != null)
            keyValList.add("PROXY_CLIENT_NAME", clientname);
        keyValList.add("AUTH_MACHINE", machine);
        keyValList.add("AUTH_PID", processID);
        if(!ressourceManagerId.equals("0000"))
        {
            byte abyte5[] = meg.conv.StringToCharBytes("AUTH_INTERNALNAME_");
            abyte5[abyte5.length - 1] = 0;
            keyValList.add(abyte5, internalName);
            abyte5 = meg.conv.StringToCharBytes("AUTH_EXTERNALNAME_");
            abyte5[abyte5.length - 1] = 0;
            keyValList.add(abyte5, externalName);
        }
        keyValList.add("AUTH_ACL", aclValue);
        keyValList.add("AUTH_ALTER_SESSION", alterSession, (byte)1);
        if(editionName != null)
            keyValList.add("AUTH_ORA_EDITION", editionName);
        keyValList.add("SESSION_CLIENT_LOBATTR", enableTempLobRefCnt);
        keyValList.add("SESSION_CLIENT_DRIVER_NAME", driverName);
        keyValList.add("SESSION_CLIENT_VERSION", meg.conv.StringToCharBytes(Integer.toString(versionStringToInt(connection.getMetaData().getDriverVersion()), 10)));
        if(i != -1)
            keyValList.add("AUTH_SESSION_ID", meg.conv.StringToCharBytes(Integer.toString(i)));
        if(j != -1)
            keyValList.add("AUTH_SERIAL_NUM", meg.conv.StringToCharBytes(Integer.toString(j)));
        keyValList.add("AUTH_COPYRIGHT", meg.conv.StringToCharBytes("\"Oracle\nEverybody follows\nSpeedy bits exchange\nStars await to glow\"\nThe preceding key is copyrighted by Oracle Corporation.\nDuplication of this key is not allowed without permission\nfrom Oracle Corporation. Copyright 2003 Oracle Corporation."));
        outNbPairs = 0;
        outKeys = (byte[][])null;
        outValues = (byte[][])null;
        outFlags = new int[0];
        doRPC();
    }

    void doOSESSKEY(String s, long l)
        throws IOException, SQLException
    {
        setFunCode((short)118);
        user = meg.conv.StringToCharBytes(s);
        logonMode = l | 1L;
        keyValList = new T4CKvaldfList(meg.conv);
        keyValList.add("AUTH_TERMINAL", terminal);
        if(programName != null)
            keyValList.add("AUTH_PROGRAM_NM", programName);
        keyValList.add("AUTH_MACHINE", machine);
        keyValList.add("AUTH_PID", processID);
        keyValList.add("AUTH_SID", sysUserName);
        outNbPairs = 0;
        outKeys = (byte[][])null;
        outValues = (byte[][])null;
        outFlags = new int[0];
        doRPC();
    }

    void readRPA()
        throws IOException, SQLException
    {
        outNbPairs = meg.unmarshalUB2();
        outKeys = new byte[outNbPairs][];
        outValues = new byte[outNbPairs][];
        outFlags = meg.unmarshalKEYVAL(outKeys, outValues, outNbPairs);
    }

    void processError()
        throws SQLException
    {
        if(getFunCode() == 118)
        {
            if(oer.getRetCode() != 28035 || connection.net.getAuthenticationAdaptorName() != "RADIUS")
                oer.processError();
        } else
        {
            super.processError();
        }
    }

    protected void processRPA()
        throws SQLException
    {
        if(getFunCode() == 115)
        {
            Properties properties = new Properties();
            for(int j = 0; j < outNbPairs; j++)
            {
                String s1 = meg.conv.CharBytesToString(outKeys[j], outKeys[j].length).trim();
                String s2 = "";
                if(outValues[j] != null)
                    s2 = meg.conv.CharBytesToString(outValues[j], outValues[j].length).trim();
                properties.setProperty(s1, s2);
            }

            String s = properties.getProperty("AUTH_VERSION_NO");
            int l;
            if(s != null)
                try
                {
                    l = (new Integer(s)).intValue();
                }
                catch(NumberFormatException numberformatexception) { }
            properties.setProperty("SERVER_HOST", properties.getProperty("AUTH_SC_SERVER_HOST", ""));
            properties.setProperty("INSTANCE_NAME", properties.getProperty("AUTH_SC_INSTANCE_NAME", ""));
            properties.setProperty("DATABASE_NAME", properties.getProperty("AUTH_SC_DBUNIQUE_NAME", ""));
            properties.setProperty("SERVICE_NAME", properties.getProperty("AUTH_SC_SERVICE_NAME", ""));
            properties.setProperty("SESSION_TIME_ZONE", sessionTimeZone);
            connection.sessionProperties = properties;
        } else
        if(getFunCode() == 118 && connection.net.getAuthenticationAdaptorName() != "RADIUS")
        {
            if(outKeys == null || outKeys.length < 1)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            int i = -1;
            int k = -1;
            try
            {
                int i1 = 0;
                do
                {
                    if(i1 >= outKeys.length)
                        break;
                    String s3 = new String(outKeys[i1], "US-ASCII");
                    if(s3.equals("AUTH_SESSKEY"))
                        i = i1;
                    else
                    if(s3.equals("AUTH_VFR_DATA"))
                        k = i1;
                    if(k != -1 && i != -1)
                        break;
                    i1++;
                } while(true);
            }
            catch(UnsupportedEncodingException unsupportedencodingexception) { }
            if(i == -1)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            encryptedSK = outValues[i];
            if(k != -1)
            {
                bUseO5Logon = true;
                salt = outValues[k];
                verifierType = outFlags[k];
            }
            if(!bUseO5Logon && (encryptedSK == null || encryptedSK.length != 16))
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 438);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        }
    }

    void doOAUTH(String s, String s1, long l)
        throws IOException, SQLException
    {
        byte abyte0[] = null;
        if(s != null && s.length() > 0)
            abyte0 = meg.conv.StringToCharBytes(s);
        byte abyte1[] = null;
        Object obj = null;
        byte abyte4[] = null;
        String s2 = connection.net.getAuthenticationAdaptorName();
        if(s != null && s.length() != 0)
        {
            if(s2 != "RADIUS" && encryptedSK.length > 16 && !bUseO5Logon)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(bUseO5Logon && (encryptedSK == null || encryptedSK.length != 64 && encryptedSK.length != 96))
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            String s4 = s.trim();
            String s5 = null;
            if(s1 != null)
                s5 = s1.trim();
            s1 = null;
            String s6 = s4;
            String s7 = s5;
            if(s4.startsWith("\"") || s4.endsWith("\""))
                s6 = removeQuotes(s4);
            if(s5 != null && (s5.startsWith("\"") || s5.endsWith("\"")))
                s7 = removeQuotes(s5);
            if(s7 != null)
                abyte1 = meg.conv.StringToCharBytes(s7);
            if(s2 != "RADIUS")
            {
                if(abyte1 == null)
                    abyte4 = null;
                else
                if(bUseO5Logon)
                {
                    encryptedKB = new byte[encryptedSK.length];
                    for(int i = 0; i < encryptedKB.length; i++)
                        encryptedKB[i] = 1;

                    int ai[] = new int[1];
                    byte abyte6[] = new byte[256];
                    for(int j = 0; j < 256; j++)
                        abyte6[j] = 0;

                    try
                    {
                        o5logonHelper.generateOAuthResponse(verifierType, salt, s6, s7, abyte1, encryptedSK, encryptedKB, abyte6, ai, meg.conv.isServerCSMultiByte, serverCompileTimeCapabilities[4]);
                    }
                    catch(Exception exception1) { }
                    abyte4 = new byte[ai[0]];
                    System.arraycopy(abyte6, 0, abyte4, 0, ai[0]);
                } else
                {
                    O3LoginClientHelper o3loginclienthelper = new O3LoginClientHelper(meg.conv.isServerCSMultiByte);
                    byte abyte7[] = o3loginclienthelper.getSessionKey(s6, s7, encryptedSK);
                    byte byte0;
                    if(abyte1.length % 8 > 0)
                        byte0 = (byte)(8 - abyte1.length % 8);
                    else
                        byte0 = 0;
                    byte abyte2[] = new byte[abyte1.length + byte0];
                    System.arraycopy(abyte1, 0, abyte2, 0, abyte1.length);
                    byte abyte8[] = o3loginclienthelper.getEPasswd(abyte7, abyte2);
                    abyte4 = new byte[2 * abyte2.length + 1];
                    if(abyte4.length < 2 * abyte8.length)
                    {
                        SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 413);
                        sqlexception4.fillInStackTrace();
                        throw sqlexception4;
                    }
                    RepConversion.bArray2Nibbles(abyte8, abyte4);
                    abyte4[abyte4.length - 1] = RepConversion.nibbleToHex(byte0);
                }
            } else
            if(abyte1 != null)
                if(connection.net.getSessionAttributes().getNTAdapter() instanceof TcpsNTAdapter)
                {
                    abyte4 = abyte1;
                } else
                {
                    byte byte1;
                    if((abyte1.length + 1) % 8 > 0)
                        byte1 = (byte)(8 - (abyte1.length + 1) % 8);
                    else
                        byte1 = 0;
                    byte abyte3[] = new byte[abyte1.length + 1 + byte1];
                    System.arraycopy(abyte1, 0, abyte3, 0, abyte1.length);
                    byte abyte5[] = AuthenticationService.obfuscatePasswordForRadius(abyte3);
                    abyte4 = new byte[abyte5.length * 2];
                    for(int k = 0; k < abyte5.length; k++)
                    {
                        byte byte2 = (byte)((abyte5[k] & 0xf0) >> 4);
                        byte byte3 = (byte)(abyte5[k] & 0xf);
                        abyte4[k * 2] = (byte)(byte2 >= 10 ? (byte2 - 10) + 97 : byte2 + 48);
                        abyte4[k * 2 + 1] = (byte)(byte3 >= 10 ? (byte3 - 10) + 97 : byte3 + 48);
                    }

                }
        }
        doOAUTH(abyte0, abyte4, l, s2, false, null, null, (byte[][])null, -1, -1);
        if(s2 != "RADIUS" && bUseO5Logon)
        {
            String s3 = connection.sessionProperties.getProperty("AUTH_SVR_RESPONSE");
            try
            {
                if(!o5logonHelper.validateServerIdentity(s3))
                {
                    SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 452);
                    sqlexception2.fillInStackTrace();
                    throw sqlexception2;
                }
            }
            catch(Exception exception)
            {
                SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 452);
                sqlexception3.fillInStackTrace();
                throw sqlexception3;
            }
        }
    }

    void doOAUTH(int i, Properties properties, int j, int k)
        throws IOException, SQLException
    {
        byte abyte0[] = null;
        byte abyte1[] = null;
        String as[] = null;
        byte abyte2[][] = (byte[][])null;
        byte abyte3[] = null;
        if(i == 1)
        {
            String s = properties.getProperty("PROXY_USER_NAME");
            String s2 = properties.getProperty("PROXY_USER_PASSWORD");
            if(s2 != null)
                s = (new StringBuilder()).append(s).append("/").append(s2).toString();
            abyte3 = meg.conv.StringToCharBytes(s);
        } else
        if(i == 2)
        {
            String s1 = properties.getProperty("PROXY_DISTINGUISHED_NAME");
            abyte0 = meg.conv.StringToCharBytes(s1);
        } else
        {
            try
            {
                abyte1 = (byte[])(byte[])properties.get("PROXY_CERTIFICATE");
                StringBuffer stringbuffer = new StringBuffer();
                for(int j1 = 0; j1 < abyte1.length; j1++)
                {
                    String s3 = Integer.toHexString(0xff & abyte1[j1]);
                    int i1 = s3.length();
                    if(i1 == 0)
                    {
                        stringbuffer.append("00");
                        continue;
                    }
                    if(i1 == 1)
                    {
                        stringbuffer.append('0');
                        stringbuffer.append(s3);
                    } else
                    {
                        stringbuffer.append(s3);
                    }
                }

                abyte1 = stringbuffer.toString().getBytes();
            }
            catch(Exception exception) { }
        }
        try
        {
            as = (String[])(String[])properties.get("PROXY_ROLES");
        }
        catch(Exception exception1) { }
        if(as != null)
        {
            abyte2 = new byte[as.length][];
            for(int l = 0; l < as.length; l++)
                abyte2[l] = meg.conv.StringToCharBytes(as[l]);

        }
        doOAUTH(abyte3, null, 0L, null, true, abyte0, abyte1, abyte2, j, k);
    }

    private void setSessionFields(T4CConnection t4cconnection)
        throws SQLException
    {
        String s = connection.thinVsessionTerminal;
        String s1 = connection.thinVsessionMachine;
        String s2 = connection.thinVsessionOsuser;
        String s3 = connection.thinVsessionProgram;
        String s4 = connection.thinVsessionProcess;
        String s5 = connection.thinVsessionIname;
        String s6 = connection.thinVsessionEname;
        String s7 = connection.proxyClientName;
        String s8 = connection.driverNameAttribute;
        String s9 = connection.editionName;
        try
        {
            if(connection.enableTempLobRefCnt)
                enableTempLobRefCnt = (new String("1")).getBytes("US-ASCII");
            else
                enableTempLobRefCnt = (new String("0")).getBytes("US-ASCII");
        }
        catch(UnsupportedEncodingException unsupportedencodingexception) { }
        if(s1 == null)
            try
            {
                s1 = InetAddress.getLocalHost().getHostName();
            }
            catch(Exception exception)
            {
                s1 = "jdbcclient";
            }
        if(s6 == null)
            s6 = (new StringBuilder()).append("jdbc_").append(ressourceManagerId).toString();
        if(s8 == null)
            s8 = "jdbcthin";
        terminal = meg.conv.StringToCharBytes(s);
        machine = meg.conv.StringToCharBytes(s1);
        sysUserName = meg.conv.StringToCharBytes(s2);
        programName = meg.conv.StringToCharBytes(s3);
        processID = meg.conv.StringToCharBytes(s4);
        internalName = meg.conv.StringToCharBytes(s5);
        externalName = meg.conv.StringToCharBytes(s6);
        if(s7 != null)
            clientname = meg.conv.StringToCharBytes(s7);
        if(s9 != null)
            editionName = meg.conv.StringToCharBytes(s9);
        driverName = meg.conv.StringToCharBytes(s8);
        TimeZone timezone = TimeZone.getDefault();
        String s10 = timezone.getID();
        if(!ZONEIDMAP.isValidRegion(s10) || !t4cconnection.timezoneAsRegion)
        {
            int i = timezone.getOffset(System.currentTimeMillis());
            int j = i / 0x36ee80;
            int k = (i / 60000) % 60;
            s10 = (new StringBuilder()).append(j >= 0 ? (new StringBuilder()).append("+").append(j).toString() : (new StringBuilder()).append("").append(j).toString()).append(k >= 10 ? (new StringBuilder()).append(":").append(k).toString() : (new StringBuilder()).append(":0").append(k).toString()).toString();
        }
        sessionTimeZone = s10;
        t4cconnection.sessionTimeZone = s10;
        String s11 = CharacterSetMetaData.getNLSLanguage(ClassRef.LOCALE.getDefault());
        String s12 = CharacterSetMetaData.getNLSTerritory(ClassRef.LOCALE.getDefault());
        if(s11 == null || s12 == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            alterSession = meg.conv.StringToCharBytes((new StringBuilder()).append("ALTER SESSION SET ").append(isSessionTZ ? (new StringBuilder()).append("TIME_ZONE='").append(sessionTimeZone).append("'").toString() : "").append(" NLS_LANGUAGE='").append(s11).append("' NLS_TERRITORY='").append(s12).append("' ").toString());
            aclValue = meg.conv.StringToCharBytes("4400");
            alterSession[alterSession.length - 1] = 0;
            return;
        }
    }

    String removeQuotes(String s)
    {
        int i = 0;
        int j = s.length() - 1;
        int k = 0;
        do
        {
            if(k >= s.length())
                break;
            if(s.charAt(k) != '"')
            {
                i = k;
                break;
            }
            k++;
        } while(true);
        k = s.length() - 1;
        do
        {
            if(k < 0)
                break;
            if(s.charAt(k) != '"')
            {
                j = k;
                break;
            }
            k--;
        } while(true);
        String s1 = s.substring(i, j + 1);
        return s1;
    }

    private int versionStringToInt(String s)
        throws SQLException
    {
        String as[] = s.split("\\.");
        int i = Integer.parseInt(as[0].replaceAll("\\D", ""));
        int j = Integer.parseInt(as[1].replaceAll("\\D", ""));
        int k = Integer.parseInt(as[2].replaceAll("\\D", ""));
        int l = Integer.parseInt(as[3].replaceAll("\\D", ""));
        int i1 = Integer.parseInt(as[4].replaceAll("\\D", ""));
        int j1 = i << 24 | j << 20 | k << 12 | l << 8 | i1;
        return j1;
    }

    private String versionIntToString(int i)
        throws SQLException
    {
        int j = (i & 0xff000000) >> 24 & 0xff;
        int k = (i & 0xf00000) >> 20 & 0xff;
        int l = (i & 0xff000) >> 12 & 0xff;
        int i1 = (i & 0xf00) >> 8 & 0xff;
        int j1 = i & 0xff;
        String s = (new StringBuilder()).append("").append(j).append(".").append(k).append(".").append(l).append(".").append(i1).append(".").append(j1).toString();
        return s;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
