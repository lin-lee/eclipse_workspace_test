// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.driver:
//            Binder, PlsqlIbtBindInfo, OraclePreparedStatement, OraclePreparedStatementReadOnly, 
//            DatabaseError

class PlsqlIbtBinder extends Binder
{

    Binder thePlsqlIbtCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    PlsqlIbtBinder()
    {
        thePlsqlIbtCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtCopyingBinder;
        init(this);
    }

    static void init(Binder binder)
    {
        binder.type = 998;
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
        throws SQLException
    {
        PlsqlIbtBindInfo plsqlibtbindinfo = oraclepreparedstatement.parameterPlsqlIbt[k][i];
        if(flag)
            oraclepreparedstatement.parameterPlsqlIbt[k][i] = null;
        int j2 = plsqlibtbindinfo.ibtValueIndex;
label0:
        switch(plsqlibtbindinfo.element_internal_type)
        {
        case 9: // '\t'
            for(int k2 = 0; k2 < plsqlibtbindinfo.curLen; k2++)
            {
                boolean flag1 = false;
                String s = (String)(String)plsqlibtbindinfo.arrayData[k2];
                if(s != null)
                {
                    int i3 = s.length();
                    if(i3 > plsqlibtbindinfo.elemMaxLen - 1)
                        i3 = plsqlibtbindinfo.elemMaxLen - 1;
                    s.getChars(0, i3, oraclepreparedstatement.ibtBindChars, j2 + 1);
                    oraclepreparedstatement.ibtBindIndicators[plsqlibtbindinfo.ibtIndicatorIndex + k2] = 0;
                    i3 <<= 1;
                    oraclepreparedstatement.ibtBindChars[j2] = (char)i3;
                    oraclepreparedstatement.ibtBindIndicators[plsqlibtbindinfo.ibtLengthIndex + k2] = i3 != 0 ? (short)(i3 + 2) : 3;
                } else
                {
                    oraclepreparedstatement.ibtBindIndicators[plsqlibtbindinfo.ibtIndicatorIndex + k2] = -1;
                }
                j2 += plsqlibtbindinfo.elemMaxLen;
            }

            break;

        case 6: // '\006'
            int l2 = 0;
            do
            {
                if(l2 >= plsqlibtbindinfo.curLen)
                    break label0;
                byte abyte1[] = null;
                if(plsqlibtbindinfo.arrayData[l2] != null)
                    abyte1 = ((Datum)(Datum)plsqlibtbindinfo.arrayData[l2]).getBytes();
                if(abyte1 == null)
                {
                    oraclepreparedstatement.ibtBindIndicators[plsqlibtbindinfo.ibtIndicatorIndex + l2] = -1;
                } else
                {
                    oraclepreparedstatement.ibtBindIndicators[plsqlibtbindinfo.ibtIndicatorIndex + l2] = 0;
                    oraclepreparedstatement.ibtBindIndicators[plsqlibtbindinfo.ibtLengthIndex + l2] = (short)(abyte1.length + 1);
                    oraclepreparedstatement.ibtBindBytes[j2] = (byte)abyte1.length;
                    System.arraycopy(abyte1, 0, oraclepreparedstatement.ibtBindBytes, j2 + 1, abyte1.length);
                }
                j2 += plsqlibtbindinfo.elemMaxLen;
                l2++;
            } while(true);

        default:
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    Binder copyingBinder()
    {
        return thePlsqlIbtCopyingBinder;
    }

}
