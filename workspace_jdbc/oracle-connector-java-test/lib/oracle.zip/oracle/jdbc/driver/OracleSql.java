// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleSql.java

package oracle.jdbc.driver;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleStatement;

// Referenced classes of package oracle.jdbc.driver:
//            ScrollableResultSet, DatabaseError, UpdatableResultSet, DBConversion, 
//            OracleSqlReadOnly

public class OracleSql
{
    static final class ParseMode extends Enum
    {

        public static final ParseMode NORMAL;
        public static final ParseMode SCALAR;
        public static final ParseMode LOCATE_1;
        public static final ParseMode LOCATE_2;
        private static final ParseMode $VALUES[];

        public static ParseMode[] values()
        {
            return (ParseMode[])$VALUES.clone();
        }

        public static ParseMode valueOf(String s)
        {
            return (ParseMode)Enum.valueOf(oracle/jdbc/driver/OracleSql$ParseMode, s);
        }

        static 
        {
            NORMAL = new ParseMode("NORMAL", 0);
            SCALAR = new ParseMode("SCALAR", 1);
            LOCATE_1 = new ParseMode("LOCATE_1", 2);
            LOCATE_2 = new ParseMode("LOCATE_2", 3);
            $VALUES = (new ParseMode[] {
                NORMAL, SCALAR, LOCATE_1, LOCATE_2
            });
        }

        private ParseMode(String s, int j)
        {
            super(s, j);
        }
    }


    static final int UNINITIALIZED = -1;
    static final String EMPTY_LIST[] = new String[0];
    DBConversion conversion;
    String originalSql;
    String parameterSql;
    String utickSql;
    String processedSql;
    String rowidSql;
    String actualSql;
    byte sqlBytes[];
    oracle.jdbc.internal.OracleStatement.SqlKind sqlKind;
    byte sqlKindByte;
    int parameterCount;
    int returningIntoParameterCount;
    boolean currentConvertNcharLiterals;
    boolean currentProcessEscapes;
    boolean includeRowid;
    String parameterList[];
    char currentParameter[];
    int bindParameterCount;
    String bindParameterList[];
    int cachedBindParameterCount;
    String cachedBindParameterList[];
    String cachedParameterSql;
    String cachedUtickSql;
    String cachedProcessedSql;
    String cachedRowidSql;
    String cachedActualSql;
    byte cachedSqlBytes[];
    int selectEndIndex;
    int orderByStartIndex;
    int orderByEndIndex;
    int whereStartIndex;
    int whereEndIndex;
    int forUpdateStartIndex;
    int forUpdateEndIndex;
    int ncharLiteralLocation[];
    int lastNcharLiteralLocation;
    static final String paramPrefix = "rowid";
    int paramSuffix;
    StringBuffer stringBufferForScrollableStatement;
    private static final int cMax = 127;
    private static final int TRANSITION[][];
    private static final int ACTION[][];
    private static final int NO_ACTION = 0;
    private static final int DELETE_ACTION = 1;
    private static final int INSERT_ACTION = 2;
    private static final int MERGE_ACTION = 3;
    private static final int UPDATE_ACTION = 4;
    private static final int PLSQL_ACTION = 5;
    private static final int CALL_ACTION = 6;
    private static final int SELECT_ACTION = 7;
    private static final int ORDER_ACTION = 10;
    private static final int ORDER_BY_ACTION = 11;
    private static final int WHERE_ACTION = 9;
    private static final int FOR_ACTION = 12;
    private static final int FOR_UPDATE_ACTION = 13;
    private static final int OTHER_ACTION = 8;
    private static final int QUESTION_ACTION = 14;
    private static final int PARAMETER_ACTION = 15;
    private static final int END_PARAMETER_ACTION = 16;
    private static final int START_NCHAR_LITERAL_ACTION = 17;
    private static final int END_NCHAR_LITERAL_ACTION = 18;
    private static final int SAVE_DELIMITER_ACTION = 19;
    private static final int LOOK_FOR_DELIMITER_ACTION = 20;
    private static final int ALTER_SESSION_ACTION = 21;
    private static final int RETURNING_ACTION = 22;
    private static final int INTO_ACTION = 23;
    private static final int INITIAL_STATE = 0;
    private static final int RESTART_STATE = 66;
    private static final OracleSqlReadOnly.ODBCAction ODBC_ACTION[][];
    private static final boolean DEBUG_CBI = false;
    int current_argument;
    int i;
    int length;
    char currentChar;
    boolean first;
    String odbc_sql;
    StringBuffer oracle_sql;
    StringBuffer token_buffer;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleSql(DBConversion dbconversion)
    {
        sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED;
        sqlKindByte = -1;
        parameterCount = -1;
        returningIntoParameterCount = -1;
        currentConvertNcharLiterals = true;
        currentProcessEscapes = true;
        includeRowid = false;
        parameterList = EMPTY_LIST;
        currentParameter = null;
        bindParameterCount = -1;
        bindParameterList = null;
        cachedBindParameterCount = -1;
        cachedBindParameterList = null;
        selectEndIndex = -1;
        orderByStartIndex = -1;
        orderByEndIndex = -1;
        whereStartIndex = -1;
        whereEndIndex = -1;
        forUpdateStartIndex = -1;
        forUpdateEndIndex = -1;
        ncharLiteralLocation = new int[513];
        lastNcharLiteralLocation = -1;
        paramSuffix = 0;
        stringBufferForScrollableStatement = null;
        conversion = dbconversion;
    }

    protected void initialize(String s)
        throws SQLException
    {
        if(s == null || s.length() == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            originalSql = s;
            utickSql = null;
            processedSql = null;
            rowidSql = null;
            actualSql = null;
            sqlBytes = null;
            sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED;
            parameterCount = -1;
            parameterList = EMPTY_LIST;
            includeRowid = false;
            parameterSql = originalSql;
            bindParameterCount = -1;
            bindParameterList = null;
            cachedBindParameterCount = -1;
            cachedBindParameterList = null;
            cachedParameterSql = null;
            cachedActualSql = null;
            cachedProcessedSql = null;
            cachedRowidSql = null;
            cachedSqlBytes = null;
            selectEndIndex = -1;
            orderByStartIndex = -1;
            orderByEndIndex = -1;
            whereStartIndex = -1;
            whereEndIndex = -1;
            forUpdateStartIndex = -1;
            forUpdateEndIndex = -1;
            return;
        }
    }

    String getOriginalSql()
    {
        return originalSql;
    }

    boolean setNamedParameters(int j, String as[])
        throws SQLException
    {
        boolean flag = false;
        if(j == 0)
        {
            bindParameterCount = -1;
            flag = bindParameterCount != cachedBindParameterCount;
        } else
        {
            bindParameterCount = j;
            bindParameterList = as;
            flag = bindParameterCount != cachedBindParameterCount;
            if(!flag)
            {
                int k = 0;
                do
                {
                    if(k >= j)
                        break;
                    if(bindParameterList[k] != cachedBindParameterList[k])
                    {
                        flag = true;
                        break;
                    }
                    k++;
                } while(true);
            }
            if(flag)
            {
                if(bindParameterCount != getParameterCount())
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 197);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                char ac[] = originalSql.toCharArray();
                StringBuffer stringbuffer = new StringBuffer();
                int l = 0;
                for(int i1 = 0; i1 < ac.length; i1++)
                    if(ac[i1] != '?')
                    {
                        stringbuffer.append(ac[i1]);
                    } else
                    {
                        stringbuffer.append(bindParameterList[l++]);
                        stringbuffer.append((new StringBuilder()).append("=>").append(nextArgument()).toString());
                    }

                parameterSql = stringbuffer.toString();
                actualSql = null;
                utickSql = null;
                processedSql = null;
                rowidSql = null;
                sqlBytes = null;
            } else
            {
                parameterSql = cachedParameterSql;
                actualSql = cachedActualSql;
                utickSql = cachedUtickSql;
                processedSql = cachedProcessedSql;
                rowidSql = cachedRowidSql;
                sqlBytes = cachedSqlBytes;
            }
        }
        cachedBindParameterList = null;
        cachedParameterSql = null;
        cachedActualSql = null;
        cachedUtickSql = null;
        cachedProcessedSql = null;
        cachedRowidSql = null;
        cachedSqlBytes = null;
        return flag;
    }

    void resetNamedParameters()
    {
        cachedBindParameterCount = bindParameterCount;
        if(bindParameterCount != -1)
        {
            if(cachedBindParameterList == null || cachedBindParameterList == bindParameterList || cachedBindParameterList.length < bindParameterCount)
                cachedBindParameterList = new String[bindParameterCount];
            System.arraycopy(bindParameterList, 0, cachedBindParameterList, 0, bindParameterCount);
            cachedParameterSql = parameterSql;
            cachedActualSql = actualSql;
            cachedUtickSql = utickSql;
            cachedProcessedSql = processedSql;
            cachedRowidSql = rowidSql;
            cachedSqlBytes = sqlBytes;
            bindParameterCount = -1;
            bindParameterList = null;
            parameterSql = originalSql;
            actualSql = null;
            utickSql = null;
            processedSql = null;
            rowidSql = null;
            sqlBytes = null;
        }
    }

    String getSql(boolean flag, boolean flag1)
        throws SQLException
    {
        if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED)
            computeBasicInfo(parameterSql);
        if(flag != currentProcessEscapes || flag1 != currentConvertNcharLiterals)
        {
            if(flag1 != currentConvertNcharLiterals)
                utickSql = null;
            processedSql = null;
            rowidSql = null;
            actualSql = null;
            sqlBytes = null;
        }
        currentConvertNcharLiterals = flag1;
        currentProcessEscapes = flag;
        if(actualSql == null)
        {
            if(utickSql == null)
                utickSql = currentConvertNcharLiterals ? convertNcharLiterals(parameterSql) : parameterSql;
            if(processedSql == null)
                processedSql = currentProcessEscapes ? parse(utickSql) : utickSql;
            if(rowidSql == null)
                rowidSql = includeRowid ? addRowid(processedSql) : processedSql;
            actualSql = rowidSql;
        }
        return actualSql;
    }

    String getRevisedSql()
        throws SQLException
    {
        String s = null;
        if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED)
            computeBasicInfo(parameterSql);
        s = removeForUpdate(parameterSql);
        return addRowid(s);
    }

    String removeForUpdate(String s)
        throws SQLException
    {
        if(orderByStartIndex != -1 && (forUpdateStartIndex == -1 || forUpdateStartIndex > orderByStartIndex))
            s = s.substring(0, orderByStartIndex);
        else
        if(forUpdateStartIndex != -1)
            s = s.substring(0, forUpdateStartIndex);
        return s;
    }

    void appendForUpdate(StringBuffer stringbuffer)
        throws SQLException
    {
        if(orderByStartIndex != -1 && (forUpdateStartIndex == -1 || forUpdateStartIndex > orderByStartIndex))
            stringbuffer.append(originalSql.substring(orderByStartIndex));
        else
        if(forUpdateStartIndex != -1)
            stringbuffer.append(originalSql.substring(forUpdateStartIndex));
    }

    String getInsertSqlForUpdatableResultSet(UpdatableResultSet updatableresultset)
        throws SQLException
    {
        String s = getOriginalSql();
        boolean flag = generatedSqlNeedEscapeProcessing();
        if(stringBufferForScrollableStatement == null)
            stringBufferForScrollableStatement = new StringBuffer(s.length() + 100);
        else
            stringBufferForScrollableStatement.delete(0, stringBufferForScrollableStatement.length());
        stringBufferForScrollableStatement.append("insert into (");
        stringBufferForScrollableStatement.append(removeForUpdate(s));
        stringBufferForScrollableStatement.append(") values ( ");
        for(int j = 1; j < updatableresultset.getColumnCount(); j++)
        {
            if(j != 1)
                stringBufferForScrollableStatement.append(", ");
            if(flag)
                stringBufferForScrollableStatement.append("?");
            else
                stringBufferForScrollableStatement.append((new StringBuilder()).append(":").append(generateParameterName()).toString());
        }

        stringBufferForScrollableStatement.append(")");
        paramSuffix = 0;
        return stringBufferForScrollableStatement.substring(0, stringBufferForScrollableStatement.length());
    }

    String getRefetchSqlForScrollableResultSet(ScrollableResultSet scrollableresultset, int j)
        throws SQLException
    {
        String s = getRevisedSql();
        boolean flag = generatedSqlNeedEscapeProcessing();
        if(stringBufferForScrollableStatement == null)
            stringBufferForScrollableStatement = new StringBuffer(s.length() + 100);
        else
            stringBufferForScrollableStatement.delete(0, stringBufferForScrollableStatement.length());
        stringBufferForScrollableStatement.append(s);
        if(whereStartIndex == -1)
            stringBufferForScrollableStatement.append(flag ? " WHERE ( ROWID = ?" : (new StringBuilder()).append(" WHERE ( ROWID = :").append(generateParameterName()).toString());
        else
            stringBufferForScrollableStatement.append(flag ? " AND ( ROWID = ?" : (new StringBuilder()).append(" AND ( ROWID = :").append(generateParameterName()).toString());
        for(int k = 0; k < j - 1; k++)
            if(flag)
                stringBufferForScrollableStatement.append(" OR ROWID = ?");
            else
                stringBufferForScrollableStatement.append((new StringBuilder()).append(" OR ROWID = :").append(generateParameterName()).toString());

        stringBufferForScrollableStatement.append(" ) ");
        appendForUpdate(stringBufferForScrollableStatement);
        paramSuffix = 0;
        return stringBufferForScrollableStatement.substring(0, stringBufferForScrollableStatement.length());
    }

    String getUpdateSqlForUpdatableResultSet(UpdatableResultSet updatableresultset, int j, Object aobj[], int ai[])
        throws SQLException
    {
        String s = getRevisedSql();
        boolean flag = generatedSqlNeedEscapeProcessing();
        if(stringBufferForScrollableStatement == null)
            stringBufferForScrollableStatement = new StringBuffer(s.length() + 100);
        else
            stringBufferForScrollableStatement.delete(0, stringBufferForScrollableStatement.length());
        stringBufferForScrollableStatement.append("update (");
        stringBufferForScrollableStatement.append(s);
        stringBufferForScrollableStatement.append(") set ");
        if(aobj != null)
        {
            for(int k = 0; k < j; k++)
            {
                if(k > 0)
                    stringBufferForScrollableStatement.append(", ");
                stringBufferForScrollableStatement.append(updatableresultset.getInternalMetadata().getColumnName(ai[k] + 1));
                if(flag)
                    stringBufferForScrollableStatement.append(" = ?");
                else
                    stringBufferForScrollableStatement.append((new StringBuilder()).append(" = :").append(generateParameterName()).toString());
            }

        }
        stringBufferForScrollableStatement.append(" WHERE ");
        if(flag)
            stringBufferForScrollableStatement.append(" ROWID = ?");
        else
            stringBufferForScrollableStatement.append((new StringBuilder()).append(" ROWID = :").append(generateParameterName()).toString());
        paramSuffix = 0;
        return stringBufferForScrollableStatement.substring(0, stringBufferForScrollableStatement.length());
    }

    String getDeleteSqlForUpdatableResultSet(UpdatableResultSet updatableresultset)
        throws SQLException
    {
        String s = getRevisedSql();
        boolean flag = generatedSqlNeedEscapeProcessing();
        if(stringBufferForScrollableStatement == null)
            stringBufferForScrollableStatement = new StringBuffer(s.length() + 100);
        else
            stringBufferForScrollableStatement.delete(0, stringBufferForScrollableStatement.length());
        stringBufferForScrollableStatement.append("delete from (");
        stringBufferForScrollableStatement.append(s);
        stringBufferForScrollableStatement.append(") where ");
        if(flag)
            stringBufferForScrollableStatement.append(" ROWID = ?");
        else
            stringBufferForScrollableStatement.append((new StringBuilder()).append(" ROWID = :").append(generateParameterName()).toString());
        paramSuffix = 0;
        return stringBufferForScrollableStatement.substring(0, stringBufferForScrollableStatement.length());
    }

    final boolean generatedSqlNeedEscapeProcessing()
    {
        return parameterCount > 0 && parameterList == EMPTY_LIST;
    }

    byte[] getSqlBytes(boolean flag, boolean flag1)
        throws SQLException
    {
        if(sqlBytes == null || flag != currentProcessEscapes)
            sqlBytes = conversion.StringToCharBytes(getSql(flag, flag1));
        return sqlBytes;
    }

    oracle.jdbc.internal.OracleStatement.SqlKind getSqlKind()
        throws SQLException
    {
        if(parameterSql == null)
            return oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED;
        if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED)
            computeBasicInfo(parameterSql);
        return sqlKind;
    }

    protected int getParameterCount()
        throws SQLException
    {
        if(parameterCount == -1)
            computeBasicInfo(parameterSql);
        return parameterCount;
    }

    protected String[] getParameterList()
        throws SQLException
    {
        if(parameterCount == -1)
            computeBasicInfo(parameterSql);
        return parameterList;
    }

    void setIncludeRowid(boolean flag)
    {
        if(flag != includeRowid)
        {
            includeRowid = flag;
            rowidSql = null;
            actualSql = null;
            sqlBytes = null;
        }
    }

    public String toString()
    {
        return parameterSql != null ? parameterSql : "null";
    }

    private String hexUnicode(int j)
        throws SQLException
    {
        String s = Integer.toHexString(j);
        switch(s.length())
        {
        case 0: // '\0'
            return "\\0000";

        case 1: // '\001'
            return (new StringBuilder()).append("\\000").append(s).toString();

        case 2: // '\002'
            return (new StringBuilder()).append("\\00").append(s).toString();

        case 3: // '\003'
            return (new StringBuilder()).append("\\0").append(s).toString();

        case 4: // '\004'
            return (new StringBuilder()).append("\\").append(s).toString();
        }
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, (new StringBuilder()).append("Unexpected case in OracleSql.hexUnicode: ").append(j).toString());
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    String convertNcharLiterals(String s)
        throws SQLException
    {
        if(lastNcharLiteralLocation <= 2)
            return s;
        String s1 = "";
        int j = 0;
        do
        {
            int k = ncharLiteralLocation[j++];
            int i1 = ncharLiteralLocation[j++];
            s1 = (new StringBuilder()).append(s1).append(s.substring(k, i1)).toString();
            if(j < lastNcharLiteralLocation)
            {
                int l = ncharLiteralLocation[j];
                s1 = (new StringBuilder()).append(s1).append("u'").toString();
                int j1 = i1 + 2;
                while(j1 < l) 
                {
                    char c = s.charAt(j1);
                    if(c == '\\')
                        s1 = (new StringBuilder()).append(s1).append("\\\\").toString();
                    else
                    if(c < '\200')
                        s1 = (new StringBuilder()).append(s1).append(c).toString();
                    else
                        s1 = (new StringBuilder()).append(s1).append(hexUnicode(c)).toString();
                    j1++;
                }
            } else
            {
                return s1;
            }
        } while(true);
    }

    void computeBasicInfo(String s)
        throws SQLException
    {
        parameterCount = 0;
        boolean flag = false;
        boolean flag1 = false;
        returningIntoParameterCount = 0;
        lastNcharLiteralLocation = 0;
        ncharLiteralLocation[lastNcharLiteralLocation++] = 0;
        char c = '\0';
        int j = 0;
        int k = 0;
        int l = s.length();
        int i1 = -1;
        int j1 = -1;
        int k1 = l + 1;
        for(int l1 = 0; l1 < k1; l1++)
        {
            char c1 = l1 >= l ? ' ' : s.charAt(l1);
            currentChar = c1;
            if(c1 > '\177')
                if(Character.isLetterOrDigit(c1))
                    currentChar = 'X';
                else
                    currentChar = ' ';
            switch(ACTION[k][currentChar])
            {
            case 0: // '\0'
            default:
                break;

            case 1: // '\001'
                sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.DELETE;
                break;

            case 2: // '\002'
                sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.INSERT;
                break;

            case 3: // '\003'
                sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.MERGE;
                break;

            case 4: // '\004'
                sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.UPDATE;
                break;

            case 5: // '\005'
                sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.PLSQL_BLOCK;
                break;

            case 6: // '\006'
                sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.CALL_BLOCK;
                break;

            case 7: // '\007'
                sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.SELECT;
                selectEndIndex = l1;
                break;

            case 8: // '\b'
                sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.OTHER;
                break;

            case 9: // '\t'
                whereStartIndex = l1 - 5;
                whereEndIndex = l1;
                break;

            case 10: // '\n'
                i1 = l1 - 5;
                break;

            case 11: // '\013'
                orderByStartIndex = i1;
                orderByEndIndex = l1;
                break;

            case 12: // '\f'
                j1 = l1 - 3;
                break;

            case 13: // '\r'
                forUpdateStartIndex = j1;
                forUpdateEndIndex = l1;
                if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.SELECT)
                    sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.SELECT_FOR_UPDATE;
                break;

            case 21: // '\025'
                sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.ALTER_SESSION;
                break;

            case 14: // '\016'
                parameterCount++;
                if(flag1)
                    returningIntoParameterCount++;
                break;

            case 15: // '\017'
                if(currentParameter == null)
                    currentParameter = new char[32];
                if(j >= currentParameter.length)
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 134, new String(currentParameter));
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                currentParameter[j++] = c1;
                break;

            case 16: // '\020'
                if(j <= 0)
                    break;
                if(parameterList == EMPTY_LIST)
                    parameterList = new String[Math.max(8, parameterCount * 4)];
                else
                if(parameterList.length <= parameterCount)
                {
                    String as[] = new String[parameterList.length * 4];
                    System.arraycopy(parameterList, 0, as, 0, parameterList.length);
                    parameterList = as;
                }
                parameterList[parameterCount] = (new String(currentParameter, 0, j)).intern();
                j = 0;
                parameterCount++;
                if(flag1)
                    returningIntoParameterCount++;
                break;

            case 17: // '\021'
                ncharLiteralLocation[lastNcharLiteralLocation++] = l1 - 1;
                if(lastNcharLiteralLocation >= ncharLiteralLocation.length)
                    growNcharLiteralLocation(ncharLiteralLocation.length << 2);
                break;

            case 18: // '\022'
                ncharLiteralLocation[lastNcharLiteralLocation++] = l1;
                if(lastNcharLiteralLocation >= ncharLiteralLocation.length)
                    growNcharLiteralLocation(ncharLiteralLocation.length << 2);
                break;

            case 19: // '\023'
                if(c1 == '[')
                {
                    c = ']';
                    break;
                }
                if(c1 == '{')
                {
                    c = '}';
                    break;
                }
                if(c1 == '<')
                {
                    c = '>';
                    break;
                }
                if(c1 == '(')
                    c = ')';
                else
                    c = c1;
                break;

            case 20: // '\024'
                if(c1 == c)
                    k++;
                break;

            case 22: // '\026'
                flag = true;
                break;

            case 23: // '\027'
                if(flag)
                    flag1 = true;
                break;
            }
            k = TRANSITION[k][currentChar];
        }

        if(lastNcharLiteralLocation + 2 >= ncharLiteralLocation.length)
            growNcharLiteralLocation(lastNcharLiteralLocation + 2);
        ncharLiteralLocation[lastNcharLiteralLocation++] = l;
        ncharLiteralLocation[lastNcharLiteralLocation] = l;
    }

    void growNcharLiteralLocation(int j)
    {
        int ai[] = new int[j];
        System.arraycopy(ncharLiteralLocation, 0, ai, 0, ncharLiteralLocation.length);
        ncharLiteralLocation = null;
        ncharLiteralLocation = ai;
    }

    private String addRowid(String s)
        throws SQLException
    {
        if(selectEndIndex == -1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 88);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            String s1 = (new StringBuilder()).append("select rowid as \"__Oracle_JDBC_interal_ROWID__\",").append(s.substring(selectEndIndex)).toString();
            return s1;
        }
    }

    String parse(String s)
        throws SQLException
    {
        first = true;
        current_argument = 1;
        i = 0;
        odbc_sql = s;
        length = odbc_sql.length();
        if(oracle_sql == null)
        {
            oracle_sql = new StringBuffer(length);
            token_buffer = new StringBuffer(32);
        } else
        {
            oracle_sql.ensureCapacity(length);
        }
        oracle_sql.delete(0, oracle_sql.length());
        skipSpace();
        handleODBC(ParseMode.NORMAL);
        if(i < length)
        {
            Integer integer = Integer.valueOf(i);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, integer);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return oracle_sql.substring(0, oracle_sql.length());
        }
    }

    void handleODBC(ParseMode parsemode)
        throws SQLException
    {
        int j = parsemode != ParseMode.NORMAL ? 66 : 0;
        char c = '\0';
        int k = 0;
        for(; i < length; i++)
        {
            char c1 = i >= length ? ' ' : odbc_sql.charAt(i);
            currentChar = c1;
            if(c1 > '\177')
                if(Character.isLetterOrDigit(c1))
                    currentChar = 'X';
                else
                    currentChar = ' ';
            static class _cls1
            {

                static final int $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[];

                static 
                {
                    $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction = new int[OracleSqlReadOnly.ODBCAction.values().length];
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.NONE.ordinal()] = 1;
                    }
                    catch(NoSuchFieldError nosuchfielderror) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.COPY.ordinal()] = 2;
                    }
                    catch(NoSuchFieldError nosuchfielderror1) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.QUESTION.ordinal()] = 3;
                    }
                    catch(NoSuchFieldError nosuchfielderror2) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.SAVE_DELIMITER.ordinal()] = 4;
                    }
                    catch(NoSuchFieldError nosuchfielderror3) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.LOOK_FOR_DELIMITER.ordinal()] = 5;
                    }
                    catch(NoSuchFieldError nosuchfielderror4) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.FUNCTION.ordinal()] = 6;
                    }
                    catch(NoSuchFieldError nosuchfielderror5) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.CALL.ordinal()] = 7;
                    }
                    catch(NoSuchFieldError nosuchfielderror6) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.TIME.ordinal()] = 8;
                    }
                    catch(NoSuchFieldError nosuchfielderror7) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.TIMESTAMP.ordinal()] = 9;
                    }
                    catch(NoSuchFieldError nosuchfielderror8) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.DATE.ordinal()] = 10;
                    }
                    catch(NoSuchFieldError nosuchfielderror9) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.ESCAPE.ordinal()] = 11;
                    }
                    catch(NoSuchFieldError nosuchfielderror10) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.SCALAR_FUNCTION.ordinal()] = 12;
                    }
                    catch(NoSuchFieldError nosuchfielderror11) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.OUTER_JOIN.ordinal()] = 13;
                    }
                    catch(NoSuchFieldError nosuchfielderror12) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.UNKNOWN_ESCAPE.ordinal()] = 14;
                    }
                    catch(NoSuchFieldError nosuchfielderror13) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.END_ODBC_ESCAPE.ordinal()] = 15;
                    }
                    catch(NoSuchFieldError nosuchfielderror14) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.COMMA.ordinal()] = 16;
                    }
                    catch(NoSuchFieldError nosuchfielderror15) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.OPEN_PAREN.ordinal()] = 17;
                    }
                    catch(NoSuchFieldError nosuchfielderror16) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.CLOSE_PAREN.ordinal()] = 18;
                    }
                    catch(NoSuchFieldError nosuchfielderror17) { }
                    try
                    {
                        $SwitchMap$oracle$jdbc$driver$OracleSqlReadOnly$ODBCAction[OracleSqlReadOnly.ODBCAction.BEGIN.ordinal()] = 19;
                    }
                    catch(NoSuchFieldError nosuchfielderror18) { }
                }
            }

            switch(_cls1..SwitchMap.oracle.jdbc.driver.OracleSqlReadOnly.ODBCAction[ODBC_ACTION[j][currentChar].ordinal()])
            {
            case 1: // '\001'
            default:
                break;

            case 2: // '\002'
                oracle_sql.append(c1);
                break;

            case 3: // '\003'
                oracle_sql.append(nextArgument());
                oracle_sql.append(' ');
                break;

            case 4: // '\004'
                if(c1 == '[')
                    c = ']';
                else
                if(c1 == '{')
                    c = '}';
                else
                if(c1 == '<')
                    c = '>';
                else
                if(c1 == '(')
                    c = ')';
                else
                    c = c1;
                oracle_sql.append(c1);
                break;

            case 5: // '\005'
                if(c1 == c)
                    j++;
                oracle_sql.append(c1);
                break;

            case 6: // '\006'
                handleFunction();
                break;

            case 7: // '\007'
                handleCall();
                break;

            case 8: // '\b'
                handleTime();
                break;

            case 9: // '\t'
                handleTimestamp();
                break;

            case 10: // '\n'
                handleDate();
                break;

            case 11: // '\013'
                handleEscape();
                break;

            case 12: // '\f'
                handleScalarFunction();
                break;

            case 13: // '\r'
                handleOuterJoin();
                break;

            case 14: // '\016'
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, Integer.valueOf(i));
                sqlexception.fillInStackTrace();
                throw sqlexception;

            case 15: // '\017'
                if(parsemode == ParseMode.SCALAR)
                {
                    j = TRANSITION[j][currentChar];
                    return;
                }
                // fall through

            case 16: // '\020'
                if(parsemode == ParseMode.LOCATE_1 && k > 1)
                {
                    oracle_sql.append(c1);
                    break;
                }
                if(parsemode == ParseMode.LOCATE_1)
                {
                    j = TRANSITION[j][currentChar];
                    return;
                }
                if(parsemode != ParseMode.LOCATE_2)
                    oracle_sql.append(c1);
                break;

            case 17: // '\021'
                if(parsemode == ParseMode.LOCATE_1)
                {
                    if(k > 0)
                        oracle_sql.append(c1);
                    k++;
                    break;
                }
                if(parsemode == ParseMode.LOCATE_2)
                {
                    k++;
                    oracle_sql.append(c1);
                } else
                {
                    oracle_sql.append(c1);
                }
                break;

            case 18: // '\022'
                if(parsemode == ParseMode.LOCATE_1)
                {
                    k--;
                    oracle_sql.append(c1);
                    break;
                }
                if(parsemode == ParseMode.LOCATE_2 && k > 1)
                {
                    k--;
                    oracle_sql.append(c1);
                    break;
                }
                if(parsemode == ParseMode.LOCATE_2)
                {
                    i++;
                    j = TRANSITION[j][currentChar];
                    return;
                }
                oracle_sql.append(c1);
                break;

            case 19: // '\023'
                first = false;
                oracle_sql.append(c1);
                break;
            }
            j = TRANSITION[j][currentChar];
        }

    }

    void handleFunction()
        throws SQLException
    {
        boolean flag = first;
        first = false;
        if(flag)
            oracle_sql.append("BEGIN ");
        appendChar(oracle_sql, '?');
        skipSpace();
        if(currentChar != '=')
        {
            String s = (new StringBuilder()).append(i).append(". Expecting \"=\" got \"").append(currentChar).append("\"").toString();
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, s);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        i++;
        skipSpace();
        if(!odbc_sql.startsWith("call", i))
        {
            String s1 = (new StringBuilder()).append(i).append(". Expecting \"call\"").toString();
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, s1);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        i += 4;
        oracle_sql.append(" := ");
        skipSpace();
        handleODBC(ParseMode.SCALAR);
        if(flag)
            oracle_sql.append("; END;");
    }

    void handleCall()
        throws SQLException
    {
        boolean flag = first;
        first = false;
        if(flag)
            oracle_sql.append("BEGIN ");
        skipSpace();
        handleODBC(ParseMode.SCALAR);
        skipSpace();
        if(flag)
            oracle_sql.append("; END;");
    }

    void handleTimestamp()
        throws SQLException
    {
        oracle_sql.append("TO_TIMESTAMP (");
        skipSpace();
        handleODBC(ParseMode.SCALAR);
        oracle_sql.append(", 'YYYY-MM-DD HH24:MI:SS.FF')");
    }

    void handleTime()
        throws SQLException
    {
        oracle_sql.append("TO_DATE (");
        skipSpace();
        handleODBC(ParseMode.SCALAR);
        oracle_sql.append(", 'HH24:MI:SS')");
    }

    void handleDate()
        throws SQLException
    {
        oracle_sql.append("TO_DATE (");
        skipSpace();
        handleODBC(ParseMode.SCALAR);
        oracle_sql.append(", 'YYYY-MM-DD')");
    }

    void handleEscape()
        throws SQLException
    {
        oracle_sql.append("ESCAPE ");
        skipSpace();
        handleODBC(ParseMode.SCALAR);
    }

    void handleScalarFunction()
        throws SQLException
    {
        token_buffer.delete(0, token_buffer.length());
        i++;
        skipSpace();
        for(; i < length && (Character.isJavaLetterOrDigit(currentChar = odbc_sql.charAt(i)) || currentChar == '?'); i++)
            token_buffer.append(currentChar);

        String s = token_buffer.substring(0, token_buffer.length()).toUpperCase().intern();
        if(s == "ABS")
            usingFunctionName(s);
        else
        if(s == "ACOS")
            usingFunctionName(s);
        else
        if(s == "ASIN")
            usingFunctionName(s);
        else
        if(s == "ATAN")
            usingFunctionName(s);
        else
        if(s == "ATAN2")
            usingFunctionName(s);
        else
        if(s == "CEILING")
            usingFunctionName("CEIL");
        else
        if(s == "COS")
        {
            usingFunctionName(s);
        } else
        {
            if(s == "COT")
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(s == "DEGREES")
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            if(s == "EXP")
                usingFunctionName(s);
            else
            if(s == "FLOOR")
                usingFunctionName(s);
            else
            if(s == "LOG")
                usingFunctionName("LN");
            else
            if(s == "LOG10")
                replacingFunctionPrefix("LOG ( 10, ");
            else
            if(s == "MOD")
                usingFunctionName(s);
            else
            if(s == "PI")
                replacingFunctionPrefix("( 3.141592653589793238462643383279502884197169399375 ");
            else
            if(s == "POWER")
            {
                usingFunctionName(s);
            } else
            {
                if(s == "RADIANS")
                {
                    SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                    sqlexception2.fillInStackTrace();
                    throw sqlexception2;
                }
                if(s == "RAND")
                {
                    SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                    sqlexception3.fillInStackTrace();
                    throw sqlexception3;
                }
                if(s == "ROUND")
                    usingFunctionName(s);
                else
                if(s == "SIGN")
                    usingFunctionName(s);
                else
                if(s == "SIN")
                    usingFunctionName(s);
                else
                if(s == "SQRT")
                    usingFunctionName(s);
                else
                if(s == "TAN")
                    usingFunctionName(s);
                else
                if(s == "TRUNCATE")
                    usingFunctionName("TRUNC");
                else
                if(s == "ASCII")
                    usingFunctionName(s);
                else
                if(s == "CHAR")
                    usingFunctionName("CHR");
                else
                if(s == "CHAR_LENGTH")
                    usingFunctionName("LENGTH");
                else
                if(s == "CHARACTER_LENGTH")
                    usingFunctionName("LENGTH");
                else
                if(s == "CONCAT")
                {
                    usingFunctionName(s);
                } else
                {
                    if(s == "DIFFERENCE")
                    {
                        SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                        sqlexception4.fillInStackTrace();
                        throw sqlexception4;
                    }
                    if(s == "INSERT")
                    {
                        SQLException sqlexception5 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                        sqlexception5.fillInStackTrace();
                        throw sqlexception5;
                    }
                    if(s == "LCASE")
                    {
                        usingFunctionName("LOWER");
                    } else
                    {
                        if(s == "LEFT")
                        {
                            SQLException sqlexception6 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                            sqlexception6.fillInStackTrace();
                            throw sqlexception6;
                        }
                        if(s == "LENGTH")
                            usingFunctionName(s);
                        else
                        if(s == "LOCATE")
                        {
                            StringBuffer stringbuffer = oracle_sql;
                            oracle_sql = new StringBuffer();
                            handleODBC(ParseMode.LOCATE_1);
                            StringBuffer stringbuffer1 = oracle_sql;
                            oracle_sql = stringbuffer;
                            oracle_sql.append("INSTR(");
                            handleODBC(ParseMode.LOCATE_2);
                            oracle_sql.append(',');
                            oracle_sql.append(stringbuffer1);
                            oracle_sql.append(')');
                            handleODBC(ParseMode.SCALAR);
                        } else
                        if(s == "LTRIM")
                            usingFunctionName(s);
                        else
                        if(s == "OCTET_LENGTH")
                        {
                            usingFunctionName("LENGTHB");
                        } else
                        {
                            if(s == "POSITION")
                            {
                                SQLException sqlexception7 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                sqlexception7.fillInStackTrace();
                                throw sqlexception7;
                            }
                            if(s == "REPEAT")
                            {
                                SQLException sqlexception8 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                sqlexception8.fillInStackTrace();
                                throw sqlexception8;
                            }
                            if(s == "REPLACE")
                            {
                                usingFunctionName(s);
                            } else
                            {
                                if(s == "RIGHT")
                                {
                                    SQLException sqlexception9 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                    sqlexception9.fillInStackTrace();
                                    throw sqlexception9;
                                }
                                if(s == "RTRIM")
                                    usingFunctionName(s);
                                else
                                if(s == "SOUNDEX")
                                {
                                    usingFunctionName(s);
                                } else
                                {
                                    if(s == "SPACE")
                                    {
                                        SQLException sqlexception10 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                        sqlexception10.fillInStackTrace();
                                        throw sqlexception10;
                                    }
                                    if(s == "SUBSTRING")
                                        usingFunctionName("SUBSTR");
                                    else
                                    if(s == "UCASE")
                                        usingFunctionName("UPPER");
                                    else
                                    if(s == "CURRENT_DATE")
                                    {
                                        replacingFunctionPrefix("(CURRENT_DATE");
                                    } else
                                    {
                                        if(s == "CURRENT_TIME")
                                        {
                                            SQLException sqlexception11 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                            sqlexception11.fillInStackTrace();
                                            throw sqlexception11;
                                        }
                                        if(s == "CURRENT_TIMESTAMP")
                                            replacingFunctionPrefix("(CURRENT_TIMESTAMP");
                                        else
                                        if(s == "CURDATE")
                                            replacingFunctionPrefix("(CURRENT_DATE");
                                        else
                                        if(s == "CURTIME")
                                        {
                                            replacingFunctionPrefix("(CURRENT_TIMESTAMP");
                                        } else
                                        {
                                            if(s == "DAYNAME")
                                            {
                                                SQLException sqlexception12 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                                sqlexception12.fillInStackTrace();
                                                throw sqlexception12;
                                            }
                                            if(s == "DAYOFMONTH")
                                            {
                                                replacingFunctionPrefix("EXTRACT ( DAY FROM ");
                                            } else
                                            {
                                                if(s == "DAYOFWEEK")
                                                {
                                                    SQLException sqlexception13 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                                    sqlexception13.fillInStackTrace();
                                                    throw sqlexception13;
                                                }
                                                if(s == "DAYOFYEAR")
                                                {
                                                    SQLException sqlexception14 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                                    sqlexception14.fillInStackTrace();
                                                    throw sqlexception14;
                                                }
                                                if(s == "EXTRACT")
                                                    usingFunctionName("EXTRACT");
                                                else
                                                if(s == "HOUR")
                                                    replacingFunctionPrefix("EXTRACT ( HOUR FROM ");
                                                else
                                                if(s == "MINUTE")
                                                    replacingFunctionPrefix("EXTRACT ( MINUTE FROM ");
                                                else
                                                if(s == "MONTH")
                                                {
                                                    replacingFunctionPrefix("EXTRACT ( MONTH FROM ");
                                                } else
                                                {
                                                    if(s == "MONTHNAME")
                                                    {
                                                        SQLException sqlexception15 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                                        sqlexception15.fillInStackTrace();
                                                        throw sqlexception15;
                                                    }
                                                    if(s == "NOW")
                                                    {
                                                        replacingFunctionPrefix("(CURRENT_TIMESTAMP");
                                                    } else
                                                    {
                                                        if(s == "QUARTER")
                                                        {
                                                            SQLException sqlexception16 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                                            sqlexception16.fillInStackTrace();
                                                            throw sqlexception16;
                                                        }
                                                        if(s == "SECOND")
                                                        {
                                                            replacingFunctionPrefix("EXTRACT ( SECOND FROM ");
                                                        } else
                                                        {
                                                            if(s == "TIMESTAMPADD")
                                                            {
                                                                SQLException sqlexception17 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                                                sqlexception17.fillInStackTrace();
                                                                throw sqlexception17;
                                                            }
                                                            if(s == "TIMESTAMPDIFF")
                                                            {
                                                                SQLException sqlexception18 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                                                sqlexception18.fillInStackTrace();
                                                                throw sqlexception18;
                                                            }
                                                            if(s == "WEEK")
                                                            {
                                                                SQLException sqlexception19 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                                                sqlexception19.fillInStackTrace();
                                                                throw sqlexception19;
                                                            }
                                                            if(s == "YEAR")
                                                            {
                                                                replacingFunctionPrefix("EXTRACT ( YEAR FROM ");
                                                            } else
                                                            {
                                                                if(s == "DATABASE")
                                                                {
                                                                    SQLException sqlexception20 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                                                    sqlexception20.fillInStackTrace();
                                                                    throw sqlexception20;
                                                                }
                                                                if(s == "IFNULL")
                                                                    usingFunctionName("NVL");
                                                                else
                                                                if(s == "USER")
                                                                    replacingFunctionPrefix("(USER");
                                                                else
                                                                if(s == "CONVERT")
                                                                {
                                                                    SQLException sqlexception21 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                                                    sqlexception21.fillInStackTrace();
                                                                    throw sqlexception21;
                                                                } else
                                                                {
                                                                    SQLException sqlexception22 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, s);
                                                                    sqlexception22.fillInStackTrace();
                                                                    throw sqlexception22;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    void usingFunctionName(String s)
        throws SQLException
    {
        oracle_sql.append(s);
        skipSpace();
        handleODBC(ParseMode.SCALAR);
    }

    void replacingFunctionPrefix(String s)
        throws SQLException
    {
        skipSpace();
        if(i < length && (currentChar = odbc_sql.charAt(i)) == '(')
        {
            i++;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        oracle_sql.append(s);
        skipSpace();
        handleODBC(ParseMode.SCALAR);
    }

    void handleOuterJoin()
        throws SQLException
    {
        oracle_sql.append(" ( ");
        skipSpace();
        handleODBC(ParseMode.SCALAR);
        oracle_sql.append(" ) ");
    }

    String nextArgument()
    {
        String s = (new StringBuilder()).append(":").append(current_argument).toString();
        current_argument++;
        return s;
    }

    void appendChar(StringBuffer stringbuffer, char c)
    {
        if(c == '?')
            stringbuffer.append(nextArgument());
        else
            stringbuffer.append(c);
    }

    void skipSpace()
    {
        for(; i < length && (currentChar = odbc_sql.charAt(i)) == ' '; i++);
    }

    String generateParameterName()
    {
        String s;
        if(parameterCount == 0 || parameterList == null)
            return (new StringBuilder()).append("rowid").append(paramSuffix++).toString();
        do
        {
            s = (new StringBuilder()).append("rowid").append(paramSuffix++).toString();
            int j = 0;
label0:
            do
            {
label1:
                {
                    if(j >= parameterList.length)
                        break label1;
                    if(s.equals(parameterList[j]))
                        break label0;
                    j++;
                }
            } while(true);
        } while(true);
        return s;
    }

    static boolean isValidPlsqlWarning(String s)
        throws SQLException
    {
        return s.matches("('\\s*([a-zA-Z0-9:,\\(\\)\\s])*')\\s*(,\\s*'([a-zA-Z0-9:,\\(\\)\\s])*')*");
    }

    public static boolean isValidObjectName(String s)
        throws SQLException
    {
        if(s.matches("([a-zA-Z]{1}\\w*(\\$|\\#)*\\w*)|(\".*)"))
            return true;
        char ac[] = s.toCharArray();
        int j = ac.length;
        if(!Character.isLetter(ac[0]))
            return false;
        for(int k = 1; k < j; k++)
            if(!Character.isLetterOrDigit(ac[k]) && ac[k] != '$' && ac[k] != '#' && ac[k] != '_')
                return false;

        return true;
    }

    public static void main(String args[])
    {
        if(args.length < 2)
        {
            System.err.println("ERROR: incorrect usage. OracleSql (-transition <file> | <process_escapes> <convert_nchars> { <sql> } )");
            return;
        }
        if(args[0].equals("-dump"))
        {
            dumpTransitionMatrix(args[1]);
            return;
        }
        boolean flag = args[0].equals("true");
        boolean flag1 = args[1].equals("true");
        String args1[];
        if(args.length > 2)
        {
            args1 = new String[args.length - 2];
            System.arraycopy(args, 2, args1, 0, args1.length);
        } else
        {
            args1 = (new String[] {
                "select ? from dual", "insert into dual values (?)", "delete from dual", "update dual set dummy = ?", "merge tab into dual", " select ? from dual where ? = ?", "select ?from dual where?=?for update", "select '?', n'?', q'???', q'{?}', q'{cat's}' from dual", "select'?',n'?',q'???',q'{?}',q'{cat's}'from dual", "select--line\n? from dual", 
                "select --line\n? from dual", "--line\nselect ? from dual", " --line\nselect ? from dual", "--line\n select ? from dual", "begin proc4in4out (:x1, :x2, :x3, :x4); end;", "{CALL tkpjpn01(:pin, :pinout, :pout)}", "select :NumberBindVar as the_number from dual", "select {fn locate(bob(carol(),ted(alice,sue)), 'xfy')} from dual", "CREATE USER vijay6 IDENTIFIED BY \"vjay?\"", "ALTER SESSION SET TIME", 
                "SELECT ename FROM emp WHERE hiredate BETWEEN {ts'1980-12-17'} AND {ts '1981-09-28'} "
            });
        }
        String args2[] = args1;
        int j = args2.length;
        for(int k = 0; k < j; k++)
        {
            String s = args2[k];
            try
            {
                System.out.println("\n\n-----------------------");
                System.out.println(s);
                System.out.println();
                OracleSql oraclesql = new OracleSql(null);
                oraclesql.initialize(s);
                String s1 = oraclesql.getSql(flag, flag1);
                System.out.println((new StringBuilder()).append(oraclesql.sqlKind).append(", ").append(oraclesql.parameterCount).toString());
                String args3[] = oraclesql.getParameterList();
                if(args3 == EMPTY_LIST)
                {
                    System.out.println("parameterList is empty");
                } else
                {
                    for(int l = 0; l < args3.length; l++)
                        System.out.println((new StringBuilder()).append("parameterList[").append(l).append("] = ").append(args3[l]).toString());

                }
                if(oraclesql.getSqlKind().isDML())
                {
                    int i1 = oraclesql.getReturnParameterCount();
                    if(i1 == -1)
                        System.out.println("no return parameters");
                    else
                        System.out.println((new StringBuilder()).append(i1).append(" return parameters").toString());
                }
                if(oraclesql.lastNcharLiteralLocation == 2)
                {
                    System.out.println("No NCHAR literals");
                } else
                {
                    System.out.println("NCHAR Literals");
                    for(int j1 = 1; j1 < oraclesql.lastNcharLiteralLocation - 1;)
                        System.out.println(s1.substring(oraclesql.ncharLiteralLocation[j1++], oraclesql.ncharLiteralLocation[j1++]));

                }
                System.out.println("Keywords");
                if(oraclesql.selectEndIndex == -1)
                    System.out.println("no select");
                else
                    System.out.println((new StringBuilder()).append("'").append(s1.substring(oraclesql.selectEndIndex - 6, oraclesql.selectEndIndex)).append("'").toString());
                if(oraclesql.orderByStartIndex == -1)
                    System.out.println("no order by");
                else
                    System.out.println((new StringBuilder()).append("'").append(s1.substring(oraclesql.orderByStartIndex, oraclesql.orderByEndIndex)).append("'").toString());
                if(oraclesql.whereStartIndex == -1)
                    System.out.println("no where");
                else
                    System.out.println((new StringBuilder()).append("'").append(s1.substring(oraclesql.whereStartIndex, oraclesql.whereEndIndex)).append("'").toString());
                if(oraclesql.forUpdateStartIndex == -1)
                    System.out.println("no for update");
                else
                    System.out.println((new StringBuilder()).append("'").append(s1.substring(oraclesql.forUpdateStartIndex, oraclesql.forUpdateEndIndex)).append("'").toString());
                System.out.println((new StringBuilder()).append("isPlsqlOrCall(): ").append(oraclesql.getSqlKind().isPlsqlOrCall()).toString());
                System.out.println((new StringBuilder()).append("isDML(): ").append(oraclesql.getSqlKind().isDML()).toString());
                System.out.println((new StringBuilder()).append("isSELECT(): ").append(oraclesql.getSqlKind().isSELECT()).toString());
                System.out.println((new StringBuilder()).append("isOTHER(): ").append(oraclesql.getSqlKind().isOTHER()).toString());
                System.out.println((new StringBuilder()).append("\"").append(s1).append("\"").toString());
                System.out.println((new StringBuilder()).append("\"").append(oraclesql.getRevisedSql()).append("\"").toString());
            }
            catch(Exception exception)
            {
                System.out.println(exception);
            }
        }

    }

    private static final void dumpTransitionMatrix(String s)
    {
        try
        {
            PrintWriter printwriter = new PrintWriter(s);
            printwriter.print(",");
            for(int j = 0; j < 128; j++)
                printwriter.print((new StringBuilder()).append("'").append(j >= 32 ? Character.toString((char)j) : (new StringBuilder()).append("0x").append(Integer.toHexString(j)).toString()).append(j >= 127 ? "'" : "',").toString());

            printwriter.println();
            int ai[][] = OracleSqlReadOnly.TRANSITION;
            String as[] = OracleSqlReadOnly.PARSER_STATE_NAME;
            for(int k = 0; k < TRANSITION.length; k++)
            {
                printwriter.print((new StringBuilder()).append(as[k]).append(",").toString());
                for(int l = 0; l < ai[k].length; l++)
                    printwriter.print((new StringBuilder()).append(as[ai[k][l]]).append(l >= 127 ? "" : ",").toString());

                printwriter.println();
            }

            printwriter.close();
        }
        catch(Throwable throwable)
        {
            System.err.println(throwable);
        }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

    int getReturnParameterCount()
        throws SQLException
    {
        if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED)
            computeBasicInfo(parameterSql);
        if(!sqlKind.isDML())
            return -1;
        else
            return returningIntoParameterCount;
    }

    private int getSubstrPos(String s, String s1)
        throws SQLException
    {
        int j = -1;
        int k = s.indexOf(s1);
        if(k >= 1 && Character.isWhitespace(s.charAt(k - 1)))
        {
            int l = k + s1.length();
            if(l < s.length() && Character.isWhitespace(s.charAt(l)))
                j = k;
        }
        return j;
    }

    static 
    {
        TRANSITION = OracleSqlReadOnly.TRANSITION;
        ACTION = OracleSqlReadOnly.ACTION;
        ODBC_ACTION = OracleSqlReadOnly.ODBC_ACTION;
    }
}
