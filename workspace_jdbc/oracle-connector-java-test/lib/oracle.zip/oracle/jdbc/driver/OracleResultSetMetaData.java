// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleResultSetMetaData.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleArray;
import oracle.jdbc.OracleBfile;
import oracle.jdbc.OracleBlob;
import oracle.jdbc.OracleClob;
import oracle.jdbc.OracleNClob;
import oracle.jdbc.OracleOpaque;
import oracle.jdbc.OracleRef;
import oracle.jdbc.OracleStruct;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oracore.OracleNamedType;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.StructDescriptor;
import oracle.sql.TypeDescriptor;

// Referenced classes of package oracle.jdbc.driver:
//            OracleStatementWrapper, OracleStatement, PhysicalConnection, OracleResultSet, 
//            DatabaseError, Accessor

class OracleResultSetMetaData
    implements oracle.jdbc.internal.OracleResultSetMetaData
{

    PhysicalConnection connection;
    OracleStatement statement;
    int m_beginColumnIndex;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleResultSetMetaData()
    {
    }

    public OracleResultSetMetaData(PhysicalConnection physicalconnection, OracleStatement oraclestatement)
        throws SQLException
    {
        connection = physicalconnection;
        statement = oraclestatement;
        oraclestatement.describe();
        m_beginColumnIndex = 0;
    }

    OracleResultSetMetaData(PhysicalConnection physicalconnection, OracleStatement oraclestatement, int i)
        throws SQLException
    {
        connection = physicalconnection;
        statement = oraclestatement;
        oraclestatement.describe();
        m_beginColumnIndex = i;
    }

    public OracleResultSetMetaData(OracleResultSet oracleresultset)
        throws SQLException
    {
        statement = (OracleStatement)((OracleStatementWrapper)oracleresultset.getStatement()).statement;
        connection = (PhysicalConnection)statement.getConnection();
        statement.describe();
        m_beginColumnIndex = oracleresultset.getFirstUserColumnIndex();
    }

    public int getColumnCount()
        throws SQLException
    {
        return statement.getNumberOfColumns() - m_beginColumnIndex;
    }

    public boolean isAutoIncrement(int i)
        throws SQLException
    {
        return false;
    }

    int getValidColumnIndex(int i)
        throws SQLException
    {
        int j = (i + m_beginColumnIndex) - 1;
        if(j < 0 || j >= statement.getNumberOfColumns())
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "getValidColumnIndex");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return j;
        }
    }

    public boolean isCaseSensitive(int i)
        throws SQLException
    {
        int j = getColumnType(i);
        return j == 1 || j == 12 || j == -1 || j == -15 || j == -9;
    }

    public boolean isSearchable(int i)
        throws SQLException
    {
        int j = getColumnType(i);
        return j != -4 && j != -1 && j != 2004 && j != 2005 && j != -13 && j != 2011 && j != 2002 && j != 2008 && j != 2007 && j != 2003 && j != 2006 && j != -10;
    }

    public boolean isCurrency(int i)
        throws SQLException
    {
        int j = getColumnType(i);
        return j == 2 || j == 6;
    }

    public int isNullable(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        return getDescription()[j].nullable ? 1 : 0;
    }

    public boolean isSigned(int i)
        throws SQLException
    {
        return true;
    }

    public int getColumnDisplaySize(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        int k = getDescription()[j].describeType;
        switch(k)
        {
        case 2: // '\002'
            int l = getPrecision(i);
            int i1 = getDescription()[j].scale;
            if(l != 0 && i1 == -127)
            {
                l = (int)((double)l / 3.32193D);
                i1 = 1;
            } else
            {
                if(l == 0)
                    l = 38;
                if(i1 == -127)
                    i1 = 0;
            }
            int j1 = l + (i1 == 0 ? 0 : 1) + 1;
            return j1;
        }
        return getDescription()[j].describeMaxLength;
    }

    public String getColumnLabel(int i)
        throws SQLException
    {
        return getColumnName(i);
    }

    public String getColumnName(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        return statement.getDescriptionWithNames()[j].columnName;
    }

    public String getSchemaName(int i)
        throws SQLException
    {
        return "";
    }

    public int getPrecision(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        int k = getDescription()[j].describeType;
        switch(k)
        {
        case 112: // 'p'
        case 113: // 'q'
            return -1;

        case 8: // '\b'
        case 24: // '\030'
            return 0x7fffffff;

        case 1: // '\001'
        case 96: // '`'
            return getDescription()[j].describeMaxLength;
        }
        return getDescription()[j].precision;
    }

    public oracle.jdbc.SecurityAttribute getSecurityAttribute(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        return getDescription()[j].securityAttribute;
    }

    public int getScale(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        int k = getDescription()[j].scale;
        return k != -127 || !statement.connection.j2ee13Compliant ? k : 0;
    }

    public String getTableName(int i)
        throws SQLException
    {
        return "";
    }

    public String getCatalogName(int i)
        throws SQLException
    {
        return "";
    }

    public int getColumnType(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        int k = getDescription()[j].describeType;
        switch(k)
        {
        case 96: // '`'
            return getDescription()[j].formOfUse != 2 ? 1 : -15;

        case 1: // '\001'
            return getDescription()[j].formOfUse != 2 ? 12 : -9;

        case 8: // '\b'
            return -1;

        case 2: // '\002'
        case 6: // '\006'
            return !statement.connection.j2ee13Compliant || getDescription()[j].precision == 0 || getDescription()[j].scale != -127 ? 2 : 6;

        case 100: // 'd'
            return 100;

        case 101: // 'e'
            return 101;

        case 23: // '\027'
            return -3;

        case 24: // '\030'
            return -4;

        case 104: // 'h'
        case 208: 
            return -8;

        case 102: // 'f'
            return -10;

        case 12: // '\f'
            return connection.mapDateToTimestamp ? 93 : 91;

        case 180: 
            return 93;

        case 181: 
            return -101;

        case 231: 
            return -102;

        case 113: // 'q'
            return 2004;

        case 112: // 'p'
            return getDescription()[j].formOfUse != 2 ? 2005 : 2011;

        case 114: // 'r'
            return -13;

        case 109: // 'm'
            OracleNamedType oraclenamedtype = (OracleNamedType)(OracleNamedType)getDescription()[j].describeOtype;
            TypeDescriptor typedescriptor = TypeDescriptor.getTypeDescriptor(oraclenamedtype.getFullName(), connection);
            if(typedescriptor != null)
            {
                return typedescriptor.getTypeCode();
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }

        case 111: // 'o'
            return 2006;

        case 182: 
            return -103;

        case 183: 
            return -104;
        }
        return 1111;
    }

    public String getColumnTypeName(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        int k = getDescription()[j].describeType;
        switch(k)
        {
        case 96: // '`'
            if(getDescription()[j].formOfUse == 2)
                return "NCHAR";
            else
                return "CHAR";

        case 1: // '\001'
            if(getDescription()[j].formOfUse == 2)
                return "NVARCHAR2";
            else
                return "VARCHAR2";

        case 8: // '\b'
            return "LONG";

        case 2: // '\002'
        case 6: // '\006'
            if(statement.connection.j2ee13Compliant && getDescription()[j].precision != 0 && getDescription()[j].scale == -127)
                return "FLOAT";
            else
                return "NUMBER";

        case 100: // 'd'
            return "BINARY_FLOAT";

        case 101: // 'e'
            return "BINARY_DOUBLE";

        case 23: // '\027'
            return "RAW";

        case 24: // '\030'
            return "LONG RAW";

        case 104: // 'h'
        case 208: 
            return "ROWID";

        case 102: // 'f'
            return "REFCURSOR";

        case 12: // '\f'
            return "DATE";

        case 180: 
            return "TIMESTAMP";

        case 181: 
            return "TIMESTAMP WITH TIME ZONE";

        case 231: 
            return "TIMESTAMP WITH LOCAL TIME ZONE";

        case 113: // 'q'
            return "BLOB";

        case 112: // 'p'
            if(getDescription()[j].formOfUse == 2)
                return "NCLOB";
            else
                return "CLOB";

        case 114: // 'r'
            return "BFILE";

        case 109: // 'm'
            OracleTypeADT oracletypeadt = (OracleTypeADT)getDescription()[j].describeOtype;
            return oracletypeadt.getFullName();

        case 111: // 'o'
            OracleTypeADT oracletypeadt1 = (OracleTypeADT)getDescription()[j].describeOtype;
            return oracletypeadt1.getFullName();

        case 182: 
            return "INTERVALYM";

        case 183: 
            return "INTERVALDS";
        }
        return null;
    }

    public boolean isReadOnly(int i)
        throws SQLException
    {
        return false;
    }

    public boolean isWritable(int i)
        throws SQLException
    {
        return true;
    }

    public boolean isDefinitelyWritable(int i)
        throws SQLException
    {
        return false;
    }

    public String getColumnClassName(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        int k = getDescription()[j].describeType;
        switch(k)
        {
        case 1: // '\001'
        case 8: // '\b'
        case 96: // '`'
        case 999: 
            return "java.lang.String";

        case 2: // '\002'
        case 6: // '\006'
            if(getDescription()[j].precision != 0 && getDescription()[j].scale == -127)
                return "java.lang.Double";
            else
                return "java.math.BigDecimal";

        case 23: // '\027'
        case 24: // '\030'
            return "byte[]";

        case 12: // '\f'
            return "java.sql.Timestamp";

        case 180: 
            if(statement.connection.j2ee13Compliant)
                return "java.sql.Timestamp";
            else
                return "oracle.sql.TIMESTAMP";

        case 181: 
            return "oracle.sql.TIMESTAMPTZ";

        case 231: 
            return "oracle.sql.TIMESTAMPLTZ";

        case 182: 
            return "oracle.sql.INTERVALYM";

        case 183: 
            return "oracle.sql.INTERVALDS";

        case 104: // 'h'
        case 208: 
            return "oracle.sql.ROWID";

        case 113: // 'q'
            return oracle/jdbc/OracleBlob.getName();

        case 112: // 'p'
            if(getDescription()[j].formOfUse == 2)
                return oracle/jdbc/OracleNClob.getName();
            else
                return oracle/jdbc/OracleClob.getName();

        case 114: // 'r'
            return oracle/jdbc/OracleBfile.getName();

        case 102: // 'f'
            return "OracleResultSet";

        case 109: // 'm'
            switch(getColumnType(i))
            {
            case 2003: 
                return oracle/jdbc/OracleArray.getName();

            case 2007: 
                return oracle/jdbc/OracleOpaque.getName();

            case 2008: 
                OracleNamedType oraclenamedtype = (OracleNamedType)getDescription()[j].describeOtype;
                Map map1 = connection.getJavaObjectTypeMap();
                if(map1 != null)
                {
                    Class class2 = (Class)map1.get(oraclenamedtype.getFullName());
                    if(class2 != null)
                        return class2.getName();
                }
                return StructDescriptor.getJavaObjectClassName(connection, oraclenamedtype.getSchemaName(), oraclenamedtype.getSimpleName());

            case 2002: 
                Map map = connection.getTypeMap();
                if(map != null)
                {
                    Class class1 = (Class)map.get(((OracleNamedType)getDescription()[j].describeOtype).getFullName());
                    if(class1 != null)
                        return class1.getName();
                }
                return oracle/jdbc/OracleStruct.getName();

            case 2009: 
                return "java.sql.SQLXML";

            case 2004: 
            case 2005: 
            case 2006: 
            default:
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }

        case 111: // 'o'
            return oracle/jdbc/OracleRef.getName();

        case 101: // 'e'
            return "oracle.sql.BINARY_DOUBLE";

        case 100: // 'd'
            return "oracle.sql.BINARY_FLOAT";
        }
        return null;
    }

    public boolean isNCHAR(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        return getDescription()[j].formOfUse == 2;
    }

    Accessor[] getDescription()
        throws SQLException
    {
        return statement.getDescription();
    }

    public boolean isWrapperFor(Class class1)
        throws SQLException
    {
        if(class1.isInterface())
        {
            return class1.isInstance(this);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public Object unwrap(Class class1)
        throws SQLException
    {
        if(class1.isInterface() && class1.isInstance(this))
        {
            return this;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
