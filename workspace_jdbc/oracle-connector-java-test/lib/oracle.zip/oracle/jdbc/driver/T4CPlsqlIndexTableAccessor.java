// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CPlsqlIndexTableAccessor.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;

// Referenced classes of package oracle.jdbc.driver:
//            PlsqlIndexTableAccessor, T4CMAREngine, OracleStatement, PhysicalConnection, 
//            DBConversion

class T4CPlsqlIndexTableAccessor extends PlsqlIndexTableAccessor
{

    T4CMAREngine mare;
    final int meta[] = new int[1];
    final int tmp[] = new int[1];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CPlsqlIndexTableAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, int j, int k, int l, short word0, boolean flag, 
            T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, j, k, l, word0, flag);
        calculateSizeTmpByteArray();
        mare = t4cmarengine;
    }

    void processIndicator(int i)
        throws IOException, SQLException
    {
        if(internalType == 1 && describeType == 112 || internalType == 23 && describeType == 113)
        {
            mare.unmarshalUB2();
            mare.unmarshalUB2();
        } else
        if(statement.connection.versionNumber < 9200)
        {
            mare.unmarshalSB2();
            if(!statement.sqlKind.isPlsqlOrCall())
                mare.unmarshalSB2();
        } else
        if(statement.sqlKind.isPlsqlOrCall() || isDMLReturnedParam)
            mare.processIndicator(i <= 0, i);
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        if(isUseLess)
        {
            lastRowProcessed++;
            return false;
        }
        if(rowSpaceIndicator == null)
        {
            byte abyte0[] = new byte[16000];
            mare.unmarshalCLR(abyte0, 0, meta);
            processIndicator(meta[0]);
            lastRowProcessed++;
            return false;
        }
        int i = indicatorIndex + lastRowProcessed;
        int j = lengthIndex + lastRowProcessed;
        byte abyte1[] = statement.ibtBindBytes;
        char ac[] = statement.ibtBindChars;
        short aword0[] = statement.ibtBindIndicators;
        if(isNullByDescribe)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
            lastRowProcessed++;
            if(statement.connection.versionNumber < 9200)
                processIndicator(0);
            return false;
        }
        int k = (int)mare.unmarshalUB4();
        aword0[ibtMetaIndex + 4] = (short)((k & 0xffff0000) >> 16 & 0xffff);
        aword0[ibtMetaIndex + 5] = (short)(k & 0xffff);
        if(elementInternalType == 9 || elementInternalType == 96 || elementInternalType == 1)
        {
            byte abyte2[] = statement.tmpByteArray;
            for(int i1 = 0; i1 < k; i1++)
            {
                int k1 = ibtValueIndex + elementMaxLen * i1;
                mare.unmarshalCLR(abyte2, 0, meta);
                tmp[0] = meta[0];
                int l1 = statement.connection.conversion.CHARBytesToJavaChars(abyte2, 0, ac, k1 + 1, tmp, ac.length - k1 - 1);
                ac[k1] = (char)(l1 * 2);
                processIndicator(meta[0]);
                if(meta[0] == 0)
                {
                    aword0[ibtIndicatorIndex + i1] = -1;
                    aword0[ibtLengthIndex + i1] = 0;
                } else
                {
                    aword0[ibtLengthIndex + i1] = (short)(meta[0] * 2);
                    aword0[ibtIndicatorIndex + i1] = 0;
                }
            }

        } else
        {
            for(int l = 0; l < k; l++)
            {
                int j1 = ibtValueIndex + elementMaxLen * l;
                mare.unmarshalCLR(abyte1, j1 + 1, meta);
                abyte1[j1] = (byte)meta[0];
                processIndicator(meta[0]);
                if(meta[0] == 0)
                {
                    aword0[ibtIndicatorIndex + l] = -1;
                    aword0[ibtLengthIndex + l] = 0;
                } else
                {
                    aword0[ibtLengthIndex + l] = (short)meta[0];
                    aword0[ibtIndicatorIndex + l] = 0;
                }
            }

        }
        lastRowProcessed++;
        return false;
    }

    void calculateSizeTmpByteArray()
    {
        if(elementInternalType == 9 || elementInternalType == 96 || elementInternalType == 1)
        {
            int i = (ibtCharLength * statement.connection.conversion.cMaxCharSize) / maxNumberOfElements;
            if(statement.sizeTmpByteArray < i)
                statement.sizeTmpByteArray = i;
        }
    }

    String getString(int i)
        throws SQLException
    {
        String s = super.getString(i);
        if(s != null && definedColumnSize > 0 && s.length() > definedColumnSize)
            s = s.substring(0, definedColumnSize);
        return s;
    }

}
