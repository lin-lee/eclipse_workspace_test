// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ArrayLocatorResultSet.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.Map;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

// Referenced classes of package oracle.jdbc.driver:
//            OracleResultSetImpl, PhysicalConnection, OracleStatement, OraclePreparedStatementWrapper, 
//            OraclePreparedStatement, OracleConnection, DatabaseError

class ArrayLocatorResultSet extends OracleResultSetImpl
{

    static int COUNT_UNLIMITED = -1;
    Map map;
    long beginIndex;
    int count;
    long currentIndex;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public ArrayLocatorResultSet(OracleConnection oracleconnection, ArrayDescriptor arraydescriptor, byte abyte0[], Map map1)
        throws SQLException
    {
        this(oracleconnection, arraydescriptor, abyte0, 0L, COUNT_UNLIMITED, map1);
    }

    public ArrayLocatorResultSet(OracleConnection oracleconnection, ArrayDescriptor arraydescriptor, byte abyte0[], long l, int i, Map map1)
        throws SQLException
    {
        super((PhysicalConnection)oracleconnection, (OracleStatement)null);
        if(arraydescriptor == null || oracleconnection == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid arguments");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        close_statement_on_close = true;
        count = i;
        currentIndex = 0L;
        beginIndex = l;
        map = map1;
        OraclePreparedStatement oraclepreparedstatement = null;
        ARRAY array = new ARRAY(arraydescriptor, oracleconnection, (byte[])null);
        array.setLocator(abyte0);
        if(arraydescriptor.getBaseType() == 2002 || arraydescriptor.getBaseType() == 2008)
            oraclepreparedstatement = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oracleconnection.prepareStatement((new StringBuilder()).append("SELECT ROWNUM, SYS_NC_ROWINFO$ FROM TABLE( CAST(:1 AS ").append(arraydescriptor.getName()).append(") )").toString())).preparedStatement;
        else
            oraclepreparedstatement = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oracleconnection.prepareStatement((new StringBuilder()).append("SELECT ROWNUM, COLUMN_VALUE FROM TABLE( CAST(:1 AS ").append(arraydescriptor.getName()).append(") )").toString())).preparedStatement;
        oraclepreparedstatement.setArray(1, array);
        oraclepreparedstatement.executeQuery();
        statement = oraclepreparedstatement;
    }

    public boolean next()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(currentIndex < beginIndex)
        {
            do
            {
                if(currentIndex >= beginIndex)
                    break MISSING_BLOCK_LABEL_52;
                currentIndex++;
            } while(super.next());
            return false;
        }
          goto _L1
        true;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L1:
        if(count != COUNT_UNLIMITED) goto _L3; else goto _L2
_L2:
        super.next();
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L3:
        if(currentIndex >= (beginIndex + (long)count) - 1L) goto _L5; else goto _L4
_L4:
        currentIndex++;
        super.next();
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L5:
        false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Object getObject(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getObject(i, map);
        Exception exception;
        exception;
        throw exception;
    }

    public int findColumn(String s)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(s.equalsIgnoreCase("index"))
            return 1;
        if(!s.equalsIgnoreCase("value")) goto _L2; else goto _L1
_L1:
        2;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6, "get_column_index");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        Exception exception;
        exception;
        throw exception;
    }

}
