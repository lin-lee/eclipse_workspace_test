// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;


// Referenced classes of package oracle.jdbc.driver:
//            Binder, OraclePreparedStatement

abstract class ByteCopyingBinder extends Binder
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    ByteCopyingBinder()
    {
    }

    Binder copyingBinder()
    {
        return this;
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
    {
        byte abyte1[];
        int j2;
        int k2;
        if(j == 0)
        {
            abyte1 = oraclepreparedstatement.lastBoundBytes;
            j2 = oraclepreparedstatement.lastBoundByteOffsets[i];
            aword0[i2] = oraclepreparedstatement.lastBoundInds[i];
            aword0[l1] = oraclepreparedstatement.lastBoundLens[i];
            if(abyte1 == abyte0 && j2 == j1)
                return;
            k2 = oraclepreparedstatement.lastBoundByteLens[i];
            if(k2 > l)
                k2 = l;
        } else
        {
            abyte1 = abyte0;
            j2 = j1 - l;
            aword0[i2] = aword0[i2 - 1];
            aword0[l1] = aword0[l1 - 1];
            k2 = l;
        }
        System.arraycopy(abyte1, j2, abyte0, j1, k2);
    }

}
