// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   CharCommonAccessor.java

package oracle.jdbc.driver;

import java.io.*;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.*;
import java.util.Map;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            Accessor, DBConversion, OracleStatement, PhysicalConnection, 
//            DatabaseError, CRC64

abstract class CharCommonAccessor extends Accessor
{

    int internalMaxLengthNewer;
    int internalMaxLengthOlder;
    static final int MAX_NB_CHAR_PLSQL = 32766;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    CharCommonAccessor()
    {
    }

    void setOffsets(int i)
    {
        columnIndex = statement.defineCharSubRange;
        statement.defineCharSubRange = columnIndex + i * charLength;
    }

    void init(OracleStatement oraclestatement, int i, int j, int k, short word0, int l, boolean flag, 
            int i1, int j1)
        throws SQLException
    {
        if(flag)
        {
            if(i != 23)
                i = 1;
            if(oraclestatement.maxFieldSize > 0 && (k == -1 || k < oraclestatement.maxFieldSize))
                k = oraclestatement.maxFieldSize;
        }
        init(oraclestatement, i, j, word0, flag);
        if(flag && oraclestatement.connection.defaultnchar)
            formOfUse = 2;
        internalMaxLengthNewer = i1;
        internalMaxLengthOlder = j1;
        initForDataAccess(l, k, null);
    }

    void init(OracleStatement oraclestatement, int i, int j, int k, boolean flag, int l, int i1, 
            int j1, int k1, int l1, short word0, int i2, int j2)
        throws SQLException
    {
        init(oraclestatement, i, j, word0, false);
        initForDescribe(i, k, flag, l, i1, j1, k1, l1, word0, null);
        int k2 = oraclestatement.maxFieldSize;
        if(k2 != 0 && k2 <= k)
            k = k2;
        internalMaxLengthNewer = i2;
        internalMaxLengthOlder = j2;
        initForDataAccess(0, k, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        if(statement.connection.getVersionNumber() >= 8000)
            internalTypeMaxLength = internalMaxLengthNewer;
        else
            internalTypeMaxLength = internalMaxLengthOlder;
        if(j == 0)
            internalTypeMaxLength = 0;
        else
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        charLength = isNullByDescribe ? 0 : internalTypeMaxLength + 1;
    }

    int getInt(int i)
        throws SQLException
    {
        int j = 0;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            try
            {
                j = Integer.parseInt(getString(i).trim());
            }
            catch(NumberFormatException numberformatexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return j;
    }

    boolean getBoolean(int i)
        throws SQLException
    {
        String s = getString(i);
        if(s == null)
            return false;
        s = s.trim();
        try
        {
            BigDecimal bigdecimal = new BigDecimal(s);
            return bigdecimal.signum() != 0;
        }
        catch(NumberFormatException numberformatexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    short getShort(int i)
        throws SQLException
    {
        short word0 = 0;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            try
            {
                word0 = Short.parseShort(getString(i).trim());
            }
            catch(NumberFormatException numberformatexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return word0;
    }

    byte getByte(int i)
        throws SQLException
    {
        byte byte0 = 0;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            try
            {
                byte0 = Byte.parseByte(getString(i).trim());
            }
            catch(NumberFormatException numberformatexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return byte0;
    }

    long getLong(int i)
        throws SQLException
    {
        long l = 0L;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            try
            {
                l = Long.parseLong(getString(i).trim());
            }
            catch(NumberFormatException numberformatexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return l;
    }

    float getFloat(int i)
        throws SQLException
    {
        float f = 0.0F;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            try
            {
                f = Float.parseFloat(getString(i).trim());
            }
            catch(NumberFormatException numberformatexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return f;
    }

    double getDouble(int i)
        throws SQLException
    {
        double d = 0.0D;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            try
            {
                d = Double.parseDouble(getString(i).trim());
            }
            catch(NumberFormatException numberformatexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return d;
    }

    BigDecimal getBigDecimal(int i)
        throws SQLException
    {
        BigDecimal bigdecimal = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            try
            {
                String s = getString(i);
                if(s != null)
                    bigdecimal = new BigDecimal(s.trim());
            }
            catch(NumberFormatException numberformatexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return bigdecimal;
    }

    BigDecimal getBigDecimal(int i, int j)
        throws SQLException
    {
        BigDecimal bigdecimal = getBigDecimal(i);
        if(bigdecimal != null)
            bigdecimal.setScale(j, 6);
        return bigdecimal;
    }

    String getString(int i)
        throws SQLException
    {
        String s = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            int j = columnIndex + charLength * i;
            int k = rowSpaceChar[j] >> 1;
            if(k > internalTypeMaxLength)
                k = internalTypeMaxLength;
            s = new String(rowSpaceChar, j + 1, k);
        }
        return s;
    }

    Date getDate(int i)
        throws SQLException
    {
        Date date = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            date = Date.valueOf(getString(i).trim());
        return date;
    }

    Time getTime(int i)
        throws SQLException
    {
        Time time = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            time = Time.valueOf(getString(i).trim());
        return time;
    }

    Timestamp getTimestamp(int i)
        throws SQLException
    {
        Timestamp timestamp = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            timestamp = Timestamp.valueOf(getString(i).trim());
        return timestamp;
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        return getBytesInternal(i);
    }

    byte[] getBytesInternal(int i)
        throws SQLException
    {
        byte abyte0[] = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            int j = columnIndex + charLength * i;
            int k = rowSpaceChar[j] >> 1;
            if(k > internalTypeMaxLength)
                k = internalTypeMaxLength;
            DBConversion dbconversion = statement.connection.conversion;
            byte abyte1[] = new byte[k * 6];
            int l = formOfUse != 2 ? dbconversion.javaCharsToCHARBytes(rowSpaceChar, j + 1, abyte1, 0, k) : dbconversion.javaCharsToNCHARBytes(rowSpaceChar, j + 1, abyte1, 0, k);
            abyte0 = new byte[l];
            System.arraycopy(abyte1, 0, abyte0, 0, l);
        }
        return abyte0;
    }

    InputStream getAsciiStream(int i)
        throws SQLException
    {
        InputStream inputstream = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            int j = columnIndex + charLength * i;
            int k = rowSpaceChar[j] >> 1;
            if(k > internalTypeMaxLength)
                k = internalTypeMaxLength;
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            inputstream = physicalconnection.conversion.CharsToStream(rowSpaceChar, j + 1, k, 10);
        }
        return inputstream;
    }

    InputStream getUnicodeStream(int i)
        throws SQLException
    {
        InputStream inputstream = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            int j = columnIndex + charLength * i;
            int k = rowSpaceChar[j] >> 1;
            if(k > internalTypeMaxLength)
                k = internalTypeMaxLength;
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            inputstream = physicalconnection.conversion.CharsToStream(rowSpaceChar, j + 1, k << 1, 11);
        }
        return inputstream;
    }

    Reader getCharacterStream(int i)
        throws SQLException
    {
        CharArrayReader chararrayreader = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            int j = columnIndex + charLength * i;
            int k = rowSpaceChar[j] >> 1;
            if(k > internalTypeMaxLength)
                k = internalTypeMaxLength;
            chararrayreader = new CharArrayReader(rowSpaceChar, j + 1, k);
        }
        return chararrayreader;
    }

    InputStream getBinaryStream(int i)
        throws SQLException
    {
        ByteArrayInputStream bytearrayinputstream = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            int j = columnIndex + charLength * i;
            int k = rowSpaceChar[j] >> 1;
            if(k > internalTypeMaxLength)
                k = internalTypeMaxLength;
            DBConversion dbconversion = statement.connection.conversion;
            byte abyte0[] = new byte[k * 6];
            int l = formOfUse != 2 ? dbconversion.javaCharsToCHARBytes(rowSpaceChar, j + 1, abyte0, 0, k) : dbconversion.javaCharsToNCHARBytes(rowSpaceChar, j + 1, abyte0, 0, k);
            bytearrayinputstream = new ByteArrayInputStream(abyte0, 0, l);
        }
        return bytearrayinputstream;
    }

    Object getObject(int i)
        throws SQLException
    {
        return getString(i);
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        return getString(i);
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        return getCHAR(i);
    }

    CHAR getCHAR(int i)
        throws SQLException
    {
        byte abyte0[] = getBytesInternal(i);
        if(abyte0 == null || abyte0.length == 0)
            return null;
        CharacterSet characterset;
        if(formOfUse == 2)
            characterset = statement.connection.conversion.getDriverNCharSetObj();
        else
            characterset = statement.connection.conversion.getDriverCharSetObj();
        return new CHAR(abyte0, characterset);
    }

    URL getURL(int i)
        throws SQLException
    {
        URL url = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            try
            {
                url = new URL(getString(i));
            }
            catch(MalformedURLException malformedurlexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return url;
    }

    byte[] getBytesFromHexChars(int i)
        throws SQLException
    {
        byte abyte0[] = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            int j = columnIndex + charLength * i;
            int k = rowSpaceChar[j] >> 1;
            if(k > internalTypeMaxLength)
                k = internalTypeMaxLength;
            abyte0 = statement.connection.conversion.hexChars2Bytes(rowSpaceChar, j + 1, k);
        }
        return abyte0;
    }

    long updateChecksum(long l, int i)
        throws SQLException
    {
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            CRC64 _tmp = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
        } else
        {
            int j = columnIndex + charLength * i;
            int k = rowSpaceChar[j] >> 1;
            CRC64 _tmp1 = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, rowSpaceChar, j + 1, k);
        }
        return l;
    }

}
