// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleBufferedStream.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.InputStream;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            OracleStatement, DatabaseError

abstract class OracleBufferedStream extends InputStream
{

    byte resizableBuffer[];
    int initialBufferSize;
    int currentBufferSize;
    int pos;
    int count;
    long maxPosition;
    boolean closed;
    OracleStatement statement;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleBufferedStream(int i)
    {
        maxPosition = 0x7fffffffL;
        pos = 0;
        count = 0;
        closed = false;
        initialBufferSize = i;
        currentBufferSize = 0;
        resizableBuffer = null;
    }

    public OracleBufferedStream(OracleStatement oraclestatement, int i)
    {
        this(i);
        statement = oraclestatement;
    }

    public void close()
        throws IOException
    {
        closed = true;
        resizableBuffer = null;
    }

    public boolean needBytes()
        throws IOException
    {
        return needBytes(Math.max(initialBufferSize, currentBufferSize));
    }

    public abstract boolean needBytes(int i)
        throws IOException;

    public int flushBytes(int i)
    {
        int j = i <= count - pos ? i : count - pos;
        pos += j;
        return j;
    }

    public int writeBytes(byte abyte0[], int i, int j)
    {
        int k = j <= count - pos ? j : count - pos;
        System.arraycopy(resizableBuffer, pos, abyte0, i, k);
        pos += k;
        return k;
    }

    public int read()
        throws IOException
    {
        if(statement != null)
            break MISSING_BLOCK_LABEL_23;
        Object obj = this;
        JVM INSTR monitorenter ;
        return readInternal();
        Exception exception;
        exception;
        throw exception;
        obj = statement.connection;
        JVM INSTR monitorenter ;
        return readInternal();
        Exception exception1;
        exception1;
        throw exception1;
    }

    private final int readInternal()
        throws IOException
    {
        if(closed || isNull())
            return -1;
        if(needBytes())
            return resizableBuffer[pos++] & 0xff;
        else
            return -1;
    }

    public int read(byte abyte0[])
        throws IOException
    {
        return read(abyte0, 0, abyte0.length);
    }

    public int read(byte abyte0[], int i, int j)
        throws IOException
    {
        if(statement != null)
            break MISSING_BLOCK_LABEL_31;
        Object obj = this;
        JVM INSTR monitorenter ;
        return readInternal(abyte0, i, j);
        Exception exception;
        exception;
        throw exception;
        obj = statement.connection;
        JVM INSTR monitorenter ;
        return readInternal(abyte0, i, j);
        Exception exception1;
        exception1;
        throw exception1;
    }

    private final int readInternal(byte abyte0[], int i, int j)
        throws IOException
    {
        int l = i;
        if(closed || isNull())
            return -1;
        int k;
        if(j > abyte0.length)
            k = l + abyte0.length;
        else
            k = l + j;
        if(!needBytes(j))
            return -1;
        for(l += writeBytes(abyte0, l, k - l); l < k && needBytes(k - l); l += writeBytes(abyte0, l, k - l));
        return l - i;
    }

    public int available()
        throws IOException
    {
        if(closed || isNull())
            return 0;
        else
            return count - pos;
    }

    public boolean isNull()
        throws IOException
    {
        return false;
    }

    public void mark(int i)
    {
    }

    public void reset()
        throws IOException
    {
        PhysicalConnection physicalconnection = statement.connection;
        JVM INSTR monitorenter ;
        throw new IOException(DatabaseError.findMessage(194, null));
    }

    public boolean markSupported()
    {
        return false;
    }

    public long skip(int i)
        throws IOException
    {
        if(statement != null)
            break MISSING_BLOCK_LABEL_25;
        Object obj = this;
        JVM INSTR monitorenter ;
        return (long)skipInternal(i);
        Exception exception;
        exception;
        throw exception;
        obj = statement.connection;
        JVM INSTR monitorenter ;
        return (long)skipInternal(i);
        Exception exception1;
        exception1;
        throw exception1;
    }

    private final int skipInternal(int i)
        throws IOException
    {
        int j = 0;
        int k = i;
        if(closed || isNull())
            return -1;
        if(!needBytes())
            return -1;
        for(; j < k && needBytes(); j += flushBytes(k - j));
        return j;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return statement.getConnectionDuringExceptionHandling();
    }

}
