// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleSQLXML.java

package oracle.jdbc.driver;

import java.io.*;
import java.sql.*;
import javax.xml.stream.*;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stax.StAXResult;
import javax.xml.transform.stax.StAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import oracle.sql.*;
import oracle.xdb.XMLType;
import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLSAXSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

// Referenced classes of package oracle.jdbc.driver:
//            Opaqueable, DatabaseError

final class OracleSQLXML extends DatumWithConnection
    implements SQLXML, Opaqueable
{

    private XMLType xdb;
    private boolean isReadable;
    private boolean isWriteable;
    private DOMResult domResult;
    private XMLSAXSerializer serializer;
    private ByteArrayOutputStream oStream;
    static final int INITIAL_BUFFER_SIZE = 16384;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleSQLXML(Connection connection)
        throws SQLException
    {
        isReadable = false;
        isWriteable = false;
        domResult = null;
        serializer = null;
        oStream = null;
        setPhysicalConnectionOf(connection);
        isReadable = false;
        isWriteable = true;
    }

    OracleSQLXML(Connection connection, OPAQUE opaque)
        throws SQLException
    {
        isReadable = false;
        isWriteable = false;
        domResult = null;
        serializer = null;
        oStream = null;
        setPhysicalConnectionOf(connection);
        isReadable = true;
        isWriteable = false;
        if(opaque instanceof XMLType)
            xdb = (XMLType)opaque;
        else
            xdb = new XMLType(opaque.getDescriptor(), getInternalConnection(), opaque.getBytesValue());
    }

    OracleSQLXML(OpaqueDescriptor opaquedescriptor, Connection connection, byte abyte0[])
        throws SQLException
    {
        this(connection, new OPAQUE(opaquedescriptor, abyte0, connection));
    }

    OracleSQLXML(Connection connection, InputStream inputstream)
        throws SQLException
    {
        isReadable = false;
        isWriteable = false;
        domResult = null;
        serializer = null;
        oStream = null;
        setPhysicalConnectionOf(connection);
        isReadable = true;
        isWriteable = false;
        xdb = new XMLType(getInternalConnection(), inputstream);
    }

    OracleSQLXML(Connection connection, XMLType xmltype)
        throws SQLException
    {
        isReadable = false;
        isWriteable = false;
        domResult = null;
        serializer = null;
        oStream = null;
        setPhysicalConnectionOf(connection);
        isReadable = true;
        isWriteable = false;
        xdb = xmltype;
    }

    public OPAQUE toOpaque()
        throws SQLException
    {
        return getXMLTypeInternal();
    }

    XMLType getXMLTypeInternal()
        throws SQLException
    {
        if(isWriteable)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 260);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(serializer == null)
            break MISSING_BLOCK_LABEL_72;
        try
        {
            serializer.flush();
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        serializer = null;
        break MISSING_BLOCK_LABEL_72;
        Exception exception;
        exception;
        serializer = null;
        throw exception;
        if(oStream != null)
        {
            try
            {
                oStream.close();
            }
            catch(IOException ioexception1)
            {
                SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception1);
                sqlexception3.fillInStackTrace();
                throw sqlexception3;
            }
            xdb = XMLType.createXML(getInternalConnection(), new ByteArrayInputStream(oStream.toByteArray()));
            oStream = null;
        } else
        if(domResult != null)
        {
            Node node = domResult.getNode();
            Object obj = null;
            if(node instanceof Document)
            {
                obj = (Document)node;
            } else
            {
                obj = new XMLDocument();
                node = ((Document) (obj)).importNode(node, true);
                ((Document) (obj)).insertBefore(node, null);
            }
            xdb = XMLType.createXML(getInternalConnection(), ((Document) (obj)));
            domResult = null;
        }
        if(xdb == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 260);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return xdb;
        }
    }

    public byte[] getBytes()
    {
        return null;
    }

    public boolean isConvertibleTo(Class class1)
    {
        return false;
    }

    public Object toJdbc()
        throws SQLException
    {
        return this;
    }

    public Object makeJdbcArray(int i)
    {
        return null;
    }

    public void free()
        throws SQLException
    {
        isReadable = false;
        isWriteable = false;
        oStream = null;
        domResult = null;
        if(xdb != null)
            xdb.close();
        xdb = null;
    }

    InputStream getInputStream()
        throws SQLException
    {
        return new ByteArrayInputStream(xdb.getStringVal().getBytes());
    }

    public InputStream getBinaryStream()
        throws SQLException
    {
        if(!isReadable)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 261);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            isReadable = false;
            return getInputStream();
        }
    }

    public Reader getCharacterStream()
        throws SQLException
    {
        if(!isReadable)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 261);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            isReadable = false;
            return new StringReader(xdb.getStringVal());
        }
    }

    public Source getSource(Class class1)
        throws SQLException
    {
        if(!isReadable)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 261);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        isReadable = false;
        if(class1 == javax/xml/transform/dom/DOMSource)
        {
            Document document = xdb.getDocument();
            return new DOMSource(document);
        }
        if(class1 == javax/xml/transform/sax/SAXSource)
        {
            InputSource inputsource = new InputSource(getInputStream());
            return new SAXSource(inputsource);
        }
        if(class1 == javax/xml/transform/stax/StAXSource)
        {
            SQLException sqlexception2;
            try
            {
                XMLInputFactory xmlinputfactory = XMLInputFactory.newInstance();
                javax.xml.stream.XMLStreamReader xmlstreamreader = xmlinputfactory.createXMLStreamReader(getInputStream());
                return new StAXSource(xmlstreamreader);
            }
            catch(XMLStreamException xmlstreamexception)
            {
                sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), xmlstreamexception);
            }
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        if(class1 == javax/xml/transform/stream/StreamSource)
        {
            return new StreamSource(getInputStream());
        } else
        {
            isReadable = true;
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 264);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public String getString()
        throws SQLException
    {
        if(!isReadable)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 261);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            isReadable = false;
            return xdb.getStringVal();
        }
    }

    protected OutputStream getOutputStream()
        throws SQLException
    {
        if(oStream != null)
        {
            throw new SQLException("Internal Error");
        } else
        {
            oStream = new ByteArrayOutputStream(16384);
            return oStream;
        }
    }

    public OutputStream setBinaryStream()
        throws SQLException
    {
        if(!isWriteable)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 262);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            isWriteable = false;
            return getOutputStream();
        }
    }

    public Writer setCharacterStream()
        throws SQLException
    {
        if(!isWriteable)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 262);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            isWriteable = false;
            return new OutputStreamWriter(getOutputStream());
        }
    }

    public Result setResult(Class class1)
        throws SQLException
    {
        if(!isWriteable)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 262);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        isWriteable = false;
        if(class1 == javax/xml/transform/dom/DOMResult)
        {
            domResult = new DOMResult();
            return domResult;
        }
        if(class1 == javax/xml/transform/sax/SAXResult)
        {
            serializer = new XMLSAXSerializer(getOutputStream());
            return new SAXResult(serializer);
        }
        if(class1 == javax/xml/transform/stax/StAXResult)
            try
            {
                XMLOutputFactory xmloutputfactory = XMLOutputFactory.newInstance();
                return new StAXResult(xmloutputfactory.createXMLStreamWriter(getOutputStream()));
            }
            catch(XMLStreamException xmlstreamexception)
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), xmlstreamexception);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        if(class1 == javax/xml/transform/stream/StreamResult)
        {
            return new StreamResult(getOutputStream());
        } else
        {
            isWriteable = true;
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 263);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public void setString(String s)
        throws SQLException
    {
        if(!isWriteable)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 262);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            isWriteable = false;
            xdb = new XMLType(getInternalConnection(), s);
            return;
        }
    }

}
