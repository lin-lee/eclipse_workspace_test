// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   CachedRowElement.java

package oracle.jdbc.driver;

import oracle.jdbc.OracleResultSet;
import oracle.sql.Datum;

class CachedRowElement
{

    private final int row;
    private final int col;
    private final oracle.jdbc.OracleResultSet.AuthorizationIndicator securityIndicator;
    private final byte data[];
    private Datum dataAsDatum;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    CachedRowElement(int i, int j, oracle.jdbc.OracleResultSet.AuthorizationIndicator authorizationindicator, byte abyte0[])
    {
        row = i;
        col = j;
        securityIndicator = authorizationindicator;
        data = abyte0;
        dataAsDatum = null;
    }

    oracle.jdbc.OracleResultSet.AuthorizationIndicator getIndicator()
    {
        return securityIndicator;
    }

    void setData(Datum datum)
    {
        dataAsDatum = datum;
    }

    byte[] getData()
    {
        return data;
    }

    Datum getDataAsDatum()
    {
        return dataAsDatum;
    }

}
