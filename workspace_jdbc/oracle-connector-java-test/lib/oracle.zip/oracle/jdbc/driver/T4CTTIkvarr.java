// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIkvarr.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValue;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, KeywordValueI, T4CMAREngine, T4CConnection

class T4CTTIkvarr extends T4CTTIMsg
{

    KeywordValue kpdkvarrptr[];
    long kpdkvarrflg;

    T4CTTIkvarr(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)0);
        kpdkvarrptr = null;
    }

    void unmarshal()
        throws SQLException, IOException
    {
        int i = (int)meg.unmarshalUB4();
        byte byte0 = (byte)meg.unmarshalUB1();
        if(i > 0)
        {
            kpdkvarrptr = new KeywordValueI[i];
            for(int j = 0; j < i; j++)
                kpdkvarrptr[j] = KeywordValueI.unmarshal(meg);

            connection.updateSessionProperties(kpdkvarrptr);
        } else
        {
            kpdkvarrptr = null;
        }
        kpdkvarrflg = meg.unmarshalUB4();
    }
}
