// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;


// Referenced classes of package oracle.jdbc.driver:
//            DatumBinder, Binder, OraclePreparedStatementReadOnly, OraclePreparedStatement

class OracleNumberBinder extends DatumBinder
{

    Binder theVarnumCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    static void init(Binder binder)
    {
        binder.type = 6;
        binder.bytelen = 22;
    }

    OracleNumberBinder()
    {
        theVarnumCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarnumCopyingBinder;
        init(this);
    }

    Binder copyingBinder()
    {
        return theVarnumCopyingBinder;
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
    {
        byte abyte1[][] = oraclepreparedstatement.parameterDatum[k];
        byte abyte2[] = abyte1[i];
        if(flag)
            abyte1[i] = null;
        if(abyte2 == null)
        {
            aword0[i2] = -1;
        } else
        {
            aword0[i2] = 0;
            abyte0[j1] = (byte)abyte2.length;
            System.arraycopy(abyte2, 0, abyte0, j1 + 1, abyte2.length);
            aword0[l1] = (short)(abyte2.length + 1);
        }
    }

}
