// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C8TTIrxh.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, T4CMAREngine, T4CTTIrxd, T4CConnection

class T4C8TTIrxh extends T4CTTIMsg
{

    short rxhflg;
    int numRqsts;
    int iterNum;
    int numItersThisTime;
    int uacBufLength;
    static final byte RXHFU2O = 1;
    static final byte RXHFEOR = 2;
    static final byte RXHPLSV = 4;
    static final byte RXHFRXR = 8;
    static final byte RXHFKCO = 16;
    static final byte RXHFDCF = 32;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C8TTIrxh(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)0);
    }

    void unmarshalV10(T4CTTIrxd t4cttirxd)
        throws SQLException, IOException
    {
        rxhflg = meg.unmarshalUB1();
        numRqsts = meg.unmarshalUB2();
        iterNum = meg.unmarshalUB2();
        numRqsts += iterNum * 256;
        numItersThisTime = meg.unmarshalUB2();
        uacBufLength = meg.unmarshalUB2();
        byte abyte0[] = meg.unmarshalDALC();
        t4cttirxd.readBitVector(abyte0);
        byte abyte1[] = meg.unmarshalDALC();
    }

    void init()
    {
        rxhflg = 0;
        numRqsts = 0;
        iterNum = 0;
        numItersThisTime = 0;
        uacBufLength = 0;
    }

    void print()
    {
    }

}
