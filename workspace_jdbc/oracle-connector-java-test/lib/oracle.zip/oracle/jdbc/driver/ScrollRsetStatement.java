// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ScrollRsetStatement.java

package oracle.jdbc.driver;

import java.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            OracleResultSetCache

interface ScrollRsetStatement
{

    public abstract Connection getConnection()
        throws SQLException;

    public abstract void notifyCloseRset()
        throws SQLException;

    public abstract int copyBinds(Statement statement, int i)
        throws SQLException;

    public abstract String getOriginalSql()
        throws SQLException;

    public abstract OracleResultSetCache getResultSetCache()
        throws SQLException;

    public abstract int getMaxFieldSize()
        throws SQLException;
}
