// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CRefTypeAccessor.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;

// Referenced classes of package oracle.jdbc.driver:
//            RefTypeAccessor, T4CMAREngine, OracleStatement, PhysicalConnection

class T4CRefTypeAccessor extends RefTypeAccessor
{

    static final int maxLength = 4000;
    T4CMAREngine mare;
    final int meta[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CRefTypeAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, String s, short word0, int i, boolean flag, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, s, word0, i, flag);
        meta = new int[1];
        mare = t4cmarengine;
        byteLength = 4000;
    }

    T4CRefTypeAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, String s, int k1, int l1, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, flag, j, k, l, i1, j1, word0, s);
        meta = new int[1];
        mare = t4cmarengine;
        definedColumnType = k1;
        definedColumnSize = l1;
        byteLength = 4000;
    }

    void processIndicator(int i)
        throws IOException, SQLException
    {
        if(internalType == 1 && describeType == 112 || internalType == 23 && describeType == 113)
        {
            mare.unmarshalUB2();
            mare.unmarshalUB2();
        } else
        if(statement.connection.versionNumber < 9200)
        {
            mare.unmarshalSB2();
            if(!statement.sqlKind.isPlsqlOrCall())
                mare.unmarshalSB2();
        } else
        if(statement.sqlKind.isPlsqlOrCall() || isDMLReturnedParam)
            mare.processIndicator(i <= 0, i);
    }

    String getString(int i)
        throws SQLException
    {
        String s = super.getString(i);
        if(s != null && definedColumnSize > 0 && s.length() > definedColumnSize)
            s = s.substring(0, definedColumnSize);
        return s;
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        if(isUseLess)
        {
            lastRowProcessed++;
            return false;
        }
        byte abyte0[] = mare.unmarshalCLRforREFS();
        if(abyte0 == null)
            abyte0 = new byte[0];
        pickledBytes[lastRowProcessed] = abyte0;
        meta[0] = abyte0.length;
        processIndicator(meta[0]);
        int i = indicatorIndex + lastRowProcessed;
        int j = lengthIndex + lastRowProcessed;
        if(meta[0] == 0)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
        } else
        {
            rowSpaceIndicator[j] = (short)meta[0];
            rowSpaceIndicator[i] = 0;
        }
        lastRowProcessed++;
        return false;
    }

}
