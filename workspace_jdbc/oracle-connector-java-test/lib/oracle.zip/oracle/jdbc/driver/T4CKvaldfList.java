// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CKvaldfList.java

package oracle.jdbc.driver;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            DBConversion

class T4CKvaldfList
{

    static final int INTIAL_CAPACITY = 30;
    private int capacity;
    private int offset;
    private byte keys[][];
    private byte values[][];
    private byte flags[];
    DBConversion conv;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CKvaldfList(DBConversion dbconversion)
    {
        conv = dbconversion;
        initializeList();
    }

    void initializeList()
    {
        capacity = 30;
        offset = 0;
        keys = new byte[capacity][];
        values = new byte[capacity][];
        flags = new byte[capacity];
    }

    void add(byte abyte0[], byte abyte1[], byte byte0)
    {
        if(offset == capacity)
        {
            byte abyte2[][] = new byte[capacity * 2][];
            byte abyte3[][] = new byte[capacity * 2][];
            byte abyte4[] = new byte[capacity * 2];
            System.arraycopy(keys, 0, abyte2, 0, capacity);
            System.arraycopy(values, 0, abyte3, 0, capacity);
            System.arraycopy(flags, 0, abyte4, 0, capacity);
            keys = abyte2;
            values = abyte3;
            flags = abyte4;
            capacity = capacity * 2;
        }
        keys[offset] = abyte0;
        values[offset] = abyte1;
        flags[offset++] = byte0;
    }

    void add(byte abyte0[], byte abyte1[])
    {
        add(abyte0, abyte1, (byte)0);
    }

    void add(String s, byte abyte0[])
        throws SQLException
    {
        add(conv.StringToCharBytes(s), abyte0, (byte)0);
    }

    void add(String s, byte abyte0[], byte byte0)
        throws SQLException
    {
        add(conv.StringToCharBytes(s), abyte0, byte0);
    }

    int size()
    {
        return offset;
    }

    byte[][] getKeys()
    {
        return keys;
    }

    byte[][] getValues()
    {
        return values;
    }

    byte[] getFlags()
    {
        return flags;
    }

}
