// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   LongAccessor.java

package oracle.jdbc.driver;

import java.io.*;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            CharCommonAccessor, OracleStatement, PhysicalConnection, OracleDriverExtension, 
//            OracleInputStream, DatabaseError, DBConversion

class LongAccessor extends CharCommonAccessor
{

    OracleInputStream stream;
    int columnPosition;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    LongAccessor(OracleStatement oraclestatement, int i, int j, short word0, int k)
        throws SQLException
    {
        columnPosition = 0;
        init(oraclestatement, 8, 8, word0, false);
        columnPosition = i;
        initForDataAccess(k, j, null);
    }

    LongAccessor(OracleStatement oraclestatement, int i, int j, boolean flag, int k, int l, int i1, 
            int j1, int k1, short word0)
        throws SQLException
    {
        columnPosition = 0;
        init(oraclestatement, 8, 8, word0, false);
        columnPosition = i;
        initForDescribe(8, j, flag, k, l, i1, j1, k1, word0, null);
        int l1 = oraclestatement.maxFieldSize;
        if(l1 > 0 && (j == 0 || l1 < j))
            j = l1;
        initForDataAccess(0, j, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        isStream = true;
        isColumnNumberAware = true;
        internalTypeMaxLength = 0x7fffffff;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        charLength = 0;
        stream = statement.connection.driverExtension.createInputStream(statement, columnPosition, this);
    }

    OracleInputStream initForNewRow()
        throws SQLException
    {
        stream = statement.connection.driverExtension.createInputStream(statement, columnPosition, this);
        return stream;
    }

    void updateColumnNumber(int i)
    {
        i++;
        columnPosition = i;
        if(stream != null)
            stream.columnIndex = i;
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        return getBytesInternal(i);
    }

    byte[] getBytesInternal(int i)
        throws SQLException
    {
        byte abyte0[] = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1 && stream != null)
        {
            if(stream.closed)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(1024);
            byte abyte1[] = new byte[1024];
            int j;
            try
            {
                while((j = stream.read(abyte1)) != -1) 
                    bytearrayoutputstream.write(abyte1, 0, j);
            }
            catch(IOException ioexception)
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
            abyte0 = bytearrayoutputstream.toByteArray();
        }
        return abyte0;
    }

    String getString(int i)
        throws SQLException
    {
        String s = null;
        byte abyte0[] = getBytes(i);
        if(abyte0 != null)
        {
            int j = Math.min(abyte0.length, internalTypeMaxLength);
            if(j == 0)
                s = "";
            else
            if(formOfUse == 2)
                s = statement.connection.conversion.NCharBytesToString(abyte0, j);
            else
                s = statement.connection.conversion.CharBytesToString(abyte0, j);
        }
        return s;
    }

    InputStream getAsciiStream(int i)
        throws SQLException
    {
        InputStream inputstream = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1 && stream != null)
        {
            if(stream.closed)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            inputstream = physicalconnection.conversion.ConvertStream(stream, 0);
        }
        return inputstream;
    }

    InputStream getUnicodeStream(int i)
        throws SQLException
    {
        InputStream inputstream = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1 && stream != null)
        {
            if(stream.closed)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            inputstream = physicalconnection.conversion.ConvertStream(stream, 1);
        }
        return inputstream;
    }

    Reader getCharacterStream(int i)
        throws SQLException
    {
        Reader reader = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1 && stream != null)
        {
            if(stream.closed)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            reader = physicalconnection.conversion.ConvertCharacterStream(stream, 9, formOfUse);
        }
        return reader;
    }

    InputStream getBinaryStream(int i)
        throws SQLException
    {
        InputStream inputstream = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1 && stream != null)
        {
            if(stream.closed)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            inputstream = physicalconnection.conversion.ConvertStream(stream, 6);
        }
        return inputstream;
    }

    public String toString()
    {
        return (new StringBuilder()).append("LongAccessor@").append(Integer.toHexString(hashCode())).append("{columnPosition = ").append(columnPosition).append("}").toString();
    }

}
