// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFDCNTableChanges.java

package oracle.jdbc.driver;

import java.nio.ByteBuffer;
import java.util.EnumSet;
import oracle.jdbc.dcn.RowChangeDescription;
import oracle.jdbc.dcn.TableChangeDescription;
import oracle.sql.CharacterSet;

// Referenced classes of package oracle.jdbc.driver:
//            NTFDCNRowChanges

class NTFDCNTableChanges
    implements TableChangeDescription
{

    final EnumSet opcode;
    String tableName;
    final int objectNumber;
    final int numberOfRows;
    final oracle.jdbc.dcn.RowChangeDescription.RowOperation rowOpcode[];
    final int rowIdLength[];
    final byte rowid[][];
    final CharacterSet charset;
    NTFDCNRowChanges rowsDescription[];
    private static final byte OPERATION_ANY = 0;
    private static final byte OPERATION_UNKNOWN = 64;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFDCNTableChanges(ByteBuffer bytebuffer, int i)
    {
        rowsDescription = null;
        charset = CharacterSet.make(i);
        opcode = oracle.jdbc.dcn.TableChangeDescription.TableOperation.getTableOperations(bytebuffer.getInt());
        short word0 = bytebuffer.getShort();
        byte abyte0[] = new byte[word0];
        bytebuffer.get(abyte0, 0, word0);
        tableName = charset.toStringWithReplacement(abyte0, 0, word0);
        objectNumber = bytebuffer.getInt();
        if(!opcode.contains(oracle.jdbc.dcn.TableChangeDescription.TableOperation.ALL_ROWS))
        {
            numberOfRows = bytebuffer.getShort();
            rowOpcode = new oracle.jdbc.dcn.RowChangeDescription.RowOperation[numberOfRows];
            rowIdLength = new int[numberOfRows];
            rowid = new byte[numberOfRows][];
            for(int j = 0; j < numberOfRows; j++)
            {
                rowOpcode[j] = oracle.jdbc.dcn.RowChangeDescription.RowOperation.getRowOperation(bytebuffer.getInt());
                rowIdLength[j] = bytebuffer.getShort();
                rowid[j] = new byte[rowIdLength[j]];
                bytebuffer.get(rowid[j], 0, rowIdLength[j]);
            }

        } else
        {
            numberOfRows = 0;
            rowid = (byte[][])null;
            rowOpcode = null;
            rowIdLength = null;
        }
    }

    public String getTableName()
    {
        return tableName;
    }

    public int getObjectNumber()
    {
        return objectNumber;
    }

    public RowChangeDescription[] getRowChangeDescription()
    {
        if(rowsDescription == null)
            synchronized(this)
            {
                if(rowsDescription == null)
                {
                    rowsDescription = new NTFDCNRowChanges[numberOfRows];
                    for(int i = 0; i < rowsDescription.length; i++)
                        rowsDescription[i] = new NTFDCNRowChanges(rowOpcode[i], rowIdLength[i], rowid[i]);

                }
            }
        return rowsDescription;
    }

    public EnumSet getTableOperations()
    {
        return opcode;
    }

    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append((new StringBuilder()).append("    operation=").append(getTableOperations()).append(", tableName=").append(tableName).append(", objectNumber=").append(objectNumber).append("\n").toString());
        RowChangeDescription arowchangedescription[] = getRowChangeDescription();
        if(arowchangedescription != null && arowchangedescription.length > 0)
        {
            stringbuffer.append((new StringBuilder()).append("    Row Change Description (length=").append(arowchangedescription.length).append("):\n").toString());
            for(int i = 0; i < arowchangedescription.length; i++)
                stringbuffer.append(arowchangedescription[i].toString());

        }
        return stringbuffer.toString();
    }

}
