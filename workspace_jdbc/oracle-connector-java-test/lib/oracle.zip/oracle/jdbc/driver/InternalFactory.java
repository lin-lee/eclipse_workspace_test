// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   InternalFactory.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.aq.AQMessageProperties;

// Referenced classes of package oracle.jdbc.driver:
//            KeywordValueI, KeywordValueLongI, XSAttributeI, XSNamespaceI, 
//            AQMessagePropertiesI, AQAgentI, AQMessageI, T4CRowidAccessor

public abstract class InternalFactory
{

    public InternalFactory()
    {
    }

    public static KeywordValueI createKeywordValue(int i, String s, byte abyte0[])
        throws SQLException
    {
        return new KeywordValueI(i, s, abyte0);
    }

    public static KeywordValueLongI createKeywordValueLong(int i, String s, byte abyte0[])
        throws SQLException
    {
        return new KeywordValueLongI(i, s, abyte0);
    }

    public static XSAttributeI createXSAttribute()
        throws SQLException
    {
        return new XSAttributeI();
    }

    public static XSNamespaceI createXSNamespace()
        throws SQLException
    {
        return new XSNamespaceI();
    }

    public static AQMessagePropertiesI createAQMessageProperties()
        throws SQLException
    {
        return new AQMessagePropertiesI();
    }

    public static AQAgentI createAQAgent()
        throws SQLException
    {
        return new AQAgentI();
    }

    public static AQMessageI createAQMessage(AQMessageProperties aqmessageproperties)
        throws SQLException
    {
        return new AQMessageI((AQMessagePropertiesI)aqmessageproperties);
    }

    public static byte[] urowid2rowid(long al[])
    {
        return T4CRowidAccessor.rowidToString(al);
    }

    public static long[] rowid2urowid(byte abyte0[], int i, int j)
        throws SQLException
    {
        return T4CRowidAccessor.stringToRowid(abyte0, i, j);
    }
}
