// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleInputStream.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            OracleBufferedStream, OracleStatement, Accessor, PhysicalConnection, 
//            DatabaseError

abstract class OracleInputStream extends OracleBufferedStream
{

    int columnIndex;
    Accessor accessor;
    OracleInputStream nextStream;
    boolean hasBeenOpen;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleInputStream(OracleStatement oraclestatement, int i, Accessor accessor1)
    {
        super(oraclestatement, oraclestatement.connection.getDefaultStreamChunkSize());
        hasBeenOpen = false;
        closed = true;
        statement = oraclestatement;
        columnIndex = i;
        accessor = accessor1;
        nextStream = null;
        OracleInputStream oracleinputstream = statement.streamList;
        if(oracleinputstream == null || columnIndex < oracleinputstream.columnIndex)
        {
            nextStream = statement.streamList;
            statement.streamList = this;
        } else
        if(columnIndex == oracleinputstream.columnIndex)
        {
            nextStream = oracleinputstream.nextStream;
            oracleinputstream.nextStream = null;
            statement.streamList = this;
        } else
        {
            for(; oracleinputstream.nextStream != null && columnIndex > oracleinputstream.nextStream.columnIndex; oracleinputstream = oracleinputstream.nextStream);
            if(oracleinputstream.nextStream != null && columnIndex == oracleinputstream.nextStream.columnIndex)
            {
                nextStream = oracleinputstream.nextStream.nextStream;
                oracleinputstream.nextStream.nextStream = null;
                oracleinputstream.nextStream = this;
            } else
            {
                nextStream = oracleinputstream.nextStream;
                oracleinputstream.nextStream = this;
            }
        }
    }

    public String toString()
    {
        return (new StringBuilder()).append("OIS@").append(Integer.toHexString(hashCode())).append("{").append("statement = ").append(statement).append(", accessor = ").append(accessor).append(", nextStream = ").append(nextStream).append(", columnIndex = ").append(columnIndex).append(", hasBeenOpen = ").append(hasBeenOpen).append("}").toString();
    }

    public boolean needBytes(int i)
        throws IOException
    {
        if(closed)
            return false;
        if(pos >= count)
        {
            if(i > currentBufferSize)
            {
                currentBufferSize = Math.max(i, initialBufferSize);
                resizableBuffer = new byte[currentBufferSize];
            }
            try
            {
                int j = getBytes(currentBufferSize);
                pos = 0;
                count = j;
                if(count == -1)
                {
                    if(nextStream == null)
                        statement.connection.releaseLine();
                    closed = true;
                    accessor.fetchNextColumns();
                    return false;
                }
            }
            catch(SQLException sqlexception)
            {
                IOException ioexception = DatabaseError.createIOException(sqlexception);
                ioexception.fillInStackTrace();
                throw ioexception;
            }
        }
        return true;
    }

    public boolean isNull()
        throws IOException
    {
        boolean flag = false;
        try
        {
            flag = accessor.isNull(0);
        }
        catch(SQLException sqlexception)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
        return flag;
    }

    public boolean isClosed()
    {
        return closed;
    }

    public void close()
        throws IOException
    {
        synchronized(statement.connection)
        {
            if(!closed && hasBeenOpen)
            {
                for(; statement.nextStream != this; statement.nextStream = statement.nextStream.nextStream)
                    statement.nextStream.close();

                if(!isNull())
                    while(needBytes(Math.max(initialBufferSize, currentBufferSize))) 
                        pos = count;
                closed = true;
                resizableBuffer = null;
                currentBufferSize = 0;
            }
        }
    }

    public abstract int getBytes(int i)
        throws IOException;

}
