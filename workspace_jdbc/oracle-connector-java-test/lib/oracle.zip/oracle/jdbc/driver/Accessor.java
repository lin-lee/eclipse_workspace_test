// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   Accessor.java

package oracle.jdbc.driver;

import java.io.*;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.*;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oracore.OracleType;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            OracleStatement, DatabaseError, PhysicalConnection, CRC64, 
//            OracleInputStream

abstract class Accessor
{

    static final int FIXED_CHAR = 999;
    static final int CHAR = 96;
    static final int VARCHAR = 1;
    static final int VCS = 9;
    static final int LONG = 8;
    static final int NUMBER = 2;
    static final int VARNUM = 6;
    static final int BINARY_FLOAT = 100;
    static final int BINARY_DOUBLE = 101;
    static final int RAW = 23;
    static final int VBI = 15;
    static final int LONG_RAW = 24;
    static final int ROWID = 104;
    static final int RESULT_SET = 102;
    static final int RSET = 116;
    static final int DATE = 12;
    static final int BLOB = 113;
    static final int CLOB = 112;
    static final int BFILE = 114;
    static final int NAMED_TYPE = 109;
    static final int REF_TYPE = 111;
    static final int TIMESTAMP = 180;
    static final int TIMESTAMPTZ = 181;
    static final int TIMESTAMPLTZ = 231;
    static final int INTERVALYM = 182;
    static final int INTERVALDS = 183;
    static final int UROWID = 208;
    static final int PLSQL_INDEX_TABLE = 998;
    static final int T2S_OVERLONG_RAW = 997;
    static final int SET_CHAR_BYTES = 996;
    static final int NULL_TYPE = 995;
    static final int DML_RETURN_PARAM = 994;
    static final int ONLY_FORM_USABLE = 0;
    static final int NOT_USABLE = 1;
    static final int NO_NEED_TO_PREPARE = 2;
    static final int NEED_TO_PREPARE = 3;
    OracleStatement statement;
    boolean outBind;
    int internalType;
    int internalTypeMaxLength;
    boolean isStream;
    boolean isColumnNumberAware;
    short formOfUse;
    OracleType internalOtype;
    int externalType;
    String internalTypeName;
    String columnName;
    int describeType;
    int describeMaxLength;
    boolean nullable;
    int precision;
    int scale;
    int flags;
    int contflag;
    int total_elems;
    OracleType describeOtype;
    String describeTypeName;
    int definedColumnType;
    int definedColumnSize;
    int oacmxl;
    short udskpos;
    int lobPrefetchSizeForThisColumn;
    long prefetchedLobSize[];
    int prefetchedLobChunkSize[];
    byte prefetchedClobFormOfUse[];
    byte prefetchedLobData[][];
    char prefetchedLobCharData[][];
    int prefetchedLobDataL[];
    oracle.jdbc.OracleResultSetMetaData.SecurityAttribute securityAttribute;
    byte rowSpaceByte[];
    char rowSpaceChar[];
    short rowSpaceIndicator[];
    static final byte DATA_UNAUTHORIZED = 1;
    byte rowSpaceMetaData[];
    int columnIndex;
    int lengthIndex;
    int indicatorIndex;
    int metaDataIndex;
    int columnIndexLastRow;
    int lengthIndexLastRow;
    int indicatorIndexLastRow;
    int metaDataIndexLastRow;
    int byteLength;
    int charLength;
    int defineType;
    boolean isDMLReturnedParam;
    int lastRowProcessed;
    boolean isUseLess;
    int physicalColumnIndex;
    boolean isNullByDescribe;
    static final byte NULL_DATA_BYTES[] = {
        2, 3, 5, 7, 11, 13, 17, 19
    };
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    Accessor()
    {
        isStream = false;
        isColumnNumberAware = false;
        formOfUse = 2;
        definedColumnType = 0;
        definedColumnSize = 0;
        oacmxl = 0;
        udskpos = -1;
        lobPrefetchSizeForThisColumn = -1;
        prefetchedLobSize = null;
        prefetchedLobChunkSize = null;
        prefetchedClobFormOfUse = null;
        prefetchedLobData = (byte[][])null;
        prefetchedLobCharData = (char[][])null;
        prefetchedLobDataL = null;
        rowSpaceByte = null;
        rowSpaceChar = null;
        rowSpaceIndicator = null;
        rowSpaceMetaData = null;
        columnIndex = 0;
        lengthIndex = 0;
        indicatorIndex = 0;
        metaDataIndex = 0;
        columnIndexLastRow = 0;
        lengthIndexLastRow = 0;
        indicatorIndexLastRow = 0;
        metaDataIndexLastRow = 0;
        byteLength = 0;
        charLength = 0;
        isDMLReturnedParam = false;
        lastRowProcessed = 0;
        isUseLess = false;
        physicalColumnIndex = -2;
        isNullByDescribe = false;
    }

    void setOffsets(int i)
    {
        columnIndex = statement.defineByteSubRange;
        statement.defineByteSubRange = columnIndex + i * byteLength;
    }

    void init(OracleStatement oraclestatement, int i, int j, short word0, boolean flag)
        throws SQLException
    {
        statement = oraclestatement;
        outBind = flag;
        internalType = i;
        defineType = j;
        formOfUse = word0;
    }

    abstract void initForDataAccess(int i, int j, String s)
        throws SQLException;

    void initForDescribe(int i, int j, boolean flag, int k, int l, int i1, int j1, 
            int k1, short word0)
        throws SQLException
    {
        describeType = i;
        describeMaxLength = j;
        nullable = flag;
        precision = l;
        scale = i1;
        flags = k;
        contflag = j1;
        total_elems = k1;
        formOfUse = word0;
    }

    void initForDescribe(int i, int j, boolean flag, int k, int l, int i1, int j1, 
            int k1, short word0, String s)
        throws SQLException
    {
        describeTypeName = s;
        describeOtype = null;
        initForDescribe(i, j, flag, k, l, i1, j1, k1, word0);
    }

    OracleInputStream initForNewRow()
        throws SQLException
    {
        unimpl("initForNewRow");
        return null;
    }

    int useForDataAccessIfPossible(int i, int j, int k, String s)
        throws SQLException
    {
        byte byte0 = 3;
        int l = 0;
        int i1 = 0;
        if(internalType != 0)
            if(internalType != i)
                byte0 = 0;
            else
            if(rowSpaceIndicator != null)
            {
                l = byteLength;
                i1 = charLength;
            }
        if(byte0 == 3)
        {
            initForDataAccess(j, k, s);
            if(!outBind && l >= byteLength && i1 >= charLength)
                byte0 = 2;
        }
        return byte0;
    }

    boolean useForDescribeIfPossible(int i, int j, boolean flag, int k, int l, int i1, int j1, 
            int k1, short word0, String s)
        throws SQLException
    {
        if(externalType == 0 && i != describeType)
        {
            return false;
        } else
        {
            initForDescribe(i, j, flag, k, l, i1, j1, k1, word0, s);
            return true;
        }
    }

    void setFormOfUse(short word0)
    {
        formOfUse = word0;
    }

    void updateColumnNumber(int i)
    {
    }

    public String toString()
    {
        return (new StringBuilder()).append(super.toString()).append(", statement=").append(statement).append(", outBind=").append(outBind).append(", internalType=").append(internalType).append(", internalTypeMaxLength=").append(internalTypeMaxLength).append(", isStream=").append(isStream).append(", formOfUse=").append(formOfUse).append(", internalOtype=").append(internalOtype).append(", externalType=").append(externalType).append(", internalTypeName=").append(internalTypeName).append(", columnName=").append(columnName).append(", describeType=").append(describeType).append(", describeMaxLength=").append(describeMaxLength).append(", nullable=").append(nullable).append(", precision=").append(precision).append(", scale=").append(scale).append(", flags=").append(flags).append(", contflag=").append(contflag).append(", total_elems=").append(total_elems).append(", describeOtype=").append(describeOtype).append(", describeTypeName=").append(describeTypeName).append(", rowSpaceByte=").append(rowSpaceByte).append(", rowSpaceChar=").append(rowSpaceChar).append(", rowSpaceIndicator=").append(rowSpaceIndicator).append(", columnIndex=").append(columnIndex).append(", lengthIndex=").append(lengthIndex).append(", indicatorIndex=").append(indicatorIndex).append(", byteLength=").append(byteLength).append(", charLength=").append(charLength).toString();
    }

    void unimpl(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, (new StringBuilder()).append(s).append(" not implemented for ").append(getClass()).toString());
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    boolean getBoolean(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return false;
        } else
        {
            unimpl("getBoolean");
            return false;
        }
    }

    byte getByte(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return 0;
        } else
        {
            unimpl("getByte");
            return 0;
        }
    }

    oracle.jdbc.OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int i)
        throws SQLException
    {
        if(rowSpaceMetaData == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        byte byte0 = rowSpaceMetaData[metaDataIndex + 1 * i];
        if((byte0 & 1) != 0)
            return oracle.jdbc.OracleResultSet.AuthorizationIndicator.UNAUTHORIZED;
        if(securityAttribute == oracle.jdbc.OracleResultSetMetaData.SecurityAttribute.ENABLED || securityAttribute == oracle.jdbc.OracleResultSetMetaData.SecurityAttribute.NONE)
            return oracle.jdbc.OracleResultSet.AuthorizationIndicator.NONE;
        else
            return oracle.jdbc.OracleResultSet.AuthorizationIndicator.UNKNOWN;
    }

    short getShort(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return 0;
        } else
        {
            unimpl("getShort");
            return 0;
        }
    }

    int getInt(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return 0;
        } else
        {
            unimpl("getInt");
            return 0;
        }
    }

    long getLong(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return 0L;
        } else
        {
            unimpl("getLong");
            return 0L;
        }
    }

    float getFloat(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return 0.0F;
        } else
        {
            unimpl("getFloat");
            return 0.0F;
        }
    }

    double getDouble(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return 0.0D;
        } else
        {
            unimpl("getDouble");
            return 0.0D;
        }
    }

    BigDecimal getBigDecimal(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getBigDecimal");
            return null;
        }
    }

    BigDecimal getBigDecimal(int i, int j)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getBigDecimal");
            return null;
        }
    }

    String getString(int i)
        throws SQLException
    {
        return null;
    }

    Date getDate(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getDate");
            return null;
        }
    }

    Date getDate(int i, Calendar calendar)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getDate");
            return null;
        }
    }

    Time getTime(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getTime");
            return null;
        }
    }

    Time getTime(int i, Calendar calendar)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getTime");
            return null;
        }
    }

    Timestamp getTimestamp(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getTimestamp");
            return null;
        }
    }

    Timestamp getTimestamp(int i, Calendar calendar)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getTimestamp");
            return null;
        }
    }

    byte[] privateGetBytes(int i)
        throws SQLException
    {
        return getBytes(i);
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        byte abyte0[] = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            short word0 = rowSpaceIndicator[lengthIndex + i];
            int j = columnIndex + byteLength * i;
            abyte0 = new byte[word0];
            System.arraycopy(rowSpaceByte, j, abyte0, 0, word0);
        }
        return abyte0;
    }

    InputStream getAsciiStream(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getAsciiStream");
            return null;
        }
    }

    InputStream getUnicodeStream(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getUnicodeStream");
            return null;
        }
    }

    InputStream getBinaryStream(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getBinaryStream");
            return null;
        }
    }

    Object getObject(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getObject");
            return null;
        }
    }

    ResultSet getCursor(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getOracleObject");
            return null;
        }
    }

    ROWID getROWID(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    NUMBER getNUMBER(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getNUMBER");
            return null;
        }
    }

    DATE getDATE(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getDATE");
            return null;
        }
    }

    ARRAY getARRAY(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getARRAY");
            return null;
        }
    }

    STRUCT getSTRUCT(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getSTRUCT");
            return null;
        }
    }

    OPAQUE getOPAQUE(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getOPAQUE");
            return null;
        }
    }

    REF getREF(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getREF");
            return null;
        }
    }

    CHAR getCHAR(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getCHAR");
            return null;
        }
    }

    RAW getRAW(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getRAW");
            return null;
        }
    }

    BLOB getBLOB(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getBLOB");
            return null;
        }
    }

    CLOB getCLOB(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getCLOB");
            return null;
        }
    }

    BFILE getBFILE(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getBFILE");
            return null;
        }
    }

    CustomDatum getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        Datum datum = getOracleObject(i);
        return customdatumfactory.create(datum, 0);
    }

    ORAData getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException
    {
        Datum datum = getOracleObject(i);
        return oradatafactory.create(datum, 0);
    }

    Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        Datum datum = getOracleObject(i);
        Object obj = datum.toJdbc();
        return oracledatafactory.create(obj, 0);
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getObject");
            return null;
        }
    }

    Reader getCharacterStream(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getCharacterStream");
            return null;
        }
    }

    INTERVALYM getINTERVALYM(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getINTERVALYM");
            return null;
        }
    }

    INTERVALDS getINTERVALDS(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getINTERVALDS");
            return null;
        }
    }

    TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getTIMESTAMP");
            return null;
        }
    }

    TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getTIMESTAMPTZ");
            return null;
        }
    }

    TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getTIMESTAMPLTZ");
            return null;
        }
    }

    URL getURL(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getURL");
            return null;
        }
    }

    Datum[] getOraclePlsqlIndexTable(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getOraclePlsqlIndexTable");
            return null;
        }
    }

    NClob getNClob(int i)
        throws SQLException
    {
        if(formOfUse != 2)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, Integer.valueOf(columnIndex));
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return (NClob)getCLOB(i);
        }
    }

    String getNString(int i)
        throws SQLException
    {
        return getString(i);
    }

    SQLXML getSQLXML(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            return null;
        } else
        {
            unimpl("getSQLXML");
            return null;
        }
    }

    Reader getNCharacterStream(int i)
        throws SQLException
    {
        return getCharacterStream(i);
    }

    boolean isNull(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return rowSpaceIndicator[indicatorIndex + i] == -1;
        }
    }

    void setNull(int i, boolean flag)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            rowSpaceIndicator[indicatorIndex + i] = (short)(flag ? -1 : 0);
            return;
        }
    }

    void fetchNextColumns()
        throws SQLException
    {
    }

    void calculateSizeTmpByteArray()
    {
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 148);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void copyRow()
        throws SQLException, IOException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 148);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    int readStream(byte abyte0[], int i)
        throws SQLException, IOException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 148);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void initMetadata()
        throws SQLException
    {
    }

    void setDisplaySize(int i)
        throws SQLException
    {
        describeMaxLength = i;
    }

    void saveDataFromOldDefineBuffers(byte abyte0[], char ac[], short aword0[], int i, int j)
        throws SQLException
    {
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return statement.getConnectionDuringExceptionHandling();
    }

    long updateChecksum(long l, int i)
        throws SQLException
    {
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
        {
            CRC64 _tmp = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
        } else
        {
            short word0 = rowSpaceIndicator[lengthIndex + i];
            int j = columnIndex + byteLength * i;
            CRC64 _tmp1 = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, rowSpaceByte, j, word0);
        }
        return l;
    }

}
