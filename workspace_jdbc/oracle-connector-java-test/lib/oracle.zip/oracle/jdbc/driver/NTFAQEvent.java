// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFAQEvent.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.sql.SQLException;
import oracle.jdbc.aq.AQMessageProperties;
import oracle.jdbc.aq.AQNotificationEvent;
import oracle.sql.CharacterSet;
import oracle.sql.TIMESTAMP;

// Referenced classes of package oracle.jdbc.driver:
//            AQMessagePropertiesI, AQAgentI, NTFConnection

class NTFAQEvent extends AQNotificationEvent
{

    private String registrationString;
    private int namespace;
    private byte payload[];
    private String queueName;
    private byte messageId[];
    private String consumerName;
    private NTFConnection conn;
    private AQMessagePropertiesI msgProp;
    private oracle.jdbc.aq.AQNotificationEvent.EventType eventType;
    private oracle.jdbc.aq.AQNotificationEvent.AdditionalEventType additionalEventType;
    private ByteBuffer dataBuffer;
    private boolean isReady;
    private short databaseVersion;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFAQEvent(NTFConnection ntfconnection, short word0)
        throws IOException, InterruptedException
    {
        super(ntfconnection);
        queueName = null;
        messageId = null;
        consumerName = null;
        eventType = oracle.jdbc.aq.AQNotificationEvent.EventType.REGULAR;
        additionalEventType = oracle.jdbc.aq.AQNotificationEvent.AdditionalEventType.NONE;
        isReady = false;
        conn = ntfconnection;
        int i = conn.readInt();
        byte abyte0[] = new byte[i];
        conn.readBuffer(abyte0, 0, i);
        dataBuffer = ByteBuffer.wrap(abyte0);
        databaseVersion = word0;
    }

    private void initEvent()
        throws SQLException
    {
        byte byte0 = dataBuffer.get();
        int i = dataBuffer.getInt();
        byte abyte0[] = new byte[i];
        dataBuffer.get(abyte0, 0, i);
        registrationString = conn.charset.toString(abyte0, 0, i);
        byte byte1 = dataBuffer.get();
        int j = dataBuffer.getInt();
        byte abyte1[] = new byte[j];
        dataBuffer.get(abyte1, 0, j);
        namespace = abyte1[0];
        byte byte2 = dataBuffer.get();
        int k = dataBuffer.getInt();
        if(k > 0)
        {
            payload = new byte[k];
            dataBuffer.get(payload, 0, k);
        } else
        {
            payload = null;
        }
        if(dataBuffer.hasRemaining())
        {
            int l = 0;
            if(databaseVersion >= 10200)
            {
                byte byte3 = dataBuffer.get();
                int i1 = dataBuffer.getInt();
                l = dataBuffer.getInt();
            }
            byte byte4 = dataBuffer.get();
            int j1 = dataBuffer.getInt();
            byte abyte2[] = new byte[j1];
            dataBuffer.get(abyte2, 0, j1);
            queueName = conn.charset.toString(abyte2, 0, j1);
            byte byte5 = dataBuffer.get();
            int k1 = dataBuffer.getInt();
            messageId = new byte[k1];
            dataBuffer.get(messageId, 0, k1);
            byte byte6 = dataBuffer.get();
            int l1 = dataBuffer.getInt();
            byte abyte3[] = new byte[l1];
            dataBuffer.get(abyte3, 0, l1);
            consumerName = conn.charset.toString(abyte3, 0, l1);
            byte byte7 = dataBuffer.get();
            int i2 = dataBuffer.getInt();
            byte abyte4[] = new byte[i2];
            dataBuffer.get(abyte4, 0, i2);
            byte byte8 = dataBuffer.get();
            int j2 = dataBuffer.getInt();
            int k2 = dataBuffer.getInt();
            if(abyte4[0] == 1)
                k2 = -k2;
            int l2 = k2;
            byte byte9 = dataBuffer.get();
            int i3 = dataBuffer.getInt();
            int j3 = dataBuffer.getInt();
            byte byte10 = dataBuffer.get();
            int k3 = dataBuffer.getInt();
            byte abyte5[] = new byte[k3];
            dataBuffer.get(abyte5, 0, k3);
            byte byte11 = dataBuffer.get();
            int l3 = dataBuffer.getInt();
            int i4 = dataBuffer.getInt();
            if(abyte5[0] == 1)
                i4 = -i4;
            int j4 = i4;
            byte byte12 = dataBuffer.get();
            int k4 = dataBuffer.getInt();
            int l4 = dataBuffer.getInt();
            byte byte13 = dataBuffer.get();
            int i5 = dataBuffer.getInt();
            byte abyte6[] = new byte[i5];
            dataBuffer.get(abyte6, 0, i5);
            TIMESTAMP timestamp = new TIMESTAMP(abyte6);
            byte byte14 = dataBuffer.get();
            int j5 = dataBuffer.getInt();
            byte abyte7[] = new byte[j5];
            dataBuffer.get(abyte7, 0, j5);
            byte byte15 = abyte7[0];
            byte byte16 = dataBuffer.get();
            int k5 = dataBuffer.getInt();
            byte abyte8[] = new byte[k5];
            dataBuffer.get(abyte8, 0, k5);
            String s = conn.charset.toString(abyte8, 0, k5);
            byte byte17 = dataBuffer.get();
            int l5 = dataBuffer.getInt();
            byte abyte9[] = new byte[l5];
            dataBuffer.get(abyte9, 0, l5);
            String s1 = conn.charset.toString(abyte9, 0, l5);
            byte byte18 = dataBuffer.get();
            int i6 = dataBuffer.getInt();
            byte abyte10[] = null;
            if(i6 > 0)
            {
                abyte10 = new byte[i6];
                dataBuffer.get(abyte10, 0, i6);
            }
            byte byte19 = dataBuffer.get();
            int j6 = dataBuffer.getInt();
            byte abyte11[] = new byte[j6];
            dataBuffer.get(abyte11, 0, j6);
            String s2 = conn.charset.toString(abyte11, 0, j6);
            byte byte20 = dataBuffer.get();
            int k6 = dataBuffer.getInt();
            byte abyte12[] = new byte[k6];
            dataBuffer.get(abyte12, 0, k6);
            String s3 = conn.charset.toString(abyte12, 0, k6);
            byte byte21 = dataBuffer.get();
            int l6 = dataBuffer.getInt();
            byte byte22 = dataBuffer.get();
            msgProp = new AQMessagePropertiesI();
            msgProp.setAttempts(l4);
            msgProp.setCorrelation(s1);
            msgProp.setDelay(j3);
            msgProp.setEnqueueTime(timestamp.timestampValue());
            msgProp.setMessageState(oracle.jdbc.aq.AQMessageProperties.MessageState.getMessageState(byte15));
            if(databaseVersion >= 10200)
                msgProp.setDeliveryMode(oracle.jdbc.aq.AQMessageProperties.DeliveryMode.getDeliveryMode(l));
            msgProp.setPreviousQueueMessageId(abyte10);
            AQAgentI aqagenti = new AQAgentI();
            aqagenti.setAddress(s3);
            aqagenti.setName(s2);
            aqagenti.setProtocol(byte22);
            msgProp.setSender(aqagenti);
            msgProp.setPriority(l2);
            msgProp.setExpiration(j4);
            msgProp.setExceptionQueue(s);
        }
        isReady = true;
    }

    public AQMessageProperties getMessageProperties()
        throws SQLException
    {
        if(!isReady)
            initEvent();
        return msgProp;
    }

    public String getRegistration()
        throws SQLException
    {
        if(!isReady)
            initEvent();
        return registrationString;
    }

    public oracle.jdbc.aq.AQNotificationEvent.EventType getEventType()
    {
        return eventType;
    }

    public oracle.jdbc.aq.AQNotificationEvent.AdditionalEventType getAdditionalEventType()
    {
        return additionalEventType;
    }

    void setEventType(oracle.jdbc.aq.AQNotificationEvent.EventType eventtype)
        throws IOException
    {
        eventType = eventtype;
    }

    void setAdditionalEventType(oracle.jdbc.aq.AQNotificationEvent.AdditionalEventType additionaleventtype)
    {
        additionalEventType = additionaleventtype;
    }

    public byte[] getPayload()
        throws SQLException
    {
        if(!isReady)
            initEvent();
        return payload;
    }

    public String getQueueName()
        throws SQLException
    {
        if(!isReady)
            initEvent();
        return queueName;
    }

    public byte[] getMessageId()
        throws SQLException
    {
        if(!isReady)
            initEvent();
        return messageId;
    }

    public String getConsumerName()
        throws SQLException
    {
        if(!isReady)
            initEvent();
        return consumerName;
    }

    public String getConnectionInformation()
    {
        return conn.connectionDescription;
    }

    public String toString()
    {
        if(!isReady)
            try
            {
                initEvent();
            }
            catch(SQLException sqlexception)
            {
                return sqlexception.getMessage();
            }
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append((new StringBuilder()).append("Connection information  : ").append(conn.connectionDescription).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Event type              : ").append(eventType).append("\n").toString());
        if(additionalEventType != oracle.jdbc.aq.AQNotificationEvent.AdditionalEventType.NONE)
            stringbuffer.append((new StringBuilder()).append("Additional event type   : ").append(additionalEventType).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Namespace               : ").append(namespace).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Registration            : ").append(registrationString).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Queue name              : ").append(queueName).append("\n").toString());
        stringbuffer.append((new StringBuilder()).append("Consumer name           : ").append(consumerName).append("\n").toString());
        if(payload != null)
        {
            stringbuffer.append((new StringBuilder()).append("Payload length          : ").append(payload.length).append("\n").toString());
            stringbuffer.append((new StringBuilder()).append("Payload (first 50 bytes): ").append(byteBufferToHexString(payload, 50)).append("\n").toString());
        } else
        {
            stringbuffer.append("Payload                 : null\n");
        }
        stringbuffer.append((new StringBuilder()).append("Message ID              : ").append(byteBufferToHexString(messageId, 50)).append("\n").toString());
        if(msgProp != null)
            stringbuffer.append(msgProp.toString());
        return stringbuffer.toString();
    }

    static final String byteBufferToHexString(byte abyte0[], int i)
    {
        if(abyte0 == null)
            return null;
        int j = 0;
        boolean flag = true;
        StringBuffer stringbuffer = new StringBuffer();
        for(; j < abyte0.length && j < i; j++)
        {
            if(!flag)
                stringbuffer.append(' ');
            else
                flag = false;
            String s = Integer.toHexString(abyte0[j] & 0xff);
            if(s.length() == 1)
                s = (new StringBuilder()).append("0").append(s).toString();
            stringbuffer.append(s);
        }

        String s1 = stringbuffer.toString();
        return s1;
    }

}
