// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   BinaryFloatAccessor.java

package oracle.jdbc.driver;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.Map;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            Accessor, OracleStatement, DatabaseError

class BinaryFloatAccessor extends Accessor
{

    static final int MAXLENGTH = 4;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    BinaryFloatAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 100, 100, word0, flag);
        initForDataAccess(j, i, null);
    }

    BinaryFloatAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        init(oraclestatement, 100, 100, word0, false);
        initForDescribe(100, i, flag, j, k, l, i1, j1, word0, null);
        int k1 = oraclestatement.maxFieldSize;
        if(k1 > 0 && (i == 0 || k1 < i))
            i = k1;
        initForDataAccess(0, i, null);
    }

    void init(OracleStatement oraclestatement, int i, int j, int k, short word0, int l)
        throws SQLException
    {
        init(oraclestatement, i, j, word0, false);
        initForDataAccess(l, k, null);
    }

    void init(OracleStatement oraclestatement, int i, int j, int k, boolean flag, int l, int i1, 
            int j1, int k1, int l1, short word0)
        throws SQLException
    {
        init(oraclestatement, i, j, word0, false);
        initForDescribe(i, k, flag, l, i1, j1, k1, l1, word0, null);
        int i2 = oraclestatement.maxFieldSize;
        if(i2 > 0 && (k == 0 || i2 < k))
            k = i2;
        initForDataAccess(0, k, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        internalTypeMaxLength = 4;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        byteLength = internalTypeMaxLength;
    }

    float getFloat(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
            return 0.0F;
        int j = columnIndex + byteLength * i;
        int k = rowSpaceByte[j];
        int l = rowSpaceByte[j + 1];
        int i1 = rowSpaceByte[j + 2];
        int j1 = rowSpaceByte[j + 3];
        if((k & 0x80) != 0)
        {
            k &= 0x7f;
            l &= 0xff;
            i1 &= 0xff;
            j1 &= 0xff;
        } else
        {
            k = ~k & 0xff;
            l = ~l & 0xff;
            i1 = ~i1 & 0xff;
            j1 = ~j1 & 0xff;
        }
        int k1 = k << 24 | l << 16 | i1 << 8 | j1;
        return Float.intBitsToFloat(k1);
    }

    String getString(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            return Float.toString(getFloat(i));
        else
            return null;
    }

    Object getObject(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            return new Float(getFloat(i));
        else
            return null;
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            return new Float(getFloat(i));
        else
            return null;
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        return getBINARY_FLOAT(i);
    }

    BINARY_FLOAT getBINARY_FLOAT(int i)
        throws SQLException
    {
        BINARY_FLOAT binary_float = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            short word0 = rowSpaceIndicator[lengthIndex + i];
            int j = columnIndex + byteLength * i;
            byte abyte0[] = new byte[word0];
            System.arraycopy(rowSpaceByte, j, abyte0, 0, word0);
            binary_float = new BINARY_FLOAT(abyte0);
        }
        return binary_float;
    }

    NUMBER getNUMBER(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            return new NUMBER(getFloat(i));
        else
            return null;
    }

    BigInteger getBigInteger(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            return new BigInteger(getString(i));
        else
            return null;
    }

    BigDecimal getBigDecimal(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            return new BigDecimal(getString(i));
        else
            return null;
    }

    byte getByte(int i)
        throws SQLException
    {
        return (byte)(int)getFloat(i);
    }

    short getShort(int i)
        throws SQLException
    {
        return (short)(int)getFloat(i);
    }

    int getInt(int i)
        throws SQLException
    {
        return (int)getFloat(i);
    }

    long getLong(int i)
        throws SQLException
    {
        return (long)getFloat(i);
    }

    double getDouble(int i)
        throws SQLException
    {
        return (double)getFloat(i);
    }

}
