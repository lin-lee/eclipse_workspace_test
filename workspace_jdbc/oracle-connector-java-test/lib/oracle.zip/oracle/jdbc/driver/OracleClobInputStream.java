// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleClobInputStream.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.CLOB;

// Referenced classes of package oracle.jdbc.driver:
//            OracleBufferedStream, PhysicalConnection, DatabaseError

class OracleClobInputStream extends OracleBufferedStream
{

    protected long lobOffset;
    protected CLOB clob;
    protected long markedByte;
    protected boolean endOfStream;
    protected char charBuf[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleClobInputStream(CLOB clob1)
        throws SQLException
    {
        this(clob1, ((PhysicalConnection)clob1.getJavaSqlConnection()).getDefaultStreamChunkSize(), 1L);
    }

    public OracleClobInputStream(CLOB clob1, int i)
        throws SQLException
    {
        this(clob1, i, 1L);
    }

    public OracleClobInputStream(CLOB clob1, int i, long l)
        throws SQLException
    {
        super(i);
        if(clob1 == null || i <= 0 || l < 1L)
        {
            throw new IllegalArgumentException();
        } else
        {
            lobOffset = l;
            clob = clob1;
            markedByte = -1L;
            endOfStream = false;
            return;
        }
    }

    public boolean needBytes(int i)
        throws IOException
    {
        ensureOpen();
        if(pos >= count)
        {
            if(!endOfStream)
                try
                {
                    if(i > currentBufferSize)
                    {
                        currentBufferSize = Math.max(i, initialBufferSize);
                        PhysicalConnection physicalconnection = (PhysicalConnection)clob.getInternalConnection();
                        synchronized(physicalconnection)
                        {
                            resizableBuffer = physicalconnection.getByteBuffer(currentBufferSize);
                            charBuf = physicalconnection.getCharBuffer(currentBufferSize);
                        }
                    }
                    count = clob.getChars(lobOffset, currentBufferSize, charBuf);
                    for(int j = 0; j < count; j++)
                        resizableBuffer[j] = (byte)charBuf[j];

                    if(count < currentBufferSize)
                        endOfStream = true;
                    if(count > 0)
                    {
                        pos = 0;
                        lobOffset += count;
                        return true;
                    }
                }
                catch(SQLException sqlexception)
                {
                    IOException ioexception = DatabaseError.createIOException(sqlexception);
                    ioexception.fillInStackTrace();
                    throw ioexception;
                }
            return false;
        } else
        {
            return true;
        }
    }

    protected void ensureOpen()
        throws IOException
    {
        try
        {
            if(closed)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, null);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(SQLException sqlexception1)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception1);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
    }

    public boolean markSupported()
    {
        return true;
    }

    public void mark(int i)
    {
        if(i < 0)
        {
            throw new IllegalArgumentException(DatabaseError.findMessage(196, null));
        } else
        {
            markedByte = (lobOffset - (long)count) + (long)pos;
            return;
        }
    }

    public void markInternal(int i)
    {
    }

    public void reset()
        throws IOException
    {
        ensureOpen();
        if(markedByte < 0L)
        {
            throw new IOException(DatabaseError.findMessage(195, null));
        } else
        {
            lobOffset = markedByte;
            pos = count;
            endOfStream = false;
            return;
        }
    }

    public long skip(long l)
        throws IOException
    {
        ensureOpen();
        long l1 = 0L;
        if((long)(count - pos) >= l)
        {
            pos += l;
            l1 += l;
        } else
        {
            l1 += count - pos;
            pos = count;
            try
            {
                long l2 = 0L;
                l2 = (clob.length() - lobOffset) + 1L;
                if(l2 >= l - l1)
                {
                    lobOffset += l - l1;
                    l1 += l - l1;
                } else
                {
                    lobOffset += l2;
                    l1 += l2;
                }
            }
            catch(SQLException sqlexception)
            {
                IOException ioexception = DatabaseError.createIOException(sqlexception);
                ioexception.fillInStackTrace();
                throw ioexception;
            }
        }
        return l1;
    }

    public void close()
        throws IOException
    {
        if(closed)
            return;
        super.close();
        try
        {
            PhysicalConnection physicalconnection = (PhysicalConnection)clob.getInternalConnection();
            synchronized(physicalconnection)
            {
                if(charBuf != null)
                {
                    physicalconnection.cacheBuffer(charBuf);
                    charBuf = null;
                }
                if(resizableBuffer != null)
                {
                    physicalconnection.cacheBuffer(resizableBuffer);
                    resizableBuffer = null;
                }
                currentBufferSize = 0;
            }
        }
        catch(SQLException sqlexception)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
        break MISSING_BLOCK_LABEL_203;
        Exception exception1;
        exception1;
        try
        {
            PhysicalConnection physicalconnection2 = (PhysicalConnection)clob.getInternalConnection();
            synchronized(physicalconnection2)
            {
                if(charBuf != null)
                {
                    physicalconnection2.cacheBuffer(charBuf);
                    charBuf = null;
                }
                if(resizableBuffer != null)
                {
                    physicalconnection2.cacheBuffer(resizableBuffer);
                    resizableBuffer = null;
                }
                currentBufferSize = 0;
            }
        }
        catch(SQLException sqlexception1)
        {
            IOException ioexception1 = DatabaseError.createIOException(sqlexception1);
            ioexception1.fillInStackTrace();
            throw ioexception1;
        }
        throw exception1;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        try
        {
            return clob.getInternalConnection();
        }
        catch(Exception exception)
        {
            return null;
        }
    }

}
