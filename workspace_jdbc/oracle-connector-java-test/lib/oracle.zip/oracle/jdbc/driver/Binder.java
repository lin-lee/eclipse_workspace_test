// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            OraclePreparedStatement

abstract class Binder
{

    short type;
    int bytelen;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    Binder()
    {
    }

    abstract Binder copyingBinder();

    abstract void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
        throws SQLException;

    public String toString()
    {
        return (new StringBuilder()).append(getClass()).append(" [type = ").append(type).append(", bytelen = ").append(bytelen).append("]").toString();
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

    short updateInoutIndicatorValue(short word0)
    {
        return word0;
    }

    void lastBoundValueCleanup(OraclePreparedStatement oraclepreparedstatement, int i)
    {
    }

}
