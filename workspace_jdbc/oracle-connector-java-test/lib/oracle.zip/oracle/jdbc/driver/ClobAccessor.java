// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ClobAccessor.java

package oracle.jdbc.driver;

import java.io.*;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.Map;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            Accessor, DatabaseError, OracleStatement

class ClobAccessor extends Accessor
{

    static final int maxLength = 4000;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    ClobAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 112, 112, word0, flag);
        initForDataAccess(j, i, null);
    }

    ClobAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        init(oraclestatement, 112, 112, word0, false);
        initForDescribe(112, i, flag, j, k, l, i1, j1, word0, null);
        initForDataAccess(0, i, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        internalTypeMaxLength = 4000;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        byteLength = internalTypeMaxLength;
    }

    Object getObject(int i)
        throws SQLException
    {
        return getCLOB(i);
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        return getCLOB(i);
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        return getCLOB(i);
    }

    CLOB getCLOB(int i)
        throws SQLException
    {
        Object obj = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            int j = columnIndex + byteLength * i;
            short word0 = rowSpaceIndicator[lengthIndex + i];
            byte abyte0[] = new byte[word0];
            System.arraycopy(rowSpaceByte, j, abyte0, 0, word0);
            if(formOfUse == 1)
                obj = new CLOB(statement.connection, abyte0, formOfUse);
            else
                obj = new NCLOB(statement.connection, abyte0);
            if(lobPrefetchSizeForThisColumn != -1 && prefetchedLobSize != null)
            {
                ((CLOB) (obj)).setActivePrefetch(true);
                ((CLOB) (obj)).setLength(prefetchedLobSize[i]);
                ((CLOB) (obj)).setChunkSize(prefetchedLobChunkSize[i]);
                if(prefetchedLobDataL != null && prefetchedLobDataL[i] > 0)
                    initializeClobForPrefetch(i, ((CLOB) (obj)));
                else
                    ((CLOB) (obj)).setPrefetchedData(null);
            }
        }
        return ((CLOB) (obj));
    }

    NCLOB getNCLOB(int i)
        throws SQLException
    {
        if(formOfUse != 2)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return (NCLOB)getCLOB(i);
        }
    }

    void initializeClobForPrefetch(int i, CLOB clob)
        throws SQLException
    {
        clob.setPrefetchedData(prefetchedLobCharData[i]);
    }

    InputStream getAsciiStream(int i)
        throws SQLException
    {
        CLOB clob = getCLOB(i);
        if(clob == null)
            return null;
        else
            return clob.getAsciiStream();
    }

    Reader getCharacterStream(int i)
        throws SQLException
    {
        CLOB clob = getCLOB(i);
        if(clob == null)
            return null;
        else
            return clob.getCharacterStream();
    }

    InputStream getBinaryStream(int i)
        throws SQLException
    {
        CLOB clob = getCLOB(i);
        if(clob == null)
            return null;
        else
            return clob.getAsciiStream();
    }

    String getString(int i)
        throws SQLException
    {
        CLOB clob = getCLOB(i);
        if(clob == null)
            return null;
        Reader reader = clob.getCharacterStream();
        int j = clob.getBufferSize();
        int k = 0;
        StringWriter stringwriter = new StringWriter(j);
        char ac[] = new char[j];
        try
        {
            while((k = reader.read(ac)) != -1) 
                stringwriter.write(ac, 0, k);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        catch(IndexOutOfBoundsException indexoutofboundsexception)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(clob.isTemporary())
            statement.addToTempLobsToFree(clob);
        return stringwriter.getBuffer().substring(0);
    }

    byte[] privateGetBytes(int i)
        throws SQLException
    {
        return super.getBytes(i);
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    long checksum(long l, int i)
        throws SQLException
    {
        unimpl("checksum");
        return -1L;
    }

}
