// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NamedTypeAccessor.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.sql.SQLXML;
import java.util.Map;
import oracle.jdbc.OracleDataFactory;
import oracle.jdbc.oracore.OracleType;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            TypeAccessor, OracleConnection, OracleStatement, PhysicalConnection, 
//            DatabaseError, ClassRef

class NamedTypeAccessor extends TypeAccessor
{

    private static final Class xmlType;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NamedTypeAccessor(OracleStatement oraclestatement, String s, short word0, int i, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 109, 109, word0, flag);
        initForDataAccess(i, 0, s);
    }

    NamedTypeAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, String s)
        throws SQLException
    {
        init(oraclestatement, 109, 109, word0, false);
        initForDescribe(109, i, flag, j, k, l, i1, j1, word0, s);
        initForDataAccess(0, i, s);
    }

    NamedTypeAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, String s, OracleType oracletype)
        throws SQLException
    {
        init(oraclestatement, 109, 109, word0, false);
        describeOtype = oracletype;
        initForDescribe(109, i, flag, j, k, l, i1, j1, word0, s);
        internalOtype = oracletype;
        initForDataAccess(0, i, s);
    }

    OracleType otypeFromName(String s)
        throws SQLException
    {
        if(!outBind)
            return TypeDescriptor.getTypeDescriptor(s, statement.connection).getPickler();
        if(externalType == 2003)
            return ArrayDescriptor.createDescriptor(s, statement.connection).getOracleTypeCOLLECTION();
        if(externalType == 2007 || externalType == 2009)
            return OpaqueDescriptor.createDescriptor(s, statement.connection).getPickler();
        else
            return StructDescriptor.createDescriptor(s, statement.connection).getOracleTypeADT();
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        super.initForDataAccess(i, j, s);
        byteLength = statement.connection.namedTypeAccessorByteLen;
    }

    Object getObject(int i)
        throws SQLException
    {
        return getObject(i, statement.connection.getTypeMap());
    }

    Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        return oracledatafactory.create(getObject(i, statement.connection.getTypeMap()), 0);
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            if(externalType == 0)
            {
                Datum datum = getOracleObject(i);
                if(datum == null)
                    return null;
                if(datum instanceof STRUCT)
                    return ((STRUCT)datum).toJdbc(map);
                if(datum instanceof OPAQUE)
                {
                    Object obj = ((OPAQUE)datum).toJdbc(map);
                    return obj;
                } else
                {
                    return datum.toJdbc();
                }
            }
            switch(externalType)
            {
            case 2008: 
                map = null;
                // fall through

            case 2000: 
            case 2002: 
            case 2003: 
            case 2007: 
                Datum datum1 = getOracleObject(i);
                if(datum1 == null)
                    return null;
                if(datum1 instanceof STRUCT)
                    return ((STRUCT)datum1).toJdbc(map);
                else
                    return datum1.toJdbc();

            case 2009: 
                Datum datum2 = getOracleObject(i);
                if(datum2 == null)
                    return null;
                SQLException sqlexception1;
                try
                {
                    return (SQLXML)datum2;
                }
                catch(ClassCastException classcastexception)
                {
                    sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
                }
                sqlexception1.fillInStackTrace();
                throw sqlexception1;

            case 2001: 
            case 2004: 
            case 2005: 
            case 2006: 
            default:
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        } else
        {
            return null;
        }
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        Object obj = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        byte abyte0[] = pickledBytes(i);
        if(abyte0 == null || abyte0.length == 0)
            return null;
        PhysicalConnection physicalconnection = statement.connection;
        OracleTypeADT oracletypeadt = (OracleTypeADT)internalOtype;
        TypeDescriptor typedescriptor = TypeDescriptor.getTypeDescriptor(oracletypeadt.getFullName(), physicalconnection, abyte0, 0L);
        switch(typedescriptor.getTypeCode())
        {
        case 2003: 
            obj = new ARRAY((ArrayDescriptor)typedescriptor, abyte0, physicalconnection);
            break;

        case 2002: 
            obj = new STRUCT((StructDescriptor)typedescriptor, abyte0, physicalconnection);
            break;

        case 2009: 
            obj = ClassRef.XMLTYPE.createXML(new OPAQUE((OpaqueDescriptor)typedescriptor, abyte0, physicalconnection));
            break;

        case 2007: 
            obj = new OPAQUE((OpaqueDescriptor)typedescriptor, abyte0, physicalconnection);
            break;

        case 2008: 
            obj = new JAVA_STRUCT((StructDescriptor)typedescriptor, abyte0, physicalconnection);
            break;

        case 2004: 
        case 2005: 
        case 2006: 
        default:
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        return ((Datum) (obj));
    }

    ARRAY getARRAY(int i)
        throws SQLException
    {
        return (ARRAY)(ARRAY)getOracleObject(i);
    }

    STRUCT getSTRUCT(int i)
        throws SQLException
    {
        return (STRUCT)(STRUCT)getOracleObject(i);
    }

    OPAQUE getOPAQUE(int i)
        throws SQLException
    {
        return (OPAQUE)(OPAQUE)getOracleObject(i);
    }

    boolean isNull(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            byte abyte0[] = pickledBytes(i);
            return abyte0 == null || abyte0.length == 0;
        }
    }

    SQLXML getSQLXML(int i)
        throws SQLException
    {
        OPAQUE opaque;
        try
        {
            opaque = (OPAQUE)getOracleObject(i);
            if(opaque == null)
                return null;
        }
        catch(ClassCastException classcastexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return (SQLXML)opaque;
    }

    static 
    {
        Class class1 = null;
        try
        {
            class1 = Class.forName("oracle.xdb.XMLType");
        }
        catch(Throwable throwable) { }
        xmlType = class1;
    }
}
