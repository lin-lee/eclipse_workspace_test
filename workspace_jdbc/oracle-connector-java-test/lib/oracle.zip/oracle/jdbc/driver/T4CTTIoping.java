// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIoping.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CConnection

final class T4CTTIoping extends T4CTTIfun
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIoping(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        setFunCode((short)147);
    }

    void doOPING()
        throws IOException, SQLException
    {
        doRPC();
    }

    void marshal()
        throws IOException
    {
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
