// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFDCNQueryChanges.java

package oracle.jdbc.driver;

import java.nio.ByteBuffer;
import oracle.jdbc.dcn.QueryChangeDescription;
import oracle.jdbc.dcn.TableChangeDescription;

// Referenced classes of package oracle.jdbc.driver:
//            NTFDCNTableChanges

class NTFDCNQueryChanges
    implements QueryChangeDescription
{

    private final long queryId;
    private final oracle.jdbc.dcn.QueryChangeDescription.QueryChangeEventType queryopflags;
    private final int numberOfTables;
    private final NTFDCNTableChanges tcdesc[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFDCNQueryChanges(ByteBuffer bytebuffer, int i)
    {
        long l = bytebuffer.getInt() & -1;
        long l1 = bytebuffer.getInt() & -1;
        queryId = l | l1 << 32;
        queryopflags = oracle.jdbc.dcn.QueryChangeDescription.QueryChangeEventType.getQueryChangeEventType(bytebuffer.getInt());
        numberOfTables = bytebuffer.getShort();
        tcdesc = new NTFDCNTableChanges[numberOfTables];
        for(int j = 0; j < tcdesc.length; j++)
            tcdesc[j] = new NTFDCNTableChanges(bytebuffer, i);

    }

    public long getQueryId()
    {
        return queryId;
    }

    public oracle.jdbc.dcn.QueryChangeDescription.QueryChangeEventType getQueryChangeEventType()
    {
        return queryopflags;
    }

    public TableChangeDescription[] getTableChangeDescription()
    {
        return tcdesc;
    }

    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append((new StringBuilder()).append("  query ID=").append(queryId).append(", query change event type=").append(queryopflags).append("\n").toString());
        TableChangeDescription atablechangedescription[] = getTableChangeDescription();
        if(atablechangedescription != null)
        {
            stringbuffer.append((new StringBuilder()).append("  Table Change Description (length=").append(atablechangedescription.length).append("):").toString());
            for(int i = 0; i < atablechangedescription.length; i++)
                stringbuffer.append(atablechangedescription[i].toString());

        }
        return stringbuffer.toString();
    }

}
