// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;


// Referenced classes of package oracle.jdbc.driver:
//            Binder, OraclePreparedStatement, OraclePreparedStatementReadOnly

class BinaryDoubleBinder extends Binder
{

    Binder theBinaryDoubleCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    static void init(Binder binder)
    {
        binder.type = 101;
        binder.bytelen = 8;
    }

    BinaryDoubleBinder()
    {
        theBinaryDoubleCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleCopyingBinder;
        init(this);
    }

    Binder copyingBinder()
    {
        return theBinaryDoubleCopyingBinder;
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
    {
        byte abyte1[] = abyte0;
        int j2 = j1;
        double d = oraclepreparedstatement.parameterDouble[k][i];
        if(d == 0.0D)
            d = 0.0D;
        else
        if(d != d)
            d = (0.0D / 0.0D);
        long l2 = Double.doubleToLongBits(d);
        int k2 = (int)l2;
        int i3 = (int)(l2 >> 32);
        int j3 = k2;
        k2 >>= 8;
        int k3 = k2;
        k2 >>= 8;
        int l3 = k2;
        k2 >>= 8;
        int i4 = k2;
        int j4 = i3;
        i3 >>= 8;
        int k4 = i3;
        i3 >>= 8;
        int l4 = i3;
        i3 >>= 8;
        int i5 = i3;
        if((i5 & 0x80) == 0)
        {
            i5 |= 0x80;
        } else
        {
            i5 = ~i5;
            l4 = ~l4;
            k4 = ~k4;
            j4 = ~j4;
            i4 = ~i4;
            l3 = ~l3;
            k3 = ~k3;
            j3 = ~j3;
        }
        abyte1[j2 + 7] = (byte)j3;
        abyte1[j2 + 6] = (byte)k3;
        abyte1[j2 + 5] = (byte)l3;
        abyte1[j2 + 4] = (byte)i4;
        abyte1[j2 + 3] = (byte)j4;
        abyte1[j2 + 2] = (byte)k4;
        abyte1[j2 + 1] = (byte)l4;
        abyte1[j2] = (byte)i5;
        aword0[i2] = 0;
        aword0[l1] = 8;
    }

}
