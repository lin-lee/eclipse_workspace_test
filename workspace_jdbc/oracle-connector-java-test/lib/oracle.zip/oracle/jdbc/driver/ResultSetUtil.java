// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ResultSetUtil.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            UpdatableResultSet, OracleResultSetImpl, ScrollableResultSet, SensitiveScrollableResultSet, 
//            DatabaseError, ScrollRsetStatement, OracleResultSet

class ResultSetUtil
{

    static final int allRsetTypes[][] = {
        {
            0, 0
        }, {
            1003, 1007
        }, {
            1003, 1008
        }, {
            1004, 1007
        }, {
            1004, 1008
        }, {
            1005, 1007
        }, {
            1005, 1008
        }
    };
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    ResultSetUtil()
    {
    }

    static OracleResultSet createScrollResultSet(ScrollRsetStatement scrollrsetstatement, OracleResultSet oracleresultset, int i)
        throws SQLException
    {
        switch(i)
        {
        case 1: // '\001'
            return oracleresultset;

        case 2: // '\002'
            return new UpdatableResultSet(scrollrsetstatement, (OracleResultSetImpl)oracleresultset, getScrollType(i), getUpdateConcurrency(i));

        case 3: // '\003'
            return new ScrollableResultSet(scrollrsetstatement, (OracleResultSetImpl)oracleresultset, getScrollType(i), getUpdateConcurrency(i));

        case 4: // '\004'
            ScrollableResultSet scrollableresultset = new ScrollableResultSet(scrollrsetstatement, (OracleResultSetImpl)oracleresultset, getScrollType(i), getUpdateConcurrency(i));
            return new UpdatableResultSet(scrollrsetstatement, scrollableresultset, getScrollType(i), getUpdateConcurrency(i));

        case 5: // '\005'
            return new SensitiveScrollableResultSet(scrollrsetstatement, (OracleResultSetImpl)oracleresultset, getScrollType(i), getUpdateConcurrency(i));

        case 6: // '\006'
            SensitiveScrollableResultSet sensitivescrollableresultset = new SensitiveScrollableResultSet(scrollrsetstatement, (OracleResultSetImpl)oracleresultset, getScrollType(i), getUpdateConcurrency(i));
            return new UpdatableResultSet(scrollrsetstatement, sensitivescrollableresultset, getScrollType(i), getUpdateConcurrency(i));
        }
        SQLException sqlexception = DatabaseError.createSqlException(null, 23, null);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    static int getScrollType(int i)
    {
        return allRsetTypes[i][0];
    }

    static int getUpdateConcurrency(int i)
    {
        return allRsetTypes[i][1];
    }

    static int getRsetTypeCode(int i, int j)
        throws SQLException
    {
        for(int k = 0; k < allRsetTypes.length; k++)
            if(allRsetTypes[k][0] == i && allRsetTypes[k][1] == j)
                return k;

        SQLException sqlexception = DatabaseError.createSqlException(null, 68);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    static boolean needIdentifier(int i)
        throws SQLException
    {
        return i != 1 && i != 3;
    }

    static boolean needIdentifier(int i, int j)
        throws SQLException
    {
        return needIdentifier(getRsetTypeCode(i, j));
    }

    static boolean needCache(int i)
        throws SQLException
    {
        return i >= 3;
    }

    static boolean needCache(int i, int j)
        throws SQLException
    {
        return needCache(getRsetTypeCode(i, j));
    }

    static boolean supportRefreshRow(int i)
        throws SQLException
    {
        return i >= 4;
    }

    static boolean supportRefreshRow(int i, int j)
        throws SQLException
    {
        return supportRefreshRow(getRsetTypeCode(i, j));
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
