// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatementWrapper.java

package oracle.jdbc.driver;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import oracle.jdbc.OracleParameterMetaData;
import oracle.jdbc.internal.OraclePreparedStatement;
import oracle.sql.ARRAY;
import oracle.sql.BFILE;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BLOB;
import oracle.sql.CHAR;
import oracle.sql.CLOB;
import oracle.sql.CustomDatum;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.NUMBER;
import oracle.sql.OPAQUE;
import oracle.sql.ORAData;
import oracle.sql.RAW;
import oracle.sql.REF;
import oracle.sql.ROWID;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;

// Referenced classes of package oracle.jdbc.driver:
//            OracleStatementWrapper

class OraclePreparedStatementWrapper extends OracleStatementWrapper
    implements OraclePreparedStatement
{

    protected OraclePreparedStatement preparedStatement;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OraclePreparedStatementWrapper(oracle.jdbc.OraclePreparedStatement oraclepreparedstatement)
        throws SQLException
    {
        super(oraclepreparedstatement);
        preparedStatement = null;
        preparedStatement = (OraclePreparedStatement)oraclepreparedstatement;
    }

    public void close()
        throws SQLException
    {
        super.close();
        preparedStatement = OracleStatementWrapper.closedStatement;
    }

    public void closeWithKey(String s)
        throws SQLException
    {
        preparedStatement.closeWithKey(s);
        statement = preparedStatement = closedStatement;
    }

    public void setArray(int i, Array array)
        throws SQLException
    {
        preparedStatement.setArray(i, array);
    }

    public void setBigDecimal(int i, BigDecimal bigdecimal)
        throws SQLException
    {
        preparedStatement.setBigDecimal(i, bigdecimal);
    }

    public void setBlob(int i, Blob blob)
        throws SQLException
    {
        preparedStatement.setBlob(i, blob);
    }

    public void setBoolean(int i, boolean flag)
        throws SQLException
    {
        preparedStatement.setBoolean(i, flag);
    }

    public void setByte(int i, byte byte0)
        throws SQLException
    {
        preparedStatement.setByte(i, byte0);
    }

    public void setBytes(int i, byte abyte0[])
        throws SQLException
    {
        preparedStatement.setBytes(i, abyte0);
    }

    public void setClob(int i, Clob clob)
        throws SQLException
    {
        preparedStatement.setClob(i, clob);
    }

    public void setDate(int i, Date date)
        throws SQLException
    {
        preparedStatement.setDate(i, date);
    }

    public void setDate(int i, Date date, Calendar calendar)
        throws SQLException
    {
        preparedStatement.setDate(i, date, calendar);
    }

    public void setDouble(int i, double d)
        throws SQLException
    {
        preparedStatement.setDouble(i, d);
    }

    public void setFloat(int i, float f)
        throws SQLException
    {
        preparedStatement.setFloat(i, f);
    }

    public void setInt(int i, int j)
        throws SQLException
    {
        preparedStatement.setInt(i, j);
    }

    public void setLong(int i, long l)
        throws SQLException
    {
        preparedStatement.setLong(i, l);
    }

    public void setNClob(int i, NClob nclob)
        throws SQLException
    {
        preparedStatement.setNClob(i, nclob);
    }

    public void setNString(int i, String s)
        throws SQLException
    {
        preparedStatement.setNString(i, s);
    }

    public void setObject(int i, Object obj)
        throws SQLException
    {
        preparedStatement.setObject(i, obj);
    }

    public void setObject(int i, Object obj, int j)
        throws SQLException
    {
        preparedStatement.setObject(i, obj, j);
    }

    public void setRef(int i, Ref ref)
        throws SQLException
    {
        preparedStatement.setRef(i, ref);
    }

    public void setRowId(int i, RowId rowid)
        throws SQLException
    {
        preparedStatement.setRowId(i, rowid);
    }

    public void setShort(int i, short word0)
        throws SQLException
    {
        preparedStatement.setShort(i, word0);
    }

    public void setSQLXML(int i, SQLXML sqlxml)
        throws SQLException
    {
        preparedStatement.setSQLXML(i, sqlxml);
    }

    public void setString(int i, String s)
        throws SQLException
    {
        preparedStatement.setString(i, s);
    }

    public void setTime(int i, Time time)
        throws SQLException
    {
        preparedStatement.setTime(i, time);
    }

    public void setTime(int i, Time time, Calendar calendar)
        throws SQLException
    {
        preparedStatement.setTime(i, time, calendar);
    }

    public void setTimestamp(int i, Timestamp timestamp)
        throws SQLException
    {
        preparedStatement.setTimestamp(i, timestamp);
    }

    public void setTimestamp(int i, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        preparedStatement.setTimestamp(i, timestamp, calendar);
    }

    public void setURL(int i, URL url)
        throws SQLException
    {
        preparedStatement.setURL(i, url);
    }

    public void setARRAY(int i, ARRAY array)
        throws SQLException
    {
        preparedStatement.setARRAY(i, array);
    }

    public void setBFILE(int i, BFILE bfile)
        throws SQLException
    {
        preparedStatement.setBFILE(i, bfile);
    }

    public void setBfile(int i, BFILE bfile)
        throws SQLException
    {
        preparedStatement.setBfile(i, bfile);
    }

    public void setBinaryFloat(int i, float f)
        throws SQLException
    {
        preparedStatement.setBinaryFloat(i, f);
    }

    public void setBinaryFloat(int i, BINARY_FLOAT binary_float)
        throws SQLException
    {
        preparedStatement.setBinaryFloat(i, binary_float);
    }

    public void setBinaryDouble(int i, double d)
        throws SQLException
    {
        preparedStatement.setBinaryDouble(i, d);
    }

    public void setBinaryDouble(int i, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        preparedStatement.setBinaryDouble(i, binary_double);
    }

    public void setBLOB(int i, BLOB blob)
        throws SQLException
    {
        preparedStatement.setBLOB(i, blob);
    }

    public void setCHAR(int i, CHAR char1)
        throws SQLException
    {
        preparedStatement.setCHAR(i, char1);
    }

    public void setCLOB(int i, CLOB clob)
        throws SQLException
    {
        preparedStatement.setCLOB(i, clob);
    }

    public void setCursor(int i, ResultSet resultset)
        throws SQLException
    {
        preparedStatement.setCursor(i, resultset);
    }

    public void setCustomDatum(int i, CustomDatum customdatum)
        throws SQLException
    {
        preparedStatement.setCustomDatum(i, customdatum);
    }

    public void setDATE(int i, DATE date)
        throws SQLException
    {
        preparedStatement.setDATE(i, date);
    }

    public void setFixedCHAR(int i, String s)
        throws SQLException
    {
        preparedStatement.setFixedCHAR(i, s);
    }

    public void setINTERVALDS(int i, INTERVALDS intervalds)
        throws SQLException
    {
        preparedStatement.setINTERVALDS(i, intervalds);
    }

    public void setINTERVALYM(int i, INTERVALYM intervalym)
        throws SQLException
    {
        preparedStatement.setINTERVALYM(i, intervalym);
    }

    public void setNUMBER(int i, NUMBER number)
        throws SQLException
    {
        preparedStatement.setNUMBER(i, number);
    }

    public void setOPAQUE(int i, OPAQUE opaque)
        throws SQLException
    {
        preparedStatement.setOPAQUE(i, opaque);
    }

    public void setOracleObject(int i, Datum datum)
        throws SQLException
    {
        preparedStatement.setOracleObject(i, datum);
    }

    public void setORAData(int i, ORAData oradata)
        throws SQLException
    {
        preparedStatement.setORAData(i, oradata);
    }

    public void setRAW(int i, RAW raw)
        throws SQLException
    {
        preparedStatement.setRAW(i, raw);
    }

    public void setREF(int i, REF ref)
        throws SQLException
    {
        preparedStatement.setREF(i, ref);
    }

    public void setRefType(int i, REF ref)
        throws SQLException
    {
        preparedStatement.setRefType(i, ref);
    }

    public void setROWID(int i, ROWID rowid)
        throws SQLException
    {
        preparedStatement.setROWID(i, rowid);
    }

    public void setSTRUCT(int i, STRUCT struct)
        throws SQLException
    {
        preparedStatement.setSTRUCT(i, struct);
    }

    public void setTIMESTAMPLTZ(int i, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        preparedStatement.setTIMESTAMPLTZ(i, timestampltz);
    }

    public void setTIMESTAMPTZ(int i, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        preparedStatement.setTIMESTAMPTZ(i, timestamptz);
    }

    public void setTIMESTAMP(int i, TIMESTAMP timestamp)
        throws SQLException
    {
        preparedStatement.setTIMESTAMP(i, timestamp);
    }

    public void setBlob(int i, InputStream inputstream)
        throws SQLException
    {
        preparedStatement.setBlob(i, inputstream);
    }

    public void setBlob(int i, InputStream inputstream, long l)
        throws SQLException
    {
        preparedStatement.setBlob(i, inputstream, l);
    }

    public void setClob(int i, Reader reader)
        throws SQLException
    {
        preparedStatement.setClob(i, reader);
    }

    public void setClob(int i, Reader reader, long l)
        throws SQLException
    {
        preparedStatement.setClob(i, reader, l);
    }

    public void setNClob(int i, Reader reader)
        throws SQLException
    {
        preparedStatement.setNClob(i, reader);
    }

    public void setNClob(int i, Reader reader, long l)
        throws SQLException
    {
        preparedStatement.setNClob(i, reader, l);
    }

    public void setAsciiStream(int i, InputStream inputstream)
        throws SQLException
    {
        preparedStatement.setAsciiStream(i, inputstream);
    }

    public void setAsciiStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        preparedStatement.setAsciiStream(i, inputstream, j);
    }

    public void setAsciiStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        preparedStatement.setAsciiStream(i, inputstream, l);
    }

    public void setBinaryStream(int i, InputStream inputstream)
        throws SQLException
    {
        preparedStatement.setBinaryStream(i, inputstream);
    }

    public void setBinaryStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        preparedStatement.setBinaryStream(i, inputstream, j);
    }

    public void setBinaryStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        preparedStatement.setBinaryStream(i, inputstream, l);
    }

    public void setCharacterStream(int i, Reader reader)
        throws SQLException
    {
        preparedStatement.setCharacterStream(i, reader);
    }

    public void setCharacterStream(int i, Reader reader, int j)
        throws SQLException
    {
        preparedStatement.setCharacterStream(i, reader, j);
    }

    public void setCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        preparedStatement.setCharacterStream(i, reader, l);
    }

    public void setNCharacterStream(int i, Reader reader)
        throws SQLException
    {
        preparedStatement.setNCharacterStream(i, reader);
    }

    public void setNCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        preparedStatement.setNCharacterStream(i, reader, l);
    }

    public void setUnicodeStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        preparedStatement.setUnicodeStream(i, inputstream, j);
    }

    public void setArrayAtName(String s, Array array)
        throws SQLException
    {
        preparedStatement.setArrayAtName(s, array);
    }

    public void setBigDecimalAtName(String s, BigDecimal bigdecimal)
        throws SQLException
    {
        preparedStatement.setBigDecimalAtName(s, bigdecimal);
    }

    public void setBlobAtName(String s, Blob blob)
        throws SQLException
    {
        preparedStatement.setBlobAtName(s, blob);
    }

    public void setBooleanAtName(String s, boolean flag)
        throws SQLException
    {
        preparedStatement.setBooleanAtName(s, flag);
    }

    public void setByteAtName(String s, byte byte0)
        throws SQLException
    {
        preparedStatement.setByteAtName(s, byte0);
    }

    public void setBytesAtName(String s, byte abyte0[])
        throws SQLException
    {
        preparedStatement.setBytesAtName(s, abyte0);
    }

    public void setClobAtName(String s, Clob clob)
        throws SQLException
    {
        preparedStatement.setClobAtName(s, clob);
    }

    public void setDateAtName(String s, Date date)
        throws SQLException
    {
        preparedStatement.setDateAtName(s, date);
    }

    public void setDateAtName(String s, Date date, Calendar calendar)
        throws SQLException
    {
        preparedStatement.setDateAtName(s, date, calendar);
    }

    public void setDoubleAtName(String s, double d)
        throws SQLException
    {
        preparedStatement.setDoubleAtName(s, d);
    }

    public void setFloatAtName(String s, float f)
        throws SQLException
    {
        preparedStatement.setFloatAtName(s, f);
    }

    public void setIntAtName(String s, int i)
        throws SQLException
    {
        preparedStatement.setIntAtName(s, i);
    }

    public void setLongAtName(String s, long l)
        throws SQLException
    {
        preparedStatement.setLongAtName(s, l);
    }

    public void setNClobAtName(String s, NClob nclob)
        throws SQLException
    {
        preparedStatement.setNClobAtName(s, nclob);
    }

    public void setNStringAtName(String s, String s1)
        throws SQLException
    {
        preparedStatement.setNStringAtName(s, s1);
    }

    public void setObjectAtName(String s, Object obj)
        throws SQLException
    {
        preparedStatement.setObjectAtName(s, obj);
    }

    public void setObjectAtName(String s, Object obj, int i)
        throws SQLException
    {
        preparedStatement.setObjectAtName(s, obj, i);
    }

    public void setRefAtName(String s, Ref ref)
        throws SQLException
    {
        preparedStatement.setRefAtName(s, ref);
    }

    public void setRowIdAtName(String s, RowId rowid)
        throws SQLException
    {
        preparedStatement.setRowIdAtName(s, rowid);
    }

    public void setShortAtName(String s, short word0)
        throws SQLException
    {
        preparedStatement.setShortAtName(s, word0);
    }

    public void setSQLXMLAtName(String s, SQLXML sqlxml)
        throws SQLException
    {
        preparedStatement.setSQLXMLAtName(s, sqlxml);
    }

    public void setStringAtName(String s, String s1)
        throws SQLException
    {
        preparedStatement.setStringAtName(s, s1);
    }

    public void setTimeAtName(String s, Time time)
        throws SQLException
    {
        preparedStatement.setTimeAtName(s, time);
    }

    public void setTimeAtName(String s, Time time, Calendar calendar)
        throws SQLException
    {
        preparedStatement.setTimeAtName(s, time, calendar);
    }

    public void setTimestampAtName(String s, Timestamp timestamp)
        throws SQLException
    {
        preparedStatement.setTimestampAtName(s, timestamp);
    }

    public void setTimestampAtName(String s, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        preparedStatement.setTimestampAtName(s, timestamp, calendar);
    }

    public void setURLAtName(String s, URL url)
        throws SQLException
    {
        preparedStatement.setURLAtName(s, url);
    }

    public void setARRAYAtName(String s, ARRAY array)
        throws SQLException
    {
        preparedStatement.setARRAYAtName(s, array);
    }

    public void setBFILEAtName(String s, BFILE bfile)
        throws SQLException
    {
        preparedStatement.setBFILEAtName(s, bfile);
    }

    public void setBfileAtName(String s, BFILE bfile)
        throws SQLException
    {
        preparedStatement.setBfileAtName(s, bfile);
    }

    public void setBinaryFloatAtName(String s, float f)
        throws SQLException
    {
        preparedStatement.setBinaryFloatAtName(s, f);
    }

    public void setBinaryFloatAtName(String s, BINARY_FLOAT binary_float)
        throws SQLException
    {
        preparedStatement.setBinaryFloatAtName(s, binary_float);
    }

    public void setBinaryDoubleAtName(String s, double d)
        throws SQLException
    {
        preparedStatement.setBinaryDoubleAtName(s, d);
    }

    public void setBinaryDoubleAtName(String s, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        preparedStatement.setBinaryDoubleAtName(s, binary_double);
    }

    public void setBLOBAtName(String s, BLOB blob)
        throws SQLException
    {
        preparedStatement.setBLOBAtName(s, blob);
    }

    public void setCHARAtName(String s, CHAR char1)
        throws SQLException
    {
        preparedStatement.setCHARAtName(s, char1);
    }

    public void setCLOBAtName(String s, CLOB clob)
        throws SQLException
    {
        preparedStatement.setCLOBAtName(s, clob);
    }

    public void setCursorAtName(String s, ResultSet resultset)
        throws SQLException
    {
        preparedStatement.setCursorAtName(s, resultset);
    }

    public void setCustomDatumAtName(String s, CustomDatum customdatum)
        throws SQLException
    {
        preparedStatement.setCustomDatumAtName(s, customdatum);
    }

    public void setDATEAtName(String s, DATE date)
        throws SQLException
    {
        preparedStatement.setDATEAtName(s, date);
    }

    public void setFixedCHARAtName(String s, String s1)
        throws SQLException
    {
        preparedStatement.setFixedCHARAtName(s, s1);
    }

    public void setINTERVALDSAtName(String s, INTERVALDS intervalds)
        throws SQLException
    {
        preparedStatement.setINTERVALDSAtName(s, intervalds);
    }

    public void setINTERVALYMAtName(String s, INTERVALYM intervalym)
        throws SQLException
    {
        preparedStatement.setINTERVALYMAtName(s, intervalym);
    }

    public void setNUMBERAtName(String s, NUMBER number)
        throws SQLException
    {
        preparedStatement.setNUMBERAtName(s, number);
    }

    public void setOPAQUEAtName(String s, OPAQUE opaque)
        throws SQLException
    {
        preparedStatement.setOPAQUEAtName(s, opaque);
    }

    public void setOracleObjectAtName(String s, Datum datum)
        throws SQLException
    {
        preparedStatement.setOracleObjectAtName(s, datum);
    }

    public void setORADataAtName(String s, ORAData oradata)
        throws SQLException
    {
        preparedStatement.setORADataAtName(s, oradata);
    }

    public void setRAWAtName(String s, RAW raw)
        throws SQLException
    {
        preparedStatement.setRAWAtName(s, raw);
    }

    public void setREFAtName(String s, REF ref)
        throws SQLException
    {
        preparedStatement.setREFAtName(s, ref);
    }

    public void setRefTypeAtName(String s, REF ref)
        throws SQLException
    {
        preparedStatement.setRefTypeAtName(s, ref);
    }

    public void setROWIDAtName(String s, ROWID rowid)
        throws SQLException
    {
        preparedStatement.setROWIDAtName(s, rowid);
    }

    public void setSTRUCTAtName(String s, STRUCT struct)
        throws SQLException
    {
        preparedStatement.setSTRUCTAtName(s, struct);
    }

    public void setTIMESTAMPLTZAtName(String s, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        preparedStatement.setTIMESTAMPLTZAtName(s, timestampltz);
    }

    public void setTIMESTAMPTZAtName(String s, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        preparedStatement.setTIMESTAMPTZAtName(s, timestamptz);
    }

    public void setTIMESTAMPAtName(String s, TIMESTAMP timestamp)
        throws SQLException
    {
        preparedStatement.setTIMESTAMPAtName(s, timestamp);
    }

    public void setBlobAtName(String s, InputStream inputstream)
        throws SQLException
    {
        preparedStatement.setBlobAtName(s, inputstream);
    }

    public void setBlobAtName(String s, InputStream inputstream, long l)
        throws SQLException
    {
        preparedStatement.setBlobAtName(s, inputstream, l);
    }

    public void setClobAtName(String s, Reader reader)
        throws SQLException
    {
        preparedStatement.setClobAtName(s, reader);
    }

    public void setClobAtName(String s, Reader reader, long l)
        throws SQLException
    {
        preparedStatement.setClobAtName(s, reader, l);
    }

    public void setNClobAtName(String s, Reader reader)
        throws SQLException
    {
        preparedStatement.setNClobAtName(s, reader);
    }

    public void setNClobAtName(String s, Reader reader, long l)
        throws SQLException
    {
        preparedStatement.setNClobAtName(s, reader, l);
    }

    public void setAsciiStreamAtName(String s, InputStream inputstream)
        throws SQLException
    {
        preparedStatement.setAsciiStreamAtName(s, inputstream);
    }

    public void setAsciiStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException
    {
        preparedStatement.setAsciiStreamAtName(s, inputstream, i);
    }

    public void setAsciiStreamAtName(String s, InputStream inputstream, long l)
        throws SQLException
    {
        preparedStatement.setAsciiStreamAtName(s, inputstream, l);
    }

    public void setBinaryStreamAtName(String s, InputStream inputstream)
        throws SQLException
    {
        preparedStatement.setBinaryStreamAtName(s, inputstream);
    }

    public void setBinaryStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException
    {
        preparedStatement.setBinaryStreamAtName(s, inputstream, i);
    }

    public void setBinaryStreamAtName(String s, InputStream inputstream, long l)
        throws SQLException
    {
        preparedStatement.setBinaryStreamAtName(s, inputstream, l);
    }

    public void setCharacterStreamAtName(String s, Reader reader)
        throws SQLException
    {
        preparedStatement.setCharacterStreamAtName(s, reader);
    }

    public void setCharacterStreamAtName(String s, Reader reader, int i)
        throws SQLException
    {
        preparedStatement.setCharacterStreamAtName(s, reader, i);
    }

    public void setCharacterStreamAtName(String s, Reader reader, long l)
        throws SQLException
    {
        preparedStatement.setCharacterStreamAtName(s, reader, l);
    }

    public void setNCharacterStreamAtName(String s, Reader reader)
        throws SQLException
    {
        preparedStatement.setNCharacterStreamAtName(s, reader);
    }

    public void setNCharacterStreamAtName(String s, Reader reader, long l)
        throws SQLException
    {
        preparedStatement.setNCharacterStreamAtName(s, reader, l);
    }

    public void setUnicodeStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException
    {
        preparedStatement.setUnicodeStreamAtName(s, inputstream, i);
    }

    public void setNull(int i, int j)
        throws SQLException
    {
        preparedStatement.setNull(i, j);
    }

    public void setNull(int i, int j, String s)
        throws SQLException
    {
        preparedStatement.setNull(i, j, s);
    }

    public void setNullAtName(String s, int i)
        throws SQLException
    {
        preparedStatement.setNullAtName(s, i);
    }

    public void setNullAtName(String s, int i, String s1)
        throws SQLException
    {
        preparedStatement.setNullAtName(s, i, s1);
    }

    public void setObject(int i, Object obj, int j, int k)
        throws SQLException
    {
        preparedStatement.setObject(i, obj, j, k);
    }

    public void setObjectAtName(String s, Object obj, int i, int j)
        throws SQLException
    {
        preparedStatement.setObjectAtName(s, obj, i, j);
    }

    public void setStructDescriptor(int i, StructDescriptor structdescriptor)
        throws SQLException
    {
        preparedStatement.setStructDescriptor(i, structdescriptor);
    }

    public void setStructDescriptorAtName(String s, StructDescriptor structdescriptor)
        throws SQLException
    {
        preparedStatement.setStructDescriptorAtName(s, structdescriptor);
    }

    public int executeUpdate()
        throws SQLException
    {
        return preparedStatement.executeUpdate();
    }

    public void addBatch()
        throws SQLException
    {
        preparedStatement.addBatch();
    }

    public void clearParameters()
        throws SQLException
    {
        preparedStatement.clearParameters();
    }

    public boolean execute()
        throws SQLException
    {
        return preparedStatement.execute();
    }

    public void setCheckBindTypes(boolean flag)
    {
        preparedStatement.setCheckBindTypes(flag);
    }

    public ResultSet getReturnResultSet()
        throws SQLException
    {
        return preparedStatement.getReturnResultSet();
    }

    public void defineParameterTypeBytes(int i, int j, int k)
        throws SQLException
    {
        preparedStatement.defineParameterTypeBytes(i, j, k);
    }

    public void defineParameterTypeChars(int i, int j, int k)
        throws SQLException
    {
        preparedStatement.defineParameterTypeChars(i, j, k);
    }

    public void defineParameterType(int i, int j, int k)
        throws SQLException
    {
        preparedStatement.defineParameterType(i, j, k);
    }

    public int getExecuteBatch()
    {
        return preparedStatement.getExecuteBatch();
    }

    public int sendBatch()
        throws SQLException
    {
        return preparedStatement.sendBatch();
    }

    public void setPlsqlIndexTable(int i, Object obj, int j, int k, int l, int i1)
        throws SQLException
    {
        preparedStatement.setPlsqlIndexTable(i, obj, j, k, l, i1);
    }

    public void setFormOfUse(int i, short word0)
    {
        preparedStatement.setFormOfUse(i, word0);
    }

    public void setDisableStmtCaching(boolean flag)
    {
        preparedStatement.setDisableStmtCaching(flag);
    }

    public OracleParameterMetaData OracleGetParameterMetaData()
        throws SQLException
    {
        return preparedStatement.OracleGetParameterMetaData();
    }

    public void registerReturnParameter(int i, int j)
        throws SQLException
    {
        preparedStatement.registerReturnParameter(i, j);
    }

    public void registerReturnParameter(int i, int j, int k)
        throws SQLException
    {
        preparedStatement.registerReturnParameter(i, j, k);
    }

    public void registerReturnParameter(int i, int j, String s)
        throws SQLException
    {
        preparedStatement.registerReturnParameter(i, j, s);
    }

    public ResultSet executeQuery()
        throws SQLException
    {
        return preparedStatement.executeQuery();
    }

    public ResultSetMetaData getMetaData()
        throws SQLException
    {
        return preparedStatement.getMetaData();
    }

    public void setBytesForBlob(int i, byte abyte0[])
        throws SQLException
    {
        preparedStatement.setBytesForBlob(i, abyte0);
    }

    public void setBytesForBlobAtName(String s, byte abyte0[])
        throws SQLException
    {
        preparedStatement.setBytesForBlobAtName(s, abyte0);
    }

    public void setStringForClob(int i, String s)
        throws SQLException
    {
        preparedStatement.setStringForClob(i, s);
    }

    public void setStringForClobAtName(String s, String s1)
        throws SQLException
    {
        preparedStatement.setStringForClobAtName(s, s1);
    }

    public ParameterMetaData getParameterMetaData()
        throws SQLException
    {
        return preparedStatement.getParameterMetaData();
    }

    public void setExecuteBatch(int i)
        throws SQLException
    {
        preparedStatement.setExecuteBatch(i);
    }

    public boolean isPoolable()
        throws SQLException
    {
        return preparedStatement.isPoolable();
    }

    public void setPoolable(boolean flag)
        throws SQLException
    {
        preparedStatement.setPoolable(flag);
    }

    public void setInternalBytes(int i, byte abyte0[], int j)
        throws SQLException
    {
        preparedStatement.setInternalBytes(i, abyte0, j);
    }

    public void enterImplicitCache()
        throws SQLException
    {
        preparedStatement.enterImplicitCache();
    }

    public void enterExplicitCache()
        throws SQLException
    {
        preparedStatement.enterExplicitCache();
    }

    public void exitImplicitCacheToActive()
        throws SQLException
    {
        preparedStatement.exitImplicitCacheToActive();
    }

    public void exitExplicitCacheToActive()
        throws SQLException
    {
        preparedStatement.exitExplicitCacheToActive();
    }

    public void exitImplicitCacheToClose()
        throws SQLException
    {
        preparedStatement.exitImplicitCacheToClose();
    }

    public void exitExplicitCacheToClose()
        throws SQLException
    {
        preparedStatement.exitExplicitCacheToClose();
    }

    public String getOriginalSql()
        throws SQLException
    {
        return preparedStatement.getOriginalSql();
    }

}
