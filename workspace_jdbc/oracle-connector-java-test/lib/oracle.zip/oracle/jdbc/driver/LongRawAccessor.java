// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   LongRawAccessor.java

package oracle.jdbc.driver;

import java.io.*;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            RawCommonAccessor, OracleStatement, PhysicalConnection, OracleDriverExtension, 
//            OracleInputStream, DatabaseError, DBConversion

class LongRawAccessor extends RawCommonAccessor
{

    OracleInputStream stream;
    int columnPosition;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    LongRawAccessor(OracleStatement oraclestatement, int i, int j, short word0, int k)
        throws SQLException
    {
        columnPosition = 0;
        init(oraclestatement, 24, 24, word0, false);
        columnPosition = i;
        initForDataAccess(k, j, null);
    }

    LongRawAccessor(OracleStatement oraclestatement, int i, int j, boolean flag, int k, int l, int i1, 
            int j1, int k1, short word0)
        throws SQLException
    {
        columnPosition = 0;
        init(oraclestatement, 24, 24, word0, false);
        columnPosition = i;
        initForDescribe(24, j, flag, k, l, i1, j1, k1, word0, null);
        int l1 = oraclestatement.maxFieldSize;
        if(l1 > 0 && (j == 0 || l1 < j))
            j = l1;
        initForDataAccess(0, j, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        isStream = true;
        isColumnNumberAware = true;
        internalTypeMaxLength = 0x7fffffff;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        byteLength = 0;
        stream = statement.connection.driverExtension.createInputStream(statement, columnPosition, this);
    }

    OracleInputStream initForNewRow()
        throws SQLException
    {
        stream = statement.connection.driverExtension.createInputStream(statement, columnPosition, this);
        return stream;
    }

    void updateColumnNumber(int i)
    {
        i++;
        columnPosition = i;
        if(stream != null)
            stream.columnIndex = i;
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        byte abyte0[] = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1 && stream != null)
        {
            if(stream.closed)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(1024);
            byte abyte1[] = new byte[1024];
            int j;
            try
            {
                while((j = stream.read(abyte1)) != -1) 
                    bytearrayoutputstream.write(abyte1, 0, j);
            }
            catch(IOException ioexception)
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
            abyte0 = bytearrayoutputstream.toByteArray();
        }
        return abyte0;
    }

    InputStream getAsciiStream(int i)
        throws SQLException
    {
        InputStream inputstream = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1 && stream != null)
        {
            if(stream.closed)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            inputstream = physicalconnection.conversion.ConvertStream(stream, 2);
        }
        return inputstream;
    }

    InputStream getUnicodeStream(int i)
        throws SQLException
    {
        InputStream inputstream = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1 && stream != null)
        {
            if(stream.closed)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            inputstream = physicalconnection.conversion.ConvertStream(stream, 3);
        }
        return inputstream;
    }

    Reader getCharacterStream(int i)
        throws SQLException
    {
        Reader reader = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1 && stream != null)
        {
            if(stream.closed)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            reader = physicalconnection.conversion.ConvertCharacterStream(stream, 8);
        }
        return reader;
    }

    InputStream getBinaryStream(int i)
        throws SQLException
    {
        InputStream inputstream = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1 && stream != null)
        {
            if(stream.closed)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 27);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            PhysicalConnection physicalconnection = statement.connection;
            PhysicalConnection _tmp = physicalconnection;
            inputstream = physicalconnection.conversion.ConvertStream(stream, 6);
        }
        return inputstream;
    }

    public String toString()
    {
        return (new StringBuilder()).append("LongRawAccessor@").append(Integer.toHexString(hashCode())).append("{columnPosition = ").append(columnPosition).append("}").toString();
    }

}
