// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   VarcharAccessor.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;
import oracle.sql.ROWID;

// Referenced classes of package oracle.jdbc.driver:
//            CharCommonAccessor, OracleStatement, PhysicalConnection, DatabaseError

class VarcharAccessor extends CharCommonAccessor
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    VarcharAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        char c = '\u0FA0';
        if(oraclestatement.sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.PLSQL_BLOCK)
            c = oraclestatement.connection.plsqlVarcharParameter4KOnly ? '\u0FA0' : '\u7FFE';
        init(oraclestatement, 1, 9, i, word0, j, flag, c, 2000);
    }

    VarcharAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        char c = '\u0FA0';
        if(oraclestatement.sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.PLSQL_BLOCK)
            c = oraclestatement.connection.plsqlVarcharParameter4KOnly ? '\u0FA0' : '\u7FFE';
        init(oraclestatement, 1, 9, i, flag, j, k, l, i1, j1, word0, c, 2000);
    }

    ROWID getROWID(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        ROWID rowid = null;
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            byte abyte0[] = getBytesInternal(i);
            if(abyte0 != null)
                rowid = new ROWID(abyte0);
        }
        return rowid;
    }

}
