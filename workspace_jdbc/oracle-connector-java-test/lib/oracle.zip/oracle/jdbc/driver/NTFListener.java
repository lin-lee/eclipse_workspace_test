// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFListener.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.nio.channels.*;
import java.util.Iterator;
import java.util.Set;

// Referenced classes of package oracle.jdbc.driver:
//            NTFConnection, NTFManager

class NTFListener extends Thread
{

    private NTFConnection connections[];
    private int nbOfConnections;
    private boolean needsToBeClosed;
    NTFManager dcnManager;
    ServerSocketChannel ssChannel;
    int tcpport;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFListener(NTFManager ntfmanager, ServerSocketChannel serversocketchannel, int i)
    {
        connections = null;
        nbOfConnections = 0;
        needsToBeClosed = false;
        dcnManager = ntfmanager;
        connections = new NTFConnection[10];
        ssChannel = serversocketchannel;
        tcpport = i;
    }

    public void run()
    {
        try
        {
            Selector selector = Selector.open();
            ssChannel.register(selector, 16);
            do
            {
                selector.select();
                if(needsToBeClosed)
                    break;
                Iterator iterator = selector.selectedKeys().iterator();
                while(iterator.hasNext()) 
                {
                    SelectionKey selectionkey = (SelectionKey)iterator.next();
                    if((selectionkey.readyOps() & 0x10) == 16)
                    {
                        ServerSocketChannel serversocketchannel = (ServerSocketChannel)selectionkey.channel();
                        SocketChannel socketchannel = serversocketchannel.accept();
                        NTFConnection ntfconnection = new NTFConnection(dcnManager, socketchannel);
                        if(connections.length == nbOfConnections)
                        {
                            NTFConnection antfconnection[] = new NTFConnection[connections.length * 2];
                            System.arraycopy(connections, 0, antfconnection, 0, connections.length);
                            connections = antfconnection;
                        }
                        connections[nbOfConnections++] = ntfconnection;
                        ntfconnection.start();
                        iterator.remove();
                    }
                }
            } while(true);
            selector.close();
            ssChannel.close();
        }
        catch(IOException ioexception) { }
    }

    synchronized void closeThisListener()
    {
        for(int i = 0; i < nbOfConnections; i++)
        {
            connections[i].closeThisConnection();
            connections[i].interrupt();
        }

        needsToBeClosed = true;
    }

}
