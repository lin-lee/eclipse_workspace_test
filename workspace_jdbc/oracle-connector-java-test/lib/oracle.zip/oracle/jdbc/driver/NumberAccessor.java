// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NumberAccessor.java

package oracle.jdbc.driver;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            NumberCommonAccessor, OracleStatement

class NumberAccessor extends NumberCommonAccessor
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NumberAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        init(oraclestatement, i, word0, j, flag);
    }

    NumberAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        init(oraclestatement, 2, i, flag, j, k, l, i1, j1, word0);
    }

}
