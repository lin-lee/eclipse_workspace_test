// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleResultSet.java

package oracle.jdbc.driver;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.OracleDataFactory;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.ARRAY;
import oracle.sql.BFILE;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BLOB;
import oracle.sql.CHAR;
import oracle.sql.CLOB;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.NUMBER;
import oracle.sql.OPAQUE;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.RAW;
import oracle.sql.REF;
import oracle.sql.ROWID;
import oracle.sql.STRUCT;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;

// Referenced classes of package oracle.jdbc.driver:
//            DatabaseError, OracleStatement

abstract class OracleResultSet
    implements oracle.jdbc.internal.OracleResultSet
{

    static final boolean DEBUG = false;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleResultSet()
    {
    }

    int getFirstUserColumnIndex()
        throws SQLException
    {
        return 0;
    }

    public abstract void closeStatementOnClose()
        throws SQLException;

    public abstract Array getArray(int i)
        throws SQLException;

    public abstract BigDecimal getBigDecimal(int i)
        throws SQLException;

    public abstract BigDecimal getBigDecimal(int i, int j)
        throws SQLException;

    public abstract Blob getBlob(int i)
        throws SQLException;

    public abstract boolean getBoolean(int i)
        throws SQLException;

    public abstract byte getByte(int i)
        throws SQLException;

    public abstract byte[] getBytes(int i)
        throws SQLException;

    public abstract Clob getClob(int i)
        throws SQLException;

    public abstract Date getDate(int i)
        throws SQLException;

    public abstract Date getDate(int i, Calendar calendar)
        throws SQLException;

    public abstract double getDouble(int i)
        throws SQLException;

    public abstract float getFloat(int i)
        throws SQLException;

    public abstract int getInt(int i)
        throws SQLException;

    public abstract long getLong(int i)
        throws SQLException;

    public abstract NClob getNClob(int i)
        throws SQLException;

    public abstract String getNString(int i)
        throws SQLException;

    public abstract Object getObject(int i)
        throws SQLException;

    public abstract Object getObject(int i, Map map)
        throws SQLException;

    public abstract Ref getRef(int i)
        throws SQLException;

    public abstract RowId getRowId(int i)
        throws SQLException;

    public abstract short getShort(int i)
        throws SQLException;

    public abstract SQLXML getSQLXML(int i)
        throws SQLException;

    public abstract String getString(int i)
        throws SQLException;

    public abstract Time getTime(int i)
        throws SQLException;

    public abstract Time getTime(int i, Calendar calendar)
        throws SQLException;

    public abstract Timestamp getTimestamp(int i)
        throws SQLException;

    public abstract Timestamp getTimestamp(int i, Calendar calendar)
        throws SQLException;

    public abstract URL getURL(int i)
        throws SQLException;

    public abstract ARRAY getARRAY(int i)
        throws SQLException;

    public abstract BFILE getBFILE(int i)
        throws SQLException;

    public abstract BFILE getBfile(int i)
        throws SQLException;

    public abstract BLOB getBLOB(int i)
        throws SQLException;

    public abstract CHAR getCHAR(int i)
        throws SQLException;

    public abstract CLOB getCLOB(int i)
        throws SQLException;

    public abstract ResultSet getCursor(int i)
        throws SQLException;

    public abstract CustomDatum getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException;

    public abstract DATE getDATE(int i)
        throws SQLException;

    public abstract INTERVALDS getINTERVALDS(int i)
        throws SQLException;

    public abstract INTERVALYM getINTERVALYM(int i)
        throws SQLException;

    public abstract NUMBER getNUMBER(int i)
        throws SQLException;

    public abstract OPAQUE getOPAQUE(int i)
        throws SQLException;

    public abstract Datum getOracleObject(int i)
        throws SQLException;

    public abstract ORAData getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException;

    public abstract Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException;

    public abstract RAW getRAW(int i)
        throws SQLException;

    public abstract REF getREF(int i)
        throws SQLException;

    public abstract ROWID getROWID(int i)
        throws SQLException;

    public abstract STRUCT getSTRUCT(int i)
        throws SQLException;

    public abstract TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException;

    public abstract TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException;

    public abstract TIMESTAMP getTIMESTAMP(int i)
        throws SQLException;

    public abstract InputStream getAsciiStream(int i)
        throws SQLException;

    public abstract InputStream getBinaryStream(int i)
        throws SQLException;

    public abstract Reader getCharacterStream(int i)
        throws SQLException;

    public abstract Reader getNCharacterStream(int i)
        throws SQLException;

    public abstract InputStream getUnicodeStream(int i)
        throws SQLException;

    public abstract void updateArray(int i, Array array)
        throws SQLException;

    public abstract void updateBigDecimal(int i, BigDecimal bigdecimal)
        throws SQLException;

    public abstract void updateBlob(int i, Blob blob)
        throws SQLException;

    public abstract void updateBoolean(int i, boolean flag)
        throws SQLException;

    public abstract void updateByte(int i, byte byte0)
        throws SQLException;

    public abstract void updateBytes(int i, byte abyte0[])
        throws SQLException;

    public abstract void updateClob(int i, Clob clob)
        throws SQLException;

    public abstract void updateDate(int i, Date date)
        throws SQLException;

    public abstract void updateDate(int i, Date date, Calendar calendar)
        throws SQLException;

    public abstract void updateDouble(int i, double d)
        throws SQLException;

    public abstract void updateFloat(int i, float f)
        throws SQLException;

    public abstract void updateInt(int i, int j)
        throws SQLException;

    public abstract void updateLong(int i, long l)
        throws SQLException;

    public abstract void updateNClob(int i, NClob nclob)
        throws SQLException;

    public abstract void updateNString(int i, String s)
        throws SQLException;

    public abstract void updateObject(int i, Object obj)
        throws SQLException;

    public abstract void updateObject(int i, Object obj, int j)
        throws SQLException;

    public abstract void updateRef(int i, Ref ref)
        throws SQLException;

    public abstract void updateRowId(int i, RowId rowid)
        throws SQLException;

    public abstract void updateShort(int i, short word0)
        throws SQLException;

    public abstract void updateSQLXML(int i, SQLXML sqlxml)
        throws SQLException;

    public abstract void updateString(int i, String s)
        throws SQLException;

    public abstract void updateTime(int i, Time time)
        throws SQLException;

    public abstract void updateTime(int i, Time time, Calendar calendar)
        throws SQLException;

    public abstract void updateTimestamp(int i, Timestamp timestamp)
        throws SQLException;

    public abstract void updateTimestamp(int i, Timestamp timestamp, Calendar calendar)
        throws SQLException;

    public abstract void updateURL(int i, URL url)
        throws SQLException;

    public abstract void updateARRAY(int i, ARRAY array)
        throws SQLException;

    public abstract void updateBFILE(int i, BFILE bfile)
        throws SQLException;

    public abstract void updateBfile(int i, BFILE bfile)
        throws SQLException;

    public abstract void updateBinaryFloat(int i, float f)
        throws SQLException;

    public abstract void updateBinaryFloat(int i, BINARY_FLOAT binary_float)
        throws SQLException;

    public abstract void updateBinaryDouble(int i, double d)
        throws SQLException;

    public abstract void updateBinaryDouble(int i, BINARY_DOUBLE binary_double)
        throws SQLException;

    public abstract void updateBLOB(int i, BLOB blob)
        throws SQLException;

    public abstract void updateCHAR(int i, CHAR char1)
        throws SQLException;

    public abstract void updateCLOB(int i, CLOB clob)
        throws SQLException;

    public abstract void updateCursor(int i, ResultSet resultset)
        throws SQLException;

    public abstract void updateCustomDatum(int i, CustomDatum customdatum)
        throws SQLException;

    public abstract void updateDATE(int i, DATE date)
        throws SQLException;

    public abstract void updateFixedCHAR(int i, String s)
        throws SQLException;

    public abstract void updateINTERVALDS(int i, INTERVALDS intervalds)
        throws SQLException;

    public abstract void updateINTERVALYM(int i, INTERVALYM intervalym)
        throws SQLException;

    public abstract void updateNUMBER(int i, NUMBER number)
        throws SQLException;

    public abstract void updateOPAQUE(int i, OPAQUE opaque)
        throws SQLException;

    public abstract void updateOracleObject(int i, Datum datum)
        throws SQLException;

    public abstract void updateORAData(int i, ORAData oradata)
        throws SQLException;

    public abstract void updateRAW(int i, RAW raw)
        throws SQLException;

    public abstract void updateREF(int i, REF ref)
        throws SQLException;

    public abstract void updateRefType(int i, REF ref)
        throws SQLException;

    public abstract void updateROWID(int i, ROWID rowid)
        throws SQLException;

    public abstract void updateSTRUCT(int i, STRUCT struct)
        throws SQLException;

    public abstract void updateTIMESTAMPLTZ(int i, TIMESTAMPLTZ timestampltz)
        throws SQLException;

    public abstract void updateTIMESTAMPTZ(int i, TIMESTAMPTZ timestamptz)
        throws SQLException;

    public abstract void updateTIMESTAMP(int i, TIMESTAMP timestamp)
        throws SQLException;

    public abstract void updateBlob(int i, InputStream inputstream)
        throws SQLException;

    public abstract void updateBlob(int i, InputStream inputstream, long l)
        throws SQLException;

    public abstract void updateClob(int i, Reader reader)
        throws SQLException;

    public abstract void updateClob(int i, Reader reader, long l)
        throws SQLException;

    public abstract void updateNClob(int i, Reader reader)
        throws SQLException;

    public abstract void updateNClob(int i, Reader reader, long l)
        throws SQLException;

    public abstract void updateAsciiStream(int i, InputStream inputstream)
        throws SQLException;

    public abstract void updateAsciiStream(int i, InputStream inputstream, int j)
        throws SQLException;

    public abstract void updateAsciiStream(int i, InputStream inputstream, long l)
        throws SQLException;

    public abstract void updateBinaryStream(int i, InputStream inputstream)
        throws SQLException;

    public abstract void updateBinaryStream(int i, InputStream inputstream, int j)
        throws SQLException;

    public abstract void updateBinaryStream(int i, InputStream inputstream, long l)
        throws SQLException;

    public abstract void updateCharacterStream(int i, Reader reader)
        throws SQLException;

    public abstract void updateCharacterStream(int i, Reader reader, int j)
        throws SQLException;

    public abstract void updateCharacterStream(int i, Reader reader, long l)
        throws SQLException;

    public abstract void updateNCharacterStream(int i, Reader reader)
        throws SQLException;

    public abstract void updateNCharacterStream(int i, Reader reader, long l)
        throws SQLException;

    public abstract void updateUnicodeStream(int i, InputStream inputstream, int j)
        throws SQLException;

    public Array getArray(String s)
        throws SQLException
    {
        return getArray(findColumn(s));
    }

    public BigDecimal getBigDecimal(String s)
        throws SQLException
    {
        return getBigDecimal(findColumn(s));
    }

    public BigDecimal getBigDecimal(String s, int i)
        throws SQLException
    {
        return getBigDecimal(findColumn(s), i);
    }

    public Blob getBlob(String s)
        throws SQLException
    {
        return getBlob(findColumn(s));
    }

    public boolean getBoolean(String s)
        throws SQLException
    {
        return getBoolean(findColumn(s));
    }

    public byte getByte(String s)
        throws SQLException
    {
        return getByte(findColumn(s));
    }

    public byte[] getBytes(String s)
        throws SQLException
    {
        return getBytes(findColumn(s));
    }

    public Clob getClob(String s)
        throws SQLException
    {
        return getClob(findColumn(s));
    }

    public Date getDate(String s)
        throws SQLException
    {
        return getDate(findColumn(s));
    }

    public Date getDate(String s, Calendar calendar)
        throws SQLException
    {
        return getDate(findColumn(s), calendar);
    }

    public double getDouble(String s)
        throws SQLException
    {
        return getDouble(findColumn(s));
    }

    public float getFloat(String s)
        throws SQLException
    {
        return getFloat(findColumn(s));
    }

    public int getInt(String s)
        throws SQLException
    {
        return getInt(findColumn(s));
    }

    public long getLong(String s)
        throws SQLException
    {
        return getLong(findColumn(s));
    }

    public NClob getNClob(String s)
        throws SQLException
    {
        return getNClob(findColumn(s));
    }

    public String getNString(String s)
        throws SQLException
    {
        return getNString(findColumn(s));
    }

    public Object getObject(String s)
        throws SQLException
    {
        return getObject(findColumn(s));
    }

    public Object getObject(String s, Map map)
        throws SQLException
    {
        return getObject(findColumn(s), map);
    }

    public Ref getRef(String s)
        throws SQLException
    {
        return getRef(findColumn(s));
    }

    public RowId getRowId(String s)
        throws SQLException
    {
        return getRowId(findColumn(s));
    }

    public short getShort(String s)
        throws SQLException
    {
        return getShort(findColumn(s));
    }

    public SQLXML getSQLXML(String s)
        throws SQLException
    {
        return getSQLXML(findColumn(s));
    }

    public String getString(String s)
        throws SQLException
    {
        return getString(findColumn(s));
    }

    public Time getTime(String s)
        throws SQLException
    {
        return getTime(findColumn(s));
    }

    public Time getTime(String s, Calendar calendar)
        throws SQLException
    {
        return getTime(findColumn(s), calendar);
    }

    public Timestamp getTimestamp(String s)
        throws SQLException
    {
        return getTimestamp(findColumn(s));
    }

    public Timestamp getTimestamp(String s, Calendar calendar)
        throws SQLException
    {
        return getTimestamp(findColumn(s), calendar);
    }

    public URL getURL(String s)
        throws SQLException
    {
        return getURL(findColumn(s));
    }

    public ARRAY getARRAY(String s)
        throws SQLException
    {
        return getARRAY(findColumn(s));
    }

    public BFILE getBFILE(String s)
        throws SQLException
    {
        return getBFILE(findColumn(s));
    }

    public BFILE getBfile(String s)
        throws SQLException
    {
        return getBfile(findColumn(s));
    }

    public BLOB getBLOB(String s)
        throws SQLException
    {
        return getBLOB(findColumn(s));
    }

    public CHAR getCHAR(String s)
        throws SQLException
    {
        return getCHAR(findColumn(s));
    }

    public CLOB getCLOB(String s)
        throws SQLException
    {
        return getCLOB(findColumn(s));
    }

    public ResultSet getCursor(String s)
        throws SQLException
    {
        return getCursor(findColumn(s));
    }

    public CustomDatum getCustomDatum(String s, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        return getCustomDatum(findColumn(s), customdatumfactory);
    }

    public DATE getDATE(String s)
        throws SQLException
    {
        return getDATE(findColumn(s));
    }

    public INTERVALDS getINTERVALDS(String s)
        throws SQLException
    {
        return getINTERVALDS(findColumn(s));
    }

    public INTERVALYM getINTERVALYM(String s)
        throws SQLException
    {
        return getINTERVALYM(findColumn(s));
    }

    public NUMBER getNUMBER(String s)
        throws SQLException
    {
        return getNUMBER(findColumn(s));
    }

    public OPAQUE getOPAQUE(String s)
        throws SQLException
    {
        return getOPAQUE(findColumn(s));
    }

    public Datum getOracleObject(String s)
        throws SQLException
    {
        return getOracleObject(findColumn(s));
    }

    public ORAData getORAData(String s, ORADataFactory oradatafactory)
        throws SQLException
    {
        return getORAData(findColumn(s), oradatafactory);
    }

    public Object getObject(String s, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        return getObject(findColumn(s), oracledatafactory);
    }

    public RAW getRAW(String s)
        throws SQLException
    {
        return getRAW(findColumn(s));
    }

    public REF getREF(String s)
        throws SQLException
    {
        return getREF(findColumn(s));
    }

    public ROWID getROWID(String s)
        throws SQLException
    {
        return getROWID(findColumn(s));
    }

    public STRUCT getSTRUCT(String s)
        throws SQLException
    {
        return getSTRUCT(findColumn(s));
    }

    public TIMESTAMPLTZ getTIMESTAMPLTZ(String s)
        throws SQLException
    {
        return getTIMESTAMPLTZ(findColumn(s));
    }

    public TIMESTAMPTZ getTIMESTAMPTZ(String s)
        throws SQLException
    {
        return getTIMESTAMPTZ(findColumn(s));
    }

    public TIMESTAMP getTIMESTAMP(String s)
        throws SQLException
    {
        return getTIMESTAMP(findColumn(s));
    }

    public InputStream getAsciiStream(String s)
        throws SQLException
    {
        return getAsciiStream(findColumn(s));
    }

    public InputStream getBinaryStream(String s)
        throws SQLException
    {
        return getBinaryStream(findColumn(s));
    }

    public Reader getCharacterStream(String s)
        throws SQLException
    {
        return getCharacterStream(findColumn(s));
    }

    public Reader getNCharacterStream(String s)
        throws SQLException
    {
        return getNCharacterStream(findColumn(s));
    }

    public InputStream getUnicodeStream(String s)
        throws SQLException
    {
        return getUnicodeStream(findColumn(s));
    }

    public void updateArray(String s, Array array)
        throws SQLException
    {
        updateArray(findColumn(s), array);
    }

    public void updateBigDecimal(String s, BigDecimal bigdecimal)
        throws SQLException
    {
        updateBigDecimal(findColumn(s), bigdecimal);
    }

    public void updateBlob(String s, Blob blob)
        throws SQLException
    {
        updateBlob(findColumn(s), blob);
    }

    public void updateBoolean(String s, boolean flag)
        throws SQLException
    {
        updateBoolean(findColumn(s), flag);
    }

    public void updateByte(String s, byte byte0)
        throws SQLException
    {
        updateByte(findColumn(s), byte0);
    }

    public void updateBytes(String s, byte abyte0[])
        throws SQLException
    {
        updateBytes(findColumn(s), abyte0);
    }

    public void updateClob(String s, Clob clob)
        throws SQLException
    {
        updateClob(findColumn(s), clob);
    }

    public void updateDate(String s, Date date)
        throws SQLException
    {
        updateDate(findColumn(s), date);
    }

    public void updateDate(String s, Date date, Calendar calendar)
        throws SQLException
    {
        updateDate(findColumn(s), date, calendar);
    }

    public void updateDouble(String s, double d)
        throws SQLException
    {
        updateDouble(findColumn(s), d);
    }

    public void updateFloat(String s, float f)
        throws SQLException
    {
        updateFloat(findColumn(s), f);
    }

    public void updateInt(String s, int i)
        throws SQLException
    {
        updateInt(findColumn(s), i);
    }

    public void updateLong(String s, long l)
        throws SQLException
    {
        updateLong(findColumn(s), l);
    }

    public void updateNClob(String s, NClob nclob)
        throws SQLException
    {
        updateNClob(findColumn(s), nclob);
    }

    public void updateNString(String s, String s1)
        throws SQLException
    {
        updateNString(findColumn(s), s1);
    }

    public void updateObject(String s, Object obj)
        throws SQLException
    {
        updateObject(findColumn(s), obj);
    }

    public void updateObject(String s, Object obj, int i)
        throws SQLException
    {
        updateObject(findColumn(s), obj, i);
    }

    public void updateRef(String s, Ref ref)
        throws SQLException
    {
        updateRef(findColumn(s), ref);
    }

    public void updateRowId(String s, RowId rowid)
        throws SQLException
    {
        updateRowId(findColumn(s), rowid);
    }

    public void updateShort(String s, short word0)
        throws SQLException
    {
        updateShort(findColumn(s), word0);
    }

    public void updateSQLXML(String s, SQLXML sqlxml)
        throws SQLException
    {
        updateSQLXML(findColumn(s), sqlxml);
    }

    public void updateString(String s, String s1)
        throws SQLException
    {
        updateString(findColumn(s), s1);
    }

    public void updateTime(String s, Time time)
        throws SQLException
    {
        updateTime(findColumn(s), time);
    }

    public void updateTime(String s, Time time, Calendar calendar)
        throws SQLException
    {
        updateTime(findColumn(s), time, calendar);
    }

    public void updateTimestamp(String s, Timestamp timestamp)
        throws SQLException
    {
        updateTimestamp(findColumn(s), timestamp);
    }

    public void updateTimestamp(String s, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        updateTimestamp(findColumn(s), timestamp, calendar);
    }

    public void updateURL(String s, URL url)
        throws SQLException
    {
        updateURL(findColumn(s), url);
    }

    public void updateARRAY(String s, ARRAY array)
        throws SQLException
    {
        updateARRAY(findColumn(s), array);
    }

    public void updateBFILE(String s, BFILE bfile)
        throws SQLException
    {
        updateBFILE(findColumn(s), bfile);
    }

    public void updateBfile(String s, BFILE bfile)
        throws SQLException
    {
        updateBfile(findColumn(s), bfile);
    }

    public void updateBinaryFloat(String s, float f)
        throws SQLException
    {
        updateBinaryFloat(findColumn(s), f);
    }

    public void updateBinaryFloat(String s, BINARY_FLOAT binary_float)
        throws SQLException
    {
        updateBinaryFloat(findColumn(s), binary_float);
    }

    public void updateBinaryDouble(String s, double d)
        throws SQLException
    {
        updateBinaryDouble(findColumn(s), d);
    }

    public void updateBinaryDouble(String s, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        updateBinaryDouble(findColumn(s), binary_double);
    }

    public void updateBLOB(String s, BLOB blob)
        throws SQLException
    {
        updateBLOB(findColumn(s), blob);
    }

    public void updateCHAR(String s, CHAR char1)
        throws SQLException
    {
        updateCHAR(findColumn(s), char1);
    }

    public void updateCLOB(String s, CLOB clob)
        throws SQLException
    {
        updateCLOB(findColumn(s), clob);
    }

    public void updateCursor(String s, ResultSet resultset)
        throws SQLException
    {
        updateCursor(findColumn(s), resultset);
    }

    public void updateCustomDatum(String s, CustomDatum customdatum)
        throws SQLException
    {
        updateCustomDatum(findColumn(s), customdatum);
    }

    public void updateDATE(String s, DATE date)
        throws SQLException
    {
        updateDATE(findColumn(s), date);
    }

    public void updateFixedCHAR(String s, String s1)
        throws SQLException
    {
        updateFixedCHAR(findColumn(s), s1);
    }

    public void updateINTERVALDS(String s, INTERVALDS intervalds)
        throws SQLException
    {
        updateINTERVALDS(findColumn(s), intervalds);
    }

    public void updateINTERVALYM(String s, INTERVALYM intervalym)
        throws SQLException
    {
        updateINTERVALYM(findColumn(s), intervalym);
    }

    public void updateNUMBER(String s, NUMBER number)
        throws SQLException
    {
        updateNUMBER(findColumn(s), number);
    }

    public void updateOPAQUE(String s, OPAQUE opaque)
        throws SQLException
    {
        updateOPAQUE(findColumn(s), opaque);
    }

    public void updateOracleObject(String s, Datum datum)
        throws SQLException
    {
        updateOracleObject(findColumn(s), datum);
    }

    public void updateORAData(String s, ORAData oradata)
        throws SQLException
    {
        updateORAData(findColumn(s), oradata);
    }

    public void updateRAW(String s, RAW raw)
        throws SQLException
    {
        updateRAW(findColumn(s), raw);
    }

    public void updateREF(String s, REF ref)
        throws SQLException
    {
        updateREF(findColumn(s), ref);
    }

    public void updateRefType(String s, REF ref)
        throws SQLException
    {
        updateRefType(findColumn(s), ref);
    }

    public void updateROWID(String s, ROWID rowid)
        throws SQLException
    {
        updateROWID(findColumn(s), rowid);
    }

    public void updateSTRUCT(String s, STRUCT struct)
        throws SQLException
    {
        updateSTRUCT(findColumn(s), struct);
    }

    public void updateTIMESTAMPLTZ(String s, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        updateTIMESTAMPLTZ(findColumn(s), timestampltz);
    }

    public void updateTIMESTAMPTZ(String s, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        updateTIMESTAMPTZ(findColumn(s), timestamptz);
    }

    public void updateTIMESTAMP(String s, TIMESTAMP timestamp)
        throws SQLException
    {
        updateTIMESTAMP(findColumn(s), timestamp);
    }

    public void updateBlob(String s, InputStream inputstream)
        throws SQLException
    {
        updateBlob(findColumn(s), inputstream);
    }

    public void updateBlob(String s, InputStream inputstream, long l)
        throws SQLException
    {
        updateBlob(findColumn(s), inputstream, l);
    }

    public void updateClob(String s, Reader reader)
        throws SQLException
    {
        updateClob(findColumn(s), reader);
    }

    public void updateClob(String s, Reader reader, long l)
        throws SQLException
    {
        updateClob(findColumn(s), reader, l);
    }

    public void updateNClob(String s, Reader reader)
        throws SQLException
    {
        updateNClob(findColumn(s), reader);
    }

    public void updateNClob(String s, Reader reader, long l)
        throws SQLException
    {
        updateNClob(findColumn(s), reader, l);
    }

    public void updateAsciiStream(String s, InputStream inputstream)
        throws SQLException
    {
        updateAsciiStream(findColumn(s), inputstream);
    }

    public void updateAsciiStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        updateAsciiStream(findColumn(s), inputstream, i);
    }

    public void updateAsciiStream(String s, InputStream inputstream, long l)
        throws SQLException
    {
        updateAsciiStream(findColumn(s), inputstream, l);
    }

    public void updateBinaryStream(String s, InputStream inputstream)
        throws SQLException
    {
        updateBinaryStream(findColumn(s), inputstream);
    }

    public void updateBinaryStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        updateBinaryStream(findColumn(s), inputstream, i);
    }

    public void updateBinaryStream(String s, InputStream inputstream, long l)
        throws SQLException
    {
        updateBinaryStream(findColumn(s), inputstream, l);
    }

    public void updateCharacterStream(String s, Reader reader)
        throws SQLException
    {
        updateCharacterStream(findColumn(s), reader);
    }

    public void updateCharacterStream(String s, Reader reader, int i)
        throws SQLException
    {
        updateCharacterStream(findColumn(s), reader, i);
    }

    public void updateCharacterStream(String s, Reader reader, long l)
        throws SQLException
    {
        updateCharacterStream(findColumn(s), reader, l);
    }

    public void updateNCharacterStream(String s, Reader reader)
        throws SQLException
    {
        updateNCharacterStream(findColumn(s), reader);
    }

    public void updateNCharacterStream(String s, Reader reader, long l)
        throws SQLException
    {
        updateNCharacterStream(findColumn(s), reader, l);
    }

    public void updateUnicodeStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        updateUnicodeStream(findColumn(s), inputstream, i);
    }

    public abstract oracle.jdbc.AuthorizationIndicator getAuthorizationIndicator(int i)
        throws SQLException;

    public oracle.jdbc.AuthorizationIndicator getAuthorizationIndicator(String s)
        throws SQLException
    {
        return getAuthorizationIndicator(findColumn(s));
    }

    public abstract void setAutoRefetch(boolean flag)
        throws SQLException;

    public abstract boolean getAutoRefetch()
        throws SQLException;

    public abstract SQLWarning getWarnings()
        throws SQLException;

    public abstract void clearWarnings()
        throws SQLException;

    public abstract String getCursorName()
        throws SQLException;

    public abstract ResultSetMetaData getMetaData()
        throws SQLException;

    public abstract int findColumn(String s)
        throws SQLException;

    public abstract boolean next()
        throws SQLException;

    public abstract void close()
        throws SQLException;

    public abstract boolean wasNull()
        throws SQLException;

    public abstract boolean isBeforeFirst()
        throws SQLException;

    public abstract boolean isAfterLast()
        throws SQLException;

    public abstract boolean isFirst()
        throws SQLException;

    public abstract boolean isLast()
        throws SQLException;

    public abstract void beforeFirst()
        throws SQLException;

    public abstract void afterLast()
        throws SQLException;

    public abstract boolean first()
        throws SQLException;

    public abstract boolean last()
        throws SQLException;

    public abstract int getRow()
        throws SQLException;

    public abstract boolean absolute(int i)
        throws SQLException;

    public abstract boolean relative(int i)
        throws SQLException;

    public abstract boolean previous()
        throws SQLException;

    public abstract void setFetchDirection(int i)
        throws SQLException;

    public abstract int getFetchDirection()
        throws SQLException;

    public abstract void setFetchSize(int i)
        throws SQLException;

    public abstract int getFetchSize()
        throws SQLException;

    public abstract int getType()
        throws SQLException;

    public abstract int getConcurrency()
        throws SQLException;

    public abstract void insertRow()
        throws SQLException;

    public abstract void updateRow()
        throws SQLException;

    public abstract void deleteRow()
        throws SQLException;

    public abstract void refreshRow()
        throws SQLException;

    public abstract void moveToInsertRow()
        throws SQLException;

    public abstract void cancelRowUpdates()
        throws SQLException;

    public abstract void moveToCurrentRow()
        throws SQLException;

    public abstract Statement getStatement()
        throws SQLException;

    public abstract boolean rowUpdated()
        throws SQLException;

    public abstract boolean rowInserted()
        throws SQLException;

    public abstract boolean rowDeleted()
        throws SQLException;

    public abstract void updateNull(int i)
        throws SQLException;

    public void updateNull(String s)
        throws SQLException
    {
        updateNull(findColumn(s));
    }

    public boolean isWrapperFor(Class class1)
        throws SQLException
    {
        if(class1.isInterface())
        {
            return class1.isInstance(this);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public Object unwrap(Class class1)
        throws SQLException
    {
        if(class1.isInterface() && class1.isInstance(this))
        {
            return this;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

    abstract OracleStatement getOracleStatement()
        throws SQLException;

}
