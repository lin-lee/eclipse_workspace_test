// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDiagnosabilityMBean.java

package oracle.jdbc.driver;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.*;

// Referenced classes of package oracle.jdbc.driver:
//            DiagnosabilityMXBean, OracleLog, DatabaseError

public class OracleDiagnosabilityMBean extends StandardMBean
    implements DiagnosabilityMXBean
{

    OracleDiagnosabilityMBean()
    {
        super(oracle/jdbc/driver/DiagnosabilityMXBean, true);
    }

    public boolean getLoggingEnabled()
    {
        return OracleLog.isEnabled();
    }

    public void setLoggingEnabled(boolean flag)
    {
        OracleLog.setTrace(flag);
    }

    public boolean stateManageable()
    {
        return false;
    }

    public boolean statisticsProvider()
    {
        return false;
    }

    protected String getDescription(MBeanInfo mbeaninfo)
    {
        return DatabaseError.findMessage("DiagnosabilityMBeanDescription", this);
    }

    protected String getDescription(MBeanConstructorInfo mbeanconstructorinfo)
    {
        return DatabaseError.findMessage("DiagnosabilityMBeanConstructor()", this);
    }

    protected String getDescription(MBeanAttributeInfo mbeanattributeinfo)
    {
        String s = mbeanattributeinfo.getName();
        if(s.equals("LoggingEnabled"))
            return DatabaseError.findMessage("DiagnosabilityMBeanLoggingEnabledDescription", this);
        if(s.equals("stateManageable"))
            return DatabaseError.findMessage("DiagnosabilityMBeanStateManageableDescription", this);
        if(s.equals("statisticsProvider"))
        {
            return DatabaseError.findMessage("DiagnosabilityMBeanStatisticsProviderDescription", this);
        } else
        {
            Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, (new StringBuilder()).append("Got a request to describe an unexpected  Attribute: ").append(s).toString());
            return super.getDescription(mbeanattributeinfo);
        }
    }
}
