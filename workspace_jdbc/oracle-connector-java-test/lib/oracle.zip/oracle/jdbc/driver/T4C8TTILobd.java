// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C8TTILobd.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.net.ns.NetInputStream;
import oracle.net.ns.NetOutputStream;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, T4CMAREngine, T4CConnection

class T4C8TTILobd extends T4CTTIMsg
{

    static final int LOBD_STATE0 = 0;
    static final int LOBD_STATE1 = 1;
    static final int LOBD_STATE2 = 2;
    static final int LOBD_STATE3 = 3;
    static final int LOBD_STATE_EXIT = 4;
    static final short TTCG_LNG = 254;
    static final short LOBDATALENGTH = 252;
    static byte ucs2Char[] = new byte[2];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C8TTILobd(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)14);
    }

    void marshalLobData(byte abyte0[], long l, long l1, boolean flag)
        throws IOException
    {
        long l2 = l1;
        marshalTTCcode();
        if(flag)
        {
            meg.outStream.flush();
            meg.outStream.writeZeroCopyIO(abyte0, (int)l, (int)l1);
        } else
        {
            boolean flag1 = false;
            if(l2 > 252L)
            {
                flag1 = true;
                meg.marshalUB1((short)254);
            }
            long l3 = 0L;
            for(; l2 > 252L; l2 -= 252L)
            {
                meg.marshalUB1((short)252);
                meg.marshalB1Array(abyte0, (int)(l + l3 * 252L), 252);
                l3++;
            }

            if(l2 > 0L)
            {
                meg.marshalUB1((short)(int)l2);
                meg.marshalB1Array(abyte0, (int)(l + l3 * 252L), (int)l2);
            }
            if(flag1)
                meg.marshalUB1((short)0);
        }
    }

    void marshalClobUB2_For9iDB(byte abyte0[], long l, long l1)
        throws IOException
    {
        long l2 = l1;
        boolean flag = false;
        marshalTTCcode();
        if(l2 > 84L)
        {
            flag = true;
            meg.marshalUB1((short)254);
        }
        long l3 = 0L;
        for(; l2 > 84L; l2 -= 84L)
        {
            meg.marshalUB1((short)252);
            for(int i = 0; i < 84; i++)
            {
                meg.marshalUB1((short)2);
                meg.marshalB1Array(abyte0, (int)(l + l3 * 168L + (long)(i * 2)), 2);
            }

            l3++;
        }

        if(l2 > 0L)
        {
            long l4 = l2 * 3L;
            meg.marshalUB1((short)(int)l4);
            for(int j = 0; (long)j < l2; j++)
            {
                meg.marshalUB1((short)2);
                meg.marshalB1Array(abyte0, (int)(l + l3 * 168L + (long)(j * 2)), 2);
            }

        }
        if(flag)
            meg.marshalUB1((short)0);
    }

    long unmarshalLobData(byte abyte0[], int i, boolean flag)
        throws SQLException, IOException
    {
        int j = 0;
        if(!flag) goto _L2; else goto _L1
_L1:
        int k = 0;
        int ai[] = new int[1];
        boolean flag1 = false;
        while(!flag1) 
        {
            flag1 = meg.inStream.readZeroCopyIO(abyte0, i + k, ai);
            k += ai[0];
        }
        j = k;
          goto _L3
_L2:
        int l;
        short word0;
        int i1;
        l = i;
        word0 = 0;
        i1 = 0;
_L5:
        if(i1 != 4)
        {
            switch(i1)
            {
            case 0: // '\0'
                word0 = meg.unmarshalUB1();
                if(word0 == 254)
                    i1 = 2;
                else
                    i1 = 1;
                break;

            case 1: // '\001'
                if(abyte0.length >= l + word0)
                {
                    meg.getNBytes(abyte0, l, word0);
                } else
                {
                    byte abyte1[] = new byte[word0];
                    meg.getNBytes(abyte1, 0, word0);
                    int j1 = Math.min(abyte0.length - l, word0);
                    System.arraycopy(abyte1, 0, abyte0, l, j1);
                }
                j += word0;
                i1 = 4;
                break;

            case 2: // '\002'
                word0 = meg.unmarshalUB1();
                if(word0 > 0)
                    i1 = 3;
                else
                    i1 = 4;
                break;

            case 3: // '\003'
                if(abyte0.length >= l + word0)
                {
                    meg.getNBytes(abyte0, l, word0);
                } else
                {
                    byte abyte2[] = new byte[word0];
                    meg.getNBytes(abyte2, 0, word0);
                    int k1 = Math.min(abyte0.length - l, word0);
                    System.arraycopy(abyte2, 0, abyte0, l, k1);
                }
                j += word0;
                l += word0;
                i1 = 2;
                break;
            }
            continue; /* Loop/switch isn't completed */
        }
_L3:
        return (long)j;
        if(true) goto _L5; else goto _L4
_L4:
    }

    long unmarshalClobUB2_For9iDB(byte abyte0[], int i)
        throws SQLException, IOException
    {
        long l = 0L;
        long l1 = i;
        short word0 = 0;
        boolean flag = false;
        boolean flag1 = false;
        int k1 = 0;
        do
            if(k1 != 4)
                switch(k1)
                {
                case 0: // '\0'
                    word0 = meg.unmarshalUB1();
                    if(word0 == 254)
                        k1 = 2;
                    else
                        k1 = 1;
                    break;

                case 1: // '\001'
                    for(int j = 0; j < word0;)
                    {
                        int i1 = meg.unmarshalUCS2(abyte0, l1);
                        j += i1;
                        l1 += 2L;
                        l += 2L;
                    }

                    k1 = 4;
                    break;

                case 2: // '\002'
                    word0 = meg.unmarshalUB1();
                    if(word0 > 0)
                        k1 = 3;
                    else
                        k1 = 4;
                    break;

                case 3: // '\003'
                    for(int k = 0; k < word0;)
                    {
                        int j1 = meg.unmarshalUCS2(abyte0, l1);
                        k += j1;
                        l1 += 2L;
                        l += 2L;
                    }

                    k1 = 2;
                    break;
                }
            else
                return l;
        while(true);
    }

}
