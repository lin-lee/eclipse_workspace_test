// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIokpn.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.TIMESTAMPTZ;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CMAREngine, DBConversion, T4CConnection

final class T4CTTIokpn extends T4CTTIfun
{

    static final int REGISTER_KPNDEF = 1;
    static final int UNREGISTER_KPNDEF = 2;
    static final int POST_KPNDEF = 3;
    static final int EXISTINGCLIENT_KPNDEF = 0;
    static final int NEWCLIENT_KPNDEF = 1;
    static final int KPUN_PRS_RAW = 1;
    static final int KPUN_VER_10200 = 2;
    static final int KPUN_VER_11100 = 3;
    static final int KPUN_VER_11200 = 4;
    static final int OCI_SUBSCR_NAMESPACE_ANONYMOUS = 0;
    static final int OCI_SUBSCR_NAMESPACE_AQ = 1;
    static final int OCI_SUBSCR_NAMESPACE_DBCHANGE = 2;
    static final int OCI_SUBSCR_NAMESPACE_MAX = 3;
    static final int KPD_CHNF_OPFILTER = 1;
    static final int KPD_CHNF_INSERT = 2;
    static final int KPD_CHNF_UPDATE = 4;
    static final int KPD_CHNF_DELETE = 8;
    static final int KPD_CHNF_ROWID = 16;
    static final int KPD_CQ_QUERYNF = 32;
    static final int KPD_CQ_BEST_EFFORT = 64;
    static final int KPD_CQ_CLQRYCACHE = 128;
    static final int KPD_CHNF_INVALID_REGID = 0;
    static final int SUBSCR_QOS_RELIABLE = 1;
    static final int SUBSCR_QOS_PAYLOAD = 2;
    static final int SUBSCR_QOS_REPLICATE = 4;
    static final int SUBSCR_QOS_SECURE = 8;
    static final int SUBSCR_QOS_PURGE_ON_NTFN = 16;
    static final int SUBSCR_QOS_MULTICBK = 32;
    static final byte SUBSCR_NTFN_GROUPING_CLASS_NONE = 0;
    static final byte SUBSCR_NTFN_GROUPING_CLASS_TIME = 1;
    static final byte SUBSCR_NTFN_GROUPING_TYPE_SUMMARY = 1;
    static final byte SUBSCR_NTFN_GROUPING_TYPE_LAST = 2;
    private int opcode;
    private int mode;
    private int nbOfRegistrationInfo;
    private String user;
    private String location;
    private int namespace[];
    private int kpdnrgrpval[];
    private int kpdnrgrprepcnt[];
    private int payloadType[];
    private int qosFlags[];
    private int timeout[];
    private int dbchangeOpFilter[];
    private int dbchangeTxnLag[];
    private byte registeredAgentName[][];
    private byte kpdnrcx[][];
    private byte kpdnrgrpcla[];
    private byte kpdnrgrptyp[];
    private TIMESTAMPTZ kpdnrgrpstatim[];
    private long dbchangeRegistrationId[];
    private byte userArr[];
    private byte locationArr[];
    private long regid;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIokpn(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        dbchangeTxnLag = null;
        registeredAgentName = (byte[][])null;
        kpdnrcx = (byte[][])null;
        kpdnrgrptyp = null;
        kpdnrgrpstatim = null;
        dbchangeRegistrationId = null;
        userArr = null;
        locationArr = null;
        regid = 0L;
        setFunCode((short)125);
    }

    void doOKPN(int i, int j, String s, String s1, int k, int ai[], String as[], 
            byte abyte0[][], int ai1[], int ai2[], int ai3[], int ai4[], int ai5[], long al[], 
            byte abyte1[], int ai6[], byte abyte2[], TIMESTAMPTZ atimestamptz[], int ai7[])
        throws IOException, SQLException
    {
        opcode = i;
        mode = j;
        user = s;
        location = s1;
        nbOfRegistrationInfo = k;
        namespace = ai;
        kpdnrcx = abyte0;
        payloadType = ai1;
        qosFlags = ai2;
        timeout = ai3;
        dbchangeOpFilter = ai4;
        dbchangeTxnLag = ai5;
        dbchangeRegistrationId = al;
        kpdnrgrpcla = abyte1;
        kpdnrgrpval = ai6;
        kpdnrgrptyp = abyte2;
        kpdnrgrpstatim = atimestamptz;
        kpdnrgrprepcnt = ai7;
        registeredAgentName = new byte[nbOfRegistrationInfo][];
        for(int l = 0; l < nbOfRegistrationInfo; l++)
            if(as[l] != null)
                registeredAgentName[l] = meg.conv.StringToCharBytes(as[l]);

        if(user != null)
            userArr = meg.conv.StringToCharBytes(user);
        else
            userArr = null;
        if(location != null)
            locationArr = meg.conv.StringToCharBytes(location);
        else
            locationArr = null;
        regid = 0L;
        doRPC();
    }

    void marshal()
        throws IOException
    {
        int i = 1;
        byte byte0 = 2;
        meg.marshalUB1((byte)opcode);
        meg.marshalUB4(mode);
        if(userArr != null)
        {
            meg.marshalPTR();
            meg.marshalUB4(userArr.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        }
        if(locationArr != null)
        {
            meg.marshalPTR();
            meg.marshalUB4(locationArr.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        }
        meg.marshalPTR();
        meg.marshalUB4(nbOfRegistrationInfo);
        meg.marshalUB2(i);
        meg.marshalUB2(byte0);
        if(connection.getTTCVersion() >= 4)
        {
            meg.marshalNULLPTR();
            meg.marshalPTR();
            if(connection.getTTCVersion() >= 5)
            {
                meg.marshalNULLPTR();
                meg.marshalPTR();
            }
        }
        if(userArr != null)
            meg.marshalCHR(userArr);
        if(locationArr != null)
            meg.marshalCHR(locationArr);
        for(int j = 0; j < nbOfRegistrationInfo; j++)
        {
            meg.marshalUB4(namespace[j]);
            byte abyte0[] = registeredAgentName[j];
            if(abyte0 != null && abyte0.length > 0)
            {
                meg.marshalUB4(abyte0.length);
                meg.marshalCLR(abyte0, 0, abyte0.length);
            } else
            {
                meg.marshalUB4(0L);
            }
            if(kpdnrcx[j] != null && kpdnrcx[j].length > 0)
            {
                meg.marshalUB4(kpdnrcx[j].length);
                meg.marshalCLR(kpdnrcx[j], 0, kpdnrcx[j].length);
            } else
            {
                meg.marshalUB4(0L);
            }
            meg.marshalUB4(payloadType[j]);
            if(connection.getTTCVersion() < 4)
                continue;
            meg.marshalUB4(qosFlags[j]);
            byte abyte1[] = new byte[0];
            meg.marshalUB4(abyte1.length);
            if(abyte1.length > 0)
                meg.marshalCLR(abyte1, abyte1.length);
            meg.marshalUB4(timeout[j]);
            int k = 0;
            meg.marshalUB4(k);
            meg.marshalUB4(dbchangeOpFilter[j]);
            meg.marshalUB4(dbchangeTxnLag[j]);
            meg.marshalUB4((int)dbchangeRegistrationId[j]);
            if(connection.getTTCVersion() < 5)
                continue;
            meg.marshalUB1(kpdnrgrpcla[j]);
            meg.marshalUB4(kpdnrgrpval[j]);
            meg.marshalUB1(kpdnrgrptyp[j]);
            if(kpdnrgrpstatim[j] == null)
                meg.marshalDALC(null);
            else
                meg.marshalDALC(kpdnrgrpstatim[j].shareBytes());
            meg.marshalSB4(kpdnrgrprepcnt[j]);
            meg.marshalSB8(dbchangeRegistrationId[j]);
        }

    }

    long getRegistrationId()
    {
        return regid;
    }

    void readRPA()
        throws IOException, SQLException
    {
        int i = (int)meg.unmarshalUB4();
        for(int j = 0; j < i; j++)
            meg.unmarshalUB4();

        int ai[] = new int[i];
        for(int k = 0; k < i; k++)
            ai[k] = (int)meg.unmarshalUB4();

        regid = ai[0];
        if(connection.getTTCVersion() >= 5)
        {
            int l = (int)meg.unmarshalUB4();
            long l1 = meg.unmarshalSB8();
            regid = l1;
        }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
