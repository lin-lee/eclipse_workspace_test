// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ScrollableResultSet.java

package oracle.jdbc.driver;

import java.io.*;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.*;
import java.util.*;
import oracle.jdbc.OracleDataFactory;
import oracle.jdbc.OracleResultSet;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            BaseResultSet, OracleStatement, OracleResultSetCacheImpl, OracleResultSetImpl, 
//            CachedRowElement, OracleResultSetMetaData, OraclePreparedStatementWrapper, OraclePreparedStatement, 
//            ScrollRsetStatement, DBConversion, PhysicalConnection, ClassRef, 
//            OracleResultSetCache, DatabaseError, SQLUtil, Accessor, 
//            OracleSql

class ScrollableResultSet extends BaseResultSet
{

    PhysicalConnection connection;
    OracleResultSetImpl resultSet;
    ScrollRsetStatement scrollStmt;
    ResultSetMetaData metadata;
    private int rsetType;
    private int rsetConcurency;
    private int beginColumnIndex;
    private int columnCount;
    private int wasNull;
    OracleResultSetCache rsetCache;
    int currentRow;
    private int numRowsCached;
    private boolean allRowsCached;
    private int lastRefetchSz;
    private Vector refetchRowids;
    private OraclePreparedStatement refetchStmt;
    private int usrFetchDirection;
    private static final ClassRef XMLTYPE_CLASS;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    ScrollableResultSet(ScrollRsetStatement scrollrsetstatement, OracleResultSetImpl oracleresultsetimpl, int i, int j)
        throws SQLException
    {
        connection = ((OracleStatement)scrollrsetstatement).connection;
        resultSet = oracleresultsetimpl;
        metadata = null;
        scrollStmt = scrollrsetstatement;
        rsetType = i;
        rsetConcurency = j;
        beginColumnIndex = needIdentifier(i, j) ? 1 : 0;
        columnCount = 0;
        wasNull = -1;
        rsetCache = scrollrsetstatement.getResultSetCache();
        if(rsetCache == null)
            rsetCache = new OracleResultSetCacheImpl();
        else
            try
            {
                rsetCache.clear();
            }
            catch(IOException ioexception)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        currentRow = 0;
        numRowsCached = 0;
        allRowsCached = false;
        lastRefetchSz = 0;
        refetchRowids = null;
        refetchStmt = null;
        usrFetchDirection = 1000;
        getInternalMetadata();
    }

    public void close()
        throws SQLException
    {
label0:
        {
            synchronized(connection)
            {
                if(!closed)
                    break label0;
            }
            return;
        }
        super.close();
        if(resultSet != null)
            resultSet.close();
        if(refetchStmt != null)
            refetchStmt.close();
        if(scrollStmt != null)
            scrollStmt.notifyCloseRset();
        if(refetchRowids != null)
            refetchRowids.removeAllElements();
        resultSet = null;
        scrollStmt = null;
        refetchStmt = null;
        refetchRowids = null;
        metadata = null;
        try
        {
            if(rsetCache != null)
            {
                rsetCache.clear();
                rsetCache.close();
            }
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        rsetCache = null;
        break MISSING_BLOCK_LABEL_164;
        Exception exception;
        exception;
        rsetCache = null;
        throw exception;
        physicalconnection;
        JVM INSTR monitorexit ;
          goto _L1
        exception1;
        throw exception1;
_L1:
    }

    public boolean wasNull()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(wasNull == -1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return wasNull == 1;
        Exception exception;
        exception;
        throw exception;
    }

    public Statement getStatement()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return (Statement)scrollStmt;
        Exception exception;
        exception;
        throw exception;
    }

    void resetBeginColumnIndex()
    {
        synchronized(connection)
        {
            beginColumnIndex = 0;
        }
    }

    ResultSet getResultSet()
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return resultSet;
        Exception exception;
        exception;
        throw exception;
    }

    int removeRowInCache(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(!isEmptyResultSet() && isValidRow(i))
        {
            removeCachedRowAt(i);
            numRowsCached--;
            if(i >= currentRow)
                currentRow--;
            return 1;
        }
        0;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    int refreshRowsInCache(int i, int j, int k)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        OracleResultSetImpl oracleresultsetimpl;
        int l;
        oracleresultsetimpl = null;
        l = 0;
        l = get_refetch_size(i, j, k);
        if(l > 0)
        {
            if(l != lastRefetchSz)
            {
                if(refetchStmt != null)
                    refetchStmt.close();
                refetchStmt = prepare_refetch_statement(l);
                refetchStmt.setQueryTimeout(((OracleStatement)scrollStmt).getQueryTimeout());
                lastRefetchSz = l;
            }
            prepare_refetch_binds(refetchStmt, l);
            oracleresultsetimpl = (OracleResultSetImpl)refetchStmt.executeQuery();
            save_refetch_results(oracleresultsetimpl, i, l, k);
        }
        if(oracleresultsetimpl != null)
            oracleresultsetimpl.close();
        break MISSING_BLOCK_LABEL_144;
        Exception exception;
        exception;
        if(oracleresultsetimpl != null)
            oracleresultsetimpl.close();
        throw exception;
        return l;
        Exception exception1;
        exception1;
        throw exception1;
    }

    public boolean next()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(isEmptyResultSet())
            return false;
        if(currentRow < 1)
            currentRow = 1;
        else
            currentRow++;
        isValidRow(currentRow);
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isBeforeFirst()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return !isEmptyResultSet() && currentRow < 1;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isAfterLast()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return !isEmptyResultSet() && currentRow > 0 && !isValidRow(currentRow);
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isFirst()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return currentRow == 1;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isLast()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return !isEmptyResultSet() && isValidRow(currentRow) && !isValidRow(currentRow + 1);
        Exception exception;
        exception;
        throw exception;
    }

    public void beforeFirst()
        throws SQLException
    {
        synchronized(connection)
        {
            if(closed)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(!isEmptyResultSet())
                currentRow = 0;
        }
    }

    public void afterLast()
        throws SQLException
    {
        synchronized(connection)
        {
            if(closed)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(!isEmptyResultSet())
                currentRow = getLastRow() + 1;
        }
    }

    public boolean first()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(isEmptyResultSet())
            return false;
        currentRow = 1;
        isValidRow(currentRow);
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean last()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(isEmptyResultSet())
            return false;
        currentRow = getLastRow();
        isValidRow(currentRow);
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public int getRow()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(isValidRow(currentRow))
            return currentRow;
        0;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean absolute(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i == 0)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, (new StringBuilder()).append("absolute(").append(i).append(")").toString());
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(isEmptyResultSet())
            return false;
        if(i > 0)
            currentRow = i;
        else
        if(i < 0)
            currentRow = getLastRow() + 1 + i;
        isValidRow(currentRow);
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean relative(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(isEmptyResultSet())
            return false;
        if(!isValidRow(currentRow)) goto _L2; else goto _L1
_L1:
        currentRow += i;
        isValidRow(currentRow);
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82, "relative");
        sqlexception1.fillInStackTrace();
        throw sqlexception1;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean previous()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(isEmptyResultSet())
            return false;
        if(isAfterLast())
            currentRow = getLastRow();
        else
            currentRow--;
        isValidRow(currentRow);
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Datum getOracleObject(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        wasNull = -1;
        if(!isValidRow(currentRow))
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(i < 1 || i > getColumnCount())
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        Datum datum = getCachedDatumValueAt(currentRow, i + beginColumnIndex);
        wasNull = datum != null ? 0 : 1;
        return datum;
        Exception exception;
        exception;
        throw exception;
    }

    public String getString(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null) goto _L2; else goto _L1
_L1:
        getInternalMetadata().getColumnType(i + beginColumnIndex);
        JVM INSTR lookupswitch 4: default 195
    //                   91: 97
    //                   93: 127
    //                   2005: 76
    //                   2011: 76;
           goto _L3 _L4 _L5 _L6 _L6
_L6:
        CLOB clob = (CLOB)datum;
        return clob.getSubString(1L, (int)clob.length());
_L4:
        if(!connection.mapDateToTimestamp) goto _L8; else goto _L7
_L7:
        datum.toJdbc().toString();
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L8:
        datum.dateValue().toString();
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L5:
        if(!(datum instanceof DATE)) goto _L10; else goto _L9
_L9:
        if(!connection.mapDateToTimestamp) goto _L12; else goto _L11
_L11:
        datum.toJdbc().toString();
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L12:
        datum.dateValue().toString();
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L10:
        if(!connection.j2ee13Compliant) goto _L14; else goto _L13
_L13:
        datum.toJdbc().toString();
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L14:
        datum.stringValue(connection);
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L3:
        datum.stringValue(connection);
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean getBoolean(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.booleanValue();
        false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public oracle.jdbc.OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(!isValidRow(currentRow))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i < 1 || i > getColumnCount())
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        CachedRowElement cachedrowelement = null;
        oracle.jdbc.OracleResultSet.AuthorizationIndicator authorizationindicator = null;
        try
        {
            cachedrowelement = (CachedRowElement)rsetCache.get(currentRow, i);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        if(cachedrowelement != null)
            authorizationindicator = cachedrowelement.getIndicator();
        return authorizationindicator;
        Exception exception;
        exception;
        throw exception;
    }

    public byte getByte(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.byteValue();
        0;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public short getShort(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        long l = getLong(i);
        if(l > 0x10001L || l < 0xfffffffffffefffeL)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return (short)(int)l;
        Exception exception;
        exception;
        throw exception;
    }

    public int getInt(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.intValue();
        0;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public long getLong(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.longValue();
        0L;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public float getFloat(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.floatValue();
        0.0F;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public double getDouble(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.doubleValue();
        0.0D;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public BigDecimal getBigDecimal(int i, int j)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.bigDecimalValue();
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public byte[] getBytes(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        byte abyte0[] = null;
        Datum datum = getOracleObject(i);
        if(datum != null)
            if(datum instanceof RAW)
                abyte0 = ((RAW)datum).shareBytes();
            else
            if(datum instanceof BLOB)
            {
                BLOB blob = (BLOB)datum;
                long l = blob.length();
                if(l > 0x7fffffffL)
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                abyte0 = blob.getBytes(1L, (int)l);
                if(blob.isTemporary())
                    resultSet.statement.addToTempLobsToFree(blob);
            } else
            {
                abyte0 = datum.getBytes();
            }
        return abyte0;
        Exception exception;
        exception;
        throw exception;
    }

    public Date getDate(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        Date date = null;
        if(datum != null)
        {
            ResultSetMetaData resultsetmetadata = getInternalMetadata();
            switch(resultsetmetadata.getColumnType(i + beginColumnIndex))
            {
            case -101: 
                date = ((TIMESTAMPTZ)datum).dateValue(connection);
                break;

            case -102: 
                date = ((TIMESTAMPLTZ)datum).dateValue(connection);
                break;

            default:
                date = datum.dateValue();
                break;
            }
        }
        return date;
        Exception exception;
        exception;
        throw exception;
    }

    public Time getTime(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        Time time = null;
        if(datum != null)
        {
            ResultSetMetaData resultsetmetadata = getInternalMetadata();
            switch(resultsetmetadata.getColumnType(i + beginColumnIndex))
            {
            case -101: 
                time = ((TIMESTAMPTZ)datum).timeValue(connection);
                break;

            case -102: 
                time = ((TIMESTAMPLTZ)datum).timeValue(connection, connection.getDbTzCalendar());
                break;

            default:
                time = datum.timeValue();
                break;
            }
        }
        return time;
        Exception exception;
        exception;
        throw exception;
    }

    public Timestamp getTimestamp(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        Timestamp timestamp = null;
        if(datum != null)
        {
            ResultSetMetaData resultsetmetadata = getInternalMetadata();
            switch(resultsetmetadata.getColumnType(i + beginColumnIndex))
            {
            case -101: 
                timestamp = ((TIMESTAMPTZ)datum).timestampValue(connection);
                break;

            case -102: 
                timestamp = ((TIMESTAMPLTZ)datum).timestampValue(connection, connection.getDbTzCalendar());
                break;

            default:
                timestamp = datum.timestampValue();
                break;
            }
        }
        return timestamp;
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getAsciiStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null) goto _L2; else goto _L1
_L1:
        int j = getInternalMetadata().getColumnType(i + beginColumnIndex);
        if((datum instanceof CHAR) && (j == -15 || j == -9))
        {
            DBConversion dbconversion = connection.conversion;
            byte abyte0[] = datum.shareBytes();
            connection;
            return dbconversion.ConvertStream(new ByteArrayInputStream(abyte0), 12);
        }
        datum.asciiStreamValue();
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getUnicodeStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum;
        DBConversion dbconversion;
        byte abyte0[];
        datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_113;
        dbconversion = connection.conversion;
        abyte0 = datum.shareBytes();
        if(datum instanceof RAW)
        {
            connection;
            return dbconversion.ConvertStream(new ByteArrayInputStream(abyte0), 3);
        }
        if(!(datum instanceof CHAR)) goto _L2; else goto _L1
_L1:
        connection;
        dbconversion.ConvertStream(new ByteArrayInputStream(abyte0), 1);
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getBinaryStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.binaryStreamValue();
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Object getObject(int i)
        throws SQLException
    {
        return getObject(i, connection.getTypeMap());
    }

    public Reader getCharacterStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.characterStreamValue();
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public BigDecimal getBigDecimal(int i)
        throws SQLException
    {
        return getBigDecimal(i, 0);
    }

    public Object getObject(int i, Map map)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Object obj = null;
        Datum datum = getOracleObject(i);
        if(datum != null)
        {
            int j = getInternalMetadata().getColumnType(i + beginColumnIndex);
            switch(j)
            {
            case 2002: 
                obj = ((STRUCT)datum).toJdbc(map);
                break;

            case 91: // '['
                if(connection.mapDateToTimestamp)
                    obj = datum.toJdbc();
                else
                    obj = datum.dateValue();
                break;

            case 93: // ']'
                if(datum instanceof DATE)
                {
                    if(connection.mapDateToTimestamp)
                        obj = datum.toJdbc();
                    else
                        obj = datum.dateValue();
                } else
                if(connection.j2ee13Compliant)
                    obj = datum.toJdbc();
                else
                    obj = datum;
                break;

            case -102: 
            case -101: 
                obj = datum;
                break;

            case 2007: 
                obj = ((OPAQUE)datum).toJdbc(map);
                break;

            default:
                obj = datum.toJdbc();
                break;
            }
        }
        return obj;
        Exception exception;
        exception;
        throw exception;
    }

    public Ref getRef(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getREF(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Blob getBlob(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getBLOB(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Clob getClob(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getCLOB(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Array getArray(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getARRAY(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Date getDate(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        Date date = null;
        if(datum != null)
        {
            ResultSetMetaData resultsetmetadata = getInternalMetadata();
            switch(resultsetmetadata.getColumnType(i + beginColumnIndex))
            {
            case -101: 
                date = new Date(((TIMESTAMPTZ)datum).timestampValue(connection).getTime());
                break;

            case -102: 
                Calendar calendar1 = connection.getDbTzCalendar();
                date = new Date(((TIMESTAMPLTZ)datum).timestampValue(connection, calendar1 != null ? calendar1 : calendar).getTime());
                break;

            default:
                date = new Date(datum.timestampValue(calendar).getTime());
                break;
            }
        }
        return date;
        Exception exception;
        exception;
        throw exception;
    }

    public Time getTime(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        Time time = null;
        if(datum != null)
        {
            ResultSetMetaData resultsetmetadata = getInternalMetadata();
            switch(resultsetmetadata.getColumnType(i + beginColumnIndex))
            {
            case -101: 
                time = new Time(((TIMESTAMPTZ)datum).timestampValue(connection).getTime());
                break;

            case -102: 
                Calendar calendar1 = connection.getDbTzCalendar();
                time = new Time(((TIMESTAMPLTZ)datum).timestampValue(connection, calendar1 != null ? calendar1 : calendar).getTime());
                break;

            default:
                time = new Time(datum.timestampValue(calendar).getTime());
                break;
            }
        }
        return time;
        Exception exception;
        exception;
        throw exception;
    }

    public Timestamp getTimestamp(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        Timestamp timestamp = null;
        if(datum != null)
        {
            ResultSetMetaData resultsetmetadata = getInternalMetadata();
            switch(resultsetmetadata.getColumnType(i + beginColumnIndex))
            {
            case -101: 
                timestamp = ((TIMESTAMPTZ)datum).timestampValue(connection);
                break;

            case -102: 
                Calendar calendar1 = connection.getDbTzCalendar();
                timestamp = ((TIMESTAMPLTZ)datum).timestampValue(connection, calendar1 != null ? calendar1 : calendar);
                break;

            default:
                timestamp = datum.timestampValue(calendar);
                break;
            }
        }
        return timestamp;
        Exception exception;
        exception;
        throw exception;
    }

    public URL getURL(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        URL url = null;
        int j = getInternalMetadata().getColumnType(i + beginColumnIndex);
        int k = SQLUtil.getInternalType(j);
        if(k == 96 || k == 1 || k == 8)
        {
            try
            {
                String s = getString(i);
                if(s == null)
                    url = null;
                else
                    url = new URL(s);
            }
            catch(MalformedURLException malformedurlexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Conversion to java.net.URL not supported.");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return url;
        Exception exception;
        exception;
        throw exception;
    }

    public ResultSet getCursor(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ROWID getROWID(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof ROWID)
            return (ROWID)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public NUMBER getNUMBER(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof NUMBER)
            return (NUMBER)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public DATE getDATE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum;
        datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_111;
        if(datum instanceof DATE)
            return (DATE)datum;
        if(!(datum instanceof TIMESTAMP)) goto _L2; else goto _L1
_L1:
        TIMESTAMP.toDATE(datum.getBytes());
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        if(!(datum instanceof TIMESTAMPLTZ)) goto _L4; else goto _L3
_L3:
        TIMESTAMPLTZ.toDATE(connection, datum.getBytes());
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L4:
        if(!(datum instanceof TIMESTAMPTZ)) goto _L6; else goto _L5
_L5:
        TIMESTAMPTZ.toDATE(connection, datum.getBytes());
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L6:
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum;
        datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_115;
        if(datum instanceof TIMESTAMP)
            return (TIMESTAMP)datum;
        if(!(datum instanceof TIMESTAMPLTZ)) goto _L2; else goto _L1
_L1:
        TIMESTAMPLTZ.toTIMESTAMP(connection, datum.getBytes());
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        if(!(datum instanceof TIMESTAMPTZ)) goto _L4; else goto _L3
_L3:
        TIMESTAMPTZ.toTIMESTAMP(connection, datum.getBytes());
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L4:
        if(!(datum instanceof DATE)) goto _L6; else goto _L5
_L5:
        new TIMESTAMP((DATE)datum);
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L6:
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum;
        datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_73;
        if(datum instanceof TIMESTAMPTZ)
            return (TIMESTAMPTZ)datum;
        if(!(datum instanceof TIMESTAMPLTZ)) goto _L2; else goto _L1
_L1:
        TIMESTAMPLTZ.toTIMESTAMPTZ(connection, datum.getBytes());
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof TIMESTAMPLTZ)
            return (TIMESTAMPLTZ)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public INTERVALDS getINTERVALDS(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof INTERVALDS)
            return (INTERVALDS)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALDS");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public INTERVALYM getINTERVALYM(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof INTERVALYM)
            return (INTERVALYM)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALYM");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public ARRAY getARRAY(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof ARRAY)
            return (ARRAY)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public STRUCT getSTRUCT(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof STRUCT)
            return (STRUCT)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public OPAQUE getOPAQUE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof OPAQUE)
            return (OPAQUE)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public REF getREF(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof REF)
            return (REF)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public CHAR getCHAR(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof CHAR)
            return (CHAR)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public RAW getRAW(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof RAW)
            return (RAW)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public BLOB getBLOB(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof BLOB)
            return (BLOB)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public CLOB getCLOB(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof CLOB)
            return (CLOB)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public NCLOB getNCLOB(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof NCLOB)
            return (NCLOB)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public BFILE getBFILE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof BFILE)
            return (BFILE)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public BFILE getBfile(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getBFILE(i);
        Exception exception;
        exception;
        throw exception;
    }

    public CustomDatum getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        return customdatumfactory.create(datum, 0);
        Exception exception;
        exception;
        throw exception;
    }

    public ORAData getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        return oradatafactory.create(datum, 0);
        Exception exception;
        exception;
        throw exception;
    }

    public Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return oracledatafactory.create(getObject(i), 0);
        Exception exception;
        exception;
        throw exception;
    }

    public NClob getNClob(int i)
        throws SQLException
    {
        NCLOB nclob = getNCLOB(i);
        if(nclob == null)
            return null;
        if(!(nclob instanceof NClob))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 184);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return nclob;
        }
    }

    public String getNString(int i)
        throws SQLException
    {
        return getString(i);
    }

    public Reader getNCharacterStream(int i)
        throws SQLException
    {
        return getCharacterStream(i);
    }

    public RowId getRowId(int i)
        throws SQLException
    {
        return getROWID(i);
    }

    public SQLXML getSQLXML(int i)
        throws SQLException
    {
        Datum datum = getOracleObject(i);
        if(datum != null)
        {
            if(datum instanceof SQLXML)
            {
                return (SQLXML)datum;
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSQLXML");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        {
            return null;
        }
    }

    public ResultSetMetaData getMetaData()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return new OracleResultSetMetaData(connection, (OracleStatement)scrollStmt, beginColumnIndex);
        Exception exception;
        exception;
        throw exception;
    }

    public int findColumn(String s)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return resultSet.findColumn(s) - beginColumnIndex;
        Exception exception;
        exception;
        throw exception;
    }

    public void setFetchDirection(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            if(i == 1000)
                usrFetchDirection = i;
            else
            if(i == 1001 || i == 1002)
            {
                usrFetchDirection = i;
                sqlWarning = DatabaseError.addSqlWarning(sqlWarning, 87);
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
    }

    public int getFetchDirection()
        throws SQLException
    {
        return 1000;
    }

    public void setFetchSize(int i)
        throws SQLException
    {
        synchronized(connection)
        {
            resultSet.setFetchSize(i);
        }
    }

    public int getFetchSize()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return resultSet.getFetchSize();
        Exception exception;
        exception;
        throw exception;
    }

    public int getType()
        throws SQLException
    {
        return rsetType;
    }

    public int getConcurrency()
        throws SQLException
    {
        return rsetConcurency;
    }

    public void refreshRow()
        throws SQLException
    {
        if(!needIdentifier(rsetType, rsetConcurency))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "refreshRow");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(isValidRow(currentRow))
        {
            int i = getFetchDirection();
            try
            {
                refreshRowsInCache(currentRow, getFetchSize(), i);
            }
            catch(SQLException sqlexception2)
            {
                SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), sqlexception2, 90, "Unsupported syntax for refreshRow()");
                sqlexception3.fillInStackTrace();
                throw sqlexception3;
            }
        } else
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82, "refreshRow");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    private boolean isEmptyResultSet()
        throws SQLException
    {
        if(numRowsCached != 0)
            return false;
        if(numRowsCached == 0 && allRowsCached)
            return true;
        else
            return !isValidRow(1);
    }

    boolean isValidRow(int i)
        throws SQLException
    {
        if(i > 0 && i <= numRowsCached)
            return true;
        if(i <= 0)
            return false;
        else
            return cacheRowAt(i);
    }

    private void cacheCurrentRow(OracleResultSetImpl oracleresultsetimpl, int i)
        throws SQLException
    {
        for(int j = 0; j < getColumnCount(); j++)
        {
            byte abyte0[] = oracleresultsetimpl.privateGetBytes(j + 1);
            oracle.jdbc.OracleResultSet.AuthorizationIndicator authorizationindicator = oracleresultsetimpl.getAuthorizationIndicator(j + 1);
            CachedRowElement cachedrowelement = new CachedRowElement(i, j + 1, authorizationindicator, abyte0);
            int k = oracleresultsetimpl.statement.accessors[j].internalType;
            if(k == 112)
            {
                CLOB clob = oracleresultsetimpl.getCLOB(j + 1);
                cachedrowelement.setData(clob);
            } else
            if(k == 113)
            {
                BLOB blob = oracleresultsetimpl.getBLOB(j + 1);
                cachedrowelement.setData(blob);
            }
            putCachedValueAt(i, j + 1, cachedrowelement);
        }

    }

    private boolean cacheRowAt(int i)
        throws SQLException
    {
        for(; numRowsCached < i && resultSet.next(); cacheCurrentRow(resultSet, ++numRowsCached));
        if(numRowsCached < i)
        {
            allRowsCached = true;
            return false;
        } else
        {
            return true;
        }
    }

    private int cacheAllRows()
        throws SQLException
    {
        for(; resultSet.next(); cacheCurrentRow(resultSet, ++numRowsCached));
        allRowsCached = true;
        return numRowsCached;
    }

    int getColumnCount()
        throws SQLException
    {
        if(columnCount == 0)
        {
            int i = resultSet.statement.numberOfDefinePositions;
            if(resultSet.statement.accessors != null && i > 0)
                columnCount = i;
            else
                columnCount = getInternalMetadata().getColumnCount();
        }
        return columnCount;
    }

    private ResultSetMetaData getInternalMetadata()
        throws SQLException
    {
        if(metadata == null)
            metadata = resultSet.getMetaData();
        return metadata;
    }

    private int getLastRow()
        throws SQLException
    {
        if(!allRowsCached)
            cacheAllRows();
        return numRowsCached;
    }

    private int get_refetch_size(int i, int j, int k)
        throws SQLException
    {
        byte byte0 = ((byte)(k != 1001 ? 1 : -1));
        int l = 0;
        if(refetchRowids == null)
            refetchRowids = new Vector(10);
        else
            refetchRowids.removeAllElements();
        for(; l < j && isValidRow(i + l * byte0); l++)
            refetchRowids.addElement(getCachedDatumValueAt(i + l * byte0, 1));

        return l;
    }

    private OraclePreparedStatement prepare_refetch_statement(int i)
        throws SQLException
    {
        if(i < 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            java.sql.PreparedStatement preparedstatement = connection.prepareStatement(((OracleStatement)scrollStmt).sqlObject.getRefetchSqlForScrollableResultSet(this, i));
            return (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedstatement).preparedStatement;
        }
    }

    private void prepare_refetch_binds(OraclePreparedStatement oraclepreparedstatement, int i)
        throws SQLException
    {
        int j = scrollStmt.copyBinds(oraclepreparedstatement, 0);
        for(int k = 0; k < i; k++)
            oraclepreparedstatement.setROWID(j + k + 1, (ROWID)refetchRowids.elementAt(k));

    }

    private void save_refetch_results(OracleResultSetImpl oracleresultsetimpl, int i, int j, int k)
        throws SQLException
    {
        byte byte0 = ((byte)(k != 1001 ? 1 : -1));
        do
        {
            if(!oracleresultsetimpl.next())
                break;
            ROWID rowid = oracleresultsetimpl.getROWID(1);
            boolean flag = false;
            int l;
            for(l = i; !flag && l < i + j * byte0;)
                if(((ROWID)getCachedDatumValueAt(l, 1)).stringValue(connection).equals(rowid.stringValue(connection)))
                    flag = true;
                else
                    l += byte0;

            if(flag)
                cacheCurrentRow(oracleresultsetimpl, l);
        } while(true);
    }

    private Datum getCachedDatumValueAt(int i, int j)
        throws SQLException
    {
        CachedRowElement cachedrowelement = null;
        try
        {
            cachedrowelement = (CachedRowElement)rsetCache.get(i, j);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        Datum datum = null;
        if(cachedrowelement != null)
        {
            datum = cachedrowelement.getDataAsDatum();
            byte abyte0[] = cachedrowelement.getData();
            if(datum == null && abyte0 != null && abyte0.length > 0)
            {
                int k = getInternalMetadata().getColumnType(j);
                int l = getInternalMetadata().getColumnDisplaySize(j);
                int i1 = ((OracleResultSetMetaData)getInternalMetadata()).getDescription()[j - 1].internalType;
                int j1 = scrollStmt.getMaxFieldSize();
                if(j1 > 0 && j1 < l)
                    l = j1;
                String s = null;
                if(k == 2006 || k == 2002 || k == 2008 || k == 2007 || k == 2003 || k == 2009)
                    s = getInternalMetadata().getColumnTypeName(j);
                short word0 = resultSet.statement.accessors[j - 1].formOfUse;
                if(word0 == 2 && (i1 == 96 || i1 == 1 || i1 == 8 || i1 == 112))
                    datum = SQLUtil.makeNDatum(connection, (byte[])abyte0, i1, s, word0, l);
                else
                    datum = SQLUtil.makeDatum(connection, (byte[])abyte0, i1, s, l);
                cachedrowelement.setData(datum);
            }
        }
        return datum;
    }

    private void putCachedValueAt(int i, int j, CachedRowElement cachedrowelement)
        throws SQLException
    {
        try
        {
            rsetCache.put(i, j, cachedrowelement);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    private void removeCachedRowAt(int i)
        throws SQLException
    {
        try
        {
            rsetCache.remove(i);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public static boolean needIdentifier(int i, int j)
    {
        return (i != 1003 || j != 1007) && (i != 1004 || j != 1007);
    }

    public static boolean needCache(int i, int j)
    {
        return i != 1003 && (i != 1004 || j != 1007);
    }

    public static boolean supportRefreshRow(int i, int j)
    {
        return i != 1003 && (i != 1004 || j != 1007);
    }

    int getFirstUserColumnIndex()
    {
        return beginColumnIndex;
    }

    public String getCursorName()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

    OracleStatement getOracleStatement()
        throws SQLException
    {
        return resultSet != null ? resultSet.getOracleStatement() : null;
    }

    static 
    {
        ClassRef classref = null;
        try
        {
            classref = ClassRef.newInstance("oracle.xdb.XMLType");
        }
        catch(ClassNotFoundException classnotfoundexception) { }
        XMLTYPE_CLASS = classref;
    }
}
