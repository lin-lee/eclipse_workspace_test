// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIdcb.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.OracleResultSetMetaData;
import oracle.jdbc.oracore.OracleTypeADT;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, Accessor, T4C8TTIuds, T4CConnection, 
//            T4CCharAccessor, T4CNumberAccessor, T4CVarcharAccessor, T4CLongAccessor, 
//            T4CVarnumAccessor, T4CBinaryFloatAccessor, T4CBinaryDoubleAccessor, T4CRawAccessor, 
//            T4CLongRawAccessor, T4CRowidAccessor, T4CResultSetAccessor, T4CDateAccessor, 
//            T4CBlobAccessor, T4CClobAccessor, T4CBfileAccessor, T4CNamedTypeAccessor, 
//            T4CRefTypeAccessor, T4CTimestampAccessor, T4CTimestamptzAccessor, T4CTimestampltzAccessor, 
//            T4CIntervalymAccessor, T4CIntervaldsAccessor, T4CMAREngine, OracleStatement, 
//            DBConversion, OracleSql, T4CTTIoac, PhysicalConnection, 
//            CRC64

class T4CTTIdcb extends T4CTTIMsg
{

    static final int DCBRXFR = 1;
    static final int DCBFIOT = 2;
    static final int DCBFHAVECOOKIE = 4;
    static final int DCBFNEWCOOKIE = 8;
    static final int DCBFREM = 16;
    int numuds;
    int colOffset;
    byte ignoreBuff[];
    OracleStatement statement;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIdcb(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)16);
        statement = null;
        ignoreBuff = new byte[40];
    }

    void init(OracleStatement oraclestatement, int i)
    {
        statement = oraclestatement;
        colOffset = i;
    }

    Accessor[] receive(Accessor aaccessor[])
        throws SQLException, IOException
    {
        short word0 = meg.unmarshalUB1();
        if(ignoreBuff.length < word0)
            ignoreBuff = new byte[word0];
        meg.unmarshalNBytes(ignoreBuff, 0, word0);
        int i = (int)meg.unmarshalUB4();
        aaccessor = receiveCommon(aaccessor, false);
        return aaccessor;
    }

    Accessor[] receiveFromRefCursor(Accessor aaccessor[])
        throws SQLException, IOException
    {
        short word0 = meg.unmarshalUB1();
        int i = (int)meg.unmarshalUB4();
        aaccessor = receiveCommon(aaccessor, false);
        return aaccessor;
    }

    Accessor[] receiveCommon(Accessor aaccessor[], boolean flag)
        throws SQLException, IOException
    {
        if(flag)
        {
            numuds = meg.unmarshalUB2();
        } else
        {
            numuds = (int)meg.unmarshalUB4();
            short word0;
            if(numuds > 0)
                word0 = meg.unmarshalUB1();
        }
        if(statement.needToPrepareDefineBuffer && (aaccessor == null || aaccessor.length != numuds + colOffset))
        {
            Accessor aaccessor1[] = new Accessor[numuds + colOffset];
            if(aaccessor != null && aaccessor.length == colOffset)
                System.arraycopy(aaccessor, 0, aaccessor1, 0, colOffset);
            aaccessor = aaccessor1;
        }
        T4C8TTIuds t4c8ttiuds = new T4C8TTIuds((T4CConnection)statement.connection);
        long l = statement.checkSum;
        for(int i = 0; i < numuds; i++)
        {
            t4c8ttiuds.unmarshal();
            String s = meg.conv.CharBytesToString(t4c8ttiuds.getColumName(), t4c8ttiuds.getColumNameByteLength());
            if(statement.needToPrepareDefineBuffer)
                l = fillupAccessors(aaccessor, colOffset + i, t4c8ttiuds, s, l);
            statement.checkSum = l;
        }

        if(!flag)
        {
            byte abyte0[] = meg.unmarshalDALC();
            if(connection.getTTCVersion() >= 3)
            {
                int j = (int)meg.unmarshalUB4();
                int k = (int)meg.unmarshalUB4();
                if(connection.getTTCVersion() >= 4)
                {
                    int i1 = (int)meg.unmarshalUB4();
                    int j1 = (int)meg.unmarshalUB4();
                    byte abyte1[];
                    if(connection.getTTCVersion() >= 5)
                        abyte1 = meg.unmarshalDALC();
                }
            }
        }
        if(statement.needToPrepareDefineBuffer && !flag)
        {
            statement.rowPrefetchInLastFetch = -1;
            statement.describedWithNames = true;
            statement.described = true;
            statement.numberOfDefinePositions = numuds;
            statement.accessors = aaccessor;
            statement.prepareAccessors();
            statement.allocateTmpByteArray();
        }
        return aaccessor;
    }

    long fillupAccessors(Accessor aaccessor[], int i, T4C8TTIuds t4c8ttiuds, String s, long l)
        throws SQLException
    {
        int ai[] = statement.definedColumnType;
        int ai1[] = statement.definedColumnSize;
        int ai2[] = statement.definedColumnFormOfUse;
        int j = statement.sqlObject.includeRowid ? 1 : 0;
        String s1 = null;
        String s2 = null;
        Object obj = null;
        int i2 = 0;
        int j2 = 0;
        int k2 = 0;
        if(i >= j)
        {
            int l2 = i - j;
            if(ai != null && ai.length > l2 && ai[l2] != 0)
                i2 = ai[l2];
            if(ai1 != null && ai1.length > l2 && ai1[l2] > 0)
                j2 = ai1[l2];
            if(ai2 != null && ai2.length > l2 && ai2[l2] > 0)
                k2 = ai2[l2];
        }
        int k = t4c8ttiuds.udsoac.oacmxl;
        switch(t4c8ttiuds.udsoac.oacdty)
        {
        case 96: // '`'
            if(t4c8ttiuds.udsoac.oacmxlc != 0 && t4c8ttiuds.udsoac.oacmxlc < k)
                k = 2 * t4c8ttiuds.udsoac.oacmxlc;
            int i1 = k;
            if((i2 == 1 || i2 == 12) && j2 > 0 && j2 < k)
                i1 = j2;
            aaccessor[i] = new T4CCharAccessor(statement, i1, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, k, i2, j2, meg);
            if((t4c8ttiuds.udsoac.oacfl2 & 0x1000) == 4096 || t4c8ttiuds.udsoac.oacmxlc != 0)
                aaccessor[i].setDisplaySize(t4c8ttiuds.udsoac.oacmxlc);
            break;

        case 2: // '\002'
            aaccessor[i] = new T4CNumberAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        case 1: // '\001'
            if(t4c8ttiuds.udsoac.oacmxlc != 0 && t4c8ttiuds.udsoac.oacmxlc < k)
                k = 2 * t4c8ttiuds.udsoac.oacmxlc;
            int j1 = k;
            if((i2 == 1 || i2 == 12) && j2 > 0 && j2 < k)
                j1 = j2;
            aaccessor[i] = new T4CVarcharAccessor(statement, j1, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, k, i2, j2, meg);
            if((t4c8ttiuds.udsoac.oacfl2 & 0x1000) == 4096 || t4c8ttiuds.udsoac.oacmxlc != 0)
                aaccessor[i].setDisplaySize(t4c8ttiuds.udsoac.oacmxlc);
            break;

        case 8: // '\b'
            if((i2 == 1 || i2 == 12) && connection.versionNumber >= 9000 && j2 < 4001)
            {
                int k1;
                if(j2 > 0)
                    k1 = j2;
                else
                    k1 = 4000;
                k = -1;
                aaccessor[i] = new T4CVarcharAccessor(statement, k1, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, k, i2, j2, meg);
                aaccessor[i].describeType = 8;
            } else
            {
                k = 0;
                aaccessor[i] = new T4CLongAccessor(statement, i + 1, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            }
            break;

        case 6: // '\006'
            aaccessor[i] = new T4CVarnumAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        case 100: // 'd'
            aaccessor[i] = new T4CBinaryFloatAccessor(statement, 4, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        case 101: // 'e'
            aaccessor[i] = new T4CBinaryDoubleAccessor(statement, 8, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        case 23: // '\027'
            aaccessor[i] = new T4CRawAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        case 24: // '\030'
            if(i2 == -2 && j2 < 2001 && connection.versionNumber >= 9000)
            {
                k = -1;
                aaccessor[i] = new T4CRawAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
                aaccessor[i].describeType = 24;
            } else
            {
                aaccessor[i] = new T4CLongRawAccessor(statement, i + 1, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            }
            break;

        case 11: // '\013'
        case 104: // 'h'
        case 208: 
            aaccessor[i] = new T4CRowidAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            if(t4c8ttiuds.udsoac.oacdty == 208)
                aaccessor[i].describeType = 208;
            break;

        case 102: // 'f'
            aaccessor[i] = new T4CResultSetAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        case 12: // '\f'
            aaccessor[i] = new T4CDateAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        case 113: // 'q'
            if(i2 == -4 && connection.versionNumber >= 9000)
            {
                aaccessor[i] = new T4CLongRawAccessor(statement, i + 1, 0x7fffffff, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
                aaccessor[i].describeType = 113;
            } else
            if(i2 == -3 && connection.versionNumber >= 9000)
            {
                aaccessor[i] = new T4CRawAccessor(statement, 4000, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
                aaccessor[i].describeType = 113;
            } else
            {
                aaccessor[i] = new T4CBlobAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
                if(connection.useLobPrefetch && i2 == 2004)
                    aaccessor[i].lobPrefetchSizeForThisColumn = j2;
                else
                    aaccessor[i].lobPrefetchSizeForThisColumn = -1;
            }
            break;

        case 112: // 'p'
            short word0 = 1;
            if(k2 != 0)
                word0 = (short)k2;
            if((i2 == -1 || i2 == -16) && connection.versionNumber >= 9000)
            {
                k = 0;
                aaccessor[i] = new T4CLongAccessor(statement, i + 1, 0x7fffffff, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, word0, i2, j2, meg);
                aaccessor[i].describeType = 112;
            } else
            if((i2 == 12 || i2 == 1 || i2 == -15 || i2 == -9) && connection.versionNumber >= 9000)
            {
                int l1 = 4000;
                if(j2 > 0 && j2 < l1)
                    l1 = j2;
                aaccessor[i] = new T4CVarcharAccessor(statement, l1, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, word0, 4000, i2, j2, meg);
                aaccessor[i].describeType = 112;
            } else
            {
                aaccessor[i] = new T4CClobAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
                if(connection.useLobPrefetch && (i2 == 2005 || i2 == 2011))
                    aaccessor[i].lobPrefetchSizeForThisColumn = j2;
                else
                    aaccessor[i].lobPrefetchSizeForThisColumn = -1;
            }
            break;

        case 114: // 'r'
            aaccessor[i] = new T4CBfileAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            if(connection.useLobPrefetch && i2 == -13)
                aaccessor[i].lobPrefetchSizeForThisColumn = j2;
            else
                aaccessor[i].lobPrefetchSizeForThisColumn = -1;
            break;

        case 109: // 'm'
            s1 = meg.conv.CharBytesToString(t4c8ttiuds.getTypeName(), t4c8ttiuds.getTypeCharLength());
            s2 = meg.conv.CharBytesToString(t4c8ttiuds.getSchemaName(), t4c8ttiuds.getSchemaCharLength());
            String s3 = (new StringBuilder()).append(s2).append(".").append(s1).toString();
            aaccessor[i] = new T4CNamedTypeAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, s3, i2, j2, meg);
            break;

        case 111: // 'o'
            s1 = meg.conv.CharBytesToString(t4c8ttiuds.getTypeName(), t4c8ttiuds.getTypeCharLength());
            s2 = meg.conv.CharBytesToString(t4c8ttiuds.getSchemaName(), t4c8ttiuds.getSchemaCharLength());
            String s4 = (new StringBuilder()).append(s2).append(".").append(s1).toString();
            aaccessor[i] = new T4CRefTypeAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, s4, i2, j2, meg);
            break;

        case 180: 
            aaccessor[i] = new T4CTimestampAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        case 181: 
            aaccessor[i] = new T4CTimestamptzAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        case 231: 
            aaccessor[i] = new T4CTimestampltzAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        case 182: 
            aaccessor[i] = new T4CIntervalymAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        case 183: 
            aaccessor[i] = new T4CIntervaldsAccessor(statement, k, t4c8ttiuds.udsnull, t4c8ttiuds.udsoac.oacflg, t4c8ttiuds.udsoac.oacpre, t4c8ttiuds.udsoac.oacscl, t4c8ttiuds.udsoac.oacfl2, t4c8ttiuds.udsoac.oacmal, t4c8ttiuds.udsoac.oaccsfrm, i2, j2, meg);
            break;

        default:
            aaccessor[i] = null;
            break;
        }
        if(t4c8ttiuds.udsoac.oactoid.length > 0)
            aaccessor[i].internalOtype = new OracleTypeADT(t4c8ttiuds.udsoac.oactoid, t4c8ttiuds.udsoac.oacvsn, t4c8ttiuds.udsoac.oaccsi, t4c8ttiuds.udsoac.oaccsfrm, (new StringBuilder()).append(s2).append(".").append(s1).toString());
        else
            aaccessor[i].internalOtype = null;
        aaccessor[i].columnName = s;
        aaccessor[i].securityAttribute = oracle.jdbc.OracleResultSetMetaData.SecurityAttribute.NONE;
        if((t4c8ttiuds.udsflg & 1) != 0)
            aaccessor[i].securityAttribute = oracle.jdbc.OracleResultSetMetaData.SecurityAttribute.ENABLED;
        else
        if((t4c8ttiuds.udsflg & 2) != 0)
            aaccessor[i].securityAttribute = oracle.jdbc.OracleResultSetMetaData.SecurityAttribute.UNKNOWN;
        if(t4c8ttiuds.udsoac.oacmxl == 0)
            aaccessor[i].isNullByDescribe = true;
        aaccessor[i].udskpos = t4c8ttiuds.getKernelPosition();
        if(connection.calculateChecksum)
        {
            CRC64 _tmp = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, t4c8ttiuds.udsoac.oacdty);
            CRC64 _tmp1 = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, t4c8ttiuds.udsoac.oacmxl);
            CRC64 _tmp2 = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, t4c8ttiuds.udsoac.oacpre);
            CRC64 _tmp3 = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, t4c8ttiuds.udsoac.oacscl);
            CRC64 _tmp4 = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, t4c8ttiuds.udsoac.oaccsfrm);
            if(s1 != null)
            {
                CRC64 _tmp5 = PhysicalConnection.CHECKSUM;
                l = CRC64.updateChecksum(l, (new StringBuilder()).append(s2).append(".").append(s1).toString());
            }
            CRC64 _tmp6 = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, s);
        }
        return l;
    }

}
