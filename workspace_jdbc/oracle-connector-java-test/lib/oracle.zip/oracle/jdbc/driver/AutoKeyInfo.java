// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AutoKeyInfo.java

package oracle.jdbc.driver;

import java.io.Serializable;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;

// Referenced classes of package oracle.jdbc.driver:
//            OracleResultSetMetaData, OracleSql, DatabaseError, OracleReturnResultSet, 
//            Accessor

class AutoKeyInfo extends OracleResultSetMetaData
{

    String originalSql;
    String newSql;
    String tableName;
    oracle.jdbc.internal.OracleStatement.SqlKind sqlKind;
    int sqlParserParamCount;
    String sqlParserParamList[];
    boolean useNamedParameter;
    int current_argument;
    String columnNames[];
    int columnIndexes[];
    int numColumns;
    String tableColumnNames[];
    int tableColumnTypes[];
    int tableMaxLengths[];
    boolean tableNullables[];
    short tableFormOfUses[];
    int tablePrecisions[];
    int tableScales[];
    String tableTypeNames[];
    int autoKeyType;
    static final int KEYFLAG = 0;
    static final int COLUMNAME = 1;
    static final int COLUMNINDEX = 2;
    static final char QMARK = 63;
    int returnTypes[];
    Accessor returnAccessors[];
    private static final ThreadLocal SQL_PARSER = new ThreadLocal() {

        protected OracleSql initialValue()
        {
            return new OracleSql(null);
        }

        protected volatile Object initialValue()
        {
            return initialValue();
        }

    }
;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    AutoKeyInfo(String s)
    {
        sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED;
        originalSql = s;
        autoKeyType = 0;
    }

    AutoKeyInfo(String s, String as[])
    {
        sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED;
        originalSql = s;
        columnNames = as;
        autoKeyType = 1;
    }

    AutoKeyInfo(String s, int ai[])
    {
        sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED;
        originalSql = s;
        columnIndexes = ai;
        autoKeyType = 2;
    }

    private void parseSql()
        throws SQLException
    {
        if(originalSql == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        OracleSql oraclesql = (OracleSql)SQL_PARSER.get();
        oraclesql.initialize(originalSql);
        sqlKind = oraclesql.getSqlKind();
        if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.INSERT)
        {
            sqlParserParamCount = oraclesql.getParameterCount();
            sqlParserParamList = oraclesql.getParameterList();
            if(sqlParserParamList == OracleSql.EMPTY_LIST)
            {
                useNamedParameter = false;
            } else
            {
                useNamedParameter = true;
                current_argument = sqlParserParamCount;
            }
        }
    }

    private String generateUniqueNamedParameter()
    {
        boolean flag;
        String s;
        do
        {
            flag = false;
            s = Integer.toString(++current_argument).intern();
            int i = 0;
            do
            {
                if(i >= sqlParserParamCount)
                    break;
                if(sqlParserParamList[i] == s)
                {
                    flag = true;
                    break;
                }
                i++;
            } while(true);
        } while(flag);
        return (new StringBuilder()).append(":").append(s).toString();
    }

    String getNewSql()
        throws SQLException
    {
        try
        {
            if(newSql != null)
                return newSql;
        }
        catch(Exception exception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), exception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED)
            parseSql();
        switch(autoKeyType)
        {
        case 0: // '\0'
            newSql = (new StringBuilder()).append(originalSql).append(" RETURNING ROWID INTO ").append(useNamedParameter ? ((Object) (generateUniqueNamedParameter())) : ((Object) (Character.valueOf('?')))).toString();
            returnTypes = new int[1];
            returnTypes[0] = 104;
            break;

        case 1: // '\001'
            getNewSqlByColumnName();
            break;

        case 2: // '\002'
            getNewSqlByColumnIndexes();
            break;
        }
        sqlKind = oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED;
        sqlParserParamList = null;
        return newSql;
    }

    private String getNewSqlByColumnName()
        throws SQLException
    {
        returnTypes = new int[columnNames.length];
        columnIndexes = new int[columnNames.length];
        StringBuffer stringbuffer = new StringBuffer(originalSql);
        stringbuffer.append(" RETURNING ");
        for(int j = 0; j < columnNames.length; j++)
        {
            int i = getReturnParamTypeCode(j, columnNames[j], columnIndexes);
            returnTypes[j] = i;
            stringbuffer.append(columnNames[j]);
            if(j < columnNames.length - 1)
                stringbuffer.append(", ");
        }

        stringbuffer.append(" INTO ");
        for(int k = 0; k < columnNames.length - 1; k++)
            stringbuffer.append((new StringBuilder()).append(useNamedParameter ? ((Object) (generateUniqueNamedParameter())) : ((Object) (Character.valueOf('?')))).append(", ").toString());

        stringbuffer.append(useNamedParameter ? ((Object) (generateUniqueNamedParameter())) : ((Object) (Character.valueOf('?'))));
        newSql = new String(stringbuffer);
        return newSql;
    }

    private String getNewSqlByColumnIndexes()
        throws SQLException
    {
        returnTypes = new int[columnIndexes.length];
        StringBuffer stringbuffer = new StringBuffer(originalSql);
        stringbuffer.append(" RETURNING ");
        for(int j = 0; j < columnIndexes.length; j++)
        {
            int l = columnIndexes[j] - 1;
            if(l < 0 || l > tableColumnNames.length)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            int i = tableColumnTypes[l];
            String s = tableColumnNames[l];
            returnTypes[j] = i;
            stringbuffer.append(s);
            if(j < columnIndexes.length - 1)
                stringbuffer.append(", ");
        }

        stringbuffer.append(" INTO ");
        for(int k = 0; k < columnIndexes.length - 1; k++)
            stringbuffer.append((new StringBuilder()).append(useNamedParameter ? ((Object) (generateUniqueNamedParameter())) : ((Object) (Character.valueOf('?')))).append(", ").toString());

        stringbuffer.append(useNamedParameter ? ((Object) (generateUniqueNamedParameter())) : ((Object) (Character.valueOf('?'))));
        newSql = new String(stringbuffer);
        return newSql;
    }

    private final int getReturnParamTypeCode(int i, String s, int ai[])
        throws SQLException
    {
        for(int j = 0; j < tableColumnNames.length; j++)
            if(s.equalsIgnoreCase(tableColumnNames[j]))
            {
                ai[i] = j + 1;
                return tableColumnTypes[j];
            }

        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    final boolean isInsertSqlStmt()
        throws SQLException
    {
        if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED)
            parseSql();
        return sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.INSERT;
    }

    String getTableName()
        throws SQLException
    {
        if(tableName != null)
            return tableName;
        String s = originalSql.trim().toUpperCase();
        int i = s.indexOf("INSERT");
        i = s.indexOf("INTO", i);
        if(i < 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        int j = s.length();
        int k;
        for(k = i + 5; k < j && s.charAt(k) == ' '; k++);
        if(k >= j)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int l;
        for(l = k + 1; l < j && s.charAt(l) != ' ' && s.charAt(l) != '('; l++);
        if(k == l - 1)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        } else
        {
            tableName = s.substring(k, l);
            return tableName;
        }
    }

    void allocateSpaceForDescribedData(int i)
        throws SQLException
    {
        numColumns = i;
        tableColumnNames = new String[i];
        tableColumnTypes = new int[i];
        tableMaxLengths = new int[i];
        tableNullables = new boolean[i];
        tableFormOfUses = new short[i];
        tablePrecisions = new int[i];
        tableScales = new int[i];
        tableTypeNames = new String[i];
    }

    void fillDescribedData(int i, String s, int j, int k, boolean flag, short word0, int l, 
            int i1, String s1)
        throws SQLException
    {
        tableColumnNames[i] = s;
        tableColumnTypes[i] = j;
        tableMaxLengths[i] = k;
        tableNullables[i] = flag;
        tableFormOfUses[i] = word0;
        tablePrecisions[i] = l;
        tableScales[i] = i1;
        tableTypeNames[i] = s1;
    }

    void initMetaData(OracleReturnResultSet oraclereturnresultset)
        throws SQLException
    {
        if(returnAccessors != null)
            return;
        returnAccessors = oraclereturnresultset.returnAccessors;
        switch(autoKeyType)
        {
        case 0: // '\0'
            initMetaDataKeyFlag();
            break;

        case 1: // '\001'
        case 2: // '\002'
            initMetaDataColumnIndexes();
            break;
        }
    }

    void initMetaDataKeyFlag()
        throws SQLException
    {
        returnAccessors[0].columnName = "ROWID";
        returnAccessors[0].describeType = 104;
        returnAccessors[0].describeMaxLength = 4;
        returnAccessors[0].nullable = true;
        returnAccessors[0].precision = 0;
        returnAccessors[0].scale = 0;
        returnAccessors[0].formOfUse = 0;
    }

    void initMetaDataColumnIndexes()
        throws SQLException
    {
        for(int j = 0; j < returnAccessors.length; j++)
        {
            Accessor accessor = returnAccessors[j];
            int i = columnIndexes[j] - 1;
            accessor.columnName = tableColumnNames[i];
            accessor.describeType = tableColumnTypes[i];
            accessor.describeMaxLength = tableMaxLengths[i];
            accessor.nullable = tableNullables[i];
            accessor.precision = tablePrecisions[i];
            accessor.scale = tablePrecisions[i];
            accessor.formOfUse = tableFormOfUses[i];
        }

    }

    int getValidColumnIndex(int i)
        throws SQLException
    {
        if(i <= 0 || i > returnAccessors.length)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return i - 1;
        }
    }

    public int getColumnCount()
        throws SQLException
    {
        return returnAccessors.length;
    }

    public String getColumnName(int i)
        throws SQLException
    {
        if(i <= 0 || i > returnAccessors.length)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return returnAccessors[i - 1].columnName;
        }
    }

    public String getTableName(int i)
        throws SQLException
    {
        if(i <= 0 || i > returnAccessors.length)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return getTableName();
        }
    }

    Accessor[] getDescription()
        throws SQLException
    {
        return returnAccessors;
    }

}
