// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            RowidBinder, Binder, OraclePreparedStatementReadOnly, OraclePreparedStatement, 
//            T4CRowidAccessor

class T4CURowidBinder extends RowidBinder
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    static void init(Binder binder)
    {
        binder.type = 208;
        binder.bytelen = 130;
    }

    T4CURowidBinder()
    {
        theRowidCopyingBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidCopyingBinder;
        init(this);
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
        throws SQLException
    {
        byte abyte1[][] = oraclepreparedstatement.parameterDatum[k];
        byte abyte2[] = abyte1[i];
        if(flag)
            abyte1[i] = null;
        if(abyte2 == null)
        {
            aword0[i2] = -1;
        } else
        {
            aword0[i2] = 0;
            int j2 = T4CRowidAccessor.kgrdc2ub(abyte2, 0, abyte0, j1 + 2, abyte2.length);
            abyte0[j1] = (byte)(j2 >> 8);
            abyte0[j1 + 1] = (byte)(j2 & 0xff);
            aword0[l1] = (short)(j2 + 2);
        }
    }

}
