// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CNamedTypeAccessor.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;

// Referenced classes of package oracle.jdbc.driver:
//            NamedTypeAccessor, T4CMAREngine, OracleStatement, PhysicalConnection

class T4CNamedTypeAccessor extends NamedTypeAccessor
{

    static final int maxLength = 0x7fffffff;
    final int meta[];
    T4CMAREngine mare;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    void processIndicator(int i)
        throws IOException, SQLException
    {
        if(internalType == 1 && describeType == 112 || internalType == 23 && describeType == 113)
        {
            mare.unmarshalUB2();
            mare.unmarshalUB2();
        } else
        if(statement.connection.versionNumber < 9200)
        {
            mare.unmarshalSB2();
            if(!statement.sqlKind.isPlsqlOrCall())
                mare.unmarshalSB2();
        } else
        if(statement.sqlKind.isPlsqlOrCall() || isDMLReturnedParam)
            mare.processIndicator(i <= 0, i);
    }

    String getString(int i)
        throws SQLException
    {
        String s = super.getString(i);
        if(s != null && definedColumnSize > 0 && s.length() > definedColumnSize)
            s = s.substring(0, definedColumnSize);
        return s;
    }

    T4CNamedTypeAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, String s, short word0, int i, boolean flag, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, s, word0, i, flag);
        meta = new int[1];
        mare = t4cmarengine;
    }

    T4CNamedTypeAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, String s, int k1, int l1, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, flag, j, k, l, i1, j1, word0, s);
        meta = new int[1];
        mare = t4cmarengine;
        definedColumnType = k1;
        definedColumnSize = l1;
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        if(isUseLess)
        {
            lastRowProcessed++;
            return false;
        }
        byte abyte0[] = mare.unmarshalDALC();
        byte abyte1[] = mare.unmarshalDALC();
        byte abyte2[] = mare.unmarshalDALC();
        int i = mare.unmarshalUB2();
        long l = mare.unmarshalUB4();
        int j = mare.unmarshalUB2();
        byte abyte3[] = null;
        if(l > 0L)
            abyte3 = mare.unmarshalCLR((int)l, meta);
        else
            abyte3 = new byte[0];
        pickledBytes[lastRowProcessed] = abyte3;
        processIndicator(meta[0]);
        int k = indicatorIndex + lastRowProcessed;
        int i1 = lengthIndex + lastRowProcessed;
        if(rowSpaceIndicator != null)
            if(meta[0] == 0)
            {
                rowSpaceIndicator[k] = -1;
                rowSpaceIndicator[i1] = 0;
            } else
            {
                rowSpaceIndicator[i1] = (short)meta[0];
                rowSpaceIndicator[k] = 0;
            }
        lastRowProcessed++;
        return false;
    }

}
