// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4Caqe.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.aq.AQEnqueueOptions;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4Ctoh, T4CTTIaqm, AQAgentI, 
//            AQMessagePropertiesI, T4CMAREngine, DBConversion, T4CConnection

final class T4Caqe extends T4CTTIfun
{

    static final int KPD_AQ_BUFMSG = 2;
    static final int KPD_AQ_EITHER = 16;
    static final int OCI_COMMIT_ON_SUCCESS = 32;
    static final int ATTR_TRANSFORMATION = 196;
    T4CTTIaqm aqm;
    T4Ctoh toh;
    private byte queueNameBytes[];
    private AQEnqueueOptions enqueueOptions;
    private AQMessagePropertiesI messageProperties;
    private byte messageData[];
    private byte messageOid[];
    private boolean isRawQueue;
    private int nbExtensions;
    private byte extensionTextValues[][];
    private byte extensionBinaryValues[][];
    private int extensionKeywords[];
    private AQAgentI attrRecipientList[];
    private byte recipientTextValues[][];
    private byte recipientBinaryValues[][];
    private int recipientKeywords[];
    private byte aqmcorBytes[];
    private byte aqmeqnBytes[];
    private boolean retrieveMessageId;
    private byte outMsgid[];
    private byte senderAgentName[];
    private byte senderAgentAddress[];
    private byte senderAgentProtocol;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4Caqe(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        queueNameBytes = null;
        enqueueOptions = null;
        messageProperties = null;
        messageData = null;
        messageOid = null;
        isRawQueue = false;
        nbExtensions = 0;
        extensionTextValues = (byte[][])null;
        extensionBinaryValues = (byte[][])null;
        extensionKeywords = null;
        attrRecipientList = null;
        recipientTextValues = (byte[][])null;
        recipientBinaryValues = (byte[][])null;
        recipientKeywords = null;
        retrieveMessageId = false;
        outMsgid = null;
        senderAgentName = null;
        senderAgentAddress = null;
        senderAgentProtocol = 0;
        setFunCode((short)121);
        toh = new T4Ctoh();
        aqm = new T4CTTIaqm(connection, toh);
    }

    void doOAQEQ(String s, AQEnqueueOptions aqenqueueoptions, AQMessagePropertiesI aqmessagepropertiesi, byte abyte0[], byte abyte1[], boolean flag)
        throws SQLException, IOException
    {
        enqueueOptions = aqenqueueoptions;
        messageProperties = aqmessagepropertiesi;
        String s1 = messageProperties.getCorrelation();
        if(s1 != null && s1.length() != 0)
            aqmcorBytes = meg.conv.StringToCharBytes(s1);
        else
            aqmcorBytes = null;
        String s2 = messageProperties.getExceptionQueue();
        if(s2 != null && s2.length() != 0)
            aqmeqnBytes = meg.conv.StringToCharBytes(s2);
        else
            aqmeqnBytes = null;
        AQAgentI aqagenti = (AQAgentI)messageProperties.getSender();
        if(aqagenti != null)
        {
            if(aqagenti.getName() != null)
                senderAgentName = meg.conv.StringToCharBytes(aqagenti.getName());
            else
                senderAgentName = null;
            if(aqagenti.getAddress() != null)
                senderAgentAddress = meg.conv.StringToCharBytes(aqagenti.getAddress());
            else
                senderAgentAddress = null;
            senderAgentProtocol = (byte)aqagenti.getProtocol();
        } else
        {
            senderAgentName = null;
            senderAgentAddress = null;
            senderAgentProtocol = 0;
        }
        messageData = abyte0;
        messageOid = abyte1;
        isRawQueue = flag;
        if(s != null && s.length() != 0)
            queueNameBytes = meg.conv.StringToCharBytes(s);
        else
            queueNameBytes = null;
        attrRecipientList = (AQAgentI[])(AQAgentI[])messageProperties.getRecipientList();
        if(attrRecipientList != null && attrRecipientList.length > 0)
        {
            recipientTextValues = new byte[attrRecipientList.length * 3][];
            recipientBinaryValues = new byte[attrRecipientList.length * 3][];
            recipientKeywords = new int[attrRecipientList.length * 3];
            for(int i = 0; i < attrRecipientList.length; i++)
            {
                if(attrRecipientList[i].getName() != null)
                    recipientTextValues[3 * i] = meg.conv.StringToCharBytes(attrRecipientList[i].getName());
                if(attrRecipientList[i].getAddress() != null)
                    recipientTextValues[3 * i + 1] = meg.conv.StringToCharBytes(attrRecipientList[i].getAddress());
                recipientBinaryValues[3 * i + 2] = new byte[1];
                recipientBinaryValues[3 * i + 2][0] = (byte)attrRecipientList[i].getProtocol();
                recipientKeywords[3 * i] = 3 * i;
                recipientKeywords[3 * i + 1] = 3 * i + 1;
                recipientKeywords[3 * i + 2] = 3 * i + 2;
            }

        }
        String s3 = enqueueOptions.getTransformation();
        if(s3 != null && s3.length() > 0)
        {
            nbExtensions = 1;
            extensionTextValues = new byte[nbExtensions][];
            extensionBinaryValues = new byte[nbExtensions][];
            extensionKeywords = new int[nbExtensions];
            extensionTextValues[0] = meg.conv.StringToCharBytes(s3);
            extensionBinaryValues[0] = null;
            extensionKeywords[0] = 196;
        } else
        {
            nbExtensions = 0;
        }
        outMsgid = null;
        doRPC();
    }

    void marshal()
        throws IOException
    {
        if(queueNameBytes != null && queueNameBytes.length != 0)
        {
            meg.marshalPTR();
            meg.marshalSWORD(queueNameBytes.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        aqm.initToDefaultValues();
        aqm.aqmpri = messageProperties.getPriority();
        aqm.aqmdel = messageProperties.getDelay();
        aqm.aqmexp = messageProperties.getExpiration();
        aqm.aqmcorBytes = aqmcorBytes;
        aqm.aqmeqnBytes = aqmeqnBytes;
        aqm.senderAgentName = senderAgentName;
        aqm.senderAgentAddress = senderAgentAddress;
        aqm.senderAgentProtocol = senderAgentProtocol;
        aqm.originalMsgId = messageProperties.getPreviousQueueMessageId();
        aqm.marshal();
        AQAgentI aaqagenti[] = (AQAgentI[])(AQAgentI[])messageProperties.getRecipientList();
        if(aaqagenti != null && aaqagenti.length > 0)
        {
            meg.marshalPTR();
            meg.marshalSWORD(aaqagenti.length * 3);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        meg.marshalSB4(enqueueOptions.getVisibility().getCode());
        boolean flag = false;
        if(enqueueOptions.getRelativeMessageId() != null && enqueueOptions.getRelativeMessageId().length > 0)
        {
            flag = true;
            meg.marshalPTR();
            meg.marshalSWORD(enqueueOptions.getRelativeMessageId().length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        meg.marshalSWORD(enqueueOptions.getSequenceDeviation().getCode());
        meg.marshalPTR();
        meg.marshalSWORD(16);
        meg.marshalUB2(1);
        if(!isRawQueue)
        {
            meg.marshalPTR();
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalPTR();
            meg.marshalUB4(messageData.length);
        }
        if(enqueueOptions.getRetrieveMessageId())
        {
            retrieveMessageId = true;
            meg.marshalPTR();
            meg.marshalSWORD(16);
        } else
        {
            retrieveMessageId = false;
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        int i = 0;
        if(connection.autocommit)
            i = 32;
        if(enqueueOptions.getDeliveryMode() == oracle.jdbc.aq.AQEnqueueOptions.DeliveryMode.BUFFERED)
            i |= 2;
        meg.marshalUB4(i);
        meg.marshalNULLPTR();
        meg.marshalNULLPTR();
        if(nbExtensions > 0)
        {
            meg.marshalPTR();
            meg.marshalSWORD(nbExtensions);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        meg.marshalNULLPTR();
        meg.marshalSWORD(0);
        meg.marshalNULLPTR();
        meg.marshalSWORD(0);
        meg.marshalNULLPTR();
        if(connection.getTTCVersion() >= 4)
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
            meg.marshalNULLPTR();
            meg.marshalNULLPTR();
        }
        if(queueNameBytes != null && queueNameBytes.length != 0)
            meg.marshalCHR(queueNameBytes);
        if(aaqagenti != null && aaqagenti.length > 0)
            meg.marshalKPDKV(recipientTextValues, recipientBinaryValues, recipientKeywords);
        if(flag)
            meg.marshalB1Array(enqueueOptions.getRelativeMessageId());
        meg.marshalB1Array(messageOid);
        if(!isRawQueue)
        {
            toh.init(messageOid, messageData.length);
            toh.marshal(meg);
            meg.marshalCLR(messageData, 0, messageData.length);
        } else
        {
            meg.marshalB1Array(messageData);
        }
        if(nbExtensions > 0)
            meg.marshalKPDKV(extensionTextValues, extensionBinaryValues, extensionKeywords);
    }

    byte[] getMessageId()
    {
        return outMsgid;
    }

    void readRPA()
        throws SQLException, IOException
    {
        if(retrieveMessageId)
        {
            outMsgid = new byte[16];
            meg.unmarshalBuffer(outMsgid, 0, 16);
        }
        int i = meg.unmarshalUB2();
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
