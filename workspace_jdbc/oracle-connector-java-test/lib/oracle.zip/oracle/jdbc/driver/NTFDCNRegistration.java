// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFDCNRegistration.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.Executor;
import oracle.jdbc.dcn.DatabaseChangeListener;
import oracle.jdbc.dcn.DatabaseChangeRegistration;

// Referenced classes of package oracle.jdbc.driver:
//            NTFRegistration, NTFEventListener

class NTFDCNRegistration extends NTFRegistration
    implements DatabaseChangeRegistration
{

    private final long regid;
    private String tables[];
    private int nbOfStringsInTable;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFDCNRegistration(int i, boolean flag, String s, long l, String s1, String s2, 
            int j, Properties properties, short word0)
    {
        super(i, 2, flag, s, s2, j, properties, s1, word0);
        tables = new String[10];
        nbOfStringsInTable = 0;
        regid = l;
    }

    NTFDCNRegistration(String s, long l, String s1, short word0)
    {
        super(0, 2, false, s, null, 0, null, s1, word0);
        tables = new String[10];
        nbOfStringsInTable = 0;
        regid = l;
    }

    public int getRegistrationId()
    {
        return (int)regid;
    }

    public long getRegId()
    {
        return regid;
    }

    public void addListener(DatabaseChangeListener databasechangelistener, Executor executor)
        throws SQLException
    {
        NTFEventListener ntfeventlistener = new NTFEventListener(databasechangelistener);
        ntfeventlistener.setExecutor(executor);
        addListener(ntfeventlistener);
    }

    public void addListener(DatabaseChangeListener databasechangelistener)
        throws SQLException
    {
        NTFEventListener ntfeventlistener = new NTFEventListener(databasechangelistener);
        addListener(ntfeventlistener);
    }

    public void removeListener(DatabaseChangeListener databasechangelistener)
        throws SQLException
    {
        super.removeListener(databasechangelistener);
    }

    synchronized void addTablesName(String as[], int i)
    {
        if(nbOfStringsInTable + i > tables.length)
        {
            String as1[] = new String[(nbOfStringsInTable + i) * 2];
            System.arraycopy(tables, 0, as1, 0, tables.length);
            tables = as1;
        }
        System.arraycopy(as, 0, tables, nbOfStringsInTable, i);
        nbOfStringsInTable += i;
    }

    public String[] getTables()
    {
        String as[] = new String[nbOfStringsInTable];
        System.arraycopy(tables, 0, as, 0, nbOfStringsInTable);
        return as;
    }

}
