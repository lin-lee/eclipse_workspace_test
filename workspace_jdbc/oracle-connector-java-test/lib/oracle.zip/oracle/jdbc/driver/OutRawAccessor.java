// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OutRawAccessor.java

package oracle.jdbc.driver;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            RawCommonAccessor, OracleStatement, PhysicalConnection, DatabaseError

class OutRawAccessor extends RawCommonAccessor
{

    static final int MAXLENGTH_NEW = 32767;
    static final int MAXLENGTH_OLD = 32767;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OutRawAccessor(OracleStatement oraclestatement, int i, short word0, int j)
        throws SQLException
    {
        init(oraclestatement, 23, 23, word0, true);
        initForDataAccess(j, i, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        if(statement.connection.getVersionNumber() >= 8000)
            internalTypeMaxLength = 32767;
        else
            internalTypeMaxLength = 32767;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        byteLength = internalTypeMaxLength;
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        byte abyte0[] = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            short word0 = rowSpaceIndicator[lengthIndex + i];
            int j = columnIndex + byteLength * i;
            abyte0 = new byte[word0];
            System.arraycopy(rowSpaceByte, j, abyte0, 0, word0);
        }
        return abyte0;
    }

}
