// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4Caqdq.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.aq.AQDequeueOptions;
import oracle.jdbc.aq.AQMessageProperties;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.TIMESTAMP;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4Ctoh, T4CTTIaqm, AQAgentI, 
//            T4CMAREngine, DBConversion, T4CConnection, AQMessagePropertiesI, 
//            T4CTTIoer

final class T4Caqdq extends T4CTTIfun
{

    T4CTTIaqm aqm;
    T4Ctoh toh;
    private String queueName;
    private AQDequeueOptions dequeueOptions;
    private byte payloadToid[];
    private byte queueNameBytes[];
    private byte consumerNameBytes[];
    private byte correlationBytes[];
    private byte conditionBytes[];
    private int nbExtensions;
    private byte extensionTextValues[][];
    private byte extensionBinaryValues[][];
    private int extensionKeywords[];
    private byte payload[];
    private boolean hasAMessageBeenDequeued;
    private byte dequeuedMessageId[];
    private boolean isRawQueue;
    private AQMessagePropertiesI properties;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4Caqdq(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        dequeueOptions = null;
        payloadToid = null;
        queueNameBytes = null;
        consumerNameBytes = null;
        correlationBytes = null;
        conditionBytes = null;
        nbExtensions = 0;
        extensionTextValues = (byte[][])null;
        extensionBinaryValues = (byte[][])null;
        extensionKeywords = null;
        payload = null;
        hasAMessageBeenDequeued = false;
        dequeuedMessageId = null;
        isRawQueue = false;
        properties = null;
        setFunCode((short)122);
        toh = new T4Ctoh();
        aqm = new T4CTTIaqm(connection, toh);
    }

    void doOAQDQ(String s, AQDequeueOptions aqdequeueoptions, byte abyte0[], boolean flag, AQMessagePropertiesI aqmessagepropertiesi)
        throws SQLException, IOException
    {
        queueName = s;
        dequeueOptions = aqdequeueoptions;
        payloadToid = abyte0;
        isRawQueue = flag;
        properties = aqmessagepropertiesi;
        if(queueName != null && queueName.length() != 0)
            queueNameBytes = meg.conv.StringToCharBytes(queueName);
        else
            queueNameBytes = null;
        String s1 = dequeueOptions.getConsumerName();
        if(s1 != null && s1.length() > 0)
            consumerNameBytes = meg.conv.StringToCharBytes(s1);
        else
            consumerNameBytes = null;
        String s2 = dequeueOptions.getCorrelation();
        if(s2 != null && s2.length() != 0)
            correlationBytes = meg.conv.StringToCharBytes(s2);
        else
            correlationBytes = null;
        String s3 = dequeueOptions.getCondition();
        if(s3 != null && s3.length() > 0)
            conditionBytes = meg.conv.StringToCharBytes(s3);
        else
            conditionBytes = null;
        String s4 = dequeueOptions.getTransformation();
        if(s4 != null && s4.length() > 0)
        {
            nbExtensions = 1;
            extensionTextValues = new byte[nbExtensions][];
            extensionBinaryValues = new byte[nbExtensions][];
            extensionKeywords = new int[nbExtensions];
            extensionTextValues[0] = meg.conv.StringToCharBytes(s4);
            extensionBinaryValues[0] = null;
            extensionKeywords[0] = 196;
        } else
        {
            nbExtensions = 0;
        }
        hasAMessageBeenDequeued = false;
        dequeuedMessageId = null;
        payload = null;
        doRPC();
    }

    void marshal()
        throws IOException
    {
        if(queueNameBytes != null && queueNameBytes.length != 0)
        {
            meg.marshalPTR();
            meg.marshalSWORD(queueNameBytes.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        meg.marshalPTR();
        meg.marshalPTR();
        meg.marshalPTR();
        meg.marshalPTR();
        if(consumerNameBytes != null && consumerNameBytes.length != 0)
        {
            meg.marshalPTR();
            meg.marshalSWORD(consumerNameBytes.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        meg.marshalSB4(dequeueOptions.getDequeueMode().getCode());
        meg.marshalSB4(dequeueOptions.getNavigation().getCode());
        meg.marshalSB4(dequeueOptions.getVisibility().getCode());
        meg.marshalSB4(dequeueOptions.getWait());
        byte abyte0[] = dequeueOptions.getDequeueMessageId();
        boolean flag = false;
        if(abyte0 != null && abyte0.length > 0)
        {
            meg.marshalPTR();
            meg.marshalSWORD(abyte0.length);
            flag = true;
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        if(correlationBytes != null && correlationBytes.length != 0)
        {
            meg.marshalPTR();
            meg.marshalSWORD(correlationBytes.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        meg.marshalPTR();
        meg.marshalSWORD(payloadToid.length);
        meg.marshalUB2(1);
        meg.marshalPTR();
        if(dequeueOptions.getRetrieveMessageId())
        {
            meg.marshalPTR();
            meg.marshalSWORD(16);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        int i = 0;
        if(connection.autocommit)
            i = 32;
        if(dequeueOptions.getDeliveryFilter() == oracle.jdbc.aq.AQDequeueOptions.DeliveryFilter.BUFFERED)
            i |= 2;
        else
        if(dequeueOptions.getDeliveryFilter() == oracle.jdbc.aq.AQDequeueOptions.DeliveryFilter.PERSISTENT_OR_BUFFERED)
            i |= 0x10;
        meg.marshalUB4(i);
        if(conditionBytes != null && conditionBytes.length > 0)
        {
            meg.marshalPTR();
            meg.marshalSWORD(conditionBytes.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        if(nbExtensions > 0)
        {
            meg.marshalPTR();
            meg.marshalSWORD(nbExtensions);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalSWORD(0);
        }
        if(queueNameBytes != null && queueNameBytes.length != 0)
            meg.marshalCHR(queueNameBytes);
        if(consumerNameBytes != null && consumerNameBytes.length != 0)
            meg.marshalCHR(consumerNameBytes);
        if(flag)
            meg.marshalB1Array(abyte0);
        if(correlationBytes != null && correlationBytes.length != 0)
            meg.marshalCHR(correlationBytes);
        meg.marshalB1Array(payloadToid);
        if(conditionBytes != null && conditionBytes.length > 0)
            meg.marshalCHR(conditionBytes);
        if(nbExtensions > 0)
            meg.marshalKPDKV(extensionTextValues, extensionBinaryValues, extensionKeywords);
    }

    byte[] getPayload()
    {
        return payload;
    }

    boolean hasAMessageBeenDequeued()
    {
        return hasAMessageBeenDequeued;
    }

    byte[] getDequeuedMessageId()
    {
        return dequeuedMessageId;
    }

    void readRPA()
        throws SQLException, IOException
    {
        hasAMessageBeenDequeued = true;
        int i = (int)meg.unmarshalUB4();
        if(i > 0)
        {
            aqm.initToDefaultValues();
            aqm.receive();
            properties.setPriority(aqm.aqmpri);
            properties.setDelay(aqm.aqmdel);
            properties.setExpiration(aqm.aqmexp);
            if(aqm.aqmcorBytes != null)
            {
                String s = meg.conv.CharBytesToString(aqm.aqmcorBytes, aqm.aqmcorBytesLength, true);
                properties.setCorrelation(s);
            }
            properties.setAttempts(aqm.aqmatt);
            if(aqm.aqmeqnBytes != null)
            {
                String s1 = meg.conv.CharBytesToString(aqm.aqmeqnBytes, aqm.aqmeqnBytesLength, true);
                properties.setExceptionQueue(s1);
            }
            properties.setMessageState(oracle.jdbc.aq.AQMessageProperties.MessageState.getMessageState(aqm.aqmsta));
            properties.setEnqueueTime(aqm.aqmeqt.timestampValue());
            AQAgentI aqagenti = new AQAgentI();
            if(aqm.senderAgentName != null)
                aqagenti.setName(meg.conv.CharBytesToString(aqm.senderAgentName, aqm.senderAgentNameLength, true));
            if(aqm.senderAgentAddress != null)
                aqagenti.setAddress(meg.conv.CharBytesToString(aqm.senderAgentAddress, aqm.senderAgentAddressLength, true));
            aqagenti.setProtocol(aqm.senderAgentProtocol);
            properties.setSender(aqagenti);
            properties.setPreviousQueueMessageId(aqm.originalMsgId);
            properties.setDeliveryMode(oracle.jdbc.aq.AQMessageProperties.DeliveryMode.getDeliveryMode(aqm.aqmflg));
            if(aqm.aqmetiBytes != null)
            {
                String s2 = meg.conv.CharBytesToString(aqm.aqmetiBytes, aqm.aqmetiBytes.length, true);
                properties.setTransactionGroup(s2);
            }
        }
        int j = (int)meg.unmarshalUB4();
        toh.unmarshal(meg);
        int k = toh.imageLength;
        if(k > 0)
        {
            int l = k;
            if(isRawQueue)
            {
                if(k > 4)
                    l -= 4;
                l = Math.min(l, dequeueOptions.getMaximumBufferLength());
                byte abyte1[] = new byte[l];
                int ai[] = new int[1];
                if(k > 4)
                    meg.unmarshalCLR(abyte1, 0, ai, abyte1.length, 4);
                else
                    meg.unmarshalCLR(abyte1, 0, ai, abyte1.length);
                payload = abyte1;
            } else
            {
                byte abyte2[] = new byte[l];
                int ai1[] = new int[1];
                meg.unmarshalCLR(abyte2, 0, ai1, abyte2.length);
                payload = abyte2;
            }
        }
        if(dequeueOptions.getRetrieveMessageId())
        {
            byte abyte0[] = new byte[16];
            meg.unmarshalBuffer(abyte0, 0, 16);
            dequeuedMessageId = abyte0;
        }
    }

    void processError()
        throws SQLException
    {
        if(oer.retCode != 25228)
            oer.processError();
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
