// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;


// Referenced classes of package oracle.jdbc.driver:
//            VarnumBinder, OraclePreparedStatement

class IntBinder extends VarnumBinder
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    IntBinder()
    {
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
    {
        byte abyte1[] = abyte0;
        int j2 = j1 + 1;
        int k2 = oraclepreparedstatement.parameterInt[k][i];
        int l2 = 0;
        if(k2 == 0)
        {
            abyte1[j2] = -128;
            l2 = 1;
        } else
        if(k2 < 0)
        {
            if(k2 == 0x80000000)
            {
                abyte1[j2] = 58;
                abyte1[j2 + 1] = 80;
                abyte1[j2 + 2] = 54;
                abyte1[j2 + 3] = 53;
                abyte1[j2 + 4] = 65;
                abyte1[j2 + 5] = 53;
                abyte1[j2 + 6] = 102;
                l2 = 7;
            } else
            if(-k2 < 100)
            {
                abyte1[j2] = 62;
                abyte1[j2 + 1] = (byte)(101 + k2);
                abyte1[j2 + 2] = 102;
                l2 = 3;
            } else
            if(-k2 < 10000)
            {
                abyte1[j2] = 61;
                abyte1[j2 + 1] = (byte)(101 - -k2 / 100);
                int i3 = -k2 % 100;
                if(i3 != 0)
                {
                    abyte1[j2 + 2] = (byte)(101 - i3);
                    abyte1[j2 + 3] = 102;
                    l2 = 4;
                } else
                {
                    abyte1[j2 + 2] = 102;
                    l2 = 3;
                }
            } else
            if(-k2 < 0xf4240)
            {
                abyte1[j2] = 60;
                abyte1[j2 + 1] = (byte)(101 - -k2 / 10000);
                int j3 = -k2 % 100;
                if(j3 != 0)
                {
                    abyte1[j2 + 2] = (byte)(101 - (-k2 % 10000) / 100);
                    abyte1[j2 + 3] = (byte)(101 - j3);
                    abyte1[j2 + 4] = 102;
                    l2 = 5;
                } else
                {
                    int k3 = (-k2 % 10000) / 100;
                    if(k3 != 0)
                    {
                        abyte1[j2 + 2] = (byte)(101 - k3);
                        abyte1[j2 + 3] = 102;
                        l2 = 4;
                    } else
                    {
                        abyte1[j2 + 2] = 102;
                        l2 = 3;
                    }
                }
            } else
            if(-k2 < 0x5f5e100)
            {
                abyte1[j2] = 59;
                abyte1[j2 + 1] = (byte)(101 - -k2 / 0xf4240);
                int l3 = -k2 % 100;
                if(l3 != 0)
                {
                    abyte1[j2 + 2] = (byte)(101 - (-k2 % 0xf4240) / 10000);
                    abyte1[j2 + 3] = (byte)(101 - (-k2 % 10000) / 100);
                    abyte1[j2 + 4] = (byte)(101 - l3);
                    abyte1[j2 + 5] = 102;
                    l2 = 6;
                } else
                {
                    int i4 = (-k2 % 10000) / 100;
                    if(i4 != 0)
                    {
                        abyte1[j2 + 2] = (byte)(101 - (-k2 % 0xf4240) / 10000);
                        abyte1[j2 + 3] = (byte)(101 - i4);
                        abyte1[j2 + 4] = 102;
                        l2 = 5;
                    } else
                    {
                        int j4 = (-k2 % 0xf4240) / 10000;
                        if(j4 != 0)
                        {
                            abyte1[j2 + 2] = (byte)(101 - j4);
                            abyte1[j2 + 3] = 102;
                            l2 = 4;
                        } else
                        {
                            abyte1[j2 + 2] = 102;
                            l2 = 3;
                        }
                    }
                }
            } else
            {
                abyte1[j2] = 58;
                abyte1[j2 + 1] = (byte)(101 - -k2 / 0x5f5e100);
                int k4 = -k2 % 100;
                if(k4 != 0)
                {
                    abyte1[j2 + 2] = (byte)(101 - (-k2 % 0x5f5e100) / 0xf4240);
                    abyte1[j2 + 3] = (byte)(101 - (-k2 % 0xf4240) / 10000);
                    abyte1[j2 + 4] = (byte)(101 - (-k2 % 10000) / 100);
                    abyte1[j2 + 5] = (byte)(101 - k4);
                    abyte1[j2 + 6] = 102;
                    l2 = 7;
                } else
                {
                    int l4 = (-k2 % 10000) / 100;
                    if(l4 != 0)
                    {
                        abyte1[j2 + 2] = (byte)(101 - (-k2 % 0x5f5e100) / 0xf4240);
                        abyte1[j2 + 3] = (byte)(101 - (-k2 % 0xf4240) / 10000);
                        abyte1[j2 + 4] = (byte)(101 - l4);
                        abyte1[j2 + 5] = 102;
                        l2 = 6;
                    } else
                    {
                        int i5 = (-k2 % 0xf4240) / 10000;
                        if(i5 != 0)
                        {
                            abyte1[j2 + 2] = (byte)(101 - (-k2 % 0x5f5e100) / 0xf4240);
                            abyte1[j2 + 3] = (byte)(101 - i5);
                            abyte1[j2 + 4] = 102;
                            l2 = 5;
                        } else
                        {
                            int j5 = (-k2 % 0x5f5e100) / 0xf4240;
                            if(j5 != 0)
                            {
                                abyte1[j2 + 2] = (byte)(101 - j5);
                                abyte1[j2 + 3] = 102;
                                l2 = 4;
                            } else
                            {
                                abyte1[j2 + 2] = 102;
                                l2 = 3;
                            }
                        }
                    }
                }
            }
        } else
        if(k2 < 100)
        {
            abyte1[j2] = -63;
            abyte1[j2 + 1] = (byte)(k2 + 1);
            l2 = 2;
        } else
        if(k2 < 10000)
        {
            abyte1[j2] = -62;
            abyte1[j2 + 1] = (byte)(k2 / 100 + 1);
            int k5 = k2 % 100;
            if(k5 != 0)
            {
                abyte1[j2 + 2] = (byte)(k5 + 1);
                l2 = 3;
            } else
            {
                l2 = 2;
            }
        } else
        if(k2 < 0xf4240)
        {
            abyte1[j2] = -61;
            abyte1[j2 + 1] = (byte)(k2 / 10000 + 1);
            int l5 = k2 % 100;
            if(l5 != 0)
            {
                abyte1[j2 + 2] = (byte)((k2 % 10000) / 100 + 1);
                abyte1[j2 + 3] = (byte)(l5 + 1);
                l2 = 4;
            } else
            {
                int i6 = (k2 % 10000) / 100;
                if(i6 != 0)
                {
                    abyte1[j2 + 2] = (byte)(i6 + 1);
                    l2 = 3;
                } else
                {
                    l2 = 2;
                }
            }
        } else
        if(k2 < 0x5f5e100)
        {
            abyte1[j2] = -60;
            abyte1[j2 + 1] = (byte)(k2 / 0xf4240 + 1);
            int j6 = k2 % 100;
            if(j6 != 0)
            {
                abyte1[j2 + 2] = (byte)((k2 % 0xf4240) / 10000 + 1);
                abyte1[j2 + 3] = (byte)((k2 % 10000) / 100 + 1);
                abyte1[j2 + 4] = (byte)(j6 + 1);
                l2 = 5;
            } else
            {
                int k6 = (k2 % 10000) / 100;
                if(k6 != 0)
                {
                    abyte1[j2 + 2] = (byte)((k2 % 0xf4240) / 10000 + 1);
                    abyte1[j2 + 3] = (byte)(k6 + 1);
                    l2 = 4;
                } else
                {
                    int l6 = (k2 % 0xf4240) / 10000;
                    if(l6 != 0)
                    {
                        abyte1[j2 + 2] = (byte)(l6 + 1);
                        l2 = 3;
                    } else
                    {
                        l2 = 2;
                    }
                }
            }
        } else
        {
            abyte1[j2] = -59;
            abyte1[j2 + 1] = (byte)(k2 / 0x5f5e100 + 1);
            int i7 = k2 % 100;
            if(i7 != 0)
            {
                abyte1[j2 + 2] = (byte)((k2 % 0x5f5e100) / 0xf4240 + 1);
                abyte1[j2 + 3] = (byte)((k2 % 0xf4240) / 10000 + 1);
                abyte1[j2 + 4] = (byte)((k2 % 10000) / 100 + 1);
                abyte1[j2 + 5] = (byte)(i7 + 1);
                l2 = 6;
            } else
            {
                int j7 = (k2 % 10000) / 100;
                if(j7 != 0)
                {
                    abyte1[j2 + 2] = (byte)((k2 % 0x5f5e100) / 0xf4240 + 1);
                    abyte1[j2 + 3] = (byte)((k2 % 0xf4240) / 10000 + 1);
                    abyte1[j2 + 4] = (byte)(j7 + 1);
                    l2 = 5;
                } else
                {
                    int k7 = (k2 % 0xf4240) / 10000;
                    if(k7 != 0)
                    {
                        abyte1[j2 + 2] = (byte)((k2 % 0x5f5e100) / 0xf4240 + 1);
                        abyte1[j2 + 3] = (byte)(k7 + 1);
                        l2 = 4;
                    } else
                    {
                        int l7 = (k2 % 0x5f5e100) / 0xf4240;
                        if(l7 != 0)
                        {
                            abyte1[j2 + 2] = (byte)(l7 + 1);
                            l2 = 3;
                        } else
                        {
                            l2 = 2;
                        }
                    }
                }
            }
        }
        abyte1[j1] = (byte)l2;
        aword0[i2] = 0;
        aword0[l1] = (short)(l2 + 1);
    }

}
