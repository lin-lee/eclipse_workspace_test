// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIiov.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import oracle.jdbc.oracore.OracleTypeADT;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, Accessor, DBConversion, OracleStatement, 
//            T4C8TTIrxh, T4CConnection, T4C8Oall, T4CMAREngine, 
//            DatabaseError, T4CTTIrxd

class T4CTTIiov extends T4CTTIMsg
{

    T4C8TTIrxh rxh;
    T4CTTIrxd rxd;
    short bindtype;
    byte iovector[];
    int bindcnt;
    int inbinds;
    int outbinds;
    static final byte BV_IN_V = 32;
    static final byte BV_OUT_V = 16;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIiov(T4CConnection t4cconnection, T4C8TTIrxh t4c8ttirxh, T4CTTIrxd t4cttirxd)
        throws SQLException, IOException
    {
        super(t4cconnection, (byte)0);
        bindtype = 0;
        bindcnt = 0;
        inbinds = 0;
        outbinds = 0;
        rxh = t4c8ttirxh;
        rxd = t4cttirxd;
    }

    void init()
        throws SQLException, IOException
    {
    }

    Accessor[] processRXD(Accessor aaccessor[], int i, byte abyte0[], char ac[], short aword0[], int j, DBConversion dbconversion, 
            byte abyte1[], byte abyte2[], InputStream ainputstream[][], byte abyte3[][][], OracleTypeADT aoracletypeadt[][], OracleStatement oraclestatement, byte abyte4[], 
            char ac1[], short aword1[])
        throws SQLException, IOException
    {
        if(abyte2 != null)
        {
            for(int k = 0; k < abyte2.length; k++)
            {
                if((abyte2[k] & 0x10) != 0 && (aaccessor == null || aaccessor.length <= k || aaccessor[k] == null))
                {
                    int l = j + 5 + 10 * k;
                    int i1 = aword0[l + 0] & 0xffff;
                    int j1 = i1;
                    if(i1 == 9)
                        i1 = 1;
                    Accessor accessor = oraclestatement.allocateAccessor(i1, i1, k, 0, (short)0, null, false);
                    accessor.rowSpaceIndicator = null;
                    if(accessor.defineType == 109 || accessor.defineType == 111)
                        accessor.setOffsets(1);
                    if(aaccessor == null)
                    {
                        aaccessor = new Accessor[k + 1];
                        aaccessor[k] = accessor;
                        continue;
                    }
                    if(aaccessor.length <= k)
                    {
                        Accessor aaccessor1[] = new Accessor[k + 1];
                        aaccessor1[k] = accessor;
                        for(int k1 = 0; k1 < aaccessor.length; k1++)
                            if(aaccessor[k1] != null)
                                aaccessor1[k1] = aaccessor[k1];

                        aaccessor = aaccessor1;
                    } else
                    {
                        aaccessor[k] = accessor;
                    }
                    continue;
                }
                if((abyte2[k] & 0x10) == 0 && aaccessor != null && k < aaccessor.length && aaccessor[k] != null)
                    aaccessor[k].isUseLess = true;
            }

        }
        return aaccessor;
    }

    void unmarshalV10()
        throws IOException, SQLException
    {
        rxh.unmarshalV10(rxd);
        bindcnt = rxh.numRqsts;
        iovector = new byte[connection.all8.numberOfBindPositions];
        for(int i = 0; i < iovector.length; i++)
        {
            if((bindtype = meg.unmarshalUB1()) == 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if((bindtype & 0x20) > 0)
            {
                iovector[i] |= 0x20;
                inbinds++;
            }
            if((bindtype & 0x10) > 0)
            {
                iovector[i] |= 0x10;
                outbinds++;
            }
        }

    }

    byte[] getIOVector()
    {
        return iovector;
    }

    boolean isIOVectorEmpty()
    {
        return iovector.length == 0;
    }

}
