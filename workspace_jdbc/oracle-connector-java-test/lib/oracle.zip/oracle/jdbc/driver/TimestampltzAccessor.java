// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   TimestampltzAccessor.java

package oracle.jdbc.driver;

import java.sql.*;
import java.util.*;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            DateTimeCommonAccessor, DatabaseError, OracleStatement, PhysicalConnection

class TimestampltzAccessor extends DateTimeCommonAccessor
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    TimestampltzAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 231, 231, word0, flag);
        initForDataAccess(j, i, null);
    }

    TimestampltzAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        init(oraclestatement, 231, 231, word0, false);
        initForDescribe(231, i, flag, j, k, l, i1, j1, word0, null);
        initForDataAccess(0, i, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        internalTypeMaxLength = 11;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        byteLength = internalTypeMaxLength;
    }

    String getString(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
            return null;
        Calendar calendar = statement.connection.getDbTzCalendar();
        String s = statement.connection.getSessionTimeZone();
        if(s == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        TimeZone timezone = TimeZone.getTimeZone(s);
        Calendar calendar1 = Calendar.getInstance(timezone);
        int j = columnIndex + byteLength * i;
        short word0 = rowSpaceIndicator[lengthIndex + i];
        int k = oracleYear(j);
        calendar.set(1, k);
        calendar.set(2, oracleMonth(j));
        calendar.set(5, oracleDay(j));
        calendar.set(11, oracleHour(j));
        calendar.set(12, oracleMin(j));
        calendar.set(13, oracleSec(j));
        calendar.set(14, 0);
        TimeZoneAdjust(calendar, calendar1);
        k = calendar1.get(1);
        int l = calendar1.get(2) + 1;
        int i1 = calendar1.get(5);
        int j1 = calendar1.get(11);
        int k1 = calendar1.get(12);
        int l1 = calendar1.get(13);
        int i2 = 0;
        boolean flag = j1 < 12;
        String s1 = calendar1.getTimeZone().getID();
        if(s1.length() > 3 && s1.startsWith("GMT"))
            s1 = s1.substring(3);
        if(word0 == 11)
            i2 = oracleNanos(j);
        return toText(k, l, i1, j1, k1, l1, i2, flag, s1);
    }

    Date getDate(int i, Calendar calendar)
        throws SQLException
    {
        return getDate(i);
    }

    Date getDate(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
            return null;
        Calendar calendar = statement.connection.getDbTzCalendar();
        String s = statement.connection.getSessionTimeZone();
        if(s == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            TimeZone timezone = TimeZone.getTimeZone(s);
            Calendar calendar1 = Calendar.getInstance(timezone);
            int j = columnIndex + byteLength * i;
            int k = oracleYear(j);
            calendar.set(1, k);
            calendar.set(2, oracleMonth(j));
            calendar.set(5, oracleDay(j));
            calendar.set(11, oracleHour(j));
            calendar.set(12, oracleMin(j));
            calendar.set(13, oracleSec(j));
            calendar.set(14, 0);
            long l = TimeZoneAdjustUTC(calendar);
            return new Date(l);
        }
    }

    Time getTime(int i, Calendar calendar)
        throws SQLException
    {
        return getTime(i);
    }

    Time getTime(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
            return null;
        Calendar calendar = statement.connection.getDbTzCalendar();
        String s = statement.connection.getSessionTimeZone();
        if(s == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            TimeZone timezone = TimeZone.getTimeZone(s);
            Calendar calendar1 = Calendar.getInstance(timezone);
            int j = columnIndex + byteLength * i;
            int k = oracleYear(j);
            calendar.set(1, k);
            calendar.set(2, oracleMonth(j));
            calendar.set(5, oracleDay(j));
            calendar.set(11, oracleHour(j));
            calendar.set(12, oracleMin(j));
            calendar.set(13, oracleSec(j));
            calendar.set(14, 0);
            long l = TimeZoneAdjustUTC(calendar);
            return new Time(l);
        }
    }

    Timestamp getTimestamp(int i, Calendar calendar)
        throws SQLException
    {
        return getTimestamp(i);
    }

    Timestamp getTimestamp(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
            return null;
        Calendar calendar = statement.connection.getDbTzCalendar();
        String s = statement.connection.getSessionTimeZone();
        if(s == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 198);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        TimeZone timezone = TimeZone.getTimeZone(s);
        Calendar calendar1 = Calendar.getInstance(timezone);
        int j = columnIndex + byteLength * i;
        short word0 = rowSpaceIndicator[lengthIndex + i];
        int k = oracleYear(j);
        calendar.set(1, k);
        calendar.set(2, oracleMonth(j));
        calendar.set(5, oracleDay(j));
        calendar.set(11, oracleHour(j));
        calendar.set(12, oracleMin(j));
        calendar.set(13, oracleSec(j));
        calendar.set(14, 0);
        long l = TimeZoneAdjustUTC(calendar);
        Timestamp timestamp = new Timestamp(l);
        if(word0 == 11)
            timestamp.setNanos(oracleNanos(j));
        return timestamp;
    }

    Object getObject(int i)
        throws SQLException
    {
        return getTIMESTAMPLTZ(i);
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        return getTIMESTAMPLTZ(i);
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        return getTIMESTAMPLTZ(i);
    }

    TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException
    {
        TIMESTAMPLTZ timestampltz = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            short word0 = rowSpaceIndicator[lengthIndex + i];
            int j = columnIndex + byteLength * i;
            byte abyte0[] = new byte[word0];
            System.arraycopy(rowSpaceByte, j, abyte0, 0, word0);
            timestampltz = new TIMESTAMPLTZ(abyte0);
        }
        return timestampltz;
    }

    TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        TIMESTAMPTZ timestamptz = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            short word0 = rowSpaceIndicator[lengthIndex + i];
            int j = columnIndex + byteLength * i;
            byte abyte0[] = new byte[word0];
            System.arraycopy(rowSpaceByte, j, abyte0, 0, word0);
            timestamptz = TIMESTAMPLTZ.toTIMESTAMPTZ(statement.connection, abyte0);
        }
        return timestamptz;
    }

    TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        TIMESTAMPTZ timestamptz = getTIMESTAMPTZ(i);
        return TIMESTAMPTZ.toTIMESTAMP(statement.connection, timestamptz.getBytes());
    }

    DATE getDATE(int i)
        throws SQLException
    {
        TIMESTAMPTZ timestamptz = getTIMESTAMPTZ(i);
        return TIMESTAMPTZ.toDATE(statement.connection, timestamptz.getBytes());
    }

    void TimeZoneAdjust(Calendar calendar, Calendar calendar1)
        throws SQLException
    {
        String s = calendar.getTimeZone().getID();
        String s1 = calendar1.getTimeZone().getID();
        if(!s1.equals(s))
        {
            OffsetDST offsetdst = new OffsetDST();
            byte byte0 = getZoneOffset(calendar, offsetdst);
            int j1 = offsetdst.getOFFSET();
            calendar.add(11, -(j1 / 0x36ee80));
            calendar.add(12, -(j1 % 0x36ee80) / 60000);
            int i;
            if(s1.equals("Custom") || s1.startsWith("GMT") && s1.length() > 3)
            {
                i = calendar1.getTimeZone().getRawOffset();
            } else
            {
                int i2 = ZONEIDMAP.getID(s1);
                if(!ZONEIDMAP.isValidID(i2))
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
                TIMEZONETAB timezonetab = statement.connection.getTIMEZONETAB();
                if(timezonetab.checkID(i2))
                    timezonetab.updateTable(statement.connection, i2);
                Calendar calendar2 = statement.getGMTCalendar();
                calendar2.set(1, calendar.get(1));
                calendar2.set(2, calendar.get(2));
                calendar2.set(5, calendar.get(5));
                calendar2.set(11, calendar.get(11));
                calendar2.set(12, calendar.get(12));
                calendar2.set(13, calendar.get(13));
                calendar2.set(14, calendar.get(14));
                i = timezonetab.getOffset(calendar2, i2);
            }
            calendar.add(11, i / 0x36ee80);
            calendar.add(12, (i % 0x36ee80) / 60000);
        }
        if(s1.equals("Custom") && s.equals("Custom") || s1.startsWith("GMT") && s1.length() > 3 && s.startsWith("GMT") && s.length() > 3)
        {
            int j = calendar.getTimeZone().getRawOffset();
            int l = calendar1.getTimeZone().getRawOffset();
            int k1 = 0;
            if(j != l)
            {
                k1 = j - l;
                k1 = k1 <= 0 ? -k1 : k1;
            }
            if(j > l)
                k1 = -k1;
            calendar.add(11, k1 / 0x36ee80);
            calendar.add(12, (k1 % 0x36ee80) / 60000);
        }
        int k = calendar.get(1);
        int i1 = calendar.get(2);
        int l1 = calendar.get(5);
        int j2 = calendar.get(11);
        int k2 = calendar.get(12);
        int l2 = calendar.get(13);
        int i3 = calendar.get(14);
        calendar1.set(1, k);
        calendar1.set(2, i1);
        calendar1.set(5, l1);
        calendar1.set(11, j2);
        calendar1.set(12, k2);
        calendar1.set(13, l2);
        calendar1.set(14, i3);
    }

    long TimeZoneAdjustUTC(Calendar calendar)
        throws SQLException
    {
        String s = calendar.getTimeZone().getID();
        if(s.equals("Custom") || s.startsWith("GMT") && s.length() > 3)
        {
            int i = calendar.getTimeZone().getRawOffset();
            calendar.add(11, -(i / 0x36ee80));
            calendar.add(12, -(i % 0x36ee80) / 60000);
        } else
        if(!s.equals("GMT") && !s.equals("UTC"))
        {
            OffsetDST offsetdst = new OffsetDST();
            byte byte0 = getZoneOffset(calendar, offsetdst);
            int l = offsetdst.getOFFSET();
            calendar.add(11, -(l / 0x36ee80));
            calendar.add(12, -(l % 0x36ee80) / 60000);
        }
        int j = calendar.get(1);
        int k = calendar.get(2);
        int i1 = calendar.get(5);
        int j1 = calendar.get(11);
        int k1 = calendar.get(12);
        int l1 = calendar.get(13);
        int i2 = calendar.get(14);
        Calendar calendar1 = statement.getGMTCalendar();
        calendar1.set(1, j);
        calendar1.set(2, k);
        calendar1.set(5, i1);
        calendar1.set(11, j1);
        calendar1.set(12, k1);
        calendar1.set(13, l1);
        calendar1.set(14, i2);
        long l2 = calendar1.getTimeInMillis();
        return l2;
    }

    byte getZoneOffset(Calendar calendar, OffsetDST offsetdst)
        throws SQLException
    {
        byte byte0 = 0;
        String s = calendar.getTimeZone().getID();
        if(s == "Custom" || s.startsWith("GMT") && s.length() > 3)
        {
            offsetdst.setOFFSET(calendar.getTimeZone().getRawOffset());
        } else
        {
            int i = ZONEIDMAP.getID(s);
            if(!ZONEIDMAP.isValidID(i))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 199);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            TIMEZONETAB timezonetab = statement.connection.getTIMEZONETAB();
            if(timezonetab.checkID(i))
                timezonetab.updateTable(statement.connection, i);
            byte0 = timezonetab.getLocalOffset(calendar, i, offsetdst);
        }
        return byte0;
    }

}
