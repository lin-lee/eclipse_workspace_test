// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIrxd.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.BitSet;
import java.util.Vector;
import oracle.jdbc.OracleResultSetMetaData;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleStatement;
import oracle.jdbc.oracore.OracleTypeADT;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, DBConversion, T4CMAREngine, DatabaseError, 
//            T4CRowidAccessor, T4CConnection, Accessor, OracleStatement

class T4CTTIrxd extends T4CTTIMsg
{

    static final byte NO_BYTES[] = new byte[0];
    byte buffer[];
    byte bufferCHAR[];
    BitSet bvcColSent;
    int nbOfColumns;
    boolean bvcFound;
    boolean isFirstCol;
    static final byte TTICMD_UNAUTHORIZED = 1;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;
    static final boolean $assertionsDisabled = !oracle/jdbc/driver/T4CTTIrxd.desiredAssertionStatus();

    T4CTTIrxd(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)7);
        bvcColSent = null;
        nbOfColumns = 0;
        bvcFound = false;
        isFirstCol = true;
    }

    void init()
    {
        isFirstCol = true;
    }

    void setNumberOfColumns(int i)
    {
        nbOfColumns = i;
        bvcFound = false;
        if(bvcColSent == null || bvcColSent.length() < nbOfColumns)
            bvcColSent = new BitSet(nbOfColumns);
        else
            bvcColSent.clear();
    }

    void unmarshalBVC(int i)
        throws SQLException, IOException
    {
        int j = 0;
        for(int k = 0; k < bvcColSent.length(); k++)
            bvcColSent.clear(k);

        int l = nbOfColumns / 8 + (nbOfColumns % 8 == 0 ? 0 : 1);
        for(int i1 = 0; i1 < l; i1++)
        {
            byte byte0 = (byte)(meg.unmarshalUB1() & 0xff);
            for(int j1 = 0; j1 < 8; j1++)
                if((byte0 & 1 << j1) != 0)
                {
                    bvcColSent.set(i1 * 8 + j1);
                    j++;
                }

        }

        if(j != i)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.unmarshalBVC: bits missing in vector");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            bvcFound = true;
            return;
        }
    }

    void readBitVector(byte abyte0[])
        throws SQLException, IOException
    {
        for(int i = 0; i < bvcColSent.length(); i++)
            bvcColSent.clear(i);

        if(abyte0 == null || abyte0.length == 0)
        {
            bvcFound = false;
        } else
        {
            for(int j = 0; j < abyte0.length; j++)
            {
                byte byte0 = abyte0[j];
                for(int k = 0; k < 8; k++)
                    if((byte0 & 1 << k) != 0)
                        bvcColSent.set(j * 8 + k);

            }

            bvcFound = true;
        }
    }

    Vector marshal(byte abyte0[], char ac[], short aword0[], int i, byte abyte1[], DBConversion dbconversion, InputStream ainputstream[], 
            byte abyte2[][], OracleTypeADT aoracletypeadt[], byte abyte3[], char ac1[], short aword1[], byte abyte4[], int j, 
            int ai[], boolean flag, int ai1[], int ai2[], int ai3[][], boolean flag1)
        throws IOException
    {
        Vector vector = null;
        try
        {
            marshalTTCcode();
            int k = aword0[i + 0] & 0xffff;
            int l6 = 0;
            int i7 = ai2[0];
            int ai4[] = ai3[0];
            int j7 = 0;
            int k7;
            if(flag1)
            {
                k7 = 1;
                if(!$assertionsDisabled && i7 <= 0)
                    throw new AssertionError("No postoned columns in RXD");
            } else
            {
                for(int l7 = 0; l7 < k; l7++)
                {
                    if(l6 < i7 && ai4[l6] == l7)
                    {
                        l6++;
                        continue;
                    }
                    boolean flag2 = false;
                    int l = i + 5 + 10 * l7;
                    int l5 = aword0[l + 0] & 0xffff;
                    if(abyte4 != null && (abyte4[l7] & 0x20) == 0)
                    {
                        if(l5 == 998)
                            j7++;
                        continue;
                    }
                    int j1 = ((aword0[l + 7] & 0xffff) << 16) + (aword0[l + 8] & 0xffff) + j;
                    int j6 = ((aword0[l + 5] & 0xffff) << 16) + (aword0[l + 6] & 0xffff) + j;
                    int l1 = aword0[j1] & 0xffff;
                    short word0 = aword0[j6];
                    if(l5 == 116)
                    {
                        meg.marshalUB1((short)1);
                        meg.marshalUB1((short)0);
                        continue;
                    }
                    if(l5 == 994)
                    {
                        word0 = -1;
                        int k8 = ai1[3 + l7 * 4 + 0];
                        if(k8 == 109)
                            flag2 = true;
                    } else
                    if(l5 == 8 || l5 == 24 || !flag && ai != null && ai.length > l7 && ai[l7] > 4000)
                    {
                        if(i7 >= ai4.length)
                        {
                            int ai5[] = new int[ai4.length << 1];
                            System.arraycopy(ai4, 0, ai5, 0, ai4.length);
                            ai4 = ai5;
                        }
                        ai4[i7++] = l7;
                        continue;
                    }
                    if(word0 == -1)
                    {
                        if(l5 == 109 || flag2)
                        {
                            meg.marshalDALC(NO_BYTES);
                            meg.marshalDALC(NO_BYTES);
                            meg.marshalDALC(NO_BYTES);
                            meg.marshalUB2(0);
                            meg.marshalUB4(0L);
                            meg.marshalUB2(1);
                            continue;
                        }
                        if(l5 == 998)
                        {
                            j7++;
                            meg.marshalUB4(0L);
                            continue;
                        }
                        if(l5 == 112 || l5 == 113 || l5 == 114)
                        {
                            meg.marshalUB4(0L);
                            continue;
                        }
                        if(l5 != 8 && l5 != 24)
                        {
                            meg.marshalUB1((short)0);
                            continue;
                        }
                    }
                    if(l5 == 998)
                    {
                        int l8 = (aword1[6 + j7 * 8 + 4] & 0xffff) << 16 & 0xffff000 | aword1[6 + j7 * 8 + 5] & 0xffff;
                        int j9 = (aword1[6 + j7 * 8 + 6] & 0xffff) << 16 & 0xffff000 | aword1[6 + j7 * 8 + 7] & 0xffff;
                        int i10 = aword1[6 + j7 * 8] & 0xffff;
                        int j10 = aword1[6 + j7 * 8 + 1] & 0xffff;
                        meg.marshalUB4(l8);
                        for(int i11 = 0; i11 < l8; i11++)
                        {
                            int k11 = j9 + i11 * j10;
                            if(i10 == 9)
                            {
                                int l3 = ac1[k11] / 2;
                                int i5 = 0;
                                i5 = dbconversion.javaCharsToCHARBytes(ac1, k11 + 1, abyte1, 0, l3);
                                meg.marshalCLR(abyte1, i5);
                                continue;
                            }
                            l1 = abyte3[k11];
                            if(l1 < 1)
                                meg.marshalUB1((short)0);
                            else
                                meg.marshalCLR(abyte3, k11 + 1, l1);
                        }

                        j7++;
                        continue;
                    }
                    int j2 = aword0[l + 1] & 0xffff;
                    if(j2 != 0)
                    {
                        int i3 = ((aword0[l + 3] & 0xffff) << 16) + (aword0[l + 4] & 0xffff) + j2 * j;
                        if(l5 == 6)
                        {
                            i3++;
                            l1--;
                        } else
                        if(l5 == 9)
                        {
                            i3 += 2;
                            l1 -= 2;
                        } else
                        if(l5 == 114 || l5 == 113 || l5 == 112)
                            meg.marshalUB4(l1);
                        if(l5 == 109 || l5 == 111)
                        {
                            if(abyte2 == null)
                            {
                                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.marshal: parameterDatum is null");
                                sqlexception1.fillInStackTrace();
                                throw sqlexception1;
                            }
                            byte abyte5[] = abyte2[l7];
                            l1 = abyte5 != null ? abyte5.length : 0;
                            if(l5 == 109)
                            {
                                meg.marshalDALC(NO_BYTES);
                                meg.marshalDALC(NO_BYTES);
                                meg.marshalDALC(NO_BYTES);
                                meg.marshalUB2(0);
                                meg.marshalUB4(l1);
                                meg.marshalUB2(1);
                            }
                            if(l1 > 0)
                                meg.marshalCLR(abyte5, 0, l1);
                            continue;
                        }
                        if(l5 == 104)
                        {
                            i3 += 2;
                            long al[] = T4CRowidAccessor.stringToRowid(abyte0, i3, 18);
                            short word2 = 14;
                            long l10 = al[0];
                            int j11 = (int)al[1];
                            short word3 = 0;
                            long l11 = al[2];
                            int i12 = (int)al[3];
                            if(l10 == 0L && j11 == 0 && l11 == 0L && i12 == 0)
                            {
                                meg.marshalUB1((short)0);
                            } else
                            {
                                meg.marshalUB1(word2);
                                meg.marshalUB4(l10);
                                meg.marshalUB2(j11);
                                meg.marshalUB1(word3);
                                meg.marshalUB4(l11);
                                meg.marshalUB2(i12);
                            }
                            continue;
                        }
                        if(l5 == 208)
                        {
                            i3 += 2;
                            l1 -= 2;
                            meg.marshalUB4(l1);
                            meg.marshalCLR(abyte0, i3, l1);
                            continue;
                        }
                        if(l1 < 1)
                            meg.marshalUB1((short)0);
                        else
                            meg.marshalCLR(abyte0, i3, l1);
                        continue;
                    }
                    int k4 = aword0[l + 9] & 0xffff;
                    int k2 = aword0[l + 2] & 0xffff;
                    int j3 = ((aword0[l + 3] & 0xffff) << 16) + (aword0[l + 4] & 0xffff) + k2 * j + 1;
                    if(l5 == 996)
                    {
                        char c = ac[j3 - 1];
                        if(bufferCHAR == null || bufferCHAR.length < c)
                            bufferCHAR = new byte[c];
                        for(int k9 = 0; k9 < c; k9++)
                        {
                            bufferCHAR[k9] = (byte)((ac[j3 + k9 / 2] & 0xff00) >> 8 & 0xff);
                            if(k9 < c - 1)
                            {
                                bufferCHAR[k9 + 1] = (byte)(ac[j3 + k9 / 2] & 0xff & 0xff);
                                k9++;
                            }
                        }

                        meg.marshalCLR(bufferCHAR, c);
                        if(bufferCHAR.length > 4000)
                            bufferCHAR = null;
                        continue;
                    }
                    int i4;
                    if(l5 == 96)
                    {
                        i4 = l1 / 2;
                        j3--;
                    } else
                    {
                        i4 = (l1 - 2) / 2;
                    }
                    int j5 = 0;
                    if(k4 == 2)
                        j5 = dbconversion.javaCharsToNCHARBytes(ac, j3, abyte1, 0, i4);
                    else
                        j5 = dbconversion.javaCharsToCHARBytes(ac, j3, abyte1, 0, i4);
                    meg.marshalCLR(abyte1, j5);
                }

                k7 = i7;
            }
            if(i7 > 0)
            {
                for(int i8 = 0; i8 < k7; i8++)
                {
                    int j8 = ai4[i8];
                    int i1 = i + 5 + 10 * j8;
                    int i6 = aword0[i1 + 0] & 0xffff;
                    int k1 = ((aword0[i1 + 7] & 0xffff) << 16) + (aword0[i1 + 8] & 0xffff) + j;
                    int k6 = ((aword0[i1 + 5] & 0xffff) << 16) + (aword0[i1 + 6] & 0xffff) + j;
                    short word1 = aword0[k6];
                    int i2 = aword0[k1] & 0xffff;
                    int l2 = aword0[i1 + 2] & 0xffff;
                    int k3 = ((aword0[i1 + 3] & 0xffff) << 16) + (aword0[i1 + 4] & 0xffff) + l2 * j + 1;
                    if(word1 == -1)
                    {
                        meg.marshalUB1((short)0);
                        continue;
                    }
                    if(i6 == 996)
                    {
                        char c1 = ac[k3 - 1];
                        if(bufferCHAR == null || bufferCHAR.length < c1)
                            bufferCHAR = new byte[c1];
                        for(int l9 = 0; l9 < c1; l9++)
                        {
                            bufferCHAR[l9] = (byte)((ac[k3 + l9 / 2] & 0xff00) >> 8 & 0xff);
                            if(l9 < c1 - 1)
                            {
                                bufferCHAR[l9 + 1] = (byte)(ac[k3 + l9 / 2] & 0xff & 0xff);
                                l9++;
                            }
                        }

                        meg.marshalCLR(bufferCHAR, c1);
                        if(bufferCHAR.length > 4000)
                            bufferCHAR = null;
                        continue;
                    }
                    if(i6 != 8 && i6 != 24)
                    {
                        int j4;
                        if(i6 == 96)
                        {
                            j4 = i2 / 2;
                            k3--;
                        } else
                        {
                            j4 = (i2 - 2) / 2;
                        }
                        int l4 = aword0[i1 + 9] & 0xffff;
                        int k5 = 0;
                        if(l4 == 2)
                            k5 = dbconversion.javaCharsToNCHARBytes(ac, k3, abyte1, 0, j4);
                        else
                            k5 = dbconversion.javaCharsToCHARBytes(ac, k3, abyte1, 0, j4);
                        meg.marshalCLR(abyte1, k5);
                        continue;
                    }
                    int i9 = j8;
                    if(ainputstream == null)
                        continue;
                    InputStream inputstream = ainputstream[i9];
                    if(inputstream == null)
                        continue;
                    byte byte0 = 64;
                    if(buffer == null)
                        buffer = new byte[byte0];
                    boolean flag3 = false;
                    meg.marshalUB1((short)254);
                    boolean flag4 = false;
                    do
                    {
                        if(flag4 || connection.sentCancel)
                            break;
                        int k10;
                        try
                        {
                            k10 = inputstream.read(buffer, 0, byte0);
                        }
                        catch(IOException ioexception1)
                        {
                            k10 = -1;
                            if(vector == null)
                                vector = new Vector();
                            vector.add(ioexception1);
                        }
                        if(k10 == -1)
                            flag4 = true;
                        if(k10 > 0)
                        {
                            meg.marshalUB1((short)(k10 & 0xff));
                            meg.marshalB1Array(buffer, 0, k10);
                        }
                    } while(true);
                    meg.marshalUB1((short)0);
                }

            }
            ai2[0] = i7;
            ai3[0] = ai4;
        }
        catch(SQLException sqlexception)
        {
            IOException ioexception = new IOException();
            ioexception.initCause(sqlexception);
            throw ioexception;
        }
        return vector;
    }

    boolean unmarshal(Accessor aaccessor[], int i)
        throws SQLException, IOException
    {
        return unmarshal(aaccessor, 0, i);
    }

    boolean unmarshal(Accessor aaccessor[], int i, int j)
        throws SQLException, IOException
    {
        if(i == 0)
            isFirstCol = true;
        for(int k = i; k < j && k < aaccessor.length; k++)
        {
            if(aaccessor[k] == null)
                continue;
            if(aaccessor[k].physicalColumnIndex < 0)
            {
                int l = 0;
                for(int i1 = 0; i1 < j && i1 < aaccessor.length; i1++)
                {
                    if(aaccessor[i1] == null)
                        continue;
                    aaccessor[i1].physicalColumnIndex = l;
                    if(!aaccessor[i1].isUseLess)
                        l++;
                }

            }
            if(bvcFound && !aaccessor[k].isUseLess && !bvcColSent.get(aaccessor[k].physicalColumnIndex))
            {
                aaccessor[k].copyRow();
                continue;
            }
            byte byte0 = 0;
            if(aaccessor[k].statement.statementType != 2 && !aaccessor[k].statement.sqlKind.isPlsqlOrCall())
            {
                int j1 = aaccessor[k].metaDataIndex + aaccessor[k].lastRowProcessed * 1;
                if(aaccessor[k].securityAttribute == oracle.jdbc.OracleResultSetMetaData.SecurityAttribute.ENABLED)
                    byte0 = (byte)meg.unmarshalUB1();
                aaccessor[k].rowSpaceMetaData[j1] = byte0;
            }
            if(aaccessor[k].unmarshalOneRow())
                return true;
            isFirstCol = false;
        }

        bvcFound = false;
        return false;
    }

    boolean unmarshal(Accessor aaccessor[], int i, int j, int k)
        throws SQLException, IOException
    {
        return false;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
