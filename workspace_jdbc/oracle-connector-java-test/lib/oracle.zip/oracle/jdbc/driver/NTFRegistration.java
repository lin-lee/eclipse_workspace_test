// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFRegistration.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.EventListener;
import java.util.Properties;
import java.util.concurrent.Executor;
import oracle.jdbc.NotificationRegistration;
import oracle.jdbc.aq.AQNotificationEvent;
import oracle.jdbc.aq.AQNotificationListener;
import oracle.jdbc.dcn.DatabaseChangeListener;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            NTFEventListener, NTFDCNEvent, NTFAQEvent, DatabaseError, 
//            PhysicalConnection, NTFManager

abstract class NTFRegistration
{

    private final boolean jdbcGetsNotification;
    private final String clientHost;
    private final int clientTCPPort;
    private final Properties options;
    private final boolean isPurgeOnNTF;
    private final String username;
    private final int namespace;
    private final int jdbcRegId;
    private final String dbName;
    private final short databaseVersion;
    private oracle.jdbc.NotificationRegistration.RegistrationState state;
    private NTFEventListener listeners[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFRegistration(int i, int j, boolean flag, String s, String s1, int k, Properties properties, 
            String s2, short word0)
    {
        listeners = new NTFEventListener[0];
        namespace = j;
        clientHost = s1;
        clientTCPPort = k;
        options = properties;
        jdbcRegId = i;
        username = s2;
        jdbcGetsNotification = flag;
        dbName = s;
        state = oracle.jdbc.NotificationRegistration.RegistrationState.ACTIVE;
        if(options.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
            isPurgeOnNTF = true;
        else
            isPurgeOnNTF = false;
        databaseVersion = word0;
    }

    short getDatabaseVersion()
    {
        return databaseVersion;
    }

    synchronized void addListener(NTFEventListener ntfeventlistener)
        throws SQLException
    {
        if(state == oracle.jdbc.NotificationRegistration.RegistrationState.CLOSED)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 251);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(!jdbcGetsNotification)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 247);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int i = listeners.length;
        for(int j = 0; j < i; j++)
            if(listeners[j].getListener() == ntfeventlistener.getListener())
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 248);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }

        NTFEventListener antfeventlistener[] = new NTFEventListener[i + 1];
        System.arraycopy(listeners, 0, antfeventlistener, 0, i);
        antfeventlistener[i] = ntfeventlistener;
        listeners = antfeventlistener;
    }

    synchronized void removeListener(EventListener eventlistener)
        throws SQLException
    {
        int i = 0;
        int k = listeners.length;
        for(i = 0; i < k && listeners[i].getListener() != eventlistener; i++);
        if(i == k)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 249);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        NTFEventListener antfeventlistener[] = new NTFEventListener[k - 1];
        int l = 0;
        for(int j = 0; j < k; j++)
            if(listeners[j].getListener() != eventlistener)
                antfeventlistener[l++] = listeners[j];

        listeners = antfeventlistener;
    }

    void notify(final NTFDCNEvent event)
    {
        long l1 = 0L;
        NTFEventListener antfeventlistener[] = listeners;
        int i = antfeventlistener.length;
        for(int j = 0; j < i; j++)
        {
            Executor executor = antfeventlistener[j].getExecutor();
            if(executor != null)
            {
                final DatabaseChangeListener l = antfeventlistener[j].getDCNListener();
                executor.execute(new Runnable() {

                    final DatabaseChangeListener val$l;
                    final NTFDCNEvent val$event;
                    final NTFRegistration this$0;

                    public void run()
                    {
                        l.onDatabaseChangeNotification(event);
                    }

            
            {
                this$0 = NTFRegistration.this;
                l = databasechangelistener;
                event = ntfdcnevent;
                super();
            }
                }
);
            } else
            {
                antfeventlistener[j].getDCNListener().onDatabaseChangeNotification(event);
            }
        }

        if(event.isDeregistrationEvent() || isPurgeOnNTF)
        {
            PhysicalConnection.ntfManager.removeRegistration(this);
            PhysicalConnection.ntfManager.freeJdbcRegId(getJdbcRegId());
            PhysicalConnection.ntfManager.cleanListenersT4C(getClientTCPPort());
            state = oracle.jdbc.NotificationRegistration.RegistrationState.CLOSED;
        }
    }

    void notify(final NTFAQEvent event)
    {
        long l1 = 0L;
        NTFEventListener antfeventlistener[] = listeners;
        int i = antfeventlistener.length;
        for(int j = 0; j < i; j++)
        {
            Executor executor = antfeventlistener[j].getExecutor();
            if(executor != null)
            {
                final AQNotificationListener l = antfeventlistener[j].getAQListener();
                executor.execute(new Runnable() {

                    final AQNotificationListener val$l;
                    final NTFAQEvent val$event;
                    final NTFRegistration this$0;

                    public void run()
                    {
                        l.onAQNotification(event);
                    }

            
            {
                this$0 = NTFRegistration.this;
                l = aqnotificationlistener;
                event = ntfaqevent;
                super();
            }
                }
);
            } else
            {
                antfeventlistener[j].getAQListener().onAQNotification(event);
            }
        }

        if(event.getEventType() == oracle.jdbc.aq.AQNotificationEvent.EventType.DEREG || isPurgeOnNTF)
        {
            PhysicalConnection.ntfManager.removeRegistration(this);
            PhysicalConnection.ntfManager.freeJdbcRegId(getJdbcRegId());
            PhysicalConnection.ntfManager.cleanListenersT4C(getClientTCPPort());
            state = oracle.jdbc.NotificationRegistration.RegistrationState.CLOSED;
        }
    }

    public Properties getRegistrationOptions()
    {
        return options;
    }

    int getJdbcRegId()
    {
        return jdbcRegId;
    }

    public String getUserName()
    {
        return username;
    }

    String getClientHost()
    {
        return clientHost;
    }

    int getClientTCPPort()
    {
        return clientTCPPort;
    }

    public String getDatabaseName()
    {
        return dbName;
    }

    public oracle.jdbc.NotificationRegistration.RegistrationState getState()
    {
        return state;
    }

    protected void setState(oracle.jdbc.NotificationRegistration.RegistrationState registrationstate)
    {
        state = registrationstate;
    }

    int getNamespace()
    {
        return namespace;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
