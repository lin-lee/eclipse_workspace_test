// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AQMessageI.java

package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.aq.AQMessage;
import oracle.jdbc.aq.AQMessageProperties;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.sql.*;
import oracle.xdb.XMLType;

// Referenced classes of package oracle.jdbc.driver:
//            OracleConnection, DatabaseError, AQMessagePropertiesI

class AQMessageI
    implements AQMessage
{

    private byte id[];
    private AQMessagePropertiesI properties;
    private byte toid[];
    private byte payload[];
    private STRUCT payLoadSTRUCT;
    private ANYDATA payLoadANYDATA;
    private RAW payLoadRAW;
    private XMLType payLoadXMLType;
    private Connection conn;
    private String typeName;
    private TypeDescriptor sd;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    AQMessageI(AQMessagePropertiesI aqmessagepropertiesi, Connection connection)
    {
        id = null;
        properties = null;
        toid = null;
        properties = aqmessagepropertiesi;
        conn = connection;
    }

    AQMessageI(AQMessagePropertiesI aqmessagepropertiesi)
        throws SQLException
    {
        id = null;
        properties = null;
        toid = null;
        properties = aqmessagepropertiesi;
    }

    void setTypeName(String s)
    {
        typeName = s;
    }

    void setTypeDescriptor(TypeDescriptor typedescriptor)
    {
        sd = typedescriptor;
    }

    public byte[] getMessageId()
    {
        return id;
    }

    void setMessageId(byte abyte0[])
        throws SQLException
    {
        id = abyte0;
    }

    public AQMessageProperties getMessageProperties()
    {
        return properties;
    }

    AQMessagePropertiesI getMessagePropertiesI()
    {
        return properties;
    }

    public void setPayload(byte abyte0[])
        throws SQLException
    {
        payload = abyte0;
        toid = TypeDescriptor.RAWTOID;
    }

    public void setPayload(byte abyte0[], byte abyte1[])
        throws SQLException
    {
        payload = abyte0;
        toid = abyte1;
    }

    public void setPayload(STRUCT struct)
        throws SQLException
    {
        payload = struct.toBytes();
        payLoadSTRUCT = struct;
        toid = struct.getDescriptor().getOracleTypeADT().getTOID();
    }

    public void setPayload(ANYDATA anydata)
        throws SQLException
    {
        payload = anydata.toDatum(conn).shareBytes();
        payLoadANYDATA = anydata;
        toid = TypeDescriptor.ANYDATATOID;
    }

    public void setPayload(RAW raw)
        throws SQLException
    {
        payload = raw.shareBytes();
        payLoadRAW = raw;
        toid = TypeDescriptor.RAWTOID;
    }

    public void setPayload(XMLType xmltype)
        throws SQLException
    {
        payload = xmltype.toBytes();
        payLoadXMLType = xmltype;
        toid = TypeDescriptor.XMLTYPETOID;
    }

    public byte[] getPayload()
    {
        return payload;
    }

    public RAW getRAWPayload()
        throws SQLException
    {
        RAW raw = null;
        if(payLoadRAW != null)
            raw = payLoadRAW;
        else
        if(isRAWPayload())
        {
            payLoadRAW = new RAW(payload);
            raw = payLoadRAW;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return raw;
    }

    public boolean isRAWPayload()
        throws SQLException
    {
        if(toid == null || toid.length != 16)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return compareToid(toid, TypeDescriptor.RAWTOID);
    }

    public STRUCT getSTRUCTPayload()
        throws SQLException
    {
        STRUCT struct = null;
        if(!isSTRUCTPayload())
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(payLoadSTRUCT != null)
        {
            struct = payLoadSTRUCT;
        } else
        {
            if(sd == null)
            {
                typeName = OracleTypeADT.toid2typename(conn, toid);
                sd = TypeDescriptor.getTypeDescriptor(typeName, (oracle.jdbc.driver.OracleConnection)conn);
            }
            if(sd instanceof StructDescriptor)
            {
                struct = new STRUCT((StructDescriptor)sd, payload, conn);
                payLoadSTRUCT = struct;
            } else
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }
        return struct;
    }

    public boolean isSTRUCTPayload()
        throws SQLException
    {
        if(toid == null || toid.length != 16)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        boolean flag = true;
        boolean flag1 = true;
        int i = 0;
        do
        {
            if(i >= 15)
                break;
            if(toid[i] != 0)
            {
                flag1 = false;
                break;
            }
            i++;
        } while(true);
        if(flag1 || isRAWPayload() || isANYDATAPayload())
            flag = false;
        return flag;
    }

    public ANYDATA getANYDATAPayload()
        throws SQLException
    {
        ANYDATA anydata = null;
        if(payLoadANYDATA != null)
            anydata = payLoadANYDATA;
        else
        if(isANYDATAPayload())
        {
            OpaqueDescriptor opaquedescriptor = OpaqueDescriptor.createDescriptor("SYS.ANYDATA", conn);
            OPAQUE opaque = new OPAQUE(opaquedescriptor, payload, conn);
            payLoadANYDATA = new ANYDATA(opaque);
            anydata = payLoadANYDATA;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return anydata;
    }

    public boolean isANYDATAPayload()
        throws SQLException
    {
        if(toid == null || toid.length != 16)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return typeName != null && typeName.equals("SYS.ANYDATA") || compareToid(toid, TypeDescriptor.ANYDATATOID);
    }

    public XMLType getXMLTypePayload()
        throws SQLException
    {
        XMLType xmltype = null;
        if(payLoadXMLType != null)
            xmltype = payLoadXMLType;
        else
        if(isXMLTypePayload())
        {
            OpaqueDescriptor opaquedescriptor = OpaqueDescriptor.createDescriptor("SYS.XMLTYPE", conn);
            OPAQUE opaque = new OPAQUE(opaquedescriptor, payload, conn);
            payLoadXMLType = XMLType.createXML(opaque);
            xmltype = payLoadXMLType;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 193);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return xmltype;
    }

    public boolean isXMLTypePayload()
        throws SQLException
    {
        if(toid == null || toid.length != 16)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 252);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return typeName != null && typeName.equals("SYS.XMLTYPE") || compareToid(toid, TypeDescriptor.XMLTYPETOID);
    }

    public byte[] getPayloadTOID()
    {
        return toid;
    }

    static boolean compareToid(byte abyte0[], byte abyte1[])
    {
        boolean flag = false;
        if(abyte0 != null)
            if(abyte0 == abyte1)
                flag = true;
            else
            if(abyte0.length == abyte1.length)
            {
                boolean flag1 = true;
                int i = 0;
                do
                {
                    if(i >= abyte0.length)
                        break;
                    if(abyte0[i] != abyte1[i])
                    {
                        flag1 = false;
                        break;
                    }
                    i++;
                } while(true);
                if(flag1)
                    flag = true;
            }
        return flag;
    }

    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append("Message Properties={");
        stringbuffer.append(properties);
        stringbuffer.append("} ");
        return stringbuffer.toString();
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
