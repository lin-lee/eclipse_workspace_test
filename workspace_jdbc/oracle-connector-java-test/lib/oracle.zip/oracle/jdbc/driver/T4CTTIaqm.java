// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIaqm.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.sql.TIMESTAMP;

// Referenced classes of package oracle.jdbc.driver:
//            T4CConnection, T4CMAREngine, T4Ctoh

class T4CTTIaqm
{

    static final int ATTR_ORIGINAL_MSGID = 69;
    static final byte ATTR_AGENT_NAME = 64;
    static final byte ATTR_AGENT_ADDRESS = 65;
    static final byte ATTR_AGENT_PROTOCOL = 66;
    static final int AQM_MSG_NO_DELAY = 0;
    static final int AQM_MSG_NO_EXPIRATION = -1;
    static final int AQM_MSGPROP_CORRID_SIZE = 128;
    int aqmpri;
    int aqmdel;
    int aqmexp;
    byte aqmcorBytes[];
    int aqmcorBytesLength;
    int aqmatt;
    byte aqmeqnBytes[];
    int aqmeqnBytesLength;
    int aqmsta;
    private byte aqmeqtBuffer[];
    private int retInt[];
    TIMESTAMP aqmeqt;
    byte aqmetiBytes[];
    byte senderAgentName[];
    int senderAgentNameLength;
    byte senderAgentAddress[];
    int senderAgentAddressLength;
    byte senderAgentProtocol;
    byte originalMsgId[];
    T4Ctoh toh;
    int aqmcsn;
    int aqmdsn;
    int aqmflg;
    T4CMAREngine mar;
    T4CConnection connection;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIaqm(T4CConnection t4cconnection, T4Ctoh t4ctoh)
    {
        aqmeqtBuffer = new byte[7];
        retInt = new int[1];
        senderAgentName = null;
        senderAgentNameLength = 0;
        senderAgentAddress = null;
        senderAgentAddressLength = 0;
        senderAgentProtocol = 0;
        toh = t4ctoh;
        connection = t4cconnection;
        mar = connection.mare;
    }

    void initToDefaultValues()
    {
        aqmpri = 0;
        aqmdel = 0;
        aqmexp = -1;
        aqmcorBytes = null;
        aqmcorBytesLength = 0;
        aqmatt = 0;
        aqmeqnBytes = null;
        aqmeqnBytesLength = 0;
        aqmsta = 0;
        aqmeqt = null;
        aqmetiBytes = null;
        senderAgentName = null;
        senderAgentNameLength = 0;
        senderAgentAddress = null;
        senderAgentAddressLength = 0;
        senderAgentProtocol = 0;
        originalMsgId = null;
        aqmcsn = 0;
        aqmdsn = 0;
        aqmflg = 0;
    }

    void marshal()
        throws IOException
    {
        mar.marshalSB4(aqmpri);
        mar.marshalSB4(aqmdel);
        mar.marshalSB4(aqmexp);
        if(aqmcorBytes != null && aqmcorBytes.length != 0)
        {
            mar.marshalSWORD(aqmcorBytes.length);
            mar.marshalCLR(aqmcorBytes, 0, aqmcorBytes.length);
        } else
        {
            mar.marshalSWORD(0);
        }
        mar.marshalSB4(0);
        if(aqmeqnBytes != null && aqmeqnBytes.length != 0)
        {
            mar.marshalSWORD(aqmeqnBytes.length);
            mar.marshalCLR(aqmeqnBytes, 0, aqmeqnBytes.length);
        } else
        {
            mar.marshalSWORD(0);
        }
        mar.marshalSB4(aqmsta);
        mar.marshalSWORD(0);
        if(connection.getTTCVersion() >= 3)
            if(aqmetiBytes != null && aqmetiBytes.length > 0)
            {
                mar.marshalSWORD(aqmetiBytes.length);
                mar.marshalCLR(aqmetiBytes, 0, aqmetiBytes.length);
            } else
            {
                mar.marshalSWORD(0);
            }
        byte byte0 = 4;
        byte abyte0[][] = new byte[byte0][];
        byte abyte1[][] = new byte[byte0][];
        int ai[] = new int[byte0];
        abyte0[0] = senderAgentName;
        abyte1[0] = null;
        ai[0] = 64;
        abyte0[1] = senderAgentAddress;
        abyte1[1] = null;
        ai[1] = 65;
        abyte0[2] = null;
        abyte1[2] = new byte[1];
        abyte1[2][0] = senderAgentProtocol;
        ai[2] = 66;
        abyte0[3] = null;
        abyte1[3] = originalMsgId;
        ai[3] = 69;
        mar.marshalSWORD(byte0);
        mar.marshalUB1((short)14);
        mar.marshalKPDKV(abyte0, abyte1, ai);
        if(connection.getTTCVersion() >= 3)
        {
            mar.marshalUB4(1L);
            toh.init(T4Ctoh.ANYDATA_TOID, 0);
            toh.marshal(mar);
            mar.marshalUB4(0L);
            mar.marshalUB4(0L);
            if(connection.getTTCVersion() >= 4)
                mar.marshalUB4(0L);
        }
    }

    void receive()
        throws SQLException, IOException
    {
        aqmpri = mar.unmarshalSB4();
        aqmdel = mar.unmarshalSB4();
        aqmexp = mar.unmarshalSB4();
        int i = mar.unmarshalSWORD();
        if(i > 0)
        {
            aqmcorBytes = new byte[i];
            int ai[] = new int[1];
            mar.unmarshalCLR(aqmcorBytes, 0, ai, aqmcorBytes.length);
            aqmcorBytesLength = ai[0];
        } else
        {
            aqmcorBytes = null;
        }
        aqmatt = mar.unmarshalSB4();
        int j = mar.unmarshalSWORD();
        if(j > 0)
        {
            aqmeqnBytes = new byte[j];
            int ai1[] = new int[1];
            mar.unmarshalCLR(aqmeqnBytes, 0, ai1, aqmeqnBytes.length);
            aqmeqnBytesLength = ai1[0];
        } else
        {
            aqmeqnBytes = null;
        }
        aqmsta = mar.unmarshalSB4();
        int k = mar.unmarshalSB4();
        if(k > 0)
        {
            mar.unmarshalCLR(aqmeqtBuffer, 0, retInt, 7);
            aqmeqt = new TIMESTAMP(aqmeqtBuffer);
        }
        if(connection.getTTCVersion() >= 3)
        {
            int l = mar.unmarshalSWORD();
            if(l > 0)
            {
                aqmetiBytes = new byte[l];
                int ai2[] = new int[1];
                mar.unmarshalCLR(aqmetiBytes, 0, ai2, aqmetiBytes.length);
            } else
            {
                aqmetiBytes = null;
            }
        }
        int i1 = mar.unmarshalSWORD();
        mar.unmarshalUB1();
        if(i1 > 0)
        {
            byte abyte0[][] = new byte[i1][];
            int ai3[] = new int[i1];
            byte abyte1[][] = new byte[i1][];
            int ai4[] = new int[i1];
            mar.unmarshalKPDKV(abyte0, ai3, abyte1, ai4);
            for(int k1 = 0; k1 < i1; k1++)
            {
                if(ai4[k1] == 64 && abyte0[k1] != null && ai3[k1] > 0)
                {
                    senderAgentName = abyte0[k1];
                    senderAgentNameLength = ai3[k1];
                }
                if(ai4[k1] == 65 && abyte0[k1] != null && ai3[k1] > 0)
                {
                    senderAgentAddress = abyte0[k1];
                    senderAgentAddressLength = ai3[k1];
                }
                if(ai4[k1] == 66 && abyte1[k1] != null && abyte1[k1].length > 0)
                    senderAgentProtocol = abyte1[k1][0];
                if(ai4[k1] == 69 && abyte1[k1] != null && abyte1[k1].length > 0)
                    originalMsgId = abyte1[k1];
            }

        }
        if(connection.getTTCVersion() >= 3)
        {
            int j1 = mar.unmarshalSWORD();
            aqmcsn = (int)mar.unmarshalUB4();
            aqmdsn = (int)mar.unmarshalUB4();
            if(connection.getTTCVersion() >= 4)
                aqmflg = (int)mar.unmarshalUB4();
        }
    }

}
