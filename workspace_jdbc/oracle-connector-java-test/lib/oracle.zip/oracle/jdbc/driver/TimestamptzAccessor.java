// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   TimestamptzAccessor.java

package oracle.jdbc.driver;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import java.util.TimeZone;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMEZONETAB;
import oracle.sql.ZONEIDMAP;

// Referenced classes of package oracle.jdbc.driver:
//            DateTimeCommonAccessor, OracleStatement, PhysicalConnection, DatabaseError

class TimestamptzAccessor extends DateTimeCommonAccessor
{
    abstract class TimestampTzConverter
    {

        final TimestamptzAccessor this$0;

        abstract Date getDate(int i)
            throws SQLException;

        abstract Time getTime(int i)
            throws SQLException;

        abstract Timestamp getTimestamp(int i)
            throws SQLException;

        Object getObject(int i)
            throws SQLException
        {
            return getTIMESTAMPTZ(i);
        }

        Datum getOracleObject(int i)
            throws SQLException
        {
            return getTIMESTAMPTZ(i);
        }

        Object getObject(int i, Map map)
            throws SQLException
        {
            return getTIMESTAMPTZ(i);
        }

        abstract TIMESTAMPTZ getTIMESTAMPTZ(int i)
            throws SQLException;

        TimestampTzConverter()
        {
            this$0 = TimestamptzAccessor.this;
            super();
        }
    }

    class GmtTimestampTzConverter extends TimestampTzConverter
    {

        final TimestamptzAccessor this$0;

        Date getDate(int i)
            throws SQLException
        {
            if(rowSpaceIndicator == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(rowSpaceIndicator[indicatorIndex + i] == -1)
            {
                return null;
            } else
            {
                int j = columnIndex + byteLength * i;
                Calendar calendar = statement.getGMTCalendar();
                int k = oracleYear(j);
                calendar.set(1, k);
                calendar.set(2, oracleMonth(j));
                calendar.set(5, oracleDay(j));
                calendar.set(11, oracleHour(j));
                calendar.set(12, oracleMin(j));
                calendar.set(13, oracleSec(j));
                calendar.set(14, 0);
                long l = calendar.getTimeInMillis();
                return new Date(l);
            }
        }

        Time getTime(int i)
            throws SQLException
        {
            if(rowSpaceIndicator == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(rowSpaceIndicator[indicatorIndex + i] == -1)
            {
                return null;
            } else
            {
                int j = columnIndex + byteLength * i;
                Calendar calendar = statement.getGMTCalendar();
                int k = oracleYear(j);
                calendar.set(1, k);
                calendar.set(2, oracleMonth(j));
                calendar.set(5, oracleDay(j));
                calendar.set(11, oracleHour(j));
                calendar.set(12, oracleMin(j));
                calendar.set(13, oracleSec(j));
                calendar.set(14, 0);
                return new Time(calendar.getTimeInMillis());
            }
        }

        Timestamp getTimestamp(int i)
            throws SQLException
        {
            if(rowSpaceIndicator == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(rowSpaceIndicator[indicatorIndex + i] == -1)
            {
                return null;
            } else
            {
                int j = columnIndex + byteLength * i;
                Calendar calendar = statement.getGMTCalendar();
                int k = oracleYear(j);
                calendar.set(1, k);
                calendar.set(2, oracleMonth(j));
                calendar.set(5, oracleDay(j));
                calendar.set(11, oracleHour(j));
                calendar.set(12, oracleMin(j));
                calendar.set(13, oracleSec(j));
                calendar.set(14, 0);
                long l = calendar.getTimeInMillis();
                Timestamp timestamp = new Timestamp(l);
                int i1 = oracleNanos(j);
                timestamp.setNanos(i1);
                return timestamp;
            }
        }

        TIMESTAMPTZ getTIMESTAMPTZ(int i)
            throws SQLException
        {
            TIMESTAMPTZ timestamptz = null;
            if(rowSpaceIndicator == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(rowSpaceIndicator[indicatorIndex + i] != -1)
            {
                int j = columnIndex + byteLength * i;
                byte abyte0[] = new byte[13];
                System.arraycopy(rowSpaceByte, j, abyte0, 0, 13);
                timestamptz = new TIMESTAMPTZ(abyte0);
            }
            return timestamptz;
        }

        GmtTimestampTzConverter()
        {
            this$0 = TimestamptzAccessor.this;
            super();
        }
    }

    class OldTimestampTzConverter extends TimestampTzConverter
    {

        final TimestamptzAccessor this$0;

        Date getDate(int i)
            throws SQLException
        {
            if(rowSpaceIndicator == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(rowSpaceIndicator[indicatorIndex + i] == -1)
                return null;
            int j = columnIndex + byteLength * i;
            TimeZone timezone = statement.getDefaultTimeZone();
            Calendar calendar = Calendar.getInstance(timezone);
            int k = oracleYear(j);
            calendar.set(1, k);
            calendar.set(2, oracleMonth(j));
            calendar.set(5, oracleDay(j));
            calendar.set(11, oracleHour(j));
            calendar.set(12, oracleMin(j));
            calendar.set(13, oracleSec(j));
            calendar.set(14, 0);
            if((oracleTZ1(j) & TimestamptzAccessor.REGIONIDBIT) != 0)
            {
                int l = TimestamptzAccessor.getHighOrderbits(oracleTZ1(j));
                l += TimestamptzAccessor.getLowOrderbits(oracleTZ2(j));
                TIMEZONETAB timezonetab = statement.connection.getTIMEZONETAB();
                if(timezonetab.checkID(l))
                    timezonetab.updateTable(statement.connection, l);
                int i1 = timezonetab.getOffset(calendar, l);
                boolean flag = timezone.inDaylightTime(calendar.getTime());
                boolean flag1 = timezone.inDaylightTime(new java.util.Date(calendar.getTimeInMillis() + (long)i1));
                if(!flag && flag1)
                    calendar.add(14, -1 * timezone.getDSTSavings());
                else
                if(flag && !flag1)
                    calendar.add(14, timezone.getDSTSavings());
                calendar.add(10, i1 / 0x36ee80);
                calendar.add(12, (i1 % 0x36ee80) / 60000);
            } else
            {
                calendar.add(10, oracleTZ1(j) - TimestamptzAccessor.OFFSET_HOUR);
                calendar.add(12, oracleTZ2(j) - TimestamptzAccessor.OFFSET_MINUTE);
            }
            long l1 = calendar.getTimeInMillis();
            return new Date(l1);
        }

        Time getTime(int i)
            throws SQLException
        {
            if(rowSpaceIndicator == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(rowSpaceIndicator[indicatorIndex + i] == -1)
                return null;
            int j = columnIndex + byteLength * i;
            TimeZone timezone = statement.getDefaultTimeZone();
            Calendar calendar = Calendar.getInstance(timezone);
            int k = oracleYear(j);
            calendar.set(1, k);
            calendar.set(2, oracleMonth(j));
            calendar.set(5, oracleDay(j));
            calendar.set(11, oracleHour(j));
            calendar.set(12, oracleMin(j));
            calendar.set(13, oracleSec(j));
            calendar.set(14, 0);
            if((oracleTZ1(j) & TimestamptzAccessor.REGIONIDBIT) != 0)
            {
                int l = TimestamptzAccessor.getHighOrderbits(oracleTZ1(j));
                l += TimestamptzAccessor.getLowOrderbits(oracleTZ2(j));
                TIMEZONETAB timezonetab = statement.connection.getTIMEZONETAB();
                if(timezonetab.checkID(l))
                    timezonetab.updateTable(statement.connection, l);
                int i1 = timezonetab.getOffset(calendar, l);
                boolean flag = timezone.inDaylightTime(calendar.getTime());
                boolean flag1 = timezone.inDaylightTime(new java.util.Date(calendar.getTimeInMillis() + (long)i1));
                if(!flag && flag1)
                    calendar.add(14, -1 * timezone.getDSTSavings());
                else
                if(flag && !flag1)
                    calendar.add(14, timezone.getDSTSavings());
                calendar.add(10, i1 / 0x36ee80);
                calendar.add(12, (i1 % 0x36ee80) / 60000);
            } else
            {
                calendar.add(10, oracleTZ1(j) - TimestamptzAccessor.OFFSET_HOUR);
                calendar.add(12, oracleTZ2(j) - TimestamptzAccessor.OFFSET_MINUTE);
            }
            long l1 = calendar.getTimeInMillis();
            return new Time(l1);
        }

        Timestamp getTimestamp(int i)
            throws SQLException
        {
            if(rowSpaceIndicator == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(rowSpaceIndicator[indicatorIndex + i] == -1)
                return null;
            int j = columnIndex + byteLength * i;
            TimeZone timezone = statement.getDefaultTimeZone();
            Calendar calendar = Calendar.getInstance(timezone);
            Calendar calendar1 = statement.getGMTCalendar();
            int k = oracleYear(j);
            calendar.set(1, k);
            calendar.set(2, oracleMonth(j));
            calendar.set(5, oracleDay(j));
            calendar.set(11, oracleHour(j));
            calendar.set(12, oracleMin(j));
            calendar.set(13, oracleSec(j));
            calendar.set(14, 0);
            calendar1.set(1, k);
            calendar1.set(2, oracleMonth(j));
            calendar1.set(5, oracleDay(j));
            calendar1.set(11, oracleHour(j));
            calendar1.set(12, oracleMin(j));
            calendar1.set(13, oracleSec(j));
            calendar1.set(14, 0);
            if((oracleTZ1(j) & TimestamptzAccessor.REGIONIDBIT) != 0)
            {
                int l = TimestamptzAccessor.getHighOrderbits(oracleTZ1(j));
                l += TimestamptzAccessor.getLowOrderbits(oracleTZ2(j));
                TIMEZONETAB timezonetab = statement.connection.getTIMEZONETAB();
                if(timezonetab.checkID(l))
                    timezonetab.updateTable(statement.connection, l);
                int i1 = timezonetab.getOffset(calendar1, l);
                boolean flag = timezone.inDaylightTime(calendar.getTime());
                boolean flag1 = timezone.inDaylightTime(new java.util.Date(calendar.getTimeInMillis() + (long)i1));
                if(!flag && flag1)
                    calendar.add(14, -1 * timezone.getDSTSavings());
                else
                if(flag && !flag1)
                    calendar.add(14, timezone.getDSTSavings());
                calendar.add(10, i1 / 0x36ee80);
                calendar.add(12, (i1 % 0x36ee80) / 60000);
            } else
            {
                calendar.add(10, oracleTZ1(j) - TimestamptzAccessor.OFFSET_HOUR);
                calendar.add(12, oracleTZ2(j) - TimestamptzAccessor.OFFSET_MINUTE);
            }
            long l1 = calendar.getTimeInMillis();
            Timestamp timestamp = new Timestamp(l1);
            int j1 = oracleNanos(j);
            timestamp.setNanos(j1);
            return timestamp;
        }

        TIMESTAMPTZ getTIMESTAMPTZ(int i)
            throws SQLException
        {
            TIMESTAMPTZ timestamptz = null;
            if(rowSpaceIndicator == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(rowSpaceIndicator[indicatorIndex + i] != -1)
            {
                int j = columnIndex + byteLength * i;
                byte abyte0[] = new byte[13];
                System.arraycopy(rowSpaceByte, j, abyte0, 0, 13);
                timestamptz = new TIMESTAMPTZ(abyte0);
            }
            return timestamptz;
        }

        OldTimestampTzConverter()
        {
            this$0 = TimestamptzAccessor.this;
            super();
        }
    }


    static final int maxLength = 13;
    TimestampTzConverter tstzConverter;
    static int OFFSET_HOUR = 20;
    static int OFFSET_MINUTE = 60;
    static byte REGIONIDBIT = -128;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    TimestamptzAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        tstzConverter = null;
        init(oraclestatement, 181, 181, word0, flag);
        initForDataAccess(j, i, null);
        if(statement.connection.timestamptzInGmt)
            tstzConverter = new GmtTimestampTzConverter();
        else
            tstzConverter = new OldTimestampTzConverter();
    }

    TimestamptzAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        tstzConverter = null;
        init(oraclestatement, 181, 181, word0, false);
        initForDescribe(181, i, flag, j, k, l, i1, j1, word0, null);
        initForDataAccess(0, i, null);
        if(statement.connection.timestamptzInGmt)
            tstzConverter = new GmtTimestampTzConverter();
        else
            tstzConverter = new OldTimestampTzConverter();
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        internalTypeMaxLength = 13;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        byteLength = internalTypeMaxLength;
    }

    String getString(int i)
        throws SQLException
    {
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] == -1)
            return null;
        int j = columnIndex + byteLength * i;
        int k = 0;
        String s;
        if((oracleTZ1(j) & REGIONIDBIT) != 0)
        {
            k = getHighOrderbits(oracleTZ1(j));
            k += getLowOrderbits(oracleTZ2(j));
            TIMEZONETAB timezonetab = statement.connection.getTIMEZONETAB();
            if(timezonetab.checkID(k))
                timezonetab.updateTable(statement.connection, k);
            s = ZONEIDMAP.getRegion(k);
        } else
        {
            int l = oracleTZ1(j) - OFFSET_HOUR;
            int i1 = oracleTZ2(j) - OFFSET_MINUTE;
            s = (new StringBuilder()).append("GMT").append(l >= 0 ? "+" : "-").append(Math.abs(l)).append(":").append(i1 >= 10 ? "" : "0").append(i1).toString();
        }
        Calendar calendar = statement.getGMTCalendar();
        int j1 = oracleYear(j);
        calendar.set(1, j1);
        calendar.set(2, oracleMonth(j));
        calendar.set(5, oracleDay(j));
        calendar.set(11, oracleHour(j));
        calendar.set(12, oracleMin(j));
        calendar.set(13, oracleSec(j));
        calendar.set(14, 0);
        if((oracleTZ1(j) & REGIONIDBIT) != 0)
        {
            TIMEZONETAB timezonetab1 = statement.connection.getTIMEZONETAB();
            int l1 = timezonetab1.getOffset(calendar, k);
            calendar.add(14, l1);
        } else
        {
            calendar.add(10, oracleTZ1(j) - OFFSET_HOUR);
            calendar.add(12, oracleTZ2(j) - OFFSET_MINUTE);
        }
        j1 = calendar.get(1);
        int k1 = calendar.get(2) + 1;
        int i2 = calendar.get(5);
        int j2 = calendar.get(11);
        int k2 = calendar.get(12);
        int l2 = calendar.get(13);
        boolean flag = j2 < 12;
        if(s.length() > 3 && s.startsWith("GMT"))
            s = s.substring(3);
        int i3 = oracleNanos(j);
        return toText(j1, k1, i2, j2, k2, l2, i3, flag, s);
    }

    Date getDate(int i)
        throws SQLException
    {
        return tstzConverter.getDate(i);
    }

    Date getDate(int i, Calendar calendar)
        throws SQLException
    {
        return getDate(i);
    }

    Time getTime(int i)
        throws SQLException
    {
        return tstzConverter.getTime(i);
    }

    Time getTime(int i, Calendar calendar)
        throws SQLException
    {
        return getTime(i);
    }

    Timestamp getTimestamp(int i)
        throws SQLException
    {
        return tstzConverter.getTimestamp(i);
    }

    Timestamp getTimestamp(int i, Calendar calendar)
        throws SQLException
    {
        return getTimestamp(i);
    }

    Object getObject(int i)
        throws SQLException
    {
        return tstzConverter.getObject(i);
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        return tstzConverter.getOracleObject(i);
    }

    DATE getDATE(int i)
        throws SQLException
    {
        TIMESTAMPTZ timestamptz = tstzConverter.getTIMESTAMPTZ(i);
        return TIMESTAMPTZ.toDATE(statement.connection, timestamptz.getBytes());
    }

    TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        TIMESTAMPTZ timestamptz = tstzConverter.getTIMESTAMPTZ(i);
        return TIMESTAMPTZ.toTIMESTAMP(statement.connection, timestamptz.getBytes());
    }

    TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        return tstzConverter.getTIMESTAMPTZ(i);
    }

    static int setHighOrderbits(int i)
    {
        return (i & 0x1fc0) >> 6;
    }

    static int setLowOrderbits(int i)
    {
        return (i & 0x3f) << 2;
    }

    static int getHighOrderbits(int i)
    {
        return (i & 0x7f) << 6;
    }

    static int getLowOrderbits(int i)
    {
        return (i & 0xfc) >> 2;
    }

}
