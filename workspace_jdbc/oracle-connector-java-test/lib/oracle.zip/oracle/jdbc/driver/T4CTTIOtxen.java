// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIOtxen.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CMAREngine, T4CConnection

final class T4CTTIOtxen extends T4CTTIfun
{

    static final int OTXCOMIT = 1;
    static final int OTXABORT = 2;
    static final int OTXPREPA = 3;
    static final int OTXFORGT = 4;
    static final int OTXRECOV = 5;
    static final int OTXMLPRE = 6;
    static final int K2CMDprepare = 0;
    static final int K2CMDrqcommit = 1;
    static final int K2CMDcommit = 2;
    static final int K2CMDabort = 3;
    static final int K2CMDrdonly = 4;
    static final int K2CMDforget = 5;
    static final int K2CMDrecovered = 7;
    static final int K2CMDtimeout = 8;
    static final int K2STAidle = 0;
    static final int K2STAcollecting = 1;
    static final int K2STAprepared = 2;
    static final int K2STAcommitted = 3;
    static final int K2STAhabort = 4;
    static final int K2STAhcommit = 5;
    static final int K2STAhdamage = 6;
    static final int K2STAtimeout = 7;
    static final int K2STAinactive = 9;
    static final int K2STAactive = 10;
    static final int K2STAptprepared = 11;
    static final int K2STAptcommitted = 12;
    static final int K2STAmax = 13;
    static final int OTXNDEF_F_CWRBATCH = 1;
    static final int OTXNDEF_F_CWRBATOPT = 2;
    static final int OTXNDEF_F_CWRNOWAIT = 4;
    static final int OTXNDEF_F_CWRWATOPT = 8;
    static final int OTXNDEF_F_CWRBATMSK = 3;
    static final int OTXNDEF_F_CWRWATMSK = 12;
    private int operation;
    private int formatId;
    private int gtridLength;
    private int bqualLength;
    private int timeout;
    private int inState;
    private int txnflg;
    private byte transactionContext[];
    private byte xid[];
    private int outState;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIOtxen(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        xid = null;
        outState = -1;
        setFunCode((short)104);
    }

    void doOTXEN(int i, byte abyte0[], byte abyte1[], int j, int k, int l, int i1, 
            int j1, int k1)
        throws IOException, SQLException
    {
        if(i != 1 && i != 2 && i != 3 && i != 4 && i != 5 && i != 6)
        {
            throw new SQLException("Invalid operation.");
        } else
        {
            operation = i;
            formatId = j;
            gtridLength = k;
            bqualLength = l;
            timeout = i1;
            inState = j1;
            txnflg = k1;
            transactionContext = abyte0;
            xid = abyte1;
            outState = -1;
            doRPC();
            return;
        }
    }

    void marshal()
        throws IOException
    {
        int i = operation;
        meg.marshalSWORD(i);
        if(transactionContext == null)
            meg.marshalNULLPTR();
        else
            meg.marshalPTR();
        if(transactionContext == null)
            meg.marshalUB4(0L);
        else
            meg.marshalUB4(transactionContext.length);
        meg.marshalUB4(formatId);
        meg.marshalUB4(gtridLength);
        meg.marshalUB4(bqualLength);
        if(xid != null)
            meg.marshalPTR();
        else
            meg.marshalNULLPTR();
        if(xid != null)
            meg.marshalUB4(xid.length);
        else
            meg.marshalUB4(0L);
        meg.marshalUWORD(timeout);
        meg.marshalUB4(inState);
        meg.marshalPTR();
        if(connection.getTTCVersion() >= 4)
            meg.marshalUB4(txnflg);
        if(transactionContext != null)
            meg.marshalB1Array(transactionContext);
        if(xid != null)
            meg.marshalB1Array(xid);
    }

    void readRPA()
        throws IOException, SQLException
    {
        outState = (int)meg.unmarshalUB4();
    }

    int getOutStateFromServer()
    {
        return outState;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
