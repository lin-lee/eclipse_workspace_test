// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFConnection.java

package oracle.jdbc.driver;

import java.io.EOFException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.util.Iterator;
import java.util.Set;
import oracle.jdbc.aq.AQNotificationEvent;
import oracle.jdbc.dcn.DatabaseChangeEvent;
import oracle.sql.CharacterSet;

// Referenced classes of package oracle.jdbc.driver:
//            NTFRegistration, NTFDCNEvent, NTFAQEvent, NTFManager

class NTFConnection extends Thread
{

    private static final int NS_HEADER_SIZE = 10;
    private SocketChannel channel;
    private ByteBuffer inBuffer;
    private ByteBuffer outBuffer;
    private int currentNSPacketLength;
    private int currentNSPacketType;
    private ByteBuffer currentNSPacketDataBuffer;
    private boolean needsToBeClosed;
    private NTFManager ntfManager;
    private Selector selector;
    private Iterator iterator;
    private SelectionKey aKey;
    int remotePort;
    String remoteAddress;
    String remoteName;
    int localPort;
    String localAddress;
    String localName;
    String connectionDescription;
    CharacterSet charset;
    static final int NSPTCN = 1;
    static final int NSPTAC = 2;
    static final int NSPTAK = 3;
    static final int NSPTRF = 4;
    static final int NSPTRD = 5;
    static final int NSPTDA = 6;
    static final int NSPTNL = 7;
    static final int NSPTAB = 9;
    static final int NSPTRS = 11;
    static final int NSPTMK = 12;
    static final int NSPTAT = 13;
    static final int NSPTCNL = 14;
    static final int NSPTHI = 19;
    static final short KPDNFY_TIMEOUT = 1;
    static final short KPDNFY_GROUPING = 2;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFConnection(NTFManager ntfmanager, SocketChannel socketchannel)
    {
        inBuffer = null;
        outBuffer = null;
        needsToBeClosed = false;
        selector = null;
        iterator = null;
        aKey = null;
        charset = null;
        try
        {
            ntfManager = ntfmanager;
            channel = socketchannel;
            channel.configureBlocking(false);
            inBuffer = ByteBuffer.allocate(4096);
            outBuffer = ByteBuffer.allocate(2048);
            Socket socket = channel.socket();
            InetAddress inetaddress = socket.getInetAddress();
            InetAddress inetaddress1 = socket.getLocalAddress();
            remotePort = socket.getPort();
            localPort = socket.getLocalPort();
            remoteAddress = inetaddress.getHostAddress();
            remoteName = inetaddress.getHostName();
            localAddress = inetaddress1.getHostAddress();
            localName = inetaddress1.getHostName();
            connectionDescription = (new StringBuilder()).append("local=").append(localName).append("/").append(localAddress).append(":").append(localPort).append(", remote=").append(remoteName).append("/").append(remoteAddress).append(":").append(remotePort).toString();
        }
        catch(IOException ioexception) { }
    }

    public void run()
    {
        try
        {
            selector = Selector.open();
            channel.register(selector, 1);
            boolean flag = false;
            inBuffer.limit(0);
            for(; !needsToBeClosed; unmarshalOneNSPacket())
            {
                if(inBuffer.hasRemaining())
                    continue;
                int i;
                do
                    i = readFromNetwork();
                while(i == 0);
            }

        }
        catch(IOException ioexception1)
        {
            try
            {
                selector.close();
                channel.close();
            }
            catch(IOException ioexception2) { }
            break MISSING_BLOCK_LABEL_150;
        }
        catch(InterruptedException interruptedexception)
        {
            try
            {
                selector.close();
                channel.close();
            }
            catch(IOException ioexception3) { }
            break MISSING_BLOCK_LABEL_150;
        }
        try
        {
            selector.close();
            channel.close();
        }
        catch(IOException ioexception) { }
        break MISSING_BLOCK_LABEL_150;
        Exception exception;
        exception;
        try
        {
            selector.close();
            channel.close();
        }
        catch(IOException ioexception4) { }
        throw exception;
    }

    private int readFromNetwork()
        throws IOException, InterruptedException
    {
        inBuffer.compact();
        do
        {
            for(; iterator == null || !iterator.hasNext(); iterator = selector.selectedKeys().iterator())
            {
                selector.select();
                if(needsToBeClosed)
                    throw new InterruptedException();
            }

            aKey = (SelectionKey)iterator.next();
        } while((aKey.readyOps() & 1) != 1);
        int i = channel.read(inBuffer);
        if(i < 0)
            throw new EOFException();
        if(i > 0)
            inBuffer.flip();
        iterator.remove();
        return i;
    }

    private void getNextNSPacket()
        throws IOException, InterruptedException
    {
        int i;
        while(!inBuffer.hasRemaining() || inBuffer.remaining() < 10) 
            i = readFromNetwork();
        currentNSPacketLength = inBuffer.getShort();
        if(currentNSPacketLength <= 0)
            throw new IOException("Invalid NS packet length.");
        inBuffer.position(inBuffer.position() + 2);
        currentNSPacketType = inBuffer.get();
        validatePacketType();
        inBuffer.position(inBuffer.position() + 5);
        while(inBuffer.remaining() < currentNSPacketLength - 10) 
            i = readFromNetwork();
        int j = inBuffer.limit();
        int k = (inBuffer.position() + currentNSPacketLength) - 10;
        inBuffer.limit(k);
        currentNSPacketDataBuffer = inBuffer.slice();
        inBuffer.limit(j);
        inBuffer.position(k);
    }

    private void unmarshalOneNSPacket()
        throws IOException, InterruptedException
    {
        getNextNSPacket();
        if(currentNSPacketDataBuffer.hasRemaining())
            switch(currentNSPacketType)
            {
            default:
                break;

            case 1: // '\001'
                byte abyte0[] = {
                    0, 24, 0, 0, 2, 0, 0, 0, 1, 52, 
                    0, 0, 8, 0, 127, -1, 1, 0, 0, 0, 
                    0, 24, 65, 1
                };
                outBuffer.clear();
                outBuffer.put(abyte0);
                outBuffer.limit(24);
                outBuffer.rewind();
                channel.write(outBuffer);
                break;

            case 6: // '\006'
                if(currentNSPacketDataBuffer.get(0) == -34 && currentNSPacketDataBuffer.get(1) == -83)
                {
                    byte abyte1[] = {
                        0, 127, 0, 0, 6, 0, 0, 0, 0, 0, 
                        -34, -83, -66, -17, 0, 117, 10, 32, 1, 0, 
                        0, 4, 0, 0, 4, 0, 3, 0, 0, 0, 
                        0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 
                        2, 0, 6, 0, 31, 0, 14, 0, 1, -34, 
                        -83, -66, -17, 0, 3, 0, 0, 0, 2, 0, 
                        4, 0, 1, 0, 1, 0, 2, 0, 0, 0, 
                        0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 
                        2, 0, 6, -5, -1, 0, 2, 0, 2, 0, 
                        0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 
                        0, 0, 1, 0, 2, 0, 0, 3, 0, 2, 
                        0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 
                        1, 0, 0, 1, 0, 2, 0
                    };
                    outBuffer.clear();
                    outBuffer.put(abyte1);
                    outBuffer.limit(abyte1.length);
                    outBuffer.rewind();
                    channel.write(outBuffer);
                } else
                {
                    unmarshalNSDataPacket();
                }
                break;
            }
    }

    private void unmarshalNSDataPacket()
        throws IOException, InterruptedException
    {
        short word0 = readShort();
        int i = readInt();
        byte byte0 = readByte();
        int j = readInt();
        short word1 = readShort();
        if(charset == null || charset.getOracleId() != word1)
            charset = CharacterSet.make(word1);
        byte byte1 = readByte();
        int k = readInt();
        short word2 = readShort();
        byte byte2 = readByte();
        int l = readInt();
        short word3 = readShort();
        int i1 = (i - 21) / 9;
        int ai[] = new int[i1];
        for(int j1 = 0; j1 < i1; j1++)
        {
            byte byte3 = readByte();
            int k1 = readInt();
            byte abyte0[] = new byte[k1];
            readBuffer(abyte0, 0, k1);
            for(int i2 = 0; i2 < k1; i2++)
                if(i2 < 4)
                    ai[j1] |= (abyte0[i2] & 0xff) << 8 * (k1 - i2 - 1);

        }

        NTFDCNEvent ntfdcnevent = null;
        NTFAQEvent ntfaqevent = null;
        int l1 = 0;
        short word4 = 0;
        NTFRegistration antfregistration[] = null;
        if(word0 >= 2)
        {
            short word5 = readShort();
            antfregistration = new NTFRegistration[ai.length];
            for(int j2 = 0; j2 < ai.length; j2++)
            {
                antfregistration[j2] = ntfManager.getRegistration(ai[j2]);
                if(antfregistration[j2] != null)
                {
                    l1 = antfregistration[j2].getNamespace();
                    word4 = antfregistration[j2].getDatabaseVersion();
                }
            }

            if(l1 == 2)
                ntfdcnevent = new NTFDCNEvent(this, word4);
            else
            if(l1 == 1)
                ntfaqevent = new NTFAQEvent(this, word4);
            else
            if(l1 != 0);
        }
        boolean flag = false;
        if(word0 >= 3)
        {
            short word7 = readShort();
            int i3 = readInt();
            byte byte4 = readByte();
            int j3 = readInt();
            short word6 = readShort();
            if(l1 == 2 && ntfdcnevent != null)
            {
                ntfdcnevent.setAdditionalEventType(oracle.jdbc.dcn.DatabaseChangeEvent.AdditionalEventType.getEventType(word6));
                if(word6 == 1)
                    ntfdcnevent.setEventType(oracle.jdbc.dcn.DatabaseChangeEvent.EventType.DEREG);
            } else
            if(l1 == 1 && ntfaqevent != null)
            {
                ntfaqevent.setAdditionalEventType(oracle.jdbc.aq.AQNotificationEvent.AdditionalEventType.getEventType(word6));
                if(word6 == 1)
                    ntfaqevent.setEventType(oracle.jdbc.aq.AQNotificationEvent.EventType.DEREG);
            }
        }
        if(word0 <= 3);
        if(antfregistration != null)
            if(l1 == 2)
            {
                for(int k2 = 0; k2 < antfregistration.length; k2++)
                    if(antfregistration[k2] != null && ntfdcnevent != null)
                        antfregistration[k2].notify(ntfdcnevent);

            } else
            if(l1 == 1)
            {
                for(int l2 = 0; l2 < antfregistration.length; l2++)
                    if(antfregistration[l2] != null && ntfaqevent != null)
                        antfregistration[l2].notify(ntfaqevent);

            }
    }

    void closeThisConnection()
    {
        needsToBeClosed = true;
    }

    byte readByte()
        throws IOException, InterruptedException
    {
        byte byte0 = 0;
        if(currentNSPacketDataBuffer.hasRemaining())
        {
            byte0 = currentNSPacketDataBuffer.get();
        } else
        {
            getNextNSPacket();
            byte0 = currentNSPacketDataBuffer.get();
        }
        return byte0;
    }

    short readShort()
        throws IOException, InterruptedException
    {
        short word0 = 0;
        if(currentNSPacketDataBuffer.remaining() >= 2)
        {
            word0 = currentNSPacketDataBuffer.getShort();
        } else
        {
            int i = readByte() & 0xff;
            int j = readByte() & 0xff;
            word0 = (short)(i << 8 | j);
        }
        return word0;
    }

    int readInt()
        throws IOException, InterruptedException
    {
        int i = 0;
        if(currentNSPacketDataBuffer.remaining() >= 4)
        {
            i = currentNSPacketDataBuffer.getInt();
        } else
        {
            int j = readByte() & 0xff;
            int k = readByte() & 0xff;
            int l = readByte() & 0xff;
            int i1 = readByte() & 0xff;
            i = j << 24 | k << 16 | l << 8 | i1;
        }
        return i;
    }

    long readLong()
        throws IOException, InterruptedException
    {
        long l = 0L;
        if(currentNSPacketDataBuffer.remaining() >= 8)
        {
            l = currentNSPacketDataBuffer.getLong();
        } else
        {
            long l1 = readByte() & 0xff;
            long l2 = readByte() & 0xff;
            long l3 = readByte() & 0xff;
            long l4 = readByte() & 0xff;
            long l5 = readByte() & 0xff;
            long l6 = readByte() & 0xff;
            long l7 = readByte() & 0xff;
            long l8 = readByte() & 0xff;
            l = l1 << 56 | l2 << 48 | l3 << 40 | l4 << 32 | l5 << 24 | l6 << 16 | l7 << 8 | l8;
        }
        return l;
    }

    void readBuffer(byte abyte0[], int i, int j)
        throws IOException, InterruptedException
    {
        if(currentNSPacketDataBuffer.remaining() >= j)
        {
            currentNSPacketDataBuffer.get(abyte0, i, j);
        } else
        {
            boolean flag = false;
            int k = 0;
            boolean flag1 = false;
            int i1 = currentNSPacketDataBuffer.remaining();
            currentNSPacketDataBuffer.get(abyte0, i, i1);
            i += i1;
            k += i1;
            do
            {
                if(flag)
                    break;
                getNextNSPacket();
                int j1 = currentNSPacketDataBuffer.remaining();
                int l = Math.min(j1, j - k);
                currentNSPacketDataBuffer.get(abyte0, i, l);
                i += l;
                k += l;
                if(k == j)
                    flag = true;
            } while(true);
        }
    }

    private String packetToString(ByteBuffer bytebuffer)
        throws IOException
    {
        int i = 0;
        char ac[] = new char[8];
        StringBuffer stringbuffer = new StringBuffer();
        int j = bytebuffer.position();
        do
        {
            if(!bytebuffer.hasRemaining())
                break;
            byte byte0 = bytebuffer.get();
            String s = Integer.toHexString(byte0 & 0xff);
            s = s.toUpperCase();
            if(s.length() == 1)
                s = (new StringBuilder()).append("0").append(s).toString();
            stringbuffer.append(s);
            stringbuffer.append(' ');
            if(byte0 > 32 && byte0 < 127)
                ac[i] = (char)byte0;
            else
                ac[i] = '.';
            if(++i == 8)
            {
                stringbuffer.append('|');
                stringbuffer.append(ac);
                stringbuffer.append('|');
                stringbuffer.append('\n');
                i = 0;
            }
        } while(true);
        if(i != 0)
        {
            int k = 8 - i;
            for(int l = 0; l < k * 3; l++)
                stringbuffer.append(' ');

            stringbuffer.append('|');
            stringbuffer.append(ac, 0, i);
            for(int i1 = 0; i1 < k; i1++)
                stringbuffer.append(' ');

            stringbuffer.append('|');
            stringbuffer.append('\n');
        }
        stringbuffer.append("\nEnd of Packet\n\n");
        bytebuffer.position(j);
        return stringbuffer.toString();
    }

    private void validatePacketType()
        throws IOException
    {
        if(currentNSPacketType < 1 || currentNSPacketType > 19)
            throw new IOException("Invalid NS packet type.");
        else
            return;
    }

}
