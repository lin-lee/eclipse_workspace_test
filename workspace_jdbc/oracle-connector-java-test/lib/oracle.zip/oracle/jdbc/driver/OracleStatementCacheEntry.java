// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleStatementCacheEntry.java

package oracle.jdbc.driver;

import java.io.PrintStream;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            OraclePreparedStatement

class OracleStatementCacheEntry
{

    protected OracleStatementCacheEntry applicationNext;
    protected OracleStatementCacheEntry applicationPrev;
    protected OracleStatementCacheEntry explicitNext;
    protected OracleStatementCacheEntry explicitPrev;
    protected OracleStatementCacheEntry implicitNext;
    protected OracleStatementCacheEntry implicitPrev;
    boolean onImplicit;
    String sql;
    int statementType;
    int scrollType;
    OraclePreparedStatement statement;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleStatementCacheEntry()
    {
        applicationNext = null;
        applicationPrev = null;
        explicitNext = null;
        explicitPrev = null;
        implicitNext = null;
        implicitPrev = null;
    }

    public void print()
        throws SQLException
    {
        System.out.println((new StringBuilder()).append("Cache entry ").append(this).toString());
        System.out.println((new StringBuilder()).append("  Key: ").append(sql).append("$$").append(statementType).append("$$").append(scrollType).toString());
        System.out.println((new StringBuilder()).append("  Statement: ").append(statement).toString());
        System.out.println((new StringBuilder()).append("  onImplicit: ").append(onImplicit).toString());
        System.out.println((new StringBuilder()).append("  applicationNext: ").append(applicationNext).append("  applicationPrev: ").append(applicationPrev).toString());
        System.out.println((new StringBuilder()).append("  implicitNext: ").append(implicitNext).append("  implicitPrev: ").append(implicitPrev).toString());
        System.out.println((new StringBuilder()).append("  explicitNext: ").append(explicitNext).append("  explicitPrev: ").append(explicitPrev).toString());
    }

}
