// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTypeRep.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            DatabaseError

class T4CTypeRep
{

    static final byte REPUNV = 1;
    static final byte REPBUNV = 1;
    static final byte REPCUNV = 1;
    static final byte REPCASC = 10;
    static final byte REPCEBC = 11;
    static final byte REPIUNV = 1;
    static final byte REPIT11 = 10;
    static final byte REPIT12_OLD = 11;
    static final byte REPIT14_OLD = 12;
    static final byte REPIU11 = 13;
    static final byte REPIU12_OLD = 14;
    static final byte REPIU14_OLD = 15;
    static final byte REPIT21_OLD = 16;
    static final byte REPIT41_OLD = 17;
    static final byte REPIU21_OLD = 18;
    static final byte REPIU41_OLD = 19;
    static final byte REPIT32_OLD = 20;
    static final byte REPIU32_OLD = 21;
    static final byte REPIT12 = 22;
    static final byte REPIT14 = 23;
    static final byte REPIU12 = 24;
    static final byte REPIU14 = 25;
    static final byte REPIT21 = 26;
    static final byte REPIT41 = 27;
    static final byte REPIU21 = 28;
    static final byte REPIU41 = 29;
    static final byte REPIT32 = 30;
    static final byte REPIU32 = 31;
    static final byte REPIT18 = 32;
    static final byte REPIU18 = 33;
    static final byte REPIT81 = 34;
    static final byte REPIU81 = 35;
    static final byte REPAUNV = 1;
    static final byte REPA4Z = 10;
    static final byte REPA2Z = 11;
    static final byte REPA8Z = 12;
    static final byte REPA16Z = 13;
    static final byte REPNV51 = 10;
    static final byte REPDV51 = 10;
    static final byte REPRUNV = 1;
    static final byte NATIVE = 0;
    static final byte UNIVERSAL = 1;
    static final byte LSB = 2;
    static final byte MAXREP = 3;
    static final byte B1 = 0;
    static final byte B2 = 1;
    static final byte B4 = 2;
    static final byte B8 = 3;
    static final byte PTR = 4;
    static final byte MAXTYPE = 4;
    byte rep[];
    final byte NUMREPS = 5;
    byte conversionFlags;
    boolean serverConversion;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTypeRep()
    {
        conversionFlags = 0;
        serverConversion = false;
        rep = new byte[5];
        rep[0] = 0;
        rep[1] = 1;
        rep[2] = 1;
        rep[3] = 1;
        rep[4] = 1;
    }

    void setRep(byte byte0, byte byte1)
        throws SQLException
    {
        if(byte0 < 0 || byte0 > 4 || byte1 > 3)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 407);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            rep[byte0] = byte1;
            return;
        }
    }

    byte getRep(byte byte0)
        throws SQLException
    {
        if(byte0 < 0 || byte0 > 4)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 408);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return rep[byte0];
        }
    }

    void setFlags(byte byte0)
    {
        conversionFlags = byte0;
    }

    byte getFlags()
    {
        return conversionFlags;
    }

    boolean isConvNeeded()
    {
        boolean flag = (conversionFlags & 2) > 0;
        return flag;
    }

    void setServerConversion(boolean flag)
    {
        serverConversion = flag;
    }

    boolean isServerConversion()
    {
        return serverConversion;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
