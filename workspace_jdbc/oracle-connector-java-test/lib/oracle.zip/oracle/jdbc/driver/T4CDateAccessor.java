// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CDateAccessor.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormatSymbols;
import java.util.Properties;
import java.util.TimeZone;
import oracle.jdbc.internal.OracleStatement;

// Referenced classes of package oracle.jdbc.driver:
//            DateAccessor, OracleStatement, T4CMAREngine, PhysicalConnection, 
//            DatabaseError

class T4CDateAccessor extends DateAccessor
{

    T4CMAREngine mare;
    boolean underlyingLongRaw;
    final int meta[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CDateAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, short word0, int j, boolean flag, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, word0, j, flag);
        underlyingLongRaw = false;
        meta = new int[1];
        mare = t4cmarengine;
    }

    T4CDateAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, int k1, int l1, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i != -1 ? i : l1, flag, j, k, l, i1, j1, word0);
        underlyingLongRaw = false;
        meta = new int[1];
        mare = t4cmarengine;
        if(oraclestatement != null && oraclestatement.implicitDefineForLobPrefetchDone)
        {
            definedColumnType = 0;
            definedColumnSize = 0;
        } else
        {
            definedColumnType = k1;
            definedColumnSize = l1;
        }
        if(i == -1)
            underlyingLongRaw = true;
    }

    void processIndicator(int i)
        throws IOException, SQLException
    {
        if(internalType == 1 && describeType == 112 || internalType == 23 && describeType == 113)
        {
            mare.unmarshalUB2();
            mare.unmarshalUB2();
        } else
        if(statement.connection.versionNumber < 9200)
        {
            mare.unmarshalSB2();
            if(!statement.sqlKind.isPlsqlOrCall())
                mare.unmarshalSB2();
        } else
        if(statement.sqlKind.isPlsqlOrCall() || isDMLReturnedParam)
            mare.processIndicator(i <= 0, i);
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        if(isUseLess)
        {
            lastRowProcessed++;
            return false;
        }
        if(rowSpaceIndicator == null)
        {
            byte abyte0[] = new byte[16000];
            mare.unmarshalCLR(abyte0, 0, meta);
            processIndicator(meta[0]);
            lastRowProcessed++;
            return false;
        }
        int i = indicatorIndex + lastRowProcessed;
        int j = lengthIndex + lastRowProcessed;
        if(isNullByDescribe)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
            lastRowProcessed++;
            if(statement.connection.versionNumber < 9200)
                processIndicator(0);
            return false;
        }
        int k = columnIndex + lastRowProcessed * byteLength;
        mare.unmarshalCLR(rowSpaceByte, k, meta, byteLength);
        processIndicator(meta[0]);
        if(meta[0] == 0)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
        } else
        {
            rowSpaceIndicator[j] = (short)meta[0];
            rowSpaceIndicator[i] = 0;
        }
        lastRowProcessed++;
        return false;
    }

    void copyRow()
        throws SQLException, IOException
    {
        int i;
        if(lastRowProcessed == 0)
            i = statement.rowPrefetchInLastFetch - 1;
        else
            i = lastRowProcessed - 1;
        int j = columnIndex + lastRowProcessed * byteLength;
        int k = columnIndex + i * byteLength;
        int l = indicatorIndex + lastRowProcessed;
        int i1 = indicatorIndex + i;
        int j1 = lengthIndex + lastRowProcessed;
        int k1 = lengthIndex + i;
        int l1 = rowSpaceIndicator[k1];
        int i2 = metaDataIndex + lastRowProcessed * 1;
        int j2 = metaDataIndex + i * 1;
        rowSpaceIndicator[j1] = (short)l1;
        rowSpaceIndicator[l] = rowSpaceIndicator[i1];
        if(!isNullByDescribe)
            System.arraycopy(rowSpaceByte, k, rowSpaceByte, j, l1);
        System.arraycopy(rowSpaceMetaData, j2, rowSpaceMetaData, i2, 1);
        lastRowProcessed++;
    }

    void saveDataFromOldDefineBuffers(byte abyte0[], char ac[], short aword0[], int i, int j)
        throws SQLException
    {
        int k = columnIndex + (j - 1) * byteLength;
        int l = columnIndexLastRow + (i - 1) * byteLength;
        int i1 = (indicatorIndex + j) - 1;
        int j1 = (indicatorIndexLastRow + i) - 1;
        int k1 = (lengthIndex + j) - 1;
        int l1 = (lengthIndexLastRow + i) - 1;
        int i2 = aword0[l1];
        rowSpaceIndicator[k1] = (short)i2;
        rowSpaceIndicator[i1] = aword0[j1];
        if(i2 != 0)
            System.arraycopy(abyte0, l, rowSpaceByte, k, i2);
    }

    String toText(int i, int j, int k, int l, int i1, int j1, int k1, 
            boolean flag, String s)
        throws SQLException
    {
        if(definedColumnType == 0 || definedColumnType == 91)
        {
            return super.toText(i, j, k, l, i1, j1, k1, flag, s);
        } else
        {
            String s1 = (String)statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM");
            return nlsFormatToText(i, j, k, l, i1, j1, k1, flag, s, s1);
        }
    }

    private static final String nlsFormatToText(int i, int j, int k, int l, int i1, int j1, int k1, boolean flag, 
            String s, String s1)
        throws SQLException
    {
        char ac[] = (new StringBuilder()).append(s1).append("      ").toString().toCharArray();
        int l1 = s1.length();
        StringBuffer stringbuffer = new StringBuffer(l1 + 25);
        String as[] = null;
        String as1[] = null;
        TimeZone timezone = null;
        for(int i2 = 0; i2 < l1; i2++)
            switch(ac[i2])
            {
            case 82: // 'R'
            case 114: // 'r'
                if(ac[i2 + 1] != 'R' && ac[i2 + 1] != 'r')
                    continue;
                if((ac[i2 + 2] == 'R' || ac[i2 + 2] == 'r') && (ac[i2 + 3] == 'R' || ac[i2 + 3] == 'r'))
                {
                    if(i < 1000)
                        stringbuffer.append((new StringBuilder()).append("0").append(i).toString());
                    else
                    if(i < 100)
                        stringbuffer.append((new StringBuilder()).append("00").append(i).toString());
                    else
                    if(i < 10)
                        stringbuffer.append((new StringBuilder()).append("000").append(i).toString());
                    else
                        stringbuffer.append(i);
                    i2 += 3;
                    continue;
                }
                if(i >= 100)
                    i %= 100;
                if(i < 10)
                    stringbuffer.append((new StringBuilder()).append("0").append(i).toString());
                else
                    stringbuffer.append(i);
                i2++;
                break;

            case 89: // 'Y'
            case 121: // 'y'
                if(ac[i2 + 1] != 'Y' && ac[i2 + 1] != 'y')
                    break;
                if((ac[i2 + 2] == 'Y' || ac[i2 + 2] == 'y') && (ac[i2 + 3] == 'Y' || ac[i2 + 3] == 'y'))
                {
                    if(i < 1000)
                        stringbuffer.append((new StringBuilder()).append("0").append(i).toString());
                    else
                    if(i < 100)
                        stringbuffer.append((new StringBuilder()).append("00").append(i).toString());
                    else
                    if(i < 10)
                        stringbuffer.append((new StringBuilder()).append("000").append(i).toString());
                    else
                        stringbuffer.append(i);
                    i2 += 3;
                    break;
                }
                if(i >= 100)
                    i %= 100;
                if(i < 10)
                    stringbuffer.append((new StringBuilder()).append("0").append(i).toString());
                else
                    stringbuffer.append(i);
                i2++;
                break;

            case 68: // 'D'
            case 100: // 'd'
                if(ac[i2 + 1] == 'D' || ac[i2 + 1] == 'd')
                {
                    stringbuffer.append((new StringBuilder()).append(k >= 10 ? "" : "0").append(k).toString());
                    i2++;
                }
                break;

            case 77: // 'M'
            case 109: // 'm'
                if(ac[i2 + 1] == 'M' || ac[i2 + 1] == 'm')
                {
                    stringbuffer.append((new StringBuilder()).append(j >= 10 ? "" : "0").append(j).toString());
                    i2++;
                    break;
                }
                if(ac[i2 + 1] == 'I' || ac[i2 + 1] == 'i')
                {
                    stringbuffer.append((new StringBuilder()).append(i1 >= 10 ? "" : "0").append(i1).toString());
                    i2++;
                    break;
                }
                if(ac[i2 + 1] != 'O' && ac[i2 + 1] != 'o' || ac[i2 + 2] != 'N' && ac[i2 + 2] != 'n')
                    break;
                if((ac[i2 + 3] == 'T' || ac[i2 + 3] == 't') && (ac[i2 + 4] == 'H' || ac[i2 + 4] == 'h'))
                {
                    if(as1 == null)
                        as1 = (new DateFormatSymbols()).getMonths();
                    if(ac[i2] == 'm')
                        stringbuffer.append(as1[j - 1].toLowerCase());
                    else
                    if(ac[i2 + 1] == 'O')
                        stringbuffer.append(as1[j - 1].toUpperCase());
                    else
                        stringbuffer.append(as1[j - 1]);
                    i2 += 4;
                    break;
                }
                if(as == null)
                    as = (new DateFormatSymbols()).getShortMonths();
                if(ac[i2] == 'm')
                    stringbuffer.append(as[j - 1].toLowerCase());
                else
                if(ac[i2 + 1] == 'O')
                    stringbuffer.append(as[j - 1].toUpperCase());
                else
                    stringbuffer.append(as[j - 1]);
                i2 += 2;
                break;

            case 72: // 'H'
            case 104: // 'h'
                if(ac[i2 + 1] != 'H' && ac[i2 + 1] != 'h')
                    break;
                if(ac[i2 + 2] == '2' || ac[i2 + 3] == '4')
                {
                    stringbuffer.append((new StringBuilder()).append(l >= 10 ? "" : "0").append(l).toString());
                    i2 += 3;
                    break;
                }
                if(l > 12)
                    l -= 12;
                stringbuffer.append((new StringBuilder()).append(l >= 10 ? "" : "0").append(l).toString());
                i2++;
                break;

            case 83: // 'S'
            case 115: // 's'
                if(ac[i2 + 1] != 'S' && ac[i2 + 1] != 's')
                    break;
                stringbuffer.append((new StringBuilder()).append(j1 >= 10 ? "" : "0").append(j1).toString());
                i2++;
                if((ac[i2 + 1] == 'X' || ac[i2 + 1] == 'x') && (ac[i2 + 2] == 'F' || ac[i2 + 2] == 'f') && (ac[i2 + 3] == 'F' || ac[i2 + 3] == 'f'))
                {
                    stringbuffer.append(".");
                    i2++;
                }
                break;

            case 70: // 'F'
            case 102: // 'f'
                if(ac[i2 + 1] != 'F' && ac[i2 + 1] != 'f')
                    break;
                if(k1 >= 0)
                    stringbuffer.append(k1);
                else
                    stringbuffer.append(0);
                i2++;
                break;

            case 84: // 'T'
            case 116: // 't'
                if(ac[i2 + 1] != 'Z' && ac[i2 + 1] != 'z')
                    break;
                if(ac[i2 + 2] == 'R' || ac[i2 + 2] == 'r')
                {
                    if(s.length() > 3 && s.startsWith("GMT"))
                        stringbuffer.append(s.substring(3));
                    else
                        stringbuffer.append(s.toUpperCase());
                    i2 += 2;
                    break;
                }
                if(ac[i2 + 2] == 'H' || ac[i2 + 2] == 'h')
                {
                    if(timezone == null)
                        timezone = TimeZone.getTimeZone(s);
                    long l2 = timezone.getRawOffset() / 0x36ee80;
                    stringbuffer.append(l2);
                    i2 += 2;
                    break;
                }
                if(ac[i2 + 2] != 'M' && ac[i2 + 2] != 'm')
                    break;
                if(timezone == null)
                    timezone = TimeZone.getTimeZone(s);
                long l3 = (Math.abs(timezone.getRawOffset()) % 0x36ee80) / 60000;
                stringbuffer.append((new StringBuilder()).append(l3 >= 10L ? "" : "0").append(l3).toString());
                i2 += 2;
                break;

            case 65: // 'A'
            case 80: // 'P'
            case 97: // 'a'
            case 112: // 'p'
                if(ac[i2 + 1] == 'M' || ac[i2 + 1] == 'm')
                {
                    stringbuffer.append(flag ? "AM" : "PM");
                    i2++;
                }
                break;

            case 66: // 'B'
            case 67: // 'C'
            case 69: // 'E'
            case 71: // 'G'
            case 73: // 'I'
            case 74: // 'J'
            case 75: // 'K'
            case 76: // 'L'
            case 78: // 'N'
            case 79: // 'O'
            case 81: // 'Q'
            case 85: // 'U'
            case 86: // 'V'
            case 87: // 'W'
            case 88: // 'X'
            case 90: // 'Z'
            case 91: // '['
            case 92: // '\\'
            case 93: // ']'
            case 94: // '^'
            case 95: // '_'
            case 96: // '`'
            case 98: // 'b'
            case 99: // 'c'
            case 101: // 'e'
            case 103: // 'g'
            case 105: // 'i'
            case 106: // 'j'
            case 107: // 'k'
            case 108: // 'l'
            case 110: // 'n'
            case 111: // 'o'
            case 113: // 'q'
            case 117: // 'u'
            case 118: // 'v'
            case 119: // 'w'
            case 120: // 'x'
            default:
                stringbuffer.append(ac[i2]);
                break;
            }

        return stringbuffer.substring(0, stringbuffer.length());
    }

    String getString(int i)
        throws SQLException
    {
        String s = null;
        if(definedColumnType == 0)
        {
            s = super.getString(i);
        } else
        {
            if(rowSpaceIndicator == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(rowSpaceIndicator[indicatorIndex + i] != -1)
            {
                int j = columnIndex + byteLength * i;
                int k = oracleYear(j);
                int l = 0;
                s = toText(k, rowSpaceByte[2 + j], rowSpaceByte[3 + j], l = rowSpaceByte[4 + j] - 1, rowSpaceByte[5 + j] - 1, rowSpaceByte[6 + j] - 1, -1, l < 12, null);
            }
        }
        if(s != null && definedColumnSize > 0 && s.length() > definedColumnSize)
            s = s.substring(0, definedColumnSize);
        return s;
    }

    Object getObject(int i)
        throws SQLException
    {
        if(definedColumnType == 0)
            return super.getObject(i);
        Object obj = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            switch(definedColumnType)
            {
            case -15: 
            case -9: 
            case -1: 
            case 1: // '\001'
            case 12: // '\f'
                return getString(i);

            case 91: // '['
                return getDate(i);

            case 92: // '\\'
                return getTime(i);

            case 93: // ']'
                return getTimestamp(i);

            case -4: 
            case -3: 
            case -2: 
                return getBytes(i);
            }
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return obj;
        }
    }

}
