// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   SQLStateMapping.java

package oracle.jdbc.driver;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

class SQLStateMapping
{
    private static final class Tokenizer
    {

        int lineno;
        Reader r;
        int c;

        String next()
            throws IOException
        {
            StringBuffer stringbuffer;
label0:
            {
                stringbuffer = new StringBuffer(16);
                boolean flag = true;
                do
                {
                    if(c == -1)
                        break label0;
                    if(c == 10)
                        lineno++;
                    if(c > 32 || !flag)
                        break;
                    c = r.read();
                } while(true);
                if(c <= 32 && !flag)
                    c = r.read();
                else
                if(c == 34)
                {
                    while((c = r.read()) != 34) 
                        stringbuffer.append((char)c);
                    c = r.read();
                } else
                if(48 <= c && c <= 57 || 65 <= c && c <= 90 || 97 <= c && c <= 122 || c == 95)
                {
                    do
                        stringbuffer.append((char)c);
                    while(48 <= (c = r.read()) && c <= 57 || 65 <= c && c <= 90 || 97 <= c && c <= 122 || c == 95);
                } else
                {
                    stringbuffer.append((char)c);
                    c = r.read();
                }
            }
            if(stringbuffer.length() > 0)
                return stringbuffer.toString();
            else
                return null;
        }

        Tokenizer(Reader reader)
            throws IOException
        {
            lineno = 1;
            r = reader;
            c = reader.read();
        }
    }


    public static final int SQLEXCEPTION = 0;
    public static final int SQLNONTRANSIENTEXCEPTION = 1;
    public static final int SQLTRANSIENTEXCEPTION = 2;
    public static final int SQLDATAEXCEPTION = 3;
    public static final int SQLFEATURENOTSUPPORTEDEXCEPTION = 4;
    public static final int SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION = 5;
    public static final int SQLINVALIDAUTHORIZATIONSPECEXCEPTION = 6;
    public static final int SQLNONTRANSIENTCONNECTIONEXCEPTION = 7;
    public static final int SQLSYNTAXERROREXCEPTION = 8;
    public static final int SQLTIMEOUTEXCEPTION = 9;
    public static final int SQLTRANSACTIONROLLBACKEXCEPTION = 10;
    public static final int SQLTRANSIENTCONNECTIONEXCEPTION = 11;
    public static final int SQLCLIENTINFOEXCEPTION = 12;
    public static final int SQLRECOVERABLEEXCEPTION = 13;
    int low;
    int high;
    public String sqlState;
    public int exception;
    static final String mappingResource = "errorMap.xml";
    static SQLStateMapping all[];
    private static final int NUMEBER_OF_MAPPINGS_IN_ERRORMAP_XML = 128;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public SQLStateMapping(int i, int j, String s, int k)
    {
        low = i;
        sqlState = s;
        exception = k;
        high = j;
    }

    public boolean isIncluded(int i)
    {
        return low <= i && i <= high;
    }

    public SQLException newSQLException(String s, int i)
    {
        switch(exception)
        {
        case 0: // '\0'
            return new SQLException(s, sqlState, i);

        case 1: // '\001'
            return new SQLNonTransientException(s, sqlState, i);

        case 2: // '\002'
            return new SQLTransientException(s, sqlState, i);

        case 3: // '\003'
            return new SQLDataException(s, sqlState, i);

        case 4: // '\004'
            return new SQLFeatureNotSupportedException(s, sqlState, i);

        case 5: // '\005'
            return new SQLIntegrityConstraintViolationException(s, sqlState, i);

        case 6: // '\006'
            return new SQLInvalidAuthorizationSpecException(s, sqlState, i);

        case 7: // '\007'
            return new SQLNonTransientConnectionException(s, sqlState, i);

        case 8: // '\b'
            return new SQLSyntaxErrorException(s, sqlState, i);

        case 9: // '\t'
            return new SQLTimeoutException(s, sqlState, i);

        case 10: // '\n'
            return new SQLTransactionRollbackException(s, sqlState, i);

        case 11: // '\013'
            return new SQLTransientConnectionException(s, sqlState, i);

        case 12: // '\f'
            return new SQLClientInfoException(s, sqlState, i, null);

        case 13: // '\r'
            return new SQLRecoverableException(s, sqlState, i);
        }
        return new SQLException(s, sqlState, i);
    }

    boolean lessThan(SQLStateMapping sqlstatemapping)
    {
        if(low < sqlstatemapping.low)
            return high < sqlstatemapping.high;
        else
            return high <= sqlstatemapping.high;
    }

    public String toString()
    {
        return (new StringBuilder()).append(super.toString()).append("(").append(low).append(", ").append(high).append(", ").append(sqlState).append(", ").append(exception).append(")").toString();
    }

    public static void main(String args[])
        throws IOException
    {
        SQLStateMapping asqlstatemapping[] = doGetMappings();
        System.out.println((new StringBuilder()).append("a\t").append(asqlstatemapping).toString());
        for(int i = 0; i < asqlstatemapping.length; i++)
            System.out.println((new StringBuilder()).append("low:\t").append(asqlstatemapping[i].low).append("\thigh:\t").append(asqlstatemapping[i].high).append("\tsqlState:\t").append(asqlstatemapping[i].sqlState).append("\tsqlException:\t").append(asqlstatemapping[i].exception).toString());

    }

    static SQLStateMapping[] getMappings()
    {
        if(all == null)
            try
            {
                all = doGetMappings();
            }
            catch(Throwable throwable)
            {
                all = new SQLStateMapping[0];
            }
        return all;
    }

    static SQLStateMapping[] doGetMappings()
        throws IOException
    {
        InputStream inputstream = oracle/jdbc/driver/SQLStateMapping.getResourceAsStream("errorMap.xml");
        ArrayList arraylist = new ArrayList(128);
        load(inputstream, arraylist);
        return (SQLStateMapping[])(SQLStateMapping[])arraylist.toArray(new SQLStateMapping[0]);
    }

    static void load(InputStream inputstream, List list)
        throws IOException
    {
        BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputstream));
        Tokenizer tokenizer = new Tokenizer(bufferedreader);
        int i = -1;
        int j = -1;
        String s = null;
        int k = -1;
        String s1 = null;
        int l = 0;
        do
        {
            String s2;
            if((s2 = tokenizer.next()) == null)
                break;
            switch(l)
            {
            case 0: // '\0'
                if(s2.equals("<"))
                    l = 1;
                break;

            case 1: // '\001'
                if(s2.equals("!"))
                    l = 2;
                else
                if(s2.equals("oraErrorSqlStateSqlExceptionMapping"))
                    l = 6;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".").toString());
                break;

            case 2: // '\002'
                if(s2.equals("-"))
                    l = 3;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \"-\".").toString());
                break;

            case 3: // '\003'
                if(s2.equals("-"))
                    l = 4;
                break;

            case 4: // '\004'
                if(s2.equals("-"))
                    l = 5;
                else
                    l = 3;
                break;

            case 5: // '\005'
                if(s2.equals(">"))
                    l = 1;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \">\".").toString());
                break;

            case 6: // '\006'
                if(s2.equals(">"))
                    l = 7;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \">\".").toString());
                break;

            case 7: // '\007'
                if(s2.equals("<"))
                    l = 8;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \"<\".").toString());
                break;

            case 8: // '\b'
                if(s2.equals("!"))
                    l = 9;
                else
                if(s2.equals("error"))
                    l = 14;
                else
                if(s2.equals("/"))
                    l = 16;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected one of \"!--\", \"error\", \"/\".").toString());
                break;

            case 9: // '\t'
                if(s2.equals("-"))
                    l = 10;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \"-\".").toString());
                break;

            case 10: // '\n'
                if(s2.equals("-"))
                    l = 11;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \"-\".").toString());
                break;

            case 11: // '\013'
                if(s2.equals("-"))
                    l = 12;
                break;

            case 12: // '\f'
                if(s2.equals("-"))
                    l = 13;
                else
                    l = 11;
                break;

            case 13: // '\r'
                if(s2.equals(">"))
                    l = 7;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \">\".").toString());
                break;

            case 14: // '\016'
                if(s2.equals("/"))
                    l = 15;
                else
                if(s2.equals("oraErrorFrom"))
                    l = 19;
                else
                if(s2.equals("oraErrorTo"))
                    l = 21;
                else
                if(s2.equals("sqlState"))
                    l = 23;
                else
                if(s2.equals("sqlException"))
                    l = 25;
                else
                if(s2.equals("comment"))
                    l = 27;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected one of ").append("\"oraErrorFrom\", \"oraErrorTo\", \"sqlState\", ").append("\"sqlException\", \"comment\", \"/\".").toString());
                break;

            case 15: // '\017'
                if(s2.equals(">"))
                {
                    try
                    {
                        createOne(list, i, j, s, k, s1);
                    }
                    catch(IOException ioexception)
                    {
                        throw new IOException((new StringBuilder()).append("Invalid error element at line ").append(tokenizer.lineno).append(" of errorMap.xml. ").append(ioexception.getMessage()).toString());
                    }
                    i = -1;
                    j = -1;
                    s = null;
                    k = -1;
                    s1 = null;
                    l = 7;
                } else
                {
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \">\".").toString());
                }
                break;

            case 16: // '\020'
                if(s2.equals("oraErrorSqlStateSqlExceptionMapping"))
                    l = 17;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".").toString());
                break;

            case 17: // '\021'
                if(s2.equals(">"))
                    l = 18;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \">\".").toString());
                break;

            case 19: // '\023'
                if(s2.equals("="))
                    l = 20;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \"=\".").toString());
                break;

            case 20: // '\024'
                try
                {
                    i = Integer.parseInt(s2);
                }
                catch(NumberFormatException numberformatexception)
                {
                    throw new IOException((new StringBuilder()).append("Unexpected value \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected an integer.").toString());
                }
                l = 14;
                break;

            case 21: // '\025'
                if(s2.equals("="))
                    l = 22;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \"=\".").toString());
                break;

            case 22: // '\026'
                try
                {
                    j = Integer.parseInt(s2);
                }
                catch(NumberFormatException numberformatexception1)
                {
                    throw new IOException((new StringBuilder()).append("Unexpected value \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected an integer.").toString());
                }
                l = 14;
                break;

            case 23: // '\027'
                if(s2.equals("="))
                    l = 24;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \"=\".").toString());
                break;

            case 24: // '\030'
                s = s2;
                l = 14;
                break;

            case 25: // '\031'
                if(s2.equals("="))
                    l = 26;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \"=\".").toString());
                break;

            case 26: // '\032'
                try
                {
                    k = valueOf(s2);
                }
                catch(Exception exception1)
                {
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected SQLException").append(" subclass name.").toString());
                }
                l = 14;
                break;

            case 27: // '\033'
                if(s2.equals("="))
                    l = 28;
                else
                    throw new IOException((new StringBuilder()).append("Unexpected token \"").append(s2).append("\" at line ").append(tokenizer.lineno).append(" of errorMap.xml. Expected \"=\".").toString());
                break;

            case 28: // '\034'
                s1 = s2;
                l = 14;
                break;

            default:
                throw new IOException((new StringBuilder()).append("Unknown parser state ").append(l).append(" at line ").append(tokenizer.lineno).append(" of errorMap.xml.").toString());

            case 18: // '\022'
                break;
            }
        } while(true);
    }

    private static void createOne(List list, int i, int j, String s, int k, String s1)
        throws IOException
    {
        if(i == -1)
            throw new IOException("oraErrorFrom is a required attribute");
        if(j == -1)
            j = i;
        if(s == null || s.length() == 0)
            throw new IOException("sqlState is a required attribute");
        if(k == -1)
            throw new IOException("sqlException is a required attribute");
        if(s1 == null || s1.length() < 8)
        {
            throw new IOException("a lengthy comment in required");
        } else
        {
            SQLStateMapping sqlstatemapping = new SQLStateMapping(i, j, s, k);
            add(list, sqlstatemapping);
            return;
        }
    }

    static void add(List list, SQLStateMapping sqlstatemapping)
    {
        int i;
        for(i = list.size(); i > 0 && !((SQLStateMapping)list.get(i - 1)).lessThan(sqlstatemapping); i--);
        list.add(i, sqlstatemapping);
    }

    static int valueOf(String s)
        throws Exception
    {
        if(s.equalsIgnoreCase("SQLEXCEPTION"))
            return 0;
        if(s.equalsIgnoreCase("SQLNONTRANSIENTEXCEPTION"))
            return 1;
        if(s.equalsIgnoreCase("SQLTRANSIENTEXCEPTION"))
            return 2;
        if(s.equalsIgnoreCase("SQLDATAEXCEPTION"))
            return 3;
        if(s.equalsIgnoreCase("SQLFEATURENOTSUPPORTEDEXCEPTION"))
            return 4;
        if(s.equalsIgnoreCase("SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION"))
            return 5;
        if(s.equalsIgnoreCase("SQLINVALIDAUTHORIZATIONSPECEXCEPTION"))
            return 6;
        if(s.equalsIgnoreCase("SQLNONTRANSIENTCONNECTIONEXCEPTION"))
            return 7;
        if(s.equalsIgnoreCase("SQLSYNTAXERROREXCEPTION"))
            return 8;
        if(s.equalsIgnoreCase("SQLTIMEOUTEXCEPTION"))
            return 9;
        if(s.equalsIgnoreCase("SQLTRANSACTIONROLLBACKEXCEPTION"))
            return 10;
        if(s.equalsIgnoreCase("SQLTRANSIENTCONNECTIONEXCEPTION"))
            return 11;
        if(s.equalsIgnoreCase("SQLCLIENTINFOEXCEPTION"))
            return 12;
        if(s.equalsIgnoreCase("SQLRECOVERABLEEXCEPTION"))
            return 13;
        else
            throw new Exception((new StringBuilder()).append("unexpected exception name: ").append(s).toString());
    }

}
