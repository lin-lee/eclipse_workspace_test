// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   KeywordValueI.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValue;

// Referenced classes of package oracle.jdbc.driver:
//            T4CMAREngine, DBConversion

class KeywordValueI extends KeywordValue
{

    private int keyword;
    private byte binaryValue[];
    private String textValue;
    private byte textValueArr[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    KeywordValueI(int i, String s, byte abyte0[])
    {
        keyword = i;
        textValue = s;
        binaryValue = abyte0;
        textValueArr = null;
    }

    void doCharConversion(DBConversion dbconversion)
        throws SQLException
    {
        if(textValue != null)
            textValueArr = dbconversion.StringToCharBytes(textValue);
        else
            textValueArr = null;
    }

    public byte[] getBinaryValue()
        throws SQLException
    {
        return binaryValue;
    }

    public String getTextValue()
        throws SQLException
    {
        return textValue;
    }

    public int getKeyword()
        throws SQLException
    {
        return keyword;
    }

    void marshal(T4CMAREngine t4cmarengine)
        throws IOException
    {
        if(textValueArr != null)
        {
            t4cmarengine.marshalUB2(textValueArr.length);
            t4cmarengine.marshalCLR(textValueArr, textValueArr.length);
            t4cmarengine.marshalUB2(0);
        } else
        {
            t4cmarengine.marshalUB2(0);
            if(binaryValue != null)
            {
                t4cmarengine.marshalUB2(binaryValue.length);
                t4cmarengine.marshalCLR(binaryValue, binaryValue.length);
            } else
            {
                t4cmarengine.marshalUB2(0);
            }
        }
        t4cmarengine.marshalUB2(keyword);
    }

    static KeywordValueI unmarshal(T4CMAREngine t4cmarengine)
        throws SQLException, IOException
    {
        int ai[] = new int[1];
        String s = null;
        byte abyte0[] = null;
        int i = t4cmarengine.unmarshalUB2();
        if(i != 0)
        {
            byte abyte1[] = new byte[i];
            t4cmarengine.unmarshalCLR(abyte1, 0, ai);
            s = t4cmarengine.conv.CharBytesToString(abyte1, abyte1.length);
        }
        int j = t4cmarengine.unmarshalUB2();
        if(j != 0)
        {
            abyte0 = new byte[j];
            t4cmarengine.unmarshalCLR(abyte0, 0, ai);
        }
        int k = t4cmarengine.unmarshalUB2();
        return new KeywordValueI(k, s, abyte0);
    }

}
