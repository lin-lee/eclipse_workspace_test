// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ArrayDataResultSet.java

package oracle.jdbc.driver;

import java.io.*;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.OracleDataFactory;
import oracle.jdbc.OracleResultSet;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            BaseResultSet, PhysicalConnection, OracleConnection, DBConversion, 
//            DatabaseError

class ArrayDataResultSet extends BaseResultSet
{

    Datum data[];
    Map map;
    private int currentIndex;
    private int lastIndex;
    PhysicalConnection connection;
    private Boolean wasNull;
    private int fetchSize;
    ARRAY array;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public ArrayDataResultSet(oracle.jdbc.driver.OracleConnection oracleconnection, Datum adatum[], Map map1)
        throws SQLException
    {
        connection = (PhysicalConnection)oracleconnection;
        data = adatum;
        map = map1;
        currentIndex = 0;
        lastIndex = data != null ? data.length : 0;
        fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
    }

    public ArrayDataResultSet(oracle.jdbc.driver.OracleConnection oracleconnection, Datum adatum[], long l, int i, Map map1)
        throws SQLException
    {
        connection = (PhysicalConnection)oracleconnection;
        data = adatum;
        map = map1;
        currentIndex = (int)l - 1;
        int j = data != null ? data.length : 0;
        lastIndex = currentIndex + Math.min(j - currentIndex, i);
        fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
    }

    public ArrayDataResultSet(oracle.jdbc.driver.OracleConnection oracleconnection, ARRAY array1, long l, int i, Map map1)
        throws SQLException
    {
        connection = (PhysicalConnection)oracleconnection;
        array = array1;
        map = map1;
        currentIndex = (int)l - 1;
        int j = array != null ? array1.length() : 0;
        lastIndex = currentIndex + (i != -1 ? Math.min(j - currentIndex, i) : j - currentIndex);
        fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
    }

    public boolean next()
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "next");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            currentIndex++;
            return currentIndex <= lastIndex;
        }
    }

    public void close()
        throws SQLException
    {
        synchronized(connection)
        {
            super.close();
        }
    }

    public boolean wasNull()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(wasNull == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24, null);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return wasNull.booleanValue();
        Exception exception;
        exception;
        throw exception;
    }

    public String getString(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.stringValue();
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public ResultSet getCursor(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Datum getOracleObject(int i)
        throws SQLException
    {
        if(currentIndex <= 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14, null);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i == 1)
        {
            wasNull = Boolean.FALSE;
            return new NUMBER(currentIndex);
        }
        if(i == 2)
        {
            if(data != null)
            {
                wasNull = data[currentIndex - 1] != null ? Boolean.FALSE : Boolean.TRUE;
                return data[currentIndex - 1];
            }
            if(array != null)
            {
                Datum adatum[] = array.getOracleArray(currentIndex, 1);
                if(adatum != null && adatum.length >= 1)
                {
                    wasNull = adatum[0] != null ? Boolean.FALSE : Boolean.TRUE;
                    return adatum[0];
                }
            }
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Out of sync");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, null);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
    }

    public ROWID getROWID(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof ROWID)
            return (ROWID)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public NUMBER getNUMBER(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof NUMBER)
            return (NUMBER)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public DATE getDATE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof DATE)
            return (DATE)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public ARRAY getARRAY(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof ARRAY)
            return (ARRAY)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public STRUCT getSTRUCT(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof STRUCT)
            return (STRUCT)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public OPAQUE getOPAQUE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof OPAQUE)
            return (OPAQUE)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public REF getREF(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof REF)
            return (REF)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public CHAR getCHAR(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof CHAR)
            return (CHAR)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public RAW getRAW(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof RAW)
            return (RAW)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public BLOB getBLOB(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof BLOB)
            return (BLOB)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public CLOB getCLOB(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof CLOB)
            return (CLOB)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public BFILE getBFILE(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof BFILE)
            return (BFILE)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public INTERVALDS getINTERVALDS(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_50;
        if(datum instanceof INTERVALDS)
            return (INTERVALDS)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public INTERVALYM getINTERVALYM(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_50;
        if(datum instanceof INTERVALYM)
            return (INTERVALYM)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public BFILE getBfile(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getBFILE(i);
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof TIMESTAMP)
            return (TIMESTAMP)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof TIMESTAMPTZ)
            return (TIMESTAMPTZ)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_52;
        if(datum instanceof TIMESTAMPLTZ)
            return (TIMESTAMPLTZ)datum;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean getBoolean(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.booleanValue();
        false;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public oracle.jdbc.OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int i)
        throws SQLException
    {
        return null;
    }

    public byte getByte(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.byteValue();
        0;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public short getShort(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        long l = getLong(i);
        if(l > 0x10001L || l < 0xfffffffffffefffeL)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return (short)(int)l;
        Exception exception;
        exception;
        throw exception;
    }

    public int getInt(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.intValue();
        0;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public long getLong(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.longValue();
        0L;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public float getFloat(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.floatValue();
        0.0F;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public double getDouble(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.doubleValue();
        0.0D;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public BigDecimal getBigDecimal(int i, int j)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.bigDecimalValue();
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public byte[] getBytes(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_55;
        if(datum instanceof RAW)
            return ((RAW)datum).shareBytes();
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBytes");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Date getDate(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.dateValue();
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Time getTime(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.timeValue();
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Timestamp getTimestamp(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.timestampValue();
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getAsciiStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            datum.asciiStreamValue();
        return null;
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getUnicodeStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum;
        DBConversion dbconversion;
        byte abyte0[];
        datum = getOracleObject(i);
        if(datum == null)
            break MISSING_BLOCK_LABEL_113;
        dbconversion = connection.conversion;
        abyte0 = datum.shareBytes();
        if(datum instanceof RAW)
        {
            connection;
            return dbconversion.ConvertStream(new ByteArrayInputStream(abyte0), 3);
        }
        if(!(datum instanceof CHAR)) goto _L2; else goto _L1
_L1:
        connection;
        dbconversion.ConvertStream(new ByteArrayInputStream(abyte0), 1);
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public InputStream getBinaryStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.binaryStreamValue();
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Object obj = getObject(i);
        return oracledatafactory.create(obj, 0);
        Exception exception;
        exception;
        throw exception;
    }

    public Object getObject(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getObject(i, map);
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method getCustomDatum is deprecated
     */

    public CustomDatum getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        return customdatumfactory.create(datum, 0);
        Exception exception;
        exception;
        throw exception;
    }

    public ORAData getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        return oradatafactory.create(datum, 0);
        Exception exception;
        exception;
        throw exception;
    }

    public ResultSetMetaData getMetaData()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getMetaData");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getMetaData");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public int findColumn(String s)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(s.equalsIgnoreCase("index"))
            return 1;
        if(!s.equalsIgnoreCase("value")) goto _L2; else goto _L1
_L1:
        2;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6, "get_column_index");
        sqlexception.fillInStackTrace();
        throw sqlexception;
        Exception exception;
        exception;
        throw exception;
    }

    public Statement getStatement()
        throws SQLException
    {
        return null;
    }

    public Object getObject(int i, Map map1)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum == null) goto _L2; else goto _L1
_L1:
        if(datum instanceof STRUCT)
            return ((STRUCT)datum).toJdbc(map1);
        datum.toJdbc();
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Ref getRef(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getREF(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Blob getBlob(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getBLOB(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Clob getClob(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getCLOB(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Array getArray(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return getARRAY(i);
        Exception exception;
        exception;
        throw exception;
    }

    public Reader getCharacterStream(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.characterStreamValue();
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public BigDecimal getBigDecimal(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.bigDecimalValue();
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Date getDate(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
        {
            DATE date = null;
            if(datum instanceof DATE)
                date = (DATE)datum;
            else
                date = new DATE(datum.stringValue());
            if(date != null)
                return date.dateValue(calendar);
        }
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Time getTime(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
        {
            DATE date = null;
            if(datum instanceof DATE)
                date = (DATE)datum;
            else
                date = new DATE(datum.stringValue());
            if(date != null)
                return date.timeValue(calendar);
        }
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public Timestamp getTimestamp(int i, Calendar calendar)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum datum = getOracleObject(i);
        if(datum != null)
        {
            DATE date = null;
            if(datum instanceof DATE)
                date = (DATE)datum;
            else
                date = new DATE(datum.stringValue());
            if(date != null)
                return date.timestampValue(calendar);
        }
        null;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public URL getURL(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public String getCursorName()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public NClob getNClob(int i)
        throws SQLException
    {
        Datum datum = getOracleObject(i);
        if(datum != null)
        {
            if(datum instanceof NCLOB)
            {
                return (NCLOB)datum;
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        {
            return null;
        }
    }

    public String getNString(int i)
        throws SQLException
    {
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.stringValue();
        else
            return null;
    }

    public Reader getNCharacterStream(int i)
        throws SQLException
    {
        Datum datum = getOracleObject(i);
        if(datum != null)
            return datum.characterStreamValue();
        else
            return null;
    }

    public RowId getRowId(int i)
        throws SQLException
    {
        return getROWID(i);
    }

    public SQLXML getSQLXML(int i)
        throws SQLException
    {
        Datum datum = getOracleObject(i);
        if(datum != null)
        {
            if(datum instanceof SQLXML)
            {
                return (SQLXML)datum;
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        {
            return null;
        }
    }

    public boolean isBeforeFirst()
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return currentIndex < 1;
        }
    }

    public boolean isAfterLast()
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return currentIndex > lastIndex;
        }
    }

    public boolean isFirst()
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return currentIndex == 1;
        }
    }

    public boolean isLast()
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return currentIndex == lastIndex;
        }
    }

    public int getRow()
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return currentIndex;
        }
    }

    public void setFetchSize(int i)
        throws SQLException
    {
        if(i < 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i == 0)
            fetchSize = OracleConnection.DEFAULT_ROW_PREFETCH;
        else
            fetchSize = i;
    }

    public int getFetchSize()
        throws SQLException
    {
        return fetchSize;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
