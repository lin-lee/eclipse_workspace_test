// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   TypeAccessor.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.oracore.OracleType;

// Referenced classes of package oracle.jdbc.driver:
//            Accessor, OracleStatement, DatabaseError, PhysicalConnection, 
//            CRC64

abstract class TypeAccessor extends Accessor
{

    byte pickledBytes[][];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    TypeAccessor()
    {
    }

    abstract OracleType otypeFromName(String s)
        throws SQLException;

    void initForDescribe(int i, int j, boolean flag, int k, int l, int i1, int j1, 
            int k1, short word0, String s)
        throws SQLException
    {
        describeTypeName = s;
        initForDescribe(i, j, flag, l, i1, k, j1, k1, word0);
    }

    void setOffsets(int i)
    {
        if(!outBind)
        {
            columnIndex = statement.defineByteSubRange;
            statement.defineByteSubRange = columnIndex + i * byteLength;
        }
        if(pickledBytes == null || pickledBytes.length < i)
            pickledBytes = new byte[i][];
    }

    byte[] pickledBytes(int i)
    {
        return pickledBytes[i];
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        internalTypeMaxLength = 0;
        internalTypeName = s;
    }

    void initMetadata()
        throws SQLException
    {
        if(describeOtype == null && describeTypeName != null)
            describeOtype = otypeFromName(describeTypeName);
        if(internalOtype == null && internalTypeName != null)
            internalOtype = otypeFromName(internalTypeName);
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        byte abyte0[] = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            byte abyte1[] = pickledBytes(i);
            int j = abyte1.length;
            abyte0 = new byte[j];
            System.arraycopy(abyte1, 0, abyte0, 0, j);
        }
        return abyte0;
    }

    long updateChecksum(long l, int i)
        throws SQLException
    {
        byte abyte0[] = pickledBytes(i);
        if(abyte0 == null || abyte0.length == 0)
        {
            CRC64 _tmp = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, NULL_DATA_BYTES, 0, NULL_DATA_BYTES.length);
        } else
        {
            CRC64 _tmp1 = PhysicalConnection.CHECKSUM;
            l = CRC64.updateChecksum(l, abyte0, 0, abyte0.length);
        }
        return l;
    }

}
