// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFEventListener.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.util.EventListener;
import java.util.concurrent.Executor;
import oracle.jdbc.aq.AQNotificationListener;
import oracle.jdbc.dcn.DatabaseChangeListener;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.XSEventListener;

// Referenced classes of package oracle.jdbc.driver:
//            DatabaseError

class NTFEventListener
{

    private final AQNotificationListener aqlistener;
    private final DatabaseChangeListener dcnlistener;
    private final XSEventListener xslistener;
    private Executor executor;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFEventListener(DatabaseChangeListener databasechangelistener)
        throws SQLException
    {
        executor = null;
        if(databasechangelistener == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 246);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            dcnlistener = databasechangelistener;
            aqlistener = null;
            xslistener = null;
            return;
        }
    }

    NTFEventListener(AQNotificationListener aqnotificationlistener)
        throws SQLException
    {
        executor = null;
        if(aqnotificationlistener == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 246);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            aqlistener = aqnotificationlistener;
            dcnlistener = null;
            xslistener = null;
            return;
        }
    }

    NTFEventListener(XSEventListener xseventlistener)
        throws SQLException
    {
        executor = null;
        if(xseventlistener == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 246);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            aqlistener = null;
            dcnlistener = null;
            xslistener = xseventlistener;
            return;
        }
    }

    void setExecutor(Executor executor1)
    {
        executor = executor1;
    }

    Executor getExecutor()
    {
        return executor;
    }

    EventListener getListener()
    {
        Object obj = dcnlistener;
        if(obj == null)
            obj = aqlistener;
        return ((EventListener) (obj));
    }

    AQNotificationListener getAQListener()
    {
        return aqlistener;
    }

    DatabaseChangeListener getDCNListener()
    {
        return dcnlistener;
    }

    XSEventListener getXSEventListener()
    {
        return xslistener;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
