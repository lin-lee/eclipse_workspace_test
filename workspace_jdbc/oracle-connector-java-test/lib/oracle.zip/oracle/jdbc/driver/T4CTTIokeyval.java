// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIokeyval.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, Namespace, T4CMAREngine, DBConversion, 
//            T4CConnection

final class T4CTTIokeyval extends T4CTTIfun
{

    static final byte KVASET_KPDUSR = 1;
    static final byte KVACLA_KPDUSR = 2;
    private byte namespaceByteArr[];
    private char charArr[];
    private byte attrArr[][];
    private int attrArrSize[];
    private byte valueArr[][];
    private int valueArrSize[];
    private byte kvalflg[];
    private int nbNamespaceBytes;
    private int nbKeyVal;
    private boolean clear;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIokeyval(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)17);
        setFunCode((short)154);
        namespaceByteArr = new byte[100];
        charArr = new char[100];
        attrArr = new byte[10][];
        attrArrSize = new int[10];
        valueArr = new byte[10][];
        valueArrSize = new int[10];
        kvalflg = new byte[10];
    }

    void doOKEYVAL(Namespace namespace)
        throws IOException, SQLException
    {
        String s = namespace.name;
        String as[] = namespace.keys;
        String as1[] = namespace.values;
        clear = namespace.clear;
        nbKeyVal = namespace.nbPairs;
        int i = s.length() * meg.conv.cMaxCharSize;
        if(i > namespaceByteArr.length)
            namespaceByteArr = new byte[i];
        if(s.length() > charArr.length)
            charArr = new char[s.length()];
        s.getChars(0, s.length(), charArr, 0);
        nbNamespaceBytes = meg.conv.javaCharsToCHARBytes(charArr, 0, namespaceByteArr, 0, s.length());
        if(nbKeyVal > 0)
        {
            if(nbKeyVal > attrArr.length)
            {
                attrArr = new byte[nbKeyVal][];
                attrArrSize = new int[nbKeyVal];
                valueArr = new byte[nbKeyVal][];
                valueArrSize = new int[nbKeyVal];
                kvalflg = new byte[nbKeyVal];
            }
            for(int j = 0; j < nbKeyVal; j++)
            {
                String s1 = as[j];
                String s2 = as1[j];
                int k = s1.length() * meg.conv.cMaxCharSize;
                if(attrArr[j] == null || attrArr[j].length < k)
                    attrArr[j] = new byte[k];
                int l = s2.length() * meg.conv.cMaxCharSize;
                if(valueArr[j] == null || valueArr[j].length < l)
                    valueArr[j] = new byte[l];
                if(s1.length() > charArr.length)
                    charArr = new char[s1.length()];
                s1.getChars(0, s1.length(), charArr, 0);
                attrArrSize[j] = meg.conv.javaCharsToCHARBytes(charArr, 0, attrArr[j], 0, s1.length());
                if(s2.length() > charArr.length)
                    charArr = new char[s2.length()];
                s2.getChars(0, s2.length(), charArr, 0);
                valueArrSize[j] = meg.conv.javaCharsToCHARBytes(charArr, 0, valueArr[j], 0, s2.length());
            }

        }
        doPigRPC();
    }

    void marshal()
        throws IOException
    {
        meg.marshalPTR();
        meg.marshalUB4(nbNamespaceBytes);
        if(nbKeyVal > 0)
            meg.marshalPTR();
        else
            meg.marshalNULLPTR();
        meg.marshalUB4(nbKeyVal);
        int i = 0;
        if(nbKeyVal > 0)
            i = 1;
        if(clear)
            i |= 2;
        meg.marshalUB2(i);
        meg.marshalNULLPTR();
        meg.marshalCHR(namespaceByteArr, 0, nbNamespaceBytes);
        if(nbKeyVal > 0)
            meg.marshalKEYVAL(attrArr, attrArrSize, valueArr, valueArrSize, kvalflg, nbKeyVal);
    }

}
