// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleCallableStatement.java

package oracle.jdbc.driver;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.OracleDataFactory;
import oracle.sql.ANYDATA;
import oracle.sql.ARRAY;
import oracle.sql.BFILE;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BLOB;
import oracle.sql.CHAR;
import oracle.sql.CLOB;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.NUMBER;
import oracle.sql.OPAQUE;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.RAW;
import oracle.sql.REF;
import oracle.sql.ROWID;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;

// Referenced classes of package oracle.jdbc.driver:
//            OraclePreparedStatement, Accessor, PlsqlIndexTableAccessor, DatabaseError, 
//            OracleSql, PhysicalConnection

abstract class OracleCallableStatement extends OraclePreparedStatement
    implements oracle.jdbc.internal.OracleCallableStatement
{

    boolean atLeastOneOrdinalParameter;
    boolean atLeastOneNamedParameter;
    String namedParameters[];
    int parameterCount;
    final String errMsgMixedBind = "Ordinal binding and Named binding cannot be combined!";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleCallableStatement(PhysicalConnection physicalconnection, String s, int i, int j)
        throws SQLException
    {
        this(physicalconnection, s, i, j, 1003, 1007);
    }

    OracleCallableStatement(PhysicalConnection physicalconnection, String s, int i, int j, int k, int l)
        throws SQLException
    {
        super(physicalconnection, s, 1, j, k, l);
        atLeastOneOrdinalParameter = false;
        atLeastOneNamedParameter = false;
        namedParameters = new String[8];
        parameterCount = 0;
        statementType = 2;
    }

    void registerOutParameterInternal(int i, int j, int k, int l, String s)
        throws SQLException
    {
        int i1 = i - 1;
        if(i1 < 0 || i > numberOfBindPositions)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(j == 0)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        int j1 = getInternalType(j);
        resetBatch();
        currentRowNeedToPrepareBinds = true;
        if(currentRowBindAccessors == null)
            currentRowBindAccessors = new Accessor[numberOfBindPositions];
        switch(j)
        {
        case -16: 
        case -15: 
        case -9: 
            currentRowFormOfUse[i1] = 2;
            break;

        case 2011: 
            l = 0;
            currentRowFormOfUse[i1] = 2;
            break;

        case 2009: 
            l = 0;
            s = "SYS.XMLTYPE";
            break;

        default:
            l = 0;
            break;

        case -4: 
        case -3: 
        case -1: 
        case 1: // '\001'
        case 12: // '\f'
        case 70: // 'F'
            break;
        }
        currentRowBindAccessors[i1] = allocateAccessor(j1, j, i1 + 1, l, currentRowFormOfUse[i1], s, true);
    }

    public void registerOutParameter(int i, int j, String s)
        throws SQLException
    {
        if(s == null || s.length() == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "empty Object name");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        synchronized(connection)
        {
            registerOutParameterInternal(i, j, 0, 0, s);
        }
    }

    /**
     * @deprecated Method registerOutParameterBytes is deprecated
     */

    public void registerOutParameterBytes(int i, int j, int k, int l)
        throws SQLException
    {
        synchronized(connection)
        {
            registerOutParameterInternal(i, j, k, l, null);
        }
    }

    /**
     * @deprecated Method registerOutParameterChars is deprecated
     */

    public void registerOutParameterChars(int i, int j, int k, int l)
        throws SQLException
    {
        synchronized(connection)
        {
            registerOutParameterInternal(i, j, k, l, null);
        }
    }

    public void registerOutParameter(int i, int j, int k, int l)
        throws SQLException
    {
        synchronized(connection)
        {
            registerOutParameterInternal(i, j, k, l, null);
        }
    }

    public void registerOutParameter(String s, int i, int j, int k)
        throws SQLException
    {
        synchronized(connection)
        {
            registerOutParameterInternal(s, i, j, k, null);
        }
    }

    boolean isOracleBatchStyle()
    {
        return false;
    }

    void resetBatch()
    {
        batch = 1;
    }

    public void setExecuteBatch(int i)
        throws SQLException
    {
    }

    public int sendBatch()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        return validRows;
        Exception exception;
        exception;
        throw exception;
    }

    public void registerOutParameter(int i, int j)
        throws SQLException
    {
        registerOutParameter(i, j, 0, -1);
    }

    public void registerOutParameter(int i, int j, int k)
        throws SQLException
    {
        registerOutParameter(i, j, k, -1);
    }

    public boolean wasNull()
        throws SQLException
    {
        return wasNullValue();
    }

    public String getString(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getString(currentRank);
    }

    public Datum getOracleObject(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getOracleObject(currentRank);
    }

    public ROWID getROWID(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getROWID(currentRank);
    }

    public NUMBER getNUMBER(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getNUMBER(currentRank);
    }

    public DATE getDATE(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getDATE(currentRank);
    }

    public INTERVALYM getINTERVALYM(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getINTERVALYM(currentRank);
    }

    public INTERVALDS getINTERVALDS(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getINTERVALDS(currentRank);
    }

    public TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getTIMESTAMP(currentRank);
    }

    public TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getTIMESTAMPTZ(currentRank);
    }

    public TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getTIMESTAMPLTZ(currentRank);
    }

    public REF getREF(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getREF(currentRank);
    }

    public ARRAY getARRAY(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getARRAY(currentRank);
    }

    public STRUCT getSTRUCT(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getSTRUCT(currentRank);
    }

    public OPAQUE getOPAQUE(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getOPAQUE(currentRank);
    }

    public CHAR getCHAR(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getCHAR(currentRank);
    }

    public Reader getCharacterStream(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getCharacterStream(currentRank);
    }

    public RAW getRAW(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getRAW(currentRank);
    }

    public BLOB getBLOB(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBLOB(currentRank);
    }

    public CLOB getCLOB(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getCLOB(currentRank);
    }

    public BFILE getBFILE(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBFILE(currentRank);
    }

    public BFILE getBfile(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBFILE(currentRank);
    }

    public boolean getBoolean(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBoolean(currentRank);
    }

    public byte getByte(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getByte(currentRank);
    }

    public short getShort(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getShort(currentRank);
    }

    public int getInt(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getInt(currentRank);
    }

    public long getLong(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getLong(currentRank);
    }

    public float getFloat(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getFloat(currentRank);
    }

    public double getDouble(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getDouble(currentRank);
    }

    public BigDecimal getBigDecimal(int i, int j)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBigDecimal(currentRank);
    }

    public byte[] getBytes(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBytes(currentRank);
    }

    public byte[] privateGetBytes(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.privateGetBytes(currentRank);
    }

    public Date getDate(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getDate(currentRank);
    }

    public Time getTime(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getTime(currentRank);
    }

    public Timestamp getTimestamp(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getTimestamp(currentRank);
    }

    public InputStream getAsciiStream(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getAsciiStream(currentRank);
    }

    public InputStream getUnicodeStream(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getUnicodeStream(currentRank);
    }

    public InputStream getBinaryStream(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBinaryStream(currentRank);
    }

    public Object getObject(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getObject(currentRank);
    }

    public Object getAnyDataEmbeddedObject(int i)
        throws SQLException
    {
        Object obj = null;
        Object obj1 = getObject(i);
        if(obj1 instanceof ANYDATA)
        {
            Datum datum = ((ANYDATA)obj1).accessDatum();
            if(datum != null)
                obj = datum.toJdbc();
        }
        return obj;
    }

    public Object getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getCustomDatum(currentRank, customdatumfactory);
    }

    public Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getObject(currentRank, oracledatafactory);
    }

    public Object getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getORAData(currentRank, oradatafactory);
    }

    public ResultSet getCursor(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getCursor(currentRank);
    }

    public void clearParameters()
        throws SQLException
    {
        synchronized(connection)
        {
            super.clearParameters();
        }
    }

    public Object getObject(int i, Map map)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getObject(currentRank, map);
    }

    public Ref getRef(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getREF(currentRank);
    }

    public Blob getBlob(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBLOB(currentRank);
    }

    public Clob getClob(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getCLOB(currentRank);
    }

    public Array getArray(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getARRAY(currentRank);
    }

    public BigDecimal getBigDecimal(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBigDecimal(currentRank);
    }

    public Date getDate(int i, Calendar calendar)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getDate(currentRank, calendar);
    }

    public Time getTime(int i, Calendar calendar)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getTime(currentRank, calendar);
    }

    public Timestamp getTimestamp(int i, Calendar calendar)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getTimestamp(currentRank, calendar);
    }

    public void addBatch()
        throws SQLException
    {
        if(currentRowBindAccessors != null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Stored procedure with out or inout parameters cannot be batched");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            super.addBatch();
            return;
        }
    }

    protected void alwaysOnClose()
        throws SQLException
    {
        sqlObject.resetNamedParameters();
        namedParameters = new String[8];
        parameterCount = 0;
        atLeastOneOrdinalParameter = false;
        atLeastOneNamedParameter = false;
        super.alwaysOnClose();
    }

    public void registerOutParameter(String s, int i)
        throws SQLException
    {
        registerOutParameterInternal(s, i, 0, -1, null);
    }

    public void registerOutParameter(String s, int i, int j)
        throws SQLException
    {
        registerOutParameterInternal(s, i, j, -1, null);
    }

    public void registerOutParameter(String s, int i, String s1)
        throws SQLException
    {
        registerOutParameterInternal(s, i, 0, -1, s1);
    }

    void registerOutParameterInternal(String s, int i, int j, int k, String s1)
        throws SQLException
    {
        int l = addNamedPara(s);
        registerOutParameterInternal(l, i, j, k, s1);
    }

    public URL getURL(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getURL(currentRank);
    }

    public void setStringForClob(String s, String s1)
        throws SQLException
    {
        int i = addNamedPara(s);
        if(s1 == null || s1.length() == 0)
        {
            setNull(i, 2005);
            return;
        } else
        {
            setStringForClob(i, s1);
            return;
        }
    }

    public void setStringForClob(int i, String s)
        throws SQLException
    {
        if(s == null || s.length() == 0)
        {
            setNull(i, 2005);
            return;
        }
        synchronized(connection)
        {
            setStringForClobCritical(i, s);
        }
    }

    public void setBytesForBlob(String s, byte abyte0[])
        throws SQLException
    {
        int i = addNamedPara(s);
        setBytesForBlob(i, abyte0);
    }

    public void setBytesForBlob(int i, byte abyte0[])
        throws SQLException
    {
        if(abyte0 == null || abyte0.length == 0)
        {
            setNull(i, 2004);
            return;
        }
        synchronized(connection)
        {
            setBytesForBlobCritical(i, abyte0);
        }
    }

    public String getString(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getString(currentRank);
    }

    public boolean getBoolean(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBoolean(currentRank);
    }

    public byte getByte(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getByte(currentRank);
    }

    public short getShort(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getShort(currentRank);
    }

    public int getInt(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getInt(currentRank);
    }

    public long getLong(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getLong(currentRank);
    }

    public float getFloat(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getFloat(currentRank);
    }

    public double getDouble(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getDouble(currentRank);
    }

    public byte[] getBytes(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBytes(currentRank);
    }

    public Date getDate(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getDate(currentRank);
    }

    public Time getTime(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getTime(currentRank);
    }

    public Timestamp getTimestamp(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getTimestamp(currentRank);
    }

    public Object getObject(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getObject(currentRank);
    }

    public BigDecimal getBigDecimal(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBigDecimal(currentRank);
    }

    public BigDecimal getBigDecimal(String s, int i)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int j;
        for(j = 0; j < parameterCount && s1 != namedParameters[j]; j++);
        j++;
        Accessor accessor = null;
        if(j <= 0 || j > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[j - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = j;
        if(streamList != null)
            closeUsedStreams(j);
        return accessor.getBigDecimal(currentRank, i);
    }

    public Object getObject(String s, Map map)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getObject(currentRank, map);
    }

    public Ref getRef(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getREF(currentRank);
    }

    public Blob getBlob(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBLOB(currentRank);
    }

    public Clob getClob(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getCLOB(currentRank);
    }

    public Array getArray(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getARRAY(currentRank);
    }

    public Date getDate(String s, Calendar calendar)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getDate(currentRank, calendar);
    }

    public Time getTime(String s, Calendar calendar)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getTime(currentRank, calendar);
    }

    public Timestamp getTimestamp(String s, Calendar calendar)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getTimestamp(currentRank, calendar);
    }

    public URL getURL(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getURL(currentRank);
    }

    /**
     * @deprecated Method getAsciiStream is deprecated
     */

    public InputStream getAsciiStream(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerIndexTableOutParameter(int i, int j, int k, int l)
        throws SQLException
    {
        synchronized(connection)
        {
            int i1 = i - 1;
            if(i1 < 0 || i > numberOfBindPositions)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            int j1 = getInternalType(k);
            resetBatch();
            currentRowNeedToPrepareBinds = true;
            if(currentRowBindAccessors == null)
                currentRowBindAccessors = new Accessor[numberOfBindPositions];
            currentRowBindAccessors[i1] = allocateIndexTableAccessor(k, j1, l, j, currentRowFormOfUse[i1], true);
            hasIbtBind = true;
        }
    }

    PlsqlIndexTableAccessor allocateIndexTableAccessor(int i, int j, int k, int l, short word0, boolean flag)
        throws SQLException
    {
        return new PlsqlIndexTableAccessor(this, i, j, k, l, word0, flag);
    }

    public Object getPlsqlIndexTable(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum adatum[] = getOraclePlsqlIndexTable(i);
        PlsqlIndexTableAccessor plsqlindextableaccessor = (PlsqlIndexTableAccessor)outBindAccessors[i - 1];
        int j = plsqlindextableaccessor.elementInternalType;
        Object aobj[] = null;
        switch(j)
        {
        case 9: // '\t'
            aobj = new String[adatum.length];
            break;

        case 6: // '\006'
            aobj = new BigDecimal[adatum.length];
            break;

        default:
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid column type");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        for(int k = 0; k < aobj.length; k++)
            aobj[k] = adatum[k] == null || adatum[k].getLength() == 0L ? null : adatum[k].toJdbc();

        return ((Object) (aobj));
        Exception exception;
        exception;
        throw exception;
    }

    public Object getPlsqlIndexTable(int i, Class class1)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        Datum adatum[];
        String s;
        adatum = getOraclePlsqlIndexTable(i);
        if(class1 == null || !class1.isPrimitive())
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        s = class1.getName();
        if(s.equals("byte"))
        {
            byte abyte0[] = new byte[adatum.length];
            for(int j = 0; j < adatum.length; j++)
                abyte0[j] = adatum[j] == null ? 0 : adatum[j].byteValue();

            return abyte0;
        }
        if(!s.equals("char")) goto _L2; else goto _L1
_L1:
        double ad[];
        ad = new char[adatum.length];
        for(int k = 0; k < adatum.length; k++)
            ad[k] = adatum[k] == null || adatum[k].getLength() == 0L ? '\0' : (char)adatum[k].intValue();

        ad;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        if(!s.equals("double")) goto _L4; else goto _L3
_L3:
        ad = new double[adatum.length];
        for(int l = 0; l < adatum.length; l++)
            ad[l] = adatum[l] == null || adatum[l].getLength() == 0L ? 0.0D : adatum[l].doubleValue();

        ad;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L4:
        if(!s.equals("float")) goto _L6; else goto _L5
_L5:
        ad = new float[adatum.length];
        for(int i1 = 0; i1 < adatum.length; i1++)
            ad[i1] = adatum[i1] == null || adatum[i1].getLength() == 0L ? 0.0F : adatum[i1].floatValue();

        ad;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L6:
        if(!s.equals("int")) goto _L8; else goto _L7
_L7:
        ad = new int[adatum.length];
        for(int j1 = 0; j1 < adatum.length; j1++)
            ad[j1] = adatum[j1] == null || adatum[j1].getLength() == 0L ? 0 : adatum[j1].intValue();

        ad;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L8:
        if(!s.equals("long")) goto _L10; else goto _L9
_L9:
        ad = new long[adatum.length];
        for(int k1 = 0; k1 < adatum.length; k1++)
            ad[k1] = adatum[k1] == null || adatum[k1].getLength() == 0L ? 0L : adatum[k1].longValue();

        ad;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L10:
        if(!s.equals("short")) goto _L12; else goto _L11
_L11:
        ad = new short[adatum.length];
        for(int l1 = 0; l1 < adatum.length; l1++)
            ad[l1] = adatum[l1] == null || adatum[l1].getLength() == 0L ? 0 : (short)adatum[l1].intValue();

        ad;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L12:
        if(!s.equals("boolean")) goto _L14; else goto _L13
_L13:
        ad = new boolean[adatum.length];
        for(int i2 = 0; i2 < adatum.length; i2++)
            ad[i2] = adatum[i2] == null || adatum[i2].getLength() == 0L ? false : adatum[i2].booleanValue();

        ad;
        physicalconnection;
        JVM INSTR monitorexit ;
        return;
_L14:
        SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
        sqlexception1.fillInStackTrace();
        throw sqlexception1;
        Exception exception;
        exception;
        throw exception;
    }

    public Datum[] getOraclePlsqlIndexTable(int i)
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getOraclePlsqlIndexTable(currentRank);
        Exception exception;
        exception;
        throw exception;
    }

    public boolean execute()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        if(atLeastOneNamedParameter && atLeastOneOrdinalParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(sqlObject.setNamedParameters(parameterCount, namedParameters))
            needToParse = true;
        return super.execute();
        Exception exception;
        exception;
        throw exception;
    }

    public int executeUpdate()
        throws SQLException
    {
        PhysicalConnection physicalconnection = connection;
        JVM INSTR monitorenter ;
        ensureOpen();
        if(atLeastOneNamedParameter && atLeastOneOrdinalParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(sqlObject.setNamedParameters(parameterCount, namedParameters))
            needToParse = true;
        return super.executeUpdate();
        Exception exception;
        exception;
        throw exception;
    }

    void releaseBuffers()
    {
        if(outBindAccessors != null)
        {
            int i = outBindAccessors.length;
            for(int j = 0; j < i; j++)
                if(outBindAccessors[j] != null)
                {
                    outBindAccessors[j].rowSpaceByte = null;
                    outBindAccessors[j].rowSpaceChar = null;
                }

        }
        super.releaseBuffers();
    }

    void doLocalInitialization()
    {
        if(outBindAccessors != null)
        {
            int i = outBindAccessors.length;
            for(int j = 0; j < i; j++)
                if(outBindAccessors[j] != null)
                {
                    outBindAccessors[j].rowSpaceByte = bindBytes;
                    outBindAccessors[j].rowSpaceChar = bindChars;
                }

        }
    }

    public void setArray(int i, Array array)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setArrayInternal(i, array);
    }

    public void setBigDecimal(int i, BigDecimal bigdecimal)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBigDecimalInternal(i, bigdecimal);
        }
    }

    public void setBlob(int i, Blob blob)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBlobInternal(i, blob);
        }
    }

    public void setBoolean(int i, boolean flag)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBooleanInternal(i, flag);
        }
    }

    public void setByte(int i, byte byte0)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setByteInternal(i, byte0);
        }
    }

    public void setBytes(int i, byte abyte0[])
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBytesInternal(i, abyte0);
        }
    }

    public void setClob(int i, Clob clob)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setClobInternal(i, clob);
        }
    }

    public void setDate(int i, Date date)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setDateInternal(i, date);
        }
    }

    public void setDate(int i, Date date, Calendar calendar)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setDateInternal(i, date, calendar);
        }
    }

    public void setDouble(int i, double d)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setDoubleInternal(i, d);
        }
    }

    public void setFloat(int i, float f)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setFloatInternal(i, f);
        }
    }

    public void setInt(int i, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setIntInternal(i, j);
        }
    }

    public void setLong(int i, long l)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setLongInternal(i, l);
        }
    }

    public void setNClob(int i, NClob nclob)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setNClobInternal(i, nclob);
        }
    }

    public void setNString(int i, String s)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setNStringInternal(i, s);
        }
    }

    public void setObject(int i, Object obj)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setObjectInternal(i, obj);
    }

    public void setObject(int i, Object obj, int j)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setObjectInternal(i, obj, j);
    }

    public void setRef(int i, Ref ref)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setRefInternal(i, ref);
    }

    public void setRowId(int i, RowId rowid)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setRowIdInternal(i, rowid);
        }
    }

    public void setShort(int i, short word0)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setShortInternal(i, word0);
        }
    }

    public void setSQLXML(int i, SQLXML sqlxml)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setSQLXMLInternal(i, sqlxml);
        }
    }

    public void setString(int i, String s)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setStringInternal(i, s);
        }
    }

    public void setTime(int i, Time time)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setTimeInternal(i, time);
        }
    }

    public void setTime(int i, Time time, Calendar calendar)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setTimeInternal(i, time, calendar);
        }
    }

    public void setTimestamp(int i, Timestamp timestamp)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setTimestampInternal(i, timestamp);
        }
    }

    public void setTimestamp(int i, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setTimestampInternal(i, timestamp, calendar);
        }
    }

    public void setURL(int i, URL url)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setURLInternal(i, url);
        }
    }

    public void setARRAY(int i, ARRAY array)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setARRAYInternal(i, array);
    }

    public void setBFILE(int i, BFILE bfile)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBFILEInternal(i, bfile);
        }
    }

    public void setBfile(int i, BFILE bfile)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBfileInternal(i, bfile);
        }
    }

    public void setBinaryFloat(int i, float f)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBinaryFloatInternal(i, f);
        }
    }

    public void setBinaryFloat(int i, BINARY_FLOAT binary_float)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBinaryFloatInternal(i, binary_float);
        }
    }

    public void setBinaryDouble(int i, double d)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBinaryDoubleInternal(i, d);
        }
    }

    public void setBinaryDouble(int i, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBinaryDoubleInternal(i, binary_double);
        }
    }

    public void setBLOB(int i, BLOB blob)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBLOBInternal(i, blob);
        }
    }

    public void setCHAR(int i, CHAR char1)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setCHARInternal(i, char1);
        }
    }

    public void setCLOB(int i, CLOB clob)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setCLOBInternal(i, clob);
        }
    }

    public void setCursor(int i, ResultSet resultset)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setCursorInternal(i, resultset);
        }
    }

    public void setCustomDatum(int i, CustomDatum customdatum)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setCustomDatumInternal(i, customdatum);
    }

    public void setDATE(int i, DATE date)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setDATEInternal(i, date);
        }
    }

    public void setFixedCHAR(int i, String s)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setFixedCHARInternal(i, s);
        }
    }

    public void setINTERVALDS(int i, INTERVALDS intervalds)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setINTERVALDSInternal(i, intervalds);
        }
    }

    public void setINTERVALYM(int i, INTERVALYM intervalym)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setINTERVALYMInternal(i, intervalym);
        }
    }

    public void setNUMBER(int i, NUMBER number)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setNUMBERInternal(i, number);
        }
    }

    public void setOPAQUE(int i, OPAQUE opaque)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setOPAQUEInternal(i, opaque);
    }

    public void setOracleObject(int i, Datum datum)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setOracleObjectInternal(i, datum);
    }

    public void setORAData(int i, ORAData oradata)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setORADataInternal(i, oradata);
    }

    public void setRAW(int i, RAW raw)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setRAWInternal(i, raw);
        }
    }

    public void setREF(int i, REF ref)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setREFInternal(i, ref);
    }

    public void setRefType(int i, REF ref)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setRefTypeInternal(i, ref);
    }

    public void setROWID(int i, ROWID rowid)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setROWIDInternal(i, rowid);
        }
    }

    public void setSTRUCT(int i, STRUCT struct)
        throws SQLException
    {
        atLeastOneOrdinalParameter = true;
        setSTRUCTInternal(i, struct);
    }

    public void setTIMESTAMPLTZ(int i, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setTIMESTAMPLTZInternal(i, timestampltz);
        }
    }

    public void setTIMESTAMPTZ(int i, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setTIMESTAMPTZInternal(i, timestamptz);
        }
    }

    public void setTIMESTAMP(int i, TIMESTAMP timestamp)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setTIMESTAMPInternal(i, timestamp);
        }
    }

    public void setBlob(int i, InputStream inputstream)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBlobInternal(i, inputstream);
        }
    }

    public void setBlob(int i, InputStream inputstream, long l)
        throws SQLException
    {
        synchronized(connection)
        {
            if(l < 0L)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            atLeastOneOrdinalParameter = true;
            setBlobInternal(i, inputstream, l);
        }
    }

    public void setClob(int i, Reader reader)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setClobInternal(i, reader);
        }
    }

    public void setClob(int i, Reader reader, long l)
        throws SQLException
    {
        synchronized(connection)
        {
            if(l < 0L)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            atLeastOneOrdinalParameter = true;
            setClobInternal(i, reader, l);
        }
    }

    public void setNClob(int i, Reader reader)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setNClobInternal(i, reader);
        }
    }

    public void setNClob(int i, Reader reader, long l)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setNClobInternal(i, reader, l);
        }
    }

    public void setAsciiStream(int i, InputStream inputstream)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setAsciiStreamInternal(i, inputstream);
        }
    }

    public void setAsciiStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setAsciiStreamInternal(i, inputstream, j);
        }
    }

    public void setAsciiStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setAsciiStreamInternal(i, inputstream, l);
        }
    }

    public void setBinaryStream(int i, InputStream inputstream)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBinaryStreamInternal(i, inputstream);
        }
    }

    public void setBinaryStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBinaryStreamInternal(i, inputstream, j);
        }
    }

    public void setBinaryStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setBinaryStreamInternal(i, inputstream, l);
        }
    }

    public void setCharacterStream(int i, Reader reader)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setCharacterStreamInternal(i, reader);
        }
    }

    public void setCharacterStream(int i, Reader reader, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setCharacterStreamInternal(i, reader, j);
        }
    }

    public void setCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setCharacterStreamInternal(i, reader, l);
        }
    }

    public void setNCharacterStream(int i, Reader reader)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setNCharacterStreamInternal(i, reader);
        }
    }

    public void setNCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setNCharacterStreamInternal(i, reader, l);
        }
    }

    public void setUnicodeStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setUnicodeStreamInternal(i, inputstream, j);
        }
    }

    public void setArray(String s, Array array)
        throws SQLException
    {
        int i = addNamedPara(s);
        setArrayInternal(i, array);
    }

    public void setBigDecimal(String s, BigDecimal bigdecimal)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBigDecimalInternal(i, bigdecimal);
    }

    public void setBlob(String s, Blob blob)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBlobInternal(i, blob);
    }

    public void setBoolean(String s, boolean flag)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBooleanInternal(i, flag);
    }

    public void setByte(String s, byte byte0)
        throws SQLException
    {
        int i = addNamedPara(s);
        setByteInternal(i, byte0);
    }

    public void setBytes(String s, byte abyte0[])
        throws SQLException
    {
        int i = addNamedPara(s);
        setBytesInternal(i, abyte0);
    }

    public void setClob(String s, Clob clob)
        throws SQLException
    {
        int i = addNamedPara(s);
        setClobInternal(i, clob);
    }

    public void setDate(String s, Date date)
        throws SQLException
    {
        int i = addNamedPara(s);
        setDateInternal(i, date);
    }

    public void setDate(String s, Date date, Calendar calendar)
        throws SQLException
    {
        int i = addNamedPara(s);
        setDateInternal(i, date, calendar);
    }

    public void setDouble(String s, double d)
        throws SQLException
    {
        int i = addNamedPara(s);
        setDoubleInternal(i, d);
    }

    public void setFloat(String s, float f)
        throws SQLException
    {
        int i = addNamedPara(s);
        setFloatInternal(i, f);
    }

    public void setInt(String s, int i)
        throws SQLException
    {
        int j = addNamedPara(s);
        setIntInternal(j, i);
    }

    public void setLong(String s, long l)
        throws SQLException
    {
        int i = addNamedPara(s);
        setLongInternal(i, l);
    }

    public void setNClob(String s, NClob nclob)
        throws SQLException
    {
        int i = addNamedPara(s);
        setNClobInternal(i, nclob);
    }

    public void setNString(String s, String s1)
        throws SQLException
    {
        int i = addNamedPara(s);
        setNStringInternal(i, s1);
    }

    public void setObject(String s, Object obj)
        throws SQLException
    {
        int i = addNamedPara(s);
        setObjectInternal(i, obj);
    }

    public void setObject(String s, Object obj, int i)
        throws SQLException
    {
        int j = addNamedPara(s);
        setObjectInternal(j, obj, i);
    }

    public void setRef(String s, Ref ref)
        throws SQLException
    {
        int i = addNamedPara(s);
        setRefInternal(i, ref);
    }

    public void setRowId(String s, RowId rowid)
        throws SQLException
    {
        int i = addNamedPara(s);
        setRowIdInternal(i, rowid);
    }

    public void setShort(String s, short word0)
        throws SQLException
    {
        int i = addNamedPara(s);
        setShortInternal(i, word0);
    }

    public void setSQLXML(String s, SQLXML sqlxml)
        throws SQLException
    {
        int i = addNamedPara(s);
        setSQLXMLInternal(i, sqlxml);
    }

    public void setString(String s, String s1)
        throws SQLException
    {
        int i = addNamedPara(s);
        setStringInternal(i, s1);
    }

    public void setTime(String s, Time time)
        throws SQLException
    {
        int i = addNamedPara(s);
        setTimeInternal(i, time);
    }

    public void setTime(String s, Time time, Calendar calendar)
        throws SQLException
    {
        int i = addNamedPara(s);
        setTimeInternal(i, time, calendar);
    }

    public void setTimestamp(String s, Timestamp timestamp)
        throws SQLException
    {
        int i = addNamedPara(s);
        setTimestampInternal(i, timestamp);
    }

    public void setTimestamp(String s, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        int i = addNamedPara(s);
        setTimestampInternal(i, timestamp, calendar);
    }

    public void setURL(String s, URL url)
        throws SQLException
    {
        int i = addNamedPara(s);
        setURLInternal(i, url);
    }

    public void setARRAY(String s, ARRAY array)
        throws SQLException
    {
        int i = addNamedPara(s);
        setARRAYInternal(i, array);
    }

    public void setBFILE(String s, BFILE bfile)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBFILEInternal(i, bfile);
    }

    public void setBfile(String s, BFILE bfile)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBfileInternal(i, bfile);
    }

    public void setBinaryFloat(String s, float f)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBinaryFloatInternal(i, f);
    }

    public void setBinaryFloat(String s, BINARY_FLOAT binary_float)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBinaryFloatInternal(i, binary_float);
    }

    public void setBinaryDouble(String s, double d)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBinaryDoubleInternal(i, d);
    }

    public void setBinaryDouble(String s, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBinaryDoubleInternal(i, binary_double);
    }

    public void setBLOB(String s, BLOB blob)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBLOBInternal(i, blob);
    }

    public void setCHAR(String s, CHAR char1)
        throws SQLException
    {
        int i = addNamedPara(s);
        setCHARInternal(i, char1);
    }

    public void setCLOB(String s, CLOB clob)
        throws SQLException
    {
        int i = addNamedPara(s);
        setCLOBInternal(i, clob);
    }

    public void setCursor(String s, ResultSet resultset)
        throws SQLException
    {
        int i = addNamedPara(s);
        setCursorInternal(i, resultset);
    }

    public void setCustomDatum(String s, CustomDatum customdatum)
        throws SQLException
    {
        int i = addNamedPara(s);
        setCustomDatumInternal(i, customdatum);
    }

    public void setDATE(String s, DATE date)
        throws SQLException
    {
        int i = addNamedPara(s);
        setDATEInternal(i, date);
    }

    public void setFixedCHAR(String s, String s1)
        throws SQLException
    {
        int i = addNamedPara(s);
        setFixedCHARInternal(i, s1);
    }

    public void setINTERVALDS(String s, INTERVALDS intervalds)
        throws SQLException
    {
        int i = addNamedPara(s);
        setINTERVALDSInternal(i, intervalds);
    }

    public void setINTERVALYM(String s, INTERVALYM intervalym)
        throws SQLException
    {
        int i = addNamedPara(s);
        setINTERVALYMInternal(i, intervalym);
    }

    public void setNUMBER(String s, NUMBER number)
        throws SQLException
    {
        int i = addNamedPara(s);
        setNUMBERInternal(i, number);
    }

    public void setOPAQUE(String s, OPAQUE opaque)
        throws SQLException
    {
        int i = addNamedPara(s);
        setOPAQUEInternal(i, opaque);
    }

    public void setOracleObject(String s, Datum datum)
        throws SQLException
    {
        int i = addNamedPara(s);
        setOracleObjectInternal(i, datum);
    }

    public void setORAData(String s, ORAData oradata)
        throws SQLException
    {
        int i = addNamedPara(s);
        setORADataInternal(i, oradata);
    }

    public void setRAW(String s, RAW raw)
        throws SQLException
    {
        int i = addNamedPara(s);
        setRAWInternal(i, raw);
    }

    public void setREF(String s, REF ref)
        throws SQLException
    {
        int i = addNamedPara(s);
        setREFInternal(i, ref);
    }

    public void setRefType(String s, REF ref)
        throws SQLException
    {
        int i = addNamedPara(s);
        setRefTypeInternal(i, ref);
    }

    public void setROWID(String s, ROWID rowid)
        throws SQLException
    {
        int i = addNamedPara(s);
        setROWIDInternal(i, rowid);
    }

    public void setSTRUCT(String s, STRUCT struct)
        throws SQLException
    {
        int i = addNamedPara(s);
        setSTRUCTInternal(i, struct);
    }

    public void setTIMESTAMPLTZ(String s, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        int i = addNamedPara(s);
        setTIMESTAMPLTZInternal(i, timestampltz);
    }

    public void setTIMESTAMPTZ(String s, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        int i = addNamedPara(s);
        setTIMESTAMPTZInternal(i, timestamptz);
    }

    public void setTIMESTAMP(String s, TIMESTAMP timestamp)
        throws SQLException
    {
        int i = addNamedPara(s);
        setTIMESTAMPInternal(i, timestamp);
    }

    public void setBlob(String s, InputStream inputstream)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBlobInternal(i, inputstream);
    }

    public void setBlob(String s, InputStream inputstream, long l)
        throws SQLException
    {
        if(l < 0L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setBlob() cannot be negative");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            int i = addNamedPara(s);
            setBlobInternal(i, inputstream, l);
            return;
        }
    }

    public void setClob(String s, Reader reader)
        throws SQLException
    {
        int i = addNamedPara(s);
        setClobInternal(i, reader);
    }

    public void setClob(String s, Reader reader, long l)
        throws SQLException
    {
        if(l < 0L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "length for setClob() cannot be negative");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            int i = addNamedPara(s);
            setClobInternal(i, reader, l);
            return;
        }
    }

    public void setNClob(String s, Reader reader)
        throws SQLException
    {
        int i = addNamedPara(s);
        setNClobInternal(i, reader);
    }

    public void setNClob(String s, Reader reader, long l)
        throws SQLException
    {
        int i = addNamedPara(s);
        setNClobInternal(i, reader, l);
    }

    public void setAsciiStream(String s, InputStream inputstream)
        throws SQLException
    {
        int i = addNamedPara(s);
        setAsciiStreamInternal(i, inputstream);
    }

    public void setAsciiStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        int j = addNamedPara(s);
        setAsciiStreamInternal(j, inputstream, i);
    }

    public void setAsciiStream(String s, InputStream inputstream, long l)
        throws SQLException
    {
        int i = addNamedPara(s);
        setAsciiStreamInternal(i, inputstream, l);
    }

    public void setBinaryStream(String s, InputStream inputstream)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBinaryStreamInternal(i, inputstream);
    }

    public void setBinaryStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        int j = addNamedPara(s);
        setBinaryStreamInternal(j, inputstream, i);
    }

    public void setBinaryStream(String s, InputStream inputstream, long l)
        throws SQLException
    {
        int i = addNamedPara(s);
        setBinaryStreamInternal(i, inputstream, l);
    }

    public void setCharacterStream(String s, Reader reader)
        throws SQLException
    {
        int i = addNamedPara(s);
        setCharacterStreamInternal(i, reader);
    }

    public void setCharacterStream(String s, Reader reader, int i)
        throws SQLException
    {
        int j = addNamedPara(s);
        setCharacterStreamInternal(j, reader, i);
    }

    public void setCharacterStream(String s, Reader reader, long l)
        throws SQLException
    {
        int i = addNamedPara(s);
        setCharacterStreamInternal(i, reader, l);
    }

    public void setNCharacterStream(String s, Reader reader)
        throws SQLException
    {
        int i = addNamedPara(s);
        setNCharacterStreamInternal(i, reader);
    }

    public void setNCharacterStream(String s, Reader reader, long l)
        throws SQLException
    {
        int i = addNamedPara(s);
        setNCharacterStreamInternal(i, reader, l);
    }

    public void setUnicodeStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        int j = addNamedPara(s);
        setUnicodeStreamInternal(j, inputstream, i);
    }

    public void setNull(String s, int i, String s1)
        throws SQLException
    {
        int j = addNamedPara(s);
        setNullInternal(j, i, s1);
    }

    public void setNull(String s, int i)
        throws SQLException
    {
        int j = addNamedPara(s);
        setNullInternal(j, i);
    }

    public void setStructDescriptor(String s, StructDescriptor structdescriptor)
        throws SQLException
    {
        int i = addNamedPara(s);
        setStructDescriptorInternal(i, structdescriptor);
    }

    public void setObject(String s, Object obj, int i, int j)
        throws SQLException
    {
        int k = addNamedPara(s);
        setObjectInternal(k, obj, i, j);
    }

    public void setPlsqlIndexTable(int i, Object obj, int j, int k, int l, int i1)
        throws SQLException
    {
        synchronized(connection)
        {
            atLeastOneOrdinalParameter = true;
            setPlsqlIndexTableInternal(i, obj, j, k, l, i1);
        }
    }

    int addNamedPara(String s)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        for(int i = 0; i < parameterCount; i++)
            if(s1 == namedParameters[i])
                return i + 1;

        if(parameterCount >= namedParameters.length)
        {
            String as[] = new String[namedParameters.length * 2];
            System.arraycopy(namedParameters, 0, as, 0, namedParameters.length);
            namedParameters = as;
        }
        namedParameters[parameterCount++] = s1;
        atLeastOneNamedParameter = true;
        return parameterCount;
    }

    public Reader getCharacterStream(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getCharacterStream(currentRank);
    }

    public InputStream getUnicodeStream(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getUnicodeStream(currentRank);
    }

    public InputStream getBinaryStream(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getBinaryStream(currentRank);
    }

    public RowId getRowId(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getROWID(currentRank);
    }

    public RowId getRowId(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getROWID(currentRank);
    }

    public NClob getNClob(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getNClob(currentRank);
    }

    public NClob getNClob(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getNClob(currentRank);
    }

    public SQLXML getSQLXML(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getSQLXML(currentRank);
    }

    public SQLXML getSQLXML(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getSQLXML(currentRank);
    }

    public String getNString(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getNString(currentRank);
    }

    public String getNString(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getNString(currentRank);
    }

    public Reader getNCharacterStream(int i)
        throws SQLException
    {
        if(closed)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(atLeastOneNamedParameter)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getNCharacterStream(currentRank);
    }

    public Reader getNCharacterStream(String s)
        throws SQLException
    {
        if(!atLeastOneNamedParameter)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s1 = s.toUpperCase().intern();
        int i;
        for(i = 0; i < parameterCount && s1 != namedParameters[i]; i++);
        i++;
        Accessor accessor = null;
        if(i <= 0 || i > numberOfBindPositions || outBindAccessors == null || (accessor = outBindAccessors[i - 1]) == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        lastIndex = i;
        if(streamList != null)
            closeUsedStreams(i);
        return accessor.getNCharacterStream(currentRank);
    }

}
