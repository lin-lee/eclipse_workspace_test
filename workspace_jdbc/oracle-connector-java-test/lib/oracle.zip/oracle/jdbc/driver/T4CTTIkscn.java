// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIkscn.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, T4CMAREngine, T4CConnection

class T4CTTIkscn extends T4CTTIMsg
{

    long kscnbas;
    int kscnwrp;

    T4CTTIkscn(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)0);
    }

    void unmarshal()
        throws SQLException, IOException
    {
        kscnbas = meg.unmarshalUB4();
        kscnwrp = meg.unmarshalUB2();
    }
}
