// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   DBConversion.java

package oracle.jdbc.driver;

import java.io.InputStream;
import java.io.Reader;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.util.RepConversion;
import oracle.sql.CharacterSet;
import oracle.sql.converter.CharacterSetMetaData;

// Referenced classes of package oracle.jdbc.driver:
//            OracleConversionInputStream, OracleConversionInputStreamInternal, OracleConversionReader, DatabaseError, 
//            OracleBufferedStream

public class DBConversion
{
    class UnicodeStream extends OracleBufferedStream
    {

        final DBConversion this$0;

        public boolean needBytes()
        {
            return !closed && pos < count;
        }

        public boolean needBytes(int i)
        {
            return !closed && pos < count;
        }

        UnicodeStream(char ac[], int i, int j)
        {
            this$0 = DBConversion.this;
            super(j);
            currentBufferSize = initialBufferSize;
            resizableBuffer = new byte[currentBufferSize];
            int k = i;
            for(int l = 0; l < j;)
            {
                char c = ac[k++];
                resizableBuffer[l++] = (byte)(c >> 8 & 0xff);
                resizableBuffer[l++] = (byte)(c & 0xff);
            }

            count = j;
        }
    }

    class AsciiStream extends OracleBufferedStream
    {

        final DBConversion this$0;

        public boolean needBytes()
        {
            return !closed && pos < count;
        }

        public boolean needBytes(int i)
        {
            return !closed && pos < count;
        }

        AsciiStream(char ac[], int i, int j)
        {
            this$0 = DBConversion.this;
            super(j);
            currentBufferSize = initialBufferSize;
            resizableBuffer = new byte[currentBufferSize];
            if(serverCharSetId == 1 || !isStrictASCIIConversion)
            {
                int k = i;
                for(int l = 0; l < j; l++)
                    resizableBuffer[l] = (byte)ac[k++];

            } else
            {
                if(asciiCharSet == null)
                    asciiCharSet = CharacterSet.make(1);
                resizableBuffer = asciiCharSet.convertWithReplacement(new String(ac, i, j));
            }
            count = j;
        }
    }


    public static final boolean DO_CONVERSION_WITH_REPLACEMENT = true;
    public static final short ORACLE8_PROD_VERSION = 8030;
    protected short serverNCharSetId;
    protected short serverCharSetId;
    protected short clientCharSetId;
    protected CharacterSet serverCharSet;
    protected CharacterSet serverNCharSet;
    protected CharacterSet clientCharSet;
    protected CharacterSet asciiCharSet;
    protected boolean isServerCharSetFixedWidth;
    protected boolean isServerNCharSetFixedWidth;
    protected int c2sNlsRatio;
    protected int s2cNlsRatio;
    protected int sMaxCharSize;
    protected int cMaxCharSize;
    protected int maxNCharSize;
    protected boolean isServerCSMultiByte;
    private boolean isStrictASCIIConversion;
    private boolean isQuickASCIIConversion;
    public static final short DBCS_CHARSET = -1;
    public static final short UCS2_CHARSET = -5;
    public static final short ASCII_CHARSET = 1;
    public static final short ISO_LATIN_1_CHARSET = 31;
    public static final short AL24UTFFSS_CHARSET = 870;
    public static final short UTF8_CHARSET = 871;
    public static final short AL32UTF8_CHARSET = 873;
    public static final short AL16UTF16_CHARSET = 2000;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public DBConversion(short word0, short word1, short word2, boolean flag, boolean flag1)
        throws SQLException
    {
        isStrictASCIIConversion = false;
        isQuickASCIIConversion = false;
        isStrictASCIIConversion = flag;
        isQuickASCIIConversion = flag1;
        if(word1 != -1)
            init(word0, word1, word2);
    }

    public DBConversion(short word0, short word1, short word2)
        throws SQLException
    {
        this(word0, word1, word2, false, false);
    }

    void init(short word0, short word1, short word2)
        throws SQLException
    {
        switch(word1)
        {
        default:
            unexpectedCharset(word1);
            // fall through

        case -5: 
        case 1: // '\001'
        case 2: // '\002'
        case 31: // '\037'
        case 178: 
        case 870: 
        case 871: 
        case 873: 
            serverCharSetId = word0;
            break;
        }
        clientCharSetId = word1;
        serverCharSet = CharacterSet.make(serverCharSetId);
        serverNCharSetId = word2;
        serverNCharSet = CharacterSet.make(serverNCharSetId);
        clientCharSet = CharacterSet.make(clientCharSetId);
        c2sNlsRatio = CharacterSetMetaData.getRatio(word0, word1);
        s2cNlsRatio = CharacterSetMetaData.getRatio(word1, word0);
        sMaxCharSize = CharacterSetMetaData.getRatio(word0, 1);
        cMaxCharSize = CharacterSetMetaData.getRatio(word1, 1);
        maxNCharSize = CharacterSetMetaData.getRatio(word2, 1);
        findFixedWidthInfo();
    }

    void findFixedWidthInfo()
        throws SQLException
    {
        isServerCharSetFixedWidth = CharacterSetMetaData.isFixedWidth(serverCharSetId);
        isServerNCharSetFixedWidth = CharacterSetMetaData.isFixedWidth(serverNCharSetId);
        isServerCSMultiByte = sMaxCharSize > 1;
    }

    public short getServerCharSetId()
    {
        return serverCharSetId;
    }

    public short getNCharSetId()
    {
        return serverNCharSetId;
    }

    public boolean IsNCharFixedWith()
    {
        return serverNCharSetId == 2000;
    }

    public short getClientCharSet()
    {
        if(clientCharSetId == -1)
            return serverCharSetId;
        else
            return clientCharSetId;
    }

    public CharacterSet getDbCharSetObj()
    {
        return serverCharSet;
    }

    public CharacterSet getDriverCharSetObj()
    {
        return clientCharSet;
    }

    public CharacterSet getDriverNCharSetObj()
    {
        return serverNCharSet;
    }

    public static final short findDriverCharSet(short word0, short word1)
    {
        short word2 = 0;
        switch(word0)
        {
        case 1: // '\001'
        case 2: // '\002'
        case 31: // '\037'
        case 178: 
        case 873: 
            word2 = word0;
            break;

        default:
            word2 = word1 < 8030 ? 870 : 871;
            break;
        }
        return word2;
    }

    public static final byte[] stringToDriverCharBytes(String s, short word0)
        throws SQLException
    {
        if(s == null)
            return null;
        byte abyte0[] = null;
        switch(word0)
        {
        case -5: 
        case 2000: 
            abyte0 = CharacterSet.stringToAL16UTF16Bytes(s);
            break;

        case 1: // '\001'
        case 2: // '\002'
            abyte0 = CharacterSet.stringToASCII(s);
            break;

        case 870: 
        case 871: 
            abyte0 = CharacterSet.stringToUTF(s);
            break;

        case 873: 
            abyte0 = CharacterSet.stringToAL32UTF8(s);
            break;

        case -1: 
        default:
            unexpectedCharset(word0);
            break;
        }
        return abyte0;
    }

    public byte[] StringToCharBytes(String s)
        throws SQLException
    {
        if(s.length() == 0)
            return null;
        switch(clientCharSetId)
        {
        case -1: 
            return serverCharSet.convertWithReplacement(s);

        case 2: // '\002'
        case 31: // '\037'
        case 178: 
            return clientCharSet.convertWithReplacement(s);

        case 1: // '\001'
            if(isQuickASCIIConversion)
            {
                byte abyte0[] = new byte[s.length()];
                CharacterSet.convertJavaCharsToASCIIBytes(s.toCharArray(), 0, abyte0, 0, s.length(), false);
                return abyte0;
            }
            break;
        }
        return stringToDriverCharBytes(s, clientCharSetId);
    }

    public String CharBytesToString(byte abyte0[], int i)
        throws SQLException
    {
        return CharBytesToString(abyte0, i, true);
    }

    public String CharBytesToString(byte abyte0[], int i, boolean flag)
        throws SQLException
    {
        String s = null;
        if(abyte0.length == 0)
            return s;
        switch(clientCharSetId)
        {
        case -5: 
            s = CharacterSet.AL16UTF16BytesToString(abyte0, i);
            break;

        case 1: // '\001'
            s = new String(abyte0, 0, 0, i);
            break;

        case 2: // '\002'
        case 31: // '\037'
        case 178: 
            if(flag)
                s = clientCharSet.toStringWithReplacement(abyte0, 0, i);
            else
                s = clientCharSet.toString(abyte0, 0, i);
            break;

        case 870: 
        case 871: 
            s = CharacterSet.UTFToString(abyte0, 0, i, flag);
            break;

        case 873: 
            s = CharacterSet.AL32UTF8ToString(abyte0, 0, i, flag);
            break;

        case -1: 
            s = serverCharSet.toStringWithReplacement(abyte0, 0, i);
            break;

        default:
            unexpectedCharset(clientCharSetId);
            break;
        }
        return s;
    }

    public String NCharBytesToString(byte abyte0[], int i)
        throws SQLException
    {
        String s = null;
        if(clientCharSetId == -1)
            s = serverNCharSet.toStringWithReplacement(abyte0, 0, i);
        else
            switch(serverNCharSetId)
            {
            case -5: 
            case 2000: 
                s = CharacterSet.AL16UTF16BytesToString(abyte0, i);
                break;

            case 1: // '\001'
            case 2: // '\002'
                s = new String(abyte0, 0, 0, i);
                break;

            case 31: // '\037'
            case 178: 
                s = serverNCharSet.toStringWithReplacement(abyte0, 0, i);
                break;

            case 870: 
            case 871: 
                s = CharacterSet.UTFToString(abyte0, 0, i);
                break;

            case 873: 
                s = CharacterSet.AL32UTF8ToString(abyte0, 0, i);
                break;

            case -1: 
                s = serverCharSet.toStringWithReplacement(abyte0, 0, i);
                break;

            default:
                unexpectedCharset(clientCharSetId);
                break;
            }
        return s;
    }

    public int javaCharsToCHARBytes(char ac[], int i, byte abyte0[])
        throws SQLException
    {
        return javaCharsToCHARBytes(ac, i, abyte0, clientCharSetId);
    }

    public int javaCharsToCHARBytes(char ac[], int i, byte abyte0[], int j, int k)
        throws SQLException
    {
        return javaCharsToCHARBytes(ac, i, abyte0, j, clientCharSetId, k);
    }

    public int javaCharsToNCHARBytes(char ac[], int i, byte abyte0[])
        throws SQLException
    {
        return javaCharsToCHARBytes(ac, i, abyte0, serverNCharSetId);
    }

    public int javaCharsToNCHARBytes(char ac[], int i, byte abyte0[], int j, int k)
        throws SQLException
    {
        return javaCharsToCHARBytes(ac, i, abyte0, j, serverNCharSetId, k);
    }

    protected int javaCharsToCHARBytes(char ac[], int i, byte abyte0[], short word0)
        throws SQLException
    {
        return javaCharsToCHARBytes(ac, 0, abyte0, 0, word0, i);
    }

    protected int javaCharsToCHARBytes(char ac[], int i, byte abyte0[], int j, short word0, int k)
        throws SQLException
    {
        int l = 0;
        switch(word0)
        {
        case -5: 
        case 2000: 
            l = CharacterSet.convertJavaCharsToAL16UTF16Bytes(ac, i, abyte0, j, k);
            break;

        case 2: // '\002'
        case 178: 
            byte abyte1[] = clientCharSet.convertWithReplacement(new String(ac, i, k));
            System.arraycopy(abyte1, 0, abyte0, 0, abyte1.length);
            l = abyte1.length;
            break;

        case 1: // '\001'
            l = CharacterSet.convertJavaCharsToASCIIBytes(ac, i, abyte0, j, k, isStrictASCIIConversion);
            break;

        case 31: // '\037'
            l = CharacterSet.convertJavaCharsToISOLATIN1Bytes(ac, i, abyte0, j, k);
            break;

        case 870: 
        case 871: 
            l = CharacterSet.convertJavaCharsToUTFBytes(ac, i, abyte0, j, k);
            break;

        case 873: 
            l = CharacterSet.convertJavaCharsToAL32UTF8Bytes(ac, i, abyte0, j, k);
            break;

        case -1: 
            l = javaCharsToDbCsBytes(ac, i, abyte0, j, k);
            break;

        default:
            unexpectedCharset(clientCharSetId);
            break;
        }
        return l;
    }

    public int CHARBytesToJavaChars(byte abyte0[], int i, char ac[], int j, int ai[], int k)
        throws SQLException
    {
        return _CHARBytesToJavaChars(abyte0, i, ac, j, clientCharSetId, ai, k, serverCharSet, serverNCharSet, clientCharSet, false);
    }

    public int NCHARBytesToJavaChars(byte abyte0[], int i, char ac[], int j, int ai[], int k)
        throws SQLException
    {
        return _CHARBytesToJavaChars(abyte0, i, ac, j, serverNCharSetId, ai, k, serverCharSet, serverNCharSet, clientCharSet, true);
    }

    static final int _CHARBytesToJavaChars(byte abyte0[], int i, char ac[], int j, short word0, int ai[], int k, CharacterSet characterset, 
            CharacterSet characterset1, CharacterSet characterset2, boolean flag)
        throws SQLException
    {
        int l = 0;
        boolean flag1 = false;
        switch(word0)
        {
        case -5: 
        case 2000: 
            int i1 = ai[0] - ai[0] % 2;
            if(k > ac.length - j)
                k = ac.length - j;
            if(k * 2 < i1)
                i1 = k * 2;
            l = CharacterSet.convertAL16UTF16BytesToJavaChars(abyte0, i, ac, j, i1, true);
            ai[0] = ai[0] - i1;
            break;

        case 1: // '\001'
            int j1 = ai[0];
            if(k > ac.length - j)
                k = ac.length - j;
            if(k < j1)
                j1 = k;
            l = CharacterSet.convertASCIIBytesToJavaChars(abyte0, i, ac, j, j1);
            ai[0] = ai[0] - j1;
            break;

        case 31: // '\037'
        case 178: 
            int k1 = ai[0];
            l = characterset.toCharWithReplacement(abyte0, 0, ac, j, k1);
            ai[0] -= l;
            break;

        case 870: 
        case 871: 
            if(k > ac.length - j)
                k = ac.length - j;
            l = CharacterSet.convertUTFBytesToJavaChars(abyte0, i, ac, j, ai, true, k);
            break;

        case 873: 
            if(k > ac.length - j)
                k = ac.length - j;
            l = CharacterSet.convertAL32UTF8BytesToJavaChars(abyte0, i, ac, j, ai, true, k);
            break;

        case -1: 
            unexpectedCharset((short)-1);
            break;

        default:
            CharacterSet characterset3 = characterset2;
            if(flag)
                characterset3 = characterset1;
            String s = characterset3.toStringWithReplacement(abyte0, i, ai[0]);
            char ac1[] = s.toCharArray();
            int l1 = ac1.length;
            if(l1 > k)
                l1 = k;
            l = l1;
            ai[0] = ai[0] - l1;
            System.arraycopy(ac1, 0, ac, j, l1);
            break;
        }
        return l;
    }

    public byte[] asciiBytesToCHARBytes(byte abyte0[])
    {
        byte abyte1[] = null;
        switch(clientCharSetId)
        {
        case -5: 
            abyte1 = new byte[abyte0.length * 2];
            int i = 0;
            int j = 0;
            for(; i < abyte0.length; i++)
            {
                abyte1[j++] = 0;
                abyte1[j++] = abyte0[i];
            }

            break;

        case -1: 
            if(asciiCharSet == null)
                asciiCharSet = CharacterSet.make(1);
            try
            {
                abyte1 = serverCharSet.convert(asciiCharSet, abyte0, 0, abyte0.length);
            }
            catch(SQLException sqlexception) { }
            break;

        default:
            abyte1 = abyte0;
            break;
        }
        return abyte1;
    }

    public int javaCharsToDbCsBytes(char ac[], int i, byte abyte0[])
        throws SQLException
    {
        int j = javaCharsToDbCsBytes(ac, 0, abyte0, 0, i);
        return j;
    }

    public int javaCharsToDbCsBytes(char ac[], int i, byte abyte0[], int j, int k)
        throws SQLException
    {
        int l = 0;
        catchCharsLen(ac, i, k);
        String s = new String(ac, i, k);
        byte abyte1[] = serverCharSet.convertWithReplacement(s);
        s = null;
        if(abyte1 != null)
        {
            l = abyte1.length;
            catchBytesLen(abyte0, j, l);
            System.arraycopy(abyte1, 0, abyte0, j, l);
            abyte1 = null;
        }
        return l;
    }

    public static final int javaCharsToUcs2Bytes(char ac[], int i, byte abyte0[])
        throws SQLException
    {
        int j = javaCharsToUcs2Bytes(ac, 0, abyte0, 0, i);
        return j;
    }

    public static final int javaCharsToUcs2Bytes(char ac[], int i, byte abyte0[], int j, int k)
        throws SQLException
    {
        catchCharsLen(ac, i, k);
        catchBytesLen(abyte0, j, k * 2);
        int j1 = k + i;
        int l = i;
        int i1 = j;
        for(; l < j1; l++)
        {
            abyte0[i1++] = (byte)(ac[l] >> 8 & 0xff);
            abyte0[i1++] = (byte)(ac[l] & 0xff);
        }

        return i1 - j;
    }

    public static final int ucs2BytesToJavaChars(byte abyte0[], int i, char ac[])
        throws SQLException
    {
        return CharacterSet.AL16UTF16BytesToJavaChars(abyte0, i, ac);
    }

    public static final byte[] stringToAsciiBytes(String s)
    {
        return CharacterSet.stringToASCII(s);
    }

    public static final int asciiBytesToJavaChars(byte abyte0[], int i, char ac[])
        throws SQLException
    {
        return CharacterSet.convertASCIIBytesToJavaChars(abyte0, 0, ac, 0, i);
    }

    public static final int javaCharsToAsciiBytes(char ac[], int i, byte abyte0[])
        throws SQLException
    {
        return CharacterSet.convertJavaCharsToASCIIBytes(ac, 0, abyte0, 0, i);
    }

    public static final boolean isCharSetMultibyte(short word0)
    {
        switch(word0)
        {
        case 1: // '\001'
        case 31: // '\037'
            return false;

        case -5: 
        case -1: 
        case 870: 
        case 871: 
        case 873: 
            return true;
        }
        return false;
    }

    public int getMaxCharbyteSize()
    {
        return _getMaxCharbyteSize(clientCharSetId);
    }

    public int getMaxNCharbyteSize()
    {
        return _getMaxCharbyteSize(serverNCharSetId);
    }

    public int _getMaxCharbyteSize(short word0)
    {
        switch(word0)
        {
        case 1: // '\001'
            return 1;

        case 31: // '\037'
            return 1;

        case 870: 
        case 871: 
            return 3;

        case -5: 
        case 2000: 
            return 2;

        case -1: 
            return 4;

        case 873: 
            return 4;
        }
        return 1;
    }

    public boolean isUcs2CharSet()
    {
        return clientCharSetId == -5;
    }

    public static final int RAWBytesToHexChars(byte abyte0[], int i, char ac[])
    {
        int j = 0;
        int k = 0;
        for(; j < i; j++)
        {
            ac[k++] = (char)RepConversion.nibbleToHex((byte)(abyte0[j] >> 4 & 0xf));
            ac[k++] = (char)RepConversion.nibbleToHex((byte)(abyte0[j] & 0xf));
        }

        return k;
    }

    public final int hexDigit2Nibble(char c)
        throws SQLException
    {
        int i = Character.digit(c, 16);
        if(i == -1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, (new StringBuilder()).append("Invalid hex digit: ").append(c).toString());
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return i;
        }
    }

    public final byte[] hexString2Bytes(String s)
        throws SQLException
    {
        int i = s.length();
        char ac[] = new char[i];
        s.getChars(0, i, ac, 0);
        return hexChars2Bytes(ac, 0, i);
    }

    public final byte[] hexChars2Bytes(char ac[], int i, int j)
        throws SQLException
    {
        int k = 0;
        int l = i;
        if(j == 0)
            return new byte[0];
        byte abyte0[];
        if(j % 2 > 0)
        {
            abyte0 = new byte[(j + 1) / 2];
            abyte0[k++] = (byte)hexDigit2Nibble(ac[l++]);
        } else
        {
            abyte0 = new byte[j / 2];
        }
        for(; k < abyte0.length; k++)
            abyte0[k] = (byte)(hexDigit2Nibble(ac[l++]) << 4 | hexDigit2Nibble(ac[l++]));

        return abyte0;
    }

    public InputStream ConvertStream(InputStream inputstream, int i)
    {
        return new OracleConversionInputStream(this, inputstream, i);
    }

    public InputStream ConvertStream(InputStream inputstream, int i, int j)
    {
        return new OracleConversionInputStream(this, inputstream, i, j);
    }

    public InputStream ConvertStreamInternal(InputStream inputstream, int i, int j)
    {
        return new OracleConversionInputStreamInternal(this, inputstream, i, j);
    }

    public InputStream ConvertStream(Reader reader, int i, int j, short word0)
    {
        OracleConversionInputStream oracleconversioninputstream = new OracleConversionInputStream(this, reader, i, j, word0);
        return oracleconversioninputstream;
    }

    public InputStream ConvertStreamInternal(Reader reader, int i, int j, short word0)
    {
        OracleConversionInputStreamInternal oracleconversioninputstreaminternal = new OracleConversionInputStreamInternal(this, reader, i, j, word0);
        return oracleconversioninputstreaminternal;
    }

    public Reader ConvertCharacterStream(InputStream inputstream, int i)
        throws SQLException
    {
        return new OracleConversionReader(this, inputstream, i);
    }

    public Reader ConvertCharacterStream(InputStream inputstream, int i, short word0)
        throws SQLException
    {
        OracleConversionReader oracleconversionreader = new OracleConversionReader(this, inputstream, i);
        oracleconversionreader.setFormOfUse(word0);
        return oracleconversionreader;
    }

    public InputStream CharsToStream(char ac[], int i, int j, int k)
        throws SQLException
    {
        if(k == 10)
            return new AsciiStream(ac, i, j);
        if(k == 11)
        {
            return new UnicodeStream(ac, i, j);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 39, "unknownConversion");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    static final void unexpectedCharset(short word0)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(null, 35, "DBConversion");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    protected static final void catchBytesLen(byte abyte0[], int i, int j)
        throws SQLException
    {
        if(i + j > abyte0.length)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, 39, "catchBytesLen");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    protected static final void catchCharsLen(char ac[], int i, int j)
        throws SQLException
    {
        if(i + j > ac.length)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, 39, "catchCharsLen");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public static final int getUtfLen(char c)
    {
        byte byte0 = 0;
        if((c & 0xff80) == 0)
            byte0 = 1;
        else
        if((c & 0xf800) == 0)
            byte0 = 2;
        else
            byte0 = 3;
        return byte0;
    }

    int encodedByteLength(String s, boolean flag)
    {
        int i = 0;
        if(s != null)
        {
            i = s.length();
            if(i != 0)
                if(flag)
                    i = isServerNCharSetFixedWidth ? i * maxNCharSize : serverNCharSet.encodedByteLength(s);
                else
                    i = isServerCharSetFixedWidth ? i * sMaxCharSize : serverCharSet.encodedByteLength(s);
        }
        return i;
    }

    int encodedByteLength(char ac[], boolean flag)
    {
        int i = 0;
        if(ac != null)
        {
            i = ac.length;
            if(i != 0)
                if(flag)
                    i = isServerNCharSetFixedWidth ? i * maxNCharSize : serverNCharSet.encodedByteLength(ac);
                else
                    i = isServerCharSetFixedWidth ? i * sMaxCharSize : serverCharSet.encodedByteLength(ac);
        }
        return i;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }


}
