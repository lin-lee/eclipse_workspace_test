// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C8TTIClob.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            T4C8TTILob, T4CConnection, T4CMAREngine, DBConversion, 
//            DatabaseError

final class T4C8TTIClob extends T4C8TTILob
{

    int nBytes[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C8TTIClob(T4CConnection t4cconnection)
    {
        super(t4cconnection);
        nBytes = new int[1];
    }

    long read(byte abyte0[], long l, long l1, boolean flag, char ac[], 
            int i)
        throws SQLException, IOException
    {
        boolean flag1;
        byte abyte1[];
        long l2 = 0L;
        long l3 = l1;
        flag1 = false;
        abyte1 = null;
        long l4;
        initializeLobdef();
        if((abyte0[6] & 0x80) == 128)
            flag1 = true;
        int j = 0;
        if(flag1)
            j = (int)l1 * 2;
        else
            j = (int)l1 * 3;
        abyte1 = connection.getByteBuffer(j);
        if((abyte0[7] & 0x40) > 0)
            littleEndianClob = true;
        lobops = 2L;
        sourceLobLocator = abyte0;
        sourceOffset = l;
        lobamt = l1;
        sendLobamt = true;
        outBuffer = abyte1;
        doRPC();
        l4 = lobamt;
        long l5 = 0L;
        if(flag1)
        {
            if(connection.versionNumber < 10101)
            {
                meg.conv;
                DBConversion.ucs2BytesToJavaChars(outBuffer, (int)lobBytesRead, ac);
            } else
            if(littleEndianClob)
                CharacterSet.convertAL16UTF16LEBytesToJavaChars(outBuffer, 0, ac, i, (int)lobBytesRead, true);
            else
                CharacterSet.convertAL16UTF16BytesToJavaChars(outBuffer, 0, ac, i, (int)lobBytesRead, true);
        } else
        if(!flag)
        {
            nBytes[0] = (int)lobBytesRead;
            meg.conv.CHARBytesToJavaChars(outBuffer, 0, ac, i, nBytes, ac.length);
        } else
        {
            nBytes[0] = (int)lobBytesRead;
            meg.conv.NCHARBytesToJavaChars(outBuffer, 0, ac, i, nBytes, ac.length);
        }
        outBuffer = null;
        connection.cacheBuffer(abyte1);
        break MISSING_BLOCK_LABEL_349;
        Exception exception;
        exception;
        outBuffer = null;
        connection.cacheBuffer(abyte1);
        throw exception;
        return l4;
    }

    long write(byte abyte0[], long l, boolean flag, char ac[], long l1, 
            long l2)
        throws SQLException, IOException
    {
        boolean flag1 = false;
        if((abyte0[6] & 0x80) == 128)
            flag1 = true;
        if((abyte0[7] & 0x40) == 64)
            littleEndianClob = true;
        long l3 = 0L;
        byte abyte1[] = null;
        if(flag1)
        {
            abyte1 = new byte[(int)l2 * 2];
            if(connection.versionNumber < 10101)
            {
                DBConversion _tmp = meg.conv;
                DBConversion.javaCharsToUcs2Bytes(ac, (int)l1, abyte1, 0, (int)l2);
            } else
            if(littleEndianClob)
                CharacterSet.convertJavaCharsToAL16UTF16LEBytes(ac, (int)l1, abyte1, 0, (int)l2);
            else
                CharacterSet.convertJavaCharsToAL16UTF16Bytes(ac, (int)l1, abyte1, 0, (int)l2);
        } else
        {
            abyte1 = new byte[(int)l2 * 3];
            if(!flag)
                l3 = meg.conv.javaCharsToCHARBytes(ac, (int)l1, abyte1, 0, (int)l2);
            else
                l3 = meg.conv.javaCharsToNCHARBytes(ac, (int)l1, abyte1, 0, (int)l2);
        }
        initializeLobdef();
        lobops = 64L;
        sourceLobLocator = abyte0;
        sourceOffset = l;
        lobamt = l2;
        sendLobamt = true;
        inBuffer = abyte1;
        inBufferOffset = 0L;
        if(flag1)
        {
            if(connection.versionNumber < 10101)
                inBufferNumBytes = l2;
            else
                inBufferNumBytes = l2 * 2L;
        } else
        {
            inBufferNumBytes = l3;
        }
        doRPC();
        long l4 = lobamt;
        return l4;
    }

    Datum createTemporaryLob(Connection connection, boolean flag, int i)
        throws SQLException, IOException
    {
        return createTemporaryLob(connection, flag, i, (short)1);
    }

    Datum createTemporaryLob(Connection connection, boolean flag, int i, short word0)
        throws SQLException, IOException
    {
        if(i == 12)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 158);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        Object obj = null;
        initializeLobdef();
        lobops = 272L;
        sourceLobLocator = new byte[40];
        sourceLobLocator[1] = 84;
        if(word0 == 1)
            sourceOffset = 1L;
        else
            sourceOffset = 2L;
        destinationOffset = 112L;
        destinationLength = i;
        lobamt = i;
        sendLobamt = true;
        nullO2U = true;
        characterSet = word0 != 2 ? meg.conv.getServerCharSetId() : meg.conv.getNCharSetId();
        if(this.connection.versionNumber >= 9000)
        {
            lobscn = new int[1];
            lobscn[0] = flag ? 1 : 0;
            lobscnl = 1;
        }
        doRPC();
        if(sourceLobLocator != null)
            if(word0 == 1)
                obj = new CLOB((OracleConnection)connection, sourceLobLocator);
            else
                obj = new NCLOB((OracleConnection)connection, sourceLobLocator);
        return ((Datum) (obj));
    }

    boolean open(byte abyte0[], int i)
        throws SQLException, IOException
    {
        boolean flag = false;
        byte byte0 = 2;
        if(i == 0)
            byte0 = 1;
        flag = _open(abyte0, byte0, 32768);
        return flag;
    }

    boolean close(byte abyte0[])
        throws SQLException, IOException
    {
        boolean flag = false;
        flag = _close(abyte0, 0x10000);
        return flag;
    }

    boolean isOpen(byte abyte0[])
        throws SQLException, IOException
    {
        boolean flag = false;
        flag = _isOpen(abyte0, 0x11000);
        return flag;
    }

}
