// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleLog.java

package oracle.jdbc.driver;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.logging.Level;

public class OracleLog
{
    private static class OracleLevel extends Level
    {

        static final OracleLevel INTERNAL_ERROR = new OracleLevel("INTERNAL_ERROR", 1100);
        static final OracleLevel TRACE_1;
        static final OracleLevel TRACE_10 = new OracleLevel("TRACE_10", 446);
        static final OracleLevel TRACE_16;
        static final OracleLevel TRACE_20 = new OracleLevel("TRACE_20", 376);
        static final OracleLevel TRACE_30 = new OracleLevel("TRACE_30", 316);
        static final OracleLevel TRACE_32;

        static 
        {
            TRACE_1 = new OracleLevel("TRACE_1", Level.FINE.intValue());
            TRACE_16 = new OracleLevel("TRACE_16", Level.FINER.intValue());
            TRACE_32 = new OracleLevel("TRACE_32", Level.FINEST.intValue());
        }

        OracleLevel(String s, int i)
        {
            super(s, i);
        }
    }


    private static final int maxPrintBytes = 512;
    public static final boolean TRACE = false;
    public static final Level INTERNAL_ERROR;
    public static final Level TRACE_1;
    public static final Level TRACE_10;
    public static final Level TRACE_16;
    public static final Level TRACE_20;
    public static final Level TRACE_30;
    public static final Level TRACE_32;
    static boolean securityExceptionWhileGettingSystemProperties;

    public OracleLog()
    {
    }

    public static boolean isDebugZip()
    {
        boolean flag = true;
        flag = false;
        return flag;
    }

    public static boolean isPrivateLogAvailable()
    {
        boolean flag = false;
        return flag;
    }

    public static boolean isEnabled()
    {
        return false;
    }

    public static boolean registerClassNameAndGetCurrentTraceSetting(Class class1)
    {
        return false;
    }

    public static void setTrace(boolean flag)
    {
    }

    private static void initialize()
    {
        setupFromSystemProperties();
    }

    public static void setupFromSystemProperties()
    {
        boolean flag = false;
        securityExceptionWhileGettingSystemProperties = false;
        try
        {
            String s = null;
            s = getSystemProperty("oracle.jdbc.Trace", null);
            if(s != null && s.compareTo("true") == 0)
                flag = true;
        }
        catch(SecurityException securityexception)
        {
            securityExceptionWhileGettingSystemProperties = true;
        }
        setTrace(flag);
    }

    private static String getSystemProperty(String s)
    {
        return getSystemProperty(s, null);
    }

    private static String getSystemProperty(String s, String s1)
    {
        if(s != null)
        {
            String s2 = s;
            String s3 = s1;
            String as[] = {
                s1
            };
            AccessController.doPrivileged(new PrivilegedAction(as, s2, s3) {

                final String val$retStr[];
                final String val$fstr;
                final String val$fdefaultValue;

                public Object run()
                {
                    retStr[0] = System.getProperty(fstr, fdefaultValue);
                    return null;
                }

            
            {
                retStr = as;
                fstr = s;
                fdefaultValue = s1;
                super();
            }
            }
);
            return as[0];
        } else
        {
            return s1;
        }
    }

    public static String argument()
    {
        return "";
    }

    public static String argument(boolean flag)
    {
        return Boolean.toString(flag);
    }

    public static String argument(byte byte0)
    {
        return Byte.toString(byte0);
    }

    public static String argument(short word0)
    {
        return Short.toString(word0);
    }

    public static String argument(int i)
    {
        return Integer.toString(i);
    }

    public static String argument(long l)
    {
        return Long.toString(l);
    }

    public static String argument(float f)
    {
        return Float.toString(f);
    }

    public static String argument(double d)
    {
        return Double.toString(d);
    }

    public static String argument(Object obj)
    {
        if(obj == null)
            return "null";
        if(obj instanceof String)
            return (new StringBuilder()).append("\"").append((String)obj).append("\"").toString();
        else
            return obj.toString();
    }

    /**
     * @deprecated Method byteToHexString is deprecated
     */

    public static String byteToHexString(byte byte0)
    {
        StringBuffer stringbuffer = new StringBuffer("");
        int i = 0xff & byte0;
        if(i <= 15)
            stringbuffer.append("0x0");
        else
            stringbuffer.append("0x");
        stringbuffer.append(Integer.toHexString(i));
        return stringbuffer.toString();
    }

    /**
     * @deprecated Method bytesToPrintableForm is deprecated
     */

    public static String bytesToPrintableForm(String s, byte abyte0[])
    {
        int i = abyte0 != null ? abyte0.length : 0;
        return bytesToPrintableForm(s, abyte0, i);
    }

    /**
     * @deprecated Method bytesToPrintableForm is deprecated
     */

    public static String bytesToPrintableForm(String s, byte abyte0[], int i)
    {
        String s1 = null;
        if(abyte0 == null)
            s1 = (new StringBuilder()).append(s).append(": null").toString();
        else
            s1 = (new StringBuilder()).append(s).append(" (").append(abyte0.length).append(" bytes):\n").append(bytesToFormattedStr(abyte0, i, "  ")).toString();
        return s1;
    }

    /**
     * @deprecated Method bytesToFormattedStr is deprecated
     */

    public static String bytesToFormattedStr(byte abyte0[], int i, String s)
    {
        StringBuffer stringbuffer = new StringBuffer("");
        if(s == null)
            s = new String("");
        stringbuffer.append(s);
        if(abyte0 == null)
        {
            stringbuffer.append("byte [] is null");
            return stringbuffer.toString();
        }
        for(int j = 0; j < i; j++)
        {
            if(j >= 512)
            {
                stringbuffer.append((new StringBuilder()).append("\n").append(s).append("... last ").append(i - 512).append(" bytes were not printed to limit the output size").toString());
                break;
            }
            if(j > 0 && j % 20 == 0)
                stringbuffer.append((new StringBuilder()).append("\n").append(s).toString());
            if(j % 20 == 10)
                stringbuffer.append(" ");
            int k = 0xff & abyte0[j];
            if(k <= 15)
                stringbuffer.append("0");
            stringbuffer.append((new StringBuilder()).append(Integer.toHexString(k)).append(" ").toString());
        }

        return stringbuffer.toString();
    }

    /**
     * @deprecated Method strToUcs2Bytes is deprecated
     */

    public static byte[] strToUcs2Bytes(String s)
    {
        if(s == null)
            return null;
        else
            return charsToUcs2Bytes(s.toCharArray());
    }

    /**
     * @deprecated Method charsToUcs2Bytes is deprecated
     */

    public static byte[] charsToUcs2Bytes(char ac[])
    {
        if(ac == null)
            return null;
        else
            return charsToUcs2Bytes(ac, ac.length);
    }

    /**
     * @deprecated Method charsToUcs2Bytes is deprecated
     */

    public static byte[] charsToUcs2Bytes(char ac[], int i)
    {
        if(ac == null)
            return null;
        if(i < 0)
            return null;
        else
            return charsToUcs2Bytes(ac, i, 0);
    }

    /**
     * @deprecated Method charsToUcs2Bytes is deprecated
     */

    public static byte[] charsToUcs2Bytes(char ac[], int i, int j)
    {
        if(ac == null)
            return null;
        if(i > ac.length - j)
            i = ac.length - j;
        if(i < 0)
            return null;
        byte abyte0[] = new byte[2 * i];
        int l = j;
        int k = 0;
        for(; l < i; l++)
        {
            abyte0[k++] = (byte)(ac[l] >> 8 & 0xff);
            abyte0[k++] = (byte)(ac[l] & 0xff);
        }

        return abyte0;
    }

    /**
     * @deprecated Method toPrintableStr is deprecated
     */

    public static String toPrintableStr(String s, int i)
    {
        if(s == null)
            return "null";
        if(s.length() > i)
            return (new StringBuilder()).append(s.substring(0, i - 1)).append("\n ... the actual length was ").append(s.length()).toString();
        else
            return s;
    }

    public static String toHex(long l, int i)
    {
        String s;
        switch(i)
        {
        case 1: // '\001'
            s = (new StringBuilder()).append("00").append(Long.toString(l & 255L, 16)).toString();
            break;

        case 2: // '\002'
            s = (new StringBuilder()).append("0000").append(Long.toString(l & 65535L, 16)).toString();
            break;

        case 3: // '\003'
            s = (new StringBuilder()).append("000000").append(Long.toString(l & 0xffffffL, 16)).toString();
            break;

        case 4: // '\004'
            s = (new StringBuilder()).append("00000000").append(Long.toString(l & 0xffffffffL, 16)).toString();
            break;

        case 5: // '\005'
            s = (new StringBuilder()).append("0000000000").append(Long.toString(l & 0xffffffffffL, 16)).toString();
            break;

        case 6: // '\006'
            s = (new StringBuilder()).append("000000000000").append(Long.toString(l & 0xffffffffffffL, 16)).toString();
            break;

        case 7: // '\007'
            s = (new StringBuilder()).append("00000000000000").append(Long.toString(l & 0xffffffffffffffL, 16)).toString();
            break;

        case 8: // '\b'
            return (new StringBuilder()).append(toHex(l >> 32, 4)).append(toHex(l, 4).substring(2)).toString();

        default:
            return "more than 8 bytes";
        }
        return (new StringBuilder()).append("0x").append(s.substring(s.length() - 2 * i)).toString();
    }

    public static String toHex(byte byte0)
    {
        String s = (new StringBuilder()).append("00").append(Integer.toHexString(byte0 & 0xff)).toString();
        return (new StringBuilder()).append("0x").append(s.substring(s.length() - 2)).toString();
    }

    public static String toHex(short word0)
    {
        return toHex(word0, 2);
    }

    public static String toHex(int i)
    {
        return toHex(i, 4);
    }

    public static String toHex(byte abyte0[], int i)
    {
        if(abyte0 == null)
            return "null";
        if(i > abyte0.length)
            return "byte array not long enough";
        String s = "[";
        int j = Math.min(64, i);
        for(int k = 0; k < j; k++)
            s = (new StringBuilder()).append(s).append(toHex(abyte0[k])).append(" ").toString();

        if(j < i)
            s = (new StringBuilder()).append(s).append("...").toString();
        return (new StringBuilder()).append(s).append("]").toString();
    }

    public static String toHex(byte abyte0[])
    {
        if(abyte0 == null)
            return "null";
        else
            return toHex(abyte0, abyte0.length);
    }

    static 
    {
        INTERNAL_ERROR = OracleLevel.INTERNAL_ERROR;
        TRACE_1 = OracleLevel.TRACE_1;
        TRACE_10 = OracleLevel.TRACE_10;
        TRACE_16 = OracleLevel.TRACE_16;
        TRACE_20 = OracleLevel.TRACE_20;
        TRACE_30 = OracleLevel.TRACE_30;
        TRACE_32 = OracleLevel.TRACE_32;
        initialize();
    }
}
