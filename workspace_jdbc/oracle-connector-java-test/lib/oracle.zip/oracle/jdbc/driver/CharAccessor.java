// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   CharAccessor.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;

// Referenced classes of package oracle.jdbc.driver:
//            CharCommonAccessor, OracleStatement

class CharAccessor extends CharCommonAccessor
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    CharAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        int k = 2000;
        if(i > k)
            k = i;
        if(oraclestatement.sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.PLSQL_BLOCK)
            k = 32766;
        init(oraclestatement, 96, 9, i, word0, j, flag, k, 255);
    }

    CharAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        int k1 = 2000;
        if(i > k1)
            k1 = i;
        if(oraclestatement.sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.PLSQL_BLOCK)
            k1 = 32766;
        init(oraclestatement, 96, 9, i, flag, j, k, l, i1, j1, word0, k1, 255);
    }

}
