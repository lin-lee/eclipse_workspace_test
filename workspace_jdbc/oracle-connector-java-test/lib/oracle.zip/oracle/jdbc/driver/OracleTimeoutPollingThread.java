// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTimeoutPollingThread.java

package oracle.jdbc.driver;


// Referenced classes of package oracle.jdbc.driver:
//            OracleTimeoutThreadPerVM, PhysicalConnection

class OracleTimeoutPollingThread extends Thread
{

    protected static final String threadName = "OracleTimeoutPollingThread";
    public static final String pollIntervalProperty = "oracle.jdbc.TimeoutPollInterval";
    public static final String pollIntervalDefault = "1000";
    private OracleTimeoutThreadPerVM knownTimeouts[];
    private int count;
    private long sleepMillis;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleTimeoutPollingThread()
    {
        super("OracleTimeoutPollingThread");
        setDaemon(true);
        setPriority(10);
        knownTimeouts = new OracleTimeoutThreadPerVM[2];
        count = 0;
        sleepMillis = Long.parseLong(PhysicalConnection.getSystemPropertyPollInterval());
        start();
    }

    public synchronized void addTimeout(OracleTimeoutThreadPerVM oracletimeoutthreadpervm)
    {
        int i = 0;
        if(count >= knownTimeouts.length)
        {
            OracleTimeoutThreadPerVM aoracletimeoutthreadpervm[] = new OracleTimeoutThreadPerVM[knownTimeouts.length * 4];
            System.arraycopy(knownTimeouts, 0, aoracletimeoutthreadpervm, 0, knownTimeouts.length);
            i = knownTimeouts.length;
            knownTimeouts = aoracletimeoutthreadpervm;
        }
        do
        {
            if(i >= knownTimeouts.length)
                break;
            if(knownTimeouts[i] == null)
            {
                knownTimeouts[i] = oracletimeoutthreadpervm;
                count++;
                break;
            }
            i++;
        } while(true);
    }

    public synchronized void removeTimeout(OracleTimeoutThreadPerVM oracletimeoutthreadpervm)
    {
        int i = 0;
        do
        {
            if(i >= knownTimeouts.length)
                break;
            if(knownTimeouts[i] == oracletimeoutthreadpervm)
            {
                knownTimeouts[i] = null;
                count--;
                break;
            }
            i++;
        } while(true);
    }

    public void run()
    {
        do
        {
            try
            {
                Thread.sleep(sleepMillis);
            }
            catch(InterruptedException interruptedexception) { }
            pollOnce();
        } while(true);
    }

    private void pollOnce()
    {
        if(count > 0)
        {
            long l = System.currentTimeMillis();
            for(int i = 0; i < knownTimeouts.length; i++)
                try
                {
                    if(knownTimeouts[i] != null)
                        knownTimeouts[i].interruptIfAppropriate(l);
                }
                catch(NullPointerException nullpointerexception) { }

        }
    }

}
