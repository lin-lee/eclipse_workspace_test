// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIoses.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CMAREngine, T4CConnection

final class T4CTTIoses extends T4CTTIfun
{

    static final int OSESSWS = 1;
    static final int OSESDET = 3;
    private int sididx;
    private int sidser;
    private int sidopc;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIoses(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)17);
        setFunCode((short)107);
    }

    void doO80SES(int i, int j, int k)
        throws IOException, SQLException
    {
        sididx = i;
        sidser = j;
        sidopc = k;
        if(sidopc != 1 && sidopc != 3)
        {
            throw new SQLException("Wrong operation : can only do switch or detach");
        } else
        {
            doPigRPC();
            return;
        }
    }

    void marshal()
        throws IOException
    {
        meg.marshalUB4(sididx);
        meg.marshalUB4(sidser);
        meg.marshalUB4(sidopc);
    }

}
