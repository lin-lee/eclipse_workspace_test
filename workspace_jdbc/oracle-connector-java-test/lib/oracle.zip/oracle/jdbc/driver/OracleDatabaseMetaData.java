// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDatabaseMetaData.java

package oracle.jdbc.driver;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.OracleResultSet;

// Referenced classes of package oracle.jdbc.driver:
//            PhysicalConnection, OracleConnection

class OracleDatabaseMetaData extends oracle.jdbc.OracleDatabaseMetaData
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleDatabaseMetaData(OracleConnection oracleconnection)
    {
        super(oracleconnection);
    }

    public OracleDatabaseMetaData(oracle.jdbc.driver.OracleConnection oracleconnection)
    {
        this(((OracleConnection) (oracleconnection)));
    }

    public synchronized ResultSet getColumns(String s, String s1, String s2, String s3)
        throws SQLException
    {
        boolean flag = connection.getIncludeSynonyms();
        if(flag && s1 != null && !hasSqlWildcard(s1) && s2 != null && !hasSqlWildcard(s2))
            return getColumnsNoWildcards(stripSqlEscapes(s1), stripSqlEscapes(s2), s3);
        else
            return getColumnsWithWildcards(s1, s2, s3, flag);
    }

    ResultSet getColumnsNoWildcards(String s, String s1, String s2)
        throws SQLException
    {
        String s3 = getColumnsNoWildcardsPlsql();
        CallableStatement callablestatement = connection.prepareCall(s3);
        callablestatement.setString(1, s);
        callablestatement.setString(2, s1);
        callablestatement.setString(3, s2 != null ? s2 : "%");
        callablestatement.registerOutParameter(4, -10);
        callablestatement.execute();
        ResultSet resultset = ((OracleCallableStatement)callablestatement).getCursor(4);
        ((OracleResultSet)resultset).closeStatementOnClose();
        return resultset;
    }

    ResultSet getColumnsWithWildcards(String s, String s1, String s2, boolean flag)
        throws SQLException
    {
        short word0 = connection.getVersionNumber();
        String s3 = "SELECT ";
        String s4 = " NULL AS table_cat,\n";
        String s5 = "";
        if((word0 >= 10200) & (word0 < 11100) & flag)
            s5 = "/*+ CHOOSE */";
        String s6 = "       t.owner AS table_schem,\n       t.table_name AS table_name,\n";
        String s7 = "       DECODE(s.owner, NULL, t.owner, s.owner)\n              AS table_schem,\n       DECODE(s.synonym_name, NULL, t.table_name, s.synonym_name)\n              AS table_name,\n";
        String s8 = "         DECODE (t.data_type, 'CHAR', t.char_length,                   'VARCHAR', t.char_length,                   'VARCHAR2', t.char_length,                   'NVARCHAR2', t.char_length,                   'NCHAR', t.char_length,                   'NUMBER', 0,           t.data_length)";
        String s9 = (new StringBuilder()).append("       t.column_name AS column_name,\n       DECODE (t.data_type, 'CHAR', 1, 'VARCHAR2', 12, 'NUMBER', 3,\n               'LONG', -1, 'DATE', ").append(((PhysicalConnection)connection).mapDateToTimestamp ? "93" : "91").append(", 'RAW', -3, 'LONG RAW', -4,  \n").append("               'BLOB', 2004, 'CLOB', 2005, 'BFILE', -13, 'FLOAT', 6, \n").append("               'TIMESTAMP(6)', 93, 'TIMESTAMP(6) WITH TIME ZONE', -101, \n").append("               'TIMESTAMP(6) WITH LOCAL TIME ZONE', -102, \n").append("               'INTERVAL YEAR(2) TO MONTH', -103, \n").append("               'INTERVAL DAY(2) TO SECOND(6)', -104, \n").append("               'BINARY_FLOAT', 100, 'BINARY_DOUBLE', 101, \n").append("               'XMLTYPE', 2009, \n").append("               1111)\n").append("              AS data_type,\n").append("       t.data_type AS type_name,\n").append("       DECODE (t.data_precision, ").append("               null, DECODE(t.data_type, ").append("                       'NUMBER', DECODE(t.data_scale, ").append("                                   null, ").append(((PhysicalConnection)connection).j2ee13Compliant ? "38" : "0").append("                                   , 38), ").append(word0 <= 9000 ? "t.data_length" : s8).append("                           ),").append("         t.data_precision)\n").append("              AS column_size,\n").append("       0 AS buffer_length,\n").append("       DECODE (t.data_type, ").append("               'NUMBER', DECODE(t.data_precision, ").append("                                null, DECODE(t.data_scale, ").append("                                             null, ").append(((PhysicalConnection)connection).j2ee13Compliant ? "0" : "-127").append("                                             , t.data_scale), ").append("                                 t.data_scale), ").append("               t.data_scale) AS decimal_digits,\n").append("       10 AS num_prec_radix,\n").append("       DECODE (t.nullable, 'N', 0, 1) AS nullable,\n").toString();
        String s10 = "       c.comments AS remarks,\n";
        String s11 = "       NULL AS remarks,\n";
        String s12 = "       t.data_default AS column_def,\n       0 AS sql_data_type,\n       0 AS sql_datetime_sub,\n       t.data_length AS char_octet_length,\n       t.column_id AS ordinal_position,\n       DECODE (t.nullable, 'N', 'NO', 'YES') AS is_nullable,\n";
        String s13 = "         null as SCOPE_CATALOG,\n       null as SCOPE_SCHEMA,\n       null as SCOPE_TABLE,\n       null as SOURCE_DATA_TYPE,\n       'NO' as IS_AUTOINCREMENT\n";
        String s14 = "FROM all_tab_columns t";
        String s15 = ", all_synonyms s";
        String s16 = ", all_col_comments c";
        String s17 = "WHERE t.owner LIKE :1 ESCAPE '/'\n  AND t.table_name LIKE :2 ESCAPE '/'\n  AND t.column_name LIKE :3 ESCAPE '/'\n";
        String s18 = "WHERE (t.owner LIKE :4 ESCAPE '/' OR\n       (s.owner LIKE :5 ESCAPE '/' AND t.owner = s.table_owner))\n  AND (t.table_name LIKE :6 ESCAPE '/' OR\n       s.synonym_name LIKE :7 ESCAPE '/')\n  AND t.column_name LIKE :8 ESCAPE '/'\n";
        String s19 = "  AND t.owner = c.owner (+)\n  AND t.table_name = c.table_name (+)\n  AND t.column_name = c.column_name (+)\n";
        String s20 = "  AND s.table_name (+) = t.table_name\n  AND ((DECODE(s.owner, t.owner, 'OK',\n                       'PUBLIC', 'OK',\n                       NULL, 'OK',\n                       'NOT OK') = 'OK') OR\n       (t.owner LIKE :9 AND t.owner = s.table_owner) OR\n       (s.owner LIKE :10 AND t.owner = s.table_owner))";
        String s21 = "ORDER BY table_schem, table_name, ordinal_position\n";
        String s22 = (new StringBuilder()).append(s3).append(s5).append(s4).toString();
        if(flag)
            s22 = (new StringBuilder()).append(s22).append(s7).toString();
        else
            s22 = (new StringBuilder()).append(s22).append(s6).toString();
        s22 = (new StringBuilder()).append(s22).append(s9).toString();
        if(connection.getRemarksReporting())
            s22 = (new StringBuilder()).append(s22).append(s10).toString();
        else
            s22 = (new StringBuilder()).append(s22).append(s11).toString();
        s22 = (new StringBuilder()).append(s22).append(s12).append(s13).append(s14).toString();
        if(connection.getRemarksReporting())
            s22 = (new StringBuilder()).append(s22).append(s16).toString();
        if(flag)
            s22 = (new StringBuilder()).append(s22).append(s15).toString();
        if(flag)
            s22 = (new StringBuilder()).append(s22).append("\n").append(s18).toString();
        else
            s22 = (new StringBuilder()).append(s22).append("\n").append(s17).toString();
        if(connection.getRemarksReporting())
            s22 = (new StringBuilder()).append(s22).append(s19).toString();
        if(connection.getIncludeSynonyms())
            s22 = (new StringBuilder()).append(s22).append(s20).toString();
        s22 = (new StringBuilder()).append(s22).append("\n").append(s21).toString();
        PreparedStatement preparedstatement = connection.prepareStatement(s22);
        if(flag)
        {
            preparedstatement.setString(1, s != null ? s : "%");
            preparedstatement.setString(2, s != null ? s : "%");
            preparedstatement.setString(3, s1 != null ? s1 : "%");
            preparedstatement.setString(4, s1 != null ? s1 : "%");
            preparedstatement.setString(5, s2 != null ? s2 : "%");
            preparedstatement.setString(6, s != null ? s : "%");
            preparedstatement.setString(7, s != null ? s : "%");
        } else
        {
            preparedstatement.setString(1, s != null ? s : "%");
            preparedstatement.setString(2, s1 != null ? s1 : "%");
            preparedstatement.setString(3, s2 != null ? s2 : "%");
        }
        OracleResultSet oracleresultset = (OracleResultSet)preparedstatement.executeQuery();
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    public ResultSet getTypeInfo()
        throws SQLException
    {
        Statement statement = connection.createStatement();
        short word0 = connection.getVersionNumber();
        String s = (new StringBuilder()).append("union select\n 'CHAR' as type_name, 1 as data_type, ").append(word0 < 8100 ? 255 : 2000).append(" as precision,\n").append(" '''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n").append(" 1 as nullable, 1 as case_sensitive, 3 as searchable,\n").append(" 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n").append(" 'CHAR' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n").append(" NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n").append("from dual\n").toString();
        String s1 = (new StringBuilder()).append("union select\n 'VARCHAR2' as type_name, 12 as data_type, ").append(word0 < 8100 ? 2000 : 4000).append(" as precision,\n").append(" '''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n").append(" 1 as nullable, 1 as case_sensitive, 3 as searchable,\n").append(" 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n").append(" 'VARCHAR2' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n").append(" NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n").append("from dual\n").toString();
        String s2 = (new StringBuilder()).append("union select\n 'DATE' as type_name, ").append(((PhysicalConnection)connection).mapDateToTimestamp ? "93" : "91").append("as data_type, 7 as precision,\n").append(" NULL as literal_prefix, NULL as literal_suffix, NULL as create_params,\n").append(" 1 as nullable, 0 as case_sensitive, 3 as searchable,\n").append(" 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n").append(" 'DATE' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n").append(" NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n").append("from dual\n").toString();
        String s3 = (new StringBuilder()).append("union select\n 'RAW' as type_name, -3 as data_type, ").append(word0 < 8100 ? 255 : 2000).append(" as precision,\n").append(" '''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n").append(" 1 as nullable, 0 as case_sensitive, 3 as searchable,\n").append(" 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n").append(" 'RAW' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n").append(" NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n").append("from dual\n").toString();
        String s4 = "-1";
        String s5 = (new StringBuilder()).append("union select\n 'BLOB' as type_name, 2004 as data_type, ").append(s4).append(" as precision,\n").append(" null as literal_prefix, null as literal_suffix, NULL as create_params,\n").append(" 1 as nullable, 0 as case_sensitive, 0 as searchable,\n").append(" 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n").append(" 'BLOB' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n").append(" NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n").append("from dual\n").toString();
        String s6 = (new StringBuilder()).append("union select\n 'CLOB' as type_name, 2005 as data_type, ").append(s4).append(" as precision,\n").append(" '''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n").append(" 1 as nullable, 1 as case_sensitive, 0 as searchable,\n").append(" 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n").append(" 'CLOB' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n").append(" NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\n").append("from dual\n").toString();
        String s7 = (new StringBuilder()).append("select\n 'NUMBER' as type_name, 2 as data_type, 38 as precision,\n NULL as literal_prefix, NULL as literal_suffix, NULL as create_params,\n 1 as nullable, 0 as case_sensitive, 3 as searchable,\n 0 as unsigned_attribute, 1 as fixed_prec_scale, 0 as auto_increment,\n 'NUMBER' as local_type_name, -84 as minimum_scale, 127 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append(s).append(s1).append(s2).append("union select\n 'DATE' as type_name, 92 as data_type, 7 as precision,\n NULL as literal_prefix, NULL as literal_suffix, NULL as create_params,\n 1 as nullable, 0 as case_sensitive, 3 as searchable,\n 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n 'DATE' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select\n 'TIMESTAMP' as type_name, 93 as data_type, 11 as precision,\n NULL as literal_prefix, NULL as literal_suffix, NULL as create_params,\n 1 as nullable, 0 as case_sensitive, 3 as searchable,\n 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n 'TIMESTAMP' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select\n 'TIMESTAMP WITH TIME ZONE' as type_name, -101 as data_type, 13 as precision,\n NULL as literal_prefix, NULL as literal_suffix, NULL as create_params,\n 1 as nullable, 0 as case_sensitive, 3 as searchable,\n 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n 'TIMESTAMP WITH TIME ZONE' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select\n 'TIMESTAMP WITH LOCAL TIME ZONE' as type_name, -102 as data_type, 11 as precision,\n NULL as literal_prefix, NULL as literal_suffix, NULL as create_params,\n 1 as nullable, 0 as case_sensitive, 3 as searchable,\n 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n 'TIMESTAMP WITH LOCAL TIME ZONE' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select\n 'INTERVALYM' as type_name, -103 as data_type, 5 as precision,\n NULL as literal_prefix, NULL as literal_suffix, NULL as create_params,\n 1 as nullable, 0 as case_sensitive, 3 as searchable,\n 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n 'INTERVALYM' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select\n 'INTERVALDS' as type_name, -104 as data_type, 4 as precision,\n NULL as literal_prefix, NULL as literal_suffix, NULL as create_params,\n 1 as nullable, 0 as case_sensitive, 3 as searchable,\n 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n 'INTERVALDS' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append(s3).append("union select\n 'LONG' as type_name, -1 as data_type, 2147483647 as precision,\n '''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n 1 as nullable, 1 as case_sensitive, 0 as searchable,\n 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n 'LONG' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select\n 'LONG RAW' as type_name, -4 as data_type, 2147483647 as precision,\n '''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n 1 as nullable, 0 as case_sensitive, 0 as searchable,\n 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n 'LONG RAW' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select 'NUMBER' as type_name, -7 as data_type, 1 as precision,\nNULL as literal_prefix, NULL as literal_suffix, \n'(1)' as create_params, 1 as nullable, 0 as case_sensitive, 3 as searchable,\n0 as unsigned_attribute, 1 as fixed_prec_scale, 0 as auto_increment,\n'NUMBER' as local_type_name, -84 as minimum_scale, 127 as maximum_scale,\nNULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select 'NUMBER' as type_name, -6 as data_type, 3 as precision,\nNULL as literal_prefix, NULL as literal_suffix, \n'(3)' as create_params, 1 as nullable, 0 as case_sensitive, 3 as searchable,\n0 as unsigned_attribute, 1 as fixed_prec_scale, 0 as auto_increment,\n'NUMBER' as local_type_name, -84 as minimum_scale, 127 as maximum_scale,\nNULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select 'NUMBER' as type_name, 5 as data_type, 5 as precision,\nNULL as literal_prefix, NULL as literal_suffix, \n'(5)' as create_params, 1 as nullable, 0 as case_sensitive, 3 as searchable,\n0 as unsigned_attribute, 1 as fixed_prec_scale, 0 as auto_increment,\n'NUMBER' as local_type_name, -84 as minimum_scale, 127 as maximum_scale,\nNULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select 'NUMBER' as type_name, 4 as data_type, 10 as precision,\nNULL as literal_prefix, NULL as literal_suffix, \n'(10)' as create_params, 1 as nullable, 0 as case_sensitive, 3 as searchable,\n0 as unsigned_attribute, 1 as fixed_prec_scale, 0 as auto_increment,\n'NUMBER' as local_type_name, -84 as minimum_scale, 127 as maximum_scale,\nNULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select 'NUMBER' as type_name, -5 as data_type, 38 as precision,\nNULL as literal_prefix, NULL as literal_suffix, \nNULL as create_params, 1 as nullable, 0 as case_sensitive, 3 as searchable,\n0 as unsigned_attribute, 1 as fixed_prec_scale, 0 as auto_increment,\n'NUMBER' as local_type_name, -84 as minimum_scale, 127 as maximum_scale,\nNULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select 'FLOAT' as type_name, 6 as data_type, 63 as precision,\nNULL as literal_prefix, NULL as literal_suffix, \nNULL as create_params, 1 as nullable, 0 as case_sensitive, 3 as searchable,\n0 as unsigned_attribute, 1 as fixed_prec_scale, 0 as auto_increment,\n'FLOAT' as local_type_name, -84 as minimum_scale, 127 as maximum_scale,\nNULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select 'REAL' as type_name, 7 as data_type, 63 as precision,\nNULL as literal_prefix, NULL as literal_suffix, \nNULL as create_params, 1 as nullable, 0 as case_sensitive, 3 as searchable,\n0 as unsigned_attribute, 1 as fixed_prec_scale, 0 as auto_increment,\n'REAL' as local_type_name, -84 as minimum_scale, 127 as maximum_scale,\nNULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append(word0 < 8100 ? "" : (new StringBuilder()).append(s5).append(s6).append("union select\n 'REF' as type_name, 2006 as data_type, 0 as precision,\n '''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n 1 as nullable, 1 as case_sensitive, 0 as searchable,\n 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n 'REF' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select\n 'ARRAY' as type_name, 2003 as data_type, 0 as precision,\n '''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n 1 as nullable, 1 as case_sensitive, 0 as searchable,\n 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n 'ARRAY' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").append("union select\n 'STRUCT' as type_name, 2002 as data_type, 0 as precision,\n '''' as literal_prefix, '''' as literal_suffix, NULL as create_params,\n 1 as nullable, 1 as case_sensitive, 0 as searchable,\n 0 as unsigned_attribute, 0 as fixed_prec_scale, 0 as auto_increment,\n 'STRUCT' as local_type_name, 0 as minimum_scale, 0 as maximum_scale,\n NULL as sql_data_type, NULL as sql_datetime_sub, 10 as num_prec_radix\nfrom dual\n").toString()).append("order by data_type\n").toString();
        OracleResultSet oracleresultset = (OracleResultSet)statement.executeQuery(s7);
        oracleresultset.closeStatementOnClose();
        return oracleresultset;
    }

    String getColumnsNoWildcardsPlsql()
        throws SQLException
    {
        String s = "declare\n  in_owner varchar2(32) := null;\n  in_name varchar2(32) := null;\n  my_user_name varchar2(32) := null;\n  cnt number := 0;\n  out_owner varchar2(32) := null;\n  out_name  varchar2(32):= null;\n  loc varchar2(32) := null;\n  xxx SYS_REFCURSOR;\nbegin\n  in_owner := ?;\n  in_name := ?;\n  select user into my_user_name from dual;\n  if( my_user_name = in_owner ) then\n    select count(*) into cnt from user_tables where table_name = in_name;\n    if( cnt = 1 ) then\n      out_owner := in_owner;\n      out_name := in_name;\n      loc := 'USER_TABLES';\n    else\n      begin\n        select table_owner, table_name into out_owner, out_name from user_synonyms where synonym_name = in_name;\n      exception\n        when NO_DATA_FOUND then\n        out_owner := null;\n        out_name := null;\n      end;\n      if( not(out_name is null) ) then\n        loc := 'USER_SYNONYMS';\n      end if;\n    end if;\n  else\n    select count(*) into cnt from all_tables where owner = in_owner and table_name = in_name;\n    if( cnt = 1 ) then\n      out_owner := in_owner;\n      out_name := in_name;\n      loc := 'ALL_TABLES';\n    else\n      begin\n        select table_owner, table_name into out_owner, out_name from all_synonyms \n          where  owner = in_owner and synonym_name = in_name;\n      exception\n        when NO_DATA_FOUND then\n          out_owner := null;\n          out_name := null;\n      end;\n      if( not(out_owner is null) ) then\n        loc := 'ALL_SYNONYMS';\n      end if;\n    end if;\n  end if;\n";
        short word0 = connection.getVersionNumber();
        String s1 = "open xxx for SELECT NULL AS table_cat,\n";
        String s2 = "       in_owner AS table_schem,\n       in_name AS table_name,\n";
        String s3 = "         DECODE (t.data_type, 'CHAR', t.char_length,                   'VARCHAR', t.char_length,                   'VARCHAR2', t.char_length,                   'NVARCHAR2', t.char_length,                   'NCHAR', t.char_length,                   'NUMBER', 0,           t.data_length)";
        String s4 = (new StringBuilder()).append("       t.column_name AS column_name,\n       DECODE (t.data_type, 'CHAR', 1, 'VARCHAR2', 12, 'NUMBER', 3,\n               'LONG', -1, 'DATE', ").append(connection.getMapDateToTimestamp() ? "93" : "91").append(", 'RAW', -3, 'LONG RAW', -4,  \n").append("               'BLOB', 2004, 'CLOB', 2005, 'BFILE', -13, 'FLOAT', 6, \n").append("               'TIMESTAMP(6)', 93, 'TIMESTAMP(6) WITH TIME ZONE', -101, \n").append("               'TIMESTAMP(6) WITH LOCAL TIME ZONE', -102, \n").append("               'INTERVAL YEAR(2) TO MONTH', -103, \n").append("               'INTERVAL DAY(2) TO SECOND(6)', -104, \n").append("               'BINARY_FLOAT', 100, 'BINARY_DOUBLE', 101, \n").append("               'XMLTYPE', 2009, \n").append("               1111)\n").append("              AS data_type,\n").append("       t.data_type AS type_name,\n").append("       DECODE (t.data_precision, ").append("               null, DECODE(t.data_type, ").append("                       'NUMBER', DECODE(t.data_scale, ").append("                                   null, ").append(((PhysicalConnection)connection).j2ee13Compliant ? "38" : "0").append("                                   , 38), ").append(word0 <= 9000 ? "t.data_length" : s3).append("                           ),").append("         t.data_precision)\n").append("              AS column_size,\n").append("       0 AS buffer_length,\n").append("       DECODE (t.data_type, ").append("               'NUMBER', DECODE(t.data_precision, ").append("                                null, DECODE(t.data_scale, ").append("                                             null, ").append(((PhysicalConnection)connection).j2ee13Compliant ? "0" : "-127").append("                                             , t.data_scale), ").append("                                 t.data_scale), ").append("               t.data_scale) AS decimal_digits,\n").append("       10 AS num_prec_radix,\n").append("       DECODE (t.nullable, 'N', 0, 1) AS nullable,\n").toString();
        String s5 = "       c.comments AS remarks,\n";
        String s6 = "       NULL AS remarks,\n";
        String s7 = "       t.data_default AS column_def,\n       0 AS sql_data_type,\n       0 AS sql_datetime_sub,\n       t.data_length AS char_octet_length,\n       t.column_id AS ordinal_position,\n       DECODE (t.nullable, 'N', 'NO', 'YES') AS is_nullable,\n";
        String s8 = "         null as SCOPE_CATALOG,\n       null as SCOPE_SCHEMA,\n       null as SCOPE_TABLE,\n       null as SOURCE_DATA_TYPE,\n       'NO' as IS_AUTOINCREMENT\n";
        String s9 = "FROM all_tab_columns t";
        String s10 = ", all_col_comments c";
        String s11 = "WHERE t.owner = out_owner \n  AND t.table_name = out_name\n AND t.column_name LIKE ? ESCAPE '/'\n";
        String s12 = "  AND t.owner = c.owner (+)\n  AND t.table_name = c.table_name (+)\n  AND t.column_name = c.column_name (+)\n";
        String s13 = "ORDER BY table_schem, table_name, ordinal_position\n";
        String s14 = s1;
        s14 = (new StringBuilder()).append(s14).append(s2).toString();
        s14 = (new StringBuilder()).append(s14).append(s4).toString();
        if(connection.getRemarksReporting())
            s14 = (new StringBuilder()).append(s14).append(s5).toString();
        else
            s14 = (new StringBuilder()).append(s14).append(s6).toString();
        s14 = (new StringBuilder()).append(s14).append(s7).append(s8).append(s9).toString();
        if(connection.getRemarksReporting())
            s14 = (new StringBuilder()).append(s14).append(s10).toString();
        s14 = (new StringBuilder()).append(s14).append("\n").append(s11).toString();
        if(connection.getRemarksReporting())
            s14 = (new StringBuilder()).append(s14).append(s12).toString();
        s14 = (new StringBuilder()).append(s14).append("\n").append(s13).toString();
        String s15 = "; \n ? := xxx;\n end;";
        String s16 = (new StringBuilder()).append(s).append(s14).append(s15).toString();
        return s16;
    }

}
