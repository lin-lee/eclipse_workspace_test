// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CMAREngine.java

package oracle.jdbc.driver;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReference;
import oracle.jdbc.internal.OracleConnection;
import oracle.net.ns.*;

// Referenced classes of package oracle.jdbc.driver:
//            T4CSocketOutputStreamWrapper, T4CSocketInputStreamWrapper, T4CTypeRep, DatabaseError, 
//            DBConversion

class T4CMAREngine
{

    static final int TTCC_MXL = 252;
    static final int TTCC_ESC = 253;
    static final int TTCC_LNG = 254;
    static final int TTCC_ERR = 255;
    static final int TTCC_MXIN = 64;
    static final byte TTCLXMULTI = 1;
    static final byte TTCLXMCONV = 2;
    T4CTypeRep types;
    Communication net;
    DBConversion conv;
    short proSvrVer;
    NetInputStream inStream;
    NetOutputStream outStream;
    final byte ignored[];
    final byte tmpBuffer1[];
    final byte tmpBuffer2[];
    final byte tmpBuffer3[];
    final byte tmpBuffer4[];
    final byte tmpBuffer5[];
    final byte tmpBuffer6[];
    final byte tmpBuffer7[];
    final byte tmpBuffer8[];
    final int retLen[];
    AtomicReference connForException;
    ArrayList refVector;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    static String toHex(long l, int i)
    {
        String s;
        switch(i)
        {
        case 1: // '\001'
            s = (new StringBuilder()).append("00").append(Long.toString(l & 255L, 16)).toString();
            break;

        case 2: // '\002'
            s = (new StringBuilder()).append("0000").append(Long.toString(l & 65535L, 16)).toString();
            break;

        case 3: // '\003'
            s = (new StringBuilder()).append("000000").append(Long.toString(l & 0xffffffL, 16)).toString();
            break;

        case 4: // '\004'
            s = (new StringBuilder()).append("00000000").append(Long.toString(l & 0xffffffffL, 16)).toString();
            break;

        case 5: // '\005'
            s = (new StringBuilder()).append("0000000000").append(Long.toString(l & 0xffffffffffL, 16)).toString();
            break;

        case 6: // '\006'
            s = (new StringBuilder()).append("000000000000").append(Long.toString(l & 0xffffffffffffL, 16)).toString();
            break;

        case 7: // '\007'
            s = (new StringBuilder()).append("00000000000000").append(Long.toString(l & 0xffffffffffffffL, 16)).toString();
            break;

        case 8: // '\b'
            return (new StringBuilder()).append(toHex(l >> 32, 4)).append(toHex(l, 4).substring(2)).toString();

        default:
            return "more than 8 bytes";
        }
        return (new StringBuilder()).append("0x").append(s.substring(s.length() - 2 * i)).toString();
    }

    static String toHex(byte byte0)
    {
        String s = (new StringBuilder()).append("00").append(Integer.toHexString(byte0 & 0xff)).toString();
        return (new StringBuilder()).append("0x").append(s.substring(s.length() - 2)).toString();
    }

    static String toHex(short word0)
    {
        return toHex(word0, 2);
    }

    static String toHex(int i)
    {
        return toHex(i, 4);
    }

    static String toHex(byte abyte0[], int i)
    {
        if(abyte0 == null)
            return "null";
        if(i > abyte0.length)
            return "byte array not long enough";
        String s = "[";
        int j = Math.min(64, i);
        for(int k = 0; k < j; k++)
            s = (new StringBuilder()).append(s).append(toHex(abyte0[k])).append(" ").toString();

        if(j < i)
            s = (new StringBuilder()).append(s).append("...").toString();
        return (new StringBuilder()).append(s).append("]").toString();
    }

    static String toHex(byte abyte0[])
    {
        if(abyte0 == null)
            return "null";
        else
            return toHex(abyte0, abyte0.length);
    }

    T4CMAREngine(Communication communication)
        throws SQLException, IOException
    {
        this(communication, false);
    }

    T4CMAREngine(Communication communication, boolean flag)
        throws SQLException, IOException
    {
        ignored = new byte[255];
        tmpBuffer1 = new byte[1];
        tmpBuffer2 = new byte[2];
        tmpBuffer3 = new byte[3];
        tmpBuffer4 = new byte[4];
        tmpBuffer5 = new byte[5];
        tmpBuffer6 = new byte[6];
        tmpBuffer7 = new byte[7];
        tmpBuffer8 = new byte[8];
        retLen = new int[1];
        connForException = new AtomicReference();
        refVector = null;
        if(communication == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        net = communication;
        try
        {
            if(flag)
            {
                outStream = communication.getNetOutputStream();
                inStream = communication.getNetInputStream();
            } else
            {
                outStream = new T4CSocketOutputStreamWrapper((NetOutputStream)communication.getOutputStream());
                inStream = new T4CSocketInputStreamWrapper((NetInputStream)communication.getInputStream(), (T4CSocketOutputStreamWrapper)outStream);
            }
        }
        catch(NetException netexception)
        {
            throw new IOException(netexception.getMessage());
        }
        types = new T4CTypeRep();
        types.setRep((byte)1, (byte)2);
    }

    void initBuffers()
    {
    }

    final void marshalSB1(byte byte0)
        throws IOException
    {
        marshalSB2(byte0);
        break MISSING_BLOCK_LABEL_12;
        Exception exception;
        exception;
        throw exception;
    }

    final void marshalUB1(short word0)
        throws IOException
    {
        outStream.write((byte)(word0 & 0xff));
        break MISSING_BLOCK_LABEL_19;
        Exception exception;
        exception;
        throw exception;
    }

    final void marshalSB2(short word0)
        throws IOException
    {
        byte byte0;
        byte0 = value2Buffer(word0, tmpBuffer2, (byte)1);
        if(byte0 == 0)
            break MISSING_BLOCK_LABEL_34;
        outStream.write(tmpBuffer2, 0, byte0);
        break MISSING_BLOCK_LABEL_34;
        Exception exception;
        exception;
        throw exception;
    }

    final void marshalUB2(int i)
        throws IOException
    {
        marshalSB2((short)(i & 0xffff));
    }

    final void marshalSB4(int i)
        throws IOException
    {
        byte byte0;
        byte0 = value2Buffer(i, tmpBuffer4, (byte)2);
        if(byte0 == 0)
            break MISSING_BLOCK_LABEL_34;
        outStream.write(tmpBuffer4, 0, byte0);
        break MISSING_BLOCK_LABEL_34;
        Exception exception;
        exception;
        throw exception;
    }

    final void marshalUB4(long l)
        throws IOException
    {
        marshalSB4((int)(l & -1L));
    }

    final void marshalSB8(long l)
        throws IOException
    {
        byte byte0;
        byte0 = value2Buffer(l, tmpBuffer8, (byte)3);
        if(byte0 == 0)
            break MISSING_BLOCK_LABEL_36;
        outStream.write(tmpBuffer8, 0, byte0);
        break MISSING_BLOCK_LABEL_36;
        Exception exception;
        exception;
        throw exception;
    }

    final void marshalSWORD(int i)
        throws IOException
    {
        marshalSB4(i);
    }

    final void marshalUWORD(long l)
        throws IOException
    {
        marshalSB4((int)(l & -1L));
    }

    final void marshalB1Array(byte abyte0[])
        throws IOException
    {
        if(abyte0.length <= 0)
            break MISSING_BLOCK_LABEL_19;
        outStream.write(abyte0);
        break MISSING_BLOCK_LABEL_19;
        Exception exception;
        exception;
        throw exception;
    }

    final void marshalB1Array(byte abyte0[], int i, int j)
        throws IOException
    {
        if(abyte0.length <= 0)
            break MISSING_BLOCK_LABEL_23;
        outStream.write(abyte0, i, j);
        break MISSING_BLOCK_LABEL_23;
        Exception exception;
        exception;
        throw exception;
    }

    final void marshalUB4Array(long al[])
        throws IOException
    {
        for(int i = 0; i < al.length; i++)
            marshalSB4((int)(al[i] & -1L));

    }

    final void marshalO2U(boolean flag)
        throws IOException
    {
        if(flag)
            addPtr((byte)1);
        else
            addPtr((byte)0);
    }

    final void marshalNULLPTR()
        throws IOException
    {
        addPtr((byte)0);
    }

    final void marshalPTR()
        throws IOException
    {
        addPtr((byte)1);
    }

    final void marshalCHR(byte abyte0[])
        throws IOException
    {
        marshalCHR(abyte0, 0, abyte0.length);
    }

    final void marshalCHR(byte abyte0[], int i, int j)
        throws IOException
    {
        if(j <= 0)
            break MISSING_BLOCK_LABEL_42;
        if(types.isConvNeeded())
        {
            marshalCLR(abyte0, i, j);
            break MISSING_BLOCK_LABEL_42;
        }
        outStream.write(abyte0, i, j);
        break MISSING_BLOCK_LABEL_42;
        Exception exception;
        exception;
        throw exception;
    }

    final void marshalCLR(byte abyte0[], int i)
        throws IOException
    {
        marshalCLR(abyte0, 0, i);
    }

    final void marshalCLR(byte abyte0[], int i, int j)
        throws IOException
    {
        if(j > 64)
        {
            int i1 = 0;
            outStream.write(-2);
            do
            {
                int k = j - i1;
                int l = k <= 64 ? k : 64;
                outStream.write((byte)(l & 0xff));
                outStream.write(abyte0, i + i1, l);
                i1 += l;
            } while(i1 < j);
            outStream.write(0);
        } else
        {
            outStream.write((byte)(j & 0xff));
            if(abyte0.length != 0)
                outStream.write(abyte0, i, j);
        }
        break MISSING_BLOCK_LABEL_128;
        Exception exception;
        exception;
        throw exception;
    }

    final void marshalKEYVAL(byte abyte0[][], int ai[], byte abyte1[][], int ai1[], byte abyte2[], int i)
        throws IOException
    {
        for(int j = 0; j < i; j++)
        {
            if(abyte0[j] != null && ai[j] > 0)
            {
                marshalUB4(ai[j]);
                marshalCLR(abyte0[j], 0, ai[j]);
            } else
            {
                marshalUB4(0L);
            }
            if(abyte1[j] != null && ai1[j] > 0)
            {
                marshalUB4(ai1[j]);
                marshalCLR(abyte1[j], 0, ai1[j]);
            } else
            {
                marshalUB4(0L);
            }
            if(abyte2[j] != 0)
                marshalUB4(1L);
            else
                marshalUB4(0L);
        }

    }

    final void marshalKEYVAL(byte abyte0[][], byte abyte1[][], byte abyte2[], int i)
        throws IOException
    {
        int ai[] = new int[i];
        int ai1[] = new int[i];
        for(int j = 0; j < i; j++)
        {
            if(abyte0[j] != null)
                ai[j] = abyte0[j].length;
            if(abyte1[j] != null)
                ai1[j] = abyte1[j].length;
        }

        marshalKEYVAL(abyte0, ai, abyte1, ai1, abyte2, i);
    }

    final void marshalDALC(byte abyte0[])
        throws IOException
    {
        if(abyte0 != null && abyte0.length >= 1)
            break MISSING_BLOCK_LABEL_27;
        outStream.write(0);
        break MISSING_BLOCK_LABEL_42;
        Exception exception;
        exception;
        throw exception;
        marshalSB4(-1 & abyte0.length);
        marshalCLR(abyte0, abyte0.length);
    }

    final void marshalKPDKV(byte abyte0[][], byte abyte1[][], int ai[])
        throws IOException
    {
        for(int i = 0; i < abyte0.length; i++)
        {
            if(abyte0[i] != null)
            {
                marshalUB4(abyte0[i].length);
                marshalCLR(abyte0[i], 0, abyte0[i].length);
            } else
            {
                marshalUB4(0L);
            }
            if(abyte1[i] != null)
            {
                marshalUB4(abyte1[i].length);
                marshalCLR(abyte1[i], 0, abyte1[i].length);
            } else
            {
                marshalUB4(0L);
            }
            marshalUB2(ai[i]);
        }

    }

    final void unmarshalKPDKV(byte abyte0[][], int ai[], byte abyte1[][], int ai1[])
        throws IOException, SQLException
    {
        boolean flag = false;
        int ai2[] = new int[1];
        for(int j = 0; j < abyte0.length; j++)
        {
            int i = (int)unmarshalUB4();
            if(i > 0)
            {
                abyte0[j] = new byte[i];
                unmarshalCLR(abyte0[j], 0, ai2, i);
                ai[j] = ai2[0];
            }
            i = (int)unmarshalUB4();
            if(i > 0)
            {
                abyte1[j] = new byte[i];
                unmarshalCLR(abyte1[j], 0, ai2, i);
            }
            ai1[j] = unmarshalUB2();
        }

    }

    final void addPtr(byte byte0)
        throws IOException
    {
        if((types.rep[4] & 1) > 0)
        {
            outStream.write(byte0);
        } else
        {
            byte byte1 = value2Buffer(byte0, tmpBuffer4, (byte)4);
            if(byte1 != 0)
                outStream.write(tmpBuffer4, 0, byte1);
        }
        break MISSING_BLOCK_LABEL_59;
        Exception exception;
        exception;
        throw exception;
    }

    final byte value2Buffer(int i, byte abyte0[], byte byte0)
        throws IOException
    {
        byte byte1;
        boolean flag = (types.rep[byte0] & 1) > 0;
        boolean flag1 = true;
        byte1 = 0;
        for(int j = abyte0.length - 1; j >= 0; j--)
        {
            abyte0[byte1] = (byte)(i >>> 8 * j & 0xff);
            if(flag)
            {
                if(!flag1 || abyte0[byte1] != 0)
                {
                    flag1 = false;
                    byte1++;
                }
            } else
            {
                byte1++;
            }
        }

        if(!flag)
            break MISSING_BLOCK_LABEL_119;
        outStream.write(byte1);
        break MISSING_BLOCK_LABEL_119;
        Exception exception;
        exception;
        throw exception;
        if((types.rep[byte0] & 2) > 0)
            reverseArray(abyte0, byte1);
        return byte1;
    }

    final byte value2Buffer(long l, byte abyte0[], byte byte0)
        throws IOException
    {
        byte byte1;
        boolean flag = (types.rep[byte0] & 1) > 0;
        boolean flag1 = true;
        byte1 = 0;
        for(int i = abyte0.length - 1; i >= 0; i--)
        {
            abyte0[byte1] = (byte)(int)(l >>> 8 * i & 255L);
            if(flag)
            {
                if(!flag1 || abyte0[byte1] != 0)
                {
                    flag1 = false;
                    byte1++;
                }
            } else
            {
                byte1++;
            }
        }

        if(!flag)
            break MISSING_BLOCK_LABEL_121;
        outStream.write(byte1);
        break MISSING_BLOCK_LABEL_121;
        Exception exception;
        exception;
        throw exception;
        if((types.rep[byte0] & 2) > 0)
            reverseArray(abyte0, byte1);
        return byte1;
    }

    final void reverseArray(byte abyte0[], byte byte0)
    {
        int i = byte0 / 2;
        for(int j = 0; j < i; j++)
        {
            byte byte1 = abyte0[j];
            abyte0[j] = abyte0[byte0 - 1 - j];
            abyte0[byte0 - 1 - j] = byte1;
        }

    }

    final byte unmarshalSB1()
        throws SQLException, IOException
    {
        byte byte0 = (byte)unmarshalSB2();
        return byte0;
    }

    final short unmarshalUB1()
        throws SQLException, IOException
    {
        short word0 = 0;
        try
        {
            word0 = (short)inStream.read();
        }
        catch(BreakNetException breaknetexception)
        {
            net.sendReset();
            throw breaknetexception;
        }
        break MISSING_BLOCK_LABEL_29;
        Exception exception;
        exception;
        throw exception;
        if(word0 < 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return word0;
        }
    }

    final short unmarshalSB2()
        throws SQLException, IOException
    {
        short word0 = (short)unmarshalUB2();
        return word0;
    }

    final int unmarshalUB2()
        throws SQLException, IOException
    {
        int i = (int)buffer2Value((byte)1);
        return i & 0xffff;
    }

    final int unmarshalUCS2(byte abyte0[], long l)
        throws SQLException, IOException
    {
        int i = unmarshalUB2();
        tmpBuffer2[0] = (byte)((i & 0xff00) >> 8);
        tmpBuffer2[1] = (byte)(i & 0xff);
        if(l + 1L < (long)abyte0.length)
        {
            abyte0[(int)l] = tmpBuffer2[0];
            abyte0[(int)l + 1] = tmpBuffer2[1];
        }
        return tmpBuffer2[0] != 0 ? 3 : tmpBuffer2[1] != 0 ? 2 : 1;
    }

    final int unmarshalSB4()
        throws SQLException, IOException
    {
        int i = (int)unmarshalUB4();
        return i;
    }

    final long unmarshalUB4()
        throws SQLException, IOException
    {
        long l = buffer2Value((byte)2);
        return l;
    }

    final int unmarshalSB4(byte abyte0[])
        throws SQLException, IOException
    {
        long l = buffer2Value((byte)2, new ByteArrayInputStream(abyte0));
        return (int)l;
    }

    final long unmarshalSB8()
        throws SQLException, IOException
    {
        long l = buffer2Value((byte)3);
        return l;
    }

    final int unmarshalRefCursor(byte abyte0[])
        throws SQLException, IOException
    {
        int i = unmarshalSB4(abyte0);
        return i;
    }

    int unmarshalSWORD()
        throws SQLException, IOException
    {
        int i = (int)unmarshalUB4();
        return i;
    }

    long unmarshalUWORD()
        throws SQLException, IOException
    {
        long l = unmarshalUB4();
        return l;
    }

    byte[] unmarshalNBytes(int i)
        throws SQLException, IOException
    {
        byte abyte0[];
        abyte0 = new byte[i];
        if(i <= 0)
            break MISSING_BLOCK_LABEL_57;
        try
        {
            if(inStream.read(abyte0) < 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(BreakNetException breaknetexception)
        {
            net.sendReset();
            throw breaknetexception;
        }
        break MISSING_BLOCK_LABEL_57;
        Exception exception;
        exception;
        throw exception;
        return abyte0;
    }

    int unmarshalNBytes(byte abyte0[], int i, int j)
        throws SQLException, IOException
    {
        if(i + j > abyte0.length)
            j = abyte0.length - i;
        int k;
        for(k = 0; k < j; k += getNBytes(abyte0, i + k, j - k));
        return k;
    }

    int getNBytes(byte abyte0[], int i, int j)
        throws SQLException, IOException
    {
        if(i + j > abyte0.length)
            j = abyte0.length - i;
        boolean flag = false;
        int k;
        try
        {
            if((k = inStream.read(abyte0, i, j)) < 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(BreakNetException breaknetexception)
        {
            net.sendReset();
            throw breaknetexception;
        }
        break MISSING_BLOCK_LABEL_75;
        Exception exception;
        exception;
        throw exception;
        return k;
    }

    byte[] getNBytes(int i)
        throws SQLException, IOException
    {
        byte abyte0[] = new byte[i];
        try
        {
            if(inStream.read(abyte0) < 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(BreakNetException breaknetexception)
        {
            net.sendReset();
            throw breaknetexception;
        }
        break MISSING_BLOCK_LABEL_53;
        Exception exception;
        exception;
        throw exception;
        return abyte0;
    }

    byte[] unmarshalTEXT(int i)
        throws SQLException, IOException
    {
        int j;
        byte abyte0[];
        j = 0;
        abyte0 = new byte[i];
_L2:
        if(j >= i)
            break; /* Loop/switch isn't completed */
        try
        {
            if(inStream.read(abyte0, j, 1) < 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(BreakNetException breaknetexception)
        {
            net.sendReset();
            throw breaknetexception;
        }
        continue; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        throw exception;
        if(abyte0[j++] != 0) goto _L2; else goto _L1
_L1:
        byte abyte1[];
        if(abyte0.length == --j)
        {
            abyte1 = abyte0;
        } else
        {
            abyte1 = new byte[j];
            System.arraycopy(abyte0, 0, abyte1, 0, j);
        }
        return abyte1;
    }

    byte[] unmarshalCHR(int i)
        throws SQLException, IOException
    {
        byte abyte0[] = null;
        if(types.isConvNeeded())
        {
            abyte0 = unmarshalCLR(i, retLen);
            if(abyte0.length != retLen[0])
            {
                byte abyte1[] = new byte[retLen[0]];
                System.arraycopy(abyte0, 0, abyte1, 0, retLen[0]);
                abyte0 = abyte1;
            }
        } else
        {
            abyte0 = getNBytes(i);
        }
        return abyte0;
    }

    void unmarshalCLR(byte abyte0[], int i, int ai[])
        throws SQLException, IOException
    {
        unmarshalCLR(abyte0, i, ai, 0x7fffffff);
    }

    void unmarshalCLR(byte abyte0[], int i, int ai[], int j)
        throws SQLException, IOException
    {
        unmarshalCLR(abyte0, i, ai, j, 0);
    }

    void unmarshalCLR(byte abyte0[], int i, int ai[], int j, int k)
        throws SQLException, IOException
    {
        int l = 0;
        boolean flag = false;
        int j1 = i;
        boolean flag1 = false;
        int k1 = 0;
        boolean flag2 = false;
        int j2 = 0;
        byte byte0 = -1;
        l = unmarshalUB1();
        if(l < 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(l == 0)
        {
            ai[0] = 0;
            return;
        }
        if(escapeSequenceNull(l))
        {
            ai[0] = 0;
            return;
        }
        if(l != 254)
        {
            if(k - j2 >= l)
            {
                unmarshalBuffer(ignored, 0, l);
                j2 += l;
                l = 0;
            } else
            if(k - j2 > 0)
            {
                unmarshalBuffer(ignored, 0, k - j2);
                l -= k - j2;
                j2 += k - j2;
            }
            if(l > 0)
            {
                int l1 = Math.min(j - k1, l);
                j1 = unmarshalBuffer(abyte0, j1, l1);
                k1 += l1;
                int k2 = l - l1;
                if(k2 > 0)
                    unmarshalBuffer(ignored, 0, k2);
            }
        } else
        {
            byte byte1 = -1;
            do
            {
                if(byte1 != -1)
                {
                    l = unmarshalUB1();
                    if(l <= 0)
                        break;
                }
                if(l == 254)
                    switch(byte1)
                    {
                    default:
                        break;

                    case -1: 
                        byte1 = 1;
                        continue;

                    case 1: // '\001'
                        byte1 = 0;
                        break;

                    case 0: // '\0'
                        if(flag1)
                        {
                            byte1 = 0;
                            break;
                        }
                        byte1 = 0;
                        continue;
                    }
                if(j1 == -1)
                {
                    unmarshalBuffer(ignored, 0, l);
                } else
                {
                    int i1 = l;
                    if(k - j2 >= i1)
                    {
                        unmarshalBuffer(ignored, 0, i1);
                        j2 += i1;
                        i1 = 0;
                    } else
                    if(k - j2 > 0)
                    {
                        unmarshalBuffer(ignored, 0, k - j2);
                        i1 -= k - j2;
                        j2 += k - j2;
                    }
                    if(i1 > 0)
                    {
                        int i2 = Math.min(j - k1, i1);
                        j1 = unmarshalBuffer(abyte0, j1, i2);
                        k1 += i2;
                        int l2 = i1 - i2;
                        if(l2 > 0)
                            unmarshalBuffer(ignored, 0, l2);
                    }
                }
                byte1 = 0;
                if(l > 252)
                    flag1 = true;
            } while(true);
        }
        if(ai != null)
            if(j1 != -1)
                ai[0] = k1;
            else
                ai[0] = abyte0.length - i;
    }

    final byte[] unmarshalCLR(int i, int ai[])
        throws SQLException, IOException
    {
        byte abyte0[] = new byte[i * conv.c2sNlsRatio];
        unmarshalCLR(abyte0, 0, ai, i);
        return abyte0;
    }

    final int[] unmarshalKEYVAL(byte abyte0[][], byte abyte1[][], int i)
        throws SQLException, IOException
    {
        byte abyte2[] = new byte[1000];
        int ai[] = new int[1];
        int ai1[] = new int[i];
        for(int k = 0; k < i; k++)
        {
            int j = unmarshalSB4();
            if(j > 0)
            {
                unmarshalCLR(abyte2, 0, ai);
                abyte0[k] = new byte[ai[0]];
                System.arraycopy(abyte2, 0, abyte0[k], 0, ai[0]);
            }
            j = unmarshalSB4();
            if(j > 0)
            {
                unmarshalCLR(abyte2, 0, ai);
                abyte1[k] = new byte[ai[0]];
                System.arraycopy(abyte2, 0, abyte1[k], 0, ai[0]);
            }
            ai1[k] = unmarshalSB4();
        }

        abyte2 = null;
        return ai1;
    }

    final int unmarshalBuffer(byte abyte0[], int i, int j)
        throws SQLException, IOException
    {
        if(j <= 0)
            return i;
        if(abyte0.length < i + j)
        {
            unmarshalNBytes(abyte0, i, abyte0.length - i);
            unmarshalNBytes(ignored, 0, (i + j) - abyte0.length);
            i = -1;
        } else
        {
            unmarshalNBytes(abyte0, i, j);
            i += j;
        }
        return i;
    }

    final byte[] unmarshalCLRforREFS()
        throws SQLException, IOException
    {
        boolean flag = false;
        short word1 = 0;
        byte abyte0[] = null;
        short word2 = unmarshalUB1();
        if(word2 < 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(word2 == 0)
            return null;
        boolean flag1 = escapeSequenceNull(word2);
        if(!flag1)
            if(refVector == null)
                refVector = new ArrayList(10);
            else
                refVector.clear();
        if(!flag1)
        {
            if(word2 == 254)
            {
                do
                {
                    short word0;
                    if((word0 = unmarshalUB1()) <= 0)
                        break;
                    if(word0 != 254 || !types.isServerConversion())
                    {
                        word1 += word0;
                        byte abyte1[] = new byte[word0];
                        unmarshalBuffer(abyte1, 0, word0);
                        refVector.add(abyte1);
                    }
                } while(true);
            } else
            {
                word1 = word2;
                byte abyte2[] = new byte[word2];
                unmarshalBuffer(abyte2, 0, word2);
                refVector.add(abyte2);
            }
            abyte0 = new byte[word1];
            int i = 0;
            for(; refVector.size() > 0; refVector.remove(0))
            {
                int j = ((byte[])(byte[])refVector.get(0)).length;
                System.arraycopy(refVector.get(0), 0, abyte0, i, j);
                i += j;
            }

        } else
        {
            abyte0 = null;
        }
        return abyte0;
    }

    final boolean escapeSequenceNull(int i)
        throws SQLException
    {
        boolean flag = false;
        switch(i)
        {
        case 0: // '\0'
            flag = true;
            break;

        case 253: 
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
            sqlexception.fillInStackTrace();
            throw sqlexception;

        case 255: 
            flag = true;
            break;
        }
        return flag;
    }

    final int processIndicator(boolean flag, int i)
        throws SQLException, IOException
    {
        short word0 = unmarshalSB2();
        int j = 0;
        if(!flag)
            if(word0 == 0)
                j = i;
            else
            if(word0 == -2 || word0 > 0)
                j = word0;
            else
                j = 0x10000 + word0;
        return j;
    }

    final long unmarshalDALC(byte abyte0[], int i, int ai[])
        throws SQLException, IOException
    {
        long l = unmarshalUB4();
        if(l > 0L)
            unmarshalCLR(abyte0, i, ai);
        return l;
    }

    final byte[] unmarshalDALC()
        throws SQLException, IOException
    {
        long l = unmarshalUB4();
        byte abyte0[] = new byte[(int)(-1L & l)];
        if(abyte0.length > 0)
        {
            abyte0 = unmarshalCLR(abyte0.length, retLen);
            if(abyte0 == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        {
            abyte0 = new byte[0];
        }
        return abyte0;
    }

    final byte[] unmarshalDALC(int ai[])
        throws SQLException, IOException
    {
        long l = unmarshalUB4();
        byte abyte0[] = new byte[(int)(-1L & l)];
        if(abyte0.length > 0)
        {
            abyte0 = unmarshalCLR(abyte0.length, ai);
            if(abyte0 == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        {
            abyte0 = new byte[0];
        }
        return abyte0;
    }

    final long buffer2Value(byte byte0)
        throws SQLException, IOException
    {
        long l = 0L;
        int i = 1;
        try
        {
            if((types.rep[byte0] & 1) > 0)
                i = inStream.readB1();
            else
                switch(byte0)
                {
                case 1: // '\001'
                    i = 2;
                    break;

                case 2: // '\002'
                    i = 4;
                    break;

                case 3: // '\003'
                    i = 8;
                    break;
                }
            long l1;
            if((types.rep[byte0] & 2) > 0)
                l1 = inStream.readLongLSB(i);
            else
                l1 = inStream.readLongMSB(i);
            return l1;
        }
        catch(BreakNetException breaknetexception)
        {
            net.sendReset();
            throw breaknetexception;
        }
    }

    final long buffer2Value(byte byte0, ByteArrayInputStream bytearrayinputstream)
        throws SQLException, IOException
    {
        int i = 0;
        long l = 0L;
        boolean flag = false;
        if((types.rep[byte0] & 1) > 0)
        {
            i = bytearrayinputstream.read();
            if((i & 0x80) > 0)
            {
                i &= 0x7f;
                flag = true;
            }
            if(i < 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(i == 0)
                return 0L;
            if(byte0 == 1 && i > 2 || byte0 == 2 && i > 4)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 412);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        } else
        if(byte0 == 1)
            i = 2;
        else
        if(byte0 == 2)
            i = 4;
        byte abyte0[] = new byte[i];
        if(bytearrayinputstream.read(abyte0) < 0)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 410);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        for(int j = 0; j < abyte0.length; j++)
        {
            short word0;
            if((types.rep[byte0] & 2) > 0)
                word0 = (short)(abyte0[abyte0.length - 1 - j] & 0xff);
            else
                word0 = (short)(abyte0[j] & 0xff);
            l |= word0 << 8 * (abyte0.length - 1 - j);
        }

        l &= -1L;
        if(flag)
            l = -l;
        return l;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return (OracleConnection)connForException.get();
    }

    protected void setConnectionDuringExceptionHandling(OracleConnection oracleconnection)
    {
        connForException.set(oracleconnection);
    }

}
