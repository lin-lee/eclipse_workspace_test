// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleSQLException.java

package oracle.jdbc.driver;

import java.sql.SQLException;

public class OracleSQLException extends SQLException
{

    private Object m_parameters[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleSQLException()
    {
        this(null, null, 0);
    }

    public OracleSQLException(String s)
    {
        this(s, null, 0);
    }

    public OracleSQLException(String s, String s1)
    {
        this(s, s1, 0);
    }

    public OracleSQLException(String s, String s1, int i)
    {
        this(s, s1, i, null);
    }

    public OracleSQLException(String s, String s1, int i, Object aobj[])
    {
        super(s, s1, i);
        m_parameters = aobj;
    }

    public Object[] getParameters()
    {
        if(m_parameters == null)
            m_parameters = new Object[0];
        return m_parameters;
    }

    public int getNumParameters()
    {
        if(m_parameters == null)
            m_parameters = new Object[0];
        return m_parameters.length;
    }

    public void setParameters(Object aobj[])
    {
        m_parameters = aobj;
    }

}
