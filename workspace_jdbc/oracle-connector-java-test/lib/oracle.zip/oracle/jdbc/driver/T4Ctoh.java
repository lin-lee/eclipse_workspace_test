// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4Ctoh.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CMAREngine

class T4Ctoh
{

    static final int TOPLVL_KPCTOH = 1;
    static final int SERBEG_KPCTOH = 2;
    static final int SEREND_KPCTOH = 4;
    static final int SERONE_KPCTOH = 8;
    static final int NEW_KPCTOH = 16;
    static final int UPDATE_KPCTOH = 32;
    static final int DELETE_KPCTOH = 64;
    static final int LAST_KPCTOH = 128;
    static final int NOOBJ_KPCTOH = 256;
    static final int NNO_KPCTOH = 512;
    static final int RAWSTR_KPCTOH = 1024;
    static final byte EOID_KOTTD[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 1, 0, 1
    };
    static final byte KORFPFNNL = 2;
    static final byte EXTENT_OID = 8;
    static final int DONE_KPCTOC = 0;
    static final int MORE_KPCTOC = -1;
    static final int IGNORE_KPCTOC = -2;
    static final int KOLRUG_ENABLE = 1;
    static final byte ANYDATA_TOID[] = {
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
        0, 0, 0, 2, 0, 17
    };
    static final int KOIDFLEN = 16;
    static final int KOIDSLEN = 8;
    byte toid[];
    byte oid[];
    byte snapshot[];
    int versionNumber;
    int imageLength;
    int flags;
    int intArr[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4Ctoh()
    {
        toid = null;
        oid = null;
        snapshot = null;
        versionNumber = 0;
        imageLength = 0;
        flags = 0;
        intArr = new int[1];
    }

    void init(byte abyte0[], int i)
    {
        if(toid == null || toid.length != 36)
            toid = new byte[36];
        toid[0] = 0;
        toid[1] = 36;
        toid[2] = 2;
        toid[3] = 8;
        System.arraycopy(abyte0, 0, toid, 4, 16);
        System.arraycopy(EOID_KOTTD, 0, toid, 20, 16);
        imageLength = i;
        oid = null;
        snapshot = null;
        versionNumber = 0;
        flags = 1;
    }

    void marshal(T4CMAREngine t4cmarengine)
        throws IOException
    {
        if(toid == null)
        {
            t4cmarengine.marshalUB4(0L);
        } else
        {
            t4cmarengine.marshalUB4(toid.length);
            t4cmarengine.marshalCLR(toid, 0, toid.length);
        }
        if(oid == null)
        {
            t4cmarengine.marshalUB4(0L);
        } else
        {
            t4cmarengine.marshalUB4(oid.length);
            t4cmarengine.marshalCLR(oid, 0, oid.length);
        }
        if(snapshot == null)
        {
            t4cmarengine.marshalUB4(0L);
        } else
        {
            t4cmarengine.marshalUB4(snapshot.length);
            t4cmarengine.marshalCLR(snapshot, 0, snapshot.length);
        }
        t4cmarengine.marshalUB2(versionNumber);
        t4cmarengine.marshalUB4(imageLength);
        t4cmarengine.marshalUB2(flags);
    }

    void unmarshal(T4CMAREngine t4cmarengine)
        throws SQLException, IOException
    {
        int i = (int)t4cmarengine.unmarshalUB4();
        if(toid == null || toid.length != i)
            toid = new byte[i];
        if(i > 0)
            t4cmarengine.unmarshalCLR(toid, 0, intArr, i);
        int j = (int)t4cmarengine.unmarshalUB4();
        oid = new byte[j];
        if(j > 0)
            t4cmarengine.unmarshalCLR(oid, 0, intArr, j);
        int k = (int)t4cmarengine.unmarshalUB4();
        snapshot = new byte[k];
        if(k > 0)
            t4cmarengine.unmarshalCLR(snapshot, 0, intArr, k);
        versionNumber = t4cmarengine.unmarshalUB2();
        imageLength = (int)t4cmarengine.unmarshalUB4();
        flags = t4cmarengine.unmarshalUB2();
    }

}
