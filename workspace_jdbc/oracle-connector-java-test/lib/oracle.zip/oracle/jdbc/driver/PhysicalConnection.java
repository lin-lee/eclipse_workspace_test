// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   PhysicalConnection.java

package oracle.jdbc.driver;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.EnumSet;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.Vector;
import java.util.concurrent.Executor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.transaction.xa.XAResource;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleDatabaseMetaData;
import oracle.jdbc.OracleOCIFailover;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleSQLPermission;
import oracle.jdbc.OracleSavepoint;
import oracle.jdbc.OracleStatement;
import oracle.jdbc.aq.AQDequeueOptions;
import oracle.jdbc.aq.AQEnqueueOptions;
import oracle.jdbc.aq.AQMessage;
import oracle.jdbc.aq.AQNotificationRegistration;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.jdbc.internal.XSEventListener;
import oracle.jdbc.internal.XSNamespace;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.oracore.OracleTypeCLOB;
import oracle.jdbc.oracore.Util;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import oracle.jdbc.pool.OraclePooledConnection;
import oracle.net.nt.CustomSSLSocketFactory;
import oracle.security.pki.OracleSecretStore;
import oracle.security.pki.OracleWallet;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.BFILE;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BLOB;
import oracle.sql.BfileDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.sql.CLOB;
import oracle.sql.CharacterSet;
import oracle.sql.ClobDBAccess;
import oracle.sql.CustomDatum;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.NCLOB;
import oracle.sql.NUMBER;
import oracle.sql.SQLName;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;
import oracle.sql.TIMEZONETAB;
import oracle.sql.TypeDescriptor;
import oracle.xdb.XMLType;

// Referenced classes of package oracle.jdbc.driver:
//            OracleConnection, OracleStatementWrapper, OraclePreparedStatement, OraclePreparedStatementWrapper, 
//            OracleCallableStatement, OracleCallableStatementWrapper, OracleSql, OracleDatabaseMetaData, 
//            OracleStatement, ByteArrayKey, AutoKeyInfo, OracleSavepoint, 
//            LRUStatementCache, ArrayDataResultSet, ArrayLocatorResultSet, StructMetaData, 
//            LogicalConnection, AQMessageI, AQMessagePropertiesI, NTFAQRegistration, 
//            NTFDCNRegistration, CRC64, NTFManager, OracleDriverExtension, 
//            OracleDriver, DatabaseError, ClassRef, DBConversion, 
//            OracleTimeout, ResultSetUtil, OracleCloseCallback, BufferCache

abstract class PhysicalConnection extends oracle.jdbc.driver.OracleConnection
{
    private static final class BufferCacheStore
    {

        static int MAX_CACHED_BUFFER_SIZE = 0x7fffffff;
        final BufferCache byteBufferCache;
        final BufferCache charBufferCache;


        BufferCacheStore()
        {
            this(MAX_CACHED_BUFFER_SIZE);
        }

        BufferCacheStore(int i)
        {
            byteBufferCache = new BufferCache(i);
            charBufferCache = new BufferCache(i);
        }
    }


    public static final String SECRET_STORE_CONNECT = "oracle.security.client.connect_string";
    public static final String SECRET_STORE_USERNAME = "oracle.security.client.username";
    public static final String SECRET_STORE_PASSWORD = "oracle.security.client.password";
    public static final String SECRET_STORE_DEFAULT_USERNAME = "oracle.security.client.default_username";
    public static final String SECRET_STORE_DEFAULT_PASSWORD = "oracle.security.client.default_password";
    static final CRC64 CHECKSUM = new CRC64();
    public static final char slash_character = 47;
    public static final char at_sign_character = 64;
    public static final char left_square_bracket_character = 91;
    public static final char right_square_bracket_character = 93;
    static final byte EMPTY_BYTE_ARRAY[] = new byte[0];
    long outScn;
    char charOutput[][];
    byte byteOutput[][];
    short shortOutput[][];
    Properties sessionProperties;
    boolean retainV9BindBehavior;
    String userName;
    String database;
    boolean autocommit;
    String protocol;
    int streamChunkSize;
    boolean setFloatAndDoubleUseBinary;
    String thinVsessionTerminal;
    String thinVsessionMachine;
    String thinVsessionOsuser;
    String thinVsessionProgram;
    String thinVsessionProcess;
    String thinVsessionIname;
    String thinVsessionEname;
    String thinNetProfile;
    String thinNetAuthenticationServices;
    String thinNetAuthenticationKrb5Mutual;
    String thinNetAuthenticationKrb5CcName;
    String thinNetEncryptionLevel;
    String thinNetEncryptionTypes;
    String thinNetChecksumLevel;
    String thinNetChecksumTypes;
    String thinNetCryptoSeed;
    boolean thinTcpNoDelay;
    String thinReadTimeout;
    String thinNetConnectTimeout;
    boolean thinNetDisableOutOfBandBreak;
    boolean thinNetUseZeroCopyIO;
    boolean thinNetEnableSDP;
    boolean use1900AsYearForTime;
    boolean timestamptzInGmt;
    boolean timezoneAsRegion;
    String thinSslServerDnMatch;
    String thinSslVersion;
    String thinSslCipherSuites;
    String thinJavaxNetSslKeystore;
    String thinJavaxNetSslKeystoretype;
    String thinJavaxNetSslKeystorepassword;
    String thinJavaxNetSslTruststore;
    String thinJavaxNetSslTruststoretype;
    String thinJavaxNetSslTruststorepassword;
    String thinSslKeymanagerfactoryAlgorithm;
    String thinSslTrustmanagerfactoryAlgorithm;
    String thinNetOldsyntax;
    String thinNamingContextInitial;
    String thinNamingProviderUrl;
    String thinNamingSecurityAuthentication;
    String thinNamingSecurityPrincipal;
    String thinNamingSecurityCredentials;
    String walletLocation;
    String walletPassword;
    String proxyClientName;
    boolean useNio;
    String ociDriverCharset;
    String editionName;
    String logonCap;
    String internalLogon;
    boolean createDescriptorUseCurrentSchemaForSchemaName;
    long ociSvcCtxHandle;
    long ociEnvHandle;
    long ociErrHandle;
    boolean prelimAuth;
    boolean nlsLangBackdoor;
    String setNewPassword;
    boolean spawnNewThreadToCancel;
    int defaultExecuteBatch;
    int defaultRowPrefetch;
    int defaultLobPrefetchSize;
    boolean enableDataInLocator;
    boolean enableReadDataInLocator;
    boolean overrideEnableReadDataInLocator;
    boolean reportRemarks;
    boolean includeSynonyms;
    boolean restrictGettables;
    boolean accumulateBatchResult;
    boolean useFetchSizeWithLongColumn;
    boolean processEscapes;
    boolean fixedString;
    boolean defaultnchar;
    boolean permitTimestampDateMismatch;
    String resourceManagerId;
    boolean disableDefinecolumntype;
    boolean convertNcharLiterals;
    boolean j2ee13Compliant;
    boolean mapDateToTimestamp;
    boolean useThreadLocalBufferCache;
    String driverNameAttribute;
    int maxCachedBufferSize;
    int implicitStatementCacheSize;
    boolean lobStreamPosStandardCompliant;
    boolean isStrictAsciiConversion;
    boolean isQuickAsciiConversion;
    boolean thinForceDnsLoadBalancing;
    boolean enableJavaNetFastPath;
    boolean enableTempLobRefCnt;
    boolean plsqlVarcharParameter4KOnly;
    boolean keepAlive;
    public boolean calculateChecksum;
    String url;
    String savedUser;
    int commitOption;
    int ociConnectionPoolMinLimit;
    int ociConnectionPoolMaxLimit;
    int ociConnectionPoolIncrement;
    int ociConnectionPoolTimeout;
    boolean ociConnectionPoolNoWait;
    boolean ociConnectionPoolTransactionDistributed;
    String ociConnectionPoolLogonMode;
    boolean ociConnectionPoolIsPooling;
    Object ociConnectionPoolObject;
    Object ociConnectionPoolConnID;
    String ociConnectionPoolProxyType;
    Integer ociConnectionPoolProxyNumRoles;
    Object ociConnectionPoolProxyRoles;
    String ociConnectionPoolProxyUserName;
    String ociConnectionPoolProxyPassword;
    String ociConnectionPoolProxyDistinguishedName;
    Object ociConnectionPoolProxyCertificate;
    static NTFManager ntfManager = new NTFManager();
    public int protocolId;
    OracleTimeout timeout;
    DBConversion conversion;
    boolean xaWantsError;
    boolean usingXA;
    int txnMode;
    byte fdo[];
    Boolean bigEndian;
    oracle.jdbc.driver.OracleStatement statements;
    int lifecycle;
    static final int OPEN = 1;
    static final int CLOSING = 2;
    static final int CLOSED = 4;
    static final int ABORTED = 8;
    static final int BLOCKED = 16;
    boolean clientIdSet;
    String clientId;
    int txnLevel;
    Map map;
    Map javaObjectMap;
    final Hashtable descriptorCacheStack[];
    int dci;
    oracle.jdbc.driver.OracleStatement statementHoldingLine;
    OracleDatabaseMetaData databaseMetaData;
    LogicalConnection logicalConnectionAttached;
    boolean isProxy;
    OracleSql sqlObj;
    SQLWarning sqlWarning;
    boolean readOnly;
    LRUStatementCache statementCache;
    boolean clearStatementMetaData;
    OracleCloseCallback closeCallback;
    Object privateData;
    Statement savepointStatement;
    boolean isUsable;
    TimeZone defaultTimeZone;
    final int endToEndMaxLength[];
    boolean endToEndAnyChanged;
    final boolean endToEndHasChanged[];
    short endToEndECIDSequenceNumber;
    static final int DMS_NONE = 0;
    static final int DMS_10G = 1;
    static final int DMS_11 = 2;
    String endToEndValues[];
    final int whichDMS = 0;
    OracleConnection wrapper;
    int minVcsBindSize;
    int maxRawBytesSql;
    int maxRawBytesPlsql;
    int maxVcsCharsSql;
    int maxVcsNCharsSql;
    int maxVcsBytesPlsql;
    int maxIbtVarcharElementLength;
    String instanceName;
    OracleDriverExtension driverExtension;
    static final String uninitializedMarker = "";
    String databaseProductVersion;
    short versionNumber;
    int namedTypeAccessorByteLen;
    int refTypeAccessorByteLen;
    CharacterSet setCHARCharSetObj;
    CharacterSet setCHARNCharSetObj;
    protected final Object cancelInProgressLockForThin;
    boolean plsqlCompilerWarnings;
    private static final Pattern driverNameAttributePattern = Pattern.compile("[\\x20-\\x7e]{0,8}");
    private static final OracleSQLPermission CALL_ABORT_PERMISSION = new OracleSQLPermission("callAbort");
    static final String DATABASE_NAME = "DATABASE_NAME";
    static final String SERVER_HOST = "SERVER_HOST";
    static final String INSTANCE_NAME = "INSTANCE_NAME";
    static final String SERVICE_NAME = "SERVICE_NAME";
    Hashtable clientData;
    private BufferCacheStore connectionBufferCacheStore;
    private static ThreadLocal threadLocalBufferCacheStore;
    private int pingResult;
    String sessionTimeZone;
    String databaseTimeZone;
    Calendar dbTzCalendar;
    static final String RAW_STR = "RAW";
    static final String SYS_RAW_STR = "SYS.RAW";
    static final String SYS_ANYDATA_STR = "SYS.ANYDATA";
    static final String SYS_XMLTYPE_STR = "SYS.XMLTYPE";
    int timeZoneVersionNumber;
    TIMEZONETAB timeZoneTab;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected PhysicalConnection()
    {
        outScn = 0L;
        charOutput = new char[1][];
        byteOutput = new byte[1][];
        shortOutput = new short[1][];
        sessionProperties = null;
        ociConnectionPoolMinLimit = 0;
        ociConnectionPoolMaxLimit = 0;
        ociConnectionPoolIncrement = 0;
        ociConnectionPoolTimeout = 0;
        ociConnectionPoolNoWait = false;
        ociConnectionPoolTransactionDistributed = false;
        ociConnectionPoolLogonMode = null;
        ociConnectionPoolIsPooling = false;
        ociConnectionPoolObject = null;
        ociConnectionPoolConnID = null;
        ociConnectionPoolProxyType = null;
        ociConnectionPoolProxyNumRoles = Integer.valueOf(0);
        ociConnectionPoolProxyRoles = null;
        ociConnectionPoolProxyUserName = null;
        ociConnectionPoolProxyPassword = null;
        ociConnectionPoolProxyDistinguishedName = null;
        ociConnectionPoolProxyCertificate = null;
        protocolId = -3;
        txnMode = 0;
        clientIdSet = false;
        clientId = null;
        descriptorCacheStack = new Hashtable[2];
        dci = 0;
        databaseMetaData = null;
        isProxy = false;
        sqlObj = null;
        sqlWarning = null;
        readOnly = false;
        statementCache = null;
        clearStatementMetaData = false;
        closeCallback = null;
        privateData = null;
        savepointStatement = null;
        isUsable = true;
        defaultTimeZone = null;
        endToEndMaxLength = new int[4];
        endToEndAnyChanged = false;
        endToEndHasChanged = new boolean[4];
        endToEndECIDSequenceNumber = -32768;
        endToEndValues = null;
        wrapper = null;
        instanceName = null;
        databaseProductVersion = "";
        versionNumber = -1;
        plsqlCompilerWarnings = false;
        sessionTimeZone = null;
        databaseTimeZone = null;
        dbTzCalendar = null;
        timeZoneVersionNumber = -1;
        timeZoneTab = null;
        cancelInProgressLockForThin = new Object();
    }

    PhysicalConnection(String s, Properties properties, OracleDriverExtension oracledriverextension)
        throws SQLException
    {
        outScn = 0L;
        charOutput = new char[1][];
        byteOutput = new byte[1][];
        shortOutput = new short[1][];
        sessionProperties = null;
        ociConnectionPoolMinLimit = 0;
        ociConnectionPoolMaxLimit = 0;
        ociConnectionPoolIncrement = 0;
        ociConnectionPoolTimeout = 0;
        ociConnectionPoolNoWait = false;
        ociConnectionPoolTransactionDistributed = false;
        ociConnectionPoolLogonMode = null;
        ociConnectionPoolIsPooling = false;
        ociConnectionPoolObject = null;
        ociConnectionPoolConnID = null;
        ociConnectionPoolProxyType = null;
        ociConnectionPoolProxyNumRoles = Integer.valueOf(0);
        ociConnectionPoolProxyRoles = null;
        ociConnectionPoolProxyUserName = null;
        ociConnectionPoolProxyPassword = null;
        ociConnectionPoolProxyDistinguishedName = null;
        ociConnectionPoolProxyCertificate = null;
        protocolId = -3;
        txnMode = 0;
        clientIdSet = false;
        clientId = null;
        descriptorCacheStack = new Hashtable[2];
        dci = 0;
        databaseMetaData = null;
        isProxy = false;
        sqlObj = null;
        sqlWarning = null;
        readOnly = false;
        statementCache = null;
        clearStatementMetaData = false;
        closeCallback = null;
        privateData = null;
        savepointStatement = null;
        isUsable = true;
        defaultTimeZone = null;
        endToEndMaxLength = new int[4];
        endToEndAnyChanged = false;
        endToEndHasChanged = new boolean[4];
        endToEndECIDSequenceNumber = -32768;
        endToEndValues = null;
        wrapper = null;
        instanceName = null;
        databaseProductVersion = "";
        versionNumber = -1;
        plsqlCompilerWarnings = false;
        sessionTimeZone = null;
        databaseTimeZone = null;
        dbTzCalendar = null;
        timeZoneVersionNumber = -1;
        timeZoneTab = null;
        cancelInProgressLockForThin = new Object();
        readConnectionProperties(s, properties);
        driverExtension = oracledriverextension;
        initialize(null, null, null);
        logicalConnectionAttached = null;
        try
        {
            needLine();
            logon();
            setAutoCommit(autocommit);
            if(getVersionNumber() >= 11202)
            {
                minVcsBindSize = 4001;
                maxRawBytesSql = 4000;
                maxRawBytesPlsql = 32766;
                maxVcsCharsSql = 32766;
                maxVcsNCharsSql = 32766;
                maxVcsBytesPlsql = 32766;
                maxIbtVarcharElementLength = 32766;
                endToEndMaxLength[0] = 64;
                endToEndMaxLength[1] = 64;
                endToEndMaxLength[2] = 64;
                endToEndMaxLength[3] = 64;
            } else
            if(getVersionNumber() >= 11000)
            {
                minVcsBindSize = 4001;
                maxRawBytesSql = 4000;
                maxRawBytesPlsql = 32766;
                maxVcsCharsSql = 32766;
                maxVcsNCharsSql = 32766;
                maxVcsBytesPlsql = 32766;
                maxIbtVarcharElementLength = 32766;
                endToEndMaxLength[0] = 32;
                endToEndMaxLength[1] = 64;
                endToEndMaxLength[2] = 64;
                endToEndMaxLength[3] = 48;
            } else
            if(getVersionNumber() >= 10000)
            {
                minVcsBindSize = 4001;
                maxRawBytesSql = 2000;
                maxRawBytesPlsql = 32512;
                maxVcsCharsSql = 32766;
                maxVcsNCharsSql = 32766;
                maxVcsBytesPlsql = 32512;
                maxIbtVarcharElementLength = 32766;
                endToEndMaxLength[0] = 32;
                endToEndMaxLength[1] = 64;
                endToEndMaxLength[2] = 64;
                endToEndMaxLength[3] = 48;
            } else
            if(getVersionNumber() >= 9200)
            {
                minVcsBindSize = 4001;
                maxRawBytesSql = 2000;
                maxRawBytesPlsql = 32512;
                maxVcsCharsSql = 32766;
                maxVcsNCharsSql = 32766;
                maxVcsBytesPlsql = 32512;
                maxIbtVarcharElementLength = 32766;
                endToEndMaxLength[0] = 32;
                endToEndMaxLength[1] = 64;
                endToEndMaxLength[2] = 64;
                endToEndMaxLength[3] = 48;
            } else
            {
                minVcsBindSize = 4001;
                maxRawBytesSql = 2000;
                maxRawBytesPlsql = 2000;
                maxVcsCharsSql = 4000;
                maxVcsNCharsSql = 4000;
                maxVcsBytesPlsql = 4000;
                maxIbtVarcharElementLength = 4000;
                endToEndMaxLength[0] = 32;
                endToEndMaxLength[1] = 64;
                endToEndMaxLength[2] = 64;
                endToEndMaxLength[3] = 48;
            }
            if(getVersionNumber() >= 10000)
                retainV9BindBehavior = false;
            initializeSetCHARCharSetObjs();
            if(implicitStatementCacheSize > 0)
            {
                setStatementCacheSize(implicitStatementCacheSize);
                setImplicitCachingEnabled(true);
            }
        }
        catch(SQLException sqlexception)
        {
            lifecycle = 2;
            try
            {
                logoff();
            }
            catch(SQLException sqlexception1) { }
            lifecycle = 4;
            throw sqlexception;
        }
        txnMode = 0;
    }

    private static final String propertyVariableName(String s)
    {
        char ac[] = new char[s.length()];
        s.getChars(0, s.length(), ac, 0);
        String s1 = "";
        for(int i = 0; i < ac.length; i++)
        {
            if(Character.isUpperCase(ac[i]))
                s1 = (new StringBuilder()).append(s1).append("_").toString();
            s1 = (new StringBuilder()).append(s1).append(Character.toUpperCase(ac[i])).toString();
        }

        return s1;
    }

    private void initializeUserDefaults(Properties properties)
    {
        Iterator iterator = OracleDriver.DEFAULT_CONNECTION_PROPERTIES.stringPropertyNames().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            String s = (String)iterator.next();
            if(!properties.containsKey(s))
                properties.setProperty(s, OracleDriver.DEFAULT_CONNECTION_PROPERTIES.getProperty(s));
        } while(true);
    }

    private void readConnectionProperties(String s, Properties properties)
        throws SQLException
    {
        initializeUserDefaults(properties);
        String s1 = null;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.RetainV9LongBindBehavior");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.RetainV9LongBindBehavior", null);
        if(s1 == null)
            s1 = "false";
        retainV9BindBehavior = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("user");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.user");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.user", null);
        if(s1 == null)
            s1 = null;
        userName = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("database");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.database");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.database", null);
        if(s1 == null)
            s1 = null;
        database = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("autoCommit");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.autoCommit");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.autoCommit", null);
        if(s1 == null)
            s1 = "true";
        autocommit = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("protocol");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.protocol");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.protocol", null);
        if(s1 == null)
            s1 = null;
        protocol = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.StreamChunkSize");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.StreamChunkSize", null);
        if(s1 == null)
            s1 = "16384";
        try
        {
            streamChunkSize = Integer.parseInt(s1);
        }
        catch(NumberFormatException numberformatexception)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'streamChunkSize'");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("SetFloatAndDoubleUseBinary");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.SetFloatAndDoubleUseBinary");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.SetFloatAndDoubleUseBinary", null);
        if(s1 == null)
            s1 = "false";
        setFloatAndDoubleUseBinary = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("v$session.terminal");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.v$session.terminal");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.v$session.terminal", null);
        if(s1 == null)
            s1 = "unknown";
        thinVsessionTerminal = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("v$session.machine");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.v$session.machine");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.v$session.machine", null);
        if(s1 == null)
            s1 = null;
        thinVsessionMachine = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("v$session.osuser");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.v$session.osuser");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.v$session.osuser", null);
        if(s1 == null)
            s1 = null;
        thinVsessionOsuser = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("v$session.program");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.v$session.program");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.v$session.program", null);
        if(s1 == null)
            s1 = "JDBC Thin Client";
        thinVsessionProgram = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("v$session.process");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.v$session.process");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.v$session.process", null);
        if(s1 == null)
            s1 = "1234";
        thinVsessionProcess = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("v$session.iname");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.v$session.iname");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.v$session.iname", null);
        if(s1 == null)
            s1 = "jdbc_ttc_impl";
        thinVsessionIname = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("v$session.ename");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.v$session.ename");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.v$session.ename", null);
        if(s1 == null)
            s1 = null;
        thinVsessionEname = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.profile");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.profile", null);
        if(s1 == null)
            s1 = null;
        thinNetProfile = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.authentication_services");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.authentication_services", null);
        if(s1 == null)
            s1 = null;
        thinNetAuthenticationServices = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.kerberos5_mutual_authentication");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.kerberos5_mutual_authentication", null);
        if(s1 == null)
            s1 = null;
        thinNetAuthenticationKrb5Mutual = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.kerberos5_cc_name");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.kerberos5_cc_name", null);
        if(s1 == null)
            s1 = null;
        thinNetAuthenticationKrb5CcName = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.encryption_client");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.encryption_client", null);
        if(s1 == null)
            s1 = null;
        thinNetEncryptionLevel = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.encryption_types_client");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.encryption_types_client", null);
        if(s1 == null)
            s1 = null;
        thinNetEncryptionTypes = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.crypto_checksum_client");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.crypto_checksum_client", null);
        if(s1 == null)
            s1 = null;
        thinNetChecksumLevel = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.crypto_checksum_types_client");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.crypto_checksum_types_client", null);
        if(s1 == null)
            s1 = null;
        thinNetChecksumTypes = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.crypto_seed");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.crypto_seed", null);
        if(s1 == null)
            s1 = null;
        thinNetCryptoSeed = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.TcpNoDelay");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.TcpNoDelay", null);
        if(s1 == null)
            s1 = "false";
        thinTcpNoDelay = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.ReadTimeout");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.ReadTimeout", null);
        if(s1 == null)
            s1 = null;
        thinReadTimeout = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.CONNECT_TIMEOUT");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.CONNECT_TIMEOUT", null);
        if(s1 == null)
            s1 = null;
        thinNetConnectTimeout = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.disableOob");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.disableOob", null);
        if(s1 == null)
            s1 = "false";
        thinNetDisableOutOfBandBreak = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.useZeroCopyIO");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.useZeroCopyIO", null);
        if(s1 == null)
            s1 = "true";
        thinNetUseZeroCopyIO = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.SDP");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.SDP", null);
        if(s1 == null)
            s1 = "false";
        thinNetEnableSDP = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.use1900AsYearForTime");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.use1900AsYearForTime", null);
        if(s1 == null)
            s1 = "false";
        use1900AsYearForTime = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.timestampTzInGmt");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.timestampTzInGmt", null);
        if(s1 == null)
            s1 = "true";
        timestamptzInGmt = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.timezoneAsRegion");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.timezoneAsRegion", null);
        if(s1 == null)
            s1 = "true";
        timezoneAsRegion = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.ssl_server_dn_match");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.ssl_server_dn_match", null);
        if(s1 == null)
            s1 = null;
        thinSslServerDnMatch = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.ssl_version");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.ssl_version", null);
        if(s1 == null)
            s1 = null;
        thinSslVersion = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.ssl_cipher_suites");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.ssl_cipher_suites", null);
        if(s1 == null)
            s1 = null;
        thinSslCipherSuites = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("javax.net.ssl.keyStore");
        if(s1 == null)
            s1 = getSystemProperty("javax.net.ssl.keyStore", null);
        if(s1 == null)
            s1 = null;
        thinJavaxNetSslKeystore = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("javax.net.ssl.keyStoreType");
        if(s1 == null)
            s1 = getSystemProperty("javax.net.ssl.keyStoreType", null);
        if(s1 == null)
            s1 = null;
        thinJavaxNetSslKeystoretype = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("javax.net.ssl.keyStorePassword");
        if(s1 == null)
            s1 = getSystemProperty("javax.net.ssl.keyStorePassword", null);
        if(s1 == null)
            s1 = null;
        thinJavaxNetSslKeystorepassword = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("javax.net.ssl.trustStore");
        if(s1 == null)
            s1 = getSystemProperty("javax.net.ssl.trustStore", null);
        if(s1 == null)
            s1 = null;
        thinJavaxNetSslTruststore = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("javax.net.ssl.trustStoreType");
        if(s1 == null)
            s1 = getSystemProperty("javax.net.ssl.trustStoreType", null);
        if(s1 == null)
            s1 = null;
        thinJavaxNetSslTruststoretype = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("javax.net.ssl.trustStorePassword");
        if(s1 == null)
            s1 = getSystemProperty("javax.net.ssl.trustStorePassword", null);
        if(s1 == null)
            s1 = null;
        thinJavaxNetSslTruststorepassword = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("ssl.keyManagerFactory.algorithm");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm", null);
        if(s1 == null)
            s1 = null;
        thinSslKeymanagerfactoryAlgorithm = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("ssl.trustManagerFactory.algorithm");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm", null);
        if(s1 == null)
            s1 = null;
        thinSslTrustmanagerfactoryAlgorithm = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.oldSyntax");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.oldSyntax", null);
        if(s1 == null)
            s1 = null;
        thinNetOldsyntax = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("java.naming.factory.initial");
        if(s1 == null)
            s1 = null;
        thinNamingContextInitial = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("java.naming.provider.url");
        if(s1 == null)
            s1 = null;
        thinNamingProviderUrl = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("java.naming.security.authentication");
        if(s1 == null)
            s1 = null;
        thinNamingSecurityAuthentication = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("java.naming.security.principal");
        if(s1 == null)
            s1 = null;
        thinNamingSecurityPrincipal = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("java.naming.security.credentials");
        if(s1 == null)
            s1 = null;
        thinNamingSecurityCredentials = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.wallet_location");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.wallet_location", null);
        if(s1 == null)
            s1 = null;
        walletLocation = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.wallet_password");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.wallet_password", null);
        if(s1 == null)
            s1 = null;
        walletPassword = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.proxyClientName");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.proxyClientName", null);
        if(s1 == null)
            s1 = null;
        proxyClientName = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.useNio");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.useNio", null);
        if(s1 == null)
            s1 = "false";
        useNio = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("JDBCDriverCharSetId");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.JDBCDriverCharSetId");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.JDBCDriverCharSetId", null);
        if(s1 == null)
            s1 = null;
        ociDriverCharset = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.editionName");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.editionName", null);
        if(s1 == null)
            s1 = null;
        editionName = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.thinLogonCapability");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.thinLogonCapability", null);
        if(s1 == null)
            s1 = "o5";
        logonCap = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("internal_logon");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.internal_logon");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.internal_logon", null);
        if(s1 == null)
            s1 = null;
        internalLogon = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName", null);
        if(s1 == null)
            s1 = "false";
        createDescriptorUseCurrentSchemaForSchemaName = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("OCISvcCtxHandle");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.OCISvcCtxHandle");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.OCISvcCtxHandle", null);
        if(s1 == null)
            s1 = "0";
        try
        {
            ociSvcCtxHandle = Long.parseLong(s1);
        }
        catch(NumberFormatException numberformatexception1)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociSvcCtxHandle'");
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("OCIEnvHandle");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.OCIEnvHandle");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.OCIEnvHandle", null);
        if(s1 == null)
            s1 = "0";
        try
        {
            ociEnvHandle = Long.parseLong(s1);
        }
        catch(NumberFormatException numberformatexception2)
        {
            SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociEnvHandle'");
            sqlexception3.fillInStackTrace();
            throw sqlexception3;
        }
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("OCIErrHandle");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.OCIErrHandle");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.OCIErrHandle", null);
        if(s1 == null)
            s1 = "0";
        try
        {
            ociErrHandle = Long.parseLong(s1);
        }
        catch(NumberFormatException numberformatexception3)
        {
            SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociErrHandle'");
            sqlexception4.fillInStackTrace();
            throw sqlexception4;
        }
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("prelim_auth");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.prelim_auth");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.prelim_auth", null);
        if(s1 == null)
            s1 = "false";
        prelimAuth = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.ociNlsLangBackwardCompatible");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.ociNlsLangBackwardCompatible", null);
        if(s1 == null)
            s1 = "false";
        nlsLangBackdoor = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("OCINewPassword");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.OCINewPassword");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.OCINewPassword", null);
        if(s1 == null)
            s1 = null;
        setNewPassword = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.spawnNewThreadToCancel");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.spawnNewThreadToCancel", null);
        if(s1 == null)
            s1 = "false";
        spawnNewThreadToCancel = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("defaultExecuteBatch");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.defaultExecuteBatch");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.defaultExecuteBatch", null);
        if(s1 == null)
            s1 = "1";
        try
        {
            defaultExecuteBatch = Integer.parseInt(s1);
        }
        catch(NumberFormatException numberformatexception4)
        {
            SQLException sqlexception5 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultExecuteBatch'");
            sqlexception5.fillInStackTrace();
            throw sqlexception5;
        }
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("defaultRowPrefetch");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.defaultRowPrefetch");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.defaultRowPrefetch", null);
        if(s1 == null)
            s1 = "10";
        try
        {
            defaultRowPrefetch = Integer.parseInt(s1);
        }
        catch(NumberFormatException numberformatexception5)
        {
            SQLException sqlexception6 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultRowPrefetch'");
            sqlexception6.fillInStackTrace();
            throw sqlexception6;
        }
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.defaultLobPrefetchSize");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.defaultLobPrefetchSize", null);
        if(s1 == null)
            s1 = "4000";
        try
        {
            defaultLobPrefetchSize = Integer.parseInt(s1);
        }
        catch(NumberFormatException numberformatexception6)
        {
            SQLException sqlexception7 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultLobPrefetchSize'");
            sqlexception7.fillInStackTrace();
            throw sqlexception7;
        }
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.enableDataInLocator");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.enableDataInLocator", null);
        if(s1 == null)
            s1 = "true";
        enableDataInLocator = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.enableReadDataInLocator");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.enableReadDataInLocator", null);
        if(s1 == null)
            s1 = "true";
        enableReadDataInLocator = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.overrideEnableReadDataInLocator");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.overrideEnableReadDataInLocator", null);
        if(s1 == null)
            s1 = "false";
        overrideEnableReadDataInLocator = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("remarksReporting");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.remarksReporting");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.remarksReporting", null);
        if(s1 == null)
            s1 = "false";
        reportRemarks = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("includeSynonyms");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.includeSynonyms");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.includeSynonyms", null);
        if(s1 == null)
            s1 = "false";
        includeSynonyms = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("restrictGetTables");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.restrictGetTables");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.restrictGetTables", null);
        if(s1 == null)
            s1 = "false";
        restrictGettables = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("AccumulateBatchResult");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.AccumulateBatchResult");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.AccumulateBatchResult", null);
        if(s1 == null)
            s1 = "true";
        accumulateBatchResult = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("useFetchSizeWithLongColumn");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.useFetchSizeWithLongColumn");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.useFetchSizeWithLongColumn", null);
        if(s1 == null)
            s1 = "false";
        useFetchSizeWithLongColumn = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("processEscapes");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.processEscapes");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.processEscapes", null);
        if(s1 == null)
            s1 = "true";
        processEscapes = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("fixedString");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.fixedString");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.fixedString", null);
        if(s1 == null)
            s1 = "false";
        fixedString = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("defaultNChar");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.defaultNChar");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.defaultNChar", null);
        if(s1 == null)
            s1 = "false";
        defaultnchar = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch", null);
        if(s1 == null)
            s1 = "false";
        permitTimestampDateMismatch = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("RessourceManagerId");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.RessourceManagerId");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.RessourceManagerId", null);
        if(s1 == null)
            s1 = "0000";
        resourceManagerId = s1;
        s1 = null;
        if(properties != null)
        {
            s1 = properties.getProperty("disableDefineColumnType");
            if(s1 == null)
                s1 = properties.getProperty("oracle.jdbc.disableDefineColumnType");
        }
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.disableDefineColumnType", null);
        if(s1 == null)
            s1 = "false";
        disableDefinecolumntype = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.convertNcharLiterals");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.convertNcharLiterals", null);
        if(s1 == null)
            s1 = "false";
        convertNcharLiterals = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.J2EE13Compliant");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.J2EE13Compliant", null);
        if(s1 == null)
            s1 = "false";
        j2ee13Compliant = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.mapDateToTimestamp");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.mapDateToTimestamp", null);
        if(s1 == null)
            s1 = "true";
        mapDateToTimestamp = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.useThreadLocalBufferCache");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.useThreadLocalBufferCache", null);
        if(s1 == null)
            s1 = "false";
        useThreadLocalBufferCache = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.driverNameAttribute");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.driverNameAttribute", null);
        if(s1 == null)
            s1 = null;
        driverNameAttribute = s1;
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.maxCachedBufferSize");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.maxCachedBufferSize", null);
        if(s1 == null)
            s1 = "30";
        try
        {
            maxCachedBufferSize = Integer.parseInt(s1);
        }
        catch(NumberFormatException numberformatexception7)
        {
            SQLException sqlexception8 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'maxCachedBufferSize'");
            sqlexception8.fillInStackTrace();
            throw sqlexception8;
        }
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.implicitStatementCacheSize");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.implicitStatementCacheSize", null);
        if(s1 == null)
            s1 = "0";
        try
        {
            implicitStatementCacheSize = Integer.parseInt(s1);
        }
        catch(NumberFormatException numberformatexception8)
        {
            SQLException sqlexception9 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'implicitStatementCacheSize'");
            sqlexception9.fillInStackTrace();
            throw sqlexception9;
        }
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.LobStreamPosStandardCompliant");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.LobStreamPosStandardCompliant", null);
        if(s1 == null)
            s1 = "false";
        lobStreamPosStandardCompliant = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.strictASCIIConversion");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.strictASCIIConversion", null);
        if(s1 == null)
            s1 = "false";
        isStrictAsciiConversion = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.quickASCIIConversion");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.quickASCIIConversion", null);
        if(s1 == null)
            s1 = "false";
        isQuickAsciiConversion = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.thinForceDNSLoadBalancing");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.thinForceDNSLoadBalancing", null);
        if(s1 == null)
            s1 = "false";
        thinForceDnsLoadBalancing = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.enableJavaNetFastPath");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.enableJavaNetFastPath", null);
        if(s1 == null)
            s1 = "false";
        enableJavaNetFastPath = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.enableTempLobRefCnt");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.enableTempLobRefCnt", null);
        if(s1 == null)
            s1 = "true";
        enableTempLobRefCnt = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.plsqlVarcharParameter4KOnly");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.plsqlVarcharParameter4KOnly", null);
        if(s1 == null)
            s1 = "false";
        plsqlVarcharParameter4KOnly = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.net.keepAlive");
        if(s1 == null)
            s1 = getSystemProperty("oracle.net.keepAlive", null);
        if(s1 == null)
            s1 = "false";
        keepAlive = s1 != null && s1.equalsIgnoreCase("true");
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.commitOption");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.commitOption", null);
        if(s1 != null)
        {
            commitOption = 0;
            String as[] = s1.split(",");
            if(as != null && as.length > 0)
            {
                String as1[] = as;
                int j = as1.length;
                for(int k = 0; k < j; k++)
                {
                    String s3 = as1[k];
                    if(s3.trim() != "")
                        commitOption |= oracle.jdbc.OracleConnection.CommitOption.valueOf(s3.trim()).getCode();
                }

            }
        }
        s1 = null;
        if(properties != null)
            s1 = properties.getProperty("oracle.jdbc.calculateChecksum");
        if(s1 == null)
            s1 = getSystemProperty("oracle.jdbc.calculateChecksum", null);
        if(s1 == null)
            s1 = "false";
        calculateChecksum = s1 != null && s1.equalsIgnoreCase("true");
        includeSynonyms = parseConnectionProperty_boolean(properties, "synonyms", (byte)3, includeSynonyms);
        reportRemarks = parseConnectionProperty_boolean(properties, "remarks", (byte)3, reportRemarks);
        defaultRowPrefetch = parseConnectionProperty_int(properties, "prefetch", (byte)3, defaultRowPrefetch);
        defaultRowPrefetch = parseConnectionProperty_int(properties, "rowPrefetch", (byte)3, defaultRowPrefetch);
        defaultExecuteBatch = parseConnectionProperty_int(properties, "batch", (byte)3, defaultExecuteBatch);
        defaultExecuteBatch = parseConnectionProperty_int(properties, "executeBatch", (byte)3, defaultExecuteBatch);
        proxyClientName = parseConnectionProperty_String(properties, "PROXY_CLIENT_NAME", (byte)1, proxyClientName);
        if(defaultRowPrefetch <= 0)
            defaultRowPrefetch = Integer.parseInt("10");
        if(defaultExecuteBatch <= 0)
            defaultExecuteBatch = Integer.parseInt("1");
        if(defaultLobPrefetchSize < -1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(streamChunkSize > 0)
            streamChunkSize = Math.max(4096, streamChunkSize);
        else
            streamChunkSize = Integer.parseInt("16384");
        if(thinVsessionOsuser == null)
        {
            thinVsessionOsuser = getSystemProperty("user.name", null);
            if(thinVsessionOsuser == null)
                thinVsessionOsuser = "jdbcuser";
        }
        if(thinNetConnectTimeout == CONNECTION_PROPERTY_THIN_NET_CONNECT_TIMEOUT_DEFAULT)
        {
            int i = DriverManager.getLoginTimeout();
            if(i != 0)
                thinNetConnectTimeout = (new StringBuilder()).append("").append(i * 1000).toString();
        }
        url = s;
        Hashtable hashtable = parseUrl(url, walletLocation, walletPassword);
        if(userName == CONNECTION_PROPERTY_USER_NAME_DEFAULT)
            userName = (String)hashtable.get("user");
        String as2[] = new String[1];
        String as3[] = new String[1];
        userName = parseLoginOption(userName, properties, as2, as3);
        if(as2[0] != null)
            internalLogon = as2[0];
        if(as3[0] != null)
            proxyClientName = as3[0];
        String s2 = properties.getProperty("password", CONNECTION_PROPERTY_PASSWORD_DEFAULT);
        if(s2 == CONNECTION_PROPERTY_PASSWORD_DEFAULT)
            s2 = (String)hashtable.get("password");
        initializePassword(s2);
        if(database == CONNECTION_PROPERTY_DATABASE_DEFAULT)
            database = properties.getProperty("server", CONNECTION_PROPERTY_DATABASE_DEFAULT);
        if(database == CONNECTION_PROPERTY_DATABASE_DEFAULT)
            database = (String)hashtable.get("database");
        protocol = (String)hashtable.get("protocol");
        if(protocol == null)
        {
            SQLException sqlexception10 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 40, "Protocol is not specified in URL");
            sqlexception10.fillInStackTrace();
            throw sqlexception10;
        }
        if(protocol.equals("oci8") || protocol.equals("oci"))
            database = translateConnStr(database);
        if(properties.getProperty("is_connection_pooling") == "true" && database == null)
            database = "";
        if(userName != null && !userName.startsWith("\""))
        {
            char ac[] = userName.toCharArray();
            for(int l = 0; l < ac.length; l++)
                ac[l] = Character.toUpperCase(ac[l]);

            userName = String.copyValueOf(ac);
        }
        xaWantsError = false;
        usingXA = false;
        readOCIConnectionPoolProperties(properties);
        validateConnectionProperties();
    }

    private void readOCIConnectionPoolProperties(Properties properties)
        throws SQLException
    {
        ociConnectionPoolMinLimit = parseConnectionProperty_int(properties, "connpool_min_limit", (byte)1, 0);
        ociConnectionPoolMaxLimit = parseConnectionProperty_int(properties, "connpool_max_limit", (byte)1, 0);
        ociConnectionPoolIncrement = parseConnectionProperty_int(properties, "connpool_increment", (byte)1, 0);
        ociConnectionPoolTimeout = parseConnectionProperty_int(properties, "connpool_timeout", (byte)1, 0);
        ociConnectionPoolNoWait = parseConnectionProperty_boolean(properties, "connpool_nowait", (byte)1, false);
        ociConnectionPoolTransactionDistributed = parseConnectionProperty_boolean(properties, "transactions_distributed", (byte)1, false);
        ociConnectionPoolLogonMode = parseConnectionProperty_String(properties, "connection_pool", (byte)1, null);
        ociConnectionPoolIsPooling = parseConnectionProperty_boolean(properties, "is_connection_pooling", (byte)1, false);
        ociConnectionPoolObject = parseConnectionProperty_Object(properties, "connpool_object", null);
        ociConnectionPoolConnID = parseConnectionProperty_Object(properties, "connection_id", null);
        ociConnectionPoolProxyType = parseConnectionProperty_String(properties, "proxytype", (byte)1, null);
        ociConnectionPoolProxyNumRoles = (Integer)parseConnectionProperty_Object(properties, "proxy_num_roles", Integer.valueOf(0));
        ociConnectionPoolProxyRoles = parseConnectionProperty_Object(properties, "proxy_roles", null);
        ociConnectionPoolProxyUserName = parseConnectionProperty_String(properties, "proxy_user_name", (byte)1, null);
        ociConnectionPoolProxyPassword = parseConnectionProperty_String(properties, "proxy_password", (byte)1, null);
        ociConnectionPoolProxyDistinguishedName = parseConnectionProperty_String(properties, "proxy_distinguished_name", (byte)1, null);
        ociConnectionPoolProxyCertificate = parseConnectionProperty_Object(properties, "proxy_certificate", null);
    }

    void validateConnectionProperties()
        throws SQLException
    {
        if(driverNameAttribute != null && !driverNameAttributePattern.matcher(driverNameAttribute).matches())
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 257);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    private static final Object parseConnectionProperty_Object(Properties properties, String s, Object obj)
        throws SQLException
    {
        Object obj1 = obj;
        if(properties != null)
        {
            Object obj2 = properties.get(s);
            if(obj2 != null)
                obj1 = obj2;
        }
        return obj1;
    }

    private static final String parseConnectionProperty_String(Properties properties, String s, byte byte0, String s1)
        throws SQLException
    {
        String s2 = null;
        if((byte0 == 1 || byte0 == 3) && properties != null)
        {
            s2 = properties.getProperty(s);
            if(s2 == null && !s.startsWith("oracle.") && !s.startsWith("java.") && !s.startsWith("javax."))
                s2 = properties.getProperty((new StringBuilder()).append("oracle.jdbc.").append(s).toString());
        }
        if(s2 == null && (byte0 == 2 || byte0 == 3))
            if(s.startsWith("oracle.") || s.startsWith("java.") || s.startsWith("javax."))
                s2 = getSystemProperty(s, null);
            else
                s2 = getSystemProperty((new StringBuilder()).append("oracle.jdbc.").append(s).toString(), null);
        if(s2 == null)
            s2 = s1;
        return s2;
    }

    private static final int parseConnectionProperty_int(Properties properties, String s, byte byte0, int i)
        throws SQLException
    {
        int j = i;
        String s1 = parseConnectionProperty_String(properties, s, byte0, null);
        if(s1 != null)
            try
            {
                j = Integer.parseInt(s1);
            }
            catch(NumberFormatException numberformatexception)
            {
                SQLException sqlexception = DatabaseError.createSqlException(null, 190, (new StringBuilder()).append("Property is '").append(s).append("' and value is '").append(s1).append("'").toString());
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return j;
    }

    private static final long parseConnectionProperty_long(Properties properties, String s, byte byte0, long l)
        throws SQLException
    {
        long l1 = l;
        String s1 = parseConnectionProperty_String(properties, s, byte0, null);
        if(s1 != null)
            try
            {
                l1 = Long.parseLong(s1);
            }
            catch(NumberFormatException numberformatexception)
            {
                SQLException sqlexception = DatabaseError.createSqlException(null, 190, (new StringBuilder()).append("Property is '").append(s).append("' and value is '").append(s1).append("'").toString());
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return l1;
    }

    private static final boolean parseConnectionProperty_boolean(Properties properties, String s, byte byte0, boolean flag)
        throws SQLException
    {
        boolean flag1 = flag;
        String s1 = parseConnectionProperty_String(properties, s, byte0, null);
        if(s1 != null)
            if(s1.equalsIgnoreCase("false"))
                flag1 = false;
            else
            if(s1.equalsIgnoreCase("true"))
                flag1 = true;
        return flag1;
    }

    private static String parseLoginOption(String s, Properties properties, String as[], String as1[])
    {
        boolean flag = false;
        String s1 = null;
        Object obj = null;
        if(s == null)
            return null;
        int k = s.length();
        if(k == 0)
            return null;
        int i = s.indexOf('[');
        if(i > 0)
        {
            int j = s.indexOf(']');
            String s2 = s.substring(i + 1, j);
            s2 = s2.trim();
            if(s2.length() > 0)
                as1[0] = s2;
            s = (new StringBuilder()).append(s.substring(0, i)).append(s.substring(j + 1, k)).toString();
        }
        String s3 = s.toLowerCase();
        i = s3.lastIndexOf(" as ");
        if(i == -1 || i < s3.lastIndexOf("\""))
            return s;
        s1 = s.substring(0, i);
        for(i += 4; i < k && s3.charAt(i) == ' '; i++);
        if(i == k)
            return s;
        String s4 = s3.substring(i).trim();
        if(s4.length() > 0)
            as[0] = s4;
        return s1;
    }

    private static final Hashtable parseUrl(String s, String s1, String s2)
        throws SQLException
    {
        Hashtable hashtable = new Hashtable(5);
        int i = s.indexOf(':', s.indexOf(':') + 1) + 1;
        int j = s.length();
        if(i == j)
            return hashtable;
        int k = s.indexOf(':', i);
        if(k == -1)
            return hashtable;
        hashtable.put("protocol", s.substring(i, k));
        int l = k + 1;
        int i1 = s.indexOf('/', l);
        int j1 = s.indexOf('@', l);
        if(j1 > l && l > i && i1 == -1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, 67);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(j1 == -1)
            j1 = j;
        if(i1 == -1)
            i1 = j1;
        if(i1 < j1 && i1 != l && j1 != l)
        {
            hashtable.put("user", s.substring(l, i1));
            hashtable.put("password", s.substring(i1 + 1, j1));
        }
        if(i1 <= j1 && (i1 == l || j1 == l) && j1 < j)
        {
            String s3 = s.substring(j1 + 1);
            String as[] = getSecretStoreCredentials(s3, s1, s2);
            if(as[0] != null || as[1] != null)
            {
                hashtable.put("user", as[0]);
                hashtable.put("password", as[1]);
            }
        }
        if(j1 < j)
            hashtable.put("database", s.substring(j1 + 1));
        return hashtable;
    }

    private static final synchronized String[] getSecretStoreCredentials(String s, String s1, String s2)
        throws SQLException
    {
        String as[];
label0:
        {
            as = new String[2];
            as[0] = null;
            as[1] = null;
            if(s1 == null)
                break label0;
            try
            {
                if(s1.startsWith("("))
                    s1 = (new StringBuilder()).append("file:").append(CustomSSLSocketFactory.processWalletLocation(s1)).toString();
                OracleWallet oraclewallet = new OracleWallet();
                if(!oraclewallet.exists(s1))
                    break label0;
                char ac[] = null;
                if(s2 != null)
                    ac = s2.toCharArray();
                oraclewallet.open(s1, ac);
                OracleSecretStore oraclesecretstore = oraclewallet.getSecretStore();
                if(oraclesecretstore.containsAlias("oracle.security.client.default_username"))
                    as[0] = new String(oraclesecretstore.getSecret("oracle.security.client.default_username"));
                if(oraclesecretstore.containsAlias("oracle.security.client.default_password"))
                    as[1] = new String(oraclesecretstore.getSecret("oracle.security.client.default_password"));
                Enumeration enumeration = oraclewallet.getSecretStore().internalAliases();
                String s3 = null;
                do
                {
                    if(!enumeration.hasMoreElements())
                        break label0;
                    s3 = (String)enumeration.nextElement();
                } while(!s3.startsWith("oracle.security.client.connect_string") || !s.equalsIgnoreCase(new String(oraclesecretstore.getSecret(s3))));
                String s4 = s3.substring("oracle.security.client.connect_string".length());
                as[0] = new String(oraclesecretstore.getSecret((new StringBuilder()).append("oracle.security.client.username").append(s4).toString()));
                as[1] = new String(oraclesecretstore.getSecret((new StringBuilder()).append("oracle.security.client.password").append(s4).toString()));
            }
            catch(NoClassDefFoundError noclassdeffounderror)
            {
                SQLException sqlexception = DatabaseError.createSqlException(null, 167, noclassdeffounderror);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            catch(Exception exception)
            {
                if(exception instanceof RuntimeException)
                {
                    throw (RuntimeException)exception;
                } else
                {
                    SQLException sqlexception1 = DatabaseError.createSqlException(null, 168, exception);
                    sqlexception1.fillInStackTrace();
                    throw sqlexception1;
                }
            }
        }
        return as;
    }

    private String translateConnStr(String s)
        throws SQLException
    {
        int i = 0;
        int j = 0;
        if(s == null || s.equals(""))
            return s;
        if(s.indexOf(')') != -1)
            return s;
        boolean flag = false;
        if(s.indexOf('[') != -1)
        {
            i = s.indexOf(']');
            if(i == -1)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, s);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            flag = true;
        }
        i = s.indexOf(':', i);
        if(i == -1)
            return s;
        j = s.indexOf(':', i + 1);
        if(j == -1)
            return s;
        if(s.indexOf(':', j + 1) != -1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, s);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        String s2 = null;
        if(flag)
            s2 = s.substring(1, i - 1);
        else
            s2 = s.substring(0, i);
        String s3 = s.substring(i + 1, j);
        String s4 = s.substring(j + 1, s.length());
        String s1 = (new StringBuilder()).append("(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=").append(s2).append(")(PORT=").append(s3).append("))(CONNECT_DATA=(SID=").append(s4).append(")))").toString();
        return s1;
    }

    protected static String getSystemPropertyPollInterval()
    {
        return getSystemProperty("oracle.jdbc.TimeoutPollInterval", "1000");
    }

    static String getSystemPropertyFastConnectionFailover(String s)
    {
        return getSystemProperty("oracle.jdbc.FastConnectionFailover", s);
    }

    static String getSystemPropertyJserverVersion()
    {
        return getSystemProperty("oracle.jserver.version", null);
    }

    private static String getSystemProperty(String s, String s1)
    {
        if(s != null)
        {
            String s2 = s;
            String s3 = s1;
            String as[] = {
                s1
            };
            AccessController.doPrivileged(new PrivilegedAction(as, s2, s3) {

                final String val$rets[];
                final String val$fstr;
                final String val$fdefaultValue;

                public Object run()
                {
                    rets[0] = System.getProperty(fstr, fdefaultValue);
                    return null;
                }

            
            {
                rets = as;
                fstr = s;
                fdefaultValue = s1;
                super();
            }
            }
);
            return as[0];
        } else
        {
            return s1;
        }
    }

    abstract void initializePassword(String s)
        throws SQLException;

    public Properties getProperties()
    {
        Properties properties = new Properties();
        Class class1;
        Field afield[];
        int i;
        class1 = null;
        Class class2 = null;
        try
        {
            class1 = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
            class2 = ClassRef.newInstance("oracle.jdbc.driver.PhysicalConnection").get();
        }
        catch(ClassNotFoundException classnotfoundexception) { }
        afield = class2.getDeclaredFields();
        i = 0;
_L5:
        int j;
        if(i >= afield.length)
            break; /* Loop/switch isn't completed */
        j = afield[i].getModifiers();
        if(!Modifier.isStatic(j)) goto _L2; else goto _L1
_L2:
        String s1;
        String s = afield[i].getName();
        s1 = (new StringBuilder()).append("CONNECTION_PROPERTY_").append(propertyVariableName(s)).toString();
        Object obj = null;
        Field field = class1.getField(s1);
          goto _L3
        NoSuchFieldException nosuchfieldexception;
        nosuchfieldexception;
          goto _L1
_L3:
        if(!s1.matches(".*PASSWORD.*"))
        {
            String s2 = (String)field.get(null);
            String s3 = afield[i].getType().getName();
            if(s3.equals("boolean"))
            {
                boolean flag = afield[i].getBoolean(this);
                if(flag)
                    properties.setProperty(s2, "true");
                else
                    properties.setProperty(s2, "false");
            } else
            if(s3.equals("int"))
            {
                int k = afield[i].getInt(this);
                properties.setProperty(s2, Integer.toString(k));
            } else
            if(s3.equals("long"))
            {
                long l = afield[i].getLong(this);
                properties.setProperty(s2, Long.toString(l));
            } else
            if(s3.equals("java.lang.String"))
            {
                String s4 = (String)afield[i].get(this);
                if(s4 != null)
                    properties.setProperty(s2, s4);
            }
        }
_L1:
        i++;
        if(true) goto _L5; else goto _L4
        IllegalAccessException illegalaccessexception;
        illegalaccessexception;
_L4:
        return properties;
    }

    /**
     * @deprecated Method _getPC is deprecated
     */

    public synchronized Connection _getPC()
    {
        return null;
    }

    public synchronized oracle.jdbc.internal.OracleConnection getPhysicalConnection()
    {
        return this;
    }

    public synchronized boolean isLogicalConnection()
    {
        return false;
    }

    void initialize(Hashtable hashtable, Map map1, Map map2)
        throws SQLException
    {
        clearStatementMetaData = false;
        if(hashtable != null)
            descriptorCacheStack[dci] = hashtable;
        else
            descriptorCacheStack[dci] = new Hashtable(10);
        map = map1;
        if(map2 != null)
            javaObjectMap = map2;
        else
            javaObjectMap = new Hashtable(10);
        lifecycle = 1;
        txnLevel = 2;
        clientIdSet = false;
    }

    void initializeSetCHARCharSetObjs()
    {
        setCHARNCharSetObj = conversion.getDriverNCharSetObj();
        setCHARCharSetObj = conversion.getDriverCharSetObj();
    }

    OracleTimeout getTimeout()
        throws SQLException
    {
        if(timeout == null)
            timeout = OracleTimeout.newTimeout(url);
        return timeout;
    }

    public synchronized Statement createStatement()
        throws SQLException
    {
        return createStatement(-1, -1);
    }

    public synchronized Statement createStatement(int i, int j)
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            oracle.jdbc.driver.OracleStatement oraclestatement = null;
            oraclestatement = driverExtension.allocateStatement(this, i, j);
            return new OracleStatementWrapper(oraclestatement);
        }
    }

    public synchronized PreparedStatement prepareStatement(String s)
        throws SQLException
    {
        return prepareStatement(s, -1, -1);
    }

    /**
     * @deprecated Method prepareStatementWithKey is deprecated
     */

    public synchronized PreparedStatement prepareStatementWithKey(String s)
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(s == null)
            return null;
        if(!isStatementCacheInitialized())
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Object obj = null;
        obj = (oracle.jdbc.driver.OraclePreparedStatement)statementCache.searchExplicitCache(s);
        if(obj != null)
            obj = new OraclePreparedStatementWrapper((OraclePreparedStatement)obj);
        return ((PreparedStatement) (obj));
    }

    public synchronized PreparedStatement prepareStatement(String s, int i, int j)
        throws SQLException
    {
        if(s == null || s.length() == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(lifecycle != 1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        oracle.jdbc.driver.OraclePreparedStatement oraclepreparedstatement = null;
        if(statementCache != null)
            oraclepreparedstatement = (oracle.jdbc.driver.OraclePreparedStatement)statementCache.searchImplicitCache(s, 1, i == -1 && j == -1 ? 1 : ResultSetUtil.getRsetTypeCode(i, j));
        if(oraclepreparedstatement == null)
            oraclepreparedstatement = driverExtension.allocatePreparedStatement(this, s, i, j);
        return new OraclePreparedStatementWrapper((OraclePreparedStatement)oraclepreparedstatement);
    }

    public synchronized CallableStatement prepareCall(String s)
        throws SQLException
    {
        return prepareCall(s, -1, -1);
    }

    public synchronized CallableStatement prepareCall(String s, int i, int j)
        throws SQLException
    {
        if(s == null || s.length() == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(lifecycle != 1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        oracle.jdbc.driver.OracleCallableStatement oraclecallablestatement = null;
        if(statementCache != null)
            oraclecallablestatement = (oracle.jdbc.driver.OracleCallableStatement)statementCache.searchImplicitCache(s, 2, i == -1 && j == -1 ? 1 : ResultSetUtil.getRsetTypeCode(i, j));
        if(oraclecallablestatement == null)
            oraclecallablestatement = driverExtension.allocateCallableStatement(this, s, i, j);
        return new OracleCallableStatementWrapper((OracleCallableStatement)oraclecallablestatement);
    }

    public synchronized CallableStatement prepareCallWithKey(String s)
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(s == null)
            return null;
        if(!isStatementCacheInitialized())
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        Object obj = null;
        obj = (oracle.jdbc.driver.OracleCallableStatement)statementCache.searchExplicitCache(s);
        if(obj != null)
            obj = new OracleCallableStatementWrapper((OracleCallableStatement)obj);
        return ((CallableStatement) (obj));
    }

    public String nativeSQL(String s)
        throws SQLException
    {
        if(sqlObj == null)
            sqlObj = new OracleSql(conversion);
        sqlObj.initialize(s);
        String s1 = sqlObj.getSql(processEscapes, convertNcharLiterals);
        return s1;
    }

    public synchronized void setAutoCommit(boolean flag)
        throws SQLException
    {
        if(flag)
            disallowGlobalTxnMode(116);
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            needLine();
            doSetAutoCommit(flag);
            return;
        }
    }

    public boolean getAutoCommit()
        throws SQLException
    {
        return autocommit;
    }

    public void cancel()
        throws SQLException
    {
        oracle.jdbc.driver.OracleStatement oraclestatement = statements;
        if(lifecycle != 1 && lifecycle != 16)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        boolean flag = false;
        for(; oraclestatement != null; oraclestatement = oraclestatement.next)
            try
            {
                if(oraclestatement.doCancel())
                    flag = true;
            }
            catch(SQLException sqlexception1) { }

        if(!flag)
            cancelOperationOnServer(false);
    }

    public void commit(EnumSet enumset)
        throws SQLException
    {
        int i = 0;
        if(enumset != null)
        {
            if(enumset.contains(oracle.jdbc.OracleConnection.CommitOption.WRITEBATCH) && enumset.contains(oracle.jdbc.OracleConnection.CommitOption.WRITEIMMED) || enumset.contains(oracle.jdbc.OracleConnection.CommitOption.WAIT) && enumset.contains(oracle.jdbc.OracleConnection.CommitOption.NOWAIT))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            for(Iterator iterator = enumset.iterator(); iterator.hasNext();)
            {
                oracle.jdbc.OracleConnection.CommitOption commitoption = (oracle.jdbc.OracleConnection.CommitOption)iterator.next();
                i |= commitoption.getCode();
            }

        }
        commit(i);
    }

    synchronized void commit(int i)
        throws SQLException
    {
        disallowGlobalTxnMode(114);
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        for(oracle.jdbc.driver.OracleStatement oraclestatement = statements; oraclestatement != null; oraclestatement = oraclestatement.next)
            if(!oraclestatement.closed)
                oraclestatement.sendBatch();

        if((i & oracle.jdbc.OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0 && (i & oracle.jdbc.OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0 || (i & oracle.jdbc.OracleConnection.CommitOption.WAIT.getCode()) != 0 && (i & oracle.jdbc.OracleConnection.CommitOption.NOWAIT.getCode()) != 0)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            registerHeartbeat();
            needLine();
            doCommit(i);
            return;
        }
    }

    public void commit()
        throws SQLException
    {
        commit(commitOption);
    }

    public synchronized void rollback()
        throws SQLException
    {
        disallowGlobalTxnMode(115);
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        for(oracle.jdbc.driver.OracleStatement oraclestatement = statements; oraclestatement != null; oraclestatement = oraclestatement.next)
            if(oraclestatement.isOracleBatchStyle())
                oraclestatement.clearBatch();

        registerHeartbeat();
        needLine();
        doRollback();
    }

    public synchronized void close()
        throws SQLException
    {
        if(lifecycle == 2 || lifecycle == 4)
            return;
        needLineUnchecked();
        if(closeCallback != null)
            closeCallback.beforeClose(this, privateData);
        closeStatementCache();
        closeStatements(false);
        if(lifecycle == 1)
            lifecycle = 2;
        if(isProxy)
            close(1);
        if(timeZoneTab != null)
            timeZoneTab.freeInstance();
        logoff();
        cleanup();
        if(timeout != null)
            timeout.close();
        if(closeCallback != null)
            closeCallback.afterClose(privateData);
        lifecycle = 4;
        isUsable = false;
        break MISSING_BLOCK_LABEL_158;
        Exception exception;
        exception;
        lifecycle = 4;
        isUsable = false;
        throw exception;
    }

    public String getDataIntegrityAlgorithmName()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public String getEncryptionAlgorithmName()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public String getAuthenticationAdaptorName()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void closeInternal(boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void cleanupAndClose(boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void cleanupAndClose()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            return;
        } else
        {
            lifecycle = 16;
            cancel();
            return;
        }
    }

    synchronized void closeLogicalConnection()
        throws SQLException
    {
        if(lifecycle == 1 || lifecycle == 16 || lifecycle == 2)
        {
            savepointStatement = null;
            closeStatements(true);
            if(clientIdSet)
                clearClientIdentifier(clientId);
            logicalConnectionAttached = null;
            lifecycle = 1;
        }
    }

    public synchronized void close(Properties properties)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized void close(int i)
        throws SQLException
    {
        if((i & 0x1000) != 0)
        {
            close();
            return;
        }
        if((i & 1) != 0 && isProxy)
        {
            purgeStatementCache();
            closeStatements(false);
            descriptorCacheStack[dci--] = null;
            closeProxySession();
            isProxy = false;
        }
    }

    public void abort()
        throws SQLException
    {
        SecurityManager securitymanager = System.getSecurityManager();
        if(securitymanager != null)
            securitymanager.checkPermission(CALL_ABORT_PERMISSION);
        if(lifecycle == 4 || lifecycle == 8)
        {
            return;
        } else
        {
            lifecycle = 8;
            doAbort();
            return;
        }
    }

    abstract void doAbort()
        throws SQLException;

    void closeProxySession()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Properties getServerSessionInfo()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized void applyConnectionAttributes(Properties properties)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized Properties getConnectionAttributes()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized Properties getUnMatchedConnectionAttributes()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized void setAbandonedTimeoutEnabled(boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized void registerConnectionCacheCallback(OracleConnectionCacheCallback oracleconnectioncachecallback, Object obj, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public OracleConnectionCacheCallback getConnectionCacheCallbackObj()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Object getConnectionCacheCallbackPrivObj()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getConnectionCacheCallbackFlag()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized void setConnectionReleasePriority(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getConnectionReleasePriority()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized boolean isClosed()
        throws SQLException
    {
        return lifecycle != 1;
    }

    public synchronized boolean isProxySession()
    {
        return isProxy;
    }

    public synchronized void openProxySession(int i, Properties properties)
        throws SQLException
    {
        boolean flag;
        flag = true;
        if(isProxy)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 149);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s = properties.getProperty("PROXY_USER_NAME");
        String s1 = properties.getProperty("PROXY_USER_PASSWORD");
        String s2 = properties.getProperty("PROXY_DISTINGUISHED_NAME");
        Object obj = properties.get("PROXY_CERTIFICATE");
        if(i == 1)
        {
            if(s == null && s1 == null)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        } else
        if(i == 2)
        {
            if(s2 == null)
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        } else
        if(i == 3)
        {
            if(obj == null)
            {
                SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
                sqlexception3.fillInStackTrace();
                throw sqlexception3;
            }
            byte abyte0[];
            try
            {
                abyte0 = (byte[])(byte[])obj;
            }
            catch(ClassCastException classcastexception)
            {
                SQLException sqlexception5 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
                sqlexception5.fillInStackTrace();
                throw sqlexception5;
            }
        } else
        {
            SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
            sqlexception4.fillInStackTrace();
            throw sqlexception4;
        }
        purgeStatementCache();
        closeStatements(false);
        doProxySession(i, properties);
        dci++;
        flag = false;
        if(flag)
            closeProxySession();
        break MISSING_BLOCK_LABEL_274;
        Exception exception;
        exception;
        if(flag)
            closeProxySession();
        throw exception;
    }

    void doProxySession(int i, Properties properties)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void cleanup()
    {
        fdo = null;
        conversion = null;
        statements = null;
        descriptorCacheStack[dci] = null;
        map = null;
        javaObjectMap = null;
        statementHoldingLine = null;
        sqlObj = null;
        isProxy = false;
    }

    public synchronized DatabaseMetaData getMetaData()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(databaseMetaData == null)
            databaseMetaData = new oracle.jdbc.driver.OracleDatabaseMetaData(this);
        return databaseMetaData;
    }

    public void setReadOnly(boolean flag)
        throws SQLException
    {
        readOnly = flag;
    }

    public boolean isReadOnly()
        throws SQLException
    {
        return readOnly;
    }

    public void setCatalog(String s)
        throws SQLException
    {
    }

    public String getCatalog()
        throws SQLException
    {
        return null;
    }

    public synchronized void setTransactionIsolation(int i)
        throws SQLException
    {
        Statement statement;
        if(txnLevel == i)
            return;
        statement = createStatement();
        switch(i)
        {
        case 2: // '\002'
            statement.execute("ALTER SESSION SET ISOLATION_LEVEL = READ COMMITTED");
            txnLevel = 2;
            break;

        case 8: // '\b'
            statement.execute("ALTER SESSION SET ISOLATION_LEVEL = SERIALIZABLE");
            txnLevel = 8;
            break;

        default:
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 30);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        statement.close();
        break MISSING_BLOCK_LABEL_114;
        Exception exception;
        exception;
        statement.close();
        throw exception;
    }

    public int getTransactionIsolation()
        throws SQLException
    {
        return txnLevel;
    }

    public synchronized void setAutoClose(boolean flag)
        throws SQLException
    {
        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 31);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public boolean getAutoClose()
        throws SQLException
    {
        return true;
    }

    public SQLWarning getWarnings()
        throws SQLException
    {
        return sqlWarning;
    }

    public void clearWarnings()
        throws SQLException
    {
        sqlWarning = null;
    }

    public void setWarnings(SQLWarning sqlwarning)
    {
        sqlWarning = sqlwarning;
    }

    public void setDefaultRowPrefetch(int i)
        throws SQLException
    {
        if(i <= 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            defaultRowPrefetch = i;
            return;
        }
    }

    public int getDefaultRowPrefetch()
    {
        return defaultRowPrefetch;
    }

    public boolean getTimestamptzInGmt()
    {
        return timestamptzInGmt;
    }

    public boolean getUse1900AsYearForTime()
    {
        return use1900AsYearForTime;
    }

    public synchronized void setDefaultExecuteBatch(int i)
        throws SQLException
    {
        if(i <= 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            defaultExecuteBatch = i;
            return;
        }
    }

    public synchronized int getDefaultExecuteBatch()
    {
        return defaultExecuteBatch;
    }

    public synchronized void setRemarksReporting(boolean flag)
    {
        reportRemarks = flag;
    }

    public synchronized boolean getRemarksReporting()
    {
        return reportRemarks;
    }

    public void setIncludeSynonyms(boolean flag)
    {
        includeSynonyms = flag;
    }

    public synchronized String[] getEndToEndMetrics()
        throws SQLException
    {
        String as[];
        if(endToEndValues == null)
        {
            as = null;
        } else
        {
            as = new String[endToEndValues.length];
            System.arraycopy(endToEndValues, 0, as, 0, endToEndValues.length);
        }
        return as;
    }

    public short getEndToEndECIDSequenceNumber()
        throws SQLException
    {
        return endToEndECIDSequenceNumber;
    }

    public synchronized void setEndToEndMetrics(String as[], short word0)
        throws SQLException
    {
        String as1[] = new String[as.length];
        System.arraycopy(as, 0, as1, 0, as.length);
        setEndToEndMetricsInternal(as1, word0);
    }

    void setEndToEndMetricsInternal(String as[], short word0)
        throws SQLException
    {
        if(as != endToEndValues)
        {
            if(as.length != 4)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 156);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            for(int i = 0; i < 4; i++)
            {
                String s = as[i];
                if(s != null && s.length() > endToEndMaxLength[i])
                {
                    SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, s);
                    sqlexception1.fillInStackTrace();
                    throw sqlexception1;
                }
            }

            if(endToEndValues != null)
            {
                for(int j = 0; j < 4; j++)
                {
                    String s1 = as[j];
                    if(s1 == null && endToEndValues[j] != null || s1 != null && !s1.equals(endToEndValues[j]))
                    {
                        endToEndHasChanged[j] = true;
                        endToEndAnyChanged = true;
                    }
                }

                endToEndHasChanged[0] |= endToEndHasChanged[3];
            } else
            {
                for(int k = 0; k < 4; k++)
                    endToEndHasChanged[k] = true;

                endToEndAnyChanged = true;
            }
            endToEndValues = as;
        }
        endToEndECIDSequenceNumber = word0;
    }

    void updateSystemContext()
        throws SQLException
    {
    }

    void resetSystemContext()
    {
    }

    void updateSystemContext11()
        throws SQLException
    {
    }

    public boolean getIncludeSynonyms()
    {
        return includeSynonyms;
    }

    public void setRestrictGetTables(boolean flag)
    {
        restrictGettables = flag;
    }

    public boolean getRestrictGetTables()
    {
        return restrictGettables;
    }

    public void setDefaultFixedString(boolean flag)
    {
        fixedString = flag;
    }

    public void setDefaultNChar(boolean flag)
    {
        defaultnchar = flag;
    }

    public boolean getDefaultFixedString()
    {
        return fixedString;
    }

    public int getNlsRatio()
    {
        return 1;
    }

    public int getC2SNlsRatio()
    {
        return 1;
    }

    synchronized void addStatement(oracle.jdbc.driver.OracleStatement oraclestatement)
    {
        if(oraclestatement.next != null)
            throw new Error((new StringBuilder()).append("add_statement called twice on ").append(oraclestatement).toString());
        oraclestatement.next = statements;
        if(statements != null)
            statements.prev = oraclestatement;
        statements = oraclestatement;
    }

    synchronized void removeStatement(oracle.jdbc.driver.OracleStatement oraclestatement)
    {
        oracle.jdbc.driver.OracleStatement oraclestatement1 = oraclestatement.prev;
        oracle.jdbc.driver.OracleStatement oraclestatement2 = oraclestatement.next;
        if(oraclestatement1 == null)
        {
            if(statements != oraclestatement)
                return;
            statements = oraclestatement2;
        } else
        {
            oraclestatement1.next = oraclestatement2;
        }
        if(oraclestatement2 != null)
            oraclestatement2.prev = oraclestatement1;
        oraclestatement.next = null;
        oraclestatement.prev = null;
    }

    synchronized void closeStatements(boolean flag)
        throws SQLException
    {
        oracle.jdbc.driver.OracleStatement oraclestatement2;
        for(oracle.jdbc.driver.OracleStatement oraclestatement = statements; oraclestatement != null; oraclestatement = oraclestatement2)
        {
            oraclestatement2 = oraclestatement.nextChild;
            if(oraclestatement.serverCursor)
            {
                oraclestatement.close();
                removeStatement(oraclestatement);
            }
        }

        oracle.jdbc.driver.OracleStatement oraclestatement3;
        for(oracle.jdbc.driver.OracleStatement oraclestatement1 = statements; oraclestatement1 != null; oraclestatement1 = oraclestatement3)
        {
            oraclestatement3 = oraclestatement1.next;
            if(flag)
                oraclestatement1.close();
            else
                oraclestatement1.hardClose();
            removeStatement(oraclestatement1);
        }

    }

    final void purgeStatementCache()
        throws SQLException
    {
        if(isStatementCacheInitialized())
        {
            statementCache.purgeImplicitCache();
            statementCache.purgeExplicitCache();
        }
    }

    final void closeStatementCache()
        throws SQLException
    {
        if(isStatementCacheInitialized())
        {
            statementCache.close();
            statementCache = null;
            clearStatementMetaData = true;
        }
    }

    void needLine()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            needLineUnchecked();
            return;
        }
    }

    synchronized void needLineUnchecked()
        throws SQLException
    {
        if(statementHoldingLine != null)
            statementHoldingLine.freeLine();
    }

    synchronized void holdLine(oracle.jdbc.internal.OracleStatement oraclestatement)
    {
        holdLine((oracle.jdbc.driver.OracleStatement)oraclestatement);
    }

    synchronized void holdLine(oracle.jdbc.driver.OracleStatement oraclestatement)
    {
        statementHoldingLine = oraclestatement;
    }

    synchronized void releaseLine()
    {
        releaseLineForCancel();
    }

    void releaseLineForCancel()
    {
        statementHoldingLine = null;
    }

    public synchronized void startup(String s, int i)
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            SQLException sqlexception1 = DatabaseError.createUnsupportedFeatureSqlException();
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public synchronized void startup(oracle.jdbc.OracleConnection.DatabaseStartupMode databasestartupmode)
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(databasestartupmode == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            needLine();
            doStartup(databasestartupmode.getMode());
            return;
        }
    }

    void doStartup(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized void shutdown(oracle.jdbc.OracleConnection.DatabaseShutdownMode databaseshutdownmode)
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(databaseshutdownmode == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            needLine();
            doShutdown(databaseshutdownmode.getMode());
            return;
        }
    }

    void doShutdown(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized void archive(int i, int j, String s)
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            SQLException sqlexception1 = DatabaseError.createUnsupportedFeatureSqlException();
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public synchronized void registerSQLType(String s, String s1)
        throws SQLException
    {
        if(s == null || s1 == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        try
        {
            registerSQLType(s, Class.forName(s1));
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, (new StringBuilder()).append("Class not found: ").append(s1).toString());
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public synchronized void registerSQLType(String s, Class class1)
        throws SQLException
    {
        if(s == null || class1 == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(map == null)
            map = new Hashtable(10);
        map.put(s, class1);
        map.put(class1.getName(), s);
    }

    public synchronized String getSQLType(Object obj)
        throws SQLException
    {
        if(obj != null && map != null)
        {
            String s = obj.getClass().getName();
            return (String)map.get(s);
        } else
        {
            return null;
        }
    }

    public synchronized Object getJavaObject(String s)
        throws SQLException
    {
        Object obj = null;
        try
        {
            if(s != null && map != null)
            {
                Class class1 = (Class)map.get(s);
                obj = class1.newInstance();
            }
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            illegalaccessexception.printStackTrace();
        }
        catch(InstantiationException instantiationexception)
        {
            instantiationexception.printStackTrace();
        }
        return obj;
    }

    public synchronized void putDescriptor(String s, Object obj)
        throws SQLException
    {
        if(s != null && obj != null)
        {
            if(descriptorCacheStack[dci] == null)
                descriptorCacheStack[dci] = new Hashtable(10);
            ((TypeDescriptor)obj).fixupConnection(this);
            descriptorCacheStack[dci].put(s, obj);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public synchronized Object getDescriptor(String s)
    {
        Object obj = null;
        if(s != null)
        {
            if(descriptorCacheStack[dci] != null)
                obj = descriptorCacheStack[dci].get(s);
            if(obj == null && dci == 1 && descriptorCacheStack[0] != null)
                obj = descriptorCacheStack[0].get(s);
        }
        return obj;
    }

    /**
     * @deprecated Method removeDecriptor is deprecated
     */

    public synchronized void removeDecriptor(String s)
    {
        removeDescriptor(s);
    }

    public synchronized void removeDescriptor(String s)
    {
        if(s != null && descriptorCacheStack[dci] != null)
            descriptorCacheStack[dci].remove(s);
        if(s != null && dci == 1 && descriptorCacheStack[0] != null)
            descriptorCacheStack[0].remove(s);
    }

    public synchronized void removeAllDescriptor()
    {
        for(int i = 0; i <= dci; i++)
            if(descriptorCacheStack[i] != null)
                descriptorCacheStack[i].clear();

    }

    public int numberOfDescriptorCacheEntries()
    {
        int i = 0;
        for(int j = 0; j <= dci; j++)
            if(descriptorCacheStack[j] != null)
                i += descriptorCacheStack[j].size();

        return i;
    }

    public Enumeration descriptorCacheKeys()
    {
        if(dci == 0)
            if(descriptorCacheStack[dci] != null)
                return descriptorCacheStack[dci].keys();
            else
                return null;
        if(descriptorCacheStack[0] == null && descriptorCacheStack[1] != null)
            return descriptorCacheStack[1].keys();
        if(descriptorCacheStack[1] == null && descriptorCacheStack[0] != null)
            return descriptorCacheStack[0].keys();
        if(descriptorCacheStack[0] == null && descriptorCacheStack[1] == null)
        {
            return null;
        } else
        {
            Vector vector = new Vector(descriptorCacheStack[1].keySet());
            vector.addAll(descriptorCacheStack[0].keySet());
            return vector.elements();
        }
    }

    public synchronized void putDescriptor(byte abyte0[], Object obj)
        throws SQLException
    {
        if(abyte0 != null && obj != null)
        {
            if(descriptorCacheStack[dci] == null)
                descriptorCacheStack[dci] = new Hashtable(10);
            descriptorCacheStack[dci].put(new ByteArrayKey(abyte0), obj);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public synchronized Object getDescriptor(byte abyte0[])
    {
        Object obj = null;
        if(abyte0 != null)
        {
            ByteArrayKey bytearraykey = new ByteArrayKey(abyte0);
            if(descriptorCacheStack[dci] != null)
                obj = descriptorCacheStack[dci].get(bytearraykey);
            if(obj == null && dci == 1 && descriptorCacheStack[0] != null)
                obj = descriptorCacheStack[0].get(bytearraykey);
        }
        return obj;
    }

    public synchronized void removeDecriptor(byte abyte0[])
    {
        if(abyte0 != null)
        {
            ByteArrayKey bytearraykey = new ByteArrayKey(abyte0);
            if(descriptorCacheStack[dci] != null)
                descriptorCacheStack[dci].remove(bytearraykey);
            if(dci == 1 && descriptorCacheStack[0] != null)
                descriptorCacheStack[0].remove(bytearraykey);
        }
    }

    public short getJdbcCsId()
        throws SQLException
    {
        if(conversion == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return conversion.getClientCharSet();
        }
    }

    public short getDbCsId()
        throws SQLException
    {
        if(conversion == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return conversion.getServerCharSetId();
        }
    }

    public short getNCsId()
        throws SQLException
    {
        if(conversion == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return conversion.getNCharSetId();
        }
    }

    public short getStructAttrCsId()
        throws SQLException
    {
        return getDbCsId();
    }

    public short getStructAttrNCsId()
        throws SQLException
    {
        return getNCsId();
    }

    public synchronized Map getTypeMap()
    {
        if(map == null)
            map = new Hashtable(10);
        return map;
    }

    public synchronized void setTypeMap(Map map1)
    {
        map = map1;
    }

    public synchronized void setUsingXAFlag(boolean flag)
    {
        usingXA = flag;
    }

    public synchronized boolean getUsingXAFlag()
    {
        return usingXA;
    }

    public synchronized void setXAErrorFlag(boolean flag)
    {
        xaWantsError = flag;
    }

    public synchronized boolean getXAErrorFlag()
    {
        return xaWantsError;
    }

    String getPropertyFromDatabase(String s)
        throws SQLException
    {
        String s1;
        Statement statement;
        ResultSet resultset;
        s1 = null;
        statement = null;
        resultset = null;
        statement = createStatement();
        statement.setFetchSize(1);
        resultset = statement.executeQuery(s);
        if(resultset.next())
            s1 = resultset.getString(1);
        if(resultset != null)
            resultset.close();
        if(statement != null)
            statement.close();
        break MISSING_BLOCK_LABEL_99;
        Exception exception;
        exception;
        if(resultset != null)
            resultset.close();
        if(statement != null)
            statement.close();
        throw exception;
        return s1;
    }

    public synchronized String getUserName()
        throws SQLException
    {
        if(userName == null)
            userName = getPropertyFromDatabase("SELECT USER FROM DUAL");
        return userName;
    }

    public String getCurrentSchema()
        throws SQLException
    {
        return getPropertyFromDatabase("SELECT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') FROM DUAL");
    }

    public String getDefaultSchemaNameForNamedTypes()
        throws SQLException
    {
        String s = null;
        if(createDescriptorUseCurrentSchemaForSchemaName)
            s = getCurrentSchema();
        else
            s = getUserName();
        return s;
    }

    public synchronized void setStartTime(long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized long getStartTime()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void registerHeartbeat()
        throws SQLException
    {
        if(logicalConnectionAttached != null)
            logicalConnectionAttached.registerHeartbeat();
    }

    public int getHeartbeatNoChangeCount()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public synchronized byte[] getFDO(boolean flag)
        throws SQLException
    {
        CallableStatement callablestatement;
        if(fdo != null || !flag)
            break MISSING_BLOCK_LABEL_86;
        callablestatement = null;
        callablestatement = prepareCall("begin :1 := dbms_pickler.get_format (:2); end;");
        callablestatement.registerOutParameter(1, 2);
        callablestatement.registerOutParameter(2, -4);
        callablestatement.execute();
        fdo = callablestatement.getBytes(2);
        if(callablestatement != null)
            callablestatement.close();
        callablestatement = null;
        break MISSING_BLOCK_LABEL_86;
        Exception exception;
        exception;
        if(callablestatement != null)
            callablestatement.close();
        callablestatement = null;
        throw exception;
        return fdo;
    }

    public synchronized void setFDO(byte abyte0[])
        throws SQLException
    {
        fdo = abyte0;
    }

    public synchronized boolean getBigEndian()
        throws SQLException
    {
        if(bigEndian == null)
        {
            int ai[] = Util.toJavaUnsignedBytes(getFDO(true));
            int i = ai[6 + ai[5] + ai[6] + 5];
            int j = (byte)(i & 0x10);
            if(j < 0)
                j += 256;
            if(j > 0)
                bigEndian = Boolean.TRUE;
            else
                bigEndian = Boolean.FALSE;
        }
        return bigEndian.booleanValue();
    }

    public void setHoldability(int i)
        throws SQLException
    {
    }

    public int getHoldability()
        throws SQLException
    {
        return 1;
    }

    public synchronized Savepoint setSavepoint()
        throws SQLException
    {
        return oracleSetSavepoint();
    }

    public synchronized Savepoint setSavepoint(String s)
        throws SQLException
    {
        return oracleSetSavepoint(s);
    }

    public synchronized void rollback(Savepoint savepoint)
        throws SQLException
    {
        disallowGlobalTxnMode(122);
        if(autocommit)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(savepointStatement == null)
            savepointStatement = createStatement();
        String s = null;
        try
        {
            s = savepoint.getSavepointName();
        }
        catch(SQLException sqlexception1)
        {
            s = (new StringBuilder()).append("ORACLE_SVPT_").append(savepoint.getSavepointId()).toString();
        }
        savepointStatement.executeUpdate((new StringBuilder()).append("ROLLBACK TO ").append(s).toString());
    }

    public synchronized void releaseSavepoint(Savepoint savepoint)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Statement createStatement(int i, int j, int k)
        throws SQLException
    {
        return createStatement(i, j);
    }

    public PreparedStatement prepareStatement(String s, int i, int j, int k)
        throws SQLException
    {
        return prepareStatement(s, i, j);
    }

    public CallableStatement prepareCall(String s, int i, int j, int k)
        throws SQLException
    {
        return prepareCall(s, i, j);
    }

    public PreparedStatement prepareStatement(String s, int i)
        throws SQLException
    {
        AutoKeyInfo autokeyinfo = new AutoKeyInfo(s);
        if(i == 2 || !autokeyinfo.isInsertSqlStmt())
            return prepareStatement(s);
        if(i != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            String s1 = autokeyinfo.getNewSql();
            OraclePreparedStatement oraclepreparedstatement = (OraclePreparedStatement)prepareStatement(s1);
            oracle.jdbc.driver.OraclePreparedStatement oraclepreparedstatement1 = (oracle.jdbc.driver.OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclepreparedstatement).preparedStatement;
            oraclepreparedstatement1.isAutoGeneratedKey = true;
            oraclepreparedstatement1.autoKeyInfo = autokeyinfo;
            oraclepreparedstatement1.registerReturnParamsForAutoKey();
            return oraclepreparedstatement;
        }
    }

    public PreparedStatement prepareStatement(String s, int ai[])
        throws SQLException
    {
        AutoKeyInfo autokeyinfo = new AutoKeyInfo(s, ai);
        if(!autokeyinfo.isInsertSqlStmt())
            return prepareStatement(s);
        if(ai == null || ai.length == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            doDescribeTable(autokeyinfo);
            String s1 = autokeyinfo.getNewSql();
            OraclePreparedStatement oraclepreparedstatement = (OraclePreparedStatement)prepareStatement(s1);
            oracle.jdbc.driver.OraclePreparedStatement oraclepreparedstatement1 = (oracle.jdbc.driver.OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclepreparedstatement).preparedStatement;
            oraclepreparedstatement1.isAutoGeneratedKey = true;
            oraclepreparedstatement1.autoKeyInfo = autokeyinfo;
            oraclepreparedstatement1.registerReturnParamsForAutoKey();
            return oraclepreparedstatement;
        }
    }

    public PreparedStatement prepareStatement(String s, String as[])
        throws SQLException
    {
        AutoKeyInfo autokeyinfo = new AutoKeyInfo(s, as);
        if(!autokeyinfo.isInsertSqlStmt())
            return prepareStatement(s);
        if(as == null || as.length == 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            doDescribeTable(autokeyinfo);
            String s1 = autokeyinfo.getNewSql();
            OraclePreparedStatement oraclepreparedstatement = (OraclePreparedStatement)prepareStatement(s1);
            oracle.jdbc.driver.OraclePreparedStatement oraclepreparedstatement1 = (oracle.jdbc.driver.OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclepreparedstatement).preparedStatement;
            oraclepreparedstatement1.isAutoGeneratedKey = true;
            oraclepreparedstatement1.autoKeyInfo = autokeyinfo;
            oraclepreparedstatement1.registerReturnParamsForAutoKey();
            return oraclepreparedstatement;
        }
    }

    public synchronized OracleSavepoint oracleSetSavepoint()
        throws SQLException
    {
        disallowGlobalTxnMode(117);
        if(autocommit)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(savepointStatement == null)
            savepointStatement = createStatement();
        oracle.jdbc.driver.OracleSavepoint oraclesavepoint = new oracle.jdbc.driver.OracleSavepoint();
        String s = (new StringBuilder()).append("SAVEPOINT ORACLE_SVPT_").append(oraclesavepoint.getSavepointId()).toString();
        savepointStatement.executeUpdate(s);
        return oraclesavepoint;
    }

    public synchronized OracleSavepoint oracleSetSavepoint(String s)
        throws SQLException
    {
        disallowGlobalTxnMode(117);
        if(autocommit)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(savepointStatement == null)
            savepointStatement = createStatement();
        oracle.jdbc.driver.OracleSavepoint oraclesavepoint = new oracle.jdbc.driver.OracleSavepoint(s);
        String s1 = (new StringBuilder()).append("SAVEPOINT ").append(oraclesavepoint.getSavepointName()).toString();
        savepointStatement.executeUpdate(s1);
        return oraclesavepoint;
    }

    public synchronized void oracleRollback(OracleSavepoint oraclesavepoint)
        throws SQLException
    {
        disallowGlobalTxnMode(115);
        if(autocommit)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(savepointStatement == null)
            savepointStatement = createStatement();
        String s = null;
        try
        {
            s = oraclesavepoint.getSavepointName();
        }
        catch(SQLException sqlexception1)
        {
            s = (new StringBuilder()).append("ORACLE_SVPT_").append(oraclesavepoint.getSavepointId()).toString();
        }
        savepointStatement.executeUpdate((new StringBuilder()).append("ROLLBACK TO ").append(s).toString());
    }

    public synchronized void oracleReleaseSavepoint(OracleSavepoint oraclesavepoint)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void disallowGlobalTxnMode(int i)
        throws SQLException
    {
        if(txnMode == 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), i);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public void setTxnMode(int i)
    {
        txnMode = i;
    }

    public int getTxnMode()
    {
        return txnMode;
    }

    public synchronized Object getClientData(Object obj)
    {
        if(clientData == null)
            return null;
        else
            return clientData.get(obj);
    }

    public synchronized Object setClientData(Object obj, Object obj1)
    {
        if(clientData == null)
            clientData = new Hashtable();
        return clientData.put(obj, obj1);
    }

    public synchronized Object removeClientData(Object obj)
    {
        if(clientData == null)
            return null;
        else
            return clientData.remove(obj);
    }

    public BlobDBAccess createBlobDBAccess()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ClobDBAccess createClobDBAccess()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BfileDBAccess createBfileDBAccess()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void printState()
    {
        try
        {
            short word0 = getJdbcCsId();
            short word1 = getDbCsId();
            short word2 = getStructAttrCsId();
        }
        catch(SQLException sqlexception)
        {
            sqlexception.printStackTrace();
        }
    }

    public String getProtocolType()
    {
        return protocol;
    }

    public String getURL()
    {
        return url;
    }

    /**
     * @deprecated Method setStmtCacheSize is deprecated
     */

    public synchronized void setStmtCacheSize(int i)
        throws SQLException
    {
        setStatementCacheSize(i);
        setImplicitCachingEnabled(true);
        setExplicitCachingEnabled(true);
    }

    /**
     * @deprecated Method setStmtCacheSize is deprecated
     */

    public synchronized void setStmtCacheSize(int i, boolean flag)
        throws SQLException
    {
        setStatementCacheSize(i);
        setImplicitCachingEnabled(true);
        setExplicitCachingEnabled(true);
        clearStatementMetaData = flag;
    }

    /**
     * @deprecated Method getStmtCacheSize is deprecated
     */

    public synchronized int getStmtCacheSize()
    {
        int i = 0;
        try
        {
            i = getStatementCacheSize();
        }
        catch(SQLException sqlexception) { }
        if(i == -1)
            i = 0;
        return i;
    }

    public synchronized void setStatementCacheSize(int i)
        throws SQLException
    {
        if(statementCache == null)
            statementCache = new LRUStatementCache(i);
        else
            statementCache.resize(i);
    }

    public synchronized int getStatementCacheSize()
        throws SQLException
    {
        if(statementCache == null)
            return -1;
        else
            return statementCache.getCacheSize();
    }

    public synchronized void setImplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        if(statementCache == null)
            statementCache = new LRUStatementCache(0);
        statementCache.setImplicitCachingEnabled(flag);
    }

    public synchronized boolean getImplicitCachingEnabled()
        throws SQLException
    {
        if(statementCache == null)
            return false;
        else
            return statementCache.getImplicitCachingEnabled();
    }

    public synchronized void setExplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        if(statementCache == null)
            statementCache = new LRUStatementCache(0);
        statementCache.setExplicitCachingEnabled(flag);
    }

    public synchronized boolean getExplicitCachingEnabled()
        throws SQLException
    {
        if(statementCache == null)
            return false;
        else
            return statementCache.getExplicitCachingEnabled();
    }

    public synchronized void purgeImplicitCache()
        throws SQLException
    {
        if(statementCache != null)
            statementCache.purgeImplicitCache();
    }

    public synchronized void purgeExplicitCache()
        throws SQLException
    {
        if(statementCache != null)
            statementCache.purgeExplicitCache();
    }

    public synchronized PreparedStatement getStatementWithKey(String s)
        throws SQLException
    {
        if(statementCache != null)
        {
            oracle.jdbc.driver.OracleStatement oraclestatement = statementCache.searchExplicitCache(s);
            if(oraclestatement == null || oraclestatement.statementType == 1)
            {
                return (PreparedStatement)oraclestatement;
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        {
            return null;
        }
    }

    public synchronized CallableStatement getCallWithKey(String s)
        throws SQLException
    {
        if(statementCache != null)
        {
            oracle.jdbc.driver.OracleStatement oraclestatement = statementCache.searchExplicitCache(s);
            if(oraclestatement == null || oraclestatement.statementType == 2)
            {
                return (CallableStatement)oraclestatement;
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        {
            return null;
        }
    }

    public synchronized void cacheImplicitStatement(oracle.jdbc.driver.OraclePreparedStatement oraclepreparedstatement, String s, int i, int j)
        throws SQLException
    {
        if(statementCache == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            statementCache.addToImplicitCache(oraclepreparedstatement, s, i, j);
            return;
        }
    }

    public synchronized void cacheExplicitStatement(oracle.jdbc.driver.OraclePreparedStatement oraclepreparedstatement, String s)
        throws SQLException
    {
        if(statementCache == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            statementCache.addToExplicitCache(oraclepreparedstatement, s);
            return;
        }
    }

    public synchronized boolean isStatementCacheInitialized()
    {
        if(statementCache == null)
            return false;
        return statementCache.getCacheSize() != 0;
    }

    private BufferCacheStore getBufferCacheStore()
    {
        if(useThreadLocalBufferCache)
        {
            if(threadLocalBufferCacheStore == null)
            {
                BufferCacheStore.MAX_CACHED_BUFFER_SIZE = maxCachedBufferSize;
                threadLocalBufferCacheStore = new ThreadLocal() {

                    final PhysicalConnection this$0;

                    protected BufferCacheStore initialValue()
                    {
                        return new BufferCacheStore();
                    }

                    protected volatile Object initialValue()
                    {
                        return initialValue();
                    }

            
            {
                this$0 = PhysicalConnection.this;
                super();
            }
                }
;
            }
            return (BufferCacheStore)threadLocalBufferCacheStore.get();
        }
        if(connectionBufferCacheStore == null)
            connectionBufferCacheStore = new BufferCacheStore(maxCachedBufferSize);
        return connectionBufferCacheStore;
    }

    void cacheBuffer(byte abyte0[])
    {
        if(abyte0 != null)
        {
            BufferCacheStore buffercachestore = getBufferCacheStore();
            buffercachestore.byteBufferCache.put(abyte0);
        }
    }

    void cacheBuffer(char ac[])
    {
        if(ac != null)
        {
            BufferCacheStore buffercachestore = getBufferCacheStore();
            buffercachestore.charBufferCache.put(ac);
        }
    }

    public void cacheBufferSync(char ac[])
    {
        synchronized(this)
        {
            cacheBuffer(ac);
        }
    }

    byte[] getByteBuffer(int i)
    {
        BufferCacheStore buffercachestore = getBufferCacheStore();
        return (byte[])buffercachestore.byteBufferCache.get(Byte.TYPE, i);
    }

    char[] getCharBuffer(int i)
    {
        BufferCacheStore buffercachestore = getBufferCacheStore();
        return (char[])buffercachestore.charBufferCache.get(Character.TYPE, i);
    }

    public char[] getCharBufferSync(int i)
    {
        PhysicalConnection physicalconnection = this;
        JVM INSTR monitorenter ;
        return getCharBuffer(i);
        Exception exception;
        exception;
        throw exception;
    }

    public oracle.jdbc.internal.OracleConnection.BufferCacheStatistics getByteBufferCacheStatistics()
    {
        BufferCacheStore buffercachestore = getBufferCacheStore();
        return buffercachestore.byteBufferCache.getStatistics();
    }

    public oracle.jdbc.internal.OracleConnection.BufferCacheStatistics getCharBufferCacheStatistics()
    {
        BufferCacheStore buffercachestore = getBufferCacheStore();
        return buffercachestore.charBufferCache.getStatistics();
    }

    public synchronized void registerTAFCallback(OracleOCIFailover oracleocifailover, Object obj)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public String getDatabaseProductVersion()
        throws SQLException
    {
        if(databaseProductVersion == "")
        {
            needLine();
            databaseProductVersion = doGetDatabaseProductVersion();
        }
        return databaseProductVersion;
    }

    public synchronized boolean getReportRemarks()
    {
        return reportRemarks;
    }

    public short getVersionNumber()
        throws SQLException
    {
        if(versionNumber == -1)
            synchronized(this)
            {
                if(versionNumber == -1)
                {
                    needLine();
                    versionNumber = doGetVersionNumber();
                }
            }
        return versionNumber;
    }

    public synchronized void registerCloseCallback(OracleCloseCallback oracleclosecallback, Object obj)
    {
        closeCallback = oracleclosecallback;
        privateData = obj;
    }

    public void setCreateStatementAsRefCursor(boolean flag)
    {
    }

    public boolean getCreateStatementAsRefCursor()
    {
        return false;
    }

    public int pingDatabase()
        throws SQLException
    {
        if(lifecycle != 1)
            return -1;
        else
            return doPingDatabase();
    }

    /**
     * @deprecated Method pingDatabase is deprecated
     */

    public int pingDatabase(int i)
        throws SQLException
    {
        if(lifecycle != 1)
            return -1;
        if(i == 0)
            return pingDatabase();
        try
        {
            pingResult = -2;
            Thread thread = new Thread(new Runnable() {

                final PhysicalConnection this$0;

                public void run()
                {
                    try
                    {
                        pingResult = doPingDatabase();
                    }
                    catch(Throwable throwable) { }
                }

            
            {
                this$0 = PhysicalConnection.this;
                super();
            }
            }
);
            thread.start();
            thread.join(i * 1000);
            return pingResult;
        }
        catch(InterruptedException interruptedexception)
        {
            return -3;
        }
    }

    int doPingDatabase()
        throws SQLException
    {
        Statement statement = null;
        statement = createStatement();
        ((OracleStatement)statement).defineColumnType(1, 12, 1);
        statement.executeQuery("SELECT 'x' FROM DUAL");
        if(statement != null)
            statement.close();
        break MISSING_BLOCK_LABEL_73;
        SQLException sqlexception;
        sqlexception;
        byte byte0 = -1;
        if(statement != null)
            statement.close();
        return byte0;
        Exception exception;
        exception;
        if(statement != null)
            statement.close();
        throw exception;
        return 0;
    }

    public synchronized Map getJavaObjectTypeMap()
    {
        return javaObjectMap;
    }

    public synchronized void setJavaObjectTypeMap(Map map1)
    {
        javaObjectMap = map1;
    }

    /**
     * @deprecated Method clearClientIdentifier is deprecated
     */

    public void clearClientIdentifier(String s)
        throws SQLException
    {
        if(s != null && s.length() != 0)
        {
            String as[] = getEndToEndMetrics();
            if(as != null && s.equals(as[1]))
            {
                as[1] = null;
                setEndToEndMetrics(as, getEndToEndECIDSequenceNumber());
            }
        }
    }

    /**
     * @deprecated Method setClientIdentifier is deprecated
     */

    public void setClientIdentifier(String s)
        throws SQLException
    {
        String as[] = getEndToEndMetrics();
        if(as == null)
            as = new String[4];
        as[1] = s;
        setEndToEndMetrics(as, getEndToEndECIDSequenceNumber());
    }

    public void setSessionTimeZone(String s)
        throws SQLException
    {
        Statement statement;
        statement = null;
        Object obj = null;
        try
        {
            statement = createStatement();
            statement.executeUpdate((new StringBuilder()).append("ALTER SESSION SET TIME_ZONE = '").append(s).append("'").toString());
            if(dbTzCalendar == null)
                setDbTzCalendar(getDatabaseTimeZone());
        }
        catch(SQLException sqlexception)
        {
            throw sqlexception;
        }
        if(statement != null)
            statement.close();
        break MISSING_BLOCK_LABEL_90;
        Exception exception;
        exception;
        if(statement != null)
            statement.close();
        throw exception;
        sessionTimeZone = s;
        return;
    }

    public String getDatabaseTimeZone()
        throws SQLException
    {
        if(databaseTimeZone == null)
            databaseTimeZone = getPropertyFromDatabase("SELECT DBTIMEZONE FROM DUAL");
        return databaseTimeZone;
    }

    public String getSessionTimeZone()
    {
        return sessionTimeZone;
    }

    private static String to2DigitString(int i)
    {
        String s;
        if(i < 10)
            s = (new StringBuilder()).append("0").append(i).toString();
        else
            s = (new StringBuilder()).append("").append(i).toString();
        return s;
    }

    public String tzToOffset(String s)
    {
        if(s == null)
            return s;
        char c = s.charAt(0);
        if(c != '-' && c != '+')
        {
            TimeZone timezone = TimeZone.getTimeZone(s);
            int i = timezone.getOffset(System.currentTimeMillis());
            if(i != 0)
            {
                int j = i / 60000;
                int k = j / 60;
                j -= k * 60;
                if(i > 0)
                    s = (new StringBuilder()).append("+").append(to2DigitString(k)).append(":").append(to2DigitString(j)).toString();
                else
                    s = (new StringBuilder()).append("-").append(to2DigitString(-k)).append(":").append(to2DigitString(-j)).toString();
            } else
            {
                s = "+00:00";
            }
        }
        return s;
    }

    public String getSessionTimeZoneOffset()
        throws SQLException
    {
        String s = getPropertyFromDatabase("SELECT SESSIONTIMEZONE FROM DUAL");
        if(s != null)
            s = tzToOffset(s.trim());
        return s;
    }

    private void setDbTzCalendar(String s)
    {
        char c = s.charAt(0);
        if(c == '-' || c == '+')
            s = (new StringBuilder()).append("GMT").append(s).toString();
        TimeZone timezone = TimeZone.getTimeZone(s);
        dbTzCalendar = new GregorianCalendar(timezone);
    }

    public Calendar getDbTzCalendar()
        throws SQLException
    {
        if(dbTzCalendar == null)
            setDbTzCalendar(getDatabaseTimeZone());
        return dbTzCalendar;
    }

    public void setAccumulateBatchResult(boolean flag)
    {
        accumulateBatchResult = flag;
    }

    public boolean isAccumulateBatchResult()
    {
        return accumulateBatchResult;
    }

    public void setJ2EE13Compliant(boolean flag)
    {
        j2ee13Compliant = flag;
    }

    public boolean getJ2EE13Compliant()
    {
        return j2ee13Compliant;
    }

    public Class classForNameAndSchema(String s, String s1)
        throws ClassNotFoundException
    {
        return Class.forName(s);
    }

    public Class safelyGetClassForName(String s)
        throws ClassNotFoundException
    {
        return Class.forName(s);
    }

    public int getHeapAllocSize()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            SQLException sqlexception1 = DatabaseError.createUnsupportedFeatureSqlException();
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public int getOCIEnvHeapAllocSize()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            SQLException sqlexception1 = DatabaseError.createUnsupportedFeatureSqlException();
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public static oracle.jdbc.driver.OracleConnection unwrapCompletely(OracleConnection oracleconnection)
    {
        OracleConnection oracleconnection1 = oracleconnection;
        OracleConnection oracleconnection2 = oracleconnection1;
        do
        {
            if(oracleconnection2 == null)
                return (oracle.jdbc.driver.OracleConnection)oracleconnection1;
            oracleconnection1 = oracleconnection2;
            oracleconnection2 = oracleconnection1.unwrap();
        } while(true);
    }

    public void setWrapper(OracleConnection oracleconnection)
    {
        wrapper = oracleconnection;
    }

    public OracleConnection unwrap()
    {
        return null;
    }

    public OracleConnection getWrapper()
    {
        if(wrapper != null)
            return wrapper;
        else
            return this;
    }

    static oracle.jdbc.internal.OracleConnection _physicalConnectionWithin(Connection connection)
    {
        oracle.jdbc.driver.OracleConnection oracleconnection = null;
        if(connection != null)
            oracleconnection = unwrapCompletely((OracleConnection)connection);
        return oracleconnection;
    }

    public oracle.jdbc.internal.OracleConnection physicalConnectionWithin()
    {
        return this;
    }

    public long getTdoCState(String s, String s1)
        throws SQLException
    {
        return 0L;
    }

    public void getOracleTypeADT(OracleTypeADT oracletypeadt)
        throws SQLException
    {
    }

    public Datum toDatum(CustomDatum customdatum)
        throws SQLException
    {
        return customdatum.toDatum(this);
    }

    public short getNCharSet()
    {
        return conversion.getNCharSetId();
    }

    public ResultSet newArrayDataResultSet(Datum adatum[], long l, int i, Map map1)
        throws SQLException
    {
        return new ArrayDataResultSet(this, adatum, l, i, map1);
    }

    public ResultSet newArrayDataResultSet(ARRAY array, long l, int i, Map map1)
        throws SQLException
    {
        return new ArrayDataResultSet(this, array, l, i, map1);
    }

    public ResultSet newArrayLocatorResultSet(ArrayDescriptor arraydescriptor, byte abyte0[], long l, int i, Map map1)
        throws SQLException
    {
        return new ArrayLocatorResultSet(this, arraydescriptor, abyte0, l, i, map1);
    }

    public ResultSetMetaData newStructMetaData(StructDescriptor structdescriptor)
        throws SQLException
    {
        return new StructMetaData(structdescriptor);
    }

    public int CHARBytesToJavaChars(byte abyte0[], int i, char ac[])
        throws SQLException
    {
        int ai[] = new int[1];
        ai[0] = i;
        return conversion.CHARBytesToJavaChars(abyte0, 0, ac, 0, ai, ac.length);
    }

    public int NCHARBytesToJavaChars(byte abyte0[], int i, char ac[])
        throws SQLException
    {
        int ai[] = new int[1];
        return conversion.NCHARBytesToJavaChars(abyte0, 0, ac, 0, ai, ac.length);
    }

    public boolean IsNCharFixedWith()
    {
        return conversion.IsNCharFixedWith();
    }

    public short getDriverCharSet()
    {
        return conversion.getClientCharSet();
    }

    public int getMaxCharSize()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 58);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getMaxCharbyteSize()
    {
        return conversion.getMaxCharbyteSize();
    }

    public int getMaxNCharbyteSize()
    {
        return conversion.getMaxNCharbyteSize();
    }

    public boolean isCharSetMultibyte(short word0)
    {
        DBConversion _tmp = conversion;
        return DBConversion.isCharSetMultibyte(word0);
    }

    public int javaCharsToCHARBytes(char ac[], int i, byte abyte0[])
        throws SQLException
    {
        return conversion.javaCharsToCHARBytes(ac, i, abyte0);
    }

    public int javaCharsToNCHARBytes(char ac[], int i, byte abyte0[])
        throws SQLException
    {
        return conversion.javaCharsToNCHARBytes(ac, i, abyte0);
    }

    public abstract void getPropertyForPooledConnection(OraclePooledConnection oraclepooledconnection)
        throws SQLException;

    final void getPropertyForPooledConnection(OraclePooledConnection oraclepooledconnection, String s)
        throws SQLException
    {
        Hashtable hashtable = new Hashtable();
        hashtable.put("obj_type_map", javaObjectMap);
        Properties properties = new Properties();
        properties.put("user", userName);
        properties.put("password", s);
        properties.put("connection_url", url);
        properties.put("connect_auto_commit", (new StringBuilder()).append("").append(autocommit).toString());
        properties.put("trans_isolation", (new StringBuilder()).append("").append(txnLevel).toString());
        if(getStatementCacheSize() != -1)
        {
            properties.put("stmt_cache_size", (new StringBuilder()).append("").append(getStatementCacheSize()).toString());
            properties.put("implicit_cache_enabled", (new StringBuilder()).append("").append(getImplicitCachingEnabled()).toString());
            properties.put("explict_cache_enabled", (new StringBuilder()).append("").append(getExplicitCachingEnabled()).toString());
        }
        properties.put("defaultExecuteBatch", (new StringBuilder()).append("").append(defaultExecuteBatch).toString());
        properties.put("defaultRowPrefetch", (new StringBuilder()).append("").append(defaultRowPrefetch).toString());
        properties.put("remarksReporting", (new StringBuilder()).append("").append(reportRemarks).toString());
        properties.put("AccumulateBatchResult", (new StringBuilder()).append("").append(accumulateBatchResult).toString());
        properties.put("oracle.jdbc.J2EE13Compliant", (new StringBuilder()).append("").append(j2ee13Compliant).toString());
        properties.put("processEscapes", (new StringBuilder()).append("").append(processEscapes).toString());
        properties.put("restrictGetTables", (new StringBuilder()).append("").append(restrictGettables).toString());
        properties.put("includeSynonyms", (new StringBuilder()).append("").append(includeSynonyms).toString());
        properties.put("fixedString", (new StringBuilder()).append("").append(fixedString).toString());
        hashtable.put("connection_properties", properties);
        oraclepooledconnection.setProperties(hashtable);
    }

    public Properties getDBAccessProperties()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Properties getOCIHandles()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    abstract void logon()
        throws SQLException;

    void logoff()
        throws SQLException
    {
    }

    abstract void open(oracle.jdbc.driver.OracleStatement oraclestatement)
        throws SQLException;

    abstract void cancelOperationOnServer(boolean flag)
        throws SQLException;

    abstract void doSetAutoCommit(boolean flag)
        throws SQLException;

    abstract void doCommit(int i)
        throws SQLException;

    abstract void doRollback()
        throws SQLException;

    abstract String doGetDatabaseProductVersion()
        throws SQLException;

    abstract short doGetVersionNumber()
        throws SQLException;

    int getDefaultStreamChunkSize()
    {
        return streamChunkSize;
    }

    abstract oracle.jdbc.driver.OracleStatement RefCursorBytesToStatement(byte abyte0[], oracle.jdbc.driver.OracleStatement oraclestatement)
        throws SQLException;

    public oracle.jdbc.internal.OracleStatement refCursorCursorToStatement(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Connection getLogicalConnection(OraclePooledConnection oraclepooledconnection, boolean flag)
        throws SQLException
    {
        if(logicalConnectionAttached != null || oraclepooledconnection.getPhysicalHandle() != this)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 143);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            LogicalConnection logicalconnection = new LogicalConnection(oraclepooledconnection, this, flag);
            logicalConnectionAttached = logicalconnection;
            return logicalconnection;
        }
    }

    public void getForm(OracleTypeADT oracletypeadt, OracleTypeCLOB oracletypeclob, int i)
        throws SQLException
    {
    }

    public CLOB createClob(byte abyte0[])
        throws SQLException
    {
        Object obj = new CLOB(this, abyte0);
        if(((CLOB) (obj)).isNCLOB())
            obj = new NCLOB(((CLOB) (obj)));
        return ((CLOB) (obj));
    }

    public CLOB createClobWithUnpickledBytes(byte abyte0[])
        throws SQLException
    {
        Object obj = new CLOB(this, abyte0, true);
        if(((CLOB) (obj)).isNCLOB())
            obj = new NCLOB(((CLOB) (obj)));
        return ((CLOB) (obj));
    }

    public CLOB createClob(byte abyte0[], short word0)
        throws SQLException
    {
        if(word0 == 2)
            return new NCLOB(this, abyte0);
        else
            return new CLOB(this, abyte0, word0);
    }

    public BLOB createBlob(byte abyte0[])
        throws SQLException
    {
        return new BLOB(this, abyte0);
    }

    public BLOB createBlobWithUnpickledBytes(byte abyte0[])
        throws SQLException
    {
        return new BLOB(this, abyte0, true);
    }

    public BFILE createBfile(byte abyte0[])
        throws SQLException
    {
        return new BFILE(this, abyte0);
    }

    public ARRAY createARRAY(String s, Object obj)
        throws SQLException
    {
        ArrayDescriptor arraydescriptor = ArrayDescriptor.createDescriptor(s, this);
        return new ARRAY(arraydescriptor, this, obj);
    }

    public Array createOracleArray(String s, Object obj)
        throws SQLException
    {
        return createARRAY(s, obj);
    }

    public BINARY_DOUBLE createBINARY_DOUBLE(double d)
        throws SQLException
    {
        return new BINARY_DOUBLE(d);
    }

    public BINARY_FLOAT createBINARY_FLOAT(float f)
        throws SQLException
    {
        return new BINARY_FLOAT(f);
    }

    public DATE createDATE(Date date)
        throws SQLException
    {
        return new DATE(date);
    }

    public DATE createDATE(Time time)
        throws SQLException
    {
        return new DATE(time);
    }

    public DATE createDATE(Timestamp timestamp)
        throws SQLException
    {
        return new DATE(timestamp);
    }

    public DATE createDATE(Date date, Calendar calendar)
        throws SQLException
    {
        return new DATE(date);
    }

    public DATE createDATE(Time time, Calendar calendar)
        throws SQLException
    {
        return new DATE(time);
    }

    public DATE createDATE(Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        return new DATE(timestamp);
    }

    public DATE createDATE(String s)
        throws SQLException
    {
        return new DATE(s);
    }

    public INTERVALDS createINTERVALDS(String s)
        throws SQLException
    {
        return new INTERVALDS(s);
    }

    public INTERVALYM createINTERVALYM(String s)
        throws SQLException
    {
        return new INTERVALYM(s);
    }

    public NUMBER createNUMBER(boolean flag)
        throws SQLException
    {
        return new NUMBER(flag);
    }

    public NUMBER createNUMBER(byte byte0)
        throws SQLException
    {
        return new NUMBER(byte0);
    }

    public NUMBER createNUMBER(short word0)
        throws SQLException
    {
        return new NUMBER(word0);
    }

    public NUMBER createNUMBER(int i)
        throws SQLException
    {
        return new NUMBER(i);
    }

    public NUMBER createNUMBER(long l)
        throws SQLException
    {
        return new NUMBER(l);
    }

    public NUMBER createNUMBER(float f)
        throws SQLException
    {
        return new NUMBER(f);
    }

    public NUMBER createNUMBER(double d)
        throws SQLException
    {
        return new NUMBER(d);
    }

    public NUMBER createNUMBER(BigDecimal bigdecimal)
        throws SQLException
    {
        return new NUMBER(bigdecimal);
    }

    public NUMBER createNUMBER(BigInteger biginteger)
        throws SQLException
    {
        return new NUMBER(biginteger);
    }

    public NUMBER createNUMBER(String s, int i)
        throws SQLException
    {
        return new NUMBER(s, i);
    }

    public Array createArrayOf(String s, Object aobj[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Struct createStruct(String s, Object aobj[])
        throws SQLException
    {
        try
        {
            StructDescriptor structdescriptor = StructDescriptor.createDescriptor(s, this);
            return new STRUCT(structdescriptor, this, aobj);
        }
        catch(SQLException sqlexception)
        {
            if(sqlexception.getErrorCode() == 17049)
                removeAllDescriptor();
            throw sqlexception;
        }
    }

    public TIMESTAMP createTIMESTAMP(Date date)
        throws SQLException
    {
        return new TIMESTAMP(date);
    }

    public TIMESTAMP createTIMESTAMP(DATE date)
        throws SQLException
    {
        return new TIMESTAMP(date);
    }

    public TIMESTAMP createTIMESTAMP(Time time)
        throws SQLException
    {
        return new TIMESTAMP(time);
    }

    public TIMESTAMP createTIMESTAMP(Timestamp timestamp)
        throws SQLException
    {
        return new TIMESTAMP(timestamp);
    }

    public TIMESTAMP createTIMESTAMP(String s)
        throws SQLException
    {
        return new TIMESTAMP(s);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Date date)
        throws SQLException
    {
        return new TIMESTAMPTZ(this, date);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Date date, Calendar calendar)
        throws SQLException
    {
        return new TIMESTAMPTZ(this, date, calendar);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Time time)
        throws SQLException
    {
        return new TIMESTAMPTZ(this, time);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Time time, Calendar calendar)
        throws SQLException
    {
        return new TIMESTAMPTZ(this, time, calendar);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp timestamp)
        throws SQLException
    {
        return new TIMESTAMPTZ(this, timestamp);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        return new TIMESTAMPTZ(this, timestamp, calendar);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(String s)
        throws SQLException
    {
        return new TIMESTAMPTZ(this, s);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(String s, Calendar calendar)
        throws SQLException
    {
        return new TIMESTAMPTZ(this, s, calendar);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(DATE date)
        throws SQLException
    {
        return new TIMESTAMPTZ(this, date);
    }

    public TIMESTAMPLTZ createTIMESTAMPLTZ(Date date, Calendar calendar)
        throws SQLException
    {
        return new TIMESTAMPLTZ(this, calendar, date);
    }

    public TIMESTAMPLTZ createTIMESTAMPLTZ(Time time, Calendar calendar)
        throws SQLException
    {
        return new TIMESTAMPLTZ(this, calendar, time);
    }

    public TIMESTAMPLTZ createTIMESTAMPLTZ(Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        return new TIMESTAMPLTZ(this, calendar, timestamp);
    }

    public TIMESTAMPLTZ createTIMESTAMPLTZ(String s, Calendar calendar)
        throws SQLException
    {
        return new TIMESTAMPLTZ(this, calendar, s);
    }

    public TIMESTAMPLTZ createTIMESTAMPLTZ(DATE date, Calendar calendar)
        throws SQLException
    {
        return new TIMESTAMPLTZ(this, calendar, date);
    }

    public abstract BLOB createTemporaryBlob(Connection connection, boolean flag, int i)
        throws SQLException;

    public abstract CLOB createTemporaryClob(Connection connection, boolean flag, int i, short word0)
        throws SQLException;

    public Blob createBlob()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return createTemporaryBlob(this, true, 10);
        }
    }

    public Clob createClob()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return createTemporaryClob(this, true, 10, (short)1);
        }
    }

    public NClob createNClob()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return (NClob)createTemporaryClob(this, true, 10, (short)2);
        }
    }

    public SQLXML createSQLXML()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return (SQLXML)new XMLType(this, (String)null);
        }
    }

    public boolean isDescriptorSharable(oracle.jdbc.internal.OracleConnection oracleconnection)
        throws SQLException
    {
        PhysicalConnection physicalconnection = this;
        PhysicalConnection physicalconnection1 = (PhysicalConnection)oracleconnection.getPhysicalConnection();
        return physicalconnection == physicalconnection1 || physicalconnection.url.equals(physicalconnection1.url) || physicalconnection1.protocol != null && physicalconnection1.protocol.equals("kprb");
    }

    boolean useLittleEndianSetCHARBinder()
        throws SQLException
    {
        return false;
    }

    public void setPlsqlWarnings(String s)
        throws SQLException
    {
        String s1;
        String s2;
        Statement statement;
        if(s == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(s != null && (s = s.trim()).length() > 0 && !OracleSql.isValidPlsqlWarning(s))
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        s1 = (new StringBuilder()).append("ALTER SESSION SET PLSQL_WARNINGS=").append(s).toString();
        s2 = "ALTER SESSION SET EVENTS='10933 TRACE NAME CONTEXT LEVEL 32768'";
        statement = null;
        statement = createStatement(-1, -1);
        statement.execute(s1);
        if(s.equals("'DISABLE:ALL'"))
        {
            plsqlCompilerWarnings = false;
        } else
        {
            statement.execute(s2);
            plsqlCompilerWarnings = true;
        }
        if(statement != null)
            statement.close();
        break MISSING_BLOCK_LABEL_170;
        Exception exception;
        exception;
        if(statement != null)
            statement.close();
        throw exception;
    }

    void internalClose()
        throws SQLException
    {
        lifecycle = 4;
        oracle.jdbc.driver.OracleStatement oraclestatement2;
        for(oracle.jdbc.driver.OracleStatement oraclestatement = statements; oraclestatement != null; oraclestatement = oraclestatement2)
        {
            oraclestatement2 = oraclestatement.nextChild;
            if(oraclestatement.serverCursor)
            {
                oraclestatement.internalClose();
                removeStatement(oraclestatement);
            }
        }

        oracle.jdbc.driver.OracleStatement oraclestatement3;
        for(oracle.jdbc.driver.OracleStatement oraclestatement1 = statements; oraclestatement1 != null; oraclestatement1 = oraclestatement3)
        {
            oraclestatement3 = oraclestatement1.next;
            oraclestatement1.internalClose();
        }

        statements = null;
    }

    public XAResource getXAResource()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 164);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    protected void doDescribeTable(AutoKeyInfo autokeyinfo)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setApplicationContext(String s, String s1, String s2)
        throws SQLException
    {
        if(s == null || s1 == null || s2 == null)
            throw new NullPointerException();
        if(s.equals(""))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(s.compareToIgnoreCase("CLIENTCONTEXT") != 0)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 174);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(s1.length() > 30)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 171);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        if(s2.length() > 4000)
        {
            SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 172);
            sqlexception3.fillInStackTrace();
            throw sqlexception3;
        } else
        {
            doSetApplicationContext(s, s1, s2);
            return;
        }
    }

    void doSetApplicationContext(String s, String s1, String s2)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void clearAllApplicationContext(String s)
        throws SQLException
    {
        if(s == null)
            throw new NullPointerException();
        if(s.equals(""))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            doClearAllApplicationContext(s);
            return;
        }
    }

    void doClearAllApplicationContext(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public byte[] createLightweightSession(String s, KeywordValueLong akeywordvaluelong[], int i, KeywordValueLong akeywordvaluelong1[][], int ai[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void executeLightweightSessionRoundtrip(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j, KeywordValueLong akeywordvaluelong1[][], int ai[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void executeLightweightSessionPiggyback(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void doXSNamespaceOp(oracle.jdbc.internal.OracleConnection.XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[], XSNamespace axsnamespace1[][])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void doXSNamespaceOp(oracle.jdbc.internal.OracleConnection.XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void enqueue(String s, AQEnqueueOptions aqenqueueoptions, AQMessage aqmessage)
        throws SQLException
    {
        AQMessageI aqmessagei = (AQMessageI)aqmessage;
        byte abyte0[][] = new byte[1][];
        doEnqueue(s, aqenqueueoptions, aqmessagei.getMessagePropertiesI(), aqmessagei.getPayloadTOID(), aqmessagei.getPayload(), abyte0, aqmessagei.isRAWPayload());
        if(abyte0[0] != null)
            aqmessagei.setMessageId(abyte0[0]);
    }

    public AQMessage dequeue(String s, AQDequeueOptions aqdequeueoptions, byte abyte0[])
        throws SQLException
    {
        byte abyte1[][] = new byte[1][];
        AQMessagePropertiesI aqmessagepropertiesi = new AQMessagePropertiesI();
        byte abyte2[][] = new byte[1][];
        boolean flag = false;
        flag = doDequeue(s, aqdequeueoptions, aqmessagepropertiesi, abyte0, abyte2, abyte1, AQMessageI.compareToid(abyte0, TypeDescriptor.RAWTOID));
        AQMessageI aqmessagei = null;
        if(flag)
        {
            aqmessagei = new AQMessageI(aqmessagepropertiesi, this);
            aqmessagei.setPayload(abyte2[0], abyte0);
            aqmessagei.setMessageId(abyte1[0]);
        }
        return aqmessagei;
    }

    public AQMessage dequeue(String s, AQDequeueOptions aqdequeueoptions, String s1)
        throws SQLException
    {
        byte abyte0[] = null;
        TypeDescriptor typedescriptor = null;
        if("RAW".equals(s1) || "SYS.RAW".equals(s1))
            abyte0 = TypeDescriptor.RAWTOID;
        else
        if("SYS.ANYDATA".equals(s1))
            abyte0 = TypeDescriptor.ANYDATATOID;
        else
        if("SYS.XMLTYPE".equals(s1))
        {
            abyte0 = TypeDescriptor.XMLTYPETOID;
        } else
        {
            typedescriptor = TypeDescriptor.getTypeDescriptor(s1, this);
            abyte0 = ((OracleTypeADT)typedescriptor.getPickler()).getTOID();
        }
        AQMessageI aqmessagei = (AQMessageI)dequeue(s, aqdequeueoptions, abyte0);
        if(aqmessagei != null)
        {
            aqmessagei.setTypeName(s1);
            aqmessagei.setTypeDescriptor(typedescriptor);
        }
        return aqmessagei;
    }

    synchronized void doEnqueue(String s, AQEnqueueOptions aqenqueueoptions, AQMessagePropertiesI aqmessagepropertiesi, byte abyte0[], byte abyte1[], byte abyte2[][], boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    synchronized boolean doDequeue(String s, AQDequeueOptions aqdequeueoptions, AQMessagePropertiesI aqmessagepropertiesi, byte abyte0[], byte abyte1[][], byte abyte2[][], boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    /**
     * @deprecated Method isV8Compatible is deprecated
     */

    public boolean isV8Compatible()
        throws SQLException
    {
        return mapDateToTimestamp;
    }

    public boolean getMapDateToTimestamp()
    {
        return mapDateToTimestamp;
    }

    public byte getInstanceProperty(oracle.jdbc.internal.OracleConnection.InstanceProperty instanceproperty)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public AQNotificationRegistration[] registerAQNotification(String as[], Properties aproperties[], Properties properties)
        throws SQLException
    {
        String s = readNTFlocalhost(properties);
        int i = readNTFtcpport(properties);
        NTFAQRegistration antfaqregistration[] = doRegisterAQNotification(as, s, i, aproperties);
        return (AQNotificationRegistration[])antfaqregistration;
    }

    NTFAQRegistration[] doRegisterAQNotification(String as[], String s, int i, Properties aproperties[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void unregisterAQNotification(AQNotificationRegistration aqnotificationregistration)
        throws SQLException
    {
        NTFAQRegistration ntfaqregistration = (NTFAQRegistration)aqnotificationregistration;
        doUnregisterAQNotification(ntfaqregistration);
    }

    void doUnregisterAQNotification(NTFAQRegistration ntfaqregistration)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    private String readNTFlocalhost(Properties properties)
        throws SQLException
    {
        String s = null;
        try
        {
            s = properties.getProperty("NTF_LOCAL_HOST", InetAddress.getLocalHost().getHostAddress());
        }
        catch(UnknownHostException unknownhostexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 240);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        catch(SecurityException securityexception)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 241);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        return s;
    }

    private int readNTFtcpport(Properties properties)
        throws SQLException
    {
        int i = 0;
        try
        {
            i = Integer.parseInt(properties.getProperty("NTF_LOCAL_TCP_PORT", "0"));
            if(i < 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(NumberFormatException numberformatexception)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        return i;
    }

    int readNTFtimeout(Properties properties)
        throws SQLException
    {
        int i = 0;
        try
        {
            i = Integer.parseInt(properties.getProperty("NTF_TIMEOUT", "0"));
        }
        catch(NumberFormatException numberformatexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 243);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return i;
    }

    public DatabaseChangeRegistration registerDatabaseChangeNotification(Properties properties)
        throws SQLException
    {
        String s = readNTFlocalhost(properties);
        int i = readNTFtcpport(properties);
        int j = readNTFtimeout(properties);
        int k = 0;
        try
        {
            k = Integer.parseInt(properties.getProperty("DCN_NOTIFY_CHANGELAG", "0"));
        }
        catch(NumberFormatException numberformatexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 244);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        NTFDCNRegistration ntfdcnregistration = doRegisterDatabaseChangeNotification(s, i, properties, j, k);
        ntfManager.addRegistration(ntfdcnregistration);
        return ntfdcnregistration;
    }

    NTFDCNRegistration doRegisterDatabaseChangeNotification(String s, int i, Properties properties, int j, int k)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public DatabaseChangeRegistration getDatabaseChangeRegistration(int i)
        throws SQLException
    {
        NTFDCNRegistration ntfdcnregistration = new NTFDCNRegistration(instanceName, i, userName, versionNumber);
        return ntfdcnregistration;
    }

    public void unregisterDatabaseChangeNotification(DatabaseChangeRegistration databasechangeregistration)
        throws SQLException
    {
        NTFDCNRegistration ntfdcnregistration = (NTFDCNRegistration)databasechangeregistration;
        if(ntfdcnregistration.getDatabaseName().compareToIgnoreCase(instanceName) != 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 245);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            doUnregisterDatabaseChangeNotification(ntfdcnregistration);
            return;
        }
    }

    void doUnregisterDatabaseChangeNotification(NTFDCNRegistration ntfdcnregistration)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void unregisterDatabaseChangeNotification(int i)
        throws SQLException
    {
        String s = null;
        try
        {
            s = InetAddress.getLocalHost().getHostAddress();
        }
        catch(Exception exception) { }
        unregisterDatabaseChangeNotification(i, s, 47632);
    }

    public void unregisterDatabaseChangeNotification(int i, String s, int j)
        throws SQLException
    {
        String s1 = (new StringBuilder()).append("(ADDRESS=(PROTOCOL=tcp)(HOST=").append(s).append(")(PORT=").append(j).append("))?PR=0").toString();
        unregisterDatabaseChangeNotification(i, s1);
    }

    public void unregisterDatabaseChangeNotification(long l, String s)
        throws SQLException
    {
        doUnregisterDatabaseChangeNotification(l, s);
    }

    void doUnregisterDatabaseChangeNotification(long l, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void addXSEventListener(XSEventListener xseventlistener)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void addXSEventListener(XSEventListener xseventlistener, Executor executor)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void removeXSEventListener(XSEventListener xseventlistener)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public TypeDescriptor[] getAllTypeDescriptorsInCurrentSchema()
        throws SQLException
    {
        Statement statement;
        Object obj = null;
        statement = null;
        TypeDescriptor atypedescriptor[];
        try
        {
            statement = createStatement();
            ResultSet resultset = statement.executeQuery("SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info())");
            atypedescriptor = getTypeDescriptorsFromResultSet(resultset);
            resultset.close();
        }
        catch(SQLException sqlexception)
        {
            if(sqlexception.getErrorCode() == 904)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            } else
            {
                throw sqlexception;
            }
        }
        if(statement != null)
            statement.close();
        break MISSING_BLOCK_LABEL_93;
        Exception exception;
        exception;
        if(statement != null)
            statement.close();
        throw exception;
        return atypedescriptor;
    }

    public TypeDescriptor[] getTypeDescriptorsFromListInCurrentSchema(String as[])
        throws SQLException
    {
        String s;
        PreparedStatement preparedstatement;
        s = "SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info(?))";
        Object obj = null;
        preparedstatement = null;
        TypeDescriptor atypedescriptor[];
        try
        {
            preparedstatement = prepareStatement(s);
            int i = as.length;
            StringBuffer stringbuffer = new StringBuffer(i * 8);
            for(int j = 0; j < i; j++)
            {
                stringbuffer.append(as[j]);
                if(j < i - 1)
                    stringbuffer.append(',');
            }

            preparedstatement.setString(1, stringbuffer.toString());
            ResultSet resultset = preparedstatement.executeQuery();
            atypedescriptor = getTypeDescriptorsFromResultSet(resultset);
            resultset.close();
        }
        catch(SQLException sqlexception)
        {
            if(sqlexception.getErrorCode() == 904)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            } else
            {
                throw sqlexception;
            }
        }
        if(preparedstatement != null)
            preparedstatement.close();
        break MISSING_BLOCK_LABEL_182;
        Exception exception;
        exception;
        if(preparedstatement != null)
            preparedstatement.close();
        throw exception;
        return atypedescriptor;
    }

    public TypeDescriptor[] getTypeDescriptorsFromList(String as[][])
        throws SQLException
    {
        PreparedStatement preparedstatement;
        StringBuffer stringbuffer;
        StringBuffer stringbuffer1;
        Object obj = null;
        preparedstatement = null;
        int i = as.length;
        stringbuffer = new StringBuffer(i * 8);
        stringbuffer1 = new StringBuffer(i * 8);
        for(int j = 0; j < i; j++)
        {
            stringbuffer.append(as[j][0]);
            stringbuffer1.append(as[j][1]);
            if(j < i - 1)
            {
                stringbuffer.append(',');
                stringbuffer1.append(',');
            }
        }

        TypeDescriptor atypedescriptor[];
        try
        {
            String s = "SELECT schema_name, typename, typoid, typecode, version, tds FROM TABLE(private_jdbc.Get_All_Type_Shape_Info(?,?))";
            preparedstatement = prepareStatement(s);
            preparedstatement.setString(1, stringbuffer.toString());
            preparedstatement.setString(2, stringbuffer1.toString());
            ResultSet resultset = preparedstatement.executeQuery();
            atypedescriptor = getTypeDescriptorsFromResultSet(resultset);
            resultset.close();
        }
        catch(SQLException sqlexception)
        {
            if(sqlexception.getErrorCode() == 904)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            } else
            {
                throw sqlexception;
            }
        }
        if(preparedstatement != null)
            preparedstatement.close();
        break MISSING_BLOCK_LABEL_224;
        Exception exception;
        exception;
        if(preparedstatement != null)
            preparedstatement.close();
        throw exception;
        return atypedescriptor;
    }

    TypeDescriptor[] getTypeDescriptorsFromResultSet(ResultSet resultset)
        throws SQLException
    {
        ArrayList arraylist = new ArrayList();
        do
        {
            if(!resultset.next())
                break;
            String s = resultset.getString(1);
            String s1 = resultset.getString(2);
            byte abyte0[] = resultset.getBytes(3);
            String s2 = resultset.getString(4);
            int j = resultset.getInt(5);
            byte abyte1[] = resultset.getBytes(6);
            SQLName sqlname = new SQLName(s, s1, this);
            if(s2.equals("OBJECT"))
            {
                StructDescriptor structdescriptor = StructDescriptor.createDescriptor(sqlname, abyte0, j, abyte1, this);
                putDescriptor(abyte0, structdescriptor);
                putDescriptor(structdescriptor.getName(), structdescriptor);
                arraylist.add(structdescriptor);
            } else
            if(s2.equals("COLLECTION"))
            {
                ArrayDescriptor arraydescriptor = ArrayDescriptor.createDescriptor(sqlname, abyte0, j, abyte1, this);
                putDescriptor(abyte0, arraydescriptor);
                putDescriptor(arraydescriptor.getName(), arraydescriptor);
                arraylist.add(arraydescriptor);
            }
        } while(true);
        TypeDescriptor atypedescriptor[] = new TypeDescriptor[arraylist.size()];
        for(int i = 0; i < arraylist.size(); i++)
        {
            TypeDescriptor typedescriptor = (TypeDescriptor)(TypeDescriptor)arraylist.get(i);
            atypedescriptor[i] = typedescriptor;
        }

        return atypedescriptor;
    }

    public synchronized boolean isUsable()
    {
        return isUsable;
    }

    public void setUsable(boolean flag)
    {
        isUsable = flag;
    }

    void queryFCFProperties(Properties properties)
        throws SQLException
    {
        Statement statement;
        ResultSet resultset;
        String s;
        statement = null;
        resultset = null;
        s = "select sys_context('userenv', 'instance_name'),sys_context('userenv', 'server_host'),sys_context('userenv', 'service_name'),sys_context('userenv', 'db_unique_name') from dual";
        statement = createStatement();
        statement.setFetchSize(1);
        resultset = statement.executeQuery(s);
        do
        {
            if(!resultset.next())
                break;
            String s1 = null;
            s1 = resultset.getString(1);
            if(s1 != null)
                properties.put("INSTANCE_NAME", s1.trim());
            s1 = resultset.getString(2);
            if(s1 != null)
                properties.put("SERVER_HOST", s1.trim());
            s1 = resultset.getString(3);
            if(s1 != null)
                properties.put("SERVICE_NAME", s1.trim());
            s1 = resultset.getString(4);
            if(s1 != null)
                properties.put("DATABASE_NAME", s1.trim());
        } while(true);
        if(resultset != null)
            resultset.close();
        if(statement != null)
            statement.close();
        break MISSING_BLOCK_LABEL_201;
        Exception exception;
        exception;
        if(resultset != null)
            resultset.close();
        if(statement != null)
            statement.close();
        throw exception;
    }

    public void setDefaultTimeZone(TimeZone timezone)
        throws SQLException
    {
        defaultTimeZone = timezone;
    }

    public TimeZone getDefaultTimeZone()
        throws SQLException
    {
        return defaultTimeZone;
    }

    public int getTimezoneVersionNumber()
        throws SQLException
    {
        return timeZoneVersionNumber;
    }

    public TIMEZONETAB getTIMEZONETAB()
        throws SQLException
    {
        if(timeZoneTab == null)
            timeZoneTab = TIMEZONETAB.getInstance(getTimezoneVersionNumber());
        return timeZoneTab;
    }

    public boolean isDataInLocatorEnabled()
        throws SQLException
    {
        return (getVersionNumber() >= 10200) & (getVersionNumber() < 11000) & enableReadDataInLocator | overrideEnableReadDataInLocator;
    }

    public boolean isLobStreamPosStandardCompliant()
        throws SQLException
    {
        return lobStreamPosStandardCompliant;
    }

    public long getCurrentSCN()
        throws SQLException
    {
        return doGetCurrentSCN();
    }

    long doGetCurrentSCN()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void doSetSnapshotSCN(long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public EnumSet getTransactionState()
        throws SQLException
    {
        return doGetTransactionState();
    }

    EnumSet doGetTransactionState()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean isConnectionSocketKeepAlive()
        throws SocketException, SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }


}
