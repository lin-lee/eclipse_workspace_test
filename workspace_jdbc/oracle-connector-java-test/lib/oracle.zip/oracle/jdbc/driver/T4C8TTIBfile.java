// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C8TTIBfile.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.driver:
//            T4C8TTILob, DatabaseError, T4CConnection

final class T4C8TTIBfile extends T4C8TTILob
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C8TTIBfile(T4CConnection t4cconnection)
    {
        super(t4cconnection);
    }

    Datum createTemporaryLob(Connection connection, boolean flag, int i)
        throws SQLException, IOException
    {
        Object obj = null;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), "cannot create a temporary BFILE", -1);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    boolean open(byte abyte0[], int i)
        throws SQLException, IOException
    {
        boolean flag = false;
        flag = _open(abyte0, 11, 256);
        return flag;
    }

    boolean close(byte abyte0[])
        throws SQLException, IOException
    {
        boolean flag = false;
        flag = _close(abyte0, 512);
        return flag;
    }

    boolean isOpen(byte abyte0[])
        throws SQLException, IOException
    {
        boolean flag = _isOpen(abyte0, 1024);
        return flag;
    }

    boolean doesExist(byte abyte0[])
        throws SQLException, IOException
    {
        boolean flag = false;
        initializeLobdef();
        sourceLobLocator = abyte0;
        lobops = 2048L;
        nullO2U = true;
        doRPC();
        flag = lobnull;
        return flag;
    }

}
