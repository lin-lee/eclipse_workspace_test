// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;


// Referenced classes of package oracle.jdbc.driver:
//            Binder, OraclePreparedStatementReadOnly, OraclePreparedStatement

class SetCHARBinder extends Binder
{

    Binder theSetCHARCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    static void init(Binder binder)
    {
        binder.type = 996;
        binder.bytelen = 0;
    }

    SetCHARBinder()
    {
        theSetCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticSetCHARCopyingBinder;
        init(this);
    }

    Binder copyingBinder()
    {
        return theSetCHARCopyingBinder;
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
    {
        byte abyte1[][] = oraclepreparedstatement.parameterDatum[k];
        byte abyte2[] = abyte1[i];
        if(flag)
            abyte1[i] = null;
        if(abyte2 == null)
        {
            aword0[i2] = -1;
        } else
        {
            aword0[i2] = 0;
            int j2 = abyte2.length;
            ac[k1] = (char)j2;
            if(j2 > 65532)
                aword0[l1] = -2;
            else
                aword0[l1] = (short)(j2 + 2);
            int k2 = k1 + (j2 >> 1);
            if(j2 % 2 == 1)
                ac[k2 + 1] = (char)(abyte2[--j2] << 8);
            while(j2 > 0) 
            {
                j2 -= 2;
                ac[k2--] = (char)(abyte2[j2] << 8 | abyte2[j2 + 1] & 0xff);
            }
        }
    }

    short updateInoutIndicatorValue(short word0)
    {
        return (short)(word0 | 4);
    }

}
