// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleClobReader.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.CLOB;

// Referenced classes of package oracle.jdbc.driver:
//            PhysicalConnection, DatabaseError, DBConversion

class OracleClobReader extends Reader
{

    CLOB clob;
    DBConversion dbConversion;
    long lobOffset;
    long markedChar;
    char resizableBuffer[];
    int initialBufferSize;
    int currentBufferSize;
    int pos;
    int count;
    long maxPosition;
    boolean isClosed;
    boolean endOfStream;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleClobReader(CLOB clob1)
        throws SQLException
    {
        this(clob1, ((PhysicalConnection)clob1.getInternalConnection()).getDefaultStreamChunkSize() / 3);
    }

    public OracleClobReader(CLOB clob1, int i)
        throws SQLException
    {
        this(clob1, i, 1L);
    }

    public OracleClobReader(CLOB clob1, int i, long l)
        throws SQLException
    {
        maxPosition = 0x7fffffffffffffffL;
        if(clob1 == null || i <= 0 || clob1.getInternalConnection() == null || l < 1L)
        {
            throw new IllegalArgumentException();
        } else
        {
            dbConversion = ((PhysicalConnection)clob1.getInternalConnection()).conversion;
            clob = clob1;
            lobOffset = l;
            markedChar = -1L;
            resizableBuffer = null;
            initialBufferSize = i;
            currentBufferSize = 0;
            pos = count = 0;
            isClosed = false;
            return;
        }
    }

    public OracleClobReader(CLOB clob1, int i, long l, long l1)
        throws SQLException
    {
        this(clob1, i, l);
        maxPosition = l + l1;
    }

    public int read(char ac[], int i, int j)
        throws IOException
    {
        ensureOpen();
        int k = i;
        int l = k + Math.min(j, ac.length - i);
        if(!needChars(l - k))
            return -1;
        for(k += writeChars(ac, k, l - k); k < l && needChars(l - k); k += writeChars(ac, k, l - k));
        return k - i;
    }

    protected boolean needChars(int i)
        throws IOException
    {
        ensureOpen();
        if(pos >= count)
        {
            if(!endOfStream)
                try
                {
                    if(i > currentBufferSize)
                    {
                        currentBufferSize = Math.max(i, initialBufferSize);
                        PhysicalConnection physicalconnection = (PhysicalConnection)clob.getInternalConnection();
                        synchronized(physicalconnection)
                        {
                            resizableBuffer = physicalconnection.getCharBuffer(currentBufferSize);
                        }
                    }
                    int j = currentBufferSize;
                    if(maxPosition - lobOffset < (long)currentBufferSize)
                        j = (int)(maxPosition - lobOffset);
                    count = clob.getChars(lobOffset, j, resizableBuffer);
                    if(count < currentBufferSize)
                        endOfStream = true;
                    if(count > 0)
                    {
                        pos = 0;
                        lobOffset += count;
                        if(lobOffset >= maxPosition)
                            endOfStream = true;
                        return true;
                    }
                }
                catch(SQLException sqlexception)
                {
                    IOException ioexception = DatabaseError.createIOException(sqlexception);
                    ioexception.fillInStackTrace();
                    throw ioexception;
                }
            return false;
        } else
        {
            return true;
        }
    }

    protected int writeChars(char ac[], int i, int j)
    {
        int k = Math.min(j, count - pos);
        System.arraycopy(resizableBuffer, pos, ac, i, k);
        pos += k;
        return k;
    }

    public boolean ready()
        throws IOException
    {
        ensureOpen();
        return pos < count;
    }

    public void close()
        throws IOException
    {
        if(isClosed)
            return;
        try
        {
            isClosed = true;
            PhysicalConnection physicalconnection = (PhysicalConnection)clob.getInternalConnection();
            synchronized(physicalconnection)
            {
                if(resizableBuffer != null)
                {
                    physicalconnection.cacheBuffer(resizableBuffer);
                    resizableBuffer = null;
                }
            }
        }
        catch(SQLException sqlexception)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
    }

    void ensureOpen()
        throws IOException
    {
        try
        {
            if(isClosed)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, null);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(SQLException sqlexception1)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception1);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
    }

    public boolean markSupported()
    {
        return true;
    }

    public void mark(int i)
        throws IOException
    {
        if(i < 0)
        {
            throw new IllegalArgumentException(DatabaseError.findMessage(195, null));
        } else
        {
            markedChar = (lobOffset - (long)count) + (long)pos;
            return;
        }
    }

    public void reset()
        throws IOException
    {
        ensureOpen();
        if(markedChar < 0L)
        {
            throw new IOException(DatabaseError.findMessage(195, null));
        } else
        {
            lobOffset = markedChar;
            pos = count;
            endOfStream = false;
            return;
        }
    }

    public long skip(long l)
        throws IOException
    {
        ensureOpen();
        long l1 = 0L;
        if((long)(count - pos) >= l)
        {
            pos += l;
            l1 += l;
        } else
        {
            l1 += count - pos;
            pos = count;
            try
            {
                long l2 = (clob.length() - lobOffset) + 1L;
                if(l2 >= l - l1)
                {
                    lobOffset += l - l1;
                    l1 += l - l1;
                } else
                {
                    lobOffset += l2;
                    l1 += l2;
                }
            }
            catch(SQLException sqlexception)
            {
                IOException ioexception = DatabaseError.createIOException(sqlexception);
                ioexception.fillInStackTrace();
                throw ioexception;
            }
        }
        return l1;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        try
        {
            return clob.getInternalConnection();
        }
        catch(Exception exception)
        {
            return null;
        }
    }

}
