// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleClobWriter.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.Writer;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.CLOB;

// Referenced classes of package oracle.jdbc.driver:
//            PhysicalConnection, DatabaseError, DBConversion

class OracleClobWriter extends Writer
{

    DBConversion dbConversion;
    CLOB clob;
    long lobOffset;
    char charBuf[];
    byte nativeBuf[];
    int pos;
    int count;
    int chunkSize;
    boolean isClosed;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleClobWriter(CLOB clob1, int i)
        throws SQLException
    {
        this(clob1, i, 1L);
    }

    public OracleClobWriter(CLOB clob1, int i, long l)
        throws SQLException
    {
        if(clob1 == null || i <= 0 || clob1.getJavaSqlConnection() == null || l < 1L)
        {
            throw new IllegalArgumentException();
        } else
        {
            dbConversion = ((PhysicalConnection)clob1.getInternalConnection()).conversion;
            clob = clob1;
            lobOffset = l;
            charBuf = new char[i];
            nativeBuf = new byte[i * 3];
            pos = count = 0;
            chunkSize = i;
            isClosed = false;
            return;
        }
    }

    public void write(char ac[], int i, int j)
        throws IOException
    {
        int k;
        int l;
label0:
        {
            synchronized(lock)
            {
                ensureOpen();
                k = i;
                l = Math.min(j, ac.length - i);
                if(l < 2 * chunkSize)
                    break label0;
                if(count > 0)
                    flushBuffer();
                try
                {
                    lobOffset += clob.putChars(lobOffset, ac, i, l);
                }
                catch(SQLException sqlexception)
                {
                    IOException ioexception = DatabaseError.createIOException(sqlexception);
                    ioexception.fillInStackTrace();
                    throw ioexception;
                }
            }
            return;
        }
        int i1 = k + l;
        do
        {
            if(k >= i1)
                break;
            int j1 = Math.min(chunkSize - count, i1 - k);
            System.arraycopy(ac, k, charBuf, count, j1);
            k += j1;
            count += j1;
            if(count >= chunkSize)
                flushBuffer();
        } while(true);
        obj;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
    }

    public void flush()
        throws IOException
    {
        synchronized(lock)
        {
            ensureOpen();
            flushBuffer();
        }
    }

    public void close()
        throws IOException
    {
        synchronized(lock)
        {
            flushBuffer();
            isClosed = true;
        }
    }

    private void flushBuffer()
        throws IOException
    {
        synchronized(lock)
        {
            try
            {
                if(count > 0)
                {
                    lobOffset += clob.putChars(lobOffset, charBuf, 0, count);
                    count = 0;
                }
            }
            catch(SQLException sqlexception)
            {
                IOException ioexception = DatabaseError.createIOException(sqlexception);
                ioexception.fillInStackTrace();
                throw ioexception;
            }
        }
    }

    void ensureOpen()
        throws IOException
    {
        try
        {
            if(isClosed)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, null);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(SQLException sqlexception1)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception1);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        try
        {
            return clob.getInternalConnection();
        }
        catch(Exception exception)
        {
            return null;
        }
    }

}
