// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;


// Referenced classes of package oracle.jdbc.driver:
//            DatumBinder, Binder, OraclePreparedStatementReadOnly

class BINARY_DOUBLEBinder extends DatumBinder
{

    Binder theBINARY_DOUBLECopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    static void init(Binder binder)
    {
        binder.type = 101;
        binder.bytelen = 8;
    }

    BINARY_DOUBLEBinder()
    {
        theBINARY_DOUBLECopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLECopyingBinder;
        init(this);
    }

    Binder copyingBinder()
    {
        return theBINARY_DOUBLECopyingBinder;
    }

}
