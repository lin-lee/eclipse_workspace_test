// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   BufferCache.java

package oracle.jdbc.driver;

import java.lang.ref.SoftReference;
import java.lang.reflect.Array;
import oracle.jdbc.internal.OracleConnection;

class BufferCache
{
    private static final class InternalStatistics
        implements oracle.jdbc.internal.OracleConnection.BufferCacheStatistics
    {

        private static int CACHE_COUNT = 0;
        private final int cacheId;
        private final int sizes[];
        private final int nCacheHit[];
        private final int nCacheMiss[];
        private int nRequestTooBig;
        private final int nBufferCached[];
        private final int nBucketFull[];
        private final int nRefCleared[];
        private int nCacheTooBig;

        void cacheHit(int i)
        {
            nCacheHit[i]++;
        }

        void cacheMiss(int i)
        {
            nCacheMiss[i]++;
        }

        void requestTooBig()
        {
            nRequestTooBig++;
        }

        void bufferCached(int i)
        {
            nBufferCached[i]++;
        }

        void bucketFull(int i)
        {
            nBucketFull[i]++;
        }

        void refCleared(int i)
        {
            nRefCleared[i]++;
        }

        void cacheTooBig()
        {
            nCacheTooBig++;
        }

        public int getId()
        {
            return cacheId;
        }

        public int[] getBufferSizes()
        {
            int ai[] = new int[sizes.length];
            System.arraycopy(sizes, 0, ai, 0, sizes.length);
            return ai;
        }

        public int getCacheHits(int i)
        {
            return nCacheHit[i];
        }

        public int getCacheMisses(int i)
        {
            return nCacheMiss[i];
        }

        public int getRequestsTooBig()
        {
            return nRequestTooBig;
        }

        public int getBuffersCached(int i)
        {
            return nBufferCached[i];
        }

        public int getBucketsFull(int i)
        {
            return nBucketFull[i];
        }

        public int getReferencesCleared(int i)
        {
            return nRefCleared[i];
        }

        public int getTooBigToCache()
        {
            return nCacheTooBig;
        }

        public String toString()
        {
            int i = 0;
            int j = 0;
            int k = 0;
            int l = 0;
            int i1 = 0;
            for(int j1 = 0; j1 < sizes.length; j1++)
            {
                i += nCacheHit[j1];
                j += nCacheMiss[j1];
                k += nBufferCached[j1];
                l += nBucketFull[j1];
                i1 += nRefCleared[j1];
            }

            String s = (new StringBuilder()).append("oracle.jdbc.driver.BufferCache<").append(cacheId).append(">\n").append("\tTotal Hits   :\t").append(i).append("\n").append("\tTotal Misses :\t").append(j + nRequestTooBig).append("\n").append("\tTotal Cached :\t").append(k).append("\n").append("\tTotal Dropped:\t").append(l + nCacheTooBig).append("\n").append("\tTotal Cleared:\t").append(i1).append("\n").toString();
            return s;
        }


        InternalStatistics(int ai[])
        {
            cacheId = ++CACHE_COUNT;
            sizes = ai;
            int i = ai.length;
            nCacheHit = new int[i];
            nCacheMiss = new int[i];
            nRequestTooBig = 0;
            nBufferCached = new int[i];
            nBucketFull = new int[i];
            nRefCleared = new int[i];
            nCacheTooBig = 0;
        }
    }


    private static final double ln2 = Math.log(2D);
    private static final int BUFFERS_PER_BUCKET = 8;
    private static final int MIN_INDEX = 12;
    private final InternalStatistics stats;
    private final int bufferSize[];
    private final SoftReference buckets[][];
    private final int top[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    BufferCache(int i)
    {
        int j;
        if(i < 31)
            j = i;
        else
            j = (int)Math.ceil(Math.log(i) / ln2);
        int k = Math.max(0, (j - 12) + 1);
        buckets = (SoftReference[][])new SoftReference[k][8];
        top = new int[k];
        bufferSize = new int[k];
        int l = 4096;
        for(int i1 = 0; i1 < bufferSize.length; i1++)
        {
            bufferSize[i1] = l;
            l <<= 1;
        }

        stats = new InternalStatistics(bufferSize);
    }

    Object get(Class class1, int i)
    {
        int j = bufferIndex(i);
        if(j >= buckets.length)
        {
            stats.requestTooBig();
            return Array.newInstance(class1, i);
        }
        while(top[j] > 0) 
        {
            SoftReference softreference = buckets[j][--top[j]];
            buckets[j][top[j]] = null;
            Object obj = softreference.get();
            if(obj != null)
            {
                stats.cacheHit(j);
                return obj;
            }
        }
        stats.cacheMiss(j);
        return Array.newInstance(class1, bufferSize[j]);
    }

    void put(Object obj)
    {
        int i = Array.getLength(obj);
        int j = bufferIndex(i);
        if(j >= buckets.length || i != bufferSize[j])
        {
            stats.cacheTooBig();
            return;
        }
        if(top[j] < 8)
        {
            stats.bufferCached(j);
            buckets[j][top[j]++] = new SoftReference(obj);
        } else
        {
            for(int k = top[j]; k > 0;)
                if(buckets[j][--k].get() == null)
                {
                    stats.refCleared(j);
                    buckets[j][k] = new SoftReference(obj);
                    return;
                }

            stats.bucketFull(j);
        }
    }

    oracle.jdbc.internal.OracleConnection.BufferCacheStatistics getStatistics()
    {
        return stats;
    }

    private int bufferIndex(int i)
    {
        for(int j = 0; j < bufferSize.length; j++)
            if(i <= bufferSize[j])
                return j;

        return 0x7fffffff;
    }

}
