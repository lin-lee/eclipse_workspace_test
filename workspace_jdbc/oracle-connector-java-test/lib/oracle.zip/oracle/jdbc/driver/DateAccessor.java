// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   DateAccessor.java

package oracle.jdbc.driver;

import java.sql.*;
import java.util.Map;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.driver:
//            DateTimeCommonAccessor, DatabaseError, OracleStatement, PhysicalConnection

class DateAccessor extends DateTimeCommonAccessor
{

    static final int maxLength = 7;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    DateAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 12, 12, word0, flag);
        initForDataAccess(j, i, null);
    }

    DateAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        init(oraclestatement, 12, 12, word0, false);
        initForDescribe(12, i, flag, j, k, l, i1, j1, word0, null);
        initForDataAccess(0, i, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        internalTypeMaxLength = 7;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        byteLength = internalTypeMaxLength;
    }

    String getString(int i)
        throws SQLException
    {
        String s = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            if(externalType == 0)
            {
                if(statement.connection.mapDateToTimestamp)
                    s = getTimestamp(i).toString();
                else
                    s = getDate(i).toString();
            } else
            {
                int j = columnIndex + byteLength * i;
                int k = oracleYear(j);
                int l = 0;
                s = toText(k, rowSpaceByte[2 + j], rowSpaceByte[3 + j], l = rowSpaceByte[4 + j] - 1, rowSpaceByte[5 + j] - 1, rowSpaceByte[6 + j] - 1, -1, l < 12, null);
            }
        return s;
    }

    Object getObject(int i)
        throws SQLException
    {
        Object obj = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
            if(externalType == 0)
            {
                if(statement.connection.mapDateToTimestamp)
                    obj = getTimestamp(i);
                else
                    obj = getDate(i);
            } else
            {
                switch(externalType)
                {
                case 91: // '['
                    return getDate(i);

                case 92: // '\\'
                    return getTime(i);

                case 93: // ']'
                    return getTimestamp(i);
                }
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return obj;
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        return getDATE(i);
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        return getObject(i);
    }

    static String toStr(int i)
    {
        return i >= 10 ? Integer.toString(i) : (new StringBuilder()).append("0").append(i).toString();
    }

}
