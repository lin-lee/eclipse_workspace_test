// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   XSNamespaceI.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.XSAttribute;
import oracle.jdbc.internal.XSNamespace;
import oracle.sql.TIMESTAMPTZ;

// Referenced classes of package oracle.jdbc.driver:
//            XSAttributeI, T4CMAREngine, DBConversion

class XSNamespaceI extends XSNamespace
{

    String namespaceName;
    byte namespaceNameBytes[];
    XSAttributeI attributes[];
    byte timestampBytes[];
    long flag;
    byte aclList[][];

    XSNamespaceI()
    {
        namespaceName = null;
        attributes = null;
        timestampBytes = null;
        flag = 0L;
        aclList = (byte[][])null;
    }

    public void setNamespaceName(String s)
        throws SQLException
    {
        namespaceName = s;
    }

    public void setTimestamp(TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        timestampBytes = timestamptz.toBytes();
    }

    private void setTimestamp(byte abyte0[])
        throws SQLException
    {
        timestampBytes = abyte0;
    }

    public void setACLIdList(byte abyte0[][])
        throws SQLException
    {
        aclList = abyte0;
    }

    public void setFlag(long l)
        throws SQLException
    {
        flag = l;
    }

    public void setAttributes(XSAttribute axsattribute[])
        throws SQLException
    {
        if(axsattribute != null)
        {
            XSAttributeI axsattributei[] = new XSAttributeI[axsattribute.length];
            for(int i = 0; i < axsattribute.length; i++)
                axsattributei[i] = (XSAttributeI)axsattribute[i];

            attributes = axsattributei;
        }
    }

    void doCharConversion(DBConversion dbconversion)
        throws SQLException
    {
        if(namespaceName != null)
            namespaceNameBytes = dbconversion.StringToCharBytes(namespaceName);
        else
            namespaceNameBytes = null;
        if(attributes != null)
        {
            for(int i = 0; i < attributes.length; i++)
                attributes[i].doCharConversion(dbconversion);

        }
    }

    public String getNamespaceName()
    {
        return namespaceName;
    }

    public TIMESTAMPTZ getTimestamp()
    {
        return new TIMESTAMPTZ(timestampBytes);
    }

    public long getFlag()
    {
        return flag;
    }

    public XSAttribute[] getAttributes()
    {
        return attributes;
    }

    public byte[][] getACLIdList()
    {
        return aclList;
    }

    void marshal(T4CMAREngine t4cmarengine)
        throws IOException
    {
        if(namespaceNameBytes != null)
        {
            t4cmarengine.marshalUB4(namespaceNameBytes.length);
            t4cmarengine.marshalCLR(namespaceNameBytes, namespaceNameBytes.length);
        } else
        {
            t4cmarengine.marshalUB4(0L);
        }
        if(timestampBytes != null)
        {
            t4cmarengine.marshalUB4(timestampBytes.length);
            t4cmarengine.marshalCLR(timestampBytes, timestampBytes.length);
        } else
        {
            t4cmarengine.marshalUB4(0L);
        }
        t4cmarengine.marshalUB4(flag);
        if(attributes != null)
        {
            t4cmarengine.marshalUB4(attributes.length);
            t4cmarengine.marshalUB1((short)28);
            for(int i = 0; i < attributes.length; i++)
                attributes[i].marshal(t4cmarengine);

        } else
        {
            t4cmarengine.marshalUB4(0L);
        }
        if(aclList != null)
        {
            byte abyte0[] = new byte[aclList.length * 16];
            for(int j = 0; j < aclList.length; j++)
                System.arraycopy(aclList[j], 0, abyte0, 16 * j, 16);

            t4cmarengine.marshalUB4(abyte0.length);
            t4cmarengine.marshalCLR(abyte0, abyte0.length);
        } else
        {
            t4cmarengine.marshalUB4(0L);
        }
    }

    static XSNamespaceI unmarshal(T4CMAREngine t4cmarengine)
        throws SQLException, IOException
    {
        int ai[] = new int[1];
        String s = null;
        int i = (int)t4cmarengine.unmarshalUB4();
        if(i > 0)
        {
            byte abyte0[] = new byte[i];
            t4cmarengine.unmarshalCLR(abyte0, 0, ai);
            s = t4cmarengine.conv.CharBytesToString(abyte0, ai[0]);
        }
        byte abyte1[] = null;
        int j = (int)t4cmarengine.unmarshalUB4();
        if(j > 0)
            abyte1 = t4cmarengine.unmarshalNBytes(j);
        long l = t4cmarengine.unmarshalUB4();
        XSAttribute axsattribute[] = null;
        int k = (int)t4cmarengine.unmarshalUB4();
        axsattribute = new XSAttribute[k];
        if(k > 0)
            t4cmarengine.unmarshalUB1();
        for(int i1 = 0; i1 < k; i1++)
            axsattribute[i1] = XSAttributeI.unmarshal(t4cmarengine);

        int j1 = (int)t4cmarengine.unmarshalUB4();
        byte abyte2[][] = (byte[][])null;
        if(j1 > 0)
        {
            byte abyte3[] = new byte[j1];
            t4cmarengine.unmarshalCLR(abyte3, 0, ai);
            int k1 = j1 / 16;
            abyte2 = new byte[k1][];
            for(int l1 = 0; l1 < k1; l1++)
            {
                abyte2[l1] = new byte[16];
                System.arraycopy(abyte3, l1 * 16, abyte2[l1], 0, 16);
            }

        }
        XSNamespaceI xsnamespacei = new XSNamespaceI();
        xsnamespacei.setNamespaceName(s);
        xsnamespacei.setTimestamp(abyte1);
        xsnamespacei.setFlag(l);
        xsnamespacei.setAttributes(axsattribute);
        xsnamespacei.setACLIdList(abyte2);
        return xsnamespacei;
    }
}
