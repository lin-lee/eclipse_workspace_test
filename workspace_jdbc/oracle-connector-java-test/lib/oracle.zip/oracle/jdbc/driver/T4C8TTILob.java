// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C8TTILob.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4C8TTILobd, DatabaseError, T4CMAREngine, 
//            T4CConnection, T4CTTIoer

abstract class T4C8TTILob extends T4CTTIfun
{

    static final int KPLOB_READ = 2;
    static final int KPLOB_WRITE = 64;
    static final int KPLOB_WRITE_APPEND = 8192;
    static final int KPLOB_PAGE_SIZE = 16384;
    static final int KPLOB_FILE_OPEN = 256;
    static final int KPLOB_FILE_ISOPEN = 1024;
    static final int KPLOB_FILE_EXISTS = 2048;
    static final int KPLOB_FILE_CLOSE = 512;
    static final int KPLOB_OPEN = 32768;
    static final int KPLOB_CLOSE = 0x10000;
    static final int KPLOB_ISOPEN = 0x11000;
    static final int KPLOB_TMP_CREATE = 272;
    static final int KPLOB_TMP_FREE = 273;
    static final int KPLOB_GET_LEN = 1;
    static final int KPLOB_TRIM = 32;
    static final int KOKL_ORDONLY = 1;
    static final int KOKL_ORDWR = 2;
    static final int KOLF_ORDONLY = 11;
    static final int DTYCLOB = 112;
    static final int DTYBLOB = 113;
    byte sourceLobLocator[];
    byte destinationLobLocator[];
    long sourceOffset;
    long destinationOffset;
    int destinationLength;
    short characterSet;
    long lobamt;
    boolean lobnull;
    long lobops;
    int lobscn[];
    int lobscnl;
    boolean nullO2U;
    boolean sendLobamt;
    byte inBuffer[];
    long inBufferOffset;
    long inBufferNumBytes;
    byte outBuffer[];
    int offsetInOutBuffer;
    int rowsProcessed;
    long lobBytesRead;
    boolean littleEndianClob;
    T4C8TTILobd lobd;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C8TTILob(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        sourceLobLocator = null;
        destinationLobLocator = null;
        sourceOffset = 0L;
        destinationOffset = 0L;
        destinationLength = 0;
        characterSet = 0;
        lobamt = 0L;
        lobnull = false;
        lobops = 0L;
        lobscn = null;
        lobscnl = 0;
        nullO2U = false;
        sendLobamt = false;
        inBuffer = null;
        outBuffer = null;
        offsetInOutBuffer = 0;
        rowsProcessed = 0;
        lobBytesRead = 0L;
        littleEndianClob = false;
        lobd = null;
        setFunCode((short)96);
        lobd = new T4C8TTILobd(t4cconnection);
    }

    long read(byte abyte0[], long l, long l1, byte abyte1[], int i)
        throws SQLException, IOException
    {
        initializeLobdef();
        lobops = 2L;
        sourceLobLocator = abyte0;
        sourceOffset = l;
        lobamt = l1;
        sendLobamt = true;
        outBuffer = abyte1;
        offsetInOutBuffer = i;
        doRPC();
        return lobBytesRead;
    }

    long write(byte abyte0[], long l, byte abyte1[], long l1, long l2)
        throws SQLException, IOException
    {
        long l3 = 0L;
        initializeLobdef();
        lobops = 64L;
        sourceLobLocator = abyte0;
        sourceOffset = l;
        lobamt = l2;
        sendLobamt = true;
        inBuffer = abyte1;
        inBufferOffset = l1;
        inBufferNumBytes = l2;
        doRPC();
        l3 = lobamt;
        return l3;
    }

    long getLength(byte abyte0[])
        throws SQLException, IOException
    {
        long l = 0L;
        initializeLobdef();
        lobops = 1L;
        sourceLobLocator = abyte0;
        sendLobamt = true;
        doRPC();
        l = lobamt;
        return l;
    }

    long getChunkSize(byte abyte0[])
        throws SQLException, IOException
    {
        long l = 0L;
        initializeLobdef();
        lobops = 16384L;
        sourceLobLocator = abyte0;
        sendLobamt = true;
        doRPC();
        l = lobamt;
        return l;
    }

    long trim(byte abyte0[], long l)
        throws SQLException, IOException
    {
        long l1 = 0L;
        initializeLobdef();
        lobops = 32L;
        sourceLobLocator = abyte0;
        lobamt = l;
        sendLobamt = true;
        doRPC();
        l1 = lobamt;
        return l1;
    }

    abstract Datum createTemporaryLob(Connection connection, boolean flag, int i)
        throws SQLException, IOException;

    void freeTemporaryLob(byte abyte0[])
        throws SQLException, IOException
    {
        initializeLobdef();
        lobops = 273L;
        sourceLobLocator = abyte0;
        doRPC();
    }

    abstract boolean open(byte abyte0[], int i)
        throws SQLException, IOException;

    boolean _open(byte abyte0[], int i, int j)
        throws SQLException, IOException
    {
        boolean flag = false;
        if((abyte0[7] & 1) == 1 || (abyte0[4] & 0x40) == 64)
        {
            if((abyte0[7] & 8) == 8)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 445);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            abyte0[7] |= 8;
            if(i == 2)
                abyte0[7] |= 0x10;
            flag = true;
        } else
        {
            initializeLobdef();
            sourceLobLocator = abyte0;
            lobops = j;
            lobamt = i;
            sendLobamt = true;
            doRPC();
            if(lobamt != 0L)
                flag = true;
        }
        return flag;
    }

    abstract boolean close(byte abyte0[])
        throws SQLException, IOException;

    boolean _close(byte abyte0[], int i)
        throws SQLException, IOException
    {
        boolean flag = true;
        if((abyte0[7] & 1) == 1 || (abyte0[4] & 0x40) == 64)
        {
            if((abyte0[7] & 8) != 8)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 446);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            abyte0[7] &= 0xe7;
        } else
        {
            initializeLobdef();
            sourceLobLocator = abyte0;
            lobops = i;
            doRPC();
        }
        return flag;
    }

    abstract boolean isOpen(byte abyte0[])
        throws SQLException, IOException;

    boolean _isOpen(byte abyte0[], int i)
        throws SQLException, IOException
    {
        boolean flag = false;
        if((abyte0[7] & 1) == 1 || (abyte0[4] & 0x40) == 64)
        {
            if((abyte0[7] & 8) == 8)
                flag = true;
        } else
        {
            initializeLobdef();
            sourceLobLocator = abyte0;
            lobops = i;
            nullO2U = true;
            doRPC();
            flag = lobnull;
        }
        return flag;
    }

    void initializeLobdef()
    {
        sourceLobLocator = null;
        destinationLobLocator = null;
        sourceOffset = 0L;
        destinationOffset = 0L;
        destinationLength = 0;
        characterSet = 0;
        lobamt = 0L;
        lobnull = false;
        lobops = 0L;
        lobscn = null;
        lobscnl = 0;
        inBuffer = null;
        outBuffer = null;
        nullO2U = false;
        sendLobamt = false;
        littleEndianClob = false;
        lobBytesRead = 0L;
    }

    void marshal()
        throws IOException
    {
        int i = 0;
        if(sourceLobLocator != null)
        {
            i = sourceLobLocator.length;
            meg.marshalPTR();
        } else
        {
            meg.marshalNULLPTR();
        }
        meg.marshalSB4(i);
        if(destinationLobLocator != null)
        {
            destinationLength = destinationLobLocator.length;
            meg.marshalPTR();
        } else
        {
            meg.marshalNULLPTR();
        }
        meg.marshalSB4(destinationLength);
        if(connection.getTTCVersion() >= 3)
            meg.marshalUB4(0L);
        else
            meg.marshalUB4(sourceOffset);
        if(connection.getTTCVersion() >= 3)
            meg.marshalUB4(0L);
        else
            meg.marshalUB4(destinationOffset);
        if(characterSet != 0)
            meg.marshalPTR();
        else
            meg.marshalNULLPTR();
        if(sendLobamt && connection.getTTCVersion() < 3)
            meg.marshalPTR();
        else
            meg.marshalNULLPTR();
        if(nullO2U)
            meg.marshalPTR();
        else
            meg.marshalNULLPTR();
        meg.marshalUB4(lobops);
        if(lobscnl != 0)
            meg.marshalPTR();
        else
            meg.marshalNULLPTR();
        meg.marshalSB4(lobscnl);
        if(connection.getTTCVersion() >= 3)
        {
            meg.marshalSB8(sourceOffset);
            meg.marshalSB8(destinationOffset);
            if(sendLobamt)
                meg.marshalPTR();
            else
                meg.marshalNULLPTR();
            if(connection.getTTCVersion() >= 4)
            {
                meg.marshalNULLPTR();
                meg.marshalSWORD(0);
                meg.marshalNULLPTR();
                meg.marshalSWORD(0);
                meg.marshalNULLPTR();
                meg.marshalSWORD(0);
            }
        }
        if(sourceLobLocator != null)
            meg.marshalB1Array(sourceLobLocator);
        if(destinationLobLocator != null)
            meg.marshalB1Array(destinationLobLocator);
        if(characterSet != 0)
            meg.marshalUB2(characterSet);
        if(sendLobamt && connection.getTTCVersion() < 3)
            meg.marshalUB4(lobamt);
        if(lobscnl != 0)
        {
            for(int j = 0; j < lobscnl; j++)
                meg.marshalUB4(lobscn[j]);

        }
        if(sendLobamt && connection.getTTCVersion() >= 3)
            meg.marshalSB8(lobamt);
        if(lobops == 64L)
            marshalData();
    }

    void marshalData()
        throws IOException
    {
        boolean flag = connection.isZeroCopyIOEnabled() & ((sourceLobLocator[7] & 0xffffff80) != 0);
        boolean flag1 = false;
        if((sourceLobLocator[6] & 0x80) == 128)
            flag1 = true;
        if(connection.versionNumber < 10101 && flag1)
            lobd.marshalClobUB2_For9iDB(inBuffer, inBufferOffset, inBufferNumBytes);
        else
            lobd.marshalLobData(inBuffer, inBufferOffset, inBufferNumBytes, flag);
    }

    void readLOBD()
        throws IOException, SQLException
    {
        boolean flag = connection.isZeroCopyIOEnabled() & ((sourceLobLocator[7] & 0xffffff80) != 0);
        boolean flag1 = false;
        if((sourceLobLocator[6] & 0x80) == 128)
            flag1 = true;
        if(connection.versionNumber < 10101 && flag1)
            lobBytesRead = lobd.unmarshalClobUB2_For9iDB(outBuffer, offsetInOutBuffer);
        else
            lobBytesRead = lobd.unmarshalLobData(outBuffer, offsetInOutBuffer, flag);
    }

    void processError()
        throws SQLException
    {
        rowsProcessed = oer.getCurRowNumber();
        if(oer.getRetCode() != 1403)
            oer.processError();
    }

    void readRPA()
        throws SQLException, IOException
    {
        if(sourceLobLocator != null)
        {
            int i = sourceLobLocator.length;
            meg.getNBytes(sourceLobLocator, 0, i);
        }
        if(destinationLobLocator != null)
        {
            short word0 = meg.unmarshalSB2();
            destinationLobLocator = meg.unmarshalNBytes(word0);
        }
        if(characterSet != 0)
            characterSet = meg.unmarshalSB2();
        if(sendLobamt)
            if(connection.getTTCVersion() >= 3)
                lobamt = meg.unmarshalSB8();
            else
                lobamt = meg.unmarshalUB4();
        if(nullO2U)
        {
            short word1 = meg.unmarshalSB1();
            if(word1 != 0)
                lobnull = true;
        }
    }

}
