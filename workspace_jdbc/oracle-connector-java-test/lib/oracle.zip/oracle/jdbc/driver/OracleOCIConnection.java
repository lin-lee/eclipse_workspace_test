// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleOCIConnection.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;
import oracle.jdbc.pool.OracleOCIConnectionPool;

// Referenced classes of package oracle.jdbc.driver:
//            T2CConnection, OracleDriverExtension, DatabaseError

public abstract class OracleOCIConnection extends T2CConnection
{

    OracleOCIConnectionPool ociConnectionPool;
    boolean isPool;
    boolean aliasing;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleOCIConnection(String s, Properties properties, Object obj)
        throws SQLException
    {
        this(s, properties, (OracleDriverExtension)obj);
    }

    OracleOCIConnection(String s, Properties properties, OracleDriverExtension oracledriverextension)
        throws SQLException
    {
        super(s, properties, oracledriverextension);
        ociConnectionPool = null;
        isPool = false;
        aliasing = false;
    }

    public synchronized byte[] getConnectionId()
        throws SQLException
    {
        byte abyte0[] = t2cGetConnectionId(m_nativeState);
        if(abyte0 == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 254, "Cannot create a ByteArray for the connectionId");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            aliasing = true;
            return abyte0;
        }
    }

    public synchronized void passwordChange(String s, String s1, String s2)
        throws SQLException, IOException
    {
        ociPasswordChange(s, s1, s2);
    }

    public synchronized void close()
        throws SQLException
    {
        if(lifecycle == 2 || lifecycle == 4 || aliasing)
        {
            return;
        } else
        {
            super.close();
            ociConnectionPool.connectionClosed((oracle.jdbc.oci.OracleOCIConnection)this);
            return;
        }
    }

    public synchronized void setConnectionPool(OracleOCIConnectionPool oracleociconnectionpool)
    {
        ociConnectionPool = oracleociconnectionpool;
    }

    public synchronized void setStmtCacheSize(int i, boolean flag)
        throws SQLException
    {
        super.setStmtCacheSize(i, flag);
    }

}
