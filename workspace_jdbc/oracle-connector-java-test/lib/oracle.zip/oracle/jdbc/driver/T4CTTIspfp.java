// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIspfp.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CMAREngine, DBConversion, T4CConnection

final class T4CTTIspfp extends T4CTTIfun
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIspfp(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        setFunCode((short)138);
    }

    void doOSPFPPUT()
        throws IOException, SQLException
    {
        doRPC();
    }

    void marshal()
        throws IOException
    {
        meg.marshalPTR();
        meg.marshalSWORD(100);
        meg.marshalPTR();
        meg.marshalPTR();
        meg.marshalSWORD(0);
        meg.marshalNULLPTR();
        meg.marshalSWORD(0);
        meg.marshalNULLPTR();
        meg.marshalNULLPTR();
    }

    void readRPA()
        throws IOException, SQLException
    {
        int i = meg.unmarshalUB2();
        byte abyte0[] = meg.unmarshalNBytes(i);
        if(i > 1)
        {
            String s = meg.conv.CharBytesToString(abyte0, i, true);
            SQLWarning sqlwarning = new SQLWarning(s);
            SQLWarning sqlwarning1 = connection.getWarnings();
            if(sqlwarning1 == null)
                connection.setWarnings(sqlwarning);
            else
                sqlwarning1.setNextWarning(sqlwarning);
        }
        meg.unmarshalUB2();
        meg.unmarshalUB2();
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
