// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;

import java.math.BigDecimal;
import java.sql.SQLException;
import oracle.core.lmx.CoreException;

// Referenced classes of package oracle.jdbc.driver:
//            VarnumBinder, OraclePreparedStatement, DatabaseError

class BigDecimalBinder extends VarnumBinder
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    BigDecimalBinder()
    {
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
        throws SQLException
    {
        byte abyte1[] = abyte0;
        int j2 = j1 + 1;
        BigDecimal bigdecimal = oraclepreparedstatement.parameterBigDecimal[k][i];
        int k2 = 0;
        String s = bigdecimal.toString();
        int l2;
        if((l2 = s.indexOf("E")) != -1)
        {
            StringBuffer stringbuffer = new StringBuffer(s.length() + 5);
            int j3 = 0;
            BigDecimal bigdecimal1 = null;
            boolean flag2 = s.charAt(0) == '-';
            String s1 = s.substring(l2 + 1);
            String s2 = s.substring(flag2 ? 1 : 0, l2);
            bigdecimal1 = new BigDecimal(s2);
            boolean flag3 = s1.charAt(0) == '-';
            s1 = s1.substring(1);
            j3 = Integer.parseInt(s1);
            String s3 = bigdecimal1.toString();
            int l4 = s3.indexOf(".");
            int j5 = s3.length();
            int l5 = j5;
            if(l4 != -1)
            {
                s3 = (new StringBuilder()).append(s3.substring(0, l4)).append(s3.substring(l4 + 1)).toString();
                j5--;
                if(flag3)
                    j3 -= l4;
                else
                    l5 = ++j3;
            } else
            if(flag3)
                j3 -= j5;
            else
                l5 = ++j3;
            if(flag2)
                stringbuffer.append("-");
            if(flag3)
            {
                stringbuffer.append("0.");
                for(int k6 = 0; k6 < j3; k6++)
                    stringbuffer.append("0");

                stringbuffer.append(s3);
            } else
            {
                int l6 = j3 <= j5 ? j5 : j3;
                for(int j7 = 0; j7 < l6; j7++)
                {
                    if(l5 == j7)
                        stringbuffer.append(".");
                    stringbuffer.append(j5 <= j7 ? '0' : s3.charAt(j7));
                }

            }
            s = stringbuffer.toString();
        }
        int i3 = s.length();
        int k3 = s.indexOf('.');
        boolean flag1 = s.charAt(0) == '-';
        int l3 = ((flag1) ? 1 : 0);
        int k4 = 2;
        int i5 = i3;
        if(k3 == -1)
            k3 = i3;
        else
        if((i3 - k3 & 1) != 0)
            i5 = i3 + 1;
        char c;
        for(; l3 < i3 && ((c = s.charAt(l3)) < '1' || c > '9'); l3++);
        if(l3 >= i3)
        {
            abyte1[j2] = -128;
            k2 = 1;
        } else
        {
            int i4;
            if(l3 < k3)
                i4 = 2 - (k3 - l3 & 1);
            else
                i4 = 1 + (l3 - k3 & 1);
            int j4 = (k3 - l3 - 1) / 2;
            if(j4 > 62)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, (new StringBuilder()).append(CoreException.getMessage((byte)3)).append(" trying to bind ").append(bigdecimal).toString());
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(j4 < -65)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, (new StringBuilder()).append(CoreException.getMessage((byte)2)).append(" trying to bind ").append(bigdecimal).toString());
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            int k5 = l3 + i4 + 38;
            if(k5 > i3)
                k5 = i3;
            for(int i6 = l3 + i4; i6 < k5; i6 += 2)
            {
                if(i6 == k3)
                {
                    i6--;
                    if(k5 < i3)
                        k5++;
                    continue;
                }
                if(s.charAt(i6) != '0' || i6 + 1 < i3 && s.charAt(i6 + 1) != '0')
                    k4 = (i6 - l3 - i4) / 2 + 3;
            }

            int i7 = j2 + 2;
            int j6 = l3 + i4;
            if(!flag1)
            {
                abyte1[j2] = (byte)(192 + j4 + 1);
                int k7 = s.charAt(l3) - 48;
                if(i4 == 2)
                    k7 = k7 * 10 + (l3 + 1 >= i3 ? 0 : s.charAt(l3 + 1) - 48);
                abyte1[j2 + 1] = (byte)(k7 + 1);
                while(i7 < j2 + k4) 
                {
                    if(j6 == k3)
                        j6++;
                    int l7 = (s.charAt(j6) - 48) * 10;
                    if(j6 + 1 < i3)
                        l7 += s.charAt(j6 + 1) - 48;
                    abyte1[i7++] = (byte)(l7 + 1);
                    j6 += 2;
                }
            } else
            {
                abyte1[j2] = (byte)(62 - j4);
                int i8 = s.charAt(l3) - 48;
                if(i4 == 2)
                    i8 = i8 * 10 + (l3 + 1 >= i3 ? 0 : s.charAt(l3 + 1) - 48);
                abyte1[j2 + 1] = (byte)(101 - i8);
                while(i7 < j2 + k4) 
                {
                    if(j6 == k3)
                        j6++;
                    int j8 = (s.charAt(j6) - 48) * 10;
                    if(j6 + 1 < i3)
                        j8 += s.charAt(j6 + 1) - 48;
                    abyte1[i7++] = (byte)(101 - j8);
                    j6 += 2;
                }
                if(k4 < 21)
                    abyte1[j2 + k4++] = 102;
            }
            k2 = k4;
        }
        abyte1[j1] = (byte)k2;
        aword0[i2] = 0;
        aword0[l1] = (short)(k2 + 1);
    }

}
