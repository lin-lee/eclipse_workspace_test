// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CIntervalymAccessor.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;

// Referenced classes of package oracle.jdbc.driver:
//            IntervalymAccessor, T4CMAREngine, OracleStatement, PhysicalConnection, 
//            DatabaseError

class T4CIntervalymAccessor extends IntervalymAccessor
{

    T4CMAREngine mare;
    static int maxLength = 11;
    final int meta[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CIntervalymAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, short word0, int j, boolean flag, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, maxLength, word0, j, flag);
        meta = new int[1];
        mare = t4cmarengine;
    }

    T4CIntervalymAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, int k1, int l1, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, maxLength, flag, j, k, l, i1, j1, word0);
        meta = new int[1];
        mare = t4cmarengine;
        definedColumnType = k1;
        definedColumnSize = l1;
    }

    void processIndicator(int i)
        throws IOException, SQLException
    {
        if(internalType == 1 && describeType == 112 || internalType == 23 && describeType == 113)
        {
            mare.unmarshalUB2();
            mare.unmarshalUB2();
        } else
        if(statement.connection.versionNumber < 9200)
        {
            mare.unmarshalSB2();
            if(!statement.sqlKind.isPlsqlOrCall())
                mare.unmarshalSB2();
        } else
        if(statement.sqlKind.isPlsqlOrCall() || isDMLReturnedParam)
            mare.processIndicator(i <= 0, i);
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        if(isUseLess)
        {
            lastRowProcessed++;
            return false;
        }
        if(rowSpaceIndicator == null)
        {
            byte abyte0[] = new byte[16000];
            mare.unmarshalCLR(abyte0, 0, meta);
            processIndicator(meta[0]);
            lastRowProcessed++;
            return false;
        }
        int i = indicatorIndex + lastRowProcessed;
        int j = lengthIndex + lastRowProcessed;
        if(isNullByDescribe)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
            lastRowProcessed++;
            if(statement.connection.versionNumber < 9200)
                processIndicator(0);
            return false;
        }
        int k = columnIndex + lastRowProcessed * byteLength;
        mare.unmarshalCLR(rowSpaceByte, k, meta, byteLength);
        processIndicator(meta[0]);
        if(meta[0] == 0)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
        } else
        {
            rowSpaceIndicator[j] = (short)meta[0];
            rowSpaceIndicator[i] = 0;
        }
        lastRowProcessed++;
        return false;
    }

    void copyRow()
        throws SQLException, IOException
    {
        int i;
        if(lastRowProcessed == 0)
            i = statement.rowPrefetchInLastFetch - 1;
        else
            i = lastRowProcessed - 1;
        int j = columnIndex + lastRowProcessed * byteLength;
        int k = columnIndex + i * byteLength;
        int l = indicatorIndex + lastRowProcessed;
        int i1 = indicatorIndex + i;
        int j1 = lengthIndex + lastRowProcessed;
        int k1 = lengthIndex + i;
        int l1 = rowSpaceIndicator[k1];
        int i2 = metaDataIndex + lastRowProcessed * 1;
        int j2 = metaDataIndex + i * 1;
        rowSpaceIndicator[j1] = (short)l1;
        rowSpaceIndicator[l] = rowSpaceIndicator[i1];
        if(!isNullByDescribe)
            System.arraycopy(rowSpaceByte, k, rowSpaceByte, j, l1);
        System.arraycopy(rowSpaceMetaData, j2, rowSpaceMetaData, i2, 1);
        lastRowProcessed++;
    }

    void saveDataFromOldDefineBuffers(byte abyte0[], char ac[], short aword0[], int i, int j)
        throws SQLException
    {
        int k = columnIndex + (j - 1) * byteLength;
        int l = columnIndexLastRow + (i - 1) * byteLength;
        int i1 = (indicatorIndex + j) - 1;
        int j1 = (indicatorIndexLastRow + i) - 1;
        int k1 = (lengthIndex + j) - 1;
        int l1 = (lengthIndexLastRow + i) - 1;
        int i2 = aword0[l1];
        rowSpaceIndicator[k1] = (short)i2;
        rowSpaceIndicator[i1] = aword0[j1];
        if(i2 != 0)
            System.arraycopy(abyte0, l, rowSpaceByte, k, i2);
    }

    String getString(int i)
        throws SQLException
    {
        String s = super.getString(i);
        if(s != null && definedColumnSize > 0 && s.length() > definedColumnSize)
            s = s.substring(0, definedColumnSize);
        return s;
    }

    Object getObject(int i)
        throws SQLException
    {
        if(definedColumnType == 0)
            return super.getObject(i);
        Object obj = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            switch(definedColumnType)
            {
            case -15: 
            case -9: 
            case -1: 
            case 1: // '\001'
            case 12: // '\f'
                return getString(i);

            case -103: 
                return getINTERVALYM(i);

            case -4: 
            case -3: 
            case -2: 
                return getBytes(i);
            }
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            return obj;
        }
    }

}
