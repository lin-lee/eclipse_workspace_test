// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTimeoutThreadPerVM.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            OracleTimeout, OracleTimeoutPollingThread, DatabaseError, OracleStatement, 
//            PhysicalConnection

class OracleTimeoutThreadPerVM extends OracleTimeout
{

    private static final OracleTimeoutPollingThread watchdog = new OracleTimeoutPollingThread();
    private OracleStatement statement;
    private long interruptAfter;
    private String name;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleTimeoutThreadPerVM(String s)
    {
        name = s;
        interruptAfter = 0x7fffffffffffffffL;
        watchdog.addTimeout(this);
    }

    void close()
    {
        watchdog.removeTimeout(this);
    }

    synchronized void setTimeout(long l, OracleStatement oraclestatement)
        throws SQLException
    {
        if(interruptAfter != 0x7fffffffffffffffL)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 131);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            statement = oraclestatement;
            interruptAfter = System.currentTimeMillis() + l;
            return;
        }
    }

    synchronized void cancelTimeout()
        throws SQLException
    {
        statement = null;
        interruptAfter = 0x7fffffffffffffffL;
    }

    void interruptIfAppropriate(long l)
    {
        if(l > interruptAfter)
            synchronized(this)
            {
                if(l > interruptAfter)
                {
                    if(statement.connection.spawnNewThreadToCancel)
                    {
                        final OracleStatement s = statement;
                        Thread thread = new Thread(new Runnable() {

                            final OracleStatement val$s;
                            final OracleTimeoutThreadPerVM this$0;

                            public void run()
                            {
                                try
                                {
                                    s.cancel();
                                }
                                catch(Throwable throwable1) { }
                            }

            
            {
                this$0 = OracleTimeoutThreadPerVM.this;
                s = oraclestatement;
                super();
            }
                        }
);
                        thread.setName((new StringBuilder()).append("interruptIfAppropriate_").append(this).toString());
                        thread.setDaemon(true);
                        thread.setPriority(10);
                        thread.start();
                    } else
                    {
                        try
                        {
                            statement.cancel();
                        }
                        catch(Throwable throwable) { }
                    }
                    statement = null;
                    interruptAfter = 0x7fffffffffffffffL;
                }
            }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
