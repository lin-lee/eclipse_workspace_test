// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ByteArrayKey.java

package oracle.jdbc.driver;


class ByteArrayKey
{

    private byte theBytes[];
    private int cachedHashCode;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public ByteArrayKey(byte abyte0[])
    {
        cachedHashCode = -1;
        theBytes = abyte0;
        byte abyte1[] = theBytes;
        int i = abyte1.length;
        for(int j = 0; j < i; j++)
        {
            byte byte0 = abyte1[j];
            cachedHashCode = cachedHashCode << 1 & (cachedHashCode >= 0 ? 0 : 1) ^ byte0;
        }

    }

    public boolean equals(Object obj)
    {
        if(obj == this)
            return true;
        if(!(obj instanceof ByteArrayKey))
            return false;
        byte abyte0[] = ((ByteArrayKey)obj).theBytes;
        if(theBytes.length != abyte0.length)
            return false;
        for(int i = 0; i < theBytes.length; i++)
            if(theBytes[i] != abyte0[i])
                return false;

        return true;
    }

    public int hashCode()
    {
        return cachedHashCode;
    }

}
