// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   StructMetaData.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.jdbc.OracleArray;
import oracle.jdbc.OracleBfile;
import oracle.jdbc.OracleBlob;
import oracle.jdbc.OracleClob;
import oracle.jdbc.OracleNClob;
import oracle.jdbc.OracleOpaque;
import oracle.jdbc.OracleRef;
import oracle.jdbc.OracleResultSetMetaData;
import oracle.jdbc.OracleStruct;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oracore.OracleType;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.oracore.OracleTypeCHAR;
import oracle.jdbc.oracore.OracleTypeFLOAT;
import oracle.jdbc.oracore.OracleTypeNUMBER;
import oracle.jdbc.oracore.OracleTypeRAW;
import oracle.jdbc.oracore.OracleTypeREF;
import oracle.sql.StructDescriptor;

// Referenced classes of package oracle.jdbc.driver:
//            DatabaseError

class StructMetaData
    implements oracle.jdbc.internal.StructMetaData
{

    StructDescriptor descriptor;
    OracleTypeADT otype;
    OracleType types[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public StructMetaData(StructDescriptor structdescriptor)
        throws SQLException
    {
        if(structdescriptor == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "illegal operation: descriptor is null");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            descriptor = structdescriptor;
            otype = structdescriptor.getOracleTypeADT();
            types = otype.getAttrTypes();
            return;
        }
    }

    public int getColumnCount()
        throws SQLException
    {
        return types.length;
    }

    public boolean isAutoIncrement(int i)
        throws SQLException
    {
        return false;
    }

    public boolean isSearchable(int i)
        throws SQLException
    {
        return false;
    }

    public oracle.jdbc.OracleResultSetMetaData.SecurityAttribute getSecurityAttribute(int i)
        throws SQLException
    {
        return oracle.jdbc.OracleResultSetMetaData.SecurityAttribute.NONE;
    }

    public boolean isCurrency(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        return (types[j] instanceof OracleTypeNUMBER) || (types[j] instanceof OracleTypeFLOAT);
    }

    public boolean isCaseSensitive(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        return types[j] instanceof OracleTypeCHAR;
    }

    public int isNullable(int i)
        throws SQLException
    {
        return 1;
    }

    public boolean isSigned(int i)
        throws SQLException
    {
        return true;
    }

    public int getColumnDisplaySize(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        if(types[j] instanceof OracleTypeCHAR)
            return ((OracleTypeCHAR)types[j]).getLength();
        if(types[j] instanceof OracleTypeRAW)
            return ((OracleTypeRAW)types[j]).getLength();
        else
            return 0;
    }

    public String getColumnLabel(int i)
        throws SQLException
    {
        return getColumnName(i);
    }

    public String getColumnName(int i)
        throws SQLException
    {
        return otype.getAttributeName(i);
    }

    public String getSchemaName(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        if(types[j] instanceof OracleTypeADT)
            return ((OracleTypeADT)types[j]).getSchemaName();
        else
            return "";
    }

    public int getPrecision(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        return types[j].getPrecision();
    }

    public int getScale(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        return types[j].getScale();
    }

    public String getTableName(int i)
        throws SQLException
    {
        return null;
    }

    public String getCatalogName(int i)
        throws SQLException
    {
        return null;
    }

    public int getColumnType(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        return types[j].getTypeCode();
    }

    public String getColumnTypeName(int i)
        throws SQLException
    {
        int j = getColumnType(i);
        int k = getValidColumnIndex(i);
        switch(j)
        {
        case 12: // '\f'
            return "VARCHAR";

        case 1: // '\001'
            return "CHAR";

        case -2: 
            return "RAW";

        case 6: // '\006'
            return "FLOAT";

        case 2: // '\002'
            return "NUMBER";

        case 8: // '\b'
            return "DOUBLE";

        case 3: // '\003'
            return "DECIMAL";

        case 100: // 'd'
            return "BINARY_FLOAT";

        case 101: // 'e'
            return "BINARY_DOUBLE";

        case 91: // '['
            return "DATE";

        case -104: 
            return "INTERVALDS";

        case -103: 
            return "INTERVALYM";

        case 93: // ']'
            return "TIMESTAMP";

        case -101: 
            return "TIMESTAMP WITH TIME ZONE";

        case -102: 
            return "TIMESTAMP WITH LOCAL TIME ZONE";

        case 2004: 
            return "BLOB";

        case 2005: 
            return "CLOB";

        case -13: 
            return "BFILE";

        case 2002: 
        case 2003: 
        case 2007: 
        case 2008: 
            return ((OracleTypeADT)types[k]).getFullName();

        case 2006: 
            return (new StringBuilder()).append("REF ").append(((OracleTypeREF)types[k]).getFullName()).toString();

        case -15: 
            return "NCHAR";

        case -9: 
            return "NVARCHAR";

        case 2011: 
            return "NCLOB";

        case 1111: 
        default:
            return null;
        }
    }

    public boolean isReadOnly(int i)
        throws SQLException
    {
        return false;
    }

    public boolean isWritable(int i)
        throws SQLException
    {
        return false;
    }

    public boolean isDefinitelyWritable(int i)
        throws SQLException
    {
        return false;
    }

    public String getColumnClassName(int i)
        throws SQLException
    {
        int j = getColumnType(i);
        switch(j)
        {
        case -15: 
        case -9: 
        case 1: // '\001'
        case 12: // '\f'
            return "java.lang.String";

        case -2: 
            return "byte[]";

        case 2: // '\002'
        case 3: // '\003'
        case 6: // '\006'
        case 8: // '\b'
            return "java.math.BigDecimal";

        case 91: // '['
            return "java.sql.Timestamp";

        case -103: 
            return "oracle.sql.INTERVALYM";

        case -104: 
            return "oracle.sql.INTERVALDS";

        case 93: // ']'
            return "oracle.sql.TIMESTAMP";

        case -101: 
            return "oracle.sql.TIMESTAMPTZ";

        case -102: 
            return "oracle.sql.TIMESTAMPLTZ";

        case 2004: 
            return oracle/jdbc/OracleBlob.getName();

        case 2005: 
            return oracle/jdbc/OracleClob.getName();

        case 2011: 
            return oracle/jdbc/OracleNClob.getName();

        case -13: 
            return oracle/jdbc/OracleBfile.getName();

        case 2002: 
        case 2008: 
            return oracle/jdbc/OracleStruct.getName();

        case 2007: 
            return oracle/jdbc/OracleOpaque.getName();

        case 2003: 
            return oracle/jdbc/OracleArray.getName();

        case 2006: 
            return oracle/jdbc/OracleRef.getName();

        case 1111: 
        default:
            return null;
        }
    }

    public String getOracleColumnClassName(int i)
        throws SQLException
    {
        int j = getColumnType(i);
        switch(j)
        {
        case -15: 
        case -9: 
        case 1: // '\001'
        case 12: // '\f'
            return "CHAR";

        case -2: 
            return "RAW";

        case 2: // '\002'
        case 3: // '\003'
        case 6: // '\006'
        case 8: // '\b'
            return "NUMBER";

        case 91: // '['
            return "DATE";

        case -103: 
            return "INTERVALYM";

        case -104: 
            return "INTERVALDS";

        case 93: // ']'
            return "TIMESTAMP";

        case -101: 
            return "TIMESTAMPTZ";

        case -102: 
            return "TIMESTAMPLTZ";

        case 2004: 
            return "BLOB";

        case 2005: 
            return "CLOB";

        case 2011: 
            return "NCLOB";

        case -13: 
            return "BFILE";

        case 2002: 
            return "STRUCT";

        case 2008: 
            return "JAVA_STRUCT";

        case 2007: 
            return "OPAQUE";

        case 2003: 
            return "ARRAY";

        case 2006: 
            return "REF";

        case 1111: 
        default:
            return null;
        }
    }

    public int getLocalColumnCount()
        throws SQLException
    {
        return descriptor.getLocalAttributeCount();
    }

    public boolean isInherited(int i)
        throws SQLException
    {
        return i <= getColumnCount() - getLocalColumnCount();
    }

    public String getAttributeJavaName(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        return descriptor.getAttributeJavaName(j);
    }

    private int getValidColumnIndex(int i)
        throws SQLException
    {
        int j = i - 1;
        if(j < 0 || j >= types.length)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "getValidColumnIndex");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return j;
        }
    }

    public boolean isNCHAR(int i)
        throws SQLException
    {
        int j = getValidColumnIndex(i);
        return types[j].isNCHAR();
    }

    public boolean isWrapperFor(Class class1)
        throws SQLException
    {
        if(class1.isInterface())
        {
            return class1.isInstance(this);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public Object unwrap(Class class1)
        throws SQLException
    {
        if(class1.isInterface() && class1.isInstance(this))
        {
            return this;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
