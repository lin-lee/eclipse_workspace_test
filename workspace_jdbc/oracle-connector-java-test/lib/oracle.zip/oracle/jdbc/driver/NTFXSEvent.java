// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFXSEvent.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.jdbc.internal.XSEvent;

// Referenced classes of package oracle.jdbc.driver:
//            KeywordValueLongI, T4CConnection, T4CMAREngine, NTFAQEvent

class NTFXSEvent extends XSEvent
{

    private final byte sid_kpuzxsss[];
    private final KeywordValueLongI sess_kpuzxsss[];
    private final int flg_kpuzxsss;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFXSEvent(T4CConnection t4cconnection)
        throws SQLException, IOException
    {
        super(t4cconnection);
        T4CMAREngine t4cmarengine = t4cconnection.getMarshalEngine();
        sid_kpuzxsss = t4cmarengine.unmarshalDALC();
        int i = (int)t4cmarengine.unmarshalUB4();
        byte byte0 = (byte)t4cmarengine.unmarshalUB1();
        sess_kpuzxsss = new KeywordValueLongI[i];
        for(int j = 0; j < i; j++)
            sess_kpuzxsss[j] = KeywordValueLongI.unmarshal(t4cmarengine);

        flg_kpuzxsss = (int)t4cmarengine.unmarshalUB4();
    }

    public byte[] getSessionId()
    {
        return sid_kpuzxsss;
    }

    public KeywordValueLong[] getDetails()
    {
        return (KeywordValueLong[])sess_kpuzxsss;
    }

    public int getFlags()
    {
        return flg_kpuzxsss;
    }

    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append((new StringBuilder()).append("sid_kpuzxsss  : ").append(NTFAQEvent.byteBufferToHexString(sid_kpuzxsss, 50)).append("\n").toString());
        stringbuffer.append("sess_kpuzxsss : \n");
        stringbuffer.append((new StringBuilder()).append("  size : ").append(sess_kpuzxsss.length).append("\n").toString());
        for(int i = 0; i < sess_kpuzxsss.length; i++)
        {
            stringbuffer.append((new StringBuilder()).append("  sess_kpuzxsss #").append(i).append(" : \n").toString());
            if(sess_kpuzxsss[i] == null)
                stringbuffer.append("null\n");
            else
                stringbuffer.append(sess_kpuzxsss[i].toString());
        }

        stringbuffer.append((new StringBuilder()).append("flg_kpuzxsss  : ").append(flg_kpuzxsss).append("\n").toString());
        return stringbuffer.toString();
    }

}
