// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CStatement.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;
import oracle.jdbc.oracore.OracleTypeADT;

// Referenced classes of package oracle.jdbc.driver:
//            OracleStatement, T4CRowidAccessor, T4CCharAccessor, T4CLongAccessor, 
//            T4CVarcharAccessor, T4CNumberAccessor, T4CVarnumAccessor, T4CLongRawAccessor, 
//            T4COutRawAccessor, T4CRawAccessor, T4CBinaryFloatAccessor, T4CBinaryDoubleAccessor, 
//            T4CResultSetAccessor, T4CDateAccessor, T4CBlobAccessor, T4CClobAccessor, 
//            T4CBfileAccessor, T4CNamedTypeAccessor, T4CRefTypeAccessor, T4CTimestampAccessor, 
//            T4CTimestamptzAccessor, T4CTimestampltzAccessor, T4CIntervalymAccessor, T4CIntervaldsAccessor, 
//            T4CConnection, T4C8Oall, Accessor, DatabaseError, 
//            PhysicalConnection, DBConversion, OracleSql, OracleResultSetImpl, 
//            T4C8Odscrarr, CRC64, OracleInputStream

class T4CStatement extends oracle.jdbc.driver.OracleStatement
{

    static final byte parameterDatum[][][] = (byte[][][])null;
    static final OracleTypeADT parameterOtype[][] = (OracleTypeADT[][])null;
    static final byte EMPTY_BYTE[] = new byte[0];
    T4CConnection t4Connection;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    void doOall8(boolean flag, boolean flag1, boolean flag2, boolean flag3, boolean flag4)
        throws SQLException, IOException
    {
        if(flag || flag3 || !flag1)
            oacdefSent = null;
        t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.doOall8");
        if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.UNINITIALIZED)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, (new StringBuilder()).append("sqlKind = ").append(sqlKind).toString());
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(flag2)
            rowPrefetchInLastFetch = rowPrefetch;
        int i = numberOfDefinePositions;
        if(sqlKind.isDML())
            i = 0;
        if(accessors != null)
        {
            for(int j = 0; j < accessors.length; j++)
                if(accessors[j] != null)
                    accessors[j].lastRowProcessed = 0;

        }
        if(outBindAccessors != null)
        {
            for(int k = 0; k < outBindAccessors.length; k++)
                if(outBindAccessors[k] != null)
                    outBindAccessors[k].lastRowProcessed = 0;

        }
        if(returnParamAccessors != null)
        {
            for(int l = 0; l < returnParamAccessors.length; l++)
                if(returnParamAccessors[l] != null)
                    returnParamAccessors[l].lastRowProcessed = 0;

        }
        if(bindIndicators != null)
        {
            int i1 = ((bindIndicators[bindIndicatorSubRange + 3] & 0xffff) << 16) + (bindIndicators[bindIndicatorSubRange + 4] & 0xffff);
            int j1 = 0;
            if(ibtBindChars != null)
                j1 = ibtBindChars.length * connection.conversion.cMaxCharSize;
            for(int k1 = 0; k1 < numberOfBindPositions; k1++)
            {
                int l1 = bindIndicatorSubRange + 5 + 10 * k1;
                int i2 = bindIndicators[l1 + 2] & 0xffff;
                if(i2 == 0)
                    continue;
                int k2 = bindIndicators[l1 + 9] & 0xffff;
                if(k2 == 2)
                    j1 = Math.max(i2 * connection.conversion.maxNCharSize, j1);
                else
                    j1 = Math.max(i2 * connection.conversion.cMaxCharSize, j1);
            }

            if(tmpBindsByteArray == null)
                tmpBindsByteArray = new byte[j1];
            else
            if(tmpBindsByteArray.length < j1)
            {
                tmpBindsByteArray = null;
                tmpBindsByteArray = new byte[j1];
            }
        } else
        {
            tmpBindsByteArray = null;
        }
        int ai[] = definedColumnType;
        int ai1[] = definedColumnSize;
        int ai2[] = definedColumnFormOfUse;
        if(flag4 && flag3 && sqlObject.includeRowid)
        {
            ai = new int[definedColumnType.length + 1];
            System.arraycopy(definedColumnType, 0, ai, 1, definedColumnType.length);
            ai[0] = -8;
            ai1 = new int[definedColumnSize.length + 1];
            System.arraycopy(definedColumnSize, 0, ai1, 1, definedColumnSize.length);
            ai2 = new int[definedColumnFormOfUse.length + 1];
            System.arraycopy(definedColumnFormOfUse, 0, ai2, 1, definedColumnFormOfUse.length);
        }
        allocateTmpByteArray();
        T4C8Oall t4c8oall = t4Connection.all8;
        t4Connection.sendPiggyBackedMessages();
        try
        {
            t4c8oall.doOALL(flag, flag1, flag2, flag3, flag4, sqlKind, cursorId, sqlObject.getSqlBytes(processEscapes, convertNcharLiterals), rowPrefetch, outBindAccessors, numberOfBindPositions, accessors, i, bindBytes, bindChars, bindIndicators, bindIndicatorSubRange, connection.conversion, tmpBindsByteArray, parameterStream, parameterDatum, parameterOtype, this, ibtBindBytes, ibtBindChars, ibtBindIndicators, oacdefSent, ai, ai1, ai2, registration);
            int j2 = t4c8oall.getCursorId();
            if(j2 != 0)
                cursorId = j2;
            oacdefSent = t4c8oall.oacdefBindsSent;
        }
        catch(SQLException sqlexception1)
        {
            int l2 = t4c8oall.getCursorId();
            if(l2 != 0)
                cursorId = l2;
            if(sqlexception1.getErrorCode() == DatabaseError.getVendorCode(110))
                sqlWarning = DatabaseError.addSqlWarning(sqlWarning, 110);
            else
                throw sqlexception1;
        }
    }

    void allocateTmpByteArray()
    {
        if(tmpByteArray == null)
            tmpByteArray = new byte[sizeTmpByteArray];
        else
        if(sizeTmpByteArray > tmpByteArray.length)
            tmpByteArray = new byte[sizeTmpByteArray];
    }

    void releaseBuffers()
    {
        super.releaseBuffers();
        tmpByteArray = null;
        tmpBindsByteArray = null;
        t4Connection.all8.bindChars = null;
        t4Connection.all8.bindBytes = null;
        t4Connection.all8.tmpBindsByteArray = null;
    }

    void allocateRowidAccessor()
        throws SQLException
    {
        accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, t4Connection.mare);
    }

    void reparseOnRedefineIfNeeded()
        throws SQLException
    {
        needToParse = true;
    }

    protected void defineColumnTypeInternal(int i, int j, int k, short word0, boolean flag, String s)
        throws SQLException
    {
        if(connection.disableDefinecolumntype)
            return;
        if(j == -15 || j == -9 || j == -16)
            word0 = 2;
        if(i < 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(flag)
        {
            if(j == 1 || j == 12 || j == -15 || j == -9)
                sqlWarning = DatabaseError.addSqlWarning(sqlWarning, 108);
        } else
        if(k < 0)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(currentResultSet != null && !currentResultSet.closed)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        int l = i - 1;
        if(definedColumnType == null || definedColumnType.length <= l)
            if(definedColumnType == null)
            {
                definedColumnType = new int[(l + 1) * 4];
            } else
            {
                int ai[] = new int[(l + 1) * 4];
                System.arraycopy(definedColumnType, 0, ai, 0, definedColumnType.length);
                definedColumnType = ai;
            }
        definedColumnType[l] = j;
        if(definedColumnSize == null || definedColumnSize.length <= l)
            if(definedColumnSize == null)
            {
                definedColumnSize = new int[(l + 1) * 4];
            } else
            {
                int ai1[] = new int[(l + 1) * 4];
                System.arraycopy(definedColumnSize, 0, ai1, 0, definedColumnSize.length);
                definedColumnSize = ai1;
            }
        definedColumnSize[l] = k;
        if(definedColumnFormOfUse == null || definedColumnFormOfUse.length <= l)
            if(definedColumnFormOfUse == null)
            {
                definedColumnFormOfUse = new int[(l + 1) * 4];
            } else
            {
                int ai2[] = new int[(l + 1) * 4];
                System.arraycopy(definedColumnFormOfUse, 0, ai2, 0, definedColumnFormOfUse.length);
                definedColumnFormOfUse = ai2;
            }
        definedColumnFormOfUse[l] = word0;
        if(accessors != null && l < accessors.length && accessors[l] != null)
        {
            accessors[l].definedColumnSize = k;
            if((accessors[l].internalType == 96 || accessors[l].internalType == 1) && (j == 1 || j == 12) && k <= accessors[l].oacmxl)
            {
                needToPrepareDefineBuffer = true;
                columnsDefinedByUser = true;
                accessors[l].initForDataAccess(j, k, null);
                accessors[l].calculateSizeTmpByteArray();
            }
        }
    }

    public void clearDefines()
        throws SQLException
    {
        synchronized(connection)
        {
            super.clearDefines();
            definedColumnType = null;
            definedColumnSize = null;
            definedColumnFormOfUse = null;
            t4Connection.all8.definesAccessors = null;
        }
    }

    void saveDefineBuffersIfRequired(char ac[], byte abyte0[], short aword0[], boolean flag)
        throws SQLException
    {
        boolean flag1 = rowPrefetchInLastFetch < rowPrefetch;
        if(flag)
        {
            aword0 = new short[defineIndicators.length];
            int i = accessors[0].lengthIndexLastRow;
            int k = accessors[0].indicatorIndexLastRow;
            int j1 = flag1 ? accessors.length : 1;
            while(flag1 ? j1 < 1 : j1 > accessors.length) 
            {
                int l = (i + rowPrefetchInLastFetch * j1) - 1;
                int i1 = (k + rowPrefetchInLastFetch * j1) - 1;
                aword0[i1] = defineIndicators[i1];
                aword0[l] = defineIndicators[l];
                j1 += flag1 ? -1 : 1;
            }
        }
        int j = flag1 ? accessors.length - 1 : 0;
        while(flag1 ? j <= -1 : j >= accessors.length) 
        {
            accessors[j].saveDataFromOldDefineBuffers(abyte0, ac, aword0, rowPrefetchInLastFetch == -1 ? rowPrefetch : rowPrefetchInLastFetch, rowPrefetch);
            j += flag1 ? -1 : 1;
        }
        super.saveDefineBuffersIfRequired(ac, abyte0, aword0, flag);
    }

    void doSetSnapshotSCN(long l)
        throws SQLException
    {
        inScn = l;
    }

    Accessor allocateAccessor(int i, int j, int k, int l, short word0, String s, boolean flag)
        throws SQLException
    {
        Object obj = null;
        switch(i)
        {
        default:
            break;

        case 96: // '`'
            obj = new T4CCharAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 8: // '\b'
            if(!flag)
            {
                obj = new T4CLongAccessor(this, k, l, word0, j, t4Connection.mare);
                break;
            }
            // fall through

        case 1: // '\001'
            obj = new T4CVarcharAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 2: // '\002'
            obj = new T4CNumberAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 6: // '\006'
            obj = new T4CVarnumAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 24: // '\030'
            if(!flag)
            {
                obj = new T4CLongRawAccessor(this, k, l, word0, j, t4Connection.mare);
                break;
            }
            // fall through

        case 23: // '\027'
            if(flag && s != null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, (new StringBuilder()).append("sqlType=").append(j).toString());
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(flag)
                obj = new T4COutRawAccessor(this, l, word0, j, t4Connection.mare);
            else
                obj = new T4CRawAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 100: // 'd'
            obj = new T4CBinaryFloatAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 101: // 'e'
            obj = new T4CBinaryDoubleAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 104: // 'h'
            if(sqlKind == oracle.jdbc.internal.OracleStatement.SqlKind.CALL_BLOCK)
            {
                obj = new T4CVarcharAccessor(this, 18, word0, j, flag, t4Connection.mare);
                obj.definedColumnType = -8;
            } else
            {
                obj = new T4CRowidAccessor(this, l, word0, j, flag, t4Connection.mare);
            }
            break;

        case 102: // 'f'
            obj = new T4CResultSetAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 12: // '\f'
            obj = new T4CDateAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 113: // 'q'
            obj = new T4CBlobAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 112: // 'p'
            obj = new T4CClobAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 114: // 'r'
            obj = new T4CBfileAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 109: // 'm'
            obj = new T4CNamedTypeAccessor(this, s, word0, j, flag, t4Connection.mare);
            ((Accessor) (obj)).initMetadata();
            break;

        case 111: // 'o'
            obj = new T4CRefTypeAccessor(this, s, word0, j, flag, t4Connection.mare);
            ((Accessor) (obj)).initMetadata();
            break;

        case 180: 
            obj = new T4CTimestampAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 181: 
            obj = new T4CTimestamptzAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 231: 
            obj = new T4CTimestampltzAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 182: 
            obj = new T4CIntervalymAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 183: 
            obj = new T4CIntervaldsAccessor(this, l, word0, j, flag, t4Connection.mare);
            break;

        case 995: 
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        return ((Accessor) (obj));
    }

    void doDescribe(boolean flag)
        throws SQLException
    {
        if(!isOpen)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        try
        {
            t4Connection.needLine();
            t4Connection.sendPiggyBackedMessages();
            t4Connection.describe.doODNY(this, 0, accessors, sqlObject.getSqlBytes(processEscapes, convertNcharLiterals));
            accessors = t4Connection.describe.getAccessors();
            numberOfDefinePositions = t4Connection.describe.numuds;
            for(int i = 0; i < numberOfDefinePositions; i++)
                accessors[i].initMetadata();

        }
        catch(IOException ioexception)
        {
            ((T4CConnection)connection).handleIOException(ioexception);
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        describedWithNames = true;
        described = true;
    }

    void executeForDescribe()
        throws SQLException
    {
        t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.execute_for_describe");
        try
        {
            if(t4Connection.useFetchSizeWithLongColumn)
                doOall8(true, true, true, true, false);
            else
                doOall8(true, true, false, true, definedColumnType != null);
        }
        catch(SQLException sqlexception)
        {
            throw sqlexception;
        }
        catch(IOException ioexception)
        {
            ((T4CConnection)connection).handleIOException(ioexception);
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        rowsProcessed = t4Connection.all8.rowsProcessed;
        validRows = t4Connection.all8.getNumRows();
        break MISSING_BLOCK_LABEL_144;
        Exception exception;
        exception;
        rowsProcessed = t4Connection.all8.rowsProcessed;
        validRows = t4Connection.all8.getNumRows();
        throw exception;
        needToParse = false;
        if(connection.calculateChecksum)
            if(validRows > 0)
                calculateCheckSum();
            else
            if(rowsProcessed > 0)
            {
                PhysicalConnection.CHECKSUM;
                long l = CRC64.updateChecksum(checkSum, rowsProcessed);
                checkSum = l;
            }
        if(definedColumnType == null)
            implicitDefineForLobPrefetchDone = false;
        aFetchWasDoneDuringDescribe = false;
        if(t4Connection.all8.aFetchWasDone)
        {
            aFetchWasDoneDuringDescribe = true;
            rowPrefetchInLastFetch = rowPrefetch;
        }
        for(int i = 0; i < numberOfDefinePositions; i++)
            accessors[i].initMetadata();

        needToPrepareDefineBuffer = false;
        return;
    }

    void executeForRows(boolean flag)
        throws SQLException
    {
        boolean flag1 = false;
        if(columnsDefinedByUser)
            needToPrepareDefineBuffer = false;
        else
        if(t4Connection.useLobPrefetch && accessors != null && defaultLobPrefetchSize != -1 && !implicitDefineForLobPrefetchDone && !aFetchWasDoneDuringDescribe && definedColumnType == null)
        {
            boolean flag2 = false;
            int ai[] = new int[accessors.length];
            int ai1[] = new int[accessors.length];
            for(int i = 0; i < accessors.length; i++)
            {
                ai[i] = getJDBCType(accessors[i].internalType);
                if(accessors[i].internalType == 113 || accessors[i].internalType == 112 || accessors[i].internalType == 114)
                {
                    flag2 = true;
                    accessors[i].lobPrefetchSizeForThisColumn = defaultLobPrefetchSize;
                    ai1[i] = defaultLobPrefetchSize;
                }
            }

            if(flag2)
            {
                definedColumnType = ai;
                definedColumnSize = ai1;
                flag1 = true;
            }
        }
        doOall8(needToParse, !flag, true, false, flag1);
        needToParse = false;
        if(flag1)
            implicitDefineForLobPrefetchDone = true;
        validRows = t4Connection.all8.getNumRows();
        break MISSING_BLOCK_LABEL_317;
        Exception exception;
        exception;
        validRows = t4Connection.all8.getNumRows();
        throw exception;
        Object obj;
        obj;
        throw obj;
        obj;
        ((T4CConnection)connection).handleIOException(((IOException) (obj)));
        calculateCheckSum();
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ((IOException) (obj)));
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void fetch()
        throws SQLException
    {
        if(streamList != null)
            for(; nextStream != null; nextStream = nextStream.nextStream)
                try
                {
                    nextStream.close();
                }
                catch(IOException ioexception)
                {
                    ((T4CConnection)connection).handleIOException(ioexception);
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }

        try
        {
            doOall8(false, false, true, false, false);
            validRows = t4Connection.all8.getNumRows();
        }
        catch(IOException ioexception1)
        {
            ((T4CConnection)connection).handleIOException(ioexception1);
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception1);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        calculateCheckSum();
    }

    void continueReadRow(int i)
        throws SQLException
    {
        try
        {
            if(!connection.useFetchSizeWithLongColumn)
            {
                T4C8Oall t4c8oall = t4Connection.all8;
                t4c8oall.continueReadRow(i, this);
            }
        }
        catch(IOException ioexception)
        {
            ((T4CConnection)connection).handleIOException(ioexception);
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        catch(SQLException sqlexception)
        {
            if(sqlexception.getErrorCode() == DatabaseError.getVendorCode(110))
                sqlWarning = DatabaseError.addSqlWarning(sqlWarning, 110);
            else
                throw sqlexception;
        }
    }

    void doClose()
        throws SQLException
    {
        t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.do_close");
        if(cursorId != 0)
            t4Connection.closeCursor(cursorId);
        tmpByteArray = null;
        tmpBindsByteArray = null;
        definedColumnType = null;
        definedColumnSize = null;
        definedColumnFormOfUse = null;
        oacdefSent = null;
    }

    void closeQuery()
        throws SQLException
    {
        t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.closeQuery");
        if(streamList != null)
            for(; nextStream != null; nextStream = nextStream.nextStream)
                try
                {
                    nextStream.close();
                }
                catch(IOException ioexception)
                {
                    ((T4CConnection)connection).handleIOException(ioexception);
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }

    }

    T4CStatement(PhysicalConnection physicalconnection, int i, int j)
        throws SQLException
    {
        super(physicalconnection, 1, physicalconnection.defaultRowPrefetch, i, j);
        nbPostPonedColumns = new int[1];
        nbPostPonedColumns[0] = 0;
        indexOfPostPonedColumn = new int[1][3];
        t4Connection = (T4CConnection)physicalconnection;
    }

    void closeCursorOnPlainStatement()
        throws SQLException
    {
        if(cursorId != 0 && t4Connection.isLoggedOn())
        {
            t4Connection.closeCursor(cursorId);
            setCursorId(0);
        }
    }

}
