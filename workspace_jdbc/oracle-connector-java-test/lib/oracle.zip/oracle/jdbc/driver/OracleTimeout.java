// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTimeout.java

package oracle.jdbc.driver;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            OracleTimeoutThreadPerVM, OracleStatement

abstract class OracleTimeout
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleTimeout()
    {
    }

    static OracleTimeout newTimeout(String s)
        throws SQLException
    {
        OracleTimeoutThreadPerVM oracletimeoutthreadpervm = new OracleTimeoutThreadPerVM(s);
        return oracletimeoutthreadpervm;
    }

    abstract void setTimeout(long l, OracleStatement oraclestatement)
        throws SQLException;

    abstract void cancelTimeout()
        throws SQLException;

    abstract void close()
        throws SQLException;

}
