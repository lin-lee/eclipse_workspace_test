// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   Namespace.java

package oracle.jdbc.driver;


class Namespace
{

    static final int ATTRIBUTE_MAX_LENGTH = 30;
    static final int VALUE_MAX_LENGTH = 4000;
    String name;
    boolean clear;
    String keys[];
    String values[];
    int nbPairs;

    Namespace(String s)
    {
        if(s == null)
        {
            throw new NullPointerException();
        } else
        {
            name = s;
            clear = false;
            nbPairs = 0;
            keys = new String[5];
            values = new String[5];
            return;
        }
    }

    void clear()
    {
        clear = true;
        for(int i = 0; i < nbPairs; i++)
        {
            keys[i] = null;
            values[i] = null;
        }

        nbPairs = 0;
    }

    void setAttribute(String s, String s1)
    {
        if(s == null || s1 == null || s.equals(""))
            throw new NullPointerException();
        if(nbPairs == keys.length)
        {
            String as[] = new String[keys.length * 2];
            String as1[] = new String[keys.length * 2];
            System.arraycopy(keys, 0, as, 0, keys.length);
            System.arraycopy(values, 0, as1, 0, values.length);
            keys = as;
            values = as1;
        }
        keys[nbPairs] = s;
        values[nbPairs] = s1;
        nbPairs++;
    }
}
