// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ClassRef.java

package oracle.jdbc.driver;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import oracle.sql.OPAQUE;

public class ClassRef
{
    public static class Locale
    {

        protected final Method localeJDK7getDefault;
        protected final Object localeCategoryEnumFORMAT;

        static final Locale newInstance()
        {
            try
            {
                return new Locale();
            }
            catch(Exception exception)
            {
                return null;
            }
        }

        public java.util.Locale getDefault()
        {
            if(localeJDK7getDefault == null)
                return java.util.Locale.getDefault();
            try
            {
                return (java.util.Locale)localeJDK7getDefault.invoke(null, new Object[] {
                    localeCategoryEnumFORMAT
                });
            }
            catch(IllegalAccessException illegalaccessexception) { }
            catch(InvocationTargetException invocationtargetexception) { }
            return null;
        }

        private Locale()
        {
            LocaleCategoryClassRef localecategoryclassref = LocaleCategoryClassRef.newInstance();
            Method method = null;
            Object obj = null;
            if(localecategoryclassref != null)
                try
                {
                    Object aobj[] = localecategoryclassref.get().getEnumConstants();
                    Object aobj1[] = aobj;
                    int i = aobj1.length;
                    int j = 0;
                    do
                    {
                        if(j >= i)
                            break;
                        Object obj1 = aobj1[j];
                        if(((Enum)obj1).name() == "FORMAT")
                        {
                            obj = obj1;
                            break;
                        }
                        j++;
                    } while(true);
                    method = java/util/Locale.getDeclaredMethod("getDefault", new Class[] {
                        localecategoryclassref.get()
                    });
                }
                catch(Throwable throwable)
                {
                    method = null;
                    obj = null;
                }
            localeJDK7getDefault = method;
            localeCategoryEnumFORMAT = obj;
        }
    }

    public static class LocaleCategoryClassRef extends ClassRef
    {

        static final LocaleCategoryClassRef newInstance()
        {
            try
            {
                return new LocaleCategoryClassRef();
            }
            catch(ClassNotFoundException classnotfoundexception) { }
            catch(NoClassDefFoundError noclassdeffounderror) { }
            return null;
        }

        private LocaleCategoryClassRef()
            throws ClassNotFoundException
        {
            super("java.util.Locale$Category", null);
        }
    }

    static class XMLTypeClassRef extends ClassRef
    {

        protected final Method CREATEXML;

        static final XMLTypeClassRef newInstance()
        {
            try
            {
                return new XMLTypeClassRef();
            }
            catch(ClassNotFoundException classnotfoundexception) { }
            catch(NoClassDefFoundError noclassdeffounderror) { }
            return null;
        }

        OPAQUE createXML(OPAQUE opaque)
            throws SQLException
        {
            get();
            try
            {
                return (OPAQUE)CREATEXML.invoke(null, new Object[] {
                    opaque
                });
            }
            catch(IllegalAccessException illegalaccessexception) { }
            catch(InvocationTargetException invocationtargetexception) { }
            return null;
        }

        private XMLTypeClassRef()
            throws ClassNotFoundException
        {
            super("oracle.xdb.XMLType", null);
            Method method = null;
            try
            {
                method = get().getDeclaredMethod("createXML", new Class[] {
                    oracle/sql/OPAQUE
                });
            }
            catch(NoSuchMethodException nosuchmethodexception) { }
            CREATEXML = method;
        }
    }


    static final XMLTypeClassRef XMLTYPE = XMLTypeClassRef.newInstance();
    public static final Locale LOCALE = Locale.newInstance();
    private final String className;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    static final ClassRef newInstance(String s)
        throws ClassNotFoundException
    {
        return new ClassRef(s);
    }

    private ClassRef(String s)
        throws ClassNotFoundException
    {
        className = s;
    }

    Class get()
    {
        try
        {
            return Class.forName(className, true, Thread.currentThread().getContextClassLoader());
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            NoClassDefFoundError noclassdeffounderror = new NoClassDefFoundError(classnotfoundexception.getMessage());
            noclassdeffounderror.initCause(classnotfoundexception);
            throw noclassdeffounderror;
        }
    }


}
