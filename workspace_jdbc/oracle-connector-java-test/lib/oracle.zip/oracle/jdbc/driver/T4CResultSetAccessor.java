// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CResultSetAccessor.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleStatement;

// Referenced classes of package oracle.jdbc.driver:
//            ResultSetAccessor, OracleStatement, T4CTTIdcb, T4CConnection, 
//            OracleResultSetImpl, T4CMAREngine, PhysicalConnection, Accessor

class T4CResultSetAccessor extends ResultSetAccessor
{

    T4CMAREngine mare;
    oracle.jdbc.driver.OracleStatement newstmt[];
    byte empty[] = {
        0
    };
    boolean underlyingLongRaw;
    final int meta[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CResultSetAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, short word0, int j, boolean flag, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i, word0, j, flag);
        newstmt = new oracle.jdbc.driver.OracleStatement[10];
        underlyingLongRaw = false;
        meta = new int[1];
        mare = t4cmarengine;
    }

    T4CResultSetAccessor(oracle.jdbc.driver.OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0, int k1, int l1, T4CMAREngine t4cmarengine)
        throws SQLException
    {
        super(oraclestatement, i != -1 ? i : l1, flag, j, k, l, i1, j1, word0);
        newstmt = new oracle.jdbc.driver.OracleStatement[10];
        underlyingLongRaw = false;
        meta = new int[1];
        mare = t4cmarengine;
        if(oraclestatement != null && oraclestatement.implicitDefineForLobPrefetchDone)
        {
            definedColumnType = 0;
            definedColumnSize = 0;
        } else
        {
            definedColumnType = k1;
            definedColumnSize = l1;
        }
        if(i == -1)
            underlyingLongRaw = true;
    }

    void processIndicator(int i)
        throws IOException, SQLException
    {
        if(internalType == 1 && describeType == 112 || internalType == 23 && describeType == 113)
        {
            mare.unmarshalUB2();
            mare.unmarshalUB2();
        } else
        if(statement.connection.versionNumber < 9200)
        {
            mare.unmarshalSB2();
            if(!statement.sqlKind.isPlsqlOrCall())
                mare.unmarshalSB2();
        } else
        if(statement.sqlKind.isPlsqlOrCall() || isDMLReturnedParam)
            mare.processIndicator(i <= 0, i);
    }

    String getString(int i)
        throws SQLException
    {
        String s = super.getString(i);
        if(s != null && definedColumnSize > 0 && s.length() > definedColumnSize)
            s = s.substring(0, definedColumnSize);
        return s;
    }

    boolean unmarshalOneRow()
        throws SQLException, IOException
    {
        if(isUseLess)
        {
            lastRowProcessed++;
            return false;
        }
        if(rowSpaceIndicator == null)
        {
            byte abyte0[] = new byte[16000];
            mare.unmarshalCLR(abyte0, 0, meta);
            processIndicator(meta[0]);
            lastRowProcessed++;
            return false;
        }
        int i = indicatorIndex + lastRowProcessed;
        int j = lengthIndex + lastRowProcessed;
        if(isNullByDescribe)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
            lastRowProcessed++;
            processIndicator(0);
            return false;
        }
        int k = columnIndex + lastRowProcessed * byteLength;
        if(newstmt.length <= lastRowProcessed)
        {
            oracle.jdbc.driver.OracleStatement aoraclestatement[] = new oracle.jdbc.driver.OracleStatement[newstmt.length * 4];
            System.arraycopy(newstmt, 0, aoraclestatement, 0, newstmt.length);
            newstmt = aoraclestatement;
        }
        newstmt[lastRowProcessed] = statement.connection.RefCursorBytesToStatement(empty, statement);
        newstmt[lastRowProcessed].needToSendOalToFetch = true;
        T4CTTIdcb t4cttidcb = new T4CTTIdcb((T4CConnection)statement.connection);
        t4cttidcb.init(newstmt[lastRowProcessed], 0);
        newstmt[lastRowProcessed].accessors = t4cttidcb.receiveFromRefCursor(newstmt[lastRowProcessed].accessors);
        newstmt[lastRowProcessed].numberOfDefinePositions = newstmt[lastRowProcessed].accessors.length;
        newstmt[lastRowProcessed].describedWithNames = true;
        newstmt[lastRowProcessed].described = true;
        int l = (int)mare.unmarshalUB4();
        newstmt[lastRowProcessed].setCursorId(l);
        if(l > 0)
        {
            rowSpaceByte[k] = 1;
            rowSpaceByte[k + 1] = (byte)l;
            meta[0] = 2;
        } else
        {
            newstmt[lastRowProcessed].close();
            newstmt[lastRowProcessed] = null;
            meta[0] = 0;
        }
        processIndicator(meta[0]);
        if(meta[0] == 0)
        {
            rowSpaceIndicator[i] = -1;
            rowSpaceIndicator[j] = 0;
        } else
        {
            rowSpaceIndicator[j] = (short)meta[0];
            rowSpaceIndicator[i] = 0;
        }
        lastRowProcessed++;
        return false;
    }

    void copyRow()
        throws SQLException, IOException
    {
        int i;
        if(lastRowProcessed == 0)
            i = statement.rowPrefetchInLastFetch - 1;
        else
            i = lastRowProcessed - 1;
        int j = columnIndex + lastRowProcessed * byteLength;
        int k = columnIndex + i * byteLength;
        int l = indicatorIndex + lastRowProcessed;
        int i1 = indicatorIndex + i;
        int j1 = lengthIndex + lastRowProcessed;
        int k1 = lengthIndex + i;
        int l1 = rowSpaceIndicator[k1];
        int i2 = metaDataIndex + lastRowProcessed * 1;
        int j2 = metaDataIndex + i * 1;
        rowSpaceIndicator[j1] = (short)l1;
        rowSpaceIndicator[l] = rowSpaceIndicator[i1];
        System.arraycopy(rowSpaceByte, k, rowSpaceByte, j, l1);
        System.arraycopy(rowSpaceMetaData, j2, rowSpaceMetaData, i2, 1);
        lastRowProcessed++;
    }

    void saveDataFromOldDefineBuffers(byte abyte0[], char ac[], short aword0[], int i, int j)
        throws SQLException
    {
        int k = columnIndex + (j - 1) * byteLength;
        int l = columnIndexLastRow + (i - 1) * byteLength;
        int i1 = (indicatorIndex + j) - 1;
        int j1 = (indicatorIndexLastRow + i) - 1;
        int k1 = (lengthIndex + j) - 1;
        int l1 = (lengthIndexLastRow + i) - 1;
        int i2 = aword0[l1];
        rowSpaceIndicator[k1] = (short)i2;
        rowSpaceIndicator[i1] = aword0[j1];
        if(i2 != 0)
            System.arraycopy(abyte0, l, rowSpaceByte, k, i2);
    }

    ResultSet getCursor(int i)
        throws SQLException
    {
        OracleResultSetImpl oracleresultsetimpl = null;
        if(newstmt[i] != null)
        {
            for(int j = 0; j < newstmt[i].numberOfDefinePositions; j++)
                newstmt[i].accessors[j].initMetadata();

            newstmt[i].prepareAccessors();
            newstmt[i].setPrefetchInternal(statement.getFetchSize(), false, false);
            OracleResultSetImpl oracleresultsetimpl1 = new OracleResultSetImpl(newstmt[i].connection, newstmt[i]);
            oracleresultsetimpl1.close_statement_on_close = true;
            newstmt[i].currentResultSet = oracleresultsetimpl1;
            oracleresultsetimpl = oracleresultsetimpl1;
        }
        return oracleresultsetimpl;
    }

}
