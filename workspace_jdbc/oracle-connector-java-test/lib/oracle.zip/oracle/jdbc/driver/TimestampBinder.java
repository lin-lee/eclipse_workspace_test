// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;

import java.sql.SQLException;
import java.sql.Timestamp;

// Referenced classes of package oracle.jdbc.driver:
//            DateCommonBinder, Binder, OraclePreparedStatementReadOnly, OraclePreparedStatement

class TimestampBinder extends DateCommonBinder
{

    Binder theTimestampCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    static void init(Binder binder)
    {
        binder.type = 180;
        binder.bytelen = 11;
    }

    TimestampBinder()
    {
        theTimestampCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimestampCopyingBinder;
        init(this);
    }

    Binder copyingBinder()
    {
        return theTimestampCopyingBinder;
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
        throws SQLException
    {
        Timestamp atimestamp[] = oraclepreparedstatement.parameterTimestamp[k];
        Timestamp timestamp = atimestamp[i];
        if(flag)
            atimestamp[i] = null;
        if(timestamp == null)
        {
            aword0[i2] = -1;
        } else
        {
            aword0[i2] = 0;
            setOracleHMS(setOracleCYMD(timestamp.getTime(), abyte0, j1, oraclepreparedstatement), abyte0, j1);
            int j2 = timestamp.getNanos();
            if(j2 != 0)
            {
                setOracleNanos(j2, abyte0, j1);
                aword0[l1] = (short)l;
            } else
            {
                aword0[l1] = 7;
            }
        }
    }

}
