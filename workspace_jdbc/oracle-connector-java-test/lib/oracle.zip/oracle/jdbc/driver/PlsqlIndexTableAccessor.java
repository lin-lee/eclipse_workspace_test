// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   PlsqlIndexTableAccessor.java

package oracle.jdbc.driver;

import java.math.BigDecimal;
import java.sql.SQLException;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            Accessor, OraclePreparedStatement, DatabaseError, OracleStatement, 
//            DBConversion

class PlsqlIndexTableAccessor extends Accessor
{

    int elementInternalType;
    int maxNumberOfElements;
    int elementMaxLen;
    int ibtValueIndex;
    int ibtIndicatorIndex;
    int ibtLengthIndex;
    int ibtMetaIndex;
    int ibtByteLength;
    int ibtCharLength;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    PlsqlIndexTableAccessor(OracleStatement oraclestatement, int i, int j, int k, int l, short word0, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 998, 998, word0, flag);
        elementInternalType = j;
        maxNumberOfElements = l;
        elementMaxLen = k;
        initForDataAccess(i, k, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        switch(elementInternalType)
        {
        case 1: // '\001'
        case 96: // '`'
            internalTypeMaxLength = ((OraclePreparedStatement)statement).maxIbtVarcharElementLength;
            if(j > internalTypeMaxLength)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            elementMaxLen = (j != 0 ? j : internalTypeMaxLength) + 1;
            ibtCharLength = elementMaxLen * maxNumberOfElements;
            elementInternalType = 9;
            break;

        case 6: // '\006'
            internalTypeMaxLength = 21;
            elementMaxLen = internalTypeMaxLength + 1;
            ibtByteLength = elementMaxLen * maxNumberOfElements;
            break;

        default:
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    Object[] getPlsqlIndexTable(int i)
        throws SQLException
    {
        Object aobj[] = null;
        short aword0[] = statement.ibtBindIndicators;
        int j = ((aword0[ibtMetaIndex + 4] & 0xffff) << 16) + (aword0[ibtMetaIndex + 5] & 0xffff);
        int k = ibtValueIndex;
label0:
        switch(elementInternalType)
        {
        case 9: // '\t'
            aobj = new String[j];
            char ac[] = statement.ibtBindChars;
            for(int l = 0; l < j; l++)
            {
                if(aword0[ibtIndicatorIndex + l] == -1)
                    aobj[l] = null;
                else
                    aobj[l] = new String(ac, k + 1, ac[k] >> 1);
                k += elementMaxLen;
            }

            break;

        case 6: // '\006'
            aobj = new BigDecimal[j];
            byte abyte0[] = statement.ibtBindBytes;
            int i1 = 0;
            do
            {
                if(i1 >= j)
                    break label0;
                if(aword0[ibtIndicatorIndex + i1] == -1)
                {
                    aobj[i1] = null;
                } else
                {
                    byte byte0 = abyte0[k];
                    byte abyte1[] = new byte[byte0];
                    System.arraycopy(abyte0, k + 1, abyte1, 0, byte0);
                    aobj[i1] = NUMBER.toBigDecimal(abyte1);
                }
                k += elementMaxLen;
                i1++;
            } while(true);

        default:
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return aobj;
    }

    Datum[] getOraclePlsqlIndexTable(int i)
        throws SQLException
    {
        Object aobj[] = null;
        short aword0[] = statement.ibtBindIndicators;
        int j = ((aword0[ibtMetaIndex + 4] & 0xffff) << 16) + (aword0[ibtMetaIndex + 5] & 0xffff);
        int k = ibtValueIndex;
label0:
        switch(elementInternalType)
        {
        case 9: // '\t'
            aobj = new CHAR[j];
            CharacterSet characterset = CharacterSet.make(2000);
            char ac[] = statement.ibtBindChars;
            for(int l = 0; l < j; l++)
            {
                if(aword0[ibtIndicatorIndex + l] == -1)
                {
                    aobj[l] = null;
                } else
                {
                    char c = ac[k];
                    byte abyte1[] = new byte[c];
                    DBConversion.javaCharsToUcs2Bytes(ac, k + 1, abyte1, 0, c >> 1);
                    aobj[l] = new CHAR(abyte1, characterset);
                }
                k += elementMaxLen;
            }

            break;

        case 6: // '\006'
            aobj = new NUMBER[j];
            byte abyte0[] = statement.ibtBindBytes;
            int i1 = 0;
            do
            {
                if(i1 >= j)
                    break label0;
                if(aword0[ibtIndicatorIndex + i1] == -1)
                {
                    aobj[i1] = null;
                } else
                {
                    byte byte0 = abyte0[k];
                    byte abyte2[] = new byte[byte0];
                    System.arraycopy(abyte0, k + 1, abyte2, 0, byte0);
                    aobj[i1] = new NUMBER(abyte2);
                }
                k += elementMaxLen;
                i1++;
            } while(true);

        default:
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return ((Datum []) (aobj));
    }

}
