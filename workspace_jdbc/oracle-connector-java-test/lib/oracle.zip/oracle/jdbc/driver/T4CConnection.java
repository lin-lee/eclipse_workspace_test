// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CConnection.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.SocketException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collection;
import java.util.EnumSet;
import java.util.Hashtable;
import java.util.Properties;
import java.util.concurrent.Executor;
import java.util.zip.CRC32;
import oracle.jdbc.NotificationRegistration;
import oracle.jdbc.aq.AQDequeueOptions;
import oracle.jdbc.aq.AQEnqueueOptions;
import oracle.jdbc.internal.KeywordValue;
import oracle.jdbc.internal.KeywordValueLong;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.XSEventListener;
import oracle.jdbc.internal.XSNamespace;
import oracle.jdbc.pool.OraclePooledConnection;
import oracle.net.ns.Communication;
import oracle.net.ns.NSProtocol;
import oracle.net.ns.NetException;
import oracle.net.ns.SessionAtts;
import oracle.sql.BFILE;
import oracle.sql.BLOB;
import oracle.sql.BfileDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.sql.CLOB;
import oracle.sql.ClobDBAccess;
import oracle.sql.LobPlsqlUtil;
import oracle.sql.TIMESTAMPTZ;

// Referenced classes of package oracle.jdbc.driver:
//            PhysicalConnection, NTFEventListener, T4C8Oall, T4CTTIokpn, 
//            T4C8Oclose, T4CTTIsto, T4CTTIspfp, T4C7Ocommoncall, 
//            T4C8Odscrarr, T4C8TTIBfile, T4C8TTIBlob, T4C8TTIClob, 
//            T4CTTIOtxen, T4CTTIOtxse, T4CTTIoping, T4CTTIk2rpc, 
//            T4CTTIoses, T4CTTIokeyval, T4CTTIoxssro, T4CTTIoxsspo, 
//            T4CTTIoxsscs, T4CTTIxsnsop, T4Caqe, T4Caqdq, 
//            T4CTTIoscid, T4CTTIoauthenticate, T4C7Oversion, T4CStatement, 
//            T4CMAREngine, T4CTTIoer, T4C8TTIpro, DBConversion, 
//            T4C8TTIdty, Namespace, OracleBlobInputStream, OracleConversionInputStream, 
//            OracleConversionReader, OracleBlobOutputStream, OracleClobInputStream, OracleClobOutputStream, 
//            OracleClobReader, OracleClobWriter, NTFAQRegistration, NTFDCNRegistration, 
//            OracleStatement, T4CTypeRep, AutoKeyInfo, AQMessagePropertiesI, 
//            DatabaseError, OracleSql, Accessor, T4CXAResource, 
//            NTFManager, T4CTTIrxd, OracleDriverExtension, NTFXSEvent

class T4CConnection extends PhysicalConnection
    implements BfileDBAccess, BlobDBAccess, ClobDBAccess
{

    static final short MIN_TTCVER_SUPPORTED = 4;
    static final short V8_TTCVER_SUPPORTED = 5;
    static final short MAX_TTCVER_SUPPORTED = 6;
    static final int DEFAULT_LONG_PREFETCH_SIZE = 4080;
    static final String DEFAULT_CONNECT_STRING = "localhost:1521:orcl";
    static final int STREAM_CHUNK_SIZE = 255;
    static final int REFCURSOR_SIZE = 5;
    long LOGON_MODE;
    boolean isLoggedOn;
    private boolean useZeroCopyIO;
    boolean useLobPrefetch;
    private String password;
    Communication net;
    int eocs;
    private NTFEventListener xsListeners[];
    boolean readAsNonStream;
    T4CTTIoer oer;
    T4CMAREngine mare;
    T4C8TTIpro pro;
    T4CTTIrxd rxd;
    T4CTTIsto sto;
    T4CTTIspfp spfp;
    T4CTTIoauthenticate auth;
    T4C8Odscrarr describe;
    T4C8Oall all8;
    T4C8Oclose close8;
    T4C7Ocommoncall commoncall;
    T4Caqe aqe;
    T4Caqdq aqdq;
    T4C8TTIBfile bfileMsg;
    T4C8TTIBlob blobMsg;
    T4C8TTIClob clobMsg;
    T4CTTIoses oses;
    T4CTTIoping oping;
    T4CTTIokpn okpn;
    byte EMPTY_BYTE[];
    T4CTTIOtxen otxen;
    T4CTTIOtxse otxse;
    T4CTTIk2rpc k2rpc;
    T4CTTIoscid oscid;
    T4CTTIokeyval okeyval;
    T4CTTIoxsscs oxsscs;
    T4CTTIoxssro oxssro;
    T4CTTIoxsspo oxsspo;
    T4CTTIxsnsop xsnsop;
    int cursorToClose[];
    int cursorToCloseOffset;
    int lastCursorToCloseOffset;
    int queryToClose[];
    int queryToCloseOffset;
    int lusFunctionId2[];
    byte lusSessionId2[][];
    KeywordValueLong lusInKeyVal2[][];
    int lusInFlags2[];
    int lusOffset2;
    int sessionId;
    int serialNumber;
    byte negotiatedTTCversion;
    byte serverRuntimeCapabilities[];
    byte serverCompileTimeCapabilities[];
    Hashtable namespaces;
    byte internalName[];
    byte externalName[];
    static final int FREE = -1;
    static final int SEND = 1;
    static final int RECEIVE = 2;
    int pipeState;
    boolean sentCancel;
    String currentSchema;
    boolean cancelInProgressFlag;
    boolean statementCancel;
    byte currentTTCSeqNumber;
    private final CRC32 checksumEngine = new CRC32();
    private final Hashtable tempLobRefCount = new Hashtable();
    static final int MAX_SIZE_VSESSION_OSUSER = 30;
    static final int MAX_SIZE_VSESSION_PROCESS = 24;
    static final int MAX_SIZE_VSESSION_MACHINE = 64;
    static final int MAX_SIZE_VSESSION_TERMINAL = 30;
    static final int MAX_SIZE_VSESSION_PROGRAM = 48;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CConnection(String s, Properties properties, OracleDriverExtension oracledriverextension)
        throws SQLException
    {
        super(s, properties, oracledriverextension);
        LOGON_MODE = 0L;
        xsListeners = new NTFEventListener[0];
        EMPTY_BYTE = new byte[0];
        pipeState = -1;
        sentCancel = false;
        cancelInProgressFlag = false;
        statementCancel = true;
        currentTTCSeqNumber = 0;
        cursorToClose = new int[4];
        cursorToCloseOffset = 0;
        queryToClose = new int[10];
        queryToCloseOffset = 0;
        lusFunctionId2 = new int[10];
        lusSessionId2 = new byte[10][];
        lusInKeyVal2 = new KeywordValueLong[10][];
        lusInFlags2 = new int[10];
        lusOffset2 = 0;
        minVcsBindSize = 0;
        streamChunkSize = 255;
        namespaces = new Hashtable(5);
        currentSchema = null;
    }

    final void initializePassword(String s)
        throws SQLException
    {
        password = s;
    }

    void logon()
        throws SQLException
    {
        SQLException sqlexception = null;
        try
        {
            if(isLoggedOn)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 428);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            if(database == null)
                database = "localhost:1521:orcl";
            connect(database);
            all8 = new T4C8Oall(this);
            okpn = new T4CTTIokpn(this);
            close8 = new T4C8Oclose(this);
            sto = new T4CTTIsto(this);
            spfp = new T4CTTIspfp(this);
            commoncall = new T4C7Ocommoncall(this);
            describe = new T4C8Odscrarr(this);
            bfileMsg = new T4C8TTIBfile(this);
            blobMsg = new T4C8TTIBlob(this);
            clobMsg = new T4C8TTIClob(this);
            otxen = new T4CTTIOtxen(this);
            otxse = new T4CTTIOtxse(this);
            oping = new T4CTTIoping(this);
            k2rpc = new T4CTTIk2rpc(this);
            oses = new T4CTTIoses(this);
            okeyval = new T4CTTIokeyval(this);
            oxssro = new T4CTTIoxssro(this);
            oxsspo = new T4CTTIoxsspo(this);
            oxsscs = new T4CTTIoxsscs(this);
            xsnsop = new T4CTTIxsnsop(this);
            aqe = new T4Caqe(this);
            aqdq = new T4Caqdq(this);
            oscid = new T4CTTIoscid(this);
            LOGON_MODE = 0L;
            if(internalLogon != null)
                if(internalLogon.equalsIgnoreCase("sysoper"))
                    LOGON_MODE = 64L;
                else
                if(internalLogon.equalsIgnoreCase("sysdba"))
                    LOGON_MODE = 32L;
                else
                if(internalLogon.equalsIgnoreCase("sysasm"))
                    LOGON_MODE = 0x400000L;
                else
                if(internalLogon.equalsIgnoreCase("sysbackup"))
                    LOGON_MODE = 0x1000000L;
                else
                if(internalLogon.equalsIgnoreCase("sysdg"))
                    LOGON_MODE = 0x2000000L;
                else
                if(internalLogon.equalsIgnoreCase("syskm"))
                    LOGON_MODE = 0x4000000L;
            if(prelimAuth)
                LOGON_MODE = LOGON_MODE | 128L;
            auth = new T4CTTIoauthenticate(this, resourceManagerId, serverCompileTimeCapabilities);
            if(userName != null && userName.length() != 0)
                try
                {
                    auth.doOSESSKEY(userName, LOGON_MODE);
                }
                catch(SQLException sqlexception2)
                {
                    if(sqlexception2.getErrorCode() == 1017)
                    {
                        sqlexception = sqlexception2;
                        userName = null;
                    } else
                    {
                        throw sqlexception2;
                    }
                }
            auth.doOAUTH(userName, password, LOGON_MODE);
            sessionId = getSessionId();
            serialNumber = getSerialNumber();
            internalName = auth.internalName;
            externalName = auth.externalName;
            instanceName = sessionProperties.getProperty("AUTH_INSTANCENAME");
            if(!prelimAuth)
            {
                T4C7Oversion t4c7oversion = new T4C7Oversion(this);
                t4c7oversion.doOVERSION();
                byte abyte0[] = t4c7oversion.getVersion();
                try
                {
                    databaseProductVersion = new String(abyte0, "UTF8");
                }
                catch(UnsupportedEncodingException unsupportedencodingexception)
                {
                    SQLException sqlexception6 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), unsupportedencodingexception);
                    sqlexception6.fillInStackTrace();
                    throw sqlexception6;
                }
                versionNumber = t4c7oversion.getVersionNumber();
            } else
            {
                versionNumber = 0;
            }
            isLoggedOn = true;
            if(getVersionNumber() < 11000)
                enableTempLobRefCnt = false;
        }
        catch(NetException netexception)
        {
            SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), netexception);
            sqlexception4.fillInStackTrace();
            throw sqlexception4;
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception5 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception5.fillInStackTrace();
            throw sqlexception5;
        }
        catch(SQLException sqlexception3)
        {
            if(sqlexception != null)
                sqlexception3.initCause(sqlexception);
            try
            {
                net.disconnect();
            }
            catch(Exception exception) { }
            isLoggedOn = false;
            throw sqlexception3;
        }
    }

    void handleIOException(IOException ioexception)
        throws SQLException
    {
        try
        {
            pipeState = -1;
            net.disconnect();
            net = null;
        }
        catch(Exception exception) { }
        isLoggedOn = false;
        lifecycle = 4;
    }

    synchronized void logoff()
        throws SQLException
    {
        assertLoggedOn("T4CConnection.logoff");
        if(lifecycle == 8)
        {
            try
            {
                if(net != null)
                    net.disconnect();
            }
            catch(Exception exception) { }
            isLoggedOn = false;
            return;
        }
        sendPiggyBackedMessages();
        commoncall.doOLOGOFF();
        net.disconnect();
        net = null;
        try
        {
            if(net != null)
                net.disconnect();
        }
        catch(Exception exception1) { }
        isLoggedOn = false;
        break MISSING_BLOCK_LABEL_182;
        IOException ioexception;
        ioexception;
        handleIOException(ioexception);
        if(lifecycle != 8)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        try
        {
            if(net != null)
                net.disconnect();
        }
        catch(Exception exception2) { }
        isLoggedOn = false;
        break MISSING_BLOCK_LABEL_182;
        Exception exception3;
        exception3;
        try
        {
            if(net != null)
                net.disconnect();
        }
        catch(Exception exception4) { }
        isLoggedOn = false;
        throw exception3;
    }

    T4CMAREngine getMarshalEngine()
    {
        return mare;
    }

    synchronized void doCommit(int i)
        throws SQLException
    {
        assertLoggedOn("T4CConnection.do_commit");
        try
        {
            sendPiggyBackedMessages();
            if(i == 0)
            {
                commoncall.doOCOMMIT();
            } else
            {
                int j = 0;
                if((i & oracle.jdbc.OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0)
                    j = j | 2 | 1;
                else
                if((i & oracle.jdbc.OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0)
                    j |= 2;
                if((i & oracle.jdbc.OracleConnection.CommitOption.NOWAIT.getCode()) != 0)
                    j = j | 8 | 4;
                else
                if((i & oracle.jdbc.OracleConnection.CommitOption.WAIT.getCode()) != 0)
                    j |= 8;
                otxen.doOTXEN(1, null, null, 0, 0, 0, 0, 4, j);
                int k = otxen.getOutStateFromServer();
                if(k != 2)
                    if(k == 4);
            }
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    synchronized void doRollback()
        throws SQLException
    {
        try
        {
            assertLoggedOn("T4CConnection.do_rollback");
            sendPiggyBackedMessages();
            commoncall.doOROLLBACK();
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    synchronized void doSetAutoCommit(boolean flag)
        throws SQLException
    {
        autocommit = flag;
    }

    public synchronized void open(OracleStatement oraclestatement)
        throws SQLException
    {
        assertLoggedOn("T4CConnection.open");
        oraclestatement.setCursorId(0);
    }

    synchronized String doGetDatabaseProductVersion()
        throws SQLException
    {
        assertLoggedOn("T4CConnection.do_getDatabaseProductVersion");
        T4C7Oversion t4c7oversion = new T4C7Oversion(this);
        try
        {
            t4c7oversion.doOVERSION();
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        String s = null;
        byte abyte0[] = t4c7oversion.getVersion();
        try
        {
            s = new String(abyte0, "UTF8");
        }
        catch(UnsupportedEncodingException unsupportedencodingexception)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), unsupportedencodingexception);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        return s;
    }

    synchronized short doGetVersionNumber()
        throws SQLException
    {
        assertLoggedOn("T4CConnection.do_getVersionNumber");
        T4C7Oversion t4c7oversion = new T4C7Oversion(this);
        try
        {
            t4c7oversion.doOVERSION();
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return t4c7oversion.getVersionNumber();
    }

    OracleStatement RefCursorBytesToStatement(byte abyte0[], OracleStatement oraclestatement)
        throws SQLException
    {
        T4CStatement t4cstatement = new T4CStatement(this, -1, -1);
        try
        {
            int i = mare.unmarshalRefCursor(abyte0);
            t4cstatement.setCursorId(i);
            t4cstatement.isOpen = true;
            t4cstatement.sqlObject = oraclestatement.sqlObject;
            t4cstatement.serverCursor = true;
            oraclestatement.addChild(t4cstatement);
            t4cstatement.prepareForNewResults(true, false);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        t4cstatement.sqlStringChanged = false;
        t4cstatement.needToParse = false;
        return t4cstatement;
    }

    void cancelOperationOnServer(boolean flag)
        throws SQLException
    {
        Object obj = cancelInProgressLockForThin;
        JVM INSTR monitorenter ;
        if(cancelInProgressFlag)
            break MISSING_BLOCK_LABEL_135;
        pipeState;
        JVM INSTR tableswitch -1 2: default 72
    //                   -1 48
    //                   0 72
    //                   1 51
    //                   2 63;
           goto _L1 _L2 _L1 _L3 _L4
_L1:
        break; /* Loop/switch isn't completed */
_L2:
        return;
_L3:
        net.sendBreak();
        break; /* Loop/switch isn't completed */
_L4:
        net.sendInterrupt();
        sentCancel = true;
        break MISSING_BLOCK_LABEL_125;
        Object obj1;
        obj1;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ((IOException) (obj1)));
        sqlexception.fillInStackTrace();
        throw sqlexception;
        obj1;
        handleIOException(((IOException) (obj1)));
        SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ((IOException) (obj1)));
        sqlexception1.fillInStackTrace();
        throw sqlexception1;
        cancelInProgressFlag = true;
        statementCancel = flag;
        break MISSING_BLOCK_LABEL_147;
        Exception exception;
        exception;
        throw exception;
    }

    void connect(String s)
        throws IOException, SQLException
    {
        if(s == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        Properties properties = new Properties();
        if(thinNetProfile != null)
            properties.setProperty("oracle.net.profile", thinNetProfile);
        if(thinNetAuthenticationServices != null)
            properties.setProperty("oracle.net.authentication_services", thinNetAuthenticationServices);
        if(thinNetAuthenticationKrb5Mutual != null)
            properties.setProperty("oracle.net.kerberos5_mutual_authentication", thinNetAuthenticationKrb5Mutual);
        if(thinNetAuthenticationKrb5CcName != null)
            properties.setProperty("oracle.net.kerberos5_cc_name", thinNetAuthenticationKrb5CcName);
        if(thinNetEncryptionLevel != null)
            properties.setProperty("oracle.net.encryption_client", thinNetEncryptionLevel);
        if(thinNetEncryptionTypes != null)
            properties.setProperty("oracle.net.encryption_types_client", thinNetEncryptionTypes);
        if(thinNetChecksumLevel != null)
            properties.setProperty("oracle.net.crypto_checksum_client", thinNetChecksumLevel);
        if(thinNetChecksumTypes != null)
            properties.setProperty("oracle.net.crypto_checksum_types_client", thinNetChecksumTypes);
        if(thinNetCryptoSeed != null)
            properties.setProperty("oracle.net.crypto_seed", thinNetCryptoSeed);
        if(thinTcpNoDelay)
            properties.setProperty("TCP.NODELAY", "YES");
        if(thinReadTimeout != null)
            properties.setProperty("oracle.net.READ_TIMEOUT", thinReadTimeout);
        if(thinNetConnectTimeout != null)
            properties.setProperty("oracle.net.CONNECT_TIMEOUT", thinNetConnectTimeout);
        if(thinSslServerDnMatch != null)
            properties.setProperty("oracle.net.ssl_server_dn_match", thinSslServerDnMatch);
        if(walletLocation != null)
            properties.setProperty("oracle.net.wallet_location", walletLocation);
        if(walletPassword != null)
            properties.setProperty("oracle.net.wallet_password", walletPassword);
        if(thinSslVersion != null)
            properties.setProperty("oracle.net.ssl_version", thinSslVersion);
        if(thinSslCipherSuites != null)
            properties.setProperty("oracle.net.ssl_cipher_suites", thinSslCipherSuites);
        if(thinJavaxNetSslKeystore != null)
            properties.setProperty("javax.net.ssl.keyStore", thinJavaxNetSslKeystore);
        if(thinJavaxNetSslKeystoretype != null)
            properties.setProperty("javax.net.ssl.keyStoreType", thinJavaxNetSslKeystoretype);
        if(thinJavaxNetSslKeystorepassword != null)
            properties.setProperty("javax.net.ssl.keyStorePassword", thinJavaxNetSslKeystorepassword);
        if(thinJavaxNetSslTruststore != null)
            properties.setProperty("javax.net.ssl.trustStore", thinJavaxNetSslTruststore);
        if(thinJavaxNetSslTruststoretype != null)
            properties.setProperty("javax.net.ssl.trustStoreType", thinJavaxNetSslTruststoretype);
        if(thinJavaxNetSslTruststorepassword != null)
            properties.setProperty("javax.net.ssl.trustStorePassword", thinJavaxNetSslTruststorepassword);
        if(thinSslKeymanagerfactoryAlgorithm != null)
            properties.setProperty("ssl.keyManagerFactory.algorithm", thinSslKeymanagerfactoryAlgorithm);
        if(thinSslTrustmanagerfactoryAlgorithm != null)
            properties.setProperty("ssl.trustManagerFactory.algorithm", thinSslTrustmanagerfactoryAlgorithm);
        if(thinNetOldsyntax != null)
            properties.setProperty("oracle.net.oldSyntax", thinNetOldsyntax);
        if(thinNamingContextInitial != null)
            properties.setProperty("java.naming.factory.initial", thinNamingContextInitial);
        if(thinNamingProviderUrl != null)
            properties.setProperty("java.naming.provider.url", thinNamingProviderUrl);
        if(thinNamingSecurityAuthentication != null)
            properties.setProperty("java.naming.security.authentication", thinNamingSecurityAuthentication);
        if(thinNamingSecurityPrincipal != null)
            properties.setProperty("java.naming.security.principal", thinNamingSecurityPrincipal);
        if(thinNamingSecurityCredentials != null)
            properties.setProperty("java.naming.security.credentials", thinNamingSecurityCredentials);
        if(thinNetDisableOutOfBandBreak)
            properties.setProperty("DISABLE_OOB", (new StringBuilder()).append("").append(thinNetDisableOutOfBandBreak).toString());
        if(thinNetEnableSDP)
            properties.setProperty("oracle.net.SDP", (new StringBuilder()).append("").append(thinNetEnableSDP).toString());
        properties.setProperty("USE_ZERO_COPY_IO", (new StringBuilder()).append("").append(thinNetUseZeroCopyIO).toString());
        properties.setProperty("FORCE_DNS_LOAD_BALANCING", (new StringBuilder()).append("").append(thinForceDnsLoadBalancing).toString());
        properties.setProperty("ENABLE_JAVANET_FASTPATH", (new StringBuilder()).append("").append(enableJavaNetFastPath).toString());
        properties.setProperty("oracle.jdbc.v$session.osuser", thinVsessionOsuser);
        properties.setProperty("oracle.jdbc.v$session.program", thinVsessionProgram);
        properties.setProperty("T4CConnection.hashCode", Integer.toHexString(hashCode()).toUpperCase());
        properties.setProperty("oracle.net.keepAlive", Boolean.toString(keepAlive));
        net = new NSProtocol();
        net.connect(s, properties);
        mare = new T4CMAREngine(net, enableJavaNetFastPath);
        oer = new T4CTTIoer(this);
        mare.setConnectionDuringExceptionHandling(this);
        pro = new T4C8TTIpro(this);
        pro.marshal();
        serverCompileTimeCapabilities = pro.receive();
        serverRuntimeCapabilities = pro.getServerRuntimeCapabilities();
        short word0 = pro.getOracleVersion();
        short word1 = pro.getCharacterSet();
        short word2 = DBConversion.findDriverCharSet(word1, word0);
        conversion = new DBConversion(word1, word2, pro.getncharCHARSET(), isStrictAsciiConversion, isQuickAsciiConversion);
        mare.types.setServerConversion(word2 != word1);
        DBConversion _tmp = conversion;
        if(DBConversion.isCharSetMultibyte(word2))
        {
            DBConversion _tmp1 = conversion;
            if(DBConversion.isCharSetMultibyte(pro.getCharacterSet()))
                mare.types.setFlags((byte)1);
            else
                mare.types.setFlags((byte)2);
        } else
        {
            mare.types.setFlags(pro.getFlags());
        }
        mare.conv = conversion;
        T4C8TTIdty t4c8ttidty = new T4C8TTIdty(this, serverCompileTimeCapabilities, serverRuntimeCapabilities, logonCap != null && logonCap.trim().equals("o3"), thinNetUseZeroCopyIO);
        t4c8ttidty.doRPC();
        negotiatedTTCversion = serverCompileTimeCapabilities[7];
        if(t4c8ttidty.jdbcThinCompileTimeCapabilities[7] < serverCompileTimeCapabilities[7])
            negotiatedTTCversion = t4c8ttidty.jdbcThinCompileTimeCapabilities[7];
        if(serverRuntimeCapabilities != null && serverRuntimeCapabilities.length > 6 && (serverRuntimeCapabilities[6] & T4C8TTIdty.KPCCAP_RTB_TTC_ZCPY) != 0 && thinNetUseZeroCopyIO && (net.getSessionAttributes().getNegotiatedOptions() & 0x40) != 0 && getDataIntegrityAlgorithmName().equals("") && getEncryptionAlgorithmName().equals(""))
            useZeroCopyIO = true;
        else
            useZeroCopyIO = false;
        if(serverCompileTimeCapabilities.length > 23 && (serverCompileTimeCapabilities[23] & 0x40) != 0 && (t4c8ttidty.jdbcThinCompileTimeCapabilities[23] & 0x40) != 0)
            useLobPrefetch = true;
        else
            useLobPrefetch = false;
    }

    boolean isZeroCopyIOEnabled()
    {
        return useZeroCopyIO;
    }

    final T4CTTIoer getT4CTTIoer()
    {
        return oer;
    }

    final byte getTTCVersion()
    {
        return negotiatedTTCversion;
    }

    void doStartup(int i)
        throws SQLException
    {
        try
        {
            byte byte0 = 0;
            if(i == oracle.jdbc.OracleConnection.DatabaseStartupMode.FORCE.getMode())
                byte0 = 16;
            else
            if(i == oracle.jdbc.OracleConnection.DatabaseStartupMode.RESTRICT.getMode())
                byte0 = 1;
            spfp.doOSPFPPUT();
            sto.doOV6STRT(byte0);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    void doShutdown(int i)
        throws SQLException
    {
        try
        {
            char c = '\004';
            if(i == oracle.jdbc.OracleConnection.DatabaseShutdownMode.TRANSACTIONAL.getMode())
                c = '\200';
            else
            if(i == oracle.jdbc.OracleConnection.DatabaseShutdownMode.TRANSACTIONAL_LOCAL.getMode())
                c = '\u0100';
            else
            if(i == oracle.jdbc.OracleConnection.DatabaseShutdownMode.IMMEDIATE.getMode())
                c = '\002';
            else
            if(i == oracle.jdbc.OracleConnection.DatabaseShutdownMode.FINAL.getMode())
                c = '\b';
            else
            if(i == oracle.jdbc.OracleConnection.DatabaseShutdownMode.ABORT.getMode())
                c = '@';
            sendPiggyBackedMessages();
            sto.doOV6STOP(c);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    void sendPiggyBackedMessages()
        throws SQLException, IOException
    {
        sendPiggyBackedClose();
        if(endToEndAnyChanged && getTTCVersion() >= 3)
        {
            oscid.doOSCID(endToEndHasChanged, endToEndValues, endToEndECIDSequenceNumber);
            for(int i = 0; i < 4; i++)
                if(endToEndHasChanged[i])
                    endToEndHasChanged[i] = false;

        }
        endToEndAnyChanged = false;
        if(!namespaces.isEmpty())
        {
            if(getTTCVersion() >= 4)
            {
                Object aobj[] = namespaces.values().toArray();
                for(int k = 0; k < aobj.length; k++)
                    okeyval.doOKEYVAL((Namespace)aobj[k]);

            }
            namespaces.clear();
        }
        if(lusOffset2 > 0)
        {
            for(int j = 0; j < lusOffset2; j++)
                oxsspo.doOXSSPO(lusFunctionId2[j], lusSessionId2[j], lusInKeyVal2[j], lusInFlags2[j]);

            lusOffset2 = 0;
        }
    }

    private void sendPiggyBackedClose()
        throws SQLException, IOException
    {
        if(queryToCloseOffset > 0)
        {
            close8.doOCANA(queryToClose, queryToCloseOffset);
            queryToCloseOffset = 0;
        }
        if(cursorToCloseOffset > 0)
        {
            close8.doOCCA(cursorToClose, cursorToCloseOffset);
            lastCursorToCloseOffset = cursorToCloseOffset;
            cursorToCloseOffset = 0;
        }
    }

    void redoCursorClose()
    {
        if(cursorToCloseOffset == 0 && lastCursorToCloseOffset != 0)
        {
            cursorToCloseOffset = lastCursorToCloseOffset;
            lastCursorToCloseOffset = 0;
        }
    }

    synchronized void closeCursor(int i)
        throws SQLException
    {
        if(cursorToCloseOffset == cursorToClose.length)
        {
            int ai[] = new int[cursorToClose.length * 2];
            System.arraycopy(cursorToClose, 0, ai, 0, cursorToClose.length);
            cursorToClose = ai;
        }
        cursorToClose[cursorToCloseOffset++] = i;
    }

    void doProxySession(int i, Properties properties)
        throws SQLException
    {
        try
        {
            sendPiggyBackedMessages();
            auth.doOAUTH(i, properties, sessionId, serialNumber);
            int j = getSessionId();
            int k = getSerialNumber();
            oses.doO80SES(j, k, 1);
            savedUser = userName;
            if(i == 1)
                userName = properties.getProperty("PROXY_USER_NAME");
            else
                userName = null;
            isProxy = true;
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    void closeProxySession()
        throws SQLException
    {
        try
        {
            sendPiggyBackedMessages();
            commoncall.doOLOGOFF();
            oses.doO80SES(sessionId, serialNumber, 1);
            userName = savedUser;
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    void updateSessionProperties(KeywordValue akeywordvalue[])
        throws SQLException
    {
        for(int i = 0; i < akeywordvalue.length; i++)
        {
            int j = akeywordvalue[i].getKeyword();
            byte abyte0[] = akeywordvalue[i].getBinaryValue();
            if(j < T4C8Oall.NLS_KEYS.length)
            {
                String s = T4C8Oall.NLS_KEYS[j];
                if(s == null)
                    continue;
                if(abyte0 != null)
                {
                    sessionProperties.setProperty(s, mare.conv.CharBytesToString(abyte0, abyte0.length));
                    continue;
                }
                if(akeywordvalue[i].getTextValue() != null)
                    sessionProperties.setProperty(s, akeywordvalue[i].getTextValue().trim());
                continue;
            }
            if(j == 163)
            {
                if(abyte0 == null)
                    continue;
                int k = abyte0[4];
                int l = abyte0[5];
                if((abyte0[4] & 0xff) > 120)
                {
                    k = (abyte0[4] & 0xff) - 181;
                    l = (abyte0[5] & 0xff) - 60;
                } else
                {
                    k = (abyte0[4] & 0xff) - 60;
                    l = (abyte0[5] & 0xff) - 60;
                }
                String s2 = (new StringBuilder()).append(k <= 0 ? "" : "+").append(k).append(l > 9 ? ":" : ":0").append(l).toString();
                sessionProperties.setProperty("SESSION_TIME_ZONE", s2);
                continue;
            }
            if(j == 165 || j == 166 || j == 167)
                continue;
            if(j == 168)
            {
                String s1 = akeywordvalue[i].getTextValue();
                if(s1 != null)
                    currentSchema = s1.trim();
                continue;
            }
            if(j != 169 && j != 170)
                if(j != 171);
        }

    }

    public String getCurrentSchema()
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(currentSchema == null || getVersionNumber() < 11100)
            currentSchema = super.getCurrentSchema();
        return currentSchema;
    }

    public Properties getServerSessionInfo()
        throws SQLException
    {
        if(getVersionNumber() >= 10000 && getVersionNumber() < 10200)
            queryFCFProperties(sessionProperties);
        return sessionProperties;
    }

    public String getSessionTimeZoneOffset()
        throws SQLException
    {
        String s = getServerSessionInfo().getProperty("SESSION_TIME_ZONE");
        if(s == null)
            s = super.getSessionTimeZoneOffset();
        else
            s = tzToOffset(s);
        return s;
    }

    int getSessionId()
    {
        int i = -1;
        String s = sessionProperties.getProperty("AUTH_SESSION_ID");
        try
        {
            i = Integer.parseInt(s);
        }
        catch(NumberFormatException numberformatexception) { }
        return i;
    }

    int getSerialNumber()
    {
        int i = -1;
        String s = sessionProperties.getProperty("AUTH_SERIAL_NUM");
        try
        {
            i = Integer.parseInt(s);
        }
        catch(NumberFormatException numberformatexception) { }
        return i;
    }

    public byte getInstanceProperty(oracle.jdbc.internal.OracleConnection.InstanceProperty instanceproperty)
        throws SQLException
    {
        byte byte0 = 0;
        if(instanceproperty == oracle.jdbc.internal.OracleConnection.InstanceProperty.ASM_VOLUME_SUPPORTED)
        {
            if(serverRuntimeCapabilities == null || serverRuntimeCapabilities.length < 6)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            byte0 = serverRuntimeCapabilities[5];
        } else
        if(instanceproperty == oracle.jdbc.internal.OracleConnection.InstanceProperty.INSTANCE_TYPE)
        {
            if(serverRuntimeCapabilities == null || serverRuntimeCapabilities.length < 4)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            byte0 = serverRuntimeCapabilities[3];
        }
        return byte0;
    }

    public synchronized BlobDBAccess createBlobDBAccess()
        throws SQLException
    {
        return this;
    }

    public synchronized ClobDBAccess createClobDBAccess()
        throws SQLException
    {
        return this;
    }

    public synchronized BfileDBAccess createBfileDBAccess()
        throws SQLException
    {
        return this;
    }

    public synchronized long length(BFILE bfile)
        throws SQLException
    {
        assertLoggedOn("length");
        assertNotNull(bfile.shareBytes(), "length");
        needLine();
        long l = 0L;
        try
        {
            l = bfileMsg.getLength(bfile.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return l;
    }

    public synchronized long position(BFILE bfile, byte abyte0[], long l)
        throws SQLException
    {
        assertNotNull(bfile.shareBytes(), "position");
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            long l1 = LobPlsqlUtil.hasPattern(bfile, abyte0, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public long position(BFILE bfile, BFILE bfile1, long l)
        throws SQLException
    {
        assertNotNull(bfile.shareBytes(), "position");
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            long l1 = LobPlsqlUtil.isSubLob(bfile, bfile1, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public synchronized int getBytes(BFILE bfile, long l, int i, byte abyte0[])
        throws SQLException
    {
        assertLoggedOn("getBytes");
        assertNotNull(bfile.shareBytes(), "getBytes");
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(i <= 0 || abyte0 == null)
            return 0;
        if(pipeState != -1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        needLine();
        long l1 = 0L;
        if(i != 0)
            try
            {
                l1 = bfileMsg.read(bfile.shareBytes(), l, i, abyte0, 0);
            }
            catch(IOException ioexception)
            {
                handleIOException(ioexception);
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        return (int)l1;
    }

    public String getName(BFILE bfile)
        throws SQLException
    {
        assertLoggedOn("getName");
        assertNotNull(bfile.shareBytes(), "getName");
        String s = LobPlsqlUtil.fileGetName(bfile);
        return s;
    }

    public String getDirAlias(BFILE bfile)
        throws SQLException
    {
        assertLoggedOn("getDirAlias");
        assertNotNull(bfile.shareBytes(), "getDirAlias");
        String s = LobPlsqlUtil.fileGetDirAlias(bfile);
        return s;
    }

    public synchronized void openFile(BFILE bfile)
        throws SQLException
    {
        assertLoggedOn("openFile");
        assertNotNull(bfile.shareBytes(), "openFile");
        needLine();
        try
        {
            bfileMsg.open(bfile.shareBytes(), 11);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public synchronized boolean isFileOpen(BFILE bfile)
        throws SQLException
    {
        assertLoggedOn("openFile");
        assertNotNull(bfile.shareBytes(), "openFile");
        needLine();
        boolean flag = false;
        try
        {
            flag = bfileMsg.isOpen(bfile.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return flag;
    }

    public synchronized boolean fileExists(BFILE bfile)
        throws SQLException
    {
        assertLoggedOn("fileExists");
        assertNotNull(bfile.shareBytes(), "fileExists");
        needLine();
        boolean flag = false;
        try
        {
            flag = bfileMsg.doesExist(bfile.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return flag;
    }

    public synchronized void closeFile(BFILE bfile)
        throws SQLException
    {
        assertLoggedOn("closeFile");
        assertNotNull(bfile.shareBytes(), "closeFile");
        needLine();
        try
        {
            bfileMsg.close(bfile.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public synchronized void open(BFILE bfile, int i)
        throws SQLException
    {
        assertLoggedOn("open");
        assertNotNull(bfile.shareBytes(), "open");
        needLine();
        try
        {
            bfileMsg.open(bfile.shareBytes(), i);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public synchronized void close(BFILE bfile)
        throws SQLException
    {
        assertLoggedOn("close");
        assertNotNull(bfile.shareBytes(), "close");
        needLine();
        try
        {
            bfileMsg.close(bfile.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public synchronized boolean isOpen(BFILE bfile)
        throws SQLException
    {
        assertLoggedOn("isOpen");
        assertNotNull(bfile.shareBytes(), "isOpen");
        needLine();
        boolean flag = false;
        try
        {
            flag = bfileMsg.isOpen(bfile.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return flag;
    }

    public InputStream newInputStream(BFILE bfile, int i, long l)
        throws SQLException
    {
        if(l == 0L)
            return new OracleBlobInputStream(bfile, i);
        else
            return new OracleBlobInputStream(bfile, i, l);
    }

    public InputStream newConversionInputStream(BFILE bfile, int i)
        throws SQLException
    {
        assertNotNull(bfile.shareBytes(), "newConversionInputStream");
        OracleConversionInputStream oracleconversioninputstream = new OracleConversionInputStream(conversion, bfile.getBinaryStream(), i);
        return oracleconversioninputstream;
    }

    public Reader newConversionReader(BFILE bfile, int i)
        throws SQLException
    {
        assertNotNull(bfile.shareBytes(), "newConversionReader");
        OracleConversionReader oracleconversionreader = new OracleConversionReader(conversion, bfile.getBinaryStream(), i);
        return oracleconversionreader;
    }

    public synchronized long length(BLOB blob)
        throws SQLException
    {
        assertLoggedOn("length");
        assertNotNull(blob.shareBytes(), "length");
        needLine();
        long l = 0L;
        try
        {
            l = blobMsg.getLength(blob.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return l;
    }

    public long position(BLOB blob, byte abyte0[], long l)
        throws SQLException
    {
        assertLoggedOn("position");
        assertNotNull(blob.shareBytes(), "position");
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            long l1 = LobPlsqlUtil.hasPattern(blob, abyte0, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public long position(BLOB blob, BLOB blob1, long l)
        throws SQLException
    {
        assertLoggedOn("position");
        assertNotNull(blob.shareBytes(), "position");
        assertNotNull(blob1.shareBytes(), "position");
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            long l1 = LobPlsqlUtil.isSubLob(blob, blob1, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public synchronized int getBytes(BLOB blob, long l, int i, byte abyte0[])
        throws SQLException
    {
        assertLoggedOn("getBytes");
        assertNotNull(blob.shareBytes(), "getBytes");
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(pipeState != -1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(i <= 0 || abyte0 == null)
            return 0;
        long l1 = 0L;
        long l2 = -1L;
        if(blob.isActivePrefetch())
        {
            byte abyte1[] = blob.getPrefetchedData();
            int j = blob.getPrefetchedDataSize();
            l2 = blob.length();
            int k = 0;
            if(abyte1 != null)
                k = Math.min(j, abyte1.length);
            if(k > 0 && l <= (long)k)
            {
                int i1 = Math.min((k - (int)l) + 1, i);
                System.arraycopy(abyte1, (int)l - 1, abyte0, 0, i1);
                l1 += i1;
            }
        }
        if(l1 < (long)i && (l2 == -1L || (l - 1L) + l1 < l2))
        {
            needLine();
            try
            {
                l1 += blobMsg.read(blob.shareBytes(), l + l1, (long)i - l1, abyte0, (int)l1);
            }
            catch(IOException ioexception)
            {
                handleIOException(ioexception);
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        }
        return (int)l1;
    }

    public synchronized int putBytes(BLOB blob, long l, byte abyte0[], int i, int j)
        throws SQLException
    {
        assertLoggedOn("putBytes");
        assertNotNull(blob.shareBytes(), "putBytes");
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putBytes()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(abyte0 == null || j <= 0)
            return 0;
        needLine();
        long l1 = 0L;
        if(j != 0)
            try
            {
                blob.setActivePrefetch(false);
                blob.clearCachedData();
                l1 = blobMsg.write(blob.shareBytes(), l, abyte0, i, j);
            }
            catch(IOException ioexception)
            {
                handleIOException(ioexception);
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return (int)l1;
    }

    public synchronized int getChunkSize(BLOB blob)
        throws SQLException
    {
        assertLoggedOn("getChunkSize");
        assertNotNull(blob.shareBytes(), "getChunkSize");
        needLine();
        long l = 0L;
        try
        {
            l = blobMsg.getChunkSize(blob.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return (int)l;
    }

    public synchronized void trim(BLOB blob, long l)
        throws SQLException
    {
        assertLoggedOn("trim");
        assertNotNull(blob.shareBytes(), "trim");
        if(l < 0L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        needLine();
        try
        {
            blob.setActivePrefetch(false);
            blob.clearCachedData();
            blobMsg.trim(blob.shareBytes(), l);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public synchronized BLOB createTemporaryBlob(Connection connection, boolean flag, int i)
        throws SQLException
    {
        assertLoggedOn("createTemporaryBlob");
        needLine();
        BLOB blob = null;
        try
        {
            blob = (BLOB)blobMsg.createTemporaryLob(this, flag, i);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return blob;
    }

    private final synchronized Long getLocatorHash(byte abyte0[])
    {
        checksumEngine.reset();
        checksumEngine.update(abyte0, 10, 10);
        long l = checksumEngine.getValue();
        Long long1 = Long.valueOf(l);
        return long1;
    }

    public final synchronized int decrementTempLobReferenceCount(byte abyte0[])
    {
        int i = 0;
        if(enableTempLobRefCnt && abyte0 != null && abyte0.length == 40 && ((abyte0[7] & 1) > 0 || (abyte0[4] & 0x40) > 0))
        {
            Long long1 = getLocatorHash(abyte0);
            Integer integer = (Integer)tempLobRefCount.get(long1);
            if(integer != null)
            {
                i = integer.intValue() - 1;
                if(i == 0)
                    tempLobRefCount.remove(long1);
                else
                    tempLobRefCount.put(long1, Integer.valueOf(i));
            }
        }
        return i;
    }

    public final synchronized void incrementTempLobReferenceCount(byte abyte0[])
    {
        if(enableTempLobRefCnt && abyte0 != null && abyte0.length == 40 && ((abyte0[7] & 1) > 0 || (abyte0[4] & 0x40) > 0))
        {
            Long long1 = getLocatorHash(abyte0);
            Integer integer = (Integer)tempLobRefCount.get(long1);
            if(integer != null)
            {
                int i = integer.intValue();
                tempLobRefCount.put(long1, Integer.valueOf(i + 1));
            } else
            {
                tempLobRefCount.put(long1, Integer.valueOf(1));
            }
        }
    }

    public synchronized void freeTemporary(BLOB blob, boolean flag)
        throws SQLException
    {
        assertLoggedOn("freeTemporary");
        assertNotNull(blob.shareBytes(), "freeTemporary");
        needLine();
        try
        {
            blobMsg.freeTemporaryLob(blob.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public boolean isTemporary(BLOB blob)
        throws SQLException
    {
        assertNotNull(blob.shareBytes(), "isTemporary");
        boolean flag = false;
        byte abyte0[] = blob.shareBytes();
        if((abyte0[7] & 1) > 0 || (abyte0[4] & 0x40) > 0)
            flag = true;
        return flag;
    }

    public synchronized void open(BLOB blob, int i)
        throws SQLException
    {
        assertLoggedOn("open");
        assertNotNull(blob.shareBytes(), "open");
        needLine();
        try
        {
            blobMsg.open(blob.shareBytes(), i);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public synchronized void close(BLOB blob)
        throws SQLException
    {
        assertLoggedOn("close");
        assertNotNull(blob.shareBytes(), "close");
        needLine();
        try
        {
            blobMsg.close(blob.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public synchronized boolean isOpen(BLOB blob)
        throws SQLException
    {
        assertLoggedOn("isOpen");
        assertNotNull(blob.shareBytes(), "isOpen");
        needLine();
        boolean flag = false;
        try
        {
            flag = blobMsg.isOpen(blob.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return flag;
    }

    public InputStream newInputStream(BLOB blob, int i, long l)
        throws SQLException
    {
        if(l == 0L)
            return new OracleBlobInputStream(blob, i);
        else
            return new OracleBlobInputStream(blob, i, l);
    }

    public InputStream newInputStream(BLOB blob, int i, long l, long l1)
        throws SQLException
    {
        return new OracleBlobInputStream(blob, i, l, l1);
    }

    public OutputStream newOutputStream(BLOB blob, int i, long l, boolean flag)
        throws SQLException
    {
        if(l == 0L)
        {
            if(flag & lobStreamPosStandardCompliant)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            } else
            {
                return new OracleBlobOutputStream(blob, i);
            }
        } else
        {
            return new OracleBlobOutputStream(blob, i, l);
        }
    }

    public InputStream newConversionInputStream(BLOB blob, int i)
        throws SQLException
    {
        assertNotNull(blob.shareBytes(), "newConversionInputStream");
        OracleConversionInputStream oracleconversioninputstream = new OracleConversionInputStream(conversion, blob.getBinaryStream(), i);
        return oracleconversioninputstream;
    }

    public Reader newConversionReader(BLOB blob, int i)
        throws SQLException
    {
        assertNotNull(blob.shareBytes(), "newConversionReader");
        OracleConversionReader oracleconversionreader = new OracleConversionReader(conversion, blob.getBinaryStream(), i);
        return oracleconversionreader;
    }

    public synchronized long length(CLOB clob)
        throws SQLException
    {
        assertLoggedOn("length");
        assertNotNull(clob.shareBytes(), "length");
        needLine();
        long l = 0L;
        try
        {
            l = clobMsg.getLength(clob.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return l;
    }

    public long position(CLOB clob, String s, long l)
        throws SQLException
    {
        if(s == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        assertLoggedOn("position");
        assertNotNull(clob.shareBytes(), "position");
        if(l < 1L)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            char ac[] = new char[s.length()];
            s.getChars(0, ac.length, ac, 0);
            long l1 = LobPlsqlUtil.hasPattern(clob, ac, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public long position(CLOB clob, CLOB clob1, long l)
        throws SQLException
    {
        if(clob1 == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        assertLoggedOn("position");
        assertNotNull(clob.shareBytes(), "position");
        assertNotNull(clob1.shareBytes(), "position");
        if(l < 1L)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            long l1 = LobPlsqlUtil.isSubLob(clob, clob1, l);
            l1 = l1 != 0L ? l1 : -1L;
            return l1;
        }
    }

    public synchronized int getChars(CLOB clob, long l, int i, char ac[])
        throws SQLException
    {
        assertLoggedOn("getChars");
        assertNotNull(clob.shareBytes(), "getChars");
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getChars()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(pipeState != -1)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getChars()");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(i <= 0 || ac == null)
            return 0;
        long l1 = 0L;
        long l2 = -1L;
        if(clob.isActivePrefetch())
        {
            l2 = clob.length();
            char ac1[] = clob.getPrefetchedData();
            int j = clob.getPrefetchedDataSize();
            int k = 0;
            if(ac1 != null)
                k = Math.min(j, ac1.length);
            if(k > 0 && l <= (long)k)
            {
                int i1 = Math.min((k - (int)l) + 1, i);
                System.arraycopy(ac1, (int)l - 1, ac, 0, i1);
                l1 += i1;
            }
        }
        if(l1 < (long)i && (l2 == -1L || (l - 1L) + l1 < l2))
        {
            needLine();
            try
            {
                boolean flag = clob.isNCLOB();
                l1 += clobMsg.read(clob.shareBytes(), l + l1, (long)i - l1, flag, ac, (int)l1);
            }
            catch(IOException ioexception)
            {
                handleIOException(ioexception);
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        }
        return (int)l1;
    }

    public synchronized int putChars(CLOB clob, long l, char ac[], int i, int j)
        throws SQLException
    {
        assertLoggedOn("putChars");
        assertNotNull(clob.shareBytes(), "putChars");
        if(l < 1L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putChars()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(ac == null || j <= 0)
            return 0;
        needLine();
        long l1 = 0L;
        if(j != 0)
            try
            {
                boolean flag = clob.isNCLOB();
                clob.setActivePrefetch(false);
                clob.clearCachedData();
                l1 = clobMsg.write(clob.shareBytes(), l, flag, ac, i, j);
            }
            catch(IOException ioexception)
            {
                handleIOException(ioexception);
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return (int)l1;
    }

    public synchronized int getChunkSize(CLOB clob)
        throws SQLException
    {
        assertLoggedOn("getChunkSize");
        assertNotNull(clob.shareBytes(), "getChunkSize");
        needLine();
        long l = 0L;
        try
        {
            l = clobMsg.getChunkSize(clob.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return (int)l;
    }

    public synchronized void trim(CLOB clob, long l)
        throws SQLException
    {
        assertLoggedOn("trim");
        assertNotNull(clob.shareBytes(), "trim");
        if(l < 0L)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        needLine();
        try
        {
            clob.setActivePrefetch(false);
            clob.clearCachedData();
            clobMsg.trim(clob.shareBytes(), l);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public synchronized CLOB createTemporaryClob(Connection connection, boolean flag, int i, short word0)
        throws SQLException
    {
        assertLoggedOn("createTemporaryClob");
        if(word0 != 2 && word0 != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 184);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        needLine();
        CLOB clob = null;
        try
        {
            clob = (CLOB)clobMsg.createTemporaryLob(this, flag, i, word0);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        return clob;
    }

    public synchronized void freeTemporary(CLOB clob, boolean flag)
        throws SQLException
    {
        assertLoggedOn("freeTemporary");
        assertNotNull(clob.shareBytes(), "freeTemporary");
        needLine();
        try
        {
            clobMsg.freeTemporaryLob(clob.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public boolean isTemporary(CLOB clob)
        throws SQLException
    {
        boolean flag = false;
        byte abyte0[] = clob.shareBytes();
        if((abyte0[7] & 1) > 0 || (abyte0[4] & 0x40) > 0)
            flag = true;
        return flag;
    }

    public synchronized void open(CLOB clob, int i)
        throws SQLException
    {
        assertLoggedOn("open");
        assertNotNull(clob.shareBytes(), "open");
        needLine();
        try
        {
            clobMsg.open(clob.shareBytes(), i);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public synchronized void close(CLOB clob)
        throws SQLException
    {
        assertLoggedOn("close");
        assertNotNull(clob.shareBytes(), "close");
        needLine();
        try
        {
            clobMsg.close(clob.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public synchronized boolean isOpen(CLOB clob)
        throws SQLException
    {
        assertLoggedOn("isOpen");
        assertNotNull(clob.shareBytes(), "isOpen");
        boolean flag = false;
        needLine();
        try
        {
            flag = clobMsg.isOpen(clob.shareBytes());
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return flag;
    }

    public InputStream newInputStream(CLOB clob, int i, long l)
        throws SQLException
    {
        if(l == 0L)
            return new OracleClobInputStream(clob, i);
        else
            return new OracleClobInputStream(clob, i, l);
    }

    public OutputStream newOutputStream(CLOB clob, int i, long l, boolean flag)
        throws SQLException
    {
        if(l == 0L)
        {
            if(flag & lobStreamPosStandardCompliant)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            } else
            {
                return new OracleClobOutputStream(clob, i);
            }
        } else
        {
            return new OracleClobOutputStream(clob, i, l);
        }
    }

    public Reader newReader(CLOB clob, int i, long l)
        throws SQLException
    {
        if(l == 0L)
            return new OracleClobReader(clob, i);
        else
            return new OracleClobReader(clob, i, l);
    }

    public Reader newReader(CLOB clob, int i, long l, long l1)
        throws SQLException
    {
        return new OracleClobReader(clob, i, l, l1);
    }

    public Writer newWriter(CLOB clob, int i, long l, boolean flag)
        throws SQLException
    {
        if(l == 0L)
        {
            if(flag & lobStreamPosStandardCompliant)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            } else
            {
                return new OracleClobWriter(clob, i);
            }
        } else
        {
            return new OracleClobWriter(clob, i, l);
        }
    }

    void assertLoggedOn(String s)
        throws SQLException
    {
        if(!isLoggedOn)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 430);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    boolean isLoggedOn()
    {
        return isLoggedOn;
    }

    void assertNotNull(byte abyte0[], String s)
        throws NullPointerException
    {
        if(abyte0 == null)
            throw new NullPointerException("bytes are null");
        else
            return;
    }

    void internalClose()
        throws SQLException
    {
        super.internalClose();
        isLoggedOn = false;
        try
        {
            if(net != null)
                net.disconnect();
        }
        catch(Exception exception) { }
    }

    void doAbort()
        throws SQLException
    {
        try
        {
            net.abort();
        }
        catch(NetException netexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), netexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    protected void doDescribeTable(AutoKeyInfo autokeyinfo)
        throws SQLException
    {
        T4CStatement t4cstatement = new T4CStatement(this, -1, -1);
        t4cstatement.open();
        String s = autokeyinfo.getTableName();
        String s1 = (new StringBuilder()).append("SELECT * FROM ").append(s).toString();
        t4cstatement.sqlObject.initialize(s1);
        Accessor aaccessor[] = null;
        try
        {
            describe.doODNY(t4cstatement, 0, aaccessor, t4cstatement.sqlObject.getSqlBytes(false, false));
            aaccessor = describe.getAccessors();
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        int i = describe.numuds;
        autokeyinfo.allocateSpaceForDescribedData(i);
        for(int j1 = 0; j1 < i; j1++)
        {
            Accessor accessor = aaccessor[j1];
            String s2 = accessor.columnName;
            int j = accessor.describeType;
            int k = accessor.describeMaxLength;
            boolean flag = accessor.nullable;
            short word0 = accessor.formOfUse;
            int l = accessor.precision;
            int i1 = accessor.scale;
            String s3 = accessor.describeTypeName;
            autokeyinfo.fillDescribedData(j1, s2, j, k, flag, word0, l, i1, s3);
        }

        t4cstatement.close();
    }

    void doSetApplicationContext(String s, String s1, String s2)
        throws SQLException
    {
        Namespace namespace = (Namespace)namespaces.get(s);
        if(namespace == null)
        {
            namespace = new Namespace(s);
            namespaces.put(s, namespace);
        }
        namespace.setAttribute(s1, s2);
    }

    void doClearAllApplicationContext(String s)
        throws SQLException
    {
        Namespace namespace = new Namespace(s);
        namespace.clear();
        namespaces.put(s, namespace);
    }

    public void getPropertyForPooledConnection(OraclePooledConnection oraclepooledconnection)
        throws SQLException
    {
        super.getPropertyForPooledConnection(oraclepooledconnection, password);
    }

    final void getPasswordInternal(T4CXAResource t4cxaresource)
        throws SQLException
    {
        t4cxaresource.setPasswordInternal(password);
    }

    synchronized void doEnqueue(String s, AQEnqueueOptions aqenqueueoptions, AQMessagePropertiesI aqmessagepropertiesi, byte abyte0[], byte abyte1[], byte abyte2[][], boolean flag)
        throws SQLException
    {
        try
        {
            needLine();
            sendPiggyBackedMessages();
            aqe.doOAQEQ(s, aqenqueueoptions, aqmessagepropertiesi, abyte1, abyte0, flag);
            if(aqenqueueoptions.getRetrieveMessageId())
                abyte2[0] = aqe.getMessageId();
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    synchronized boolean doDequeue(String s, AQDequeueOptions aqdequeueoptions, AQMessagePropertiesI aqmessagepropertiesi, byte abyte0[], byte abyte1[][], byte abyte2[][], boolean flag)
        throws SQLException
    {
        boolean flag1 = false;
        try
        {
            needLine();
            sendPiggyBackedMessages();
            aqdq.doOAQDQ(s, aqdequeueoptions, abyte0, flag, aqmessagepropertiesi);
            abyte1[0] = aqdq.getPayload();
            abyte2[0] = aqdq.getDequeuedMessageId();
            flag1 = aqdq.hasAMessageBeenDequeued();
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return flag1;
    }

    synchronized int doPingDatabase()
        throws SQLException
    {
        if(versionNumber >= 10102)
        {
            try
            {
                needLine();
                sendPiggyBackedMessages();
                oping.doOPING();
            }
            catch(IOException ioexception)
            {
                return -1;
            }
            catch(SQLException sqlexception)
            {
                return -1;
            }
            return 0;
        } else
        {
            return super.doPingDatabase();
        }
    }

    synchronized NTFAQRegistration[] doRegisterAQNotification(String as[], String s, int i, Properties aproperties[])
        throws SQLException
    {
        int j = as.length;
        int ai[] = new int[j];
        byte abyte0[][] = new byte[j][];
        int ai1[] = new int[j];
        int ai2[] = new int[j];
        int ai3[] = new int[j];
        int ai4[] = new int[j];
        int ai5[] = new int[j];
        int ai6[] = new int[j];
        long al[] = new long[j];
        byte abyte1[] = new byte[j];
        int ai7[] = new int[j];
        byte abyte2[] = new byte[j];
        TIMESTAMPTZ atimestamptz[] = new TIMESTAMPTZ[j];
        int ai8[] = new int[j];
        boolean flag = false;
        if(i == 0)
        {
            flag = true;
            i = 47632;
        }
        for(int k = 0; k < j; k++)
        {
            ai[k] = PhysicalConnection.ntfManager.getNextJdbcRegId();
            abyte0[k] = new byte[4];
            abyte0[k][0] = (byte)((ai[k] & 0xff000000) >> 24);
            abyte0[k][1] = (byte)((ai[k] & 0xff0000) >> 16);
            abyte0[k][2] = (byte)((ai[k] & 0xff00) >> 8);
            abyte0[k][3] = (byte)(ai[k] & 0xff);
            ai1[k] = 1;
            ai2[k] = 23;
            if(aproperties.length <= k || aproperties[k] == null)
                continue;
            if(aproperties[k].getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
                ai3[k] |= 1;
            if(aproperties[k].getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
                ai3[k] |= 0x10;
            if(aproperties[k].getProperty("NTF_AQ_PAYLOAD", "false").compareToIgnoreCase("true") == 0)
                ai3[k] |= 2;
            ai4[k] = readNTFtimeout(aproperties[k]);
        }

        setNtfGroupingOptions(abyte1, ai7, abyte2, atimestamptz, ai8, aproperties);
        int ai9[] = new int[1];
        ai9[0] = i;
        boolean flag1 = PhysicalConnection.ntfManager.listenOnPortT4C(ai9, flag);
        i = ai9[0];
        String s1 = (new StringBuilder()).append("(ADDRESS=(PROTOCOL=tcp)(HOST=").append(s).append(")(PORT=").append(i).append("))?PR=0").toString();
        try
        {
            try
            {
                int l = flag1 ? 1 : 0;
                sendPiggyBackedMessages();
                okpn.doOKPN(1, l, userName, s1, j, ai1, as, abyte0, ai2, ai3, ai4, ai5, ai6, al, abyte1, ai7, abyte2, atimestamptz, ai8);
            }
            catch(IOException ioexception)
            {
                handleIOException(ioexception);
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }
        catch(SQLException sqlexception)
        {
            if(flag1)
                PhysicalConnection.ntfManager.cleanListenersT4C(i);
            throw sqlexception;
        }
        NTFAQRegistration antfaqregistration[] = new NTFAQRegistration[j];
        for(int i1 = 0; i1 < j; i1++)
            antfaqregistration[i1] = new NTFAQRegistration(ai[i1], true, instanceName, userName, s, i, aproperties[i1], as[i1], versionNumber);

        for(int j1 = 0; j1 < antfaqregistration.length; j1++)
            PhysicalConnection.ntfManager.addRegistration(antfaqregistration[j1]);

        return antfaqregistration;
    }

    private void setNtfGroupingOptions(byte abyte0[], int ai[], byte abyte1[], TIMESTAMPTZ atimestamptz[], int ai1[], Properties aproperties[])
        throws SQLException
    {
        for(int i = 0; i < aproperties.length; i++)
        {
            String s = aproperties[i].getProperty("NTF_GROUPING_CLASS", "NTF_GROUPING_CLASS_NONE");
            String s1 = aproperties[i].getProperty("NTF_GROUPING_VALUE");
            String s2 = aproperties[i].getProperty("NTF_GROUPING_TYPE");
            TIMESTAMPTZ timestamptz = null;
            if(aproperties[i].get("NTF_GROUPING_START_TIME") != null)
                timestamptz = (TIMESTAMPTZ)aproperties[i].get("NTF_GROUPING_START_TIME");
            String s3 = aproperties[i].getProperty("NTF_GROUPING_REPEAT_TIME", "NTF_GROUPING_REPEAT_FOREVER");
            if(s.compareTo("NTF_GROUPING_CLASS_TIME") != 0 && s.compareTo("NTF_GROUPING_CLASS_NONE") != 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(s.compareTo("NTF_GROUPING_CLASS_NONE") != 0 && getTTCVersion() < 5)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            if(s.compareTo("NTF_GROUPING_CLASS_TIME") != 0)
                continue;
            abyte0[i] = 1;
            ai[i] = 600;
            if(s1 != null)
                ai[i] = Integer.parseInt(s1);
            abyte1[i] = 1;
            if(s2 != null)
                if(s2.compareTo("NTF_GROUPING_TYPE_SUMMARY") == 0)
                    abyte1[i] = 1;
                else
                if(s2.compareTo("NTF_GROUPING_TYPE_LAST") == 0)
                {
                    abyte1[i] = 2;
                } else
                {
                    SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                    sqlexception2.fillInStackTrace();
                    throw sqlexception2;
                }
            atimestamptz[i] = timestamptz;
            if(s3.compareTo("NTF_GROUPING_REPEAT_FOREVER") == 0)
                ai1[i] = 0;
            else
                ai1[i] = Integer.parseInt(s3);
        }

    }

    synchronized void doUnregisterAQNotification(NTFAQRegistration ntfaqregistration)
        throws SQLException
    {
        String s = ntfaqregistration.getClientHost();
        int i = ntfaqregistration.getClientTCPPort();
        if(s == null)
            return;
        PhysicalConnection.ntfManager.removeRegistration(ntfaqregistration);
        PhysicalConnection.ntfManager.freeJdbcRegId(ntfaqregistration.getJdbcRegId());
        PhysicalConnection.ntfManager.cleanListenersT4C(ntfaqregistration.getClientTCPPort());
        ntfaqregistration.setState(oracle.jdbc.NotificationRegistration.RegistrationState.CLOSED);
        String s1 = (new StringBuilder()).append("(ADDRESS=(PROTOCOL=tcp)(HOST=").append(s).append(")(PORT=").append(i).append("))?PR=0").toString();
        int ai[] = {
            1
        };
        String as[] = new String[1];
        as[0] = ntfaqregistration.getQueueName();
        int ai1[] = {
            0
        };
        int ai2[] = {
            0
        };
        int ai3[] = {
            0
        };
        int ai4[] = {
            0
        };
        int ai5[] = {
            0
        };
        long al[] = {
            0L
        };
        byte abyte0[] = {
            0
        };
        int ai6[] = {
            0
        };
        byte abyte1[] = {
            0
        };
        TIMESTAMPTZ atimestamptz[] = {
            null
        };
        int ai7[] = {
            0
        };
        byte abyte2[][] = new byte[1][];
        int j = ntfaqregistration.getJdbcRegId();
        abyte2[0] = new byte[4];
        abyte2[0][0] = (byte)((j & 0xff000000) >> 24);
        abyte2[0][1] = (byte)((j & 0xff0000) >> 16);
        abyte2[0][2] = (byte)((j & 0xff00) >> 8);
        abyte2[0][3] = (byte)(j & 0xff);
        try
        {
            sendPiggyBackedMessages();
            okpn.doOKPN(2, 0, userName, s1, 1, ai, as, abyte2, ai1, ai2, ai3, ai4, ai5, al, abyte0, ai6, abyte1, atimestamptz, ai7);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    synchronized NTFDCNRegistration doRegisterDatabaseChangeNotification(String s, int i, Properties properties, int j, int k)
        throws SQLException
    {
        int l = 0;
        int i1 = 0;
        boolean flag = false;
        boolean flag1 = false;
        boolean flag2 = false;
        Object obj = null;
        boolean flag3 = false;
        boolean flag4 = false;
        if(i == 0)
        {
            flag4 = true;
            i = 47632;
        }
        if(properties.getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
            i1 |= 1;
        if(properties.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
            i1 |= 0x10;
        if(properties.getProperty("DCN_NOTIFY_ROWIDS", "false").compareToIgnoreCase("true") == 0)
            l |= 0x10;
        if(properties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION", "false").compareToIgnoreCase("true") == 0)
            l |= 0x20;
        if(properties.getProperty("DCN_BEST_EFFORT", "false").compareToIgnoreCase("true") == 0)
            l |= 0x40;
        boolean flag5 = false;
        boolean flag6 = false;
        boolean flag7 = false;
        if(properties.getProperty("DCN_IGNORE_INSERTOP", "false").compareToIgnoreCase("true") == 0)
            flag5 = true;
        if(properties.getProperty("DCN_IGNORE_UPDATEOP", "false").compareToIgnoreCase("true") == 0)
            flag6 = true;
        if(properties.getProperty("DCN_IGNORE_DELETEOP", "false").compareToIgnoreCase("true") == 0)
            flag7 = true;
        if(flag5 || flag6 || flag7)
        {
            l |= 0xf;
            if(flag5)
                l -= 2;
            if(flag6)
                l -= 4;
            if(flag7)
                l -= 8;
        }
        byte abyte0[] = new byte[1];
        int ai[] = new int[1];
        byte abyte1[] = new byte[1];
        TIMESTAMPTZ atimestamptz[] = new TIMESTAMPTZ[1];
        int ai1[] = new int[1];
        Properties aproperties[] = {
            properties
        };
        setNtfGroupingOptions(abyte0, ai, abyte1, atimestamptz, ai1, aproperties);
        int ai2[] = new int[1];
        ai2[0] = i;
        boolean flag8 = PhysicalConnection.ntfManager.listenOnPortT4C(ai2, flag4);
        i = ai2[0];
        String s1 = (new StringBuilder()).append("(ADDRESS=(PROTOCOL=tcp)(HOST=").append(s).append(")(PORT=").append(i).append("))?PR=0").toString();
        int ai3[] = {
            2
        };
        String as[] = new String[1];
        int ai4[] = {
            23
        };
        int ai5[] = {
            i1
        };
        int ai6[] = {
            j
        };
        int ai7[] = {
            l
        };
        int ai8[] = {
            k
        };
        long al[] = {
            0L
        };
        int j1 = PhysicalConnection.ntfManager.getNextJdbcRegId();
        byte abyte2[][] = new byte[1][];
        abyte2[0] = new byte[4];
        abyte2[0][0] = (byte)((j1 & 0xff000000) >> 24);
        abyte2[0][1] = (byte)((j1 & 0xff0000) >> 16);
        abyte2[0][2] = (byte)((j1 & 0xff00) >> 8);
        abyte2[0][3] = (byte)(j1 & 0xff);
        long l1 = 0L;
        try
        {
            try
            {
                int k1 = flag8 ? 1 : 0;
                sendPiggyBackedMessages();
                okpn.doOKPN(1, k1, userName, s1, 1, ai3, as, abyte2, ai4, ai5, ai6, ai7, ai8, al, abyte0, ai, abyte1, atimestamptz, ai1);
                l1 = okpn.getRegistrationId();
            }
            catch(IOException ioexception)
            {
                handleIOException(ioexception);
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }
        catch(SQLException sqlexception)
        {
            if(flag8)
                PhysicalConnection.ntfManager.cleanListenersT4C(i);
            throw sqlexception;
        }
        NTFDCNRegistration ntfdcnregistration = new NTFDCNRegistration(j1, true, instanceName, l1, userName, s, i, properties, versionNumber);
        return ntfdcnregistration;
    }

    synchronized void doUnregisterDatabaseChangeNotification(long l, String s)
        throws SQLException
    {
        int ai[] = {
            2
        };
        String as[] = new String[1];
        int ai1[] = {
            0
        };
        int ai2[] = {
            0
        };
        int ai3[] = {
            0
        };
        int ai4[] = {
            0
        };
        int ai5[] = {
            0
        };
        byte abyte0[] = {
            0
        };
        int ai6[] = {
            0
        };
        byte abyte1[] = {
            0
        };
        TIMESTAMPTZ atimestamptz[] = {
            null
        };
        int ai7[] = {
            0
        };
        long al[] = {
            l
        };
        byte abyte2[][] = new byte[1][];
        try
        {
            sendPiggyBackedMessages();
            okpn.doOKPN(2, 0, null, s, 1, ai, as, abyte2, ai1, ai2, ai3, ai4, ai5, al, abyte0, ai6, abyte1, atimestamptz, ai7);
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    synchronized void doUnregisterDatabaseChangeNotification(NTFDCNRegistration ntfdcnregistration)
        throws SQLException
    {
        PhysicalConnection.ntfManager.removeRegistration(ntfdcnregistration);
        PhysicalConnection.ntfManager.freeJdbcRegId(ntfdcnregistration.getJdbcRegId());
        PhysicalConnection.ntfManager.cleanListenersT4C(ntfdcnregistration.getClientTCPPort());
        ntfdcnregistration.setState(oracle.jdbc.NotificationRegistration.RegistrationState.CLOSED);
        doUnregisterDatabaseChangeNotification(ntfdcnregistration.getRegId(), (new StringBuilder()).append("(ADDRESS=(PROTOCOL=tcp)(HOST=").append(ntfdcnregistration.getClientHost()).append(")(PORT=").append(ntfdcnregistration.getClientTCPPort()).append("))?PR=0").toString());
    }

    public String getDataIntegrityAlgorithmName()
        throws SQLException
    {
        return net.getDataIntegrityName();
    }

    public String getEncryptionAlgorithmName()
        throws SQLException
    {
        return net.getEncryptionName();
    }

    public String getAuthenticationAdaptorName()
        throws SQLException
    {
        return net.getAuthenticationAdaptorName();
    }

    void validateConnectionProperties()
        throws SQLException
    {
        super.validateConnectionProperties();
        String s = ".*[\\00\\(\\)].*";
        if(thinVsessionOsuser != null && (thinVsessionOsuser.matches(s) || thinVsessionOsuser.length() > 30))
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, 190, (new StringBuilder()).append("Property is 'v$session.osuser' and value is '").append(thinVsessionOsuser).append("'").toString());
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(thinVsessionTerminal != null && (thinVsessionTerminal.matches(s) || thinVsessionTerminal.length() > 30))
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(null, 190, (new StringBuilder()).append("Property is 'v$session.terminal' and value is '").append(thinVsessionTerminal).append("'").toString());
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(thinVsessionMachine != null && (thinVsessionMachine.matches(s) || thinVsessionMachine.length() > 64))
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(null, 190, (new StringBuilder()).append("Property is 'v$session.machine' and value is '").append(thinVsessionMachine).append("'").toString());
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        if(thinVsessionProgram != null && (thinVsessionProgram.matches(s) || thinVsessionProgram.length() > 48))
        {
            SQLException sqlexception3 = DatabaseError.createSqlException(null, 190, (new StringBuilder()).append("Property is 'v$session.program' and value is '").append(thinVsessionProgram).append("'").toString());
            sqlexception3.fillInStackTrace();
            throw sqlexception3;
        }
        if(thinVsessionProcess != null && (thinVsessionProcess.matches(s) || thinVsessionProcess.length() > 24))
        {
            SQLException sqlexception4 = DatabaseError.createSqlException(null, 190, (new StringBuilder()).append("Property is 'v$session.process' and value is '").append(thinVsessionProcess).append("'").toString());
            sqlexception4.fillInStackTrace();
            throw sqlexception4;
        }
        if(thinVsessionIname != null && thinVsessionIname.matches(s))
        {
            SQLException sqlexception5 = DatabaseError.createSqlException(null, 190, (new StringBuilder()).append("Property is 'v$session.iname' and value is '").append(thinVsessionIname).append("'").toString());
            sqlexception5.fillInStackTrace();
            throw sqlexception5;
        }
        if(thinVsessionEname != null && thinVsessionEname.matches(s))
        {
            SQLException sqlexception6 = DatabaseError.createSqlException(null, 190, (new StringBuilder()).append("Property is 'v$session.ename' and value is '").append(thinVsessionEname).append("'").toString());
            sqlexception6.fillInStackTrace();
            throw sqlexception6;
        } else
        {
            return;
        }
    }

    public synchronized byte[] createLightweightSession(String s, KeywordValueLong akeywordvaluelong[], int i, KeywordValueLong akeywordvaluelong1[][], int ai[])
        throws SQLException
    {
        if(akeywordvaluelong1.length != 1 || ai.length != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        byte abyte0[] = null;
        try
        {
            sendPiggyBackedMessages();
            oxsscs.doOXSSCS(s, akeywordvaluelong, i);
            abyte0 = oxsscs.getSessionId();
            akeywordvaluelong1[0] = oxsscs.getOutKV();
            ai[0] = oxsscs.getOutFlags();
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        return abyte0;
    }

    private synchronized void doXSNamespaceOp(oracle.jdbc.internal.OracleConnection.XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[], XSNamespace axsnamespace1[][], boolean flag)
        throws SQLException
    {
        XSNamespace axsnamespace2[] = null;
        try
        {
            if(flag)
                sendPiggyBackedMessages();
            xsnsop.doOXSNS(xsoperationcode, abyte0, axsnamespace, flag);
            if(flag)
                axsnamespace2 = xsnsop.getNamespaces();
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(axsnamespace1 != null && axsnamespace1.length > 0)
            axsnamespace1[0] = axsnamespace2;
    }

    public void doXSNamespaceOp(oracle.jdbc.internal.OracleConnection.XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[], XSNamespace axsnamespace1[][])
        throws SQLException
    {
        doXSNamespaceOp(xsoperationcode, abyte0, axsnamespace, axsnamespace1, true);
    }

    public void doXSNamespaceOp(oracle.jdbc.internal.OracleConnection.XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[])
        throws SQLException
    {
        doXSNamespaceOp(xsoperationcode, abyte0, axsnamespace, (XSNamespace[][])null, false);
    }

    public synchronized void executeLightweightSessionRoundtrip(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j, KeywordValueLong akeywordvaluelong1[][], int ai[])
        throws SQLException
    {
        if(akeywordvaluelong1.length != 1 || ai.length != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        try
        {
            sendPiggyBackedMessages();
            oxssro.doOXSSRO(i, abyte0, akeywordvaluelong, j);
            akeywordvaluelong1[0] = oxssro.getOutKV();
            ai[0] = oxssro.getOutFlags();
        }
        catch(IOException ioexception)
        {
            handleIOException(ioexception);
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public synchronized void executeLightweightSessionPiggyback(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j)
        throws SQLException
    {
        if(lusOffset2 == lusFunctionId2.length)
        {
            int k = lusFunctionId2.length;
            int ai[] = new int[k * 2];
            System.arraycopy(lusFunctionId2, 0, ai, 0, k);
            byte abyte1[][] = new byte[k * 2][];
            System.arraycopy(lusSessionId2, 0, abyte1, 0, k);
            KeywordValueLong akeywordvaluelong1[][] = new KeywordValueLong[k * 2][];
            System.arraycopy(lusInKeyVal2, 0, akeywordvaluelong1, 0, k);
            int ai1[] = new int[k * 2];
            System.arraycopy(lusInFlags2, 0, ai1, 0, k);
            lusFunctionId2 = ai;
            lusSessionId2 = abyte1;
            lusInKeyVal2 = akeywordvaluelong1;
            lusInFlags2 = ai1;
        }
        lusFunctionId2[lusOffset2] = i;
        lusSessionId2[lusOffset2] = abyte0;
        lusInKeyVal2[lusOffset2] = akeywordvaluelong;
        lusInFlags2[lusOffset2] = j;
        lusOffset2++;
    }

    public void addXSEventListener(XSEventListener xseventlistener, Executor executor)
        throws SQLException
    {
        if(lifecycle != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        NTFEventListener ntfeventlistener = new NTFEventListener(xseventlistener);
        ntfeventlistener.setExecutor(executor);
        synchronized(xsListeners)
        {
            int i = xsListeners.length;
            for(int j = 0; j < i; j++)
                if(xsListeners[j].getXSEventListener() == xseventlistener)
                {
                    SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 248);
                    sqlexception1.fillInStackTrace();
                    throw sqlexception1;
                }

            NTFEventListener antfeventlistener1[] = new NTFEventListener[i + 1];
            System.arraycopy(xsListeners, 0, antfeventlistener1, 0, i);
            antfeventlistener1[i] = ntfeventlistener;
            xsListeners = antfeventlistener1;
        }
    }

    public void addXSEventListener(XSEventListener xseventlistener)
        throws SQLException
    {
        addXSEventListener(xseventlistener, null);
    }

    public void removeXSEventListener(XSEventListener xseventlistener)
        throws SQLException
    {
        synchronized(xsListeners)
        {
            int i = 0;
            int k = xsListeners.length;
            for(i = 0; i < k && xsListeners[i].getXSEventListener() != xseventlistener; i++);
            if(i == k)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 249);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            NTFEventListener antfeventlistener1[] = new NTFEventListener[k - 1];
            int l = 0;
            for(int j = 0; j < k; j++)
                if(xsListeners[j].getXSEventListener() != xseventlistener)
                    antfeventlistener1[l++] = xsListeners[j];

            xsListeners = antfeventlistener1;
        }
    }

    void notify(final NTFXSEvent event)
    {
        NTFEventListener antfeventlistener[] = xsListeners;
        int i = antfeventlistener.length;
        for(int j = 0; j < i; j++)
        {
            Executor executor = antfeventlistener[j].getExecutor();
            if(executor != null)
            {
                final XSEventListener l = antfeventlistener[j].getXSEventListener();
                executor.execute(new Runnable() {

                    final XSEventListener val$l;
                    final NTFXSEvent val$event;
                    final T4CConnection this$0;

                    public void run()
                    {
                        l.onXSEvent(event);
                    }

            
            {
                this$0 = T4CConnection.this;
                l = xseventlistener;
                event = ntfxsevent;
                super();
            }
                }
);
            } else
            {
                antfeventlistener[j].getXSEventListener().onXSEvent(event);
            }
        }

    }

    final boolean hasServerCompileTimeCapability(int i, int j)
    {
        boolean flag = false;
        if(serverCompileTimeCapabilities != null && serverCompileTimeCapabilities.length > i && (serverCompileTimeCapabilities[i] & j) != 0)
            flag = true;
        return flag;
    }

    long doGetCurrentSCN()
        throws SQLException
    {
        return outScn;
    }

    EnumSet doGetTransactionState()
        throws SQLException
    {
        EnumSet enumset = EnumSet.noneOf(oracle/jdbc/internal/OracleConnection$TransactionState);
        if((eocs & 1) != 0)
            enumset.add(oracle.jdbc.internal.OracleConnection.TransactionState.TRANSACTION_READONLY);
        if((eocs & 2) != 0)
            enumset.add(oracle.jdbc.internal.OracleConnection.TransactionState.TRANSACTION_STARTED);
        if((eocs & 4) != 0)
            enumset.add(oracle.jdbc.internal.OracleConnection.TransactionState.TRANSACTION_ENDED);
        if((eocs & 0x400) != 0)
            enumset.add(oracle.jdbc.internal.OracleConnection.TransactionState.TRANSACTION_INTENTION);
        return enumset;
    }

    public boolean isConnectionSocketKeepAlive()
        throws SocketException
    {
        return net.isConnectionSocketKeepAlive();
    }

    byte getNextSeqNumber()
    {
        if(currentTTCSeqNumber == 127)
        {
            currentTTCSeqNumber = 1;
            return currentTTCSeqNumber;
        } else
        {
            return ++currentTTCSeqNumber;
        }
    }

}
