// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C8Odscrarr.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CTTIdcb, OracleStatement, PhysicalConnection, 
//            T4CMAREngine, Accessor, T4CConnection

final class T4C8Odscrarr extends T4CTTIfun
{

    private static final byte OPERATIONFLAGS = 7;
    private static final long SQLPARSEVERSION = 2L;
    byte sqltext[];
    T4CTTIdcb dcb;
    int cursor_id;
    int numuds;
    private static final boolean UDSARRAYO2U = true;
    private static final boolean NUMUDSO2U = true;
    OracleStatement statement;
    private Accessor accessors[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C8Odscrarr(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        cursor_id = 0;
        numuds = 0;
        statement = null;
        setFunCode((short)98);
        dcb = new T4CTTIdcb(t4cconnection);
    }

    void doODNY(OracleStatement oraclestatement, int i, Accessor aaccessor[], byte abyte0[])
        throws IOException, SQLException
    {
        numuds = 0;
        cursor_id = oraclestatement.cursorId;
        statement = oraclestatement;
        if(abyte0 != null && abyte0.length > 0)
            sqltext = abyte0;
        else
            sqltext = PhysicalConnection.EMPTY_BYTE_ARRAY;
        dcb.init(oraclestatement, i);
        accessors = aaccessor;
        numuds = 0;
        doRPC();
    }

    void marshal()
        throws IOException
    {
        meg.marshalUB1((short)7);
        meg.marshalSWORD(cursor_id);
        if(sqltext.length == 0)
            meg.marshalNULLPTR();
        else
            meg.marshalPTR();
        meg.marshalSB4(sqltext.length);
        meg.marshalUB4(2L);
        meg.marshalO2U(true);
        meg.marshalO2U(true);
        meg.marshalCHR(sqltext);
        sqltext = PhysicalConnection.EMPTY_BYTE_ARRAY;
    }

    Accessor[] getAccessors()
    {
        return accessors;
    }

    void readRPA()
        throws IOException, SQLException
    {
        accessors = dcb.receiveCommon(accessors, true);
        numuds = dcb.numuds;
    }

}
