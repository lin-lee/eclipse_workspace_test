// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C8Oclose.java

package oracle.jdbc.driver;

import java.io.IOException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CMAREngine, T4CConnection

final class T4C8Oclose extends T4CTTIfun
{

    private int cursorId[];
    private int offset;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C8Oclose(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)17);
        cursorId = null;
        offset = 0;
    }

    void doOCANA(int ai[], int i)
        throws IOException
    {
        setFunCode((short)120);
        cursorId = ai;
        offset = i;
        doPigRPC();
    }

    void doOCCA(int ai[], int i)
        throws IOException
    {
        setFunCode((short)105);
        cursorId = ai;
        offset = i;
        doPigRPC();
    }

    void marshal()
        throws IOException
    {
        meg.marshalPTR();
        meg.marshalUB4(offset);
        for(int i = 0; i < offset; i++)
            meg.marshalUB4(cursorId[i]);

    }

}
