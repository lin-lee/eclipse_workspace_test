// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4C8TTIpro.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, T4CMAREngine, DatabaseError, T4CTypeRep, 
//            T4CConnection

class T4C8TTIpro extends T4CTTIMsg
{

    short svrCharSet;
    short svrCharSetElem;
    byte svrFlags;
    byte proSvrStr[];
    short proSvrVer;
    short oVersion;
    boolean svrInfoAvailable;
    byte proCliVerTTC8[] = {
        6, 5, 4, 3, 2, 1, 0
    };
    byte proCliStrTTC8[] = {
        74, 97, 118, 97, 95, 84, 84, 67, 45, 56, 
        46, 50, 46, 48, 0
    };
    short NCHAR_CHARSET;
    byte runtimeCapabilities[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4C8TTIpro(T4CConnection t4cconnection)
        throws SQLException, IOException
    {
        super(t4cconnection, (byte)1);
        oVersion = -1;
        svrInfoAvailable = false;
        NCHAR_CHARSET = 0;
        runtimeCapabilities = null;
    }

    byte[] receive()
        throws SQLException, IOException
    {
        if(meg.unmarshalUB1() != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        proSvrVer = meg.unmarshalUB1();
        meg.proSvrVer = proSvrVer;
        switch(proSvrVer)
        {
        case 4: // '\004'
            oVersion = 7230;
            break;

        case 5: // '\005'
            oVersion = 8030;
            break;

        case 6: // '\006'
            oVersion = 8100;
            break;

        default:
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 444);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        meg.unmarshalUB1();
        proSvrStr = meg.unmarshalTEXT(50);
        oVersion = getOracleVersion();
        svrCharSet = (short)meg.unmarshalUB2();
        svrFlags = (byte)meg.unmarshalUB1();
        if((svrCharSetElem = (short)meg.unmarshalUB2()) > 0)
            meg.unmarshalNBytes(svrCharSetElem * 5);
        svrInfoAvailable = true;
        if(proSvrVer < 5)
            return null;
        byte byte0 = meg.types.getRep((byte)1);
        meg.types.setRep((byte)1, (byte)0);
        int i = meg.unmarshalUB2();
        meg.types.setRep((byte)1, byte0);
        byte abyte0[] = meg.unmarshalNBytes(i);
        int j = 6 + (abyte0[5] & 0xff) + (abyte0[6] & 0xff);
        NCHAR_CHARSET = (short)((abyte0[j + 3] & 0xff) << 8);
        NCHAR_CHARSET |= (short)(abyte0[j + 4] & 0xff);
        if(proSvrVer < 6)
            return null;
        short word0 = meg.unmarshalUB1();
        byte abyte1[] = new byte[word0];
        for(int k = 0; k < word0; k++)
            abyte1[k] = (byte)meg.unmarshalUB1();

        word0 = meg.unmarshalUB1();
        if(word0 > 0)
        {
            runtimeCapabilities = new byte[word0];
            for(int l = 0; l < word0; l++)
                runtimeCapabilities[l] = (byte)meg.unmarshalUB1();

        }
        return abyte1;
    }

    short getOracleVersion()
    {
        return oVersion;
    }

    byte[] getServerRuntimeCapabilities()
    {
        return runtimeCapabilities;
    }

    short getCharacterSet()
    {
        return svrCharSet;
    }

    short getncharCHARSET()
    {
        return NCHAR_CHARSET;
    }

    byte getFlags()
    {
        return svrFlags;
    }

    void marshal()
        throws SQLException, IOException
    {
        marshalTTCcode();
        meg.marshalB1Array(proCliVerTTC8);
        meg.marshalB1Array(proCliStrTTC8);
    }

    void printServerInfo()
    {
        if(svrInfoAvailable)
        {
            int i = 0;
            StringWriter stringwriter = new StringWriter();
            stringwriter.write("Protocol string  =");
            while(i < proSvrStr.length) 
                stringwriter.write((char)proSvrStr[i++]);
        }
    }

}
