// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIxsnsop.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.internal.XSNamespace;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, XSNamespaceI, T4CMAREngine, T4CConnection

class T4CTTIxsnsop extends T4CTTIfun
{

    private oracle.jdbc.internal.OracleConnection.XSOperationCode operationCode;
    private byte sessionId[];
    private XSNamespace namespaces[];
    private XSNamespace outNamespaces[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIxsnsop(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        setFunCode((short)172);
    }

    void doOXSNS(oracle.jdbc.internal.OracleConnection.XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[], boolean flag)
        throws IOException, SQLException
    {
        if(flag)
            setTTCCode((byte)3);
        else
            setTTCCode((byte)17);
        operationCode = xsoperationcode;
        sessionId = abyte0;
        namespaces = axsnamespace;
        if(namespaces != null)
        {
            for(int i = 0; i < namespaces.length; i++)
                ((XSNamespaceI)namespaces[i]).doCharConversion(meg.conv);

        }
        if(flag)
            doRPC();
        else
            doPigRPC();
    }

    void marshal()
        throws IOException
    {
        meg.marshalUB4(operationCode.getCode());
        boolean flag = false;
        if(sessionId != null && sessionId.length > 0)
        {
            flag = true;
            meg.marshalPTR();
            meg.marshalUB4(sessionId.length);
        } else
        {
            meg.marshalNULLPTR();
            meg.marshalUB4(0L);
        }
        boolean flag1 = false;
        meg.marshalPTR();
        if(namespaces != null && namespaces.length > 0)
        {
            flag1 = true;
            meg.marshalUB4(namespaces.length);
        } else
        {
            meg.marshalUB4(0L);
        }
        meg.marshalPTR();
        if(flag)
            meg.marshalB1Array(sessionId);
        if(flag1)
        {
            for(int i = 0; i < namespaces.length; i++)
                ((XSNamespaceI)namespaces[i]).marshal(meg);

        }
    }

    void readRPA()
        throws SQLException, IOException
    {
        outNamespaces = null;
        int i = (int)meg.unmarshalUB4();
        if(i > 0)
        {
            outNamespaces = new XSNamespace[i];
            for(int j = 0; j < i; j++)
                outNamespaces[j] = XSNamespaceI.unmarshal(meg);

        }
    }

    XSNamespace[] getNamespaces()
        throws SQLException
    {
        return outNamespaces;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
