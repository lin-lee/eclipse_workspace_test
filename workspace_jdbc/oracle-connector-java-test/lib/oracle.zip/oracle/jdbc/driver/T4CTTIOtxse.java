// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIOtxse.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CMAREngine, T4CConnection

final class T4CTTIOtxse extends T4CTTIfun
{

    static final int OTXSTA = 1;
    static final int OTXDET = 2;
    static final int OCI_TRANS_NEW = 1;
    static final int OCI_TRANS_JOIN = 2;
    static final int OCI_TRANS_RESUME = 4;
    static final int OCI_TRANS_STARTMASK = 255;
    static final int OCI_TRANS_READONLY = 256;
    static final int OCI_TRANS_READWRITE = 512;
    static final int OCI_TRANS_SERIALIZABLE = 1024;
    static final int OCI_TRANS_ISOLMASK = 65280;
    static final int OCI_TRANS_LOOSE = 0x10000;
    static final int OCI_TRANS_TIGHT = 0x20000;
    static final int OCI_TRANS_TYPEMASK = 0xf0000;
    static final int OCI_TRANS_NOMIGRATE = 0x100000;
    static final int OCI_TRANS_SEPARABLE = 0x200000;
    boolean sendTransactionContext;
    private int operation;
    private int formatId;
    private int gtridLength;
    private int bqualLength;
    private int timeout;
    private int flag;
    private int xidapp[];
    private byte transactionContext[];
    private byte xid[];
    private int applicationValue;
    private byte ctx[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIOtxse(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        sendTransactionContext = false;
        xidapp = null;
        xid = null;
        applicationValue = -1;
        ctx = null;
        setFunCode((short)103);
    }

    void doOTXSE(int i, byte abyte0[], byte abyte1[], int j, int k, int l, int i1, 
            int j1, int ai[])
        throws IOException, SQLException
    {
        if(i != 1 && i != 2)
            throw new SQLException("Invalid operation.");
        operation = i;
        formatId = j;
        gtridLength = k;
        bqualLength = l;
        timeout = i1;
        flag = j1;
        xidapp = ai;
        transactionContext = abyte0;
        xid = abyte1;
        applicationValue = -1;
        ctx = null;
        if(operation == 2 && transactionContext == null)
        {
            throw new SQLException("Transaction context cannot be null when detach is called.");
        } else
        {
            doRPC();
            return;
        }
    }

    void marshal()
        throws IOException
    {
        int i = operation;
        meg.marshalSWORD(i);
        if(operation == 2)
        {
            sendTransactionContext = true;
            meg.marshalPTR();
        } else
        {
            sendTransactionContext = false;
            meg.marshalNULLPTR();
        }
        if(transactionContext == null)
            meg.marshalUB4(0L);
        else
            meg.marshalUB4(transactionContext.length);
        meg.marshalUB4(formatId);
        meg.marshalUB4(gtridLength);
        meg.marshalUB4(bqualLength);
        if(xid != null)
            meg.marshalPTR();
        else
            meg.marshalNULLPTR();
        if(xid != null)
            meg.marshalUB4(xid.length);
        else
            meg.marshalUB4(0L);
        meg.marshalUB4(flag);
        meg.marshalUWORD(timeout);
        if(xidapp != null)
            meg.marshalPTR();
        else
            meg.marshalNULLPTR();
        meg.marshalPTR();
        meg.marshalPTR();
        boolean flag1 = false;
        boolean flag2 = false;
        if(connection.getTTCVersion() >= 5)
        {
            if(connection.internalName != null)
            {
                flag1 = true;
                meg.marshalPTR();
                meg.marshalUB4(connection.internalName.length);
            } else
            {
                meg.marshalNULLPTR();
                meg.marshalUB4(0L);
            }
            if(connection.externalName != null)
            {
                flag2 = true;
                meg.marshalPTR();
                meg.marshalUB4(connection.externalName.length);
            } else
            {
                meg.marshalNULLPTR();
                meg.marshalUB4(0L);
            }
        }
        if(sendTransactionContext)
            meg.marshalB1Array(transactionContext);
        if(xid != null)
            meg.marshalB1Array(xid);
        if(xidapp != null)
            meg.marshalUB4(xidapp[0]);
        if(connection.getTTCVersion() >= 5)
        {
            if(flag1)
                meg.marshalCHR(connection.internalName);
            if(flag2)
                meg.marshalCHR(connection.externalName);
        }
    }

    byte[] getContext()
    {
        return ctx;
    }

    int getApplicationValue()
    {
        return applicationValue;
    }

    void readRPA()
        throws IOException, SQLException
    {
        applicationValue = (int)meg.unmarshalUB4();
        int i = meg.unmarshalUB2();
        ctx = meg.unmarshalNBytes(i);
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
