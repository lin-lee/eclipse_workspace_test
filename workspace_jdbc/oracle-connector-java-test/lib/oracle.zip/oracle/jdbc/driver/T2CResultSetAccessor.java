// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T2CResultSetAccessor.java

package oracle.jdbc.driver;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            ResultSetAccessor, T2CConnection, DatabaseError, OracleStatement

class T2CResultSetAccessor extends ResultSetAccessor
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T2CResultSetAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        super(oraclestatement, i * 2, word0, j, flag);
    }

    T2CResultSetAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        super(oraclestatement, i * 2, flag, j, k, l, i1, j1, word0);
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        byte abyte0[] = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            short word0 = rowSpaceIndicator[lengthIndex + i];
            byte byte0 = ((T2CConnection)statement.connection).byteAlign;
            int j = columnIndex + (byte0 - 1) & ~(byte0 - 1);
            int k = j + word0 * i;
            abyte0 = new byte[word0];
            System.arraycopy(rowSpaceByte, k, abyte0, 0, word0);
        }
        return abyte0;
    }

}
