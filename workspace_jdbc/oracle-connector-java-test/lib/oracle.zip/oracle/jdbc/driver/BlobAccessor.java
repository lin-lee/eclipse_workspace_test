// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   BlobAccessor.java

package oracle.jdbc.driver;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.sql.BLOB;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.driver:
//            Accessor, DatabaseError, OracleStatement

class BlobAccessor extends Accessor
{

    static final int maxLength = 4000;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    BlobAccessor(OracleStatement oraclestatement, int i, short word0, int j, boolean flag)
        throws SQLException
    {
        init(oraclestatement, 113, 113, word0, flag);
        initForDataAccess(j, i, null);
    }

    BlobAccessor(OracleStatement oraclestatement, int i, boolean flag, int j, int k, int l, int i1, 
            int j1, short word0)
        throws SQLException
    {
        init(oraclestatement, 113, 113, word0, false);
        initForDescribe(113, i, flag, j, k, l, i1, j1, word0, null);
        initForDataAccess(0, i, null);
    }

    void initForDataAccess(int i, int j, String s)
        throws SQLException
    {
        if(i != 0)
            externalType = i;
        internalTypeMaxLength = 4000;
        if(j > 0 && j < internalTypeMaxLength)
            internalTypeMaxLength = j;
        byteLength = internalTypeMaxLength;
    }

    Object getObject(int i)
        throws SQLException
    {
        return getBLOB(i);
    }

    Object getObject(int i, Map map)
        throws SQLException
    {
        return getBLOB(i);
    }

    Datum getOracleObject(int i)
        throws SQLException
    {
        return getBLOB(i);
    }

    BLOB getBLOB(int i)
        throws SQLException
    {
        BLOB blob = null;
        if(rowSpaceIndicator == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(rowSpaceIndicator[indicatorIndex + i] != -1)
        {
            int j = columnIndex + byteLength * i;
            short word0 = rowSpaceIndicator[lengthIndex + i];
            byte abyte0[] = new byte[word0];
            System.arraycopy(rowSpaceByte, j, abyte0, 0, word0);
            blob = new BLOB(statement.connection, abyte0);
            if(lobPrefetchSizeForThisColumn != -1 && prefetchedLobSize != null)
            {
                blob.setActivePrefetch(true);
                blob.setLength(prefetchedLobSize[i]);
                blob.setChunkSize(prefetchedLobChunkSize[i]);
                if(prefetchedLobDataL != null && prefetchedLobDataL[i] > 0)
                    initializeBlobForPrefetch(i, blob);
                else
                    blob.setPrefetchedData(null);
            }
        }
        return blob;
    }

    void initializeBlobForPrefetch(int i, BLOB blob)
        throws SQLException
    {
        int j = prefetchedLobDataL[i];
        byte abyte0[] = prefetchedLobData[i];
        byte abyte1[] = new byte[j];
        System.arraycopy(abyte0, 0, abyte1, 0, j);
        blob.setPrefetchedData(abyte1);
    }

    InputStream getAsciiStream(int i)
        throws SQLException
    {
        BLOB blob = getBLOB(i);
        if(blob == null)
            return null;
        else
            return blob.asciiStreamValue();
    }

    Reader getCharacterStream(int i)
        throws SQLException
    {
        BLOB blob = getBLOB(i);
        if(blob == null)
            return null;
        else
            return blob.characterStreamValue();
    }

    InputStream getBinaryStream(int i)
        throws SQLException
    {
        BLOB blob = getBLOB(i);
        if(blob == null)
            return null;
        else
            return blob.getBinaryStream();
    }

    byte[] privateGetBytes(int i)
        throws SQLException
    {
        return super.getBytes(i);
    }

    byte[] getBytes(int i)
        throws SQLException
    {
        BLOB blob = getBLOB(i);
        if(blob == null)
            return null;
        InputStream inputstream = blob.getBinaryStream();
        int j = blob.getBufferSize();
        int k = 0;
        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(j);
        byte abyte0[] = new byte[j];
        try
        {
            while((k = inputstream.read(abyte0)) != -1) 
                bytearrayoutputstream.write(abyte0, 0, k);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        catch(IndexOutOfBoundsException indexoutofboundsexception)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(blob.isTemporary())
            statement.addToTempLobsToFree(blob);
        return bytearrayoutputstream.toByteArray();
    }

    String getString(int i)
        throws SQLException
    {
        unimpl("getString");
        return null;
    }

    String getNString(int i)
        throws SQLException
    {
        unimpl("getNString");
        return null;
    }

    long checksum(long l, int i)
        throws SQLException
    {
        unimpl("checksum");
        return -1L;
    }

}
