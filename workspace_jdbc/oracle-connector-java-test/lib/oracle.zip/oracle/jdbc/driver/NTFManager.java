// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NTFManager.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.net.*;
import java.nio.channels.ServerSocketChannel;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Hashtable;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            NTFListener, NTFRegistration, DatabaseError

class NTFManager
{

    private Hashtable nsListeners;
    private Hashtable ntfRegistrations;
    private byte listOfJdbcRegId[];
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    NTFManager()
    {
        nsListeners = new Hashtable();
        ntfRegistrations = new Hashtable();
        listOfJdbcRegId = new byte[20];
    }

    synchronized boolean listenOnPortT4C(int ai[], boolean flag)
        throws SQLException
    {
        int i;
        boolean flag1;
        i = ai[0];
        flag1 = false;
_L2:
        if(nsListeners.get(Integer.valueOf(i)) != null)
            break MISSING_BLOCK_LABEL_186;
        ServerSocketChannel serversocketchannel;
        ServerSocket serversocket;
        InetSocketAddress inetsocketaddress;
        serversocketchannel = ServerSocketChannel.open();
        serversocketchannel.configureBlocking(false);
        serversocket = serversocketchannel.socket();
        inetsocketaddress = new InetSocketAddress(i);
        try
        {
            serversocket.bind(inetsocketaddress);
            flag1 = true;
            NTFListener ntflistener = new NTFListener(this, serversocketchannel, i);
            nsListeners.put(Integer.valueOf(i), ntflistener);
            ntflistener.start();
            break MISSING_BLOCK_LABEL_186;
        }
        catch(BindException bindexception)
        {
            if(!flag)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 250);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            i++;
        }
        catch(IOException ioexception1)
        {
            if(!flag)
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 250);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
            i++;
        }
        if(true) goto _L2; else goto _L1
_L1:
        IOException ioexception;
        ioexception;
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
        sqlexception.fillInStackTrace();
        throw sqlexception;
        ai[0] = i;
        return flag1;
    }

    synchronized int getNextJdbcRegId()
    {
        int i;
        for(i = 1; i < listOfJdbcRegId.length && listOfJdbcRegId[i] != 0; i++);
        if(i == listOfJdbcRegId.length - 1)
        {
            byte abyte0[] = new byte[listOfJdbcRegId.length * 2];
            System.arraycopy(listOfJdbcRegId, 0, abyte0, 0, listOfJdbcRegId.length);
            listOfJdbcRegId = abyte0;
        }
        listOfJdbcRegId[i] = 2;
        return i;
    }

    synchronized void addRegistration(NTFRegistration ntfregistration)
    {
        Integer integer = Integer.valueOf(ntfregistration.getJdbcRegId());
        Hashtable hashtable = (Hashtable)ntfRegistrations.clone();
        hashtable.put(integer, ntfregistration);
        ntfRegistrations = hashtable;
    }

    synchronized boolean removeRegistration(NTFRegistration ntfregistration)
    {
        Integer integer = Integer.valueOf(ntfregistration.getJdbcRegId());
        Hashtable hashtable = (Hashtable)ntfRegistrations.clone();
        Object obj = hashtable.remove(integer);
        ntfRegistrations = hashtable;
        boolean flag = false;
        if(obj != null)
            flag = true;
        return flag;
    }

    synchronized void freeJdbcRegId(int i)
    {
        if(listOfJdbcRegId != null && listOfJdbcRegId.length > i)
            listOfJdbcRegId[i] = 0;
    }

    synchronized void cleanListenersT4C(int i)
    {
        Enumeration enumeration = ntfRegistrations.keys();
        boolean flag = false;
        do
        {
            if(flag || !enumeration.hasMoreElements())
                break;
            Object obj = enumeration.nextElement();
            NTFRegistration ntfregistration = (NTFRegistration)ntfRegistrations.get(obj);
            if(ntfregistration.getClientTCPPort() == i)
                flag = true;
        } while(true);
        if(!flag)
        {
            NTFListener ntflistener = (NTFListener)nsListeners.get(Integer.valueOf(i));
            if(ntflistener != null)
            {
                ntflistener.closeThisListener();
                ntflistener.interrupt();
                nsListeners.remove(Integer.valueOf(i));
            }
        }
    }

    NTFRegistration getRegistration(int i)
    {
        Integer integer = Integer.valueOf(i);
        Hashtable hashtable = ntfRegistrations;
        NTFRegistration ntfregistration = (NTFRegistration)hashtable.get(integer);
        return ntfregistration;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
