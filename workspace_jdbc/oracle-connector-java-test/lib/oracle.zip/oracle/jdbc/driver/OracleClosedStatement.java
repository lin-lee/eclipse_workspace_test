// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleClosedStatement.java

package oracle.jdbc.driver;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import java.util.Map;
import oracle.jdbc.*;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.jdbc.internal.*;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            DatabaseError, OracleStatement

class OracleClosedStatement
    implements OracleCallableStatement
{

    private oracle.jdbc.driver.OracleStatement wrapper;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleClosedStatement()
    {
    }

    public void setArray(int i, Array array)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setArrayAtName(String s, Array array)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setArray(String s, Array array)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBigDecimal(int i, BigDecimal bigdecimal)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBigDecimalAtName(String s, BigDecimal bigdecimal)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBigDecimal(String s, BigDecimal bigdecimal)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBlob(int i, Blob blob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBlobAtName(String s, Blob blob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBlob(String s, Blob blob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBoolean(int i, boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBooleanAtName(String s, boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBoolean(String s, boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setByte(int i, byte byte0)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setByteAtName(String s, byte byte0)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setByte(String s, byte byte0)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBytes(int i, byte abyte0[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBytesAtName(String s, byte abyte0[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBytes(String s, byte abyte0[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setClob(int i, Clob clob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setClobAtName(String s, Clob clob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setClob(String s, Clob clob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDate(int i, Date date)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDateAtName(String s, Date date)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDate(String s, Date date)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDate(int i, Date date, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDateAtName(String s, Date date, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDate(String s, Date date, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDouble(int i, double d)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDoubleAtName(String s, double d)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDouble(String s, double d)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setFloat(int i, float f)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setFloatAtName(String s, float f)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setFloat(String s, float f)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setInt(int i, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setIntAtName(String s, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setInt(String s, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setLong(int i, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setLongAtName(String s, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setLong(String s, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNClob(int i, NClob nclob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNClobAtName(String s, NClob nclob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNClob(String s, NClob nclob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNString(int i, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNStringAtName(String s, String s1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNString(String s, String s1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setObject(int i, Object obj)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setObjectAtName(String s, Object obj)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setObject(String s, Object obj)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setObject(int i, Object obj, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setObjectAtName(String s, Object obj, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setObject(String s, Object obj, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRef(int i, Ref ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRefAtName(String s, Ref ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRef(String s, Ref ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRowId(int i, RowId rowid)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRowIdAtName(String s, RowId rowid)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRowId(String s, RowId rowid)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setShort(int i, short word0)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setShortAtName(String s, short word0)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setShort(String s, short word0)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setSQLXML(int i, SQLXML sqlxml)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setSQLXMLAtName(String s, SQLXML sqlxml)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setSQLXML(String s, SQLXML sqlxml)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setString(int i, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setStringAtName(String s, String s1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setString(String s, String s1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTime(int i, Time time)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTimeAtName(String s, Time time)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTime(String s, Time time)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTime(int i, Time time, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTimeAtName(String s, Time time, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTime(String s, Time time, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTimestamp(int i, Timestamp timestamp)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTimestampAtName(String s, Timestamp timestamp)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTimestamp(String s, Timestamp timestamp)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTimestamp(int i, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTimestampAtName(String s, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTimestamp(String s, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setURL(int i, URL url)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setURLAtName(String s, URL url)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setURL(String s, URL url)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setARRAY(int i, ARRAY array)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setARRAYAtName(String s, ARRAY array)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setARRAY(String s, ARRAY array)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBFILE(int i, BFILE bfile)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBFILEAtName(String s, BFILE bfile)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBFILE(String s, BFILE bfile)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBfile(int i, BFILE bfile)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBfileAtName(String s, BFILE bfile)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBfile(String s, BFILE bfile)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryFloat(int i, float f)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryFloatAtName(String s, float f)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryFloat(String s, float f)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryFloat(int i, BINARY_FLOAT binary_float)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryFloatAtName(String s, BINARY_FLOAT binary_float)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryFloat(String s, BINARY_FLOAT binary_float)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryDouble(int i, double d)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryDoubleAtName(String s, double d)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryDouble(String s, double d)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryDouble(int i, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryDoubleAtName(String s, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryDouble(String s, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBLOB(int i, BLOB blob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBLOBAtName(String s, BLOB blob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBLOB(String s, BLOB blob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCHAR(int i, CHAR char1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCHARAtName(String s, CHAR char1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCHAR(String s, CHAR char1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCLOB(int i, CLOB clob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCLOBAtName(String s, CLOB clob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCLOB(String s, CLOB clob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCursor(int i, ResultSet resultset)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCursorAtName(String s, ResultSet resultset)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCursor(String s, ResultSet resultset)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCustomDatum(int i, CustomDatum customdatum)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCustomDatumAtName(String s, CustomDatum customdatum)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCustomDatum(String s, CustomDatum customdatum)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDATE(int i, DATE date)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDATEAtName(String s, DATE date)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDATE(String s, DATE date)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setFixedCHAR(int i, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setFixedCHARAtName(String s, String s1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setFixedCHAR(String s, String s1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setINTERVALDS(int i, INTERVALDS intervalds)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setINTERVALDSAtName(String s, INTERVALDS intervalds)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setINTERVALDS(String s, INTERVALDS intervalds)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setINTERVALYM(int i, INTERVALYM intervalym)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setINTERVALYMAtName(String s, INTERVALYM intervalym)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setINTERVALYM(String s, INTERVALYM intervalym)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNUMBER(int i, NUMBER number)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNUMBERAtName(String s, NUMBER number)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNUMBER(String s, NUMBER number)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setOPAQUE(int i, OPAQUE opaque)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setOPAQUEAtName(String s, OPAQUE opaque)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setOPAQUE(String s, OPAQUE opaque)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setOracleObject(int i, Datum datum)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setOracleObjectAtName(String s, Datum datum)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setOracleObject(String s, Datum datum)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setORAData(int i, ORAData oradata)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setORADataAtName(String s, ORAData oradata)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setORAData(String s, ORAData oradata)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRAW(int i, RAW raw)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRAWAtName(String s, RAW raw)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRAW(String s, RAW raw)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setREF(int i, REF ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setREFAtName(String s, REF ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setREF(String s, REF ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRefType(int i, REF ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRefTypeAtName(String s, REF ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRefType(String s, REF ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setROWID(int i, ROWID rowid)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setROWIDAtName(String s, ROWID rowid)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setROWID(String s, ROWID rowid)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setSTRUCT(int i, STRUCT struct)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setSTRUCTAtName(String s, STRUCT struct)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setSTRUCT(String s, STRUCT struct)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTIMESTAMPLTZ(int i, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTIMESTAMPLTZAtName(String s, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTIMESTAMPLTZ(String s, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTIMESTAMPTZ(int i, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTIMESTAMPTZAtName(String s, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTIMESTAMPTZ(String s, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTIMESTAMP(int i, TIMESTAMP timestamp)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTIMESTAMPAtName(String s, TIMESTAMP timestamp)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setTIMESTAMP(String s, TIMESTAMP timestamp)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBlob(int i, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBlobAtName(String s, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBlob(String s, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBlob(int i, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBlobAtName(String s, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBlob(String s, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setClob(int i, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setClobAtName(String s, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setClob(String s, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setClob(int i, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setClobAtName(String s, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setClob(String s, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNClob(int i, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNClobAtName(String s, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNClob(String s, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNClob(int i, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNClobAtName(String s, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNClob(String s, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setAsciiStream(int i, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setAsciiStreamAtName(String s, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setAsciiStream(String s, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setAsciiStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setAsciiStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setAsciiStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setAsciiStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setAsciiStreamAtName(String s, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setAsciiStream(String s, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryStream(int i, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryStreamAtName(String s, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryStream(String s, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryStreamAtName(String s, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBinaryStream(String s, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCharacterStream(int i, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCharacterStreamAtName(String s, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCharacterStream(String s, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCharacterStream(int i, Reader reader, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCharacterStreamAtName(String s, Reader reader, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCharacterStream(String s, Reader reader, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCharacterStreamAtName(String s, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCharacterStream(String s, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNCharacterStream(int i, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNCharacterStreamAtName(String s, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNCharacterStream(String s, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNCharacterStreamAtName(String s, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNCharacterStream(String s, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setUnicodeStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setUnicodeStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setUnicodeStream(String s, InputStream inputstream, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Array getArray(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Array getArray(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BigDecimal getBigDecimal(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BigDecimal getBigDecimal(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BigDecimal getBigDecimal(int i, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BigDecimal getBigDecimal(String s, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Blob getBlob(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Blob getBlob(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean getBoolean(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean getBoolean(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public byte getByte(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public byte getByte(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public byte[] getBytes(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public byte[] getBytes(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Clob getClob(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Clob getClob(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Date getDate(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Date getDate(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Date getDate(int i, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Date getDate(String s, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public double getDouble(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public double getDouble(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public float getFloat(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public float getFloat(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getInt(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getInt(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public long getLong(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public long getLong(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public NClob getNClob(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public NClob getNClob(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public String getNString(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public String getNString(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Object getObject(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Object getObject(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Object getObject(int i, Map map)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Object getObject(String s, Map map)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Ref getRef(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Ref getRef(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public RowId getRowId(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public RowId getRowId(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public short getShort(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public short getShort(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public SQLXML getSQLXML(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public SQLXML getSQLXML(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public String getString(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public String getString(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Time getTime(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Time getTime(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Time getTime(int i, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Time getTime(String s, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Timestamp getTimestamp(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Timestamp getTimestamp(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Timestamp getTimestamp(int i, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Timestamp getTimestamp(String s, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public URL getURL(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public URL getURL(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ARRAY getARRAY(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ARRAY getARRAY(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BFILE getBFILE(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BFILE getBFILE(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BFILE getBfile(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BFILE getBfile(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BLOB getBLOB(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public BLOB getBLOB(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public CHAR getCHAR(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public CHAR getCHAR(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public CLOB getCLOB(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public CLOB getCLOB(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSet getCursor(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSet getCursor(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public CustomDatum getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public CustomDatum getCustomDatum(String s, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public DATE getDATE(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public DATE getDATE(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public INTERVALDS getINTERVALDS(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public INTERVALDS getINTERVALDS(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public INTERVALYM getINTERVALYM(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public INTERVALYM getINTERVALYM(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public NUMBER getNUMBER(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public NUMBER getNUMBER(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public OPAQUE getOPAQUE(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public OPAQUE getOPAQUE(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Datum getOracleObject(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Datum getOracleObject(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ORAData getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ORAData getORAData(String s, ORADataFactory oradatafactory)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Object getObject(String s, OracleDataFactory oracledatafactory)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public RAW getRAW(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public RAW getRAW(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public REF getREF(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public REF getREF(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ROWID getROWID(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ROWID getROWID(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public STRUCT getSTRUCT(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public STRUCT getSTRUCT(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public TIMESTAMPLTZ getTIMESTAMPLTZ(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public TIMESTAMPTZ getTIMESTAMPTZ(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public TIMESTAMP getTIMESTAMP(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public TIMESTAMP getTIMESTAMP(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public InputStream getAsciiStream(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public InputStream getAsciiStream(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public InputStream getBinaryStream(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public InputStream getBinaryStream(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Reader getCharacterStream(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Reader getCharacterStream(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Reader getNCharacterStream(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Reader getNCharacterStream(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public InputStream getUnicodeStream(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public InputStream getUnicodeStream(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNull(int i, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNull(String s, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNull(int i, int j, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNull(String s, int i, String s1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNullAtName(String s, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setNullAtName(String s, int i, String s1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setObject(int i, Object obj, int j, int k)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setObject(String s, Object obj, int i, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setObjectAtName(String s, Object obj, int i, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getFetchDirection()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getFetchSize()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getMaxFieldSize()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getMaxRows()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getQueryTimeout()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getResultSetConcurrency()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getResultSetHoldability()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getResultSetType()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getUpdateCount()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void cancel()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void clearBatch()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void clearWarnings()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void close()
        throws SQLException
    {
    }

    public boolean getMoreResults()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int[] executeBatch()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setFetchDirection(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setFetchSize(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setMaxFieldSize(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setMaxRows(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setQueryTimeout(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean getMoreResults(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setEscapeProcessing(boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int executeUpdate(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void addBatch(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setCursorName(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean execute(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int executeUpdate(String s, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean execute(String s, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int executeUpdate(String s, int ai[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean execute(String s, int ai[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Connection getConnection()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSet getGeneratedKeys()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSet getResultSet()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public SQLWarning getWarnings()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int executeUpdate(String s, String as[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean execute(String s, String as[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSet executeQuery(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void clearDefines()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void defineColumnType(int i, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void defineColumnType(int i, int j, int k)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void defineColumnType(int i, int j, int k, short word0)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void defineColumnTypeBytes(int i, int j, int k)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void defineColumnTypeChars(int i, int j, int k)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void defineColumnType(int i, int j, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getRowPrefetch()
    {
        return -1;
    }

    public void setResultSetCache(OracleResultSetCache oracleresultsetcache)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setRowPrefetch(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getLobPrefetchSize()
    {
        return -1;
    }

    public void setLobPrefetchSize(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void closeWithKey(String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int creationState()
    {
        return -1;
    }

    public boolean isNCHAR(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int executeUpdate()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void addBatch()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void clearParameters()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean execute()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ParameterMetaData getParameterMetaData()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSet executeQuery()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSetMetaData getMetaData()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public ResultSet getReturnResultSet()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void defineParameterTypeBytes(int i, int j, int k)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void defineParameterTypeChars(int i, int j, int k)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void defineParameterType(int i, int j, int k)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public int getExecuteBatch()
    {
        return -1;
    }

    public int sendBatch()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setExecuteBatch(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setPlsqlIndexTable(int i, Object obj, int j, int k, int l, int i1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setFormOfUse(int i, short word0)
    {
    }

    public void setDisableStmtCaching(boolean flag)
    {
    }

    public OracleParameterMetaData OracleGetParameterMetaData()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerReturnParameter(int i, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerReturnParameter(int i, int j, int k)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerReturnParameter(int i, int j, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBytesForBlob(int i, byte abyte0[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBytesForBlobAtName(String s, byte abyte0[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setStringForClob(int i, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setStringForClobAtName(String s, String s1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setStructDescriptor(int i, StructDescriptor structdescriptor)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setStructDescriptor(String s, StructDescriptor structdescriptor)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setStructDescriptorAtName(String s, StructDescriptor structdescriptor)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Object getAnyDataEmbeddedObject(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerOutParameter(int i, int j, int k, int l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerOutParameter(int i, int j, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerOutParameter(int i, int j, int k)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerOutParameter(int i, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerOutParameterBytes(int i, int j, int k, int l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerOutParameterChars(int i, int j, int k, int l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Object getPlsqlIndexTable(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Object getPlsqlIndexTable(int i, Class class1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Datum[] getOraclePlsqlIndexTable(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerIndexTableOutParameter(int i, int j, int k, int l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setStringForClob(String s, String s1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setBytesForBlob(String s, byte abyte0[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerOutParameter(String s, int i, int j, int k)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean wasNull()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerOutParameter(String s, int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerOutParameter(String s, int i, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void registerOutParameter(String s, int i, String s1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public byte[] privateGetBytes(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setDatabaseChangeRegistration(DatabaseChangeRegistration databasechangeregistration)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean isClosed()
        throws SQLException
    {
        return true;
    }

    public boolean isPoolable()
        throws SQLException
    {
        return false;
    }

    public void setPoolable(boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean isWrapperFor(Class class1)
        throws SQLException
    {
        if(class1.isInterface())
        {
            return class1.isInstance(this);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public Object unwrap(Class class1)
        throws SQLException
    {
        if(class1.isInterface() && class1.isInstance(this))
        {
            return this;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public void setFixedString(boolean flag)
    {
    }

    public boolean getFixedString()
    {
        return false;
    }

    public boolean getserverCursor()
    {
        return false;
    }

    public int getcacheState()
    {
        return 0;
    }

    public int getstatementType()
    {
        return 3;
    }

    public void setCheckBindTypes(boolean flag)
    {
    }

    public void setInternalBytes(int i, byte abyte0[], int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void enterImplicitCache()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void enterExplicitCache()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void exitImplicitCacheToActive()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void exitExplicitCacheToActive()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void exitImplicitCacheToClose()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void exitExplicitCacheToClose()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public String[] getRegisteredTableNames()
        throws SQLException
    {
        return null;
    }

    public long getRegisteredQueryId()
        throws SQLException
    {
        return -1L;
    }

    public String getOriginalSql()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setSnapshotSCN(long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

    public oracle.jdbc.internal.OracleStatement.SqlKind getSqlKind()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public long getChecksum()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public volatile Object getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException
    {
        return getORAData(i, oradatafactory);
    }

    public volatile Object getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException
    {
        return getCustomDatum(i, customdatumfactory);
    }

}
