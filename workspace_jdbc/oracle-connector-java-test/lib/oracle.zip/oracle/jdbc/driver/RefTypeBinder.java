// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;


// Referenced classes of package oracle.jdbc.driver:
//            TypeBinder, OraclePreparedStatementReadOnly, Binder

class RefTypeBinder extends TypeBinder
{

    Binder theRefTypeCopyingBinder;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    RefTypeBinder()
    {
        theRefTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticRefTypeCopyingBinder;
        init(this);
    }

    static void init(Binder binder)
    {
        binder.type = 111;
        binder.bytelen = 24;
    }

    Binder copyingBinder()
    {
        return theRefTypeCopyingBinder;
    }

}
