// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CDriverExtension.java

package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

// Referenced classes of package oracle.jdbc.driver:
//            OracleDriverExtension, T4CConnection, T4CStatement, T4CPreparedStatement, 
//            T4CCallableStatement, T4CInputStream, PhysicalConnection, OracleStatement, 
//            OraclePreparedStatement, OracleCallableStatement, Accessor, OracleInputStream

class T4CDriverExtension extends OracleDriverExtension
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CDriverExtension()
    {
    }

    Connection getConnection(String s, Properties properties)
        throws SQLException
    {
        return new T4CConnection(s, properties, this);
    }

    OracleStatement allocateStatement(PhysicalConnection physicalconnection, int i, int j)
        throws SQLException
    {
        return new T4CStatement(physicalconnection, i, j);
    }

    OraclePreparedStatement allocatePreparedStatement(PhysicalConnection physicalconnection, String s, int i, int j)
        throws SQLException
    {
        return new T4CPreparedStatement(physicalconnection, s, i, j);
    }

    OracleCallableStatement allocateCallableStatement(PhysicalConnection physicalconnection, String s, int i, int j)
        throws SQLException
    {
        return new T4CCallableStatement(physicalconnection, s, i, j);
    }

    OracleInputStream createInputStream(OracleStatement oraclestatement, int i, Accessor accessor)
        throws SQLException
    {
        return new T4CInputStream(oraclestatement, i, accessor);
    }

}
