// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.driver:
//            DatabaseError

class PlsqlIbtBindInfo
{

    Object arrayData[];
    int maxLen;
    int curLen;
    int element_internal_type;
    int elemMaxLen;
    int ibtByteLength;
    int ibtCharLength;
    int ibtValueIndex;
    int ibtIndicatorIndex;
    int ibtLengthIndex;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    PlsqlIbtBindInfo(Object aobj[], int i, int j, int k, int l)
        throws SQLException
    {
        arrayData = aobj;
        maxLen = i;
        curLen = j;
        element_internal_type = k;
        switch(k)
        {
        case 1: // '\001'
        case 96: // '`'
            elemMaxLen = l != 0 ? l + 1 : 2;
            ibtCharLength = elemMaxLen * i;
            element_internal_type = 9;
            break;

        case 6: // '\006'
            elemMaxLen = 22;
            ibtByteLength = elemMaxLen * i;
            break;

        default:
            SQLException sqlexception = DatabaseError.createSqlException(null, 97);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

}
