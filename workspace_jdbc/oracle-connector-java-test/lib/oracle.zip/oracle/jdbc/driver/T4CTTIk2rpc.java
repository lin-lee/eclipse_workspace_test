// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIk2rpc.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIfun, T4CMAREngine, T4CConnection

final class T4CTTIk2rpc extends T4CTTIfun
{

    static final int K2RPClogon = 1;
    static final int K2RPCbegin = 2;
    static final int K2RPCend = 3;
    static final int K2RPCrecover = 4;
    static final int K2RPCsession = 5;
    private int k2rpctyp;
    private int command;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIk2rpc(T4CConnection t4cconnection)
    {
        super(t4cconnection, (byte)3);
        setFunCode((short)67);
    }

    void doOK2RPC(int i, int j)
        throws IOException, SQLException
    {
        k2rpctyp = i;
        command = j;
        doRPC();
    }

    void marshal()
        throws IOException
    {
        meg.marshalUB4(0L);
        meg.marshalUB4(k2rpctyp);
        meg.marshalPTR();
        meg.marshalUB4(3L);
        meg.marshalNULLPTR();
        meg.marshalUB4(0L);
        meg.marshalNULLPTR();
        meg.marshalUB4(0L);
        meg.marshalPTR();
        meg.marshalUB4(3L);
        meg.marshalPTR();
        meg.marshalNULLPTR();
        meg.marshalUB4(0L);
        meg.marshalNULLPTR();
        meg.marshalNULLPTR();
        meg.marshalUB4(0L);
        meg.marshalNULLPTR();
        meg.marshalUB4(command);
        meg.marshalUB4(0L);
        meg.marshalUB4(0L);
    }

    void readRPA()
        throws IOException, SQLException
    {
        int i = meg.unmarshalUB2();
        for(int j = 0; j < i; j++)
            meg.unmarshalUB4();

    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
