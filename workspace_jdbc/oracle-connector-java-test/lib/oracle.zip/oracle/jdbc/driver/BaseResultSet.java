// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   BaseResultSet.java

package oracle.jdbc.driver;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.driver:
//            OracleResultSet, DatabaseError, OracleStatement

abstract class BaseResultSet extends OracleResultSet
{

    SQLWarning sqlWarning;
    boolean autoRefetch;
    boolean closed;
    boolean close_statement_on_close;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    BaseResultSet()
    {
        sqlWarning = null;
        autoRefetch = true;
        closed = false;
        close_statement_on_close = false;
    }

    public void closeStatementOnClose()
    {
        close_statement_on_close = true;
    }

    public void beforeFirst()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "beforeFirst");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void afterLast()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "afterLast");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean first()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "first");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean last()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "last");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean absolute(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "absolute");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean relative(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "relative");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean previous()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "previous");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setFetchDirection(int i)
        throws SQLException
    {
        if(i == 1000)
            return;
        if(i == 1001 || i == 1002)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "setFetchDirection(FETCH_REVERSE, FETCH_UNKNOWN)");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public int getFetchDirection()
        throws SQLException
    {
        return 1000;
    }

    public int getType()
        throws SQLException
    {
        return 1003;
    }

    public int getConcurrency()
        throws SQLException
    {
        return 1007;
    }

    public SQLWarning getWarnings()
        throws SQLException
    {
        return sqlWarning;
    }

    public void clearWarnings()
        throws SQLException
    {
        sqlWarning = null;
    }

    public void updateArray(int i, Array array)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateArray");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBigDecimal(int i, BigDecimal bigdecimal)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBigDecimal");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBlob(int i, Blob blob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBlob");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBoolean(int i, boolean flag)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBoolean");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateByte(int i, byte byte0)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateByte");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBytes(int i, byte abyte0[])
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBytes");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateClob(int i, Clob clob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateClob");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateDate(int i, Date date)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDate");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateDate(int i, Date date, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDate");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateDouble(int i, double d)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDouble");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateFloat(int i, float f)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateFloat");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateInt(int i, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateInt");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateLong(int i, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateLong");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateNClob(int i, NClob nclob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNClob");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateNString(int i, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNString");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateObject(int i, Object obj)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateObject");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateObject(int i, Object obj, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateObject");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateRef(int i, Ref ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRef");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateRowId(int i, RowId rowid)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRowId");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateShort(int i, short word0)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateShort");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateSQLXML(int i, SQLXML sqlxml)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateSQLXML");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateString(int i, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateString");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateTime(int i, Time time)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTime");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateTime(int i, Time time, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTime");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateTimestamp(int i, Timestamp timestamp)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTimestamp");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateTimestamp(int i, Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTimestamp");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateURL(int i, URL url)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateURL");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateARRAY(int i, ARRAY array)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateARRAY");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBFILE(int i, BFILE bfile)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBFILE");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBfile(int i, BFILE bfile)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBfile");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBinaryFloat(int i, float f)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryFloat");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBinaryFloat(int i, BINARY_FLOAT binary_float)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryFloat");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBinaryDouble(int i, double d)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryDouble");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBinaryDouble(int i, BINARY_DOUBLE binary_double)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryDouble");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBLOB(int i, BLOB blob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBLOB");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateCHAR(int i, CHAR char1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCHAR");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateCLOB(int i, CLOB clob)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCLOB");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateCursor(int i, ResultSet resultset)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCursor");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateCustomDatum(int i, CustomDatum customdatum)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCustomDatum");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateDATE(int i, DATE date)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDATE");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateFixedCHAR(int i, String s)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateFixedCHAR");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateINTERVALDS(int i, INTERVALDS intervalds)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateINTERVALDS");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateINTERVALYM(int i, INTERVALYM intervalym)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateINTERVALYM");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateNUMBER(int i, NUMBER number)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNUMBER");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateOPAQUE(int i, OPAQUE opaque)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateOPAQUE");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateOracleObject(int i, Datum datum)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateOracleObject");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateORAData(int i, ORAData oradata)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateORAData");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateRAW(int i, RAW raw)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRAW");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateREF(int i, REF ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateREF");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateRefType(int i, REF ref)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRefType");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateROWID(int i, ROWID rowid)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateROWID");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateSTRUCT(int i, STRUCT struct)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateSTRUCT");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateTIMESTAMPLTZ(int i, TIMESTAMPLTZ timestampltz)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMPLTZ");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateTIMESTAMPTZ(int i, TIMESTAMPTZ timestamptz)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMPTZ");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateTIMESTAMP(int i, TIMESTAMP timestamp)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMP");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBlob(int i, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBlob");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBlob(int i, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBlob");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateClob(int i, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateClob");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateClob(int i, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateClob");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateNClob(int i, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNClob");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateNClob(int i, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNClob");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateAsciiStream(int i, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateAsciiStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateAsciiStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateAsciiStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateAsciiStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateAsciiStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBinaryStream(int i, InputStream inputstream)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBinaryStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateBinaryStream(int i, InputStream inputstream, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateCharacterStream(int i, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCharacterStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateCharacterStream(int i, Reader reader, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCharacterStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCharacterStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateNCharacterStream(int i, Reader reader)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNCharacterStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateNCharacterStream(int i, Reader reader, long l)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNCharacterStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateUnicodeStream(int i, InputStream inputstream, int j)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateUnicodeStream");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateNull(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNull");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean rowUpdated()
        throws SQLException
    {
        return false;
    }

    public boolean rowInserted()
        throws SQLException
    {
        return false;
    }

    public boolean rowDeleted()
        throws SQLException
    {
        return false;
    }

    public void insertRow()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "insertRow");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void updateRow()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRow");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void deleteRow()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "deleteRow");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void refreshRow()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, null);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void cancelRowUpdates()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "cancelRowUpdates");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void moveToInsertRow()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "moveToInsertRow");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void moveToCurrentRow()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "moveToCurrentRow");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public void setAutoRefetch(boolean flag)
        throws SQLException
    {
        autoRefetch = flag;
    }

    public boolean getAutoRefetch()
        throws SQLException
    {
        return autoRefetch;
    }

    public void close()
        throws SQLException
    {
        closed = true;
    }

    OracleStatement getOracleStatement()
        throws SQLException
    {
        return null;
    }

    public int getHoldability()
        throws SQLException
    {
        return 1;
    }

    public boolean isClosed()
        throws SQLException
    {
        return closed;
    }

}
