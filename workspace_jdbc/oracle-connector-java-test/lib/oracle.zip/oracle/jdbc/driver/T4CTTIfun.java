// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   T4CTTIfun.java

package oracle.jdbc.driver;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.util.LinkedList;
import oracle.jdbc.internal.OracleConnection;
import oracle.net.ns.BreakNetException;

// Referenced classes of package oracle.jdbc.driver:
//            T4CTTIMsg, T4CTTIidc, T4CTTIkvarr, NTFXSEvent, 
//            T4CConnection, T4CMAREngine, DatabaseError, T4CTTIoer

abstract class T4CTTIfun extends T4CTTIMsg
{

    static final short OOPEN = 2;
    static final short OFETCH = 5;
    static final short OCLOSE = 8;
    static final short OLOGOFF = 9;
    static final short OCOMON = 12;
    static final short OCOMOFF = 13;
    static final short OCOMMIT = 14;
    static final short OROLLBACK = 15;
    static final short OCANCEL = 20;
    static final short ODSCRARR = 43;
    static final short OVERSION = 59;
    static final short OK2RPC = 67;
    static final short OALL7 = 71;
    static final short OSQL7 = 74;
    static final short O3LOGON = 81;
    static final short O3LOGA = 82;
    static final short OKOD = 92;
    static final short OALL8 = 94;
    static final short OLOBOPS = 96;
    static final short ODNY = 98;
    static final short OTXSE = 103;
    static final short OTXEN = 104;
    static final short OCCA = 105;
    static final short O80SES = 107;
    static final short OAUTH = 115;
    static final short OSESSKEY = 118;
    static final short OCANA = 120;
    static final short OKPN = 125;
    static final short OOTCM = 127;
    static final short OSCID = 135;
    static final short OSPFPPUT = 138;
    static final short OKPFC = 139;
    static final short OPING = 147;
    static final short OKEYVAL = 154;
    static final short OXSSCS = 155;
    static final short OXSSRO = 156;
    static final short OXSSPO = 157;
    static final short OAQEQ = 121;
    static final short OAQDQ = 122;
    static final short OAQGPS = 132;
    static final short OAQLS = 126;
    static final short OAQXQ = 145;
    static final short OXSNS = 172;
    private short funCode;
    protected final T4CTTIoer oer;
    int receiveState;
    static final int IDLE_RECEIVE_STATE = 0;
    static final int ACTIVE_RECEIVE_STATE = 1;
    static final int READROW_RECEIVE_STATE = 2;
    static final int STREAM_RECEIVE_STATE = 3;
    boolean rpaProcessed;
    boolean rxhProcessed;
    boolean iovProcessed;
    private LinkedList ttilist;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    T4CTTIfun(T4CConnection t4cconnection, byte byte0)
    {
        super(t4cconnection, byte0);
        receiveState = 0;
        rpaProcessed = false;
        rxhProcessed = false;
        iovProcessed = false;
        ttilist = new LinkedList();
        oer = t4cconnection.getT4CTTIoer();
    }

    final void setFunCode(short word0)
    {
        funCode = word0;
    }

    final short getFunCode()
    {
        return funCode;
    }

    private final void marshalFunHeader()
        throws IOException
    {
        marshalTTCcode();
        meg.marshalUB1(funCode);
        meg.marshalUB1(connection.getNextSeqNumber());
    }

    abstract void marshal()
        throws IOException;

    final void doRPC()
        throws IOException, SQLException
    {
        int i;
        if(getTTCCode() == 17)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        i = 0;
_L3:
        if(i >= 5)
            break; /* Loop/switch isn't completed */
        init();
        marshalFunHeader();
        connection.pipeState = 1;
        marshal();
        connection.pipeState = 2;
        receive();
        connection.pipeState = -1;
        break; /* Loop/switch isn't completed */
        SQLException sqlexception1;
        sqlexception1;
        synchronized(connection.cancelInProgressLockForThin)
        {
            if(sqlexception1.getErrorCode() != 1013 && (!connection.cancelInProgressFlag || sqlexception1.getMessage() == null || !sqlexception1.getMessage().contains("ORA-01013")))
                break MISSING_BLOCK_LABEL_227;
            connection.cancelInProgressFlag = false;
            connection.redoCursorClose();
            if(funCode != 15 && funCode != 12 && funCode != 13 && funCode != 14 && funCode != 59 || oer.callNumber == connection.currentTTCSeqNumber && !connection.statementCancel)
                break MISSING_BLOCK_LABEL_227;
        }
        connection.pipeState = -1;
        break MISSING_BLOCK_LABEL_257;
        obj;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
        throw sqlexception1;
        Exception exception1;
        exception1;
        connection.pipeState = -1;
        throw exception1;
        i++;
        if(true) goto _L3; else goto _L2
_L2:
    }

    final void doPigRPC()
        throws IOException
    {
        init();
        marshalFunHeader();
        marshal();
    }

    private void init()
    {
        rpaProcessed = false;
        rxhProcessed = false;
        iovProcessed = false;
        ttilist.clear();
    }

    void resumeReceive()
        throws SQLException, IOException
    {
        receive();
    }

    private void receive()
        throws SQLException, IOException
    {
        SQLException sqlexception;
        receiveState = 1;
        sqlexception = null;
_L17:
        short word0;
        word0 = meg.unmarshalUB1();
        ttilist.add(new Short(word0));
        word0;
        JVM INSTR tableswitch 4 23: default 600
    //                   4 558
    //                   5 600
    //                   6 194
    //                   7 213
    //                   8 128
    //                   9 513
    //                   10 600
    //                   11 182
    //                   12 206
    //                   13 600
    //                   14 254
    //                   15 465
    //                   16 247
    //                   17 600
    //                   18 600
    //                   19 453
    //                   20 600
    //                   21 175
    //                   22 600
    //                   23 261;
           goto _L1 _L2 _L1 _L3 _L4 _L5 _L6 _L1 _L7 _L8 _L1 _L9 _L10 _L11 _L1 _L1 _L12 _L1 _L13 _L1 _L14
_L5:
        if(rpaProcessed)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        readRPA();
        try
        {
            processRPA();
        }
        catch(SQLException sqlexception2)
        {
            sqlexception = sqlexception2;
        }
        rpaProcessed = true;
        break; /* Loop/switch isn't completed */
_L13:
        readBVC();
        break; /* Loop/switch isn't completed */
_L7:
        readIOV();
        iovProcessed = true;
        break; /* Loop/switch isn't completed */
_L3:
        readRXH();
        rxhProcessed = true;
        break; /* Loop/switch isn't completed */
_L8:
        processSLG();
        break; /* Loop/switch isn't completed */
_L4:
        receiveState = 2;
        if(!readRXD()) goto _L16; else goto _L15
_L15:
        receiveState = 3;
        connection.sentCancel = false;
        return;
_L16:
        receiveState = 1;
        break; /* Loop/switch isn't completed */
_L11:
        readDCB();
        break; /* Loop/switch isn't completed */
_L9:
        readLOBD();
        break; /* Loop/switch isn't completed */
_L14:
        byte byte0 = (byte)meg.unmarshalUB1();
        int i = meg.unmarshalUB2();
        byte byte1 = (byte)meg.unmarshalUB1();
        if(byte0 == 1)
        {
            for(int j = 0; j < i; j++)
            {
                T4CTTIidc t4cttiidc = new T4CTTIidc(connection);
                t4cttiidc.unmarshal();
            }

            break; /* Loop/switch isn't completed */
        }
        if(byte0 == 2)
        {
            for(int k = 0; k < i; k++)
            {
                short word2 = meg.unmarshalUB1();
            }

            break; /* Loop/switch isn't completed */
        }
        if(byte0 == 3 || byte0 == 4)
            break; /* Loop/switch isn't completed */
        if(byte0 == 5)
        {
            T4CTTIkvarr t4cttikvarr = new T4CTTIkvarr(connection);
            t4cttikvarr.unmarshal();
            break; /* Loop/switch isn't completed */
        }
        if(byte0 != 6)
            break; /* Loop/switch isn't completed */
        for(int l = 0; l < i; l++)
        {
            NTFXSEvent ntfxsevent = new NTFXSEvent(connection);
            connection.notify(ntfxsevent);
        }

        break; /* Loop/switch isn't completed */
_L12:
        meg.marshalUB1((short)19);
        break; /* Loop/switch isn't completed */
_L10:
        oer.init();
        oer.unmarshalWarning();
        try
        {
            oer.processWarning();
        }
        catch(SQLWarning sqlwarning)
        {
            connection.setWarnings(DatabaseError.addSqlWarning(connection.getWarnings(), sqlwarning));
        }
        break; /* Loop/switch isn't completed */
_L6:
        processEOCS();
        if(connection.getTTCVersion() >= 3)
        {
            short word1 = (short)meg.unmarshalUB2();
            connection.endToEndECIDSequenceNumber = word1;
        }
        connection.sentCancel = false;
        break MISSING_BLOCK_LABEL_667;
_L2:
        processEOCS();
        oer.init();
        oer.unmarshal();
        try
        {
            processError();
        }
        catch(SQLException sqlexception3)
        {
            sqlexception = sqlexception3;
        }
        connection.sentCancel = false;
        break MISSING_BLOCK_LABEL_667;
_L1:
        try
        {
            SQLException sqlexception4 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401, ttilist.toString());
            sqlexception4.fillInStackTrace();
            throw sqlexception4;
        }
        catch(BreakNetException breaknetexception)
        {
            connection.sentCancel = false;
        }
          goto _L17
        connection.sentCancel = false;
          goto _L17
        Exception exception;
        exception;
        connection.sentCancel = false;
        throw exception;
        receiveState = 0;
        if(sqlexception != null)
            throw sqlexception;
        else
            return;
    }

    private final void processEOCS()
        throws SQLException, IOException
    {
        if(connection.hasServerCompileTimeCapability(15, 1))
        {
            int i = (int)meg.unmarshalUB4();
            connection.eocs = i;
            long l;
            if((i & 8) != 0)
                l = meg.unmarshalSB8();
        }
    }

    void processRPA()
        throws SQLException
    {
    }

    void readRPA()
        throws IOException, SQLException
    {
    }

    void readBVC()
        throws IOException, SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void readLOBD()
        throws IOException, SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void readIOV()
        throws IOException, SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void readRXH()
        throws IOException, SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    boolean readRXD()
        throws IOException, SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void readDCB()
        throws IOException, SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void processSLG()
        throws IOException, SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    void processError()
        throws SQLException
    {
        oer.processError();
    }

    final int getErrorCode()
        throws SQLException
    {
        return oer.retCode;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
