// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.driver;


// Referenced classes of package oracle.jdbc.driver:
//            VarnumBinder, OraclePreparedStatement

class ByteBinder extends VarnumBinder
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    ByteBinder()
    {
    }

    void bind(OraclePreparedStatement oraclepreparedstatement, int i, int j, int k, byte abyte0[], char ac[], short aword0[], 
            int l, int i1, int j1, int k1, int l1, int i2, boolean flag)
    {
        byte abyte1[] = abyte0;
        int j2 = j1 + 1;
        int k2 = oraclepreparedstatement.parameterInt[k][i];
        int l2 = 0;
        if(k2 == 0)
        {
            abyte1[j2] = -128;
            l2 = 1;
        } else
        if(k2 < 0)
        {
            if(-k2 < 100)
            {
                abyte1[j2] = 62;
                abyte1[j2 + 1] = (byte)(101 + k2);
                abyte1[j2 + 2] = 102;
                l2 = 3;
            } else
            {
                abyte1[j2] = 61;
                abyte1[j2 + 1] = (byte)(101 - -k2 / 100);
                int i3 = -k2 % 100;
                if(i3 != 0)
                {
                    abyte1[j2 + 2] = (byte)(101 - i3);
                    abyte1[j2 + 3] = 102;
                    l2 = 4;
                } else
                {
                    abyte1[j2 + 2] = 102;
                    l2 = 3;
                }
            }
        } else
        if(k2 < 100)
        {
            abyte1[j2] = -63;
            abyte1[j2 + 1] = (byte)(k2 + 1);
            l2 = 2;
        } else
        {
            abyte1[j2] = -62;
            abyte1[j2 + 1] = (byte)(k2 / 100 + 1);
            int j3 = k2 % 100;
            if(j3 != 0)
            {
                abyte1[j2 + 2] = (byte)(j3 + 1);
                l2 = 3;
            } else
            {
                abyte1[j2 + 2] = 102;
                l2 = 2;
            }
        }
        abyte1[j1] = (byte)l2;
        aword0[i2] = 0;
        aword0[l1] = (short)(l2 + 1);
    }

}
