// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   LargeObjectAccessMode.java

package oracle.jdbc;


public final class LargeObjectAccessMode extends Enum
{

    public static final LargeObjectAccessMode MODE_READONLY;
    public static final LargeObjectAccessMode MODE_READWRITE;
    private final int code;
    private static final LargeObjectAccessMode $VALUES[];

    public static LargeObjectAccessMode[] values()
    {
        return (LargeObjectAccessMode[])$VALUES.clone();
    }

    public static LargeObjectAccessMode valueOf(String s)
    {
        return (LargeObjectAccessMode)Enum.valueOf(oracle/jdbc/LargeObjectAccessMode, s);
    }

    private LargeObjectAccessMode(String s, int i, int j)
    {
        super(s, i);
        code = j;
    }

    public int getCode()
    {
        return code;
    }

    static 
    {
        MODE_READONLY = new LargeObjectAccessMode("MODE_READONLY", 0, 0);
        MODE_READWRITE = new LargeObjectAccessMode("MODE_READWRITE", 1, 1);
        $VALUES = (new LargeObjectAccessMode[] {
            MODE_READONLY, MODE_READWRITE
        });
    }
}
