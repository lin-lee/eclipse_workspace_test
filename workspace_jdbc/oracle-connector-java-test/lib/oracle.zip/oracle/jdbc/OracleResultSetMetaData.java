// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleResultSetMetaData.java

package oracle.jdbc;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public interface OracleResultSetMetaData
    extends ResultSetMetaData
{
    public static final class SecurityAttribute extends Enum
    {

        public static final SecurityAttribute NONE;
        public static final SecurityAttribute ENABLED;
        public static final SecurityAttribute UNKNOWN;
        private static final SecurityAttribute $VALUES[];

        public static SecurityAttribute[] values()
        {
            return (SecurityAttribute[])$VALUES.clone();
        }

        public static SecurityAttribute valueOf(String s)
        {
            return (SecurityAttribute)Enum.valueOf(oracle/jdbc/OracleResultSetMetaData$SecurityAttribute, s);
        }

        static 
        {
            NONE = new SecurityAttribute("NONE", 0);
            ENABLED = new SecurityAttribute("ENABLED", 1);
            UNKNOWN = new SecurityAttribute("UNKNOWN", 2);
            $VALUES = (new SecurityAttribute[] {
                NONE, ENABLED, UNKNOWN
            });
        }

        private SecurityAttribute(String s, int i)
        {
            super(s, i);
        }
    }


    public abstract boolean isNCHAR(int i)
        throws SQLException;

    public abstract SecurityAttribute getSecurityAttribute(int i)
        throws SQLException;
}
