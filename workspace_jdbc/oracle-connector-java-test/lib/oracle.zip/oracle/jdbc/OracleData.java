// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleData.java

package oracle.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

public interface OracleData
{

    public abstract Object toJDBCObject(Connection connection)
        throws SQLException;
}
