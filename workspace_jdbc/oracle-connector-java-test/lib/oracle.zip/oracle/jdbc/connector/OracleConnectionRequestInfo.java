// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConnectionRequestInfo.java

package oracle.jdbc.connector;

import javax.resource.spi.ConnectionRequestInfo;

public class OracleConnectionRequestInfo
    implements ConnectionRequestInfo
{

    private String user;
    private String password;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleConnectionRequestInfo(String s, String s1)
    {
        user = null;
        password = null;
        user = s;
        password = s1;
    }

    public String getUser()
    {
        return user;
    }

    public void setUser(String s)
    {
        user = s;
    }

    public String getPassword()
    {
        return password;
    }

    public void setPassword(String s)
    {
        password = s;
    }

    public boolean equals(Object obj)
    {
        if(!(obj instanceof OracleConnectionRequestInfo))
        {
            return false;
        } else
        {
            OracleConnectionRequestInfo oracleconnectionrequestinfo = (OracleConnectionRequestInfo)obj;
            return user.equalsIgnoreCase(oracleconnectionrequestinfo.getUser()) && password.equals(oracleconnectionrequestinfo.getPassword());
        }
    }

}
