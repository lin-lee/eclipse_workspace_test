// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleManagedConnectionFactory.java

package oracle.jdbc.connector;

import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Set;
import javax.naming.*;
import javax.resource.ResourceException;
import javax.resource.spi.*;
import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.Subject;
import javax.sql.*;

// Referenced classes of package oracle.jdbc.connector:
//            OracleManagedConnection, OracleConnectionRequestInfo

public class OracleManagedConnectionFactory
    implements ManagedConnectionFactory
{

    private XADataSource xaDataSource;
    private String xaDataSourceName;
    private static final String RAERR_MCF_SET_XADS = "invalid xads";
    private static final String RAERR_MCF_GET_PCRED = "no password credential";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleManagedConnectionFactory()
        throws ResourceException
    {
        xaDataSource = null;
        xaDataSourceName = null;
    }

    public OracleManagedConnectionFactory(XADataSource xadatasource)
        throws ResourceException
    {
        xaDataSource = null;
        xaDataSourceName = null;
        xaDataSource = xadatasource;
        xaDataSourceName = "XADataSource";
    }

    public void setXADataSourceName(String s)
    {
        xaDataSourceName = s;
    }

    public String getXADataSourceName()
    {
        return xaDataSourceName;
    }

    public Object createConnectionFactory(ConnectionManager connectionmanager)
        throws ResourceException
    {
        if(xaDataSource == null)
            setupXADataSource();
        return (DataSource)xaDataSource;
    }

    public Object createConnectionFactory()
        throws ResourceException
    {
        return createConnectionFactory(null);
    }

    public ManagedConnection createManagedConnection(Subject subject, ConnectionRequestInfo connectionrequestinfo)
        throws ResourceException
    {
        try
        {
            if(xaDataSource == null)
                setupXADataSource();
            XAConnection xaconnection = null;
            PasswordCredential passwordcredential = getPasswordCredential(subject, connectionrequestinfo);
            if(passwordcredential == null)
                xaconnection = xaDataSource.getXAConnection();
            else
                xaconnection = xaDataSource.getXAConnection(passwordcredential.getUserName(), new String(passwordcredential.getPassword()));
            OracleManagedConnection oraclemanagedconnection = new OracleManagedConnection(xaconnection);
            oraclemanagedconnection.setPasswordCredential(passwordcredential);
            oraclemanagedconnection.setLogWriter(getLogWriter());
            return oraclemanagedconnection;
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
    }

    public ManagedConnection matchManagedConnections(Set set, Subject subject, ConnectionRequestInfo connectionrequestinfo)
        throws ResourceException
    {
        PasswordCredential passwordcredential = getPasswordCredential(subject, connectionrequestinfo);
        for(Iterator iterator = set.iterator(); iterator.hasNext();)
        {
            Object obj = iterator.next();
            if(obj instanceof OracleManagedConnection)
            {
                OracleManagedConnection oraclemanagedconnection = (OracleManagedConnection)obj;
                if(oraclemanagedconnection.getPasswordCredential().equals(passwordcredential))
                    return oraclemanagedconnection;
            }
        }

        return null;
    }

    public void setLogWriter(PrintWriter printwriter)
        throws ResourceException
    {
        try
        {
            if(xaDataSource == null)
                setupXADataSource();
            xaDataSource.setLogWriter(printwriter);
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
    }

    public PrintWriter getLogWriter()
        throws ResourceException
    {
        try
        {
            if(xaDataSource == null)
                setupXADataSource();
            return xaDataSource.getLogWriter();
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
    }

    private void setupXADataSource()
        throws ResourceException
    {
        try
        {
            InitialContext initialcontext = null;
            try
            {
                java.util.Properties properties = System.getProperties();
                initialcontext = new InitialContext(properties);
            }
            catch(SecurityException securityexception) { }
            if(initialcontext == null)
                initialcontext = new InitialContext();
            XADataSource xadatasource = (XADataSource)initialcontext.lookup(xaDataSourceName);
            if(xadatasource == null)
                throw new ResourceAdapterInternalException("Invalid XADataSource object");
            xaDataSource = xadatasource;
        }
        catch(NamingException namingexception)
        {
            ResourceException resourceexception = new ResourceException((new StringBuilder()).append("NamingException: ").append(namingexception.getMessage()).toString());
            resourceexception.setLinkedException(namingexception);
            throw resourceexception;
        }
    }

    private PasswordCredential getPasswordCredential(Subject subject, ConnectionRequestInfo connectionrequestinfo)
        throws ResourceException
    {
        if(subject != null)
        {
            Set set = subject.getPrivateCredentials(javax/resource/spi/security/PasswordCredential);
            for(Iterator iterator = set.iterator(); iterator.hasNext();)
            {
                PasswordCredential passwordcredential1 = (PasswordCredential)iterator.next();
                if(passwordcredential1.getManagedConnectionFactory().equals(this))
                    return passwordcredential1;
            }

            throw new SecurityException("Can not find user/password information", "no password credential");
        } else
        if(connectionrequestinfo == null)
        {
            return null;
        } else
        {
            OracleConnectionRequestInfo oracleconnectionrequestinfo = (OracleConnectionRequestInfo)connectionrequestinfo;
            PasswordCredential passwordcredential = new PasswordCredential(oracleconnectionrequestinfo.getUser(), oracleconnectionrequestinfo.getPassword().toCharArray());
            passwordcredential.setManagedConnectionFactory(this);
            return passwordcredential;
        }
    }

}
