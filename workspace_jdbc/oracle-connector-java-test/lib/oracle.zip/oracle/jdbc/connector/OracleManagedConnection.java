// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleManagedConnection.java

package oracle.jdbc.connector;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.resource.ResourceException;
import javax.resource.spi.*;
import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.Subject;
import javax.sql.XAConnection;
import javax.transaction.xa.XAResource;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.xa.OracleXAConnection;

// Referenced classes of package oracle.jdbc.connector:
//            OracleLocalTransaction, OracleManagedConnectionMetaData

public class OracleManagedConnection
    implements ManagedConnection
{

    private OracleXAConnection xaConnection;
    private Hashtable connectionListeners;
    private Connection connection;
    private PrintWriter logWriter;
    private PasswordCredential passwordCredential;
    private OracleLocalTransaction localTxn;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleManagedConnection(XAConnection xaconnection)
    {
        xaConnection = null;
        connectionListeners = null;
        connection = null;
        logWriter = null;
        passwordCredential = null;
        localTxn = null;
        xaConnection = (OracleXAConnection)xaconnection;
        connectionListeners = new Hashtable(10);
    }

    public Object getConnection(Subject subject, ConnectionRequestInfo connectionrequestinfo)
        throws ResourceException
    {
        try
        {
            if(connection != null)
                connection.close();
            connection = xaConnection.getConnection();
            return connection;
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
    }

    public void destroy()
        throws ResourceException
    {
        try
        {
            if(xaConnection != null)
            {
                Connection connection1 = xaConnection.getPhysicalHandle();
                if(localTxn != null && localTxn.isBeginCalled || ((OracleConnection)connection1).getTxnMode() == 1)
                    throw new IllegalStateException("Could not close connection while transaction is active");
            }
            if(connection != null)
                connection.close();
            if(xaConnection != null)
                xaConnection.close();
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
    }

    public void cleanup()
        throws ResourceException
    {
        try
        {
            if(connection != null)
            {
                if(localTxn != null && localTxn.isBeginCalled || ((OracleConnection)connection).getTxnMode() == 1)
                    throw new IllegalStateException("Could not close connection while transaction is active");
                connection.close();
            }
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
    }

    public void associateConnection(Object obj)
    {
    }

    public void addConnectionEventListener(ConnectionEventListener connectioneventlistener)
    {
        connectionListeners.put(connectioneventlistener, connectioneventlistener);
    }

    public void removeConnectionEventListener(ConnectionEventListener connectioneventlistener)
    {
        connectionListeners.remove(connectioneventlistener);
    }

    public XAResource getXAResource()
        throws ResourceException
    {
        return xaConnection.getXAResource();
    }

    public LocalTransaction getLocalTransaction()
        throws ResourceException
    {
        if(localTxn == null)
            localTxn = new OracleLocalTransaction(this);
        return localTxn;
    }

    public ManagedConnectionMetaData getMetaData()
        throws ResourceException
    {
        return new OracleManagedConnectionMetaData(this);
    }

    public void setLogWriter(PrintWriter printwriter)
        throws ResourceException
    {
        logWriter = printwriter;
    }

    public PrintWriter getLogWriter()
        throws ResourceException
    {
        return logWriter;
    }

    Connection getPhysicalConnection()
        throws ResourceException
    {
        try
        {
            return xaConnection.getPhysicalHandle();
        }
        catch(Exception exception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("Exception: ").append(exception.getMessage()).toString());
            eissystemexception.setLinkedException(exception);
            throw eissystemexception;
        }
    }

    void setPasswordCredential(PasswordCredential passwordcredential)
    {
        passwordCredential = passwordcredential;
    }

    PasswordCredential getPasswordCredential()
    {
        return passwordCredential;
    }

    void eventOccurred(int i)
        throws ResourceException
    {
        Enumeration enumeration = connectionListeners.keys();
        do
        {
            if(!enumeration.hasMoreElements())
                break;
            ConnectionEventListener connectioneventlistener = (ConnectionEventListener)enumeration.nextElement();
            ConnectionEvent connectionevent = new ConnectionEvent(this, i);
            switch(i)
            {
            case 1: // '\001'
                connectioneventlistener.connectionClosed(connectionevent);
                break;

            case 2: // '\002'
                connectioneventlistener.localTransactionStarted(connectionevent);
                break;

            case 3: // '\003'
                connectioneventlistener.localTransactionCommitted(connectionevent);
                break;

            case 4: // '\004'
                connectioneventlistener.localTransactionRolledback(connectionevent);
                break;

            case 5: // '\005'
                connectioneventlistener.connectionErrorOccurred(connectionevent);
                break;

            default:
                throw new IllegalArgumentException((new StringBuilder()).append("Illegal eventType in eventOccurred(): ").append(i).toString());
            }
        } while(true);
    }

}
