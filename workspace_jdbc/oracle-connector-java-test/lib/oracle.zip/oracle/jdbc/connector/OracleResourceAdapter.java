// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleResourceAdapter.java

package oracle.jdbc.connector;

import javax.resource.NotSupportedException;
import javax.resource.ResourceException;
import javax.resource.spi.*;
import javax.resource.spi.endpoint.MessageEndpointFactory;
import javax.transaction.xa.XAResource;

public class OracleResourceAdapter
    implements ResourceAdapter
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleResourceAdapter()
    {
    }

    public void start(BootstrapContext bootstrapcontext)
        throws ResourceAdapterInternalException
    {
    }

    public void stop()
    {
    }

    public void endpointActivation(MessageEndpointFactory messageendpointfactory, ActivationSpec activationspec)
        throws NotSupportedException
    {
    }

    public void endpointDeactivation(MessageEndpointFactory messageendpointfactory, ActivationSpec activationspec)
    {
    }

    public XAResource[] getXAResources(ActivationSpec aactivationspec[])
        throws ResourceException
    {
        return new XAResource[0];
    }

}
