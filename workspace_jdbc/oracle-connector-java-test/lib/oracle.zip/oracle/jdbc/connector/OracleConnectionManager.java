// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConnectionManager.java

package oracle.jdbc.connector;

import javax.resource.ResourceException;
import javax.resource.spi.*;

public class OracleConnectionManager
    implements ConnectionManager
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleConnectionManager()
    {
    }

    public Object allocateConnection(ManagedConnectionFactory managedconnectionfactory, ConnectionRequestInfo connectionrequestinfo)
        throws ResourceException
    {
        ManagedConnection managedconnection = managedconnectionfactory.createManagedConnection(null, connectionrequestinfo);
        return managedconnection.getConnection(null, connectionrequestinfo);
    }

}
