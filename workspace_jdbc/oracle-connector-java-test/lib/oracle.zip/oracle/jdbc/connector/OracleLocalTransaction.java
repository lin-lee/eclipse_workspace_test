// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleLocalTransaction.java

package oracle.jdbc.connector;

import java.sql.Connection;
import java.sql.SQLException;
import javax.resource.ResourceException;
import javax.resource.spi.*;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.connector:
//            OracleManagedConnection

public class OracleLocalTransaction
    implements LocalTransaction
{

    private OracleManagedConnection managedConnection;
    private Connection connection;
    boolean isBeginCalled;
    private static final String RAERR_LTXN_COMMIT = "commit without begin";
    private static final String RAERR_LTXN_ROLLBACK = "rollback without begin";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleLocalTransaction(OracleManagedConnection oraclemanagedconnection)
        throws ResourceException
    {
        managedConnection = null;
        connection = null;
        isBeginCalled = false;
        managedConnection = oraclemanagedconnection;
        connection = oraclemanagedconnection.getPhysicalConnection();
        isBeginCalled = false;
    }

    public void begin()
        throws ResourceException
    {
        try
        {
            if(((OracleConnection)connection).getTxnMode() == 1)
                throw new IllegalStateException("Could not start a new transaction inside an active transaction");
            if(connection.getAutoCommit())
                connection.setAutoCommit(false);
            isBeginCalled = true;
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
        managedConnection.eventOccurred(2);
    }

    public void commit()
        throws ResourceException
    {
        if(!isBeginCalled)
            throw new LocalTransactionException("begin() must be called before commit()", "commit without begin");
        try
        {
            connection.commit();
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
        isBeginCalled = false;
        managedConnection.eventOccurred(3);
    }

    public void rollback()
        throws ResourceException
    {
        if(!isBeginCalled)
            throw new LocalTransactionException("begin() must be called before rollback()", "rollback without begin");
        try
        {
            connection.rollback();
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
        isBeginCalled = false;
        managedConnection.eventOccurred(4);
    }

}
