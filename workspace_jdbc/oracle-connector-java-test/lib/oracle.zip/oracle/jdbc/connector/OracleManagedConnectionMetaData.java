// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleManagedConnectionMetaData.java

package oracle.jdbc.connector;

import java.sql.SQLException;
import javax.resource.ResourceException;
import javax.resource.spi.EISSystemException;
import javax.resource.spi.ManagedConnectionMetaData;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleDatabaseMetaData;

// Referenced classes of package oracle.jdbc.connector:
//            OracleManagedConnection

public class OracleManagedConnectionMetaData
    implements ManagedConnectionMetaData
{

    private OracleManagedConnection managedConnection;
    private OracleDatabaseMetaData databaseMetaData;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleManagedConnectionMetaData(OracleManagedConnection oraclemanagedconnection)
        throws ResourceException
    {
        managedConnection = null;
        databaseMetaData = null;
        try
        {
            managedConnection = oraclemanagedconnection;
            OracleConnection oracleconnection = (OracleConnection)oraclemanagedconnection.getPhysicalConnection();
            databaseMetaData = (OracleDatabaseMetaData)oracleconnection.getMetaData();
        }
        catch(Exception exception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("Exception: ").append(exception.getMessage()).toString());
            eissystemexception.setLinkedException(exception);
            throw eissystemexception;
        }
    }

    public String getEISProductName()
        throws ResourceException
    {
        try
        {
            return databaseMetaData.getDatabaseProductName();
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
    }

    public String getEISProductVersion()
        throws ResourceException
    {
        try
        {
            return databaseMetaData.getDatabaseProductVersion();
        }
        catch(Exception exception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("Exception: ").append(exception.getMessage()).toString());
            eissystemexception.setLinkedException(exception);
            throw eissystemexception;
        }
    }

    public int getMaxConnections()
        throws ResourceException
    {
        try
        {
            return databaseMetaData.getMaxConnections();
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
    }

    public String getUserName()
        throws ResourceException
    {
        try
        {
            return databaseMetaData.getUserName();
        }
        catch(SQLException sqlexception)
        {
            EISSystemException eissystemexception = new EISSystemException((new StringBuilder()).append("SQLException: ").append(sqlexception.getMessage()).toString());
            eissystemexception.setLinkedException(sqlexception);
            throw eissystemexception;
        }
    }

}
