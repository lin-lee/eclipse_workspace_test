// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc:
//            OracleStatement, OracleParameterMetaData

public interface OraclePreparedStatement
    extends PreparedStatement, OracleStatement
{

    public static final short FORM_NCHAR = 2;
    public static final short FORM_CHAR = 1;

    public abstract void defineParameterTypeBytes(int i, int j, int k)
        throws SQLException;

    public abstract void defineParameterTypeChars(int i, int j, int k)
        throws SQLException;

    public abstract void defineParameterType(int i, int j, int k)
        throws SQLException;

    public abstract int getExecuteBatch();

    public abstract int sendBatch()
        throws SQLException;

    public abstract void setARRAY(int i, ARRAY array)
        throws SQLException;

    public abstract void setBfile(int i, BFILE bfile)
        throws SQLException;

    public abstract void setBFILE(int i, BFILE bfile)
        throws SQLException;

    public abstract void setBLOB(int i, BLOB blob)
        throws SQLException;

    public abstract void setCHAR(int i, CHAR char1)
        throws SQLException;

    public abstract void setCLOB(int i, CLOB clob)
        throws SQLException;

    /**
     * @deprecated Method setCursor is deprecated
     */

    public abstract void setCursor(int i, ResultSet resultset)
        throws SQLException;

    /**
     * @deprecated Method setCustomDatum is deprecated
     */

    public abstract void setCustomDatum(int i, CustomDatum customdatum)
        throws SQLException;

    public abstract void setORAData(int i, ORAData oradata)
        throws SQLException;

    public abstract void setDATE(int i, DATE date)
        throws SQLException;

    public abstract void setExecuteBatch(int i)
        throws SQLException;

    public abstract void setFixedCHAR(int i, String s)
        throws SQLException;

    public abstract void setNUMBER(int i, NUMBER number)
        throws SQLException;

    public abstract void setBinaryFloat(int i, float f)
        throws SQLException;

    public abstract void setBinaryFloat(int i, BINARY_FLOAT binary_float)
        throws SQLException;

    public abstract void setBinaryDouble(int i, double d)
        throws SQLException;

    public abstract void setBinaryDouble(int i, BINARY_DOUBLE binary_double)
        throws SQLException;

    public abstract void setOPAQUE(int i, OPAQUE opaque)
        throws SQLException;

    public abstract void setOracleObject(int i, Datum datum)
        throws SQLException;

    public abstract void setStructDescriptor(int i, StructDescriptor structdescriptor)
        throws SQLException;

    public abstract void setRAW(int i, RAW raw)
        throws SQLException;

    public abstract void setREF(int i, REF ref)
        throws SQLException;

    public abstract void setRefType(int i, REF ref)
        throws SQLException;

    public abstract void setROWID(int i, ROWID rowid)
        throws SQLException;

    public abstract void setSTRUCT(int i, STRUCT struct)
        throws SQLException;

    public abstract void setTIMESTAMP(int i, TIMESTAMP timestamp)
        throws SQLException;

    public abstract void setTIMESTAMPTZ(int i, TIMESTAMPTZ timestamptz)
        throws SQLException;

    public abstract void setTIMESTAMPLTZ(int i, TIMESTAMPLTZ timestampltz)
        throws SQLException;

    public abstract void setINTERVALYM(int i, INTERVALYM intervalym)
        throws SQLException;

    public abstract void setINTERVALDS(int i, INTERVALDS intervalds)
        throws SQLException;

    public abstract void setNullAtName(String s, int i, String s1)
        throws SQLException;

    public abstract void setNullAtName(String s, int i)
        throws SQLException;

    public abstract void setBooleanAtName(String s, boolean flag)
        throws SQLException;

    public abstract void setByteAtName(String s, byte byte0)
        throws SQLException;

    public abstract void setShortAtName(String s, short word0)
        throws SQLException;

    public abstract void setIntAtName(String s, int i)
        throws SQLException;

    public abstract void setLongAtName(String s, long l)
        throws SQLException;

    public abstract void setFloatAtName(String s, float f)
        throws SQLException;

    public abstract void setDoubleAtName(String s, double d)
        throws SQLException;

    public abstract void setBinaryFloatAtName(String s, float f)
        throws SQLException;

    public abstract void setBinaryFloatAtName(String s, BINARY_FLOAT binary_float)
        throws SQLException;

    public abstract void setBinaryDoubleAtName(String s, double d)
        throws SQLException;

    public abstract void setBinaryDoubleAtName(String s, BINARY_DOUBLE binary_double)
        throws SQLException;

    public abstract void setBigDecimalAtName(String s, BigDecimal bigdecimal)
        throws SQLException;

    public abstract void setStringAtName(String s, String s1)
        throws SQLException;

    public abstract void setStringForClob(int i, String s)
        throws SQLException;

    public abstract void setStringForClobAtName(String s, String s1)
        throws SQLException;

    public abstract void setFixedCHARAtName(String s, String s1)
        throws SQLException;

    public abstract void setCursorAtName(String s, ResultSet resultset)
        throws SQLException;

    public abstract void setROWIDAtName(String s, ROWID rowid)
        throws SQLException;

    public abstract void setArrayAtName(String s, Array array)
        throws SQLException;

    public abstract void setARRAYAtName(String s, ARRAY array)
        throws SQLException;

    public abstract void setOPAQUEAtName(String s, OPAQUE opaque)
        throws SQLException;

    public abstract void setStructDescriptorAtName(String s, StructDescriptor structdescriptor)
        throws SQLException;

    public abstract void setSTRUCTAtName(String s, STRUCT struct)
        throws SQLException;

    public abstract void setRAWAtName(String s, RAW raw)
        throws SQLException;

    public abstract void setCHARAtName(String s, CHAR char1)
        throws SQLException;

    public abstract void setDATEAtName(String s, DATE date)
        throws SQLException;

    public abstract void setNUMBERAtName(String s, NUMBER number)
        throws SQLException;

    public abstract void setBLOBAtName(String s, BLOB blob)
        throws SQLException;

    public abstract void setBlobAtName(String s, Blob blob)
        throws SQLException;

    public abstract void setBlobAtName(String s, InputStream inputstream, long l)
        throws SQLException;

    public abstract void setBlobAtName(String s, InputStream inputstream)
        throws SQLException;

    public abstract void setCLOBAtName(String s, CLOB clob)
        throws SQLException;

    public abstract void setClobAtName(String s, Clob clob)
        throws SQLException;

    public abstract void setClobAtName(String s, Reader reader, long l)
        throws SQLException;

    public abstract void setClobAtName(String s, Reader reader)
        throws SQLException;

    public abstract void setBFILEAtName(String s, BFILE bfile)
        throws SQLException;

    public abstract void setBfileAtName(String s, BFILE bfile)
        throws SQLException;

    public abstract void setBytesAtName(String s, byte abyte0[])
        throws SQLException;

    public abstract void setBytesForBlob(int i, byte abyte0[])
        throws SQLException;

    public abstract void setBytesForBlobAtName(String s, byte abyte0[])
        throws SQLException;

    public abstract void setDateAtName(String s, Date date)
        throws SQLException;

    public abstract void setDateAtName(String s, Date date, Calendar calendar)
        throws SQLException;

    public abstract void setTimeAtName(String s, Time time)
        throws SQLException;

    public abstract void setTimeAtName(String s, Time time, Calendar calendar)
        throws SQLException;

    public abstract void setTimestampAtName(String s, Timestamp timestamp)
        throws SQLException;

    public abstract void setTimestampAtName(String s, Timestamp timestamp, Calendar calendar)
        throws SQLException;

    public abstract void setINTERVALYMAtName(String s, INTERVALYM intervalym)
        throws SQLException;

    public abstract void setINTERVALDSAtName(String s, INTERVALDS intervalds)
        throws SQLException;

    public abstract void setTIMESTAMPAtName(String s, TIMESTAMP timestamp)
        throws SQLException;

    public abstract void setTIMESTAMPTZAtName(String s, TIMESTAMPTZ timestamptz)
        throws SQLException;

    public abstract void setTIMESTAMPLTZAtName(String s, TIMESTAMPLTZ timestampltz)
        throws SQLException;

    public abstract void setAsciiStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException;

    public abstract void setAsciiStreamAtName(String s, InputStream inputstream, long l)
        throws SQLException;

    public abstract void setAsciiStreamAtName(String s, InputStream inputstream)
        throws SQLException;

    public abstract void setBinaryStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException;

    public abstract void setBinaryStreamAtName(String s, InputStream inputstream, long l)
        throws SQLException;

    public abstract void setBinaryStreamAtName(String s, InputStream inputstream)
        throws SQLException;

    public abstract void setCharacterStreamAtName(String s, Reader reader, long l)
        throws SQLException;

    public abstract void setCharacterStreamAtName(String s, Reader reader)
        throws SQLException;

    public abstract void setUnicodeStreamAtName(String s, InputStream inputstream, int i)
        throws SQLException;

    public abstract void setCustomDatumAtName(String s, CustomDatum customdatum)
        throws SQLException;

    public abstract void setORADataAtName(String s, ORAData oradata)
        throws SQLException;

    public abstract void setObjectAtName(String s, Object obj, int i, int j)
        throws SQLException;

    public abstract void setObjectAtName(String s, Object obj, int i)
        throws SQLException;

    public abstract void setRefTypeAtName(String s, REF ref)
        throws SQLException;

    public abstract void setRefAtName(String s, Ref ref)
        throws SQLException;

    public abstract void setREFAtName(String s, REF ref)
        throws SQLException;

    public abstract void setObjectAtName(String s, Object obj)
        throws SQLException;

    public abstract void setOracleObjectAtName(String s, Datum datum)
        throws SQLException;

    public abstract void setURLAtName(String s, URL url)
        throws SQLException;

    public abstract void setCheckBindTypes(boolean flag);

    public abstract void setPlsqlIndexTable(int i, Object obj, int j, int k, int l, int i1)
        throws SQLException;

    public abstract void setFormOfUse(int i, short word0);

    public abstract void setDisableStmtCaching(boolean flag);

    public abstract OracleParameterMetaData OracleGetParameterMetaData()
        throws SQLException;

    public abstract void registerReturnParameter(int i, int j)
        throws SQLException;

    public abstract void registerReturnParameter(int i, int j, int k)
        throws SQLException;

    public abstract void registerReturnParameter(int i, int j, String s)
        throws SQLException;

    public abstract ResultSet getReturnResultSet()
        throws SQLException;

    public abstract void setNCharacterStreamAtName(String s, Reader reader, long l)
        throws SQLException;

    public abstract void setNCharacterStreamAtName(String s, Reader reader)
        throws SQLException;

    public abstract void setNClobAtName(String s, NClob nclob)
        throws SQLException;

    public abstract void setNClobAtName(String s, Reader reader, long l)
        throws SQLException;

    public abstract void setNClobAtName(String s, Reader reader)
        throws SQLException;

    public abstract void setNStringAtName(String s, String s1)
        throws SQLException;

    public abstract void setRowIdAtName(String s, RowId rowid)
        throws SQLException;

    public abstract void setSQLXMLAtName(String s, SQLXML sqlxml)
        throws SQLException;
}
