// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NonTxnReplayableClob.java

package oracle.jdbc.replay.driver;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

// Referenced classes of package oracle.jdbc.replay.driver:
//            NonTxnReplayableBase, Replayable, FailoverManagerImpl, ReplayLoggerFactory

public abstract class NonTxnReplayableClob extends NonTxnReplayableBase
    implements Replayable
{

    private static final String CLOB_FEATURE_LOGGER_NAME = "oracle.jdbc.internal.replay.NonTxnReplayableClob";
    private static Logger CLOB_REPLAY_LOGGER;

    public NonTxnReplayableClob()
    {
    }

    protected transient void preForAll(Method method, Object obj, Object aobj[])
    {
        super.preForAll(method, obj, aobj);
    }

    protected transient void preForClobWrites(Method method, Object obj, Object aobj[])
    {
        FailoverManagerImpl.ReplayLifecycle replaylifecycle = failoverMngr.getReplayLifecycle();
        if(replaylifecycle != FailoverManagerImpl.ReplayLifecycle.ENABLED_NOT_REPLAYING)
            return;
        CLOB_REPLAY_LOGGER.log(Level.FINER, "On clob {0}, entering preForClobWrites({1})", new Object[] {
            this, method.getName()
        });
        if(failoverMngr != null)
            failoverMngr.disableReplayInternal(method, 371, "Replay disabled because of active transaction", null);
        else
            CLOB_REPLAY_LOGGER.log(Level.SEVERE, "On clob {0}, failover manager not set", this);
        CLOB_REPLAY_LOGGER.log(Level.FINER, "On clob {0}, exiting preForClobWrites()", this);
    }

    protected Object postForAll(Method method, Object obj)
    {
        if(obj instanceof NonTxnReplayableBase)
        {
            NonTxnReplayableBase nontxnreplayablebase = (NonTxnReplayableBase)obj;
            nontxnreplayablebase.setFailoverManager(getFailoverManager());
        }
        return super.postForAll(method, obj);
    }

    protected void onErrorVoidForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        super.onErrorVoidForAll(method, sqlexception);
    }

    protected Object onErrorForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        return super.onErrorForAll(method, sqlexception);
    }

    protected abstract Object getDelegate();

    protected abstract void setDelegate(Object obj);

    protected abstract Object getCreator();

    static 
    {
        CLOB_REPLAY_LOGGER = null;
        if(CLOB_REPLAY_LOGGER == null)
            CLOB_REPLAY_LOGGER = ReplayLoggerFactory.getLogger("oracle.jdbc.internal.replay.NonTxnReplayableClob");
    }
}
