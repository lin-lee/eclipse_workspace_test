// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NonTxnReplayableNClob.java

package oracle.jdbc.replay.driver;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

// Referenced classes of package oracle.jdbc.replay.driver:
//            NonTxnReplayableClob, NonTxnReplayableBase, Replayable, FailoverManagerImpl, 
//            ReplayLoggerFactory

public abstract class NonTxnReplayableNClob extends NonTxnReplayableClob
    implements Replayable
{

    private static final String NCLOB_FEATURE_LOGGER_NAME = "oracle.jdbc.internal.replay.NonTxnReplayableNClob";
    private static Logger NCLOB_REPLAY_LOGGER;

    public NonTxnReplayableNClob()
    {
    }

    protected transient void preForAll(Method method, Object obj, Object aobj[])
    {
        super.preForAll(method, obj, aobj);
    }

    protected transient void preForClobWrites(Method method, Object obj, Object aobj[])
    {
        FailoverManagerImpl.ReplayLifecycle replaylifecycle = failoverMngr.getReplayLifecycle();
        if(replaylifecycle != FailoverManagerImpl.ReplayLifecycle.ENABLED_NOT_REPLAYING)
        {
            return;
        } else
        {
            NCLOB_REPLAY_LOGGER.log(Level.FINER, "On nclob {0}, entering preForClobWrites({1})", new Object[] {
                this, method.getName()
            });
            super.preForClobWrites(method, obj, aobj);
            NCLOB_REPLAY_LOGGER.log(Level.FINER, "On nclob {0}, exiting preForClobWrites()", this);
            return;
        }
    }

    protected Object postForAll(Method method, Object obj)
    {
        if(obj instanceof NonTxnReplayableBase)
        {
            NonTxnReplayableBase nontxnreplayablebase = (NonTxnReplayableBase)obj;
            nontxnreplayablebase.setFailoverManager(getFailoverManager());
        }
        return super.postForAll(method, obj);
    }

    protected void onErrorVoidForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        super.onErrorVoidForAll(method, sqlexception);
    }

    protected Object onErrorForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        return super.onErrorForAll(method, sqlexception);
    }

    protected abstract Object getDelegate();

    protected abstract void setDelegate(Object obj);

    protected abstract Object getCreator();

    static 
    {
        NCLOB_REPLAY_LOGGER = null;
        if(NCLOB_REPLAY_LOGGER == null)
            NCLOB_REPLAY_LOGGER = ReplayLoggerFactory.getLogger("oracle.jdbc.internal.replay.NonTxnReplayableNClob");
    }
}
