// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NonTxnReplayableOpaque.java

package oracle.jdbc.replay.driver;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;

// Referenced classes of package oracle.jdbc.replay.driver:
//            NonTxnReplayableBase, Replayable, FailoverManagerImpl, ReplayLoggerFactory

public abstract class NonTxnReplayableOpaque extends NonTxnReplayableBase
    implements Replayable
{

    private static final String OPAQUE_FEATURE_LOGGER_NAME = "oracle.jdbc.internal.replay.NonTxnReplayableOpaque";
    private static Logger OPAQUE_REPLAY_LOGGER;

    public NonTxnReplayableOpaque()
    {
    }

    protected transient void preForAll(Method method, Object obj, Object aobj[])
    {
        super.preForAll(method, obj, aobj);
    }

    protected Object postForAll(Method method, Object obj)
    {
        if(obj instanceof NonTxnReplayableBase)
        {
            NonTxnReplayableBase nontxnreplayablebase = (NonTxnReplayableBase)obj;
            nontxnreplayablebase.setFailoverManager(getFailoverManager());
        }
        return super.postForAll(method, obj);
    }

    protected void onErrorVoidForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        super.onErrorVoidForAll(method, sqlexception);
    }

    protected Object onErrorForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        return super.onErrorForAll(method, sqlexception);
    }

    protected abstract Object getDelegate();

    protected abstract void setDelegate(Object obj);

    protected abstract Object getCreator();

    public Connection getJavaSqlConnection()
    {
        return (Connection)getFailoverManager().getConnectionProxy();
    }

    static 
    {
        OPAQUE_REPLAY_LOGGER = null;
        if(OPAQUE_REPLAY_LOGGER == null)
            OPAQUE_REPLAY_LOGGER = ReplayLoggerFactory.getLogger("oracle.jdbc.internal.replay.NonTxnReplayableOpaque");
    }
}
