// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NonTxnReplayableBlob.java

package oracle.jdbc.replay.driver;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

// Referenced classes of package oracle.jdbc.replay.driver:
//            NonTxnReplayableBase, Replayable, FailoverManagerImpl, ReplayLoggerFactory

public abstract class NonTxnReplayableBlob extends NonTxnReplayableBase
    implements Replayable
{

    private static final String BLOB_FEATURE_LOGGER_NAME = "oracle.jdbc.internal.replay.NonTxnReplayableBlob";
    private static Logger BLOB_REPLAY_LOGGER;

    public NonTxnReplayableBlob()
    {
    }

    protected transient void preForAll(Method method, Object obj, Object aobj[])
    {
        super.preForAll(method, obj, aobj);
    }

    protected transient void preForBlobWrites(Method method, Object obj, Object aobj[])
    {
        FailoverManagerImpl.ReplayLifecycle replaylifecycle = failoverMngr.getReplayLifecycle();
        if(replaylifecycle != FailoverManagerImpl.ReplayLifecycle.ENABLED_NOT_REPLAYING)
            return;
        BLOB_REPLAY_LOGGER.log(Level.FINER, "On blob {0}, entering preForBlobWrites({1})", new Object[] {
            this, method.getName()
        });
        if(failoverMngr != null)
            failoverMngr.disableReplayInternal(method, 371, "Replay disabled because of active transaction", null);
        else
            BLOB_REPLAY_LOGGER.log(Level.SEVERE, "On blob {0}, failover manager not set", this);
        BLOB_REPLAY_LOGGER.log(Level.FINER, "On blob {0}, exiting preForBlobWrites()", this);
    }

    protected Object postForAll(Method method, Object obj)
    {
        if(obj instanceof NonTxnReplayableBase)
        {
            NonTxnReplayableBase nontxnreplayablebase = (NonTxnReplayableBase)obj;
            nontxnreplayablebase.setFailoverManager(getFailoverManager());
        }
        return super.postForAll(method, obj);
    }

    protected void onErrorVoidForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        super.onErrorVoidForAll(method, sqlexception);
    }

    protected Object onErrorForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        return super.onErrorForAll(method, sqlexception);
    }

    protected abstract Object getDelegate();

    protected abstract void setDelegate(Object obj);

    protected abstract Object getCreator();

    static 
    {
        BLOB_REPLAY_LOGGER = null;
        if(BLOB_REPLAY_LOGGER == null)
            BLOB_REPLAY_LOGGER = ReplayLoggerFactory.getLogger("oracle.jdbc.internal.replay.NonTxnReplayableBlob");
    }
}
