// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   FailoverManagerImpl.java

package oracle.jdbc.replay.driver;

import java.lang.reflect.Method;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.replay.OracleDataSource;
import oracle.jdbc.replay.internal.ConnectionInitializationCallback;

// Referenced classes of package oracle.jdbc.replay.driver:
//            Replayable, NonTxnReplayableBase, FailoverManager, ReplayLoggerFactory

class FailoverManagerImpl
    implements FailoverManager
{
    static final class ReplayLifecycle extends Enum
    {

        public static final ReplayLifecycle ENABLED_NOT_REPLAYING;
        public static final ReplayLifecycle INTERNALLY_FAILED;
        public static final ReplayLifecycle INTERNALLY_DISABLED;
        public static final ReplayLifecycle ALWAYS_DISABLED;
        public static final ReplayLifecycle EXTERNALLY_DISABLED;
        public static final ReplayLifecycle REPLAYING_CALLBACK;
        public static final ReplayLifecycle REPLAYING;
        public static final ReplayLifecycle REPLAYING_LASTCALL;
        private static final ReplayLifecycle $VALUES[];

        public static ReplayLifecycle[] values()
        {
            return (ReplayLifecycle[])$VALUES.clone();
        }

        public static ReplayLifecycle valueOf(String s)
        {
            return (ReplayLifecycle)Enum.valueOf(oracle/jdbc/replay/driver/FailoverManagerImpl$ReplayLifecycle, s);
        }

        static 
        {
            ENABLED_NOT_REPLAYING = new ReplayLifecycle("ENABLED_NOT_REPLAYING", 0);
            INTERNALLY_FAILED = new ReplayLifecycle("INTERNALLY_FAILED", 1);
            INTERNALLY_DISABLED = new ReplayLifecycle("INTERNALLY_DISABLED", 2);
            ALWAYS_DISABLED = new ReplayLifecycle("ALWAYS_DISABLED", 3);
            EXTERNALLY_DISABLED = new ReplayLifecycle("EXTERNALLY_DISABLED", 4);
            REPLAYING_CALLBACK = new ReplayLifecycle("REPLAYING_CALLBACK", 5);
            REPLAYING = new ReplayLifecycle("REPLAYING", 6);
            REPLAYING_LASTCALL = new ReplayLifecycle("REPLAYING_LASTCALL", 7);
            $VALUES = (new ReplayLifecycle[] {
                ENABLED_NOT_REPLAYING, INTERNALLY_FAILED, INTERNALLY_DISABLED, ALWAYS_DISABLED, EXTERNALLY_DISABLED, REPLAYING_CALLBACK, REPLAYING, REPLAYING_LASTCALL
            });
        }

        private ReplayLifecycle(String s, int i)
        {
            super(s, i);
        }
    }

    static class CallHistoryEntry
    {

        Object jdbcProxy;
        Method method;
        Object args[];
        Object result;
        String callStatus;
        long scn;
        long checksum;
        SQLException callException;
        CallHistoryEntry nextEntry;
        CallHistoryEntry prevEntry;
        CallHistoryEntry nextEntrySameProxy;
        CallHistoryEntry prevEntrySameProxy;

        CallHistoryEntry(Object obj, Method method1, Object aobj[], String s)
        {
            nextEntry = null;
            prevEntry = null;
            nextEntrySameProxy = null;
            prevEntrySameProxy = null;
            jdbcProxy = obj;
            method = method1;
            args = aobj;
            result = null;
            callStatus = s;
        }
    }


    private static final String MNGR_FEATURE_LOGGER_NAME = "oracle.jdbc.internal.replay.FailoverManagerImpl";
    private static Logger MNGR_REPLAY_LOGGER;
    private static final String MONITOR_TXN = "BEGIN DBMS_APP_CONT_PRVT.MONITOR_TXN; END;";
    private static final String BEGIN_REPLAY = "BEGIN DBMS_APP_CONT_PRVT.BEGIN_REPLAY; END;";
    private static final String END_REPLAY = "BEGIN DBMS_APP_CONT_PRVT.END_REPLAY; END;";
    private CallHistoryEntry head;
    private CallHistoryEntry tail;
    private ReplayLifecycle lifecycle;
    private boolean replayInCurrentMode;
    private Object replayResult;
    private long requestStartTime;
    private long replayInitiationTimeout;
    private static final int REPLAY_RETRIES = 3;
    private int replayRetries;
    private OracleDataSource replayDataSource;
    private NonTxnReplayableBase connectionProxy;
    private Method callCausingReplayError;
    private int replayErrorCode;
    private String replayErrorMessage;
    private boolean doNotAbortConn;
    private static final ExecutorService executor = Executors.newSingleThreadExecutor(new ThreadFactory() {

        private static final String THREAD_NAME = "OJDBC-AC-WORKER-THREAD";

        public Thread newThread(Runnable runnable)
        {
            Thread thread = new Thread(null, runnable, "OJDBC-AC-WORKER-THREAD");
            thread.setPriority(5);
            thread.setDaemon(true);
            return thread;
        }

    }
);

    private FailoverManagerImpl(NonTxnReplayableBase nontxnreplayablebase, OracleDataSource oracledatasource)
        throws SQLException
    {
        lifecycle = ReplayLifecycle.INTERNALLY_DISABLED;
        replayInCurrentMode = false;
        replayInitiationTimeout = 900L;
        replayRetries = 0;
        replayDataSource = null;
        doNotAbortConn = false;
        connectionProxy = nontxnreplayablebase;
        replayDataSource = oracledatasource;
        enableTxnMonitoring((OracleConnection)connectionProxy.getDelegate());
    }

    static FailoverManager getFailoverManager(NonTxnReplayableBase nontxnreplayablebase, OracleDataSource oracledatasource)
        throws SQLException
    {
        return new FailoverManagerImpl(nontxnreplayablebase, oracledatasource);
    }

    private void append(CallHistoryEntry callhistoryentry)
    {
        callhistoryentry.prevEntry = tail;
        callhistoryentry.nextEntry = null;
        if(tail != null)
            tail.nextEntry = callhistoryentry;
        tail = callhistoryentry;
        if(head == null)
            head = callhistoryentry;
        Replayable replayable = (Replayable)callhistoryentry.jdbcProxy;
        replayable.addToSameProxyList(callhistoryentry);
    }

    private void remove(CallHistoryEntry callhistoryentry)
    {
        if(callhistoryentry.nextEntry != null)
            callhistoryentry.nextEntry.prevEntry = callhistoryentry.prevEntry;
        if(callhistoryentry.prevEntry != null)
            callhistoryentry.prevEntry.nextEntry = callhistoryentry.nextEntry;
        if(head == callhistoryentry)
            head = callhistoryentry.nextEntry;
        if(tail == callhistoryentry)
            tail = callhistoryentry.prevEntry;
        Replayable replayable = (Replayable)callhistoryentry.jdbcProxy;
        replayable.removeFromSameProxyList(callhistoryentry);
    }

    CallHistoryEntry record(Object obj, Method method, Object aobj[], String s)
    {
        FailoverManagerImpl failovermanagerimpl = this;
        JVM INSTR monitorenter ;
        String s1 = method != null ? method.getName() : "NULL METHOD";
        StringBuilder stringbuilder = new StringBuilder();
        if(aobj != null && aobj.length > 0)
        {
            for(int i = 0; i < aobj.length - 1; i++)
            {
                stringbuilder.append(aobj[i]);
                stringbuilder.append(",");
            }

            stringbuilder.append(aobj[aobj.length - 1]);
        }
        MNGR_REPLAY_LOGGER.log(Level.FINEST, "On connection {0}, recording method {1}({2})", new Object[] {
            connectionProxy, s1, stringbuilder.toString()
        });
        CallHistoryEntry callhistoryentry = new CallHistoryEntry(obj, method, aobj, s);
        append(callhistoryentry);
        MNGR_REPLAY_LOGGER.log(Level.FINEST, "On connection {0}, recorded method {1}", new Object[] {
            connectionProxy, s1
        });
        return callhistoryentry;
        Exception exception;
        exception;
        throw exception;
    }

    void update(Object obj, CallHistoryEntry callhistoryentry, Object obj1, String s, long l, long l1, SQLException sqlexception)
    {
        synchronized(this)
        {
            CallHistoryEntry callhistoryentry1 = callhistoryentry != null ? callhistoryentry : tail;
            String s1 = callhistoryentry1 != null && callhistoryentry1.method != null ? callhistoryentry1.method.getName() : "NULL METHOD";
            MNGR_REPLAY_LOGGER.log(Level.FINEST, "On connection {0}, updating entry for method {1}", new Object[] {
                connectionProxy, s1
            });
            callhistoryentry1.result = obj1;
            callhistoryentry1.checksum = l;
            callhistoryentry1.scn = l1;
            callhistoryentry1.callException = sqlexception;
            callhistoryentry1.callStatus = s;
            MNGR_REPLAY_LOGGER.log(Level.FINEST, "On connection {0}, updated entry for method {1} - result: {2}, checksum: {3}, SCN: {4}, SQLException: {5}", new Object[] {
                connectionProxy, s1, obj1, Long.valueOf(l), Long.valueOf(l1), sqlexception
            });
        }
    }

    synchronized void purge()
    {
        MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, calling explicit purge", connectionProxy);
        for(CallHistoryEntry callhistoryentry = head; callhistoryentry != null; callhistoryentry = callhistoryentry.nextEntry)
            remove(callhistoryentry);

        MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, calling explicit purge succeeds", connectionProxy);
    }

    synchronized void purgeForSameProxy(Set set, CallHistoryEntry callhistoryentry)
    {
        Object obj = callhistoryentry != null ? callhistoryentry.jdbcProxy : null;
        MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, calling implicit purge for {1}", new Object[] {
            connectionProxy, obj
        });
        for(CallHistoryEntry callhistoryentry1 = callhistoryentry; callhistoryentry1 != null; callhistoryentry1 = callhistoryentry1.nextEntrySameProxy)
        {
            Object obj1 = callhistoryentry1.result;
            if(obj1 != null && (obj1 instanceof Replayable) && !set.contains(obj1))
            {
                Replayable replayable = (Replayable)obj1;
                replayable.purgeSameProxyList();
                set.add(replayable);
            }
            MNGR_REPLAY_LOGGER.log(Level.FINEST, "On connection {0}, implicit purge {1}", new Object[] {
                connectionProxy, callhistoryentry1.method
            });
            remove(callhistoryentry1);
        }

        MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, calling implicit purge for {1} succeeds", new Object[] {
            connectionProxy, obj
        });
    }

    synchronized boolean isEmpty()
    {
        return head == null;
    }

    void fillInAllChecksums()
        throws SQLException
    {
        synchronized(this)
        {
            HashSet hashset = new HashSet();
            for(CallHistoryEntry callhistoryentry = tail.prevEntry; callhistoryentry != null; callhistoryentry = callhistoryentry.prevEntry)
            {
                if(hashset.contains(callhistoryentry.jdbcProxy))
                    continue;
                NonTxnReplayableBase nontxnreplayablebase = (NonTxnReplayableBase)callhistoryentry.jdbcProxy;
                nontxnreplayablebase.fillInChecksum(callhistoryentry);
                hashset.add(callhistoryentry.jdbcProxy);
                if(callhistoryentry.jdbcProxy instanceof ResultSet)
                    hashset.add(nontxnreplayablebase.getCreator());
            }

        }
    }

    Object replayAll(SQLRecoverableException sqlrecoverableexception)
        throws SQLException
    {
        FailoverManagerImpl failovermanagerimpl = this;
        JVM INSTR monitorenter ;
        replayRetries = 0;
_L2:
        return replayAllInternal(sqlrecoverableexception, replayRetries);
        Object obj;
        obj;
        static class _cls3
        {

            static final int $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[];

            static 
            {
                $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle = new int[ReplayLifecycle.values().length];
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[ReplayLifecycle.REPLAYING.ordinal()] = 1;
                }
                catch(NoSuchFieldError nosuchfielderror) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[ReplayLifecycle.REPLAYING_CALLBACK.ordinal()] = 2;
                }
                catch(NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[ReplayLifecycle.REPLAYING_LASTCALL.ordinal()] = 3;
                }
                catch(NoSuchFieldError nosuchfielderror2) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[ReplayLifecycle.ALWAYS_DISABLED.ordinal()] = 4;
                }
                catch(NoSuchFieldError nosuchfielderror3) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[ReplayLifecycle.INTERNALLY_DISABLED.ordinal()] = 5;
                }
                catch(NoSuchFieldError nosuchfielderror4) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[ReplayLifecycle.EXTERNALLY_DISABLED.ordinal()] = 6;
                }
                catch(NoSuchFieldError nosuchfielderror5) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[ReplayLifecycle.ENABLED_NOT_REPLAYING.ordinal()] = 7;
                }
                catch(NoSuchFieldError nosuchfielderror6) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[ReplayLifecycle.INTERNALLY_FAILED.ordinal()] = 8;
                }
                catch(NoSuchFieldError nosuchfielderror7) { }
            }
        }

        ReplayLifecycle replaylifecycle = lifecycle;
        MNGR_REPLAY_LOGGER.log(Level.FINEST, "replayAll caught new exception: {0}, current lifecycle: {1}", new Object[] {
            obj, replaylifecycle
        });
        switch(_cls3..SwitchMap.oracle.jdbc.replay.driver.FailoverManagerImpl.ReplayLifecycle[replaylifecycle.ordinal()])
        {
        case 1: // '\001'
        case 2: // '\002'
        case 3: // '\003'
            replayRetries++;
            MNGR_REPLAY_LOGGER.log(Level.FINEST, "NEW replay attempt {0}", Integer.valueOf(replayRetries));
            break;
        }
        continue; /* Loop/switch isn't completed */
        obj;
        ReplayLifecycle replaylifecycle1 = lifecycle;
        MNGR_REPLAY_LOGGER.log(Level.FINEST, "replayAll caught new exception: {0}, current lifecycle: {1}", new Object[] {
            obj, replaylifecycle1
        });
        switch(_cls3..SwitchMap.oracle.jdbc.replay.driver.FailoverManagerImpl.ReplayLifecycle[replaylifecycle1.ordinal()])
        {
        case 8: // '\b'
            replayRetries++;
            lifecycle = ReplayLifecycle.REPLAYING;
            MNGR_REPLAY_LOGGER.log(Level.FINEST, "NEW replay attempt {0} after failed replay", Integer.valueOf(replayRetries));
            break;

        case 4: // '\004'
        case 5: // '\005'
        case 6: // '\006'
            throwOriginalExceptionWithReplayError(replayErrorCode, replayErrorMessage, sqlrecoverableexception);
            // fall through

        case 3: // '\003'
            MNGR_REPLAY_LOGGER.log(Level.FINEST, "Replaying last call throws: {0}, rethrowing back", ((Throwable) (obj)));
            throw obj;
        }
        if(replayRetries <= 3) goto _L2; else goto _L1
_L1:
        MNGR_REPLAY_LOGGER.log(Level.WARNING, "Maximum replay retries exceeded");
        disableReplayAndThrowOriginalError(null, 378, "Replay disabled because maximum number of retries is exceeded", sqlrecoverableexception);
        null;
        failovermanagerimpl;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    synchronized Object replayAllInternal(SQLRecoverableException sqlrecoverableexception, int i)
        throws SQLException
    {
        MNGR_REPLAY_LOGGER.log(Level.FINER, "Entering replayAllInternal(connection proxy={0}, original error={1})", new Object[] {
            connectionProxy, sqlrecoverableexception
        });
        ReplayLifecycle replaylifecycle = lifecycle;
        MNGR_REPLAY_LOGGER.log(Level.FINEST, "current lifecycle:{0}", replaylifecycle);
        if(lifecycle != ReplayLifecycle.ENABLED_NOT_REPLAYING && lifecycle != ReplayLifecycle.REPLAYING && lifecycle != ReplayLifecycle.REPLAYING_LASTCALL && lifecycle != ReplayLifecycle.REPLAYING_CALLBACK)
        {
            if(replayErrorCode == 0)
            {
                doNotAbortConn = true;
                replayErrorCode = 370;
                replayErrorMessage = "Replay disabled";
            }
            throwReplayExceptionInternal(replayErrorCode, replayErrorMessage, sqlrecoverableexception);
        }
        OracleConnection oracleconnection = (OracleConnection)replayDataSource.getConnectionNoProxy();
        if(oracleconnection == null)
        {
            MNGR_REPLAY_LOGGER.log(Level.FINE, "FAILOVER_RETRIES exceeded");
            disableReplayAndThrowException(null, 382, "Replay disabled because Failover_Retries is exceeded", sqlrecoverableexception);
        }
        MNGR_REPLAY_LOGGER.log(Level.FINER, "Reconnect succeeded, new connection={0}", oracleconnection);
        long l = System.currentTimeMillis();
        MNGR_REPLAY_LOGGER.log(Level.FINEST, "timestamp at replay start: {0}", Long.valueOf(l));
        if(requestStartTime + replayInitiationTimeout * 1000L < l)
        {
            MNGR_REPLAY_LOGGER.log(Level.WARNING, "ReplayInitiationTimeout exceeded");
            disableReplayAndThrowException(null, 377, "Replay disabled because ReplayInitiationTimeout is exceeded", sqlrecoverableexception);
        }
        connectionProxy.setDelegate(oracleconnection);
        lifecycle = ReplayLifecycle.REPLAYING_CALLBACK;
        ConnectionInitializationCallback connectioninitializationcallback = replayDataSource.getConnectionInitializationCallback();
        if(connectioninitializationcallback != null)
        {
            try
            {
                MNGR_REPLAY_LOGGER.log(Level.FINER, "Invoking Replay Driver initialization callback with {0}", connectionProxy);
                connectioninitializationcallback.initialize((Connection)connectionProxy);
                MNGR_REPLAY_LOGGER.log(Level.FINER, "Invoking initialization callback with {0} succeeded", connectionProxy);
            }
            catch(SQLException sqlexception)
            {
                MNGR_REPLAY_LOGGER.log(Level.FINER, "Invoking initialization callback with {0} failed", connectionProxy);
                disableReplayAndThrowException(null, 379, "Replay disabled because Init callback failed", sqlrecoverableexception);
            }
            EnumSet enumset = oracleconnection.getTransactionState();
            MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, after init-callback, transaction state={1}", new Object[] {
                connectionProxy, enumset
            });
            if(enumset.contains(oracle.jdbc.internal.OracleConnection.TransactionState.TRANSACTION_STARTED))
                disableReplayAndThrowException(null, 380, "Replay disabled because of open transaction in Init callback", sqlrecoverableexception);
        }
        lifecycle = ReplayLifecycle.REPLAYING;
        if(i == 0)
            fillInAllChecksums();
        beginReplay(oracleconnection, sqlrecoverableexception);
        replayResult = replayAllBeforeLastCall(sqlrecoverableexception);
        endReplay(oracleconnection, sqlrecoverableexception);
        MNGR_REPLAY_LOGGER.log(Level.FINEST, "On connection {0}, replaying last call", connectionProxy);
        if(tail != null)
            replayResult = ((Replayable)tail.jdbcProxy).replayOneCall(tail, sqlrecoverableexception);
        lifecycle = ReplayLifecycle.ENABLED_NOT_REPLAYING;
        MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, replay succeeds", connectionProxy);
        MNGR_REPLAY_LOGGER.log(Level.FINER, "Exiting replayAll(connection proxy={0}, original error={1}), result={2}", new Object[] {
            connectionProxy, sqlrecoverableexception, replayResult
        });
        return replayResult;
    }

    private synchronized Object replayAllBeforeLastCall(SQLRecoverableException sqlrecoverableexception)
        throws SQLException
    {
        Object obj = null;
        for(CallHistoryEntry callhistoryentry = head; callhistoryentry != tail; callhistoryentry = callhistoryentry.nextEntry)
        {
            Replayable replayable = (Replayable)callhistoryentry.jdbcProxy;
            MNGR_REPLAY_LOGGER.log(Level.FINEST, "On proxy {0}, replaying {1}", new Object[] {
                replayable, callhistoryentry.method
            });
            obj = replayable.replayOneCall(callhistoryentry, sqlrecoverableexception);
            if(lifecycle != ReplayLifecycle.ENABLED_NOT_REPLAYING && lifecycle != ReplayLifecycle.REPLAYING && lifecycle != ReplayLifecycle.REPLAYING_LASTCALL && lifecycle != ReplayLifecycle.REPLAYING_CALLBACK)
                throwReplayExceptionInternal(replayErrorCode, replayErrorMessage, sqlrecoverableexception);
        }

        return obj;
    }

    boolean isReplayInCurrentMode()
    {
        return replayInCurrentMode;
    }

    void setReplayInCurrentMode()
    {
        replayInCurrentMode = true;
    }

    ReplayLifecycle getReplayLifecycle()
    {
        return lifecycle;
    }

    void setDataSource(OracleDataSource oracledatasource)
    {
        replayDataSource = oracledatasource;
    }

    void setReplayInitiationTimeout(int i)
        throws SQLException
    {
        replayInitiationTimeout = i;
    }

    void beginRequest()
        throws SQLException
    {
        MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, Entering beginRequest()", connectionProxy);
        if(lifecycle == ReplayLifecycle.ALWAYS_DISABLED)
        {
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Exiting beginRequest(), MONITOR_TXN failed, no-op");
            return;
        }
        if(lifecycle != ReplayLifecycle.INTERNALLY_DISABLED)
            throw DatabaseError.createSqlException(390);
        requestStartTime = System.currentTimeMillis();
        MNGR_REPLAY_LOGGER.log(Level.FINEST, "Request start timestamp: {0}", Long.valueOf(requestStartTime));
        OracleConnection oracleconnection = (OracleConnection)connectionProxy.getDelegate();
        EnumSet enumset = oracleconnection.getTransactionState();
        MNGR_REPLAY_LOGGER.log(Level.FINER, "transaction state: {0}", enumset);
        if(enumset.contains(oracle.jdbc.internal.OracleConnection.TransactionState.TRANSACTION_STARTED) && !enumset.contains(oracle.jdbc.internal.OracleConnection.TransactionState.TRANSACTION_READONLY))
        {
            SQLException sqlexception = DatabaseError.createSqlException(391);
            MNGR_REPLAY_LOGGER.throwing(getClass().getName(), "beginRequest", sqlexception);
            throw sqlexception;
        } else
        {
            replayErrorCode = 0;
            replayErrorMessage = "";
            callCausingReplayError = null;
            lifecycle = ReplayLifecycle.ENABLED_NOT_REPLAYING;
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Recording begins on connection {0}", connectionProxy);
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Exiting beginRequest()");
            return;
        }
    }

    void endRequest()
        throws SQLException
    {
        MNGR_REPLAY_LOGGER.log(Level.FINER, "Entering endRequest()");
        OracleConnection oracleconnection = (OracleConnection)connectionProxy.getDelegate();
        EnumSet enumset = oracleconnection.getTransactionState();
        MNGR_REPLAY_LOGGER.log(Level.FINER, "transaction state: {0}", enumset);
        if(enumset.contains(oracle.jdbc.internal.OracleConnection.TransactionState.TRANSACTION_STARTED) && !enumset.contains(oracle.jdbc.internal.OracleConnection.TransactionState.TRANSACTION_READONLY))
        {
            try
            {
                oracleconnection.rollback();
            }
            catch(SQLException sqlexception)
            {
                MNGR_REPLAY_LOGGER.log(Level.FINEST, "Rollback open transaction failed before throwing exception");
            }
            SQLException sqlexception1 = DatabaseError.createSqlException(392);
            MNGR_REPLAY_LOGGER.throwing(getClass().getName(), "endRequest", sqlexception1);
            throw sqlexception1;
        }
        if(lifecycle == ReplayLifecycle.ALWAYS_DISABLED)
        {
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Exiting endRequest() -- MONITOR_TXN failed");
            return;
        }
        if(lifecycle == ReplayLifecycle.INTERNALLY_DISABLED || lifecycle == ReplayLifecycle.EXTERNALLY_DISABLED)
        {
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Exiting endRequest() -- replay already disabled");
            lifecycle = ReplayLifecycle.INTERNALLY_DISABLED;
            return;
        } else
        {
            disableReplayInternal(null, 381, "Replay disabled after endRequest is called", null);
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Exiting endRequest()");
            return;
        }
    }

    void disableReplay()
        throws SQLException
    {
        MNGR_REPLAY_LOGGER.log(Level.FINER, "Entering disableReplay");
        if(lifecycle == ReplayLifecycle.ALWAYS_DISABLED)
        {
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Exiting disableReplay(), MONITOR_TXN failed, no-op");
            return;
        } else
        {
            disableReplayInternal(null, 370, "Replay disabled", null);
            lifecycle = ReplayLifecycle.EXTERNALLY_DISABLED;
            MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, replay is externally disabled", connectionProxy);
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Exiting disableReplay");
            return;
        }
    }

    void disableReplayInternal(Method method, int i, String s, SQLRecoverableException sqlrecoverableexception)
    {
        MNGR_REPLAY_LOGGER.log(Level.FINER, "Entering disableReplayInternal");
        ReplayLifecycle replaylifecycle = lifecycle;
        if(lifecycle != ReplayLifecycle.ALWAYS_DISABLED)
            lifecycle = ReplayLifecycle.INTERNALLY_DISABLED;
        purge();
        replayErrorCode = i;
        replayErrorMessage = s;
        callCausingReplayError = method;
        MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, replay is internally disabled", connectionProxy);
        MNGR_REPLAY_LOGGER.log(Level.FINER, "Exiting disableReplayInternal");
    }

    void failReplayInternal(Method method, int i, String s, SQLRecoverableException sqlrecoverableexception)
    {
        MNGR_REPLAY_LOGGER.log(Level.FINER, "Entering failReplayInternal");
        ReplayLifecycle replaylifecycle = lifecycle;
        if(lifecycle == ReplayLifecycle.REPLAYING || lifecycle == ReplayLifecycle.REPLAYING_CALLBACK || lifecycle == ReplayLifecycle.REPLAYING_LASTCALL)
            lifecycle = ReplayLifecycle.INTERNALLY_FAILED;
        replayErrorCode = i;
        replayErrorMessage = s;
        callCausingReplayError = method;
        MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, replay failed", connectionProxy);
        MNGR_REPLAY_LOGGER.log(Level.FINER, "Exiting failReplayInternal");
    }

    void throwReplayExceptionInternal(int i, String s, SQLRecoverableException sqlrecoverableexception)
        throws SQLException
    {
        if(i == 0)
        {
            return;
        } else
        {
            String s1 = callCausingReplayError != null ? callCausingReplayError.getName() : "";
            SQLException sqlexception = DatabaseError.createSqlException(replayErrorCode, s1);
            throw sqlexception;
        }
    }

    void disableReplayAndThrowException(Method method, int i, String s, SQLRecoverableException sqlrecoverableexception)
        throws SQLException
    {
        disableReplayInternal(method, i, s, sqlrecoverableexception);
        throwReplayExceptionInternal(i, s, sqlrecoverableexception);
    }

    void disableReplayAndThrowOriginalError(Method method, int i, String s, SQLRecoverableException sqlrecoverableexception)
        throws SQLException
    {
        disableReplayInternal(method, i, s, sqlrecoverableexception);
        throwOriginalExceptionWithReplayError(i, s, sqlrecoverableexception);
    }

    void failReplayAndThrowException(Method method, int i, String s, SQLRecoverableException sqlrecoverableexception)
        throws SQLException
    {
        failReplayInternal(method, i, s, sqlrecoverableexception);
        throwReplayExceptionInternal(i, s, sqlrecoverableexception);
    }

    void throwOriginalExceptionWithReplayError(int i, String s, SQLRecoverableException sqlrecoverableexception)
        throws SQLRecoverableException
    {
        if(!doNotAbortConn)
            killConnectionBeforeReplayDisabledException();
        String s1 = callCausingReplayError != null ? callCausingReplayError.getName() : "";
        SQLException sqlexception = DatabaseError.createSqlException(replayErrorCode, s1);
        sqlrecoverableexception.setNextException(sqlexception);
        throw sqlrecoverableexception;
    }

    void killConnectionBeforeReplayDisabledException()
    {
        final OracleConnection oconn = (OracleConnection)connectionProxy.getDelegate();
        try
        {
            oconn.abort();
        }
        catch(SQLException sqlexception)
        {
            MNGR_REPLAY_LOGGER.log(Level.FINE, "Aborting connection failed before throwing replay-disabled exception");
        }
        try
        {
            executor.submit(new Runnable() {

                final OracleConnection val$oconn;
                final FailoverManagerImpl this$0;

                public void run()
                {
                    closePhysicalConnection(oconn);
                }

            
            {
                this$0 = FailoverManagerImpl.this;
                oconn = oracleconnection;
                super();
            }
            }
);
        }
        catch(Exception exception)
        {
            MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, ASYNC close() submission during replay failed", connectionProxy);
        }
    }

    void enableTxnMonitoring(OracleConnection oracleconnection)
        throws SQLException
    {
        try
        {
            Statement statement = oracleconnection.createStatement();
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Calling MONITOR_TXN");
            statement.execute("BEGIN DBMS_APP_CONT_PRVT.MONITOR_TXN; END;");
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Calling MONITOR_TXN succeeded");
            statement.close();
        }
        catch(SQLException sqlexception)
        {
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Calling MONITOR_TXN failed");
            disableReplayInternal(null, 374, "Replay disabled because transaction monitoring failed to be enabled", null);
            lifecycle = ReplayLifecycle.ALWAYS_DISABLED;
            throw DatabaseError.createSqlException(394);
        }
    }

    void beginReplay(OracleConnection oracleconnection, SQLRecoverableException sqlrecoverableexception)
        throws SQLException
    {
        try
        {
            Statement statement = oracleconnection.createStatement();
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Calling BEGIN_REPLAY");
            statement.execute("BEGIN DBMS_APP_CONT_PRVT.BEGIN_REPLAY; END;");
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Calling BEGIN_REPLAY succeeded");
            statement.close();
            lifecycle = ReplayLifecycle.REPLAYING;
        }
        catch(SQLException sqlexception)
        {
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Calling BEGIN_REPLAY failed");
            disableReplayAndThrowException(null, 375, "Replay disabled because server begin_replay call failed", sqlrecoverableexception);
        }
    }

    void endReplay(OracleConnection oracleconnection, SQLRecoverableException sqlrecoverableexception)
        throws SQLException
    {
        try
        {
            Statement statement = oracleconnection.createStatement();
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Calling END_REPLAY");
            statement.execute("BEGIN DBMS_APP_CONT_PRVT.END_REPLAY; END;");
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Calling END_REPLAY succeeded");
            statement.close();
            lifecycle = ReplayLifecycle.REPLAYING_LASTCALL;
        }
        catch(SQLException sqlexception)
        {
            MNGR_REPLAY_LOGGER.log(Level.FINER, "Calling END_REPLAY failed");
            disableReplayAndThrowException(null, 376, "Replay disabled because server end_replay call failed", sqlrecoverableexception);
        }
    }

    Replayable getConnectionProxy()
    {
        return connectionProxy;
    }

    private boolean isReplayFailure(SQLException sqlexception)
    {
        boolean flag = false;
        if(sqlexception instanceof SQLException)
        {
            int i = sqlexception.getErrorCode();
            if(i >= 370 && i < 400)
                flag = true;
        }
        return flag;
    }

    private void closePhysicalConnection(Connection connection)
    {
        try
        {
            connection.close();
        }
        catch(SQLException sqlexception)
        {
            MNGR_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, connection close() during replay failed", connectionProxy);
        }
    }

    static 
    {
        MNGR_REPLAY_LOGGER = null;
        if(MNGR_REPLAY_LOGGER == null)
            MNGR_REPLAY_LOGGER = ReplayLoggerFactory.getLogger("oracle.jdbc.internal.replay.FailoverManagerImpl");
    }

}
