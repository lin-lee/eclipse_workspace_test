// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NonTxnReplayableBfile.java

package oracle.jdbc.replay.driver;

import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.logging.Logger;

// Referenced classes of package oracle.jdbc.replay.driver:
//            NonTxnReplayableBase, Replayable, ReplayLoggerFactory

public abstract class NonTxnReplayableBfile extends NonTxnReplayableBase
    implements Replayable
{

    private static final String BFILE_FEATURE_LOGGER_NAME = "oracle.jdbc.internal.replay.NonTxnReplayableBfile";
    private static Logger BFILE_REPLAY_LOGGER;

    public NonTxnReplayableBfile()
    {
    }

    protected transient void preForAll(Method method, Object obj, Object aobj[])
    {
        super.preForAll(method, obj, aobj);
    }

    protected Object postForAll(Method method, Object obj)
    {
        if(obj instanceof NonTxnReplayableBase)
        {
            NonTxnReplayableBase nontxnreplayablebase = (NonTxnReplayableBase)obj;
            nontxnreplayablebase.setFailoverManager(getFailoverManager());
        }
        return super.postForAll(method, obj);
    }

    protected void onErrorVoidForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        super.onErrorVoidForAll(method, sqlexception);
    }

    protected Object onErrorForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        return super.onErrorForAll(method, sqlexception);
    }

    protected abstract Object getDelegate();

    protected abstract void setDelegate(Object obj);

    protected abstract Object getCreator();

    static 
    {
        BFILE_REPLAY_LOGGER = null;
        if(BFILE_REPLAY_LOGGER == null)
            BFILE_REPLAY_LOGGER = ReplayLoggerFactory.getLogger("oracle.jdbc.internal.replay.NonTxnReplayableBfile");
    }
}
