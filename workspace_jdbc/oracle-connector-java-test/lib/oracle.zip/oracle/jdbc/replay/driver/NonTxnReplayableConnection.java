// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NonTxnReplayableConnection.java

package oracle.jdbc.replay.driver;

import java.lang.reflect.Method;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.EnumSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleSavepoint;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.replay.OracleDataSource;
import oracle.jdbc.replay.internal.ReplayableConnection;
import oracle.sql.ARRAY;

// Referenced classes of package oracle.jdbc.replay.driver:
//            NonTxnReplayableBase, FailoverManagerImpl, Replayable, ReplayLoggerFactory

public abstract class NonTxnReplayableConnection extends NonTxnReplayableBase
    implements Replayable, ReplayableConnection
{

    private static final String CONN_FEATURE_LOGGER_NAME = "oracle.jdbc.internal.replay.NonTxnReplayableConnection";
    private static Logger CONN_REPLAY_LOGGER;

    public NonTxnReplayableConnection()
    {
    }

    protected transient void preForAll(Method method, Object obj, Object aobj[])
    {
        super.preForAll(method, obj, aobj);
    }

    protected transient void preForTxnControl(Method method, Object obj, Object aobj[])
    {
        String s;
        boolean flag;
        FailoverManagerImpl.ReplayLifecycle replaylifecycle = failoverMngr.getReplayLifecycle();
        if(replaylifecycle != FailoverManagerImpl.ReplayLifecycle.ENABLED_NOT_REPLAYING)
            return;
        s = method != null ? method.getName() : "NULL METHOD";
        CONN_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, entering preForTxnControl({1})", new Object[] {
            this, s
        });
        if(failoverMngr == null)
            break MISSING_BLOCK_LABEL_269;
        flag = false;
        OracleConnection oracleconnection = (OracleConnection)getDelegate();
        EnumSet enumset = oracleconnection.getTransactionState();
        CONN_REPLAY_LOGGER.log(Level.FINEST, "On connection {0}, method {1}, transaction state: {2}", new Object[] {
            this, s, enumset
        });
        if(enumset.contains(oracle.jdbc.internal.OracleConnection.TransactionState.TRANSACTION_STARTED) && !enumset.contains(oracle.jdbc.internal.OracleConnection.TransactionState.TRANSACTION_READONLY))
            flag = true;
        if(flag)
            failoverMngr.disableReplayInternal(method, 371, "Replay disabled because of active transaction", null);
        else
            super.preForAll(method, obj, aobj);
        break MISSING_BLOCK_LABEL_281;
        SQLException sqlexception;
        sqlexception;
        CONN_REPLAY_LOGGER.log(Level.WARNING, "On connection {0}, could not get transaction state: {1}", new Object[] {
            this, sqlexception
        });
        flag = true;
        if(flag)
            failoverMngr.disableReplayInternal(method, 371, "Replay disabled because of active transaction", null);
        else
            super.preForAll(method, obj, aobj);
        break MISSING_BLOCK_LABEL_281;
        Exception exception;
        exception;
        if(flag)
            failoverMngr.disableReplayInternal(method, 371, "Replay disabled because of active transaction", null);
        else
            super.preForAll(method, obj, aobj);
        throw exception;
        CONN_REPLAY_LOGGER.log(Level.SEVERE, "On connection {0}, failover manager not set", this);
        CONN_REPLAY_LOGGER.log(Level.FINER, "On connection {0}, exiting preForTxnControl()", this);
        return;
    }

    protected transient void preForClosure(Method method, Object obj, Object aobj[])
    {
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, preForClosure({1})", new Object[] {
            this, method.getName()
        });
        isClosedAndNoReplay = true;
    }

    protected transient void preForCancel(Method method, Object obj, Object aobj[])
    {
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, preForCancel({1})", new Object[] {
            this, method.getName()
        });
    }

    protected void postForAll(Method method)
    {
        postForAll(method, null);
    }

    protected Object postForAll(Method method, Object obj)
    {
        return super.postForAll(method, obj);
    }

    protected void postForClosure(Method method)
    {
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, postForClosure({1})", new Object[] {
            this, method.getName()
        });
    }

    protected void postForCancel(Method method)
    {
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, postForCancel({1})", new Object[] {
            this, method.getName()
        });
    }

    protected void onErrorVoidForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        super.onErrorVoidForAll(method, sqlexception);
    }

    protected Object onErrorForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        return super.onErrorForAll(method, sqlexception);
    }

    protected abstract Object getDelegate();

    protected abstract void setDelegate(Object obj);

    protected abstract Object getCreator();

    public void setReplayInitiationTimeout(int i)
        throws SQLException
    {
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, entering setReplayInitiationTimeout({1})", new Object[] {
            this, Integer.valueOf(i)
        });
        failoverMngr.setReplayInitiationTimeout(i);
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, exiting setReplayInitiationTimeout({1})", new Object[] {
            this, Integer.valueOf(i)
        });
    }

    public void initialize(OracleDataSource oracledatasource)
        throws SQLException
    {
        FailoverManagerImpl failovermanagerimpl = (FailoverManagerImpl)FailoverManagerImpl.getFailoverManager(this, oracledatasource);
        setFailoverManager(failovermanagerimpl);
    }

    public void beginRequest()
        throws SQLException
    {
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, entering beginRequest()", this);
        failoverMngr.beginRequest();
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, exiting beginRequest()", this);
    }

    public void endRequest()
        throws SQLException
    {
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, entering endRequest()", this);
        failoverMngr.endRequest();
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, exiting endRequest()", this);
    }

    public void disableReplay()
        throws SQLException
    {
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, entering disableReplay()", this);
        failoverMngr.disableReplay();
        CONN_REPLAY_LOGGER.log(Level.FINE, "On connection {0}, exiting disableReplay()", this);
    }

    public ARRAY createARRAY(String s, Object obj)
        throws SQLException
    {
        Object aobj[];
        if(obj != null && (obj instanceof Object[]))
        {
            Object aobj1[] = (Object[])(Object[])obj;
            if(aobj1.length > 0)
            {
                Object aobj2[] = new Object[aobj1.length];
                int i = 0;
                Object aobj3[] = aobj1;
                int j = aobj3.length;
                for(int k = 0; k < j; k++)
                {
                    Object obj1 = aobj3[k];
                    if(obj1 instanceof NonTxnReplayableBase)
                        aobj2[i++] = ((NonTxnReplayableBase)obj1).getDelegate();
                    else
                        aobj2[i++] = obj1;
                }

                aobj = aobj2;
            } else
            {
                aobj = ((Object []) (obj));
            }
        } else
        {
            aobj = ((Object []) (obj));
        }
        Method method = null;
        try
        {
            method = oracle/jdbc/internal/OracleConnection.getMethod("createARRAY", new Class[] {
                java/lang/String, java/lang/Object
            });
        }
        catch(Exception exception)
        {
            throw DatabaseError.createSqlException(1, "Cannot create ARRAY instance");
        }
        preForAll(method, this, new Object[] {
            s, aobj
        });
        try
        {
            OracleConnection oracleconnection = (OracleConnection)getDelegate();
            ARRAY array = oracleconnection.createARRAY(s, ((Object) (aobj)));
            return (ARRAY)postForAll(method, array);
        }
        catch(SQLException sqlexception)
        {
            return (ARRAY)postForAll(method, onErrorForAll(method, sqlexception));
        }
    }

    public Array createOracleArray(String s, Object obj)
        throws SQLException
    {
        return createARRAY(s, obj);
    }

    public Array createArrayOf(String s, Object aobj[])
        throws SQLException
    {
        Object aobj1[];
        if(aobj != null && aobj.length > 0)
        {
            aobj1 = new Object[aobj.length];
            int i = 0;
            Object aobj2[] = aobj;
            int j = aobj2.length;
            for(int k = 0; k < j; k++)
            {
                Object obj = aobj2[k];
                if(obj instanceof NonTxnReplayableBase)
                    aobj1[i++] = ((NonTxnReplayableBase)obj).getDelegate();
                else
                    aobj1[i++] = obj;
            }

        } else
        {
            aobj1 = aobj;
        }
        Method method = null;
        try
        {
            method = java/sql/Connection.getDeclaredMethod("createArrayOf", new Class[] {
                java/lang/String, [Ljava/lang/Object;
            });
        }
        catch(Exception exception)
        {
            throw DatabaseError.createSqlException(1, "Cannot create Array instance");
        }
        preForAll(method, this, new Object[] {
            s, aobj1
        });
        try
        {
            Connection connection = (Connection)getDelegate();
            Array array = connection.createArrayOf(s, aobj1);
            return (Array)postForAll(method, array);
        }
        catch(SQLException sqlexception)
        {
            return (Array)postForAll(method, onErrorForAll(method, sqlexception));
        }
    }

    public Struct createStruct(String s, Object aobj[])
        throws SQLException
    {
        Object aobj1[];
        if(aobj != null && aobj.length > 0)
        {
            aobj1 = new Object[aobj.length];
            int i = 0;
            Object aobj2[] = aobj;
            int j = aobj2.length;
            for(int k = 0; k < j; k++)
            {
                Object obj = aobj2[k];
                if(obj instanceof NonTxnReplayableBase)
                    aobj1[i++] = ((NonTxnReplayableBase)obj).getDelegate();
                else
                    aobj1[i++] = obj;
            }

        } else
        {
            aobj1 = aobj;
        }
        Method method = null;
        try
        {
            method = java/sql/Connection.getDeclaredMethod("createStruct", new Class[] {
                java/lang/String, [Ljava/lang/Object;
            });
        }
        catch(Exception exception)
        {
            throw DatabaseError.createSqlException(1, "Cannot create Struct instance");
        }
        preForAll(method, this, new Object[] {
            s, aobj1
        });
        try
        {
            Connection connection = (Connection)getDelegate();
            Struct struct = connection.createStruct(s, aobj1);
            return (Struct)postForAll(method, struct);
        }
        catch(SQLException sqlexception)
        {
            return (Struct)postForAll(method, onErrorForAll(method, sqlexception));
        }
    }

    public abstract Blob createBlob()
        throws SQLException;

    public abstract Clob createClob()
        throws SQLException;

    public abstract NClob createNClob()
        throws SQLException;

    public abstract SQLXML createSQLXML()
        throws SQLException;

    public abstract Statement createStatement()
        throws SQLException;

    public abstract Statement createStatement(int i, int j)
        throws SQLException;

    public abstract Statement createStatement(int i, int j, int k)
        throws SQLException;

    public abstract CallableStatement prepareCall(String s)
        throws SQLException;

    public abstract CallableStatement prepareCall(String s, int i, int j)
        throws SQLException;

    public abstract CallableStatement prepareCall(String s, int i, int j, int k)
        throws SQLException;

    public abstract PreparedStatement prepareStatement(String s)
        throws SQLException;

    public abstract PreparedStatement prepareStatement(String s, int i)
        throws SQLException;

    public abstract PreparedStatement prepareStatement(String s, int ai[])
        throws SQLException;

    public abstract PreparedStatement prepareStatement(String s, int i, int j)
        throws SQLException;

    public abstract PreparedStatement prepareStatement(String s, int i, int j, int k)
        throws SQLException;

    public abstract PreparedStatement prepareStatement(String s, String as[])
        throws SQLException;

    public abstract Savepoint setSavepoint()
        throws SQLException;

    public abstract Savepoint setSavepoint(String s)
        throws SQLException;

    public Object unwrap(Class class1)
        throws SQLException
    {
        return getDelegate();
    }

    public abstract Connection _getPC();

    public abstract OracleSavepoint oracleSetSavepoint()
        throws SQLException;

    public abstract OracleSavepoint oracleSetSavepoint(String s)
        throws SQLException;

    public oracle.jdbc.OracleConnection unwrap()
    {
        return ((OracleConnection)getDelegate()).unwrap();
    }

    static 
    {
        CONN_REPLAY_LOGGER = null;
        if(CONN_REPLAY_LOGGER == null)
            CONN_REPLAY_LOGGER = ReplayLoggerFactory.getLogger("oracle.jdbc.internal.replay.NonTxnReplayableConnection");
    }
}
