// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NonTxnReplayableBase.java

package oracle.jdbc.replay.driver;

import java.lang.reflect.*;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleTypeMetaData;
import oracle.jdbc.replay.ReplayableConnection;

// Referenced classes of package oracle.jdbc.replay.driver:
//            Replayable, FailoverManagerImpl, ReplayLoggerFactory

public abstract class NonTxnReplayableBase
    implements Replayable, InvocationHandler
{

    private static final String BASE_FEATURE_LOGGER_NAME = "oracle.jdbc.internal.replay.NonTxnReplayableBase";
    private static Logger BASE_REPLAY_LOGGER;
    protected FailoverManagerImpl failoverMngr;
    protected FailoverManagerImpl.CallHistoryEntry headSameProxy;
    protected FailoverManagerImpl.CallHistoryEntry tailSameProxy;
    protected FailoverManagerImpl.CallHistoryEntry replayingCallEntry;
    protected SQLRecoverableException originalError;
    protected static final int SVR_TXN_IN_REPLAY_ERROR_CODE1 = 603;
    protected static final int SVR_TXN_IN_REPLAY_ERROR_CODE2 = 29791;
    protected boolean isClosedAndNoReplay;

    public NonTxnReplayableBase()
    {
        headSameProxy = null;
        tailSameProxy = null;
        replayingCallEntry = null;
        originalError = null;
        isClosedAndNoReplay = false;
    }

    protected transient void preForAll(Method method, Object obj, Object aobj[])
    {
        FailoverManagerImpl.ReplayLifecycle replaylifecycle = failoverMngr.getReplayLifecycle();
        static class _cls1
        {

            static final int $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[];

            static 
            {
                $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle = new int[FailoverManagerImpl.ReplayLifecycle.values().length];
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[FailoverManagerImpl.ReplayLifecycle.ENABLED_NOT_REPLAYING.ordinal()] = 1;
                }
                catch(NoSuchFieldError nosuchfielderror) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[FailoverManagerImpl.ReplayLifecycle.INTERNALLY_FAILED.ordinal()] = 2;
                }
                catch(NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[FailoverManagerImpl.ReplayLifecycle.ALWAYS_DISABLED.ordinal()] = 3;
                }
                catch(NoSuchFieldError nosuchfielderror2) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[FailoverManagerImpl.ReplayLifecycle.INTERNALLY_DISABLED.ordinal()] = 4;
                }
                catch(NoSuchFieldError nosuchfielderror3) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[FailoverManagerImpl.ReplayLifecycle.EXTERNALLY_DISABLED.ordinal()] = 5;
                }
                catch(NoSuchFieldError nosuchfielderror4) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[FailoverManagerImpl.ReplayLifecycle.REPLAYING.ordinal()] = 6;
                }
                catch(NoSuchFieldError nosuchfielderror5) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[FailoverManagerImpl.ReplayLifecycle.REPLAYING_CALLBACK.ordinal()] = 7;
                }
                catch(NoSuchFieldError nosuchfielderror6) { }
                try
                {
                    $SwitchMap$oracle$jdbc$replay$driver$FailoverManagerImpl$ReplayLifecycle[FailoverManagerImpl.ReplayLifecycle.REPLAYING_LASTCALL.ordinal()] = 8;
                }
                catch(NoSuchFieldError nosuchfielderror7) { }
            }
        }

        switch(_cls1..SwitchMap.oracle.jdbc.replay.driver.FailoverManagerImpl.ReplayLifecycle[replaylifecycle.ordinal()])
        {
        case 1: // '\001'
            failoverMngr.record(this, method, aobj, "started");
            // fall through

        case 2: // '\002'
        case 3: // '\003'
        case 4: // '\004'
        case 5: // '\005'
        case 6: // '\006'
        case 7: // '\007'
        case 8: // '\b'
        default:
            return;
        }
    }

    protected void postForAll(Method method)
    {
        postForAll(method, null);
    }

    protected Object postForAll(Method method, Object obj)
    {
        if(obj instanceof NonTxnReplayableBase)
        {
            NonTxnReplayableBase nontxnreplayablebase = (NonTxnReplayableBase)obj;
            nontxnreplayablebase.setFailoverManager(getFailoverManager());
        }
        FailoverManagerImpl.ReplayLifecycle replaylifecycle = failoverMngr.getReplayLifecycle();
        switch(_cls1..SwitchMap.oracle.jdbc.replay.driver.FailoverManagerImpl.ReplayLifecycle[replaylifecycle.ordinal()])
        {
        case 1: // '\001'
        case 8: // '\b'
            doPostWhenRecording(method, obj, null);
            break;

        case 6: // '\006'
            doPostWhenReplaying(method, obj, null);
            break;
        }
        return obj;
    }

    protected void doPostWhenRecording(Method method, Object obj, SQLException sqlexception)
    {
        failoverMngr.update(this, null, obj, "completed", 0L, -1L, sqlexception);
    }

    protected void doPostWhenReplaying(Method method, Object obj, SQLException sqlexception)
    {
    }

    protected void onErrorVoidForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        onErrorForAll(method, sqlexception);
    }

    protected Object onErrorForAll(Method method, SQLException sqlexception)
        throws SQLException
    {
        if(isClosedAndNoReplay)
            throw sqlexception;
        if(sqlexception instanceof SQLRecoverableException)
        {
            FailoverManagerImpl.ReplayLifecycle replaylifecycle = failoverMngr.getReplayLifecycle();
            switch(_cls1..SwitchMap.oracle.jdbc.replay.driver.FailoverManagerImpl.ReplayLifecycle[replaylifecycle.ordinal()])
            {
            case 1: // '\001'
            case 3: // '\003'
            case 4: // '\004'
            case 5: // '\005'
                return failoverMngr.replayAll((SQLRecoverableException)sqlexception);

            case 2: // '\002'
            case 6: // '\006'
            case 7: // '\007'
            case 8: // '\b'
            default:
                throw sqlexception;
            }
        }
        FailoverManagerImpl.ReplayLifecycle replaylifecycle1 = failoverMngr.getReplayLifecycle();
        switch(_cls1..SwitchMap.oracle.jdbc.replay.driver.FailoverManagerImpl.ReplayLifecycle[replaylifecycle1.ordinal()])
        {
        case 1: // '\001'
        case 8: // '\b'
            doPostWhenRecording(method, null, sqlexception);
            // fall through

        case 2: // '\002'
        case 3: // '\003'
        case 4: // '\004'
        case 5: // '\005'
        case 6: // '\006'
        case 7: // '\007'
        default:
            throw sqlexception;
        }
    }

    protected abstract Object getDelegate();

    protected abstract void setDelegate(Object obj);

    protected abstract Object getCreator();

    public void fillInChecksum(FailoverManagerImpl.CallHistoryEntry callhistoryentry)
        throws SQLException
    {
    }

    public Object replayOneCall(FailoverManagerImpl.CallHistoryEntry callhistoryentry, SQLRecoverableException sqlrecoverableexception)
        throws SQLException
    {
        Object obj = null;
        try
        {
            ((Replayable)callhistoryentry.jdbcProxy).setReplayingCallContext(callhistoryentry, sqlrecoverableexception);
            Object obj1 = callhistoryentry.method.invoke(callhistoryentry.jdbcProxy, callhistoryentry.args);
            obj = obj1;
            if(obj1 instanceof NonTxnReplayableBase)
            {
                FailoverManagerImpl.ReplayLifecycle replaylifecycle1 = failoverMngr.getReplayLifecycle();
                if(replaylifecycle1 == FailoverManagerImpl.ReplayLifecycle.REPLAYING && obj1 != null && callhistoryentry.result != null)
                {
                    Object obj2 = ((NonTxnReplayableBase)obj1).getDelegate();
                    ((NonTxnReplayableBase)callhistoryentry.result).setDelegate(obj2);
                    obj = callhistoryentry.result;
                }
            }
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            Throwable throwable1 = invocationtargetexception.getCause();
            BASE_REPLAY_LOGGER.log(Level.FINEST, "On {0}, replaying {1} got InvocationTargetException with cause: {2}", new Object[] {
                callhistoryentry.jdbcProxy, callhistoryentry.method, throwable1
            });
            if(throwable1 instanceof SQLRecoverableException)
            {
                SQLRecoverableException sqlrecoverableexception1 = (SQLRecoverableException)throwable1;
                throw sqlrecoverableexception1;
            }
            if(throwable1 instanceof SQLException)
            {
                SQLException sqlexception = (SQLException)throwable1;
                int i = sqlexception.getErrorCode();
                if(i == 29791)
                {
                    BASE_REPLAY_LOGGER.log(Level.WARNING, "On {0}, replaying {1} receives ORA-29791", new Object[] {
                        callhistoryentry.jdbcProxy, callhistoryentry.method
                    });
                    failoverMngr.disableReplayAndThrowException(callhistoryentry.method, 388, "Replay failed because of active transaction during replay", sqlrecoverableexception);
                } else
                if(callhistoryentry.callException == null || i != callhistoryentry.callException.getErrorCode())
                    failoverMngr.disableReplayAndThrowException(callhistoryentry.method, 387, "Replay failed because of error code or message mismatch", sqlrecoverableexception);
            } else
            {
                failoverMngr.disableReplayAndThrowException(callhistoryentry.method, 370, "Replay disabled", sqlrecoverableexception);
            }
        }
        catch(Throwable throwable)
        {
            BASE_REPLAY_LOGGER.log(Level.FINEST, "On {0}, replaying {1} caught throwable: {2}", new Object[] {
                callhistoryentry.jdbcProxy, callhistoryentry.method, throwable
            });
            throwable.printStackTrace();
            failoverMngr.disableReplayAndThrowException(callhistoryentry.method, 370, "Replay disabled", sqlrecoverableexception);
        }
        FailoverManagerImpl.ReplayLifecycle replaylifecycle = failoverMngr.getReplayLifecycle();
        switch(_cls1..SwitchMap.oracle.jdbc.replay.driver.FailoverManagerImpl.ReplayLifecycle[replaylifecycle.ordinal()])
        {
        case 2: // '\002'
        case 4: // '\004'
            failoverMngr.throwReplayExceptionInternal(0, null, null);
            break;
        }
        return obj;
    }

    public void addToSameProxyList(FailoverManagerImpl.CallHistoryEntry callhistoryentry)
    {
        callhistoryentry.prevEntrySameProxy = tailSameProxy;
        callhistoryentry.nextEntrySameProxy = null;
        if(tailSameProxy != null)
            tailSameProxy.nextEntrySameProxy = callhistoryentry;
        tailSameProxy = callhistoryentry;
        if(headSameProxy == null)
            headSameProxy = callhistoryentry;
    }

    public void removeFromSameProxyList(FailoverManagerImpl.CallHistoryEntry callhistoryentry)
    {
        if(callhistoryentry.nextEntrySameProxy != null)
            callhistoryentry.nextEntrySameProxy.prevEntrySameProxy = callhistoryentry.prevEntrySameProxy;
        if(callhistoryentry.prevEntrySameProxy != null)
            callhistoryentry.prevEntrySameProxy.nextEntrySameProxy = callhistoryentry.nextEntrySameProxy;
        if(headSameProxy == callhistoryentry)
            headSameProxy = callhistoryentry.nextEntrySameProxy;
        if(tailSameProxy == callhistoryentry)
            tailSameProxy = callhistoryentry.prevEntrySameProxy;
    }

    public void purgeSameProxyList()
    {
        if(failoverMngr != null)
        {
            HashSet hashset = new HashSet();
            for(Object obj = this; obj != null && (obj instanceof NonTxnReplayableBase) && !(obj instanceof ReplayableConnection); obj = ((NonTxnReplayableBase)obj).getCreator())
                hashset.add(obj);

            failoverMngr.purgeForSameProxy(hashset, headSameProxy);
        }
    }

    public void setReplayingCallContext(FailoverManagerImpl.CallHistoryEntry callhistoryentry, SQLRecoverableException sqlrecoverableexception)
    {
        replayingCallEntry = callhistoryentry;
        originalError = sqlrecoverableexception;
    }

    public synchronized void setFailoverManager(FailoverManagerImpl failovermanagerimpl)
    {
        failoverMngr = failovermanagerimpl;
    }

    public synchronized FailoverManagerImpl getFailoverManager()
    {
        return failoverMngr;
    }

    private boolean isReplayFailure(Throwable throwable)
    {
        boolean flag = false;
        if(throwable instanceof SQLException)
        {
            int i = ((SQLException)throwable).getErrorCode();
            if(i >= 370 && i < 400)
                flag = true;
        }
        return flag;
    }

    protected boolean assertThrowablesMatch(Throwable throwable, Throwable throwable1)
    {
        boolean flag = throwable1 != null ? throwable.getClass().getName().equals(throwable1.getClass().getName()) : false;
        BASE_REPLAY_LOGGER.log(Level.FINEST, "Errors at original execution and replay are of same type: {0}", Boolean.valueOf(flag));
        boolean flag1;
        if((throwable instanceof SQLException) && flag)
        {
            flag1 = ((SQLException)throwable).getErrorCode() == ((SQLException)throwable1).getErrorCode();
            BASE_REPLAY_LOGGER.log(Level.FINEST, "Errors at original execution and replay are SQLException, error codes match: {0}", Boolean.valueOf(flag1));
        } else
        if(flag)
        {
            String s = throwable.getMessage();
            String s1 = throwable1.getMessage();
            flag1 = s == null && s1 == null || s != null && s1 != null && throwable.getMessage().equals(throwable1.getMessage());
            BASE_REPLAY_LOGGER.log(Level.FINEST, "Errors at original execution and replay are same type but not SQLException, error messages match: {0}", Boolean.valueOf(flag1));
        } else
        {
            flag1 = false;
        }
        BASE_REPLAY_LOGGER.log(Level.FINEST, "Errors at original execution and replay match: {0}", Boolean.valueOf(flag1));
        return flag1;
    }

    static 
    {
        BASE_REPLAY_LOGGER = null;
        if(BASE_REPLAY_LOGGER == null)
            BASE_REPLAY_LOGGER = ReplayLoggerFactory.getLogger("oracle.jdbc.internal.replay.NonTxnReplayableBase");
    }
}
