// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDataSourceImpl.java

package oracle.jdbc.replay;

import java.io.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.*;
import javax.naming.spi.ObjectFactory;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.pool.OracleDataSource;
import oracle.jdbc.proxy.ProxyFactory;
import oracle.jdbc.replay.driver.NonTxnReplayableArray;
import oracle.jdbc.replay.driver.NonTxnReplayableBase;
import oracle.jdbc.replay.driver.NonTxnReplayableBfile;
import oracle.jdbc.replay.driver.NonTxnReplayableBlob;
import oracle.jdbc.replay.driver.NonTxnReplayableClob;
import oracle.jdbc.replay.driver.NonTxnReplayableConnection;
import oracle.jdbc.replay.driver.NonTxnReplayableNClob;
import oracle.jdbc.replay.driver.NonTxnReplayableOpaque;
import oracle.jdbc.replay.driver.NonTxnReplayableOthers;
import oracle.jdbc.replay.driver.NonTxnReplayableRef;
import oracle.jdbc.replay.driver.NonTxnReplayableResultSet;
import oracle.jdbc.replay.driver.NonTxnReplayableStatement;
import oracle.jdbc.replay.driver.NonTxnReplayableStruct;
import oracle.jdbc.replay.driver.ReplayLoggerFactory;
import oracle.jdbc.replay.internal.ConnectionInitializationCallback;
import oracle.jdbc.replay.internal.ReplayableConnection;

// Referenced classes of package oracle.jdbc.replay:
//            OracleDataSource

public class OracleDataSourceImpl
    implements oracle.jdbc.replay.OracleDataSource, Serializable, Referenceable, ObjectFactory
{

    private static final long serialVersionUID = 0x4e30afd65eb25b20L;
    private static final String FEATURE_LOGGER_NAME = "oracle.jdbc.internal.replay.OracleDataSourceImpl";
    private static final Logger RDS_LOGGER = ReplayLoggerFactory.getLogger("oracle.jdbc.internal.replay.OracleDataSourceImpl");
    private static ProxyFactory PROXY_FACTORY;
    private String user;
    private String password;
    private String url;
    private String serverName;
    private int portNumber;
    private String databaseName;
    private String dataSourceName;
    private String description;
    private String networkProtocol;
    private String roleName;
    private final Properties connectionProperties = new Properties();
    private int maxStatements;
    private boolean implicitCachingEnabled;
    private boolean explicitCachingEnabled;
    private ConnectionInitializationCallback connectionInitializationCallback;
    private AtomicBoolean isFirstConnection;
    private static final String RECONNECT_DELAY_PROPERTY = "AUTH_FAILOVER_DELAY";
    private static final String RECONNECT_RETRIES_PROPERTY = "AUTH_FAILOVER_RETRIES";
    private int reconnectDelay;
    private int reconnectRetries;
    private static final String CHECKSUM_PROPERTY = "oracle.jdbc.calculateChecksum";

    public OracleDataSourceImpl()
    {
        user = null;
        password = null;
        url = null;
        serverName = null;
        portNumber = 0;
        databaseName = null;
        dataSourceName = null;
        description = null;
        networkProtocol = null;
        roleName = null;
        maxStatements = 0;
        implicitCachingEnabled = false;
        explicitCachingEnabled = false;
        connectionInitializationCallback = null;
        isFirstConnection = new AtomicBoolean(true);
        reconnectDelay = 10;
        reconnectRetries = 18;
    }

    public Connection getConnection()
        throws SQLException
    {
        return getConnection(user, password);
    }

    public Connection getConnection(String s, String s1)
        throws SQLException
    {
        return getConnectionInternal(s, s1, true);
    }

    public Connection getConnectionNoProxy()
        throws SQLException
    {
        int i;
        Connection connection;
        Object obj;
        i = 1;
        connection = null;
        obj = null;
_L2:
        if(reconnectDelay > 0)
        {
            RDS_LOGGER.log(Level.FINER, "Reconnecting: DELAY for {0} seconds", Integer.valueOf(reconnectDelay));
            Thread.sleep(reconnectDelay * 1000);
        }
        RDS_LOGGER.log(Level.FINER, "Reconnecting: RETRY {0}", Integer.valueOf(i));
        obj = null;
        connection = getConnectionInternal(user, password, false);
        if(connection != null && obj == null)
            return connection;
        i++;
        continue; /* Loop/switch isn't completed */
        Object obj1;
        obj1;
        connection = null;
        obj = obj1;
        RDS_LOGGER.log(Level.FINER, "Reconnect threw exception during DELAY: {0}", ((Throwable) (obj1)));
        if(connection != null && obj == null)
            return connection;
        i++;
        continue; /* Loop/switch isn't completed */
        obj1;
        connection = null;
        obj = obj1;
        RDS_LOGGER.log(Level.FINER, "Reconnect FAILED, exception: {0}", ((Throwable) (obj1)));
        if(connection != null && obj == null)
            return connection;
        i++;
        continue; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        if(connection != null && obj == null)
        {
            return connection;
        } else
        {
            i++;
            throw exception;
        }
        if(i <= reconnectRetries) goto _L2; else goto _L1
_L1:
        return null;
    }

    private Connection getConnectionInternal(String s, String s1, boolean flag)
        throws SQLException
    {
        Connection connection = null;
        OracleDataSource oracledatasource = new OracleDataSource();
        oracledatasource.setUser(s);
        oracledatasource.setPassword(s1);
        oracledatasource.setURL(getURL());
        setConnectionProperty("oracle.jdbc.calculateChecksum", "true");
        oracledatasource.setConnectionProperties(getConnectionProperties());
        oracledatasource.setMaxStatements(getMaxStatements());
        oracledatasource.setImplicitCachingEnabled(getImplicitCachingEnabled());
        oracledatasource.setExplicitCachingEnabled(getExplicitCachingEnabled());
        connection = oracledatasource.getConnection();
        if(isFirstConnection.get())
        {
            OracleConnection oracleconnection = (OracleConnection)connection;
            Properties properties = oracleconnection.getServerSessionInfo();
            String s2 = properties.getProperty("AUTH_FAILOVER_DELAY");
            if(s2 != null && !"".equals(s2))
            {
                int i = Integer.parseInt(s2);
                if(i > 0)
                    reconnectDelay = i;
                else
                    RDS_LOGGER.log(Level.WARNING, "Server FAILOVER_DELAY: {0}, use driver default {1} seconds instead", new Object[] {
                        Integer.valueOf(i), Integer.valueOf(10)
                    });
            }
            String s3 = properties.getProperty("AUTH_FAILOVER_RETRIES");
            if(s3 != null && !"".equals(s3))
            {
                int j = Integer.parseInt(s3);
                if(j > 0)
                    reconnectRetries = j;
                else
                    RDS_LOGGER.log(Level.WARNING, "Server FAILOVER_RETRIES: {0}, use driver default {1} instead", new Object[] {
                        Integer.valueOf(j), Integer.valueOf(18)
                    });
            }
            short word0 = oracleconnection.getVersionNumber();
            if(word0 < 11203)
                throw DatabaseError.createSqlException(393);
            isFirstConnection.set(false);
        }
        if(flag)
        {
            Connection connection1 = (Connection)PROXY_FACTORY.proxyFor(connection);
            ReplayableConnection replayableconnection = (ReplayableConnection)connection1;
            replayableconnection.initialize(this);
            return connection1;
        } else
        {
            return connection;
        }
    }

    public PrintWriter getLogWriter()
        throws SQLException
    {
        return null;
    }

    public void setLogWriter(PrintWriter printwriter)
        throws SQLException
    {
    }

    public void setLoginTimeout(int i)
        throws SQLException
    {
    }

    public int getLoginTimeout()
        throws SQLException
    {
        return 0;
    }

    public String getUser()
    {
        return user;
    }

    public void setUser(String s)
        throws SQLException
    {
        RDS_LOGGER.log(Level.FINEST, "user: {0}", s);
        user = s;
    }

    public void setPassword(String s)
        throws SQLException
    {
        password = s;
    }

    public String getURL()
    {
        return url;
    }

    public void setURL(String s)
        throws SQLException
    {
        RDS_LOGGER.log(Level.FINEST, "URL: {0}", s);
        url = s;
    }

    public void setServerName(String s)
        throws SQLException
    {
        RDS_LOGGER.log(Level.FINEST, "Server Name: {0}", s);
        serverName = s;
    }

    public String getServerName()
    {
        return serverName;
    }

    public void setPortNumber(int i)
        throws SQLException
    {
        RDS_LOGGER.log(Level.FINEST, "Port Number: {0}", Integer.valueOf(i));
        portNumber = i;
    }

    public int getPortNumber()
    {
        return portNumber;
    }

    public void setDatabaseName(String s)
        throws SQLException
    {
        RDS_LOGGER.log(Level.FINEST, "Database Name : {0}", s);
        databaseName = s;
    }

    public String getDatabaseName()
    {
        return databaseName;
    }

    public void setDataSourceName(String s)
        throws SQLException
    {
        RDS_LOGGER.log(Level.FINEST, "DataSourceName : {0}", s);
        dataSourceName = s;
    }

    public String getDataSourceName()
    {
        return dataSourceName;
    }

    public void setDescription(String s)
        throws SQLException
    {
        RDS_LOGGER.log(Level.FINEST, "Description : {0}", s);
        description = s;
    }

    public String getDescription()
    {
        return description;
    }

    public void setNetworkProtocol(String s)
        throws SQLException
    {
        RDS_LOGGER.log(Level.FINEST, "networkProtocol : {0}", s);
        networkProtocol = s;
    }

    public String getNetworkProtocol()
    {
        return networkProtocol;
    }

    public void setRoleName(String s)
        throws SQLException
    {
        RDS_LOGGER.log(Level.FINEST, "RoleName : {0}", s);
        roleName = s;
    }

    public String getRoleName()
    {
        return roleName;
    }

    public void registerConnectionInitializationCallback(ConnectionInitializationCallback connectioninitializationcallback)
        throws SQLException
    {
        RDS_LOGGER.finest("Connection Initialization Callback registered");
        if(connectioninitializationcallback == null)
        {
            throw new NullPointerException("callback has to be non-null");
        } else
        {
            connectionInitializationCallback = connectioninitializationcallback;
            return;
        }
    }

    public void unregisterConnectionInitializationCallback(ConnectionInitializationCallback connectioninitializationcallback)
        throws SQLException
    {
        RDS_LOGGER.finest("Connection Initialization Callback removed");
        connectionInitializationCallback = null;
    }

    public ConnectionInitializationCallback getConnectionInitializationCallback()
    {
        RDS_LOGGER.finest("connection initialization callback obtained");
        return connectionInitializationCallback;
    }

    public Properties getConnectionProperties()
    {
        return connectionProperties;
    }

    public String getConnectionProperty(String s)
    {
        return connectionProperties.getProperty(s);
    }

    public void setConnectionProperty(String s, String s1)
        throws SQLException
    {
        RDS_LOGGER.log(Level.FINEST, "name: {0}, value: {1}", new Object[] {
            s, s1
        });
        if(s1 == null || s1.equals(""))
        {
            throw new IllegalArgumentException();
        } else
        {
            connectionProperties.setProperty(s, s1);
            return;
        }
    }

    public void setConnectionProperties(Properties properties)
        throws SQLException
    {
        RDS_LOGGER.log(Level.FINEST, "ConnectionProperties: {0}", properties);
        if(properties.size() <= 0)
            throw new IllegalArgumentException();
        java.util.Map.Entry entry;
        for(Iterator iterator = properties.entrySet().iterator(); iterator.hasNext(); connectionProperties.setProperty((String)entry.getKey(), (String)entry.getValue()))
            entry = (java.util.Map.Entry)iterator.next();

    }

    public void setMaxStatements(int i)
        throws SQLException
    {
        maxStatements = i;
    }

    public int getMaxStatements()
        throws SQLException
    {
        return maxStatements;
    }

    public void setImplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        implicitCachingEnabled = flag;
    }

    public boolean getImplicitCachingEnabled()
        throws SQLException
    {
        return implicitCachingEnabled;
    }

    public void setExplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        explicitCachingEnabled = flag;
    }

    public boolean getExplicitCachingEnabled()
        throws SQLException
    {
        return explicitCachingEnabled;
    }

    public Reference getReference()
        throws NamingException
    {
        Reference reference = new Reference(getClass().getName(), "oracle.jdbc.replay.OracleDataSourceImpl", null);
        if(user != null)
            reference.add(new StringRefAddr("user", user));
        if(password != null)
            reference.add(new StringRefAddr("password", password));
        if(url != null)
            reference.add(new StringRefAddr("url", url));
        if(serverName != null)
            reference.add(new StringRefAddr("serverName", serverName));
        reference.add(new StringRefAddr("portNumber", Integer.toString(portNumber)));
        if(databaseName != null)
            reference.add(new StringRefAddr("databaseName", databaseName));
        if(dataSourceName != null)
            reference.add(new StringRefAddr("dataSourceName", dataSourceName.toString()));
        if(description != null)
            reference.add(new StringRefAddr("description", description.toString()));
        if(networkProtocol != null)
            reference.add(new StringRefAddr("networkProtocol", networkProtocol.toString()));
        if(roleName != null)
            reference.add(new StringRefAddr("roleName", roleName));
        if(connectionProperties.size() > 0)
            reference.add(new StringRefAddr("connectionProperties", connectionProperties.toString()));
        if(maxStatements != 0)
            reference.add(new StringRefAddr("maxStatements", Integer.toString(maxStatements)));
        if(implicitCachingEnabled)
            reference.add(new StringRefAddr("implicitCachingEnabled", "true"));
        if(explicitCachingEnabled)
            reference.add(new StringRefAddr("explicitCachingEnabled", "true"));
        return reference;
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.defaultWriteObject();
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException, SQLException
    {
        objectinputstream.defaultReadObject();
    }

    public Object getObjectInstance(Object obj, Name name, Context context, Hashtable hashtable)
        throws Exception
    {
        Reference reference = (Reference)obj;
        String s = reference.getClassName();
        OracleDataSourceImpl oracledatasourceimpl = null;
        if(s.equals("oracle.jdbc.replay.OracleDataSource") || s.equals("oracle.jdbc.replay.OracleDataSourceImpl"))
            oracledatasourceimpl = new OracleDataSourceImpl();
        if(oracledatasourceimpl == null)
            return null;
        StringRefAddr stringrefaddr = (StringRefAddr)reference.get("user");
        if(stringrefaddr != null)
            oracledatasourceimpl.setUser((String)stringrefaddr.getContent());
        stringrefaddr = (StringRefAddr)reference.get("password");
        if(stringrefaddr != null)
            oracledatasourceimpl.setPassword((String)stringrefaddr.getContent());
        stringrefaddr = (StringRefAddr)reference.get("url");
        if(stringrefaddr != null)
            oracledatasourceimpl.setURL((String)stringrefaddr.getContent());
        stringrefaddr = (StringRefAddr)reference.get("serverName");
        if(stringrefaddr != null)
            oracledatasourceimpl.setServerName((String)stringrefaddr.getContent());
        stringrefaddr = (StringRefAddr)reference.get("portNumber");
        if(stringrefaddr != null)
            oracledatasourceimpl.setPortNumber(Integer.parseInt((String)stringrefaddr.getContent()));
        stringrefaddr = (StringRefAddr)reference.get("databaseName");
        if(stringrefaddr != null)
            oracledatasourceimpl.setDatabaseName((String)stringrefaddr.getContent());
        stringrefaddr = (StringRefAddr)reference.get("dataSourceName");
        if(stringrefaddr != null)
            oracledatasourceimpl.setDataSourceName((String)stringrefaddr.getContent());
        stringrefaddr = (StringRefAddr)reference.get("description");
        if(stringrefaddr != null)
            oracledatasourceimpl.setDescription((String)stringrefaddr.getContent());
        stringrefaddr = (StringRefAddr)reference.get("networkProtocol");
        if(stringrefaddr != null)
            oracledatasourceimpl.setNetworkProtocol((String)stringrefaddr.getContent());
        stringrefaddr = (StringRefAddr)reference.get("roleName");
        if(stringrefaddr != null)
            oracledatasourceimpl.setRoleName((String)stringrefaddr.getContent());
        stringrefaddr = (StringRefAddr)reference.get("connectionProperties");
        if(stringrefaddr != null)
        {
            String s1 = (String)stringrefaddr.getContent();
            Properties properties = new Properties();
            String as[] = s1.substring(1, s1.length() - 1).split(", ");
            String as1[] = as;
            int i = as1.length;
            for(int j = 0; j < i; j++)
            {
                String s4 = as1[j];
                String as2[] = s4.split("=");
                properties.setProperty(as2[0], as2[1]);
            }

            oracledatasourceimpl.setConnectionProperties(properties);
        }
        stringrefaddr = (StringRefAddr)reference.get("maxStatements");
        if(stringrefaddr != null)
            oracledatasourceimpl.setMaxStatements(Integer.parseInt((String)stringrefaddr.getContent()));
        stringrefaddr = (StringRefAddr)reference.get("implicitCachingEnabled");
        if(stringrefaddr != null)
        {
            String s2 = (String)stringrefaddr.getContent();
            if(s2.equalsIgnoreCase("true"))
                oracledatasourceimpl.setImplicitCachingEnabled(true);
            else
                oracledatasourceimpl.setImplicitCachingEnabled(false);
        }
        stringrefaddr = (StringRefAddr)reference.get("explicitCachingEnabled");
        if(stringrefaddr != null)
        {
            String s3 = (String)stringrefaddr.getContent();
            if(s3.equalsIgnoreCase("true"))
                oracledatasourceimpl.setExplicitCachingEnabled(true);
            else
                oracledatasourceimpl.setExplicitCachingEnabled(false);
        }
        return oracledatasourceimpl;
    }

    public boolean isWrapperFor(Class class1)
        throws SQLException
    {
        return false;
    }

    public Object unwrap(Class class1)
        throws SQLException
    {
        if(class1.isInterface() && class1.isInstance(this))
            return this;
        else
            return null;
    }

    static 
    {
        PROXY_FACTORY = null;
        if(PROXY_FACTORY == null)
            PROXY_FACTORY = ProxyFactory.createProxyFactory(new Class[] {
                oracle/jdbc/replay/driver/NonTxnReplayableBase, oracle/jdbc/replay/driver/NonTxnReplayableConnection, oracle/jdbc/replay/driver/NonTxnReplayableStatement, oracle/jdbc/replay/driver/NonTxnReplayableResultSet, oracle/jdbc/replay/driver/NonTxnReplayableArray, oracle/jdbc/replay/driver/NonTxnReplayableBfile, oracle/jdbc/replay/driver/NonTxnReplayableBlob, oracle/jdbc/replay/driver/NonTxnReplayableClob, oracle/jdbc/replay/driver/NonTxnReplayableNClob, oracle/jdbc/replay/driver/NonTxnReplayableOpaque, 
                oracle/jdbc/replay/driver/NonTxnReplayableRef, oracle/jdbc/replay/driver/NonTxnReplayableStruct, oracle/jdbc/replay/driver/NonTxnReplayableOthers
            });
    }
}
