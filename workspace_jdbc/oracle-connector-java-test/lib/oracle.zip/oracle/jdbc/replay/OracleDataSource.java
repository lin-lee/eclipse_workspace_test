// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDataSource.java

package oracle.jdbc.replay;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import javax.sql.DataSource;
import oracle.jdbc.replay.internal.ConnectionInitializationCallback;

public interface OracleDataSource
    extends DataSource
{

    public static final String USER = "user";
    public static final String URL = "url";
    public static final String PASSWORD = "password";
    public static final String SERVER_NAME = "serverName";
    public static final String PORT_NUMBER = "portNumber";
    public static final String DATABASE_NAME = "databaseName";
    public static final String DATA_SOURCE_NAME = "dataSourceName";
    public static final String DESCRIPTION = "description";
    public static final String NETWORK_PROTOCOL = "networkProtocol";
    public static final String ROLE_NAME = "roleName";
    public static final String CONNECTION_PROPERTIES = "connectionProperties";
    public static final String MAX_STATEMENTS = "maxStatements";
    public static final String IMPLICIT_CACHING_ENABLED = "implicitCachingEnabled";
    public static final String EXPLICIT_CACHING_ENABLED = "explicitCachingEnabled";

    public abstract void setURL(String s)
        throws SQLException;

    public abstract String getURL();

    public abstract void setUser(String s)
        throws SQLException;

    public abstract String getUser();

    public abstract void setPassword(String s)
        throws SQLException;

    public abstract void setServerName(String s)
        throws SQLException;

    public abstract String getServerName();

    public abstract void setPortNumber(int i)
        throws SQLException;

    public abstract int getPortNumber();

    public abstract void setDatabaseName(String s)
        throws SQLException;

    public abstract String getDatabaseName();

    public abstract void setDataSourceName(String s)
        throws SQLException;

    public abstract String getDataSourceName();

    public abstract void setDescription(String s)
        throws SQLException;

    public abstract String getDescription();

    public abstract void setNetworkProtocol(String s)
        throws SQLException;

    public abstract String getNetworkProtocol();

    public abstract void setRoleName(String s)
        throws SQLException;

    public abstract String getRoleName();

    public abstract void registerConnectionInitializationCallback(ConnectionInitializationCallback connectioninitializationcallback)
        throws SQLException;

    public abstract void unregisterConnectionInitializationCallback(ConnectionInitializationCallback connectioninitializationcallback)
        throws SQLException;

    public abstract ConnectionInitializationCallback getConnectionInitializationCallback();

    public abstract Properties getConnectionProperties();

    public abstract String getConnectionProperty(String s);

    public abstract void setConnectionProperty(String s, String s1)
        throws SQLException;

    public abstract void setConnectionProperties(Properties properties)
        throws SQLException;

    public abstract void setMaxStatements(int i)
        throws SQLException;

    public abstract int getMaxStatements()
        throws SQLException;

    public abstract void setImplicitCachingEnabled(boolean flag)
        throws SQLException;

    public abstract boolean getImplicitCachingEnabled()
        throws SQLException;

    public abstract void setExplicitCachingEnabled(boolean flag)
        throws SQLException;

    public abstract boolean getExplicitCachingEnabled()
        throws SQLException;

    public abstract Connection getConnectionNoProxy()
        throws SQLException;
}
