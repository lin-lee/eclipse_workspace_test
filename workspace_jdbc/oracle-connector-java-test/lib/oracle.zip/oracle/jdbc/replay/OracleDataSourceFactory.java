// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDataSourceFactory.java

package oracle.jdbc.replay;


// Referenced classes of package oracle.jdbc.replay:
//            OracleDataSourceImpl, OracleDataSource

public class OracleDataSourceFactory
{

    public OracleDataSourceFactory()
    {
    }

    public static OracleDataSource getOracleDataSource()
    {
        return new OracleDataSourceImpl();
    }
}
