// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   AdditionalDatabaseMetaData.java

package oracle.jdbc;

import java.sql.DatabaseMetaData;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc:
//            OracleTypeMetaData

public interface AdditionalDatabaseMetaData
    extends DatabaseMetaData
{

    public abstract OracleTypeMetaData getOracleTypeMetaData(String s)
        throws SQLException;

    public abstract long getLobMaxLength()
        throws SQLException;
}
