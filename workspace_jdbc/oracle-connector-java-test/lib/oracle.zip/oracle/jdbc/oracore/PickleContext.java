// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   PickleContext.java

package oracle.jdbc.oracore;

import java.io.IOException;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.oracore:
//            PickleOutputStream

public final class PickleContext
{

    private PickleOutputStream outStream;
    byte image[];
    int imageOffset;
    private byte lengthBuffer[];
    static short KOPI20_LN_ELNL = 255;
    static short KOPI20_LN_5BLN = 254;
    static short KOPI20_LN_ATMN = 253;
    static short KOPI20_LN_IEMN = 252;
    static short KOPI20_LN_MAXV = 245;
    static short KOPI20_IF_IS81 = 128;
    static short KOPI20_IF_CMSB = 64;
    static short KOPI20_IF_CLSB = 32;
    static short KOPI20_IF_DEGN = 16;
    static short KOPI20_IF_COLL = 8;
    static short KOPI20_IF_NOPS = 4;
    static short KOPI20_IF_ANY = 2;
    static short KOPI20_IF_NONL = 1;
    static short KOPI20_CF_CMSB = 64;
    static short KOPI20_CF_CLSB = 32;
    static short KOPI20_CF_INDX = 16;
    static short KOPI20_CF_NOLN = 8;
    static short KOPI20_VERSION = 1;
    static final byte KOPUP_INLINE_COLL = 1;
    static final byte KOPUP_TYPEINFO_NONE = 0;
    static final byte KOPUP_TYPEINFO_TOID = 4;
    static final byte KOPUP_TYPEINFO_TOBJN = 8;
    static final byte KOPUP_TYPEINFO_TDS = 12;
    static final byte KOPUP_VSN_PRESENT = 16;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public PickleContext()
    {
        lengthBuffer = new byte[5];
    }

    public PickleContext(byte abyte0[])
    {
        lengthBuffer = new byte[5];
        image = abyte0;
        imageOffset = 0;
    }

    public PickleContext(byte abyte0[], long l)
    {
        lengthBuffer = new byte[5];
        image = abyte0;
        imageOffset = (int)l;
    }

    public void initStream(int i)
    {
        outStream = new PickleOutputStream(i);
    }

    public void initStream()
    {
        outStream = new PickleOutputStream();
    }

    public int lengthInBytes(int i)
    {
        return i > KOPI20_LN_MAXV ? 5 : 1;
    }

    public int writeElementNull()
        throws SQLException
    {
        outStream.write(KOPI20_LN_ELNL);
        return 1;
    }

    public int writeAtomicNull()
        throws SQLException
    {
        outStream.write(KOPI20_LN_ATMN);
        return 1;
    }

    public int writeImmediatelyEmbeddedElementNull(byte byte0)
        throws SQLException
    {
        lengthBuffer[0] = (byte)KOPI20_LN_IEMN;
        lengthBuffer[1] = byte0;
        outStream.write(lengthBuffer, 0, 2);
        return 2;
    }

    public int writeSB2(int i)
        throws SQLException
    {
        lengthBuffer[0] = (byte)(i >> 8 & 0xff);
        lengthBuffer[1] = (byte)(i & 0xff);
        outStream.write(lengthBuffer, 0, 2);
        return 2;
    }

    public int writeLength(int i)
        throws SQLException
    {
        if(i <= KOPI20_LN_MAXV)
        {
            outStream.write((byte)i);
            return 1;
        }
        lengthBuffer[0] = (byte)KOPI20_LN_5BLN;
        lengthBuffer[1] = (byte)(i >> 24);
        i &= 0xffffff;
        lengthBuffer[2] = (byte)(i >> 16);
        i &= 0xffff;
        lengthBuffer[3] = (byte)(i >> 8);
        i &= 0xff;
        lengthBuffer[4] = (byte)i;
        try
        {
            outStream.write(lengthBuffer);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return 5;
    }

    public int writeLength(int i, boolean flag)
        throws SQLException
    {
        if(!flag)
            return writeLength(i);
        if(i <= KOPI20_LN_MAXV - 1)
        {
            outStream.write((byte)i + 1);
            return 1;
        }
        i += 5;
        lengthBuffer[0] = (byte)KOPI20_LN_5BLN;
        lengthBuffer[1] = (byte)(i >> 24);
        i &= 0xffffff;
        lengthBuffer[2] = (byte)(i >> 16);
        i &= 0xffff;
        lengthBuffer[3] = (byte)(i >> 8);
        i &= 0xff;
        lengthBuffer[4] = (byte)i;
        try
        {
            outStream.write(lengthBuffer);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return 5;
    }

    public byte[] to5bLengthBytes_pctx(int i)
        throws SQLException
    {
        lengthBuffer[0] = (byte)KOPI20_LN_5BLN;
        lengthBuffer[1] = (byte)(i >> 24);
        i &= 0xffffff;
        lengthBuffer[2] = (byte)(i >> 16);
        i &= 0xffff;
        lengthBuffer[3] = (byte)(i >> 8);
        i &= 0xff;
        lengthBuffer[4] = (byte)i;
        return lengthBuffer;
    }

    public int writeData(byte byte0)
        throws SQLException
    {
        outStream.write(byte0);
        return 1;
    }

    public int writeData(byte abyte0[])
        throws SQLException
    {
        try
        {
            outStream.write(abyte0);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return abyte0.length;
    }

    public void patchImageLen(int i, int j)
        throws SQLException
    {
        byte abyte0[] = to5bLengthBytes_pctx(j);
        outStream.overwrite(i, abyte0, 0, abyte0.length);
    }

    public int writeImageHeader(boolean flag)
        throws SQLException
    {
        return writeImageHeader(KOPI20_LN_MAXV + 1, flag);
    }

    public int writeOpaqueImageHeader(int i)
        throws SQLException
    {
        int j = 2;
        lengthBuffer[0] = (byte)(KOPI20_IF_IS81 | KOPI20_IF_NOPS | KOPI20_IF_NONL);
        lengthBuffer[1] = (byte)KOPI20_VERSION;
        outStream.write(lengthBuffer, 0, 2);
        j += writeLength(i + 2, true);
        return j;
    }

    public int writeImageHeader(int i, boolean flag)
        throws SQLException
    {
        int j = 2;
        if(flag)
            lengthBuffer[0] = (byte)KOPI20_IF_IS81;
        else
            lengthBuffer[0] = (byte)(KOPI20_IF_IS81 | KOPI20_IF_NOPS);
        lengthBuffer[1] = (byte)KOPI20_VERSION;
        outStream.write(lengthBuffer, 0, 2);
        j += writeLength(i);
        return j;
    }

    public int writeCollImageHeader(int i, int j)
        throws SQLException
    {
        return writeCollImageHeader(KOPI20_LN_MAXV + 1, i, j);
    }

    public int writeCollImageHeader(int i, int j, int k)
        throws SQLException
    {
        int l = 5;
        lengthBuffer[0] = (byte)(KOPI20_IF_IS81 | KOPI20_IF_COLL);
        lengthBuffer[1] = (byte)KOPI20_VERSION;
        outStream.write(lengthBuffer, 0, 2);
        l += writeLength(i);
        lengthBuffer[0] = 1;
        lengthBuffer[1] = 17;
        if(k > KOPI20_LN_MAXV)
        {
            lengthBuffer[0] += 5;
            l += 5;
            outStream.write(lengthBuffer, 0, 2);
            writeLength(k);
        } else
        {
            lengthBuffer[0] += 2;
            l += 2;
            outStream.write(lengthBuffer, 0, 2);
            writeSB2(k);
        }
        lengthBuffer[0] = 0;
        outStream.write(lengthBuffer, 0, 1);
        l += writeLength(j);
        return l;
    }

    public int writeCollImageHeader(byte abyte0[])
        throws SQLException
    {
        return writeCollImageHeader(KOPI20_LN_MAXV + 1, abyte0);
    }

    public int writeCollImageHeader(int i, byte abyte0[])
        throws SQLException
    {
        int j = abyte0.length;
        int k = 3 + j;
        lengthBuffer[0] = (byte)(KOPI20_IF_IS81 | KOPI20_IF_DEGN);
        lengthBuffer[1] = (byte)KOPI20_VERSION;
        outStream.write(lengthBuffer, 0, 2);
        k += writeLength(i);
        k += writeLength(j + 1);
        lengthBuffer[0] = 0;
        outStream.write(lengthBuffer, 0, 1);
        outStream.write(abyte0, 0, j);
        return k;
    }

    public byte[] stream2Bytes()
        throws SQLException
    {
        return outStream.toByteArray();
    }

    public byte readByte()
        throws SQLException
    {
        byte byte0 = image[imageOffset];
        imageOffset++;
        return byte0;
        Exception exception;
        exception;
        imageOffset++;
        throw exception;
    }

    public boolean readAndCheckVersion()
        throws SQLException
    {
        boolean flag = (image[imageOffset] & 0xff) <= KOPI20_VERSION;
        imageOffset++;
        return flag;
        Exception exception;
        exception;
        imageOffset++;
        throw exception;
    }

    public int readLength()
        throws SQLException
    {
        int i = image[imageOffset] & 0xff;
        if(i > KOPI20_LN_MAXV)
        {
            if(i == KOPI20_LN_ELNL)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid null flag read");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            i = (((image[imageOffset + 1] & 0xff) * 256 + (image[imageOffset + 2] & 0xff)) * 256 + (image[imageOffset + 3] & 0xff)) * 256 + (image[imageOffset + 4] & 0xff);
            imageOffset += 5;
        } else
        {
            imageOffset++;
        }
        return i;
    }

    public void skipLength()
        throws SQLException
    {
        int i = image[imageOffset] & 0xff;
        if(i > KOPI20_LN_MAXV)
            imageOffset += 5;
        else
            imageOffset++;
    }

    public int readRestOfLength(byte byte0)
        throws SQLException
    {
        if((byte0 & 0xff) != KOPI20_LN_5BLN)
            return byte0 & 0xff;
        int i = (((image[imageOffset] & 0xff) * 256 + (image[imageOffset + 1] & 0xff)) * 256 + (image[imageOffset + 2] & 0xff)) * 256 + (image[imageOffset + 3] & 0xff);
        imageOffset += 4;
        return i;
        Exception exception;
        exception;
        imageOffset += 4;
        throw exception;
    }

    public void skipRestOfLength(byte byte0)
        throws SQLException
    {
        if((byte0 & 0xff) > KOPI20_LN_MAXV)
            if((byte0 & 0xff) == KOPI20_LN_5BLN)
            {
                imageOffset += 4;
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid first length byte");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
    }

    public int readLength(boolean flag)
        throws SQLException
    {
        int i = image[imageOffset] & 0xff;
        if(i > KOPI20_LN_MAXV)
        {
            i = (((image[imageOffset + 1] & 0xff) * 256 + (image[imageOffset + 2] & 0xff)) * 256 + (image[imageOffset + 3] & 0xff)) * 256 + (image[imageOffset + 4] & 0xff);
            if(flag)
                i -= 5;
            imageOffset += 5;
        } else
        {
            if(flag)
                i--;
            imageOffset++;
        }
        return i;
    }

    public byte[] readPrefixSegment()
        throws SQLException
    {
        byte abyte0[] = new byte[readLength()];
        System.arraycopy(image, imageOffset, abyte0, 0, abyte0.length);
        imageOffset += abyte0.length;
        return abyte0;
    }

    public byte[] readDataValue()
        throws SQLException
    {
        int i = image[imageOffset] & 0xff;
        if(i == KOPI20_LN_ELNL)
        {
            imageOffset++;
            return null;
        }
        if(i > KOPI20_LN_MAXV)
        {
            i = (((image[imageOffset + 1] & 0xff) * 256 + (image[imageOffset + 2] & 0xff)) * 256 + (image[imageOffset + 3] & 0xff)) * 256 + (image[imageOffset + 4] & 0xff);
            imageOffset += 5;
        } else
        {
            imageOffset++;
        }
        byte abyte0[] = new byte[i];
        System.arraycopy(image, imageOffset, abyte0, 0, abyte0.length);
        imageOffset += abyte0.length;
        return abyte0;
    }

    public byte[] readBytes(int i)
        throws SQLException
    {
        byte abyte0[] = new byte[i];
        System.arraycopy(image, imageOffset, abyte0, 0, i);
        imageOffset += i;
        return abyte0;
    }

    public byte[] read1ByteDataValue()
        throws SQLException
    {
        if((image[imageOffset] & 0xff) == KOPI20_LN_ELNL)
        {
            return null;
        } else
        {
            byte abyte0[] = new byte[image[imageOffset] & 0xff];
            System.arraycopy(image, imageOffset + 1, abyte0, 0, abyte0.length);
            imageOffset += abyte0.length + 1;
            return abyte0;
        }
    }

    public byte[] readDataValue(byte byte0)
        throws SQLException
    {
        byte abyte0[] = new byte[readRestOfLength(byte0)];
        System.arraycopy(image, imageOffset, abyte0, 0, abyte0.length);
        imageOffset += abyte0.length;
        return abyte0;
    }

    public byte[] readDataValue(int i)
        throws SQLException
    {
        byte abyte0[] = new byte[i];
        System.arraycopy(image, imageOffset, abyte0, 0, i);
        imageOffset += i;
        return abyte0;
    }

    public long readUB4()
        throws SQLException
    {
        long l = (long)image[imageOffset++] << 24 & 0xffffffffff000000L | (long)image[imageOffset++] << 16 & 0xff0000L | (long)image[imageOffset++] << 8 & 65280L | (long)image[imageOffset++] & 255L;
        return l;
    }

    public int readUB2()
        throws SQLException
    {
        int i = image[imageOffset++] << 8 & 0xff00 | image[imageOffset++] & 0xff;
        return i;
    }

    public void skipDataValue()
        throws SQLException
    {
        if((image[imageOffset] & 0xff) == KOPI20_LN_ELNL)
            imageOffset++;
        else
            skipBytes(readLength());
    }

    public void skipDataValue(byte byte0)
        throws SQLException
    {
        skipBytes(readRestOfLength(byte0));
    }

    public void skipBytes(int i)
        throws SQLException
    {
        if(i > 0)
            imageOffset += i;
    }

    public int offset()
        throws SQLException
    {
        if(outStream != null)
            return outStream.offset();
        else
            return imageOffset;
    }

    public int absoluteOffset()
        throws SQLException
    {
        return imageOffset;
    }

    public void skipTo(long l)
        throws SQLException
    {
        if(l > (long)imageOffset)
            imageOffset = (int)l;
    }

    public byte[] image()
        throws SQLException
    {
        return image;
    }

    public static boolean is81format(byte byte0)
        throws SQLException
    {
        return (byte0 & 0xff & KOPI20_IF_IS81) != 0;
    }

    public static boolean isCollectionImage_pctx(byte byte0)
        throws SQLException
    {
        return (byte0 & 0xff & KOPI20_IF_COLL) != 0;
    }

    public static boolean isDegenerateImage_pctx(byte byte0)
        throws SQLException
    {
        return (byte0 & 0xff & KOPI20_IF_DEGN) != 0;
    }

    public static boolean hasPrefix(byte byte0)
        throws SQLException
    {
        return (byte0 & 0xff & KOPI20_IF_NOPS) == 0;
    }

    public static boolean isAtomicNull(byte byte0)
        throws SQLException
    {
        return (byte0 & 0xff) == KOPI20_LN_ATMN;
    }

    public static boolean isImmediatelyEmbeddedNull(byte byte0)
        throws SQLException
    {
        return (byte0 & 0xff) == KOPI20_LN_IEMN;
    }

    public static boolean isElementNull(byte byte0)
        throws SQLException
    {
        return (byte0 & 0xff) == KOPI20_LN_ELNL;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
