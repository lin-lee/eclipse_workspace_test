// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleNamedType.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType, TypeTreeElement, OracleTypeADT

public abstract class OracleNamedType extends OracleType
    implements Serializable
{

    transient OracleConnection connection;
    SQLName sqlName;
    transient OracleTypeADT parent;
    transient int idx;
    transient TypeDescriptor descriptor;
    static String getUserTypeTreeSql = "select level depth, parent_type, child_type, ATTR_NO, child_type_owner from  (select TYPE_NAME parent_type, ELEM_TYPE_NAME child_type, 0 ATTR_NO,       ELEM_TYPE_OWNER child_type_owner     from USER_COLL_TYPES  union   select TYPE_NAME parent_type, ATTR_TYPE_NAME child_type, ATTR_NO,       ATTR_TYPE_OWNER child_type_owner     from USER_TYPE_ATTRS  ) start with parent_type  = ?  connect by prior  child_type = parent_type";
    String sqlHint;
    static String getAllTypeTreeSql = "select parent_type, parent_type_owner, child_type, ATTR_NO, child_type_owner from ( select TYPE_NAME parent_type,  OWNER parent_type_owner,     ELEM_TYPE_NAME child_type, 0 ATTR_NO,     ELEM_TYPE_OWNER child_type_owner   from ALL_COLL_TYPES union   select TYPE_NAME parent_type, OWNER parent_type_owner,     ATTR_TYPE_NAME child_type, ATTR_NO,     ATTR_TYPE_OWNER child_type_owner   from ALL_TYPE_ATTRS ) start with parent_type  = ?  and parent_type_owner = ? connect by prior child_type = parent_type   and ( child_type_owner = parent_type_owner or child_type_owner is null )";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleNamedType()
    {
        sqlName = null;
        parent = null;
        descriptor = null;
        sqlHint = null;
    }

    public OracleNamedType(String s, OracleConnection oracleconnection)
        throws SQLException
    {
        sqlName = null;
        parent = null;
        descriptor = null;
        sqlHint = null;
        setConnectionInternal(oracleconnection);
        sqlName = new SQLName(s, oracleconnection);
    }

    protected OracleNamedType(OracleTypeADT oracletypeadt, int i, OracleConnection oracleconnection)
    {
        sqlName = null;
        parent = null;
        descriptor = null;
        sqlHint = null;
        setConnectionInternal(oracleconnection);
        parent = oracletypeadt;
        idx = i;
    }

    public String getFullName()
        throws SQLException
    {
        return getFullName(false);
    }

    public String getFullName(boolean flag)
        throws SQLException
    {
        String s = null;
        if(flag || sqlName == null)
            if(parent != null && (s = parent.getAttributeType(idx)) != null)
            {
                sqlName = new SQLName(s, connection);
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Unable to resolve name");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return sqlName.getName();
    }

    public String getSchemaName()
        throws SQLException
    {
        if(sqlName == null)
            getFullName();
        return sqlName.getSchema();
    }

    public String getSimpleName()
        throws SQLException
    {
        if(sqlName == null)
            getFullName();
        return sqlName.getSimpleName();
    }

    public boolean hasName()
        throws SQLException
    {
        return sqlName != null;
    }

    public OracleTypeADT getParent()
        throws SQLException
    {
        return parent;
    }

    public void setParent(OracleTypeADT oracletypeadt)
        throws SQLException
    {
        parent = oracletypeadt;
    }

    public int getOrder()
        throws SQLException
    {
        return idx;
    }

    public void setOrder(int i)
        throws SQLException
    {
        idx = i;
    }

    public OracleConnection getConnection()
        throws SQLException
    {
        return connection;
    }

    public void setConnection(OracleConnection oracleconnection)
        throws SQLException
    {
        setConnectionInternal(oracleconnection);
    }

    public void setConnectionInternal(OracleConnection oracleconnection)
    {
        connection = oracleconnection;
    }

    public Datum unlinearize(byte abyte0[], long l, Datum datum, int i, Map map)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Datum unlinearize(byte abyte0[], long l, Datum datum, long l1, int i, 
            int j, Map map)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public byte[] linearize(Datum datum)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public TypeDescriptor getDescriptor()
        throws SQLException
    {
        return descriptor;
    }

    public void setDescriptor(TypeDescriptor typedescriptor)
        throws SQLException
    {
        descriptor = typedescriptor;
    }

    public int getTypeVersion()
    {
        return 1;
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        try
        {
            objectoutputstream.writeUTF(getFullName());
        }
        catch(SQLException sqlexception)
        {
            IOException ioexception = DatabaseError.createIOException(sqlexception);
            ioexception.fillInStackTrace();
            throw ioexception;
        }
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        String s = objectinputstream.readUTF();
        try
        {
            sqlName = new SQLName(s, null);
        }
        catch(SQLException sqlexception) { }
        parent = null;
        idx = -1;
    }

    public void fixupConnection(OracleConnection oracleconnection)
        throws SQLException
    {
        if(connection == null)
            setConnection(oracleconnection);
    }

    public void printXML(PrintWriter printwriter, int i)
        throws SQLException
    {
        printXML(printwriter, i, false);
    }

    public void printXML(PrintWriter printwriter, int i, boolean flag)
        throws SQLException
    {
        for(int j = 0; j < i; j++)
            printwriter.print("  ");

        printwriter.println("<OracleNamedType/>");
    }

    public void initNamesRecursively()
        throws SQLException
    {
        Map map = createTypesTreeMap();
        if(map.size() > 0)
            initChildNamesRecursively(map);
    }

    public void setNames(String s, String s1)
        throws SQLException
    {
        sqlName = new SQLName(s, s1, connection);
    }

    public void setSqlName(SQLName sqlname)
    {
        sqlName = sqlname;
    }

    public Map createTypesTreeMap()
        throws SQLException
    {
        Map map = null;
        String s = connection.getDefaultSchemaNameForNamedTypes();
        if(sqlName.getSchema().equals(s))
            map = getNodeMapFromUserTypes();
        if(map == null)
            map = getNodeMapFromAllTypes();
        return map;
    }

    String getSqlHint()
        throws SQLException
    {
        if(sqlHint == null)
            if(connection.getVersionNumber() >= 11000)
                sqlHint = "";
            else
                sqlHint = "/*+RULE*/";
        return sqlHint;
    }

    Map getNodeMapFromUserTypes()
        throws SQLException
    {
        HashMap hashmap;
        PreparedStatement preparedstatement;
        ResultSet resultset;
        hashmap = new HashMap();
        preparedstatement = null;
        resultset = null;
        preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(getUserTypeTreeSql).toString());
        preparedstatement.setString(1, sqlName.getSimpleName());
        resultset = preparedstatement.executeQuery();
        do
        {
            if(!resultset.next())
                break;
            int i = resultset.getInt(1);
            String s = resultset.getString(2);
            String s1 = resultset.getString(3);
            int j = resultset.getInt(4);
            String s2 = resultset.getString(5);
            if(s2 != null && !s2.equals(sqlName.getSchema()))
            {
                hashmap = null;
                break;
            }
            if(s.length() > 0)
            {
                SQLName sqlname = new SQLName(sqlName.getSchema(), s, connection);
                TypeTreeElement typetreeelement = null;
                if(hashmap.containsKey(sqlname))
                {
                    typetreeelement = (TypeTreeElement)(TypeTreeElement)hashmap.get(sqlname);
                } else
                {
                    typetreeelement = new TypeTreeElement(sqlName.getSchema(), s);
                    hashmap.put(sqlname, typetreeelement);
                }
                typetreeelement.putChild(sqlName.getSchema(), s1, j);
            }
        } while(true);
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        break MISSING_BLOCK_LABEL_304;
        Exception exception;
        exception;
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        throw exception;
        return hashmap;
    }

    Map getNodeMapFromAllTypes()
        throws SQLException
    {
        HashMap hashmap;
        PreparedStatement preparedstatement;
        ResultSet resultset;
        hashmap = new HashMap();
        preparedstatement = null;
        resultset = null;
        preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(getAllTypeTreeSql).toString());
        preparedstatement.setString(1, sqlName.getSimpleName());
        preparedstatement.setString(2, sqlName.getSchema());
        resultset = preparedstatement.executeQuery();
        do
        {
            if(!resultset.next())
                break;
            String s = resultset.getString(1);
            String s1 = resultset.getString(2);
            String s2 = resultset.getString(3);
            int i = resultset.getInt(4);
            String s3 = resultset.getString(5);
            if(s3 == null)
                s3 = "SYS";
            if(s.length() > 0)
            {
                SQLName sqlname = new SQLName(s1, s, connection);
                TypeTreeElement typetreeelement = null;
                if(hashmap.containsKey(sqlname))
                {
                    typetreeelement = (TypeTreeElement)(TypeTreeElement)hashmap.get(sqlname);
                } else
                {
                    typetreeelement = new TypeTreeElement(s1, s);
                    hashmap.put(sqlname, typetreeelement);
                }
                typetreeelement.putChild(s3, s2, i);
            }
        } while(true);
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        break MISSING_BLOCK_LABEL_287;
        Exception exception;
        exception;
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        throw exception;
        return hashmap;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
