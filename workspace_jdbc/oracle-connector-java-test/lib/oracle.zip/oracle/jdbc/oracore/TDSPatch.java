// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   TDSPatch.java

package oracle.jdbc.oracore;

import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleNamedType, OracleTypeUPT, OracleTypeADT, OracleTypeCOLLECTION, 
//            OracleType

public class TDSPatch
{

    static final int S_NORMAL_PATCH = 0;
    static final int S_SIMPLE_PATCH = 1;
    int typeId;
    OracleType owner;
    long position;
    int uptCode;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public TDSPatch(int i, OracleType oracletype, long l, int j)
        throws SQLException
    {
        typeId = i;
        owner = oracletype;
        position = l;
        uptCode = j;
    }

    int getType()
        throws SQLException
    {
        return typeId;
    }

    OracleNamedType getOwner()
        throws SQLException
    {
        return (OracleNamedType)owner;
    }

    long getPosition()
        throws SQLException
    {
        return position;
    }

    byte getUptTypeCode()
        throws SQLException
    {
        return (byte)uptCode;
    }

    void apply(OracleType oracletype)
        throws SQLException
    {
        apply(oracletype, -1);
    }

    void apply(OracleType oracletype, int i)
        throws SQLException
    {
        if(typeId == 0)
        {
            OracleTypeUPT oracletypeupt = (OracleTypeUPT)owner;
            oracletypeupt.realType = (OracleTypeADT)oracletype;
            if(oracletype instanceof OracleNamedType)
            {
                OracleNamedType oraclenamedtype = (OracleNamedType)oracletype;
                oraclenamedtype.setParent(oracletypeupt.getParent());
                oraclenamedtype.setOrder(oracletypeupt.getOrder());
            }
        } else
        if(typeId == 1)
        {
            OracleTypeCOLLECTION oracletypecollection = (OracleTypeCOLLECTION)owner;
            oracletypecollection.opcode = i;
            oracletypecollection.elementType = oracletype;
            if(oracletype instanceof OracleNamedType)
            {
                OracleNamedType oraclenamedtype1 = (OracleNamedType)oracletype;
                oraclenamedtype1.setParent(oracletypecollection);
                oraclenamedtype1.setOrder(1);
            }
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
