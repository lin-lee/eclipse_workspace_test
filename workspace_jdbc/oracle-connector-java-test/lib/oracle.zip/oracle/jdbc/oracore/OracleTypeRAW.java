// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeRAW.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.Datum;
import oracle.sql.RAW;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType, TDSReader, PickleContext

public class OracleTypeRAW extends OracleType
    implements Serializable
{

    static final long serialVersionUID = 0xab927b228ac31110L;
    int length;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleTypeRAW()
    {
    }

    public OracleTypeRAW(int i)
    {
        super(i);
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        RAW raw = null;
        if(obj != null)
            try
            {
                if(obj instanceof RAW)
                    raw = (RAW)obj;
                else
                    raw = new RAW(obj);
            }
            catch(SQLException sqlexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return raw;
    }

    public Datum[] toDatumArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        Datum adatum[] = null;
        if(obj != null)
            if(obj instanceof char[][])
            {
                char ac[][] = (char[][])(char[][])obj;
                int j = (int)(i != -1 ? Math.min(((long)ac.length - l) + 1L, i) : ac.length);
                adatum = new Datum[j];
                for(int k = 0; k < j; k++)
                    adatum[k] = toDatum(new String(ac[((int)l + k) - 1]), oracleconnection);

            } else
            if(obj instanceof Object[])
            {
                return super.toDatumArray(obj, oracleconnection, l, i);
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return adatum;
    }

    public int getTypeCode()
    {
        return -2;
    }

    public void parseTDSrec(TDSReader tdsreader)
        throws SQLException
    {
        super.parseTDSrec(tdsreader);
        length = tdsreader.readUB2();
    }

    protected int pickle81(PickleContext picklecontext, Datum datum)
        throws SQLException
    {
        if(datum.getLength() > (long)length)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 72, this);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            int i = picklecontext.writeLength((int)datum.getLength());
            i += picklecontext.writeData(datum.shareBytes());
            return i;
        }
    }

    public int getLength()
    {
        return length;
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        if(abyte0 == null || abyte0.length == 0)
            return null;
        switch(i)
        {
        case 1: // '\001'
            return new RAW(abyte0);

        case 2: // '\002'
        case 3: // '\003'
            return abyte0;
        }
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, abyte0);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeInt(length);
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        length = objectinputstream.readInt();
    }

}
