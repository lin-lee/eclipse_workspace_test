// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeINTERVAL.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType, TDSReader, UnpickleContext

public class OracleTypeINTERVAL extends OracleType
    implements Serializable
{

    static final long serialVersionUID = 0x135b536045cb693dL;
    static final int LDIINTYEARMONTH = 7;
    static final int LDIINTDAYSECOND = 10;
    static final int SIZE_INTERVAL_YM = 5;
    static final int SIZE_INTERVAL_DS = 11;
    byte typeId;
    int scale;
    int precision;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleTypeINTERVAL()
    {
        typeId = 0;
        scale = 0;
        precision = 0;
    }

    public OracleTypeINTERVAL(OracleConnection oracleconnection)
    {
        typeId = 0;
        scale = 0;
        precision = 0;
    }

    public int getTypeCode()
    {
        if(typeId == 7)
            return -103;
        return typeId != 10 ? 1111 : -104;
    }

    public void parseTDSrec(TDSReader tdsreader)
        throws SQLException
    {
        typeId = tdsreader.readByte();
        precision = tdsreader.readByte();
        scale = tdsreader.readByte();
    }

    public int getScale()
        throws SQLException
    {
        return scale;
    }

    public int getPrecision()
        throws SQLException
    {
        return precision;
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        typeId = objectinputstream.readByte();
        precision = objectinputstream.readByte();
        scale = objectinputstream.readByte();
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeByte(typeId);
        objectoutputstream.writeByte(precision);
        objectoutputstream.writeByte(scale);
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        if(abyte0 == null || abyte0.length == 0)
            return null;
        switch(i)
        {
        case 1: // '\001'
            if(abyte0.length == 5)
                return new INTERVALYM(abyte0);
            if(abyte0.length == 11)
                return new INTERVALDS(abyte0);
            break;

        case 2: // '\002'
            if(abyte0.length == 5)
                return INTERVALYM.toString(abyte0);
            if(abyte0.length == 11)
                return INTERVALDS.toString(abyte0);
            break;

        case 3: // '\003'
            return abyte0;

        default:
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return null;
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        Object obj1 = null;
        if(obj != null)
            if((obj instanceof INTERVALYM) || (obj instanceof INTERVALDS))
                obj1 = (Datum)obj;
            else
            if(obj instanceof String)
            {
                try
                {
                    obj1 = new INTERVALDS((String)obj);
                }
                catch(StringIndexOutOfBoundsException stringindexoutofboundsexception)
                {
                    obj1 = new INTERVALYM((String)obj);
                }
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return ((Datum) (obj1));
    }

    protected Object unpickle81rec(UnpickleContext unpicklecontext, int i, int j, Map map)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

}
