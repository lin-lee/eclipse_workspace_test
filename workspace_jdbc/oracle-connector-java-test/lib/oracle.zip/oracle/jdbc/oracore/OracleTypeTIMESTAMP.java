// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeTIMESTAMP.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.*;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType, TDSReader, UnpickleContext

public class OracleTypeTIMESTAMP extends OracleType
    implements Serializable
{

    static final long serialVersionUID = 0x36ca447fa16f006cL;
    int precision;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleTypeTIMESTAMP()
    {
        precision = 0;
    }

    public OracleTypeTIMESTAMP(OracleConnection oracleconnection)
    {
        precision = 0;
    }

    public int getTypeCode()
    {
        return 93;
    }

    public void parseTDSrec(TDSReader tdsreader)
        throws SQLException
    {
        precision = tdsreader.readByte();
    }

    public int getScale()
        throws SQLException
    {
        return 0;
    }

    public int getPrecision()
        throws SQLException
    {
        return precision;
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        precision = objectinputstream.readByte();
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeByte(precision);
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        if(abyte0 == null || abyte0.length == 0)
            return null;
        switch(i)
        {
        case 1: // '\001'
            return new TIMESTAMP(abyte0);

        case 2: // '\002'
            return TIMESTAMP.toTimestamp(abyte0);

        case 3: // '\003'
            return abyte0;
        }
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        TIMESTAMP timestamp = null;
        if(obj != null)
            try
            {
                if(obj instanceof TIMESTAMP)
                    timestamp = (TIMESTAMP)obj;
                else
                if(obj instanceof byte[])
                    timestamp = new TIMESTAMP((byte[])(byte[])obj);
                else
                if(obj instanceof Timestamp)
                    timestamp = new TIMESTAMP((Timestamp)obj);
                else
                if(obj instanceof DATE)
                    timestamp = new TIMESTAMP((DATE)obj);
                else
                if(obj instanceof String)
                    timestamp = new TIMESTAMP((String)obj);
                else
                if(obj instanceof Date)
                    timestamp = new TIMESTAMP((Date)obj);
                else
                if(obj instanceof Time)
                {
                    timestamp = new TIMESTAMP((Time)obj);
                } else
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
            }
            catch(Exception exception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return timestamp;
    }

    protected Object unpickle81rec(UnpickleContext unpicklecontext, int i, int j, Map map)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

}
