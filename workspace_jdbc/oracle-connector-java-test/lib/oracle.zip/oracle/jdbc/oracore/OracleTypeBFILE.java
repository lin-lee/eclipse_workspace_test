// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeBFILE.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.BFILE;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType

public class OracleTypeBFILE extends OracleType
    implements Serializable
{

    static final long serialVersionUID = 0xf62ff867f451d601L;
    static int fixedDataSize = 530;
    transient OracleConnection connection;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleTypeBFILE()
    {
    }

    public OracleTypeBFILE(OracleConnection oracleconnection)
    {
        connection = oracleconnection;
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        BFILE bfile = null;
        if(obj != null)
            if(obj instanceof BFILE)
            {
                bfile = (BFILE)obj;
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return bfile;
    }

    public int getTypeCode()
    {
        return -13;
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        if(abyte0 == null || abyte0.length == 0)
            return null;
        if(i == 1 || i == 2)
            return connection.createBfile(abyte0);
        if(i == 3)
        {
            return abyte0;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, abyte0);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
    }

    public void setConnection(OracleConnection oracleconnection)
        throws SQLException
    {
        connection = oracleconnection;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
