// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   Util.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;

public class Util
{

    private static int ldsRoundTable[] = {
        0, 1, 0, 2, 0, 0, 0, 3, 0
    };
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public Util()
    {
    }

    static void checkNextByte(InputStream inputstream, byte byte0)
        throws SQLException
    {
        try
        {
            if(inputstream.read() != byte0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(null, 47, "parseTDS");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(null, ioexception);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    public static int[] toJavaUnsignedBytes(byte abyte0[])
    {
        int ai[] = new int[abyte0.length];
        for(int i = 0; i < abyte0.length; i++)
            ai[i] = abyte0[i] & 0xff;

        return ai;
    }

    static byte[] readBytes(InputStream inputstream, int i)
        throws SQLException
    {
        byte abyte0[] = new byte[i];
        try
        {
            int j = inputstream.read(abyte0);
            if(j != i)
            {
                byte abyte1[] = new byte[j];
                System.arraycopy(abyte0, 0, abyte1, 0, j);
                return abyte1;
            }
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return abyte0;
    }

    static void writeBytes(OutputStream outputstream, byte abyte0[])
        throws SQLException
    {
        try
        {
            outputstream.write(abyte0);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    static void skipBytes(InputStream inputstream, int i)
        throws SQLException
    {
        try
        {
            inputstream.skip(i);
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    static long readLong(InputStream inputstream)
        throws SQLException
    {
        byte abyte0[] = new byte[4];
        try
        {
            inputstream.read(abyte0);
            return (long)((((abyte0[0] & 0xff) * 256 + (abyte0[1] & 0xff)) * 256 + (abyte0[2] & 0xff)) * 256 + (abyte0[3] & 0xff));
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    static short readShort(InputStream inputstream)
        throws SQLException
    {
        byte abyte0[] = new byte[2];
        try
        {
            inputstream.read(abyte0);
            return (short)((abyte0[0] & 0xff) * 256 + (abyte0[1] & 0xff));
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    static byte readByte(InputStream inputstream)
        throws SQLException
    {
        try
        {
            return (byte)inputstream.read();
        }
        catch(IOException ioexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, ioexception);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    static byte fdoGetSize(byte abyte0[], int i)
    {
        byte byte0 = fdoGetEntry(abyte0, i);
        return (byte)(byte0 >> 3 & 0x1f);
    }

    static byte fdoGetAlign(byte abyte0[], int i)
    {
        byte byte0 = fdoGetEntry(abyte0, i);
        return (byte)(byte0 & 7);
    }

    static int ldsRound(int i, int j)
    {
        int k = ldsRoundTable[j];
        return (i >> k) + 1 << k;
    }

    private static byte fdoGetEntry(byte abyte0[], int i)
    {
        short word0 = getUnsignedByte(abyte0[5]);
        byte byte0 = abyte0[6 + word0 + i];
        return byte0;
    }

    public static short getUnsignedByte(byte byte0)
    {
        return (short)(byte0 & 0xff);
    }

    public static byte[] serializeObject(Object obj)
        throws IOException
    {
        if(obj == null)
        {
            return null;
        } else
        {
            ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
            ObjectOutputStream objectoutputstream = new ObjectOutputStream(bytearrayoutputstream);
            objectoutputstream.writeObject(obj);
            objectoutputstream.flush();
            return bytearrayoutputstream.toByteArray();
        }
    }

    public static Object deserializeObject(byte abyte0[])
        throws IOException, ClassNotFoundException
    {
        if(abyte0 == null)
        {
            return null;
        } else
        {
            ByteArrayInputStream bytearrayinputstream = new ByteArrayInputStream(abyte0);
            return (new ObjectInputStream(bytearrayinputstream)).readObject();
        }
    }

    public static void printByteArray(byte abyte0[])
    {
        System.out.println("DONT CALL THIS -- oracle.jdbc.oracore.Util.printByteArray");
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
