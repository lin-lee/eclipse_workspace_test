// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   UnpickleContext.java

package oracle.jdbc.oracore;

import java.sql.SQLException;
import java.util.Vector;

public final class UnpickleContext
{

    byte image[];
    int absoluteOffset;
    int beginOffset;
    int markedOffset;
    Vector patches;
    long ldsOffsets[];
    boolean nullIndicators[];
    boolean bigEndian;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public UnpickleContext()
    {
    }

    public UnpickleContext(byte abyte0[], int i, boolean aflag[], long al[], boolean flag)
    {
        image = abyte0;
        beginOffset = i;
        absoluteOffset = i;
        bigEndian = flag;
        nullIndicators = aflag;
        patches = null;
        ldsOffsets = al;
    }

    public byte readByte()
        throws SQLException
    {
        byte byte0 = image[absoluteOffset];
        absoluteOffset++;
        return byte0;
        Exception exception;
        exception;
        absoluteOffset++;
        throw exception;
    }

    public byte[] readVarNumBytes()
        throws SQLException
    {
        byte abyte0[] = new byte[image[absoluteOffset] & 0xff];
        System.arraycopy(image, absoluteOffset + 1, abyte0, 0, abyte0.length);
        absoluteOffset += 22;
        break MISSING_BLOCK_LABEL_61;
        Exception exception;
        exception;
        absoluteOffset += 22;
        throw exception;
        return abyte0;
    }

    public byte[] readPtrBytes()
        throws SQLException
    {
        byte abyte0[] = new byte[(image[absoluteOffset] & 0xff) * 256 + (image[absoluteOffset + 1] & 0xff) + 2];
        System.arraycopy(image, absoluteOffset, abyte0, 0, abyte0.length);
        absoluteOffset += abyte0.length;
        return abyte0;
    }

    public void skipPtrBytes()
        throws SQLException
    {
        absoluteOffset += (image[absoluteOffset] & 0xff) * 256 + (image[absoluteOffset + 1] & 0xff) + 2;
    }

    public byte[] readBytes(int i)
        throws SQLException
    {
        byte abyte1[];
        byte abyte0[] = new byte[i];
        System.arraycopy(image, absoluteOffset, abyte0, 0, i);
        abyte1 = abyte0;
        absoluteOffset += i;
        return abyte1;
        Exception exception;
        exception;
        absoluteOffset += i;
        throw exception;
    }

    public long readLong()
        throws SQLException
    {
        long l = (((image[absoluteOffset] & 0xff) * 256 + (image[absoluteOffset + 1] & 0xff)) * 256 + (image[absoluteOffset + 2] & 0xff)) * 256 + (image[absoluteOffset + 3] & 0xff);
        absoluteOffset += 4;
        return l;
        Exception exception;
        exception;
        absoluteOffset += 4;
        throw exception;
    }

    public short readShort()
        throws SQLException
    {
        short word0 = (short)((image[absoluteOffset] & 0xff) * 256 + (image[absoluteOffset + 1] & 0xff));
        absoluteOffset += 2;
        return word0;
        Exception exception;
        exception;
        absoluteOffset += 2;
        throw exception;
    }

    public byte[] readLengthBytes()
        throws SQLException
    {
        long l = readLong();
        return readBytes((int)l);
    }

    public void skipLengthBytes()
        throws SQLException
    {
        long l = readLong();
        absoluteOffset += l;
    }

    public void skipTo(long l)
        throws SQLException
    {
        if(l > (long)(absoluteOffset - beginOffset))
            absoluteOffset = beginOffset + (int)l;
    }

    public void skipTo(int i)
        throws SQLException
    {
        if(i > absoluteOffset - beginOffset)
            absoluteOffset = beginOffset + i;
    }

    public void mark()
        throws SQLException
    {
        markedOffset = absoluteOffset;
    }

    public void reset()
        throws SQLException
    {
        absoluteOffset = markedOffset;
    }

    public void markAndSkip()
        throws SQLException
    {
        markedOffset = absoluteOffset + 4;
        absoluteOffset = beginOffset + (int)readLong();
    }

    public void markAndSkip(long l)
        throws SQLException
    {
        markedOffset = absoluteOffset;
        absoluteOffset = beginOffset + (int)l;
    }

    public void skipBytes(int i)
        throws SQLException
    {
        if(i >= 0)
            absoluteOffset += i;
    }

    public boolean isNull(int i)
    {
        return nullIndicators[i];
    }

    public int absoluteOffset()
        throws SQLException
    {
        return absoluteOffset;
    }

    public int offset()
        throws SQLException
    {
        return absoluteOffset - beginOffset;
    }

    public byte[] image()
        throws SQLException
    {
        return image;
    }

}
