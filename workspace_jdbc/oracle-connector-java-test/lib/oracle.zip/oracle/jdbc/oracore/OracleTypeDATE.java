// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeDATE.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType

public class OracleTypeDATE extends OracleType
    implements Serializable
{

    static final long serialVersionUID = 0xaeb159670bbecac3L;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleTypeDATE()
    {
    }

    public OracleTypeDATE(int i)
    {
        super(i);
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        DATE date = null;
        if(obj != null)
            try
            {
                if(obj instanceof DATE)
                    date = (DATE)obj;
                else
                if(obj instanceof TIMESTAMP)
                    date = new DATE(((TIMESTAMP)obj).timestampValue());
                else
                    date = new DATE(obj);
            }
            catch(SQLException sqlexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return date;
    }

    public Datum[] toDatumArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        Datum adatum[] = null;
        if(obj != null)
            if(obj instanceof char[][])
            {
                char ac[][] = (char[][])(char[][])obj;
                int j = (int)(i != -1 ? Math.min(((long)ac.length - l) + 1L, i) : ac.length);
                adatum = new Datum[j];
                for(int k = 0; k < j; k++)
                    adatum[k] = toDatum(new String(ac[((int)l + k) - 1]), oracleconnection);

            } else
            if(obj instanceof Object[])
            {
                return super.toDatumArray(obj, oracleconnection, l, i);
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return adatum;
    }

    public int getTypeCode()
    {
        return 91;
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        if(abyte0 == null || abyte0.length == 0)
            return null;
        if(i == 1)
            return new DATE(abyte0);
        if(i == 2)
            return DATE.toTimestamp(abyte0);
        if(i == 3)
        {
            return abyte0;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, abyte0);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
    }

}
