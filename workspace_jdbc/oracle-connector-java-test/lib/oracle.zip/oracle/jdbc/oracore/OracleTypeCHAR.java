// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeCHAR.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;
import oracle.sql.converter.CharacterSetMetaData;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType, TDSReader, PickleContext

public class OracleTypeCHAR extends OracleType
    implements Serializable
{

    static final long serialVersionUID = 0xa0403fc3db9ee12bL;
    int form;
    int charset;
    int length;
    int characterSemantic;
    private transient OracleConnection connection;
    private short pickleCharaterSetId;
    private transient CharacterSet pickleCharacterSet;
    private short pickleNcharCharacterSet;
    static final int SQLCS_IMPLICIT = 1;
    static final int SQLCS_NCHAR = 2;
    static final int SQLCS_EXPLICIT = 3;
    static final int SQLCS_FLEXIBLE = 4;
    static final int SQLCS_LIT_NULL = 5;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleTypeCHAR()
    {
    }

    public OracleTypeCHAR(OracleConnection oracleconnection)
    {
        form = 0;
        charset = 0;
        length = 0;
        connection = oracleconnection;
        pickleCharaterSetId = 0;
        pickleNcharCharacterSet = 0;
        pickleCharacterSet = null;
        try
        {
            pickleCharaterSetId = connection.getStructAttrCsId();
        }
        catch(SQLException sqlexception)
        {
            pickleCharaterSetId = -1;
        }
        pickleCharacterSet = CharacterSet.make(pickleCharaterSetId);
    }

    protected OracleTypeCHAR(OracleConnection oracleconnection, int i)
    {
        super(i);
        form = 0;
        charset = 0;
        length = 0;
        connection = oracleconnection;
        pickleCharaterSetId = 0;
        pickleNcharCharacterSet = 0;
        pickleCharacterSet = null;
        try
        {
            pickleCharaterSetId = connection.getStructAttrCsId();
        }
        catch(SQLException sqlexception)
        {
            pickleCharaterSetId = -1;
        }
        pickleCharacterSet = CharacterSet.make(pickleCharaterSetId);
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        if(obj == null)
            return null;
        if(obj instanceof CHAR)
            return (CHAR)obj;
        CHAR char1;
        if(typeCode == 1 && (obj instanceof String))
        {
            if(characterSemantic != 0)
            {
                int i = CharacterSetMetaData.getRatio(pickleCharaterSetId, 1);
                String s = (String)obj;
                for(int j = s.length(); j < length / i; j++)
                    s = (new StringBuilder()).append(s).append(" ").toString();

                obj = s;
                char1 = new CHAR(obj, pickleCharacterSet);
            } else
            {
                char1 = new CHAR((String)obj, pickleCharacterSet, length);
            }
        } else
        {
            char1 = new CHAR(obj, pickleCharacterSet);
        }
        return char1;
    }

    public Datum[] toDatumArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        Datum adatum[] = null;
        if(obj != null)
        {
            if((obj instanceof Object[]) && !(obj instanceof char[][]))
                return super.toDatumArray(obj, oracleconnection, l, i);
            adatum = cArrayToDatumArray(obj, oracleconnection, l, i);
        }
        return adatum;
    }

    public void parseTDSrec(TDSReader tdsreader)
        throws SQLException
    {
        super.parseTDSrec(tdsreader);
        try
        {
            length = tdsreader.readUB2();
            form = tdsreader.readByte();
            characterSemantic = form & 0x80;
            form = form & 0x7f;
            charset = tdsreader.readUB2();
        }
        catch(SQLException sqlexception)
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        if(form != 2 || pickleNcharCharacterSet != 0)
            return;
        try
        {
            pickleNcharCharacterSet = connection.getStructAttrNCsId();
        }
        catch(SQLException sqlexception1)
        {
            pickleNcharCharacterSet = 2000;
        }
        pickleCharaterSetId = pickleNcharCharacterSet;
        pickleCharacterSet = CharacterSet.make(pickleCharaterSetId);
    }

    protected int pickle81(PickleContext picklecontext, Datum datum)
        throws SQLException
    {
        CHAR char1 = getDbCHAR(datum);
        if(characterSemantic != 0 && form != 2)
        {
            if(char1.getStringWithReplacement().length() > length)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 72, (new StringBuilder()).append("\"").append(char1.getStringWithReplacement()).append("\"").toString());
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        if(char1.getLength() > (long)length)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 72, (new StringBuilder()).append("\"").append(char1.getStringWithReplacement()).append("\"").toString());
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        return super.pickle81(picklecontext, char1);
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        if(abyte0 == null || abyte0.length == 0)
            return null;
        CHAR char1 = null;
        switch(form)
        {
        case 1: // '\001'
        case 2: // '\002'
            char1 = new CHAR(abyte0, pickleCharacterSet);
            break;

        case 3: // '\003'
        case 4: // '\004'
        case 5: // '\005'
            char1 = new CHAR(abyte0, null);
            break;
        }
        if(i == 1)
            return char1;
        if(i == 2)
            return char1.stringValue();
        if(i == 3)
        {
            return abyte0;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, abyte0);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    private CHAR getDbCHAR(Datum datum)
    {
        CHAR char1 = (CHAR)datum;
        CHAR char2 = null;
        if(char1.getCharacterSet().getOracleId() == pickleCharaterSetId)
            char2 = char1;
        else
            try
            {
                char2 = new CHAR(char1.toString(), pickleCharacterSet);
            }
            catch(SQLException sqlexception)
            {
                char2 = char1;
            }
        return char2;
    }

    private Datum[] cArrayToDatumArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        Datum adatum[] = null;
        if(obj != null)
            if(obj instanceof char[][])
            {
                char ac[][] = (char[][])(char[][])obj;
                int j = (int)(i != -1 ? Math.min(((long)ac.length - l) + 1L, i) : ac.length);
                adatum = new Datum[j];
                for(int j2 = 0; j2 < j; j2++)
                    adatum[j2] = new CHAR(new String(ac[((int)l + j2) - 1]), pickleCharacterSet);

            } else
            if(obj instanceof boolean[])
            {
                boolean aflag[] = (boolean[])(boolean[])obj;
                int k = (int)(i != -1 ? Math.min(((long)aflag.length - l) + 1L, i) : aflag.length);
                adatum = new Datum[k];
                for(int k2 = 0; k2 < k; k2++)
                    adatum[k2] = new CHAR(Boolean.valueOf(aflag[((int)l + k2) - 1]), pickleCharacterSet);

            } else
            if(obj instanceof short[])
            {
                short aword0[] = (short[])(short[])obj;
                int i1 = (int)(i != -1 ? Math.min(((long)aword0.length - l) + 1L, i) : aword0.length);
                adatum = new Datum[i1];
                for(int l2 = 0; l2 < i1; l2++)
                    adatum[l2] = new CHAR(Integer.valueOf(aword0[((int)l + l2) - 1]), pickleCharacterSet);

            } else
            if(obj instanceof int[])
            {
                int ai[] = (int[])(int[])obj;
                int j1 = (int)(i != -1 ? Math.min(((long)ai.length - l) + 1L, i) : ai.length);
                adatum = new Datum[j1];
                for(int i3 = 0; i3 < j1; i3++)
                    adatum[i3] = new CHAR(Integer.valueOf(ai[((int)l + i3) - 1]), pickleCharacterSet);

            } else
            if(obj instanceof long[])
            {
                long al[] = (long[])(long[])obj;
                int k1 = (int)(i != -1 ? Math.min(((long)al.length - l) + 1L, i) : al.length);
                adatum = new Datum[k1];
                for(int j3 = 0; j3 < k1; j3++)
                    adatum[j3] = new CHAR(new Long(al[((int)l + j3) - 1]), pickleCharacterSet);

            } else
            if(obj instanceof float[])
            {
                float af[] = (float[])(float[])obj;
                int l1 = (int)(i != -1 ? Math.min(((long)af.length - l) + 1L, i) : af.length);
                adatum = new Datum[l1];
                for(int k3 = 0; k3 < l1; k3++)
                    adatum[k3] = new CHAR(new Float(af[((int)l + k3) - 1]), pickleCharacterSet);

            } else
            if(obj instanceof double[])
            {
                double ad[] = (double[])(double[])obj;
                int i2 = (int)(i != -1 ? Math.min(((long)ad.length - l) + 1L, i) : ad.length);
                adatum = new Datum[i2];
                for(int l3 = 0; l3 < i2; l3++)
                    adatum[l3] = new CHAR(new Double(ad[((int)l + l3) - 1]), pickleCharacterSet);

            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return adatum;
    }

    public int getLength()
    {
        return length;
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeInt(form);
        objectoutputstream.writeInt(charset);
        objectoutputstream.writeInt(length);
        objectoutputstream.writeInt(characterSemantic);
        objectoutputstream.writeShort(pickleCharaterSetId);
        objectoutputstream.writeShort(pickleNcharCharacterSet);
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        form = objectinputstream.readInt();
        charset = objectinputstream.readInt();
        length = objectinputstream.readInt();
        characterSemantic = objectinputstream.readInt();
        pickleCharaterSetId = objectinputstream.readShort();
        pickleNcharCharacterSet = objectinputstream.readShort();
        if(pickleNcharCharacterSet != 0)
            pickleCharacterSet = CharacterSet.make(pickleNcharCharacterSet);
        else
            pickleCharacterSet = CharacterSet.make(pickleCharaterSetId);
    }

    public void setConnection(OracleConnection oracleconnection)
        throws SQLException
    {
        connection = oracleconnection;
    }

    public boolean isNCHAR()
        throws SQLException
    {
        return form == 2;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
