// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeUPT.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleTypeADT, OracleTypeCOLLECTION, OracleTypeOPAQUE, OracleNamedType, 
//            PickleContext, TDSReader, OracleType

public class OracleTypeUPT extends OracleTypeADT
    implements Serializable
{

    static final long serialVersionUID = 0xe4529d87b00602b9L;
    static final byte KOPU_UPT_ADT = -6;
    static final byte KOPU_UPT_COLL = -5;
    static final byte KOPU_UPT_REFCUR = 102;
    static final byte KOTTCOPQ = 58;
    byte uptCode;
    OracleNamedType realType;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleTypeUPT()
    {
        uptCode = 0;
        realType = null;
    }

    public OracleTypeUPT(String s, OracleConnection oracleconnection)
        throws SQLException
    {
        super(s, oracleconnection);
        uptCode = 0;
        realType = null;
    }

    public OracleTypeUPT(OracleTypeADT oracletypeadt, int i, OracleConnection oracleconnection)
        throws SQLException
    {
        super(oracletypeadt, i, oracleconnection);
        uptCode = 0;
        realType = null;
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        if(obj != null)
            return realType.toDatum(obj, oracleconnection);
        else
            return null;
    }

    public Datum[] toDatumArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        if(obj != null)
            return realType.toDatumArray(obj, oracleconnection, l, i);
        else
            return null;
    }

    public int getTypeCode()
        throws SQLException
    {
        switch(uptCode)
        {
        case -6: 
            return realType.getTypeCode();

        case -5: 
            return 2003;

        case 58: // ':'
            return 2007;
        }
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid type code");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public boolean isInHierarchyOf(OracleType oracletype)
        throws SQLException
    {
        return false;
    }

    public boolean isInHierarchyOf(StructDescriptor structdescriptor)
        throws SQLException
    {
        return false;
    }

    public boolean isObjectType()
    {
        return false;
    }

    public void parseTDSrec(TDSReader tdsreader)
        throws SQLException
    {
        long l = tdsreader.readLong();
        uptCode = tdsreader.readByte();
        tdsreader.addNormalPatch(l, uptCode, this);
    }

    protected int pickle81(PickleContext picklecontext, Datum datum)
        throws SQLException
    {
        int i = 0;
        if(datum == null)
        {
            i += picklecontext.writeElementNull();
        } else
        {
            int j = picklecontext.offset();
            i += picklecontext.writeLength(PickleContext.KOPI20_LN_MAXV + 1);
            int k = 0;
            if(uptCode == -6 && !((OracleTypeADT)realType).isFinalType())
            {
                if(datum instanceof STRUCT)
                {
                    k = ((STRUCT)datum).getDescriptor().getOracleTypeADT().pickle81(picklecontext, datum);
                } else
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "invalid upt state");
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
            } else
            {
                k = realType.pickle81(picklecontext, datum);
            }
            i += k;
            picklecontext.patchImageLen(j, k);
        }
        return i;
    }

    protected Object unpickle81rec(PickleContext picklecontext, int i, Map map)
        throws SQLException
    {
        byte byte0 = picklecontext.readByte();
        PickleContext _tmp = picklecontext;
        if(PickleContext.isElementNull(byte0))
            return null;
        if(i == 9)
        {
            picklecontext.skipBytes(picklecontext.readRestOfLength(byte0));
            return null;
        } else
        {
            picklecontext.skipRestOfLength(byte0);
            return unpickle81UPT(picklecontext, i, map);
        }
    }

    protected Object unpickle81rec(PickleContext picklecontext, byte byte0, int i, Map map)
        throws SQLException
    {
        long l = picklecontext.readRestOfLength(byte0);
        if(i == 9)
        {
            picklecontext.skipBytes((int)l);
            return null;
        } else
        {
            return unpickle81UPT(picklecontext, i, map);
        }
    }

    private Object unpickle81UPT(PickleContext picklecontext, int i, Map map)
        throws SQLException
    {
        switch(uptCode)
        {
        case -6: 
            switch(i)
            {
            case 1: // '\001'
                return ((OracleTypeADT)realType).unpickle81(picklecontext, (STRUCT)null, 3, i, map);

            case 2: // '\002'
                STRUCT struct = ((OracleTypeADT)realType).unpickle81(picklecontext, (STRUCT)null, 1, i, map);
                return struct != null ? struct.toJdbc(map) : struct;

            case 9: // '\t'
                return ((OracleTypeADT)realType).unpickle81(picklecontext, (STRUCT)null, 9, 1, map);
            }
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;

        case -5: 
            return ((OracleTypeCOLLECTION)realType).unpickle81(picklecontext, (ARRAY)null, i != 9 ? 3 : i, i, map);

        case 58: // ':'
            switch(i)
            {
            case 1: // '\001'
            case 9: // '\t'
                return ((OracleTypeOPAQUE)realType).unpickle81(picklecontext, (OPAQUE)null, i, map);

            case 2: // '\002'
                OPAQUE opaque = ((OracleTypeOPAQUE)realType).unpickle81(picklecontext, (OPAQUE)null, i, map);
                return opaque != null ? opaque.toJdbc(map) : opaque;
            }
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Unrecognized UPT code");
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    protected Datum unpickle81datumAsNull(PickleContext picklecontext, byte byte0, byte byte1)
        throws SQLException
    {
        return null;
    }

    StructDescriptor createStructDescriptor()
        throws SQLException
    {
        StructDescriptor structdescriptor = null;
        if(sqlName == null)
            structdescriptor = new StructDescriptor((OracleTypeADT)realType, connection);
        else
            structdescriptor = StructDescriptor.createDescriptor(sqlName, connection);
        return structdescriptor;
    }

    ArrayDescriptor createArrayDescriptor()
        throws SQLException
    {
        ArrayDescriptor arraydescriptor = null;
        if(sqlName == null)
            arraydescriptor = new ArrayDescriptor((OracleTypeCOLLECTION)realType, connection);
        else
            arraydescriptor = ArrayDescriptor.createDescriptor(sqlName, connection);
        return arraydescriptor;
    }

    public OracleType getRealType()
        throws SQLException
    {
        return realType;
    }

    public int getNumAttrs()
        throws SQLException
    {
        return ((OracleTypeADT)realType).getNumAttrs();
    }

    public OracleType getAttrTypeAt(int i)
        throws SQLException
    {
        return ((OracleTypeADT)realType).getAttrTypeAt(i);
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeByte(uptCode);
        objectoutputstream.writeObject(realType);
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        uptCode = objectinputstream.readByte();
        realType = (OracleNamedType)objectinputstream.readObject();
    }

    public void setConnection(OracleConnection oracleconnection)
        throws SQLException
    {
        connection = oracleconnection;
        realType.setConnection(oracleconnection);
    }

    public void initChildNamesRecursively(Map map)
        throws SQLException
    {
        if(realType != null)
        {
            realType.setSqlName(sqlName);
            realType.initChildNamesRecursively(map);
        }
    }

    public void initMetadataRecursively()
        throws SQLException
    {
        initMetadata(connection);
        if(realType != null)
            realType.initMetadataRecursively();
    }

    public void cacheDescriptor()
        throws SQLException
    {
    }

    public void printXML(PrintWriter printwriter, int i, boolean flag)
        throws SQLException
    {
        for(int j = 0; j < i; j++)
            printwriter.print("  ");

        printwriter.println((new StringBuilder()).append("<OracleTypeUPT sqlName=\"").append(sqlName).append("\" ").append(" toid=\"").append(toid).append("\" ").append(">").toString());
        if(realType != null)
            realType.printXML(printwriter, i + 1, flag);
        for(int k = 0; k < i; k++)
            printwriter.print("  ");

        printwriter.println("</OracleTypeUPT>");
    }

    public void printXML(PrintWriter printwriter, int i)
        throws SQLException
    {
        printXML(printwriter, i, false);
    }

}
