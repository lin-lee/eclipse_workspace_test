// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   PickleOutputStream.java

package oracle.jdbc.oracore;

import java.io.ByteArrayOutputStream;

public class PickleOutputStream extends ByteArrayOutputStream
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public PickleOutputStream()
    {
    }

    public PickleOutputStream(int i)
    {
        super(i);
    }

    public synchronized int offset()
    {
        return count;
    }

    public synchronized void overwrite(int i, byte abyte0[], int j, int k)
    {
        if(j < 0 || j > abyte0.length || k < 0 || j + k > abyte0.length || j + k < 0 || i + k > buf.length)
            throw new IndexOutOfBoundsException();
        if(k == 0)
            return;
        for(int l = 0; l < k; l++)
            buf[i + l] = abyte0[j + l];

    }

}
