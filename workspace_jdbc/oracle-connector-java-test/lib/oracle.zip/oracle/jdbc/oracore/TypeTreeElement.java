// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   TypeTreeElement.java

package oracle.jdbc.oracore;

import java.io.PrintWriter;
import java.io.StringWriter;

public class TypeTreeElement
{

    String schemaName;
    String typeName;
    String childSchemaNames[];
    String childTypeNames[];
    int size;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public TypeTreeElement(String s, String s1)
    {
        schemaName = null;
        typeName = null;
        childSchemaNames = null;
        childTypeNames = null;
        size = 0;
        schemaName = s;
        typeName = s1;
    }

    public void putChild(String s, String s1, int i)
    {
        if(childTypeNames == null)
        {
            int j = 10;
            if(i > j)
                j = i * 2;
            childSchemaNames = new String[j];
            childTypeNames = new String[j];
        }
        if(i >= childTypeNames.length)
        {
            int k = (i + 10) * 2;
            String as[] = new String[k];
            System.arraycopy(childSchemaNames, 0, as, 0, childSchemaNames.length);
            childSchemaNames = as;
            as = new String[k];
            System.arraycopy(childTypeNames, 0, as, 0, childTypeNames.length);
            childTypeNames = as;
        }
        childSchemaNames[i] = s;
        childTypeNames[i] = s1;
        if(i > size)
            size = i;
    }

    public String getChildSchemaName(int i)
    {
        return childSchemaNames[i];
    }

    public String getChildTypeName(int i)
    {
        return childTypeNames[i];
    }

    public String toString()
    {
        StringWriter stringwriter = new StringWriter();
        PrintWriter printwriter = new PrintWriter(stringwriter);
        printwriter.println((new StringBuilder()).append("schemaName: ").append(schemaName).append(" typeName: ").append(typeName).toString());
        for(int i = 0; i < size; i++)
            printwriter.println((new StringBuilder()).append("index: ").append(i).append(" schema name: ").append(childSchemaNames[i]).append(" type name: ").append(childTypeNames[i]).toString());

        return stringwriter.getBuffer().substring(0);
    }

}
