// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeSINT32.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType, OracleTypeNUMBER

public class OracleTypeSINT32 extends OracleType
    implements Serializable
{

    static final long serialVersionUID = 0xb424e88342d2fe18L;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleTypeSINT32()
    {
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        return OracleTypeNUMBER.toNUMBER(obj, oracleconnection);
    }

    public Datum[] toDatumArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        return OracleTypeNUMBER.toNUMBERArray(obj, oracleconnection, l, i);
    }

    public int getTypeCode()
    {
        return 2;
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        return OracleTypeNUMBER.toNumericObject(abyte0, i, map);
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
    }

}
