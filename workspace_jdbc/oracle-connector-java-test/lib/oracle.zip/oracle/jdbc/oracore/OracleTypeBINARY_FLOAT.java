// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeBINARY_FLOAT.java

package oracle.jdbc.oracore;

import java.io.Serializable;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType

public class OracleTypeBINARY_FLOAT extends OracleType
    implements Serializable
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleTypeBINARY_FLOAT()
    {
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        BINARY_FLOAT binary_float = null;
        if(obj != null)
            if(obj instanceof BINARY_FLOAT)
                binary_float = (BINARY_FLOAT)obj;
            else
            if(obj instanceof Float)
                binary_float = new BINARY_FLOAT((Float)obj);
            else
            if(obj instanceof byte[])
            {
                binary_float = new BINARY_FLOAT((byte[])(byte[])obj);
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return binary_float;
    }

    public Datum[] toDatumArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        Datum adatum[] = null;
        if(obj != null && (obj instanceof Object[]))
        {
            Object aobj[] = (Object[])(Object[])obj;
            int j = (int)(i != -1 ? Math.min(((long)aobj.length - l) + 1L, i) : aobj.length);
            adatum = new Datum[j];
            for(int k = 0; k < j; k++)
            {
                Object obj1 = aobj[((int)l + k) - 1];
                if(obj1 != null)
                {
                    if(obj1 instanceof Float)
                    {
                        adatum[k] = new BINARY_FLOAT(((Float)obj1).floatValue());
                        continue;
                    }
                    if(obj1 instanceof BINARY_FLOAT)
                    {
                        adatum[k] = (BINARY_FLOAT)obj1;
                    } else
                    {
                        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                        sqlexception.fillInStackTrace();
                        throw sqlexception;
                    }
                } else
                {
                    adatum[k] = null;
                }
            }

        }
        return adatum;
    }

    public int getTypeCode()
    {
        return 100;
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        if(abyte0 == null || abyte0.length == 0)
            return null;
        if(i == 1)
            return new BINARY_FLOAT(abyte0);
        if(i == 2)
            return (new BINARY_FLOAT(abyte0)).toJdbc();
        if(i == 3)
        {
            return abyte0;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, abyte0);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

}
