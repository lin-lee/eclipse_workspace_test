// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeNUMBER.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.Datum;
import oracle.sql.NUMBER;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType, TDSReader, PickleContext

public class OracleTypeNUMBER extends OracleType
    implements Serializable
{

    static final long serialVersionUID = 0x9c538c25d105fd9cL;
    int precision;
    int scale;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleTypeNUMBER()
    {
    }

    protected OracleTypeNUMBER(int i)
    {
        super(i);
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        return toNUMBER(obj, oracleconnection);
    }

    public Datum[] toDatumArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        return toNUMBERArray(obj, oracleconnection, l, i);
    }

    public void parseTDSrec(TDSReader tdsreader)
        throws SQLException
    {
        precision = tdsreader.readUnsignedByte();
        scale = tdsreader.readByte();
    }

    protected static Object unpickle81NativeArray(PickleContext picklecontext, long l, int i, int j)
        throws SQLException
    {
        for(int k = 1; (long)k < l && i > 0; k++)
            picklecontext.skipDataValue();

        Object obj = null;
        switch(j)
        {
        case 4: // '\004'
            int ai[] = new int[i];
            for(int i1 = 0; i1 < i; i1++)
            {
                byte abyte0[];
                if((abyte0 = picklecontext.readDataValue()) != null)
                    ai[i1] = NUMBER.toInt(abyte0);
            }

            return ai;

        case 5: // '\005'
            double ad[] = new double[i];
            for(int j1 = 0; j1 < i; j1++)
            {
                byte abyte1[];
                if((abyte1 = picklecontext.readDataValue()) != null)
                    ad[j1] = NUMBER.toDouble(abyte1);
            }

            return ad;

        case 7: // '\007'
            long al[] = new long[i];
            for(int k1 = 0; k1 < i; k1++)
            {
                byte abyte2[];
                if((abyte2 = picklecontext.readDataValue()) != null)
                    al[k1] = NUMBER.toLong(abyte2);
            }

            return al;

        case 6: // '\006'
            float af[] = new float[i];
            for(int l1 = 0; l1 < i; l1++)
            {
                byte abyte3[];
                if((abyte3 = picklecontext.readDataValue()) != null)
                    af[l1] = NUMBER.toFloat(abyte3);
            }

            return af;

        case 8: // '\b'
            short aword0[] = new short[i];
            for(int i2 = 0; i2 < i; i2++)
            {
                byte abyte4[];
                if((abyte4 = picklecontext.readDataValue()) != null)
                    aword0[i2] = NUMBER.toShort(abyte4);
            }

            return aword0;
        }
        SQLException sqlexception = DatabaseError.createSqlException(null, 23);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        return toNumericObject(abyte0, i, map);
    }

    static Object toNumericObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        if(abyte0 == null || abyte0.length == 0)
            return null;
        switch(i)
        {
        case 1: // '\001'
            return new NUMBER(abyte0);

        case 2: // '\002'
            return NUMBER.toBigDecimal(abyte0);

        case 3: // '\003'
            return abyte0;
        }
        SQLException sqlexception = DatabaseError.createSqlException(null, 23);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public static NUMBER toNUMBER(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        NUMBER number = null;
        if(obj != null)
            try
            {
                if(obj instanceof NUMBER)
                    number = (NUMBER)obj;
                else
                    number = new NUMBER(obj);
            }
            catch(SQLException sqlexception)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(null, 59, obj);
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        return number;
    }

    public static Datum[] toNUMBERArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        Datum adatum[] = null;
        if(obj != null)
            if((obj instanceof Object[]) && !(obj instanceof char[][]))
            {
                Object aobj[] = (Object[])(Object[])obj;
                int j = (int)(i != -1 ? Math.min(((long)aobj.length - l) + 1L, i) : aobj.length);
                adatum = new Datum[j];
                for(int k = 0; k < j; k++)
                    adatum[k] = toNUMBER(aobj[((int)l + k) - 1], oracleconnection);

            } else
            {
                adatum = cArrayToNUMBERArray(obj, oracleconnection, l, i);
            }
        return adatum;
    }

    static Datum[] cArrayToNUMBERArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        Datum adatum[] = null;
        if(obj != null)
            if(obj instanceof short[])
            {
                short aword0[] = (short[])(short[])obj;
                int j = (int)(i != -1 ? Math.min(((long)aword0.length - l) + 1L, i) : aword0.length);
                adatum = new Datum[j];
                for(int j2 = 0; j2 < j; j2++)
                    adatum[j2] = new NUMBER(aword0[((int)l + j2) - 1]);

            } else
            if(obj instanceof int[])
            {
                int ai[] = (int[])(int[])obj;
                int k = (int)(i != -1 ? Math.min(((long)ai.length - l) + 1L, i) : ai.length);
                adatum = new Datum[k];
                for(int k2 = 0; k2 < k; k2++)
                    adatum[k2] = new NUMBER(ai[((int)l + k2) - 1]);

            } else
            if(obj instanceof long[])
            {
                long al[] = (long[])(long[])obj;
                int i1 = (int)(i != -1 ? Math.min(((long)al.length - l) + 1L, i) : al.length);
                adatum = new Datum[i1];
                for(int l2 = 0; l2 < i1; l2++)
                    adatum[l2] = new NUMBER(al[((int)l + l2) - 1]);

            } else
            if(obj instanceof float[])
            {
                float af[] = (float[])(float[])obj;
                int j1 = (int)(i != -1 ? Math.min(((long)af.length - l) + 1L, i) : af.length);
                adatum = new Datum[j1];
                for(int i3 = 0; i3 < j1; i3++)
                    adatum[i3] = new NUMBER(af[((int)l + i3) - 1]);

            } else
            if(obj instanceof double[])
            {
                double ad[] = (double[])(double[])obj;
                int k1 = (int)(i != -1 ? Math.min(((long)ad.length - l) + 1L, i) : ad.length);
                adatum = new Datum[k1];
                for(int j3 = 0; j3 < k1; j3++)
                    adatum[j3] = new NUMBER(ad[((int)l + j3) - 1]);

            } else
            if(obj instanceof boolean[])
            {
                boolean aflag[] = (boolean[])(boolean[])obj;
                int l1 = (int)(i != -1 ? Math.min(((long)aflag.length - l) + 1L, i) : aflag.length);
                adatum = new Datum[l1];
                for(int k3 = 0; k3 < l1; k3++)
                    adatum[k3] = new NUMBER(Boolean.valueOf(aflag[((int)l + k3) - 1]));

            } else
            if(obj instanceof char[][])
            {
                char ac[][] = (char[][])(char[][])obj;
                int i2 = (int)(i != -1 ? Math.min(((long)ac.length - l) + 1L, i) : ac.length);
                adatum = new Datum[i2];
                for(int l3 = 0; l3 < i2; l3++)
                    adatum[l3] = new NUMBER(new String(ac[((int)l + l3) - 1]));

            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(null, 59, obj);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return adatum;
    }

    public int getPrecision()
    {
        return precision;
    }

    public int getScale()
    {
        return scale;
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeInt(scale);
        objectoutputstream.writeInt(precision);
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        scale = objectinputstream.readInt();
        precision = objectinputstream.readInt();
    }

}
