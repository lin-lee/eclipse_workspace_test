// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeOPAQUE.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleTypeADT, PickleContext, OracleType, TDSReader

public class OracleTypeOPAQUE extends OracleTypeADT
    implements Serializable
{

    static final long KOLOFLLB = 1L;
    static final long KOLOFLCL = 2L;
    static final long KOLOFLUB = 4L;
    static final long KOLOFLFX = 8L;
    static final long serialVersionUID = 0x9af9872d9cec8e7eL;
    long flagBits;
    long maxLen;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleTypeOPAQUE(byte abyte0[], int i, int j, short word0, String s, long l)
        throws SQLException
    {
        super(abyte0, i, j, word0, s);
        flagBits = l;
        flattenedAttrNum = 1;
    }

    public OracleTypeOPAQUE(String s, OracleConnection oracleconnection)
        throws SQLException
    {
        super(s, oracleconnection);
    }

    public OracleTypeOPAQUE(OracleTypeADT oracletypeadt, int i, OracleConnection oracleconnection)
        throws SQLException
    {
        super(oracletypeadt, i, oracleconnection);
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        if(obj != null)
        {
            if(obj instanceof OPAQUE)
            {
                return (OPAQUE)obj;
            } else
            {
                OpaqueDescriptor opaquedescriptor = createOpaqueDescriptor();
                return new OPAQUE(opaquedescriptor, connection, obj);
            }
        } else
        {
            return null;
        }
    }

    public int getTypeCode()
    {
        return 2007;
    }

    public boolean isInHierarchyOf(OracleType oracletype)
        throws SQLException
    {
        if(oracletype == null)
            return false;
        if(!(oracletype instanceof OracleTypeOPAQUE))
        {
            return false;
        } else
        {
            OpaqueDescriptor opaquedescriptor = (OpaqueDescriptor)oracletype.getTypeDescriptor();
            return descriptor.isInHierarchyOf(opaquedescriptor.getName());
        }
    }

    public boolean isInHierarchyOf(StructDescriptor structdescriptor)
        throws SQLException
    {
        return false;
    }

    public boolean isObjectType()
    {
        return false;
    }

    public void parseTDSrec(TDSReader tdsreader)
        throws SQLException
    {
        tdsreader.skipBytes(5);
        flagBits = tdsreader.readLong();
        maxLen = tdsreader.readLong();
    }

    public Datum unlinearize(byte abyte0[], long l, Datum datum, int i, Map map)
        throws SQLException
    {
        if(abyte0 == null)
            return null;
        if((abyte0[0] & 0x80) > 0)
        {
            PickleContext picklecontext = new PickleContext(abyte0, l);
            return unpickle81(picklecontext, (OPAQUE)datum, i, map);
        } else
        {
            return null;
        }
    }

    public byte[] linearize(Datum datum)
        throws SQLException
    {
        return pickle81(datum);
    }

    protected int pickle81(PickleContext picklecontext, Datum datum)
        throws SQLException
    {
        OPAQUE opaque = (OPAQUE)datum;
        byte abyte0[] = opaque.getBytesValue();
        int i = 0;
        i += picklecontext.writeOpaqueImageHeader(abyte0.length);
        i += picklecontext.writeData(abyte0);
        return i;
    }

    OPAQUE unpickle81(PickleContext picklecontext, OPAQUE opaque, int i, Map map)
        throws SQLException
    {
        return unpickle81datum(picklecontext, opaque, i);
    }

    protected Object unpickle81rec(PickleContext picklecontext, int i, Map map)
        throws SQLException
    {
        byte byte0 = picklecontext.readByte();
        Object obj = null;
        PickleContext _tmp = picklecontext;
        if(PickleContext.isElementNull(byte0))
            return null;
        picklecontext.skipRestOfLength(byte0);
        switch(i)
        {
        case 1: // '\001'
            obj = unpickle81datum(picklecontext, null);
            break;

        case 2: // '\002'
            obj = unpickle81datum(picklecontext, null).toJdbc();
            break;

        case 3: // '\003'
            obj = new OPAQUE(createOpaqueDescriptor(), picklecontext.readDataValue(), connection);
            break;

        case 9: // '\t'
            picklecontext.skipDataValue();
            break;

        case 4: // '\004'
        case 5: // '\005'
        case 6: // '\006'
        case 7: // '\007'
        case 8: // '\b'
        default:
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        return obj;
    }

    private OPAQUE unpickle81datum(PickleContext picklecontext, OPAQUE opaque)
        throws SQLException
    {
        return unpickle81datum(picklecontext, opaque, 1);
    }

    private OPAQUE unpickle81datum(PickleContext picklecontext, OPAQUE opaque, int i)
        throws SQLException
    {
        picklecontext.skipBytes(2);
        long l = picklecontext.readLength(true) - 2;
        if(opaque == null)
        {
            if(i == 2)
                return new OPAQUE(createOpaqueDescriptor(), connection, picklecontext.readBytes((int)l));
            else
                return new OPAQUE(createOpaqueDescriptor(), connection, picklecontext.readBytes((int)l));
        } else
        {
            opaque.setValue(picklecontext.readBytes((int)l));
            return opaque;
        }
    }

    OpaqueDescriptor createOpaqueDescriptor()
        throws SQLException
    {
        if(sqlName == null)
            return new OpaqueDescriptor(this, connection);
        else
            return OpaqueDescriptor.createDescriptor(sqlName, connection);
    }

    public long getMaxLength()
        throws SQLException
    {
        return maxLen;
    }

    public boolean isTrustedLibrary()
        throws SQLException
    {
        return (flagBits & 1L) != 0L;
    }

    public boolean isModeledInC()
        throws SQLException
    {
        return (flagBits & 2L) != 0L;
    }

    public boolean isUnboundedSized()
        throws SQLException
    {
        return (flagBits & 4L) != 0L;
    }

    public boolean isFixedSized()
        throws SQLException
    {
        return (flagBits & 8L) != 0L;
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
    }

    public void setConnection(OracleConnection oracleconnection)
        throws SQLException
    {
        connection = oracleconnection;
    }

}
