// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   TDSReader.java

package oracle.jdbc.oracore;

import java.sql.SQLException;
import java.util.Vector;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.oracore:
//            TDSPatch, OracleType

public class TDSReader
{

    static final int KOPT_NONE_FINAL_TYPE = 1;
    static final int KOPT_JAVA_OBJECT = 2;
    long fixedDataSize;
    Vector patches;
    byte tds[];
    int beginIndex;
    int index;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    TDSReader(byte abyte0[], long l)
    {
        fixedDataSize = 0L;
        patches = null;
        tds = abyte0;
        beginIndex = (int)l;
        index = (int)l;
    }

    void skipBytes(int i)
        throws SQLException
    {
        index += i;
    }

    void checkNextByte(byte byte0)
        throws SQLException
    {
        if(byte0 != tds[index])
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        index++;
        break MISSING_BLOCK_LABEL_58;
        Exception exception;
        exception;
        index++;
        throw exception;
    }

    byte readByte()
        throws SQLException
    {
        byte byte0 = tds[index];
        index++;
        return byte0;
        Exception exception;
        exception;
        index++;
        throw exception;
    }

    int readUnsignedByte()
        throws SQLException
    {
        int i = tds[index] & 0xff;
        index++;
        return i;
        Exception exception;
        exception;
        index++;
        throw exception;
    }

    int readUB2()
        throws SQLException
    {
        int i = ((tds[index] & 0xff) << 8) + (tds[index + 1] & 0xff);
        index += 2;
        return i;
        Exception exception;
        exception;
        index += 2;
        throw exception;
    }

    long readLong()
        throws SQLException
    {
        long l = (((tds[index] & 0xff) * 256 + (tds[index + 1] & 0xff)) * 256 + (tds[index + 2] & 0xff)) * 256 + (tds[index + 3] & 0xff);
        index += 4;
        return l;
        Exception exception;
        exception;
        index += 4;
        throw exception;
    }

    void addNormalPatch(long l, byte byte0, OracleType oracletype)
        throws SQLException
    {
        addPatch(new TDSPatch(0, oracletype, l, byte0));
    }

    void addSimplePatch(long l, OracleType oracletype)
        throws SQLException
    {
        addPatch(new TDSPatch(1, oracletype, l, 0));
    }

    void addPatch(TDSPatch tdspatch)
        throws SQLException
    {
        if(patches == null)
            patches = new Vector(5);
        patches.addElement(tdspatch);
    }

    long moveToPatchPos(TDSPatch tdspatch)
        throws SQLException
    {
        long l = tdspatch.getPosition();
        if((long)beginIndex + l > (long)tds.length)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            skip_to(l);
            return l;
        }
    }

    TDSPatch getNextPatch()
        throws SQLException
    {
        TDSPatch tdspatch = null;
        if(patches != null && patches.size() > 0)
        {
            tdspatch = (TDSPatch)patches.firstElement();
            patches.removeElementAt(0);
        }
        return tdspatch;
    }

    void skip_to(long l)
    {
        index = beginIndex + (int)l;
    }

    long offset()
        throws SQLException
    {
        return (long)(index - beginIndex);
    }

    long absoluteOffset()
        throws SQLException
    {
        return (long)index;
    }

    byte[] tds()
        throws SQLException
    {
        return tds;
    }

    boolean isJavaObject(int i, byte byte0)
    {
        return i >= 3 && (byte0 & 2) != 0;
    }

    boolean isFinalType(int i, byte byte0)
    {
        return i >= 3 && (byte0 & 1) == 0;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
