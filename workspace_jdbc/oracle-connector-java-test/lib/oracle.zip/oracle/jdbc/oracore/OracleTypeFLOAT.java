// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeFLOAT.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType, OracleTypeNUMBER, TDSReader, PickleContext

public class OracleTypeFLOAT extends OracleType
    implements Serializable
{

    static final long serialVersionUID = 0x38be7bb97b7a5965L;
    int precision;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleTypeFLOAT()
    {
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        return OracleTypeNUMBER.toNUMBER(obj, oracleconnection);
    }

    public Datum[] toDatumArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        return OracleTypeNUMBER.toNUMBERArray(obj, oracleconnection, l, i);
    }

    public int getTypeCode()
    {
        return 6;
    }

    public void parseTDSrec(TDSReader tdsreader)
        throws SQLException
    {
        precision = tdsreader.readUnsignedByte();
    }

    public int getScale()
    {
        return -127;
    }

    public int getPrecision()
    {
        return precision;
    }

    protected static Object unpickle81NativeArray(PickleContext picklecontext, long l, int i, int j)
        throws SQLException
    {
        return OracleTypeNUMBER.unpickle81NativeArray(picklecontext, l, i, j);
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        return OracleTypeNUMBER.toNumericObject(abyte0, i, map);
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeInt(precision);
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        precision = objectinputstream.readInt();
    }

}
