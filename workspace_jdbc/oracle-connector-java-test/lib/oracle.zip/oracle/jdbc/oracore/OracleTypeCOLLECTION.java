// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeCOLLECTION.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.*;
import java.util.Map;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleTypeADT, PickleContext, OracleTypeNUMBER, OracleTypeFLOAT, 
//            OracleType, TypeTreeElement, TDSReader

public class OracleTypeCOLLECTION extends OracleTypeADT
    implements Serializable
{

    static final long serialVersionUID = 0x9af9872d9cec8e7eL;
    public static final int TYPE_PLSQL_INDEX_TABLE = 1;
    public static final int TYPE_NESTED_TABLE = 2;
    public static final int TYPE_VARRAY = 3;
    int userCode;
    long maxSize;
    OracleType elementType;
    static final int CURRENT_USER_OBJECT = 0;
    static final int CURRENT_USER_SYNONYM = 1;
    static final int CURRENT_USER_SYNONYM_10g = 2;
    static final int CURRENT_USER_PUBLIC_SYNONYM = 3;
    static final int CURRENT_USER_PUBLIC_SYNONYM_10g = 4;
    static final int POSSIBLY_OTHER_USER_OBJECT = 5;
    static final int POSSIBLY_OTHER_USER_OBJECT_10g = 6;
    static final int OTHER_USER_OBJECT = 7;
    static final int OTHER_USER_SYNONYM = 8;
    static final int PUBLIC_SYNONYM = 9;
    static final int PUBLIC_SYNONYM_10g = 10;
    static final int BREAK = 11;
    static final String sqlString[] = {
        "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME = :1", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL)", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL)", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE OWNER = :1 AND TYPE_NAME = :2", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE OWNER = (SELECT TABLE_OWNER FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:1) AND TYPE_NAME = (SELECT TABLE_NAME FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:2) ", "DECLARE   the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;", 
        "DECLARE   the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;"
    };
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleTypeCOLLECTION(String s, OracleConnection oracleconnection)
        throws SQLException
    {
        super(s, oracleconnection);
        userCode = 0;
        maxSize = 0L;
        elementType = null;
    }

    public OracleTypeCOLLECTION(OracleTypeADT oracletypeadt, int i, OracleConnection oracleconnection)
        throws SQLException
    {
        super(oracletypeadt, i, oracleconnection);
        userCode = 0;
        maxSize = 0L;
        elementType = null;
    }

    public OracleTypeCOLLECTION(SQLName sqlname, byte abyte0[], int i, byte abyte1[], OracleConnection oracleconnection)
        throws SQLException
    {
        super(sqlname, abyte0, i, abyte1, oracleconnection);
        userCode = 0;
        maxSize = 0L;
        elementType = null;
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        if(obj != null)
        {
            if(obj instanceof ARRAY)
            {
                return (ARRAY)obj;
            } else
            {
                ArrayDescriptor arraydescriptor = createArrayDescriptor();
                return new ARRAY(arraydescriptor, connection, obj);
            }
        } else
        {
            return null;
        }
    }

    public int getTypeCode()
    {
        return 2003;
    }

    public boolean isInHierarchyOf(OracleType oracletype)
        throws SQLException
    {
        if(oracletype == null)
            return false;
        if(oracletype == this)
            return true;
        if(oracletype.getClass() != getClass())
            return false;
        else
            return oracletype.getTypeDescriptor().getName().equals(descriptor.getName());
    }

    public boolean isInHierarchyOf(StructDescriptor structdescriptor)
        throws SQLException
    {
        return false;
    }

    public boolean isObjectType()
    {
        return false;
    }

    public void parseTDSrec(TDSReader tdsreader)
        throws SQLException
    {
        long l = tdsreader.readLong();
        maxSize = tdsreader.readLong();
        userCode = tdsreader.readByte();
        tdsreader.addSimplePatch(l, this);
    }

    public Datum unlinearize(byte abyte0[], long l, Datum datum, int i, Map map)
        throws SQLException
    {
        return unlinearize(abyte0, l, datum, 1L, -1, i, map);
    }

    public Datum unlinearize(byte abyte0[], long l, Datum datum, long l1, int i, 
            int j, Map map)
        throws SQLException
    {
        OracleConnection oracleconnection = getConnection();
        Datum datum1 = null;
        if(oracleconnection == null)
            datum1 = unlinearizeInternal(abyte0, l, datum, l1, i, j, map);
        else
            synchronized(oracleconnection)
            {
                datum1 = unlinearizeInternal(abyte0, l, datum, l1, i, j, map);
            }
        return datum1;
    }

    public synchronized Datum unlinearizeInternal(byte abyte0[], long l, Datum datum, long l1, int i, 
            int j, Map map)
        throws SQLException
    {
        if(abyte0 == null)
        {
            return null;
        } else
        {
            PickleContext picklecontext = new PickleContext(abyte0, l);
            return unpickle81(picklecontext, (ARRAY)datum, l1, i, 1, j, map);
        }
    }

    public synchronized boolean isInlineImage(byte abyte0[], int i)
        throws SQLException
    {
        if(abyte0 == null)
            return false;
        if(PickleContext.isCollectionImage_pctx(abyte0[i]))
            return true;
        if(PickleContext.isDegenerateImage_pctx(abyte0[i]))
        {
            return false;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not a collection image");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    protected int pickle81(PickleContext picklecontext, Datum datum)
        throws SQLException
    {
        ARRAY array = (ARRAY)datum;
        boolean flag = array.hasDataSeg();
        int i = 0;
        int j = picklecontext.offset() + 2;
        if(flag)
        {
            if(!metaDataInitialized)
                copy_properties((OracleTypeCOLLECTION)array.getDescriptor().getPickler());
            Datum adatum[] = array.getOracleArray();
            if(userCode == 3 && (long)adatum.length > maxSize)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 71, null);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            i += picklecontext.writeCollImageHeader(adatum.length, typeVersion);
            for(int k = 0; k < adatum.length; k++)
                if(adatum[k] == null)
                    i += picklecontext.writeElementNull();
                else
                    i += elementType.pickle81(picklecontext, adatum[k]);

        } else
        {
            i += picklecontext.writeCollImageHeader(array.getLocator());
        }
        picklecontext.patchImageLen(j, i);
        return i;
    }

    ARRAY unpickle81(PickleContext picklecontext, ARRAY array, int i, int j, Map map)
        throws SQLException
    {
        return unpickle81(picklecontext, array, 1L, -1, i, j, map);
    }

    ARRAY unpickle81(PickleContext picklecontext, ARRAY array, long l, int i, int j, int k, 
            Map map)
        throws SQLException
    {
        ARRAY array1 = array;
        if(array1 == null)
        {
            ArrayDescriptor arraydescriptor = createArrayDescriptor();
            array1 = new ARRAY(arraydescriptor, (byte[])null, connection);
        }
        if(unpickle81ImgHeader(picklecontext, array1, j, k))
            if(l == 1L && i == -1)
                unpickle81ImgBody(picklecontext, array1, k, map);
            else
                unpickle81ImgBody(picklecontext, array1, l, i, k, map);
        return array1;
    }

    boolean unpickle81ImgHeader(PickleContext picklecontext, ARRAY array, int i, int j)
        throws SQLException
    {
        boolean flag = true;
        if(i == 3)
            array.setImage(picklecontext.image(), picklecontext.absoluteOffset(), 0L);
        byte byte0 = picklecontext.readByte();
        PickleContext _tmp = picklecontext;
        if(!PickleContext.is81format(byte0))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not in 8.1 format");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        PickleContext _tmp1 = picklecontext;
        if(!PickleContext.hasPrefix(byte0))
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image has no prefix segment");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        PickleContext _tmp2 = picklecontext;
        if(PickleContext.isCollectionImage_pctx(byte0))
        {
            flag = true;
        } else
        {
            PickleContext _tmp3 = picklecontext;
            boolean flag1;
            if(PickleContext.isDegenerateImage_pctx(byte0))
            {
                flag1 = false;
            } else
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not a collection image");
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        }
        picklecontext.readByte();
        if(i == 9)
        {
            picklecontext.skipBytes(picklecontext.readLength(true) - 2);
            return false;
        }
        if(i == 3)
        {
            long l = picklecontext.readLength();
            array.setImageLength(l);
            picklecontext.skipTo(array.getImageOffset() + l);
            return false;
        }
        picklecontext.skipLength();
        int k = picklecontext.readLength();
        array.setPrefixFlag(picklecontext.readByte());
        if(array.isInline())
            picklecontext.readDataValue(k - 1);
        else
            array.setLocator(picklecontext.readDataValue(k - 1));
        return array.isInline();
    }

    void unpickle81ImgBody(PickleContext picklecontext, ARRAY array, long l, int i, int j, Map map)
        throws SQLException
    {
        picklecontext.readByte();
        int k = picklecontext.readLength();
        array.setLength(k);
        if(j == 0)
            return;
        int i1 = (int)getAccessLength(k, l, i);
        boolean flag = ArrayDescriptor.getCacheStyle(array) == 1;
        if(l > 1L && i1 > 0)
        {
            long l1 = array.getLastIndex();
            if(l1 < l)
            {
                if(l1 > 0L)
                    picklecontext.skipTo(array.getLastOffset());
                else
                    l1 = 1L;
                if(flag)
                {
                    for(long l2 = l1; l2 < l; l2++)
                    {
                        array.setIndexOffset(l2, picklecontext.offset());
                        elementType.unpickle81rec(picklecontext, 9, null);
                    }

                } else
                {
                    for(long l3 = l1; l3 < l; l3++)
                        elementType.unpickle81rec(picklecontext, 9, null);

                }
            } else
            if(l1 > l)
            {
                long l4 = array.getOffset(l);
                if(l4 != -1L)
                    picklecontext.skipTo(l4);
                else
                if(flag)
                {
                    for(int j1 = 1; (long)j1 < l; j1++)
                    {
                        array.setIndexOffset(j1, picklecontext.offset());
                        elementType.unpickle81rec(picklecontext, 9, null);
                    }

                } else
                {
                    for(int k1 = 1; (long)k1 < l; k1++)
                        elementType.unpickle81rec(picklecontext, 9, null);

                }
            } else
            {
                picklecontext.skipTo(array.getLastOffset());
            }
            array.setLastIndexOffset(l, picklecontext.offset());
        }
        unpickle81ImgBodyElements(picklecontext, array, (int)l, i1, j, map);
    }

    void unpickle81ImgBody(PickleContext picklecontext, ARRAY array, int i, Map map)
        throws SQLException
    {
        picklecontext.readByte();
        int j = picklecontext.readLength();
        array.setLength(j);
        if(i == 0)
        {
            return;
        } else
        {
            unpickle81ImgBodyElements(picklecontext, array, 1, j, i, map);
            return;
        }
    }

    private void unpickle81ImgBodyElements(PickleContext picklecontext, ARRAY array, int i, int j, int k, Map map)
        throws SQLException
    {
        boolean flag = ArrayDescriptor.getCacheStyle(array) == 1;
        switch(k)
        {
        case 1: // '\001'
            Datum adatum[] = new Datum[j];
            if(flag)
            {
                for(int l = 0; l < j; l++)
                {
                    array.setIndexOffset(i + l, picklecontext.offset());
                    adatum[l] = (Datum)elementType.unpickle81rec(picklecontext, k, map);
                }

            } else
            {
                for(int i1 = 0; i1 < j; i1++)
                    adatum[i1] = (Datum)elementType.unpickle81rec(picklecontext, k, map);

            }
            array.setDatumArray(adatum);
            break;

        case 2: // '\002'
            Object aobj[] = ArrayDescriptor.makeJavaArray(j, elementType.getTypeCode());
            if(flag)
            {
                for(int j1 = 0; j1 < j; j1++)
                {
                    array.setIndexOffset(i + j1, picklecontext.offset());
                    aobj[j1] = elementType.unpickle81rec(picklecontext, k, map);
                }

            } else
            {
                for(int k1 = 0; k1 < j; k1++)
                    aobj[k1] = elementType.unpickle81rec(picklecontext, k, map);

            }
            array.setObjArray(((Object) (aobj)));
            break;

        case 4: // '\004'
        case 5: // '\005'
        case 6: // '\006'
        case 7: // '\007'
        case 8: // '\b'
            if((elementType instanceof OracleTypeNUMBER) || (elementType instanceof OracleTypeFLOAT))
            {
                array.setObjArray(OracleTypeNUMBER.unpickle81NativeArray(picklecontext, 1L, j, k));
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "This feature is limited to numeric collection");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            break;

        case 3: // '\003'
        default:
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, (new StringBuilder()).append("Invalid conversion type ").append(elementType).toString());
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        array.setLastIndexOffset(i + j, picklecontext.offset());
    }

    private void initCollElemTypeName()
        throws SQLException
    {
        if(connection == null)
            return;
        OracleConnection oracleconnection = connection;
        JVM INSTR monitorenter ;
        CallableStatement callablestatement;
        PreparedStatement preparedstatement;
        ResultSet resultset;
        if(sqlName == null)
            getFullName();
        callablestatement = null;
        preparedstatement = null;
        resultset = null;
        byte byte0;
label0:
        {
label1:
            do
            {
                for(byte0 = ((byte)(sqlName.getSchema().equalsIgnoreCase(connection.getDefaultSchemaNameForNamedTypes()) ? 0 : 7)); byte0 != 11; byte0 = 11)
                {
                    switch(byte0)
                    {
                    case 0: // '\0'
                        preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
                        preparedstatement.setString(1, sqlName.getSimpleName());
                        preparedstatement.setFetchSize(1);
                        resultset = preparedstatement.executeQuery();
                        byte0 = 1;
                        break;

                    case 1: // '\001'
                        if(connection.getVersionNumber() >= 10000)
                            byte0 = 2;
                        // fall through

                    case 2: // '\002'
                        preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
                        preparedstatement.setString(1, sqlName.getSimpleName());
                        preparedstatement.setString(2, sqlName.getSimpleName());
                        preparedstatement.setFetchSize(1);
                        resultset = preparedstatement.executeQuery();
                        byte0 = 3;
                        break;

                    case 3: // '\003'
                        if(connection.getVersionNumber() >= 10000)
                            byte0 = 4;
                        // fall through

                    case 4: // '\004'
                        preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
                        preparedstatement.setString(1, sqlName.getSimpleName());
                        preparedstatement.setString(2, sqlName.getSimpleName());
                        preparedstatement.setFetchSize(1);
                        resultset = preparedstatement.executeQuery();
                        byte0 = 5;
                        break;

                    case 5: // '\005'
                        if(connection.getVersionNumber() >= 10000)
                            byte0 = 6;
                        // fall through

                    case 6: // '\006'
                        preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
                        preparedstatement.setString(1, sqlName.getSimpleName());
                        preparedstatement.setString(2, sqlName.getSimpleName());
                        preparedstatement.setFetchSize(1);
                        resultset = preparedstatement.executeQuery();
                        byte0 = 8;
                        break;

                    case 7: // '\007'
                        preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
                        preparedstatement.setString(1, sqlName.getSchema());
                        preparedstatement.setString(2, sqlName.getSimpleName());
                        preparedstatement.setFetchSize(1);
                        resultset = preparedstatement.executeQuery();
                        byte0 = 8;
                        break;

                    case 8: // '\b'
                        preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
                        preparedstatement.setString(1, sqlName.getSimpleName());
                        preparedstatement.setString(2, sqlName.getSimpleName());
                        preparedstatement.setFetchSize(1);
                        resultset = preparedstatement.executeQuery();
                        byte0 = 9;
                        break;

                    case 9: // '\t'
                        if(connection.getVersionNumber() >= 10000)
                            byte0 = 10;
                        // fall through

                    case 10: // '\n'
                        callablestatement = connection.prepareCall((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
                        callablestatement.setString(1, sqlName.getSimpleName());
                        callablestatement.registerOutParameter(2, -10);
                        callablestatement.execute();
                        resultset = ((OracleCallableStatement)callablestatement).getCursor(2);
                        byte0 = 11;
                        break;
                    }
                    if(!resultset.next())
                        continue label1;
                    if(attrTypeNames == null)
                        attrTypeNames = new String[1];
                    attrTypeNames[0] = (new StringBuilder()).append(resultset.getString(2)).append(".").append(resultset.getString(1)).toString();
                }

                break label0;
            } while(byte0 != 11);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        while(byte0 != 11) ;
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        if(callablestatement != null)
            callablestatement.close();
        break MISSING_BLOCK_LABEL_970;
        Exception exception;
        exception;
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        if(callablestatement != null)
            callablestatement.close();
        throw exception;
        Exception exception1;
        exception1;
        throw exception1;
    }

    public String getAttributeName(int i)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public String getAttributeName(int i, boolean flag)
        throws SQLException
    {
        return getAttributeName(i);
    }

    public String getAttributeType(int i)
        throws SQLException
    {
        if(i != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(sqlName == null)
            getFullName();
        if(attrTypeNames == null)
            initCollElemTypeName();
        return attrTypeNames[0];
    }

    public String getAttributeType(int i, boolean flag)
        throws SQLException
    {
        if(flag)
            return getAttributeType(i);
        if(i != 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(sqlName != null && attrTypeNames != null)
            return attrTypeNames[0];
        else
            return null;
    }

    public int getNumAttrs()
        throws SQLException
    {
        return 0;
    }

    public OracleType getAttrTypeAt(int i)
        throws SQLException
    {
        return null;
    }

    ArrayDescriptor createArrayDescriptor()
        throws SQLException
    {
        return new ArrayDescriptor(this, connection);
    }

    ArrayDescriptor createArrayDescriptorWithItsOwnTree()
        throws SQLException
    {
        if(descriptor == null)
            if(sqlName == null && getFullName(false) == null)
                descriptor = new ArrayDescriptor(this, connection);
            else
                descriptor = ArrayDescriptor.createDescriptor(sqlName, connection);
        return (ArrayDescriptor)descriptor;
    }

    public OracleType getElementType()
        throws SQLException
    {
        return elementType;
    }

    public int getUserCode()
        throws SQLException
    {
        return userCode;
    }

    public long getMaxLength()
        throws SQLException
    {
        return maxSize;
    }

    private long getAccessLength(long l, long l1, int i)
        throws SQLException
    {
        if(l1 > l)
            return 0L;
        if(i < 0)
            return (l - l1) + 1L;
        else
            return Math.min((l - l1) + 1L, i);
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeInt(userCode);
        objectoutputstream.writeLong(maxSize);
        objectoutputstream.writeObject(elementType);
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        userCode = objectinputstream.readInt();
        maxSize = objectinputstream.readLong();
        elementType = (OracleType)objectinputstream.readObject();
    }

    public void setConnection(OracleConnection oracleconnection)
        throws SQLException
    {
        connection = oracleconnection;
        elementType.setConnection(oracleconnection);
    }

    public void initMetadataRecursively()
        throws SQLException
    {
        initMetadata(connection);
        if(elementType != null)
            elementType.initMetadataRecursively();
    }

    public void initChildNamesRecursively(Map map)
        throws SQLException
    {
        TypeTreeElement typetreeelement = (TypeTreeElement)(TypeTreeElement)map.get(sqlName);
        if(elementType != null)
        {
            elementType.setNames(typetreeelement.getChildSchemaName(0), typetreeelement.getChildTypeName(0));
            elementType.initChildNamesRecursively(map);
            elementType.cacheDescriptor();
        }
    }

    public void cacheDescriptor()
        throws SQLException
    {
        descriptor = ArrayDescriptor.createDescriptor(this);
    }

    public void printXML(PrintWriter printwriter, int i)
        throws SQLException
    {
        printXML(printwriter, i, false);
    }

    public void printXML(PrintWriter printwriter, int i, boolean flag)
        throws SQLException
    {
        for(int j = 0; j < i; j++)
            printwriter.print("  ");

        printwriter.println((new StringBuilder()).append("<OracleTypeCOLLECTION sqlName=\"").append(sqlName).append("\" ").append(">").toString());
        if(elementType != null)
            elementType.printXML(printwriter, i + 1, flag);
        for(int k = 0; k < i; k++)
            printwriter.print("  ");

        printwriter.println("</OracleTypeCOLLECTION>");
    }

}
