// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeBLOB.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.BLOB;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleType

public class OracleTypeBLOB extends OracleType
    implements Serializable
{

    static final long serialVersionUID = 0xdfeced72c4ec51baL;
    static int fixedDataSize = 86;
    transient OracleConnection connection;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleTypeBLOB()
    {
    }

    public OracleTypeBLOB(OracleConnection oracleconnection)
    {
        connection = oracleconnection;
    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        BLOB blob = null;
        if(obj != null)
            if(obj instanceof BLOB)
            {
                blob = (BLOB)obj;
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return blob;
    }

    public int getTypeCode()
    {
        return 2004;
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        if(abyte0 == null || abyte0.length == 0)
            return null;
        switch(i)
        {
        case 1: // '\001'
        case 2: // '\002'
            return connection.createBlobWithUnpickledBytes(abyte0);

        case 3: // '\003'
            return abyte0;
        }
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, abyte0);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
    }

    public void setConnection(OracleConnection oracleconnection)
        throws SQLException
    {
        connection = oracleconnection;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return connection;
    }

}
