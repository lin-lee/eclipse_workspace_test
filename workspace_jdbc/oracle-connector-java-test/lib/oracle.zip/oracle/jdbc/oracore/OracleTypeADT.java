// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeADT.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.*;
import java.util.*;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.ObjectData;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.oracore:
//            OracleNamedType, OracleType, OracleTypeDATE, OracleTypeCHAR, 
//            OracleTypeNUMBER, OracleTypeFLOAT, OracleTypeBINARY_FLOAT, OracleTypeBINARY_DOUBLE, 
//            OracleTypeSINT32, OracleTypeREF, OracleTypeBFILE, OracleTypeRAW, 
//            OracleTypeCLOB, OracleTypeBLOB, OracleTypeTIMESTAMP, OracleTypeTIMESTAMPTZ, 
//            OracleTypeTIMESTAMPLTZ, OracleTypeINTERVAL, OracleTypeCOLLECTION, TDSReader, 
//            OracleTypeOPAQUE, OracleTypeUPT, PickleContext, TypeTreeElement, 
//            TDSPatch, Util

public class OracleTypeADT extends OracleNamedType
    implements Serializable
{

    static final long serialVersionUID = 0x2a115af057b4b406L;
    static final int S_TOP = 1;
    static final int S_EMBEDDED = 2;
    static final int S_UPT_ADT = 4;
    static final int S_JAVA_OBJECT = 16;
    static final int S_FINAL_TYPE = 32;
    static final int S_SUB_TYPE = 64;
    static final int S_ATTR_TDS = 128;
    static final int S_HAS_METADATA = 256;
    static final int S_TDS_PARSED = 512;
    private int statusBits;
    int tdsVersion;
    static final int KOPT_V80 = 1;
    static final int KOPT_V81 = 2;
    static final int KOPT_VNFT = 3;
    static final int KOPT_VERSION = 3;
    boolean endOfAdt;
    int typeVersion;
    long fixedDataSize;
    int alignmentRequirement;
    OracleType attrTypes[];
    String attrNames[];
    String attrTypeNames[];
    public long tdoCState;
    byte toid[];
    int charSetId;
    int charSetForm;
    int flattenedAttrNum;
    transient int opcode;
    transient int idx;
    boolean isTransient;
    static final int CURRENT_USER_OBJECT = 0;
    static final int CURRENT_USER_SYNONYM = 1;
    static final int CURRENT_USER_SYNONYM_10g = 2;
    static final int CURRENT_USER_PUBLIC_SYNONYM = 3;
    static final int CURRENT_USER_PUBLIC_SYNONYM_10g = 4;
    static final int POSSIBLY_OTHER_USER_OBJECT = 5;
    static final int POSSIBLY_OTHER_USER_OBJECT_10g = 6;
    static final int OTHER_USER_OBJECT = 7;
    static final int OTHER_USER_SYNONYM = 8;
    static final int PUBLIC_SYNONYM = 9;
    static final int PUBLIC_SYNONYM_10g = 10;
    static final int BREAK = 11;
    static final String sqlString[] = {
        "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME = :1 ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ORDER BY ATTR_NO", "DECLARE CURSOR usyn_cur IS SELECT table_name, table_owner from user_synonyms; TYPE table_name_type IS TABLE OF usyn_cur%ROWTYPE; table_names table_name_type; lastrow BINARY_INTEGER := null; l_syntname user_synonyms.table_name%TYPE; l_syntown  user_synonyms.table_owner%TYPE; BEGIN SELECT TABLE_NAME, TABLE_OWNER BULK COLLECT INTO table_names FROM USER_SYNONYMS START WITH SYNONYM_NAME = ? CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME; IF table_names.LAST IS NOT NULL THEN   lastrow := table_names.LAST;   l_syntname := table_names(lastrow).table_name;   l_syntown :=  table_names(lastrow).table_owner; END IF; OPEN ? FOR SELECT  ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER   FROM ALL_TYPE_ATTRS  A   WHERE (TYPE_NAME = l_syntname OR TYPE_NAME = ?)  AND  A.OWNER = l_syntown   ORDER BY ATTR_NO; END;", "DECLARE CURSOR usyn_cur IS SELECT table_name, table_owner from user_synonyms; TYPE table_name_type IS TABLE OF usyn_cur%ROWTYPE; table_names table_name_type; lastrow BINARY_INTEGER := null; l_syntname user_synonyms.table_name%TYPE; l_syntown  user_synonyms.table_owner%TYPE; BEGIN SELECT TABLE_NAME, TABLE_OWNER BULK COLLECT INTO table_names FROM USER_SYNONYMS START WITH SYNONYM_NAME = ? CONNECT BY NOCYCLEPRIOR TABLE_NAME = SYNONYM_NAME; IF table_names.LAST IS NOT NULL THEN   lastrow := table_names.LAST;   l_syntname := table_names(lastrow).table_name;   l_syntown :=  table_names(lastrow).table_owner; END IF; OPEN ? FOR SELECT  ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER   FROM ALL_TYPE_ATTRS  A   WHERE (TYPE_NAME = l_syntname OR TYPE_NAME = ?)  AND  A.OWNER = l_syntown   ORDER BY ATTR_NO; END;", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE OWNER = :1 AND TYPE_NAME = :2 ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS WHERE OWNER = (SELECT TABLE_OWNER FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:1) AND TYPE_NAME = (SELECT TABLE_NAME FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:2) ORDER BY ATTR_NO", "DECLARE   the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME,  ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;", 
        "DECLARE   the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME,  ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;"
    };
    static final int SEARCH_USER_TYPES = 0;
    static final int SEARCH_ALL_TYPES = 1;
    static final String sqlStringTOID[] = {
        "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM USER_TYPE_ATTRS a, USER_TYPES b WHERE b.TYPE_OID = :1 AND a.TYPE_NAME = b.TYPE_NAME ORDER BY ATTR_NO", "SELECT ATTR_NO, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER FROM ALL_TYPE_ATTRS a, ALL_TYPES b WHERE b.TYPE_OID = :1 AND a.TYPE_NAME = b.TYPE_NAME AND a.OWNER = b.OWNER ORDER BY ATTR_NO"
    };
    Boolean isInstanciable;
    String superTypeName;
    int numberOfLocalAttributes;
    String subTypeNames[];
    final int LOCAL_TYPE = 0;
    final int LOOK_FOR_USER_SYNONYM = 1;
    final int LOOK_FOR_PUBLIC_SYNONYM = 2;
    final String initMetaData1_9_0_SQL[] = {
        "SELECT INSTANTIABLE, supertype_owner, supertype_name, LOCAL_ATTRIBUTES FROM all_types WHERE type_name = :1 AND owner = :2 ", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM USER_SYNONYMS WHERE \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;", "DECLARE \n bind_synonym_name user_synonyms.synonym_name%type := :1; \n the_table_owner  user_synonyms.table_owner%type; \n the_table_name   user_synonyms.table_name%type; \n the_db_link      user_synonyms.db_link%type; \n sql_string       VARCHAR2(1000); \nBEGIN \n   SELECT TABLE_NAME, TABLE_OWNER, DB_LINK INTO  \n         the_table_name, the_table_owner, the_db_link \n         FROM ALL_SYNONYMS WHERE \n         OWNER = 'PUBLIC' AND \n         SYNONYM_NAME = bind_synonym_name; \n \n   sql_string := 'SELECT INSTANTIABLE, SUPERTYPE_OWNER,      SUPERTYPE_NAME, LOCAL_ATTRIBUTES FROM ALL_TYPES'; \n \n   IF the_db_link IS NOT NULL  \n   THEN \n     sql_string := sql_string || '@' || the_db_link; \n   END IF; \n   sql_string := sql_string       || ' WHERE TYPE_NAME = '''       || the_table_name   || ''' AND OWNER = '''       || the_table_owner  || ''''; \n   OPEN :2 FOR sql_string; \nEND;"
    };
    static final int TDS_SIZE = 4;
    static final int TDS_NUMBER = 1;
    static final int KOPM_OTS_SQL_CHAR = 1;
    static final int KOPM_OTS_DATE = 2;
    static final int KOPM_OTS_DECIMAL = 3;
    static final int KOPM_OTS_DOUBLE = 4;
    static final int KOPM_OTS_FLOAT = 5;
    static final int KOPM_OTS_NUMBER = 6;
    static final int KOPM_OTS_SQL_VARCHAR2 = 7;
    static final int KOPM_OTS_SINT32 = 8;
    static final int KOPM_OTS_REF = 9;
    static final int KOPM_OTS_VARRAY = 10;
    static final int KOPM_OTS_UINT8 = 11;
    static final int KOPM_OTS_SINT8 = 12;
    static final int KOPM_OTS_UINT16 = 13;
    static final int KOPM_OTS_UINT32 = 14;
    static final int KOPM_OTS_LOB = 15;
    static final int KOPM_OTS_CANONICAL = 17;
    static final int KOPM_OTS_OCTET = 18;
    static final int KOPM_OTS_RAW = 19;
    static final int KOPM_OTS_ROWID = 20;
    static final int KOPM_OTS_STAMP = 21;
    static final int KOPM_OTS_TZSTAMP = 23;
    static final int KOPM_OTS_INTERVAL = 24;
    static final int KOPM_OTS_PTR = 25;
    static final int KOPM_OTS_SINT16 = 26;
    static final int KOPM_OTS_UPT = 27;
    static final int KOPM_OTS_COLLECTION = 28;
    static final int KOPM_OTS_CLOB = 29;
    static final int KOPM_OTS_BLOB = 30;
    static final int KOPM_OTS_BFILE = 31;
    static final int KOPM_OTS_BINARY_INTEGE = 32;
    static final int KOPM_OTS_IMPTZSTAMP = 33;
    static final int KOPM_OTS_BFLOAT = 37;
    static final int KOPM_OTS_BDOUBLE = 45;
    static final int KOTTCOPQ = 58;
    static final int KOPT_OP_STARTEMBADT = 39;
    static final int KOPT_OP_ENDEMBADT = 40;
    static final int KOPT_OP_STARTADT = 41;
    static final int KOPT_OP_ENDADT = 42;
    static final int KOPT_OP_SUBTYPE_MARKER = 43;
    static final int KOPT_OP_EMBADT_INFO = 44;
    static final int KOPT_OPCODE_START = 38;
    static final int KOPT_OP_VERSION = 38;
    static final int REGULAR_PATCH = 0;
    static final int SIMPLE_PATCH = 1;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected OracleTypeADT()
    {
        statusBits = 1;
        tdsVersion = -9999;
        endOfAdt = false;
        typeVersion = 1;
        fixedDataSize = -1L;
        alignmentRequirement = -1;
        attrTypes = null;
        tdoCState = 0L;
        toid = null;
        idx = 1;
        isTransient = false;
        numberOfLocalAttributes = -1;
    }

    public OracleTypeADT(byte abyte0[], int i, int j, short word0, String s)
        throws SQLException
    {
        this(s, ((Connection) ((OracleConnection)null)));
        toid = abyte0;
        typeVersion = i;
        charSetId = j;
        charSetForm = word0;
    }

    public OracleTypeADT(String s, Connection connection)
        throws SQLException
    {
        super(s, (OracleConnection)connection);
        statusBits = 1;
        tdsVersion = -9999;
        endOfAdt = false;
        typeVersion = 1;
        fixedDataSize = -1L;
        alignmentRequirement = -1;
        attrTypes = null;
        tdoCState = 0L;
        toid = null;
        idx = 1;
        isTransient = false;
        numberOfLocalAttributes = -1;
    }

    public OracleTypeADT(OracleTypeADT oracletypeadt, int i, Connection connection)
        throws SQLException
    {
        super(oracletypeadt, i, (OracleConnection)connection);
        statusBits = 1;
        tdsVersion = -9999;
        endOfAdt = false;
        typeVersion = 1;
        fixedDataSize = -1L;
        alignmentRequirement = -1;
        attrTypes = null;
        tdoCState = 0L;
        toid = null;
        idx = 1;
        isTransient = false;
        numberOfLocalAttributes = -1;
    }

    public OracleTypeADT(SQLName sqlname, byte abyte0[], int i, byte abyte1[], OracleConnection oracleconnection)
        throws SQLException
    {
        statusBits = 1;
        tdsVersion = -9999;
        endOfAdt = false;
        typeVersion = 1;
        fixedDataSize = -1L;
        alignmentRequirement = -1;
        attrTypes = null;
        tdoCState = 0L;
        toid = null;
        idx = 1;
        isTransient = false;
        numberOfLocalAttributes = -1;
        sqlName = sqlname;
        init(abyte1, oracleconnection);
        toid = abyte0;
        typeVersion = i;
    }

    public OracleTypeADT(AttributeDescriptor aattributedescriptor[], OracleConnection oracleconnection)
        throws SQLException
    {
        statusBits = 1;
        tdsVersion = -9999;
        endOfAdt = false;
        typeVersion = 1;
        fixedDataSize = -1L;
        alignmentRequirement = -1;
        attrTypes = null;
        tdoCState = 0L;
        toid = null;
        idx = 1;
        isTransient = false;
        numberOfLocalAttributes = -1;
        setConnectionInternal(oracleconnection);
        isTransient = true;
        flattenedAttrNum = aattributedescriptor.length;
        attrTypes = new OracleType[flattenedAttrNum];
        attrNames = new String[flattenedAttrNum];
        for(int i = 0; i < flattenedAttrNum; i++)
            attrNames[i] = aattributedescriptor[i].getAttributeName();

        statusBits |= 0x100;
        for(int j = 0; j < flattenedAttrNum; j++)
        {
            TypeDescriptor typedescriptor = aattributedescriptor[j].getTypeDescriptor();
            switch(typedescriptor.getInternalTypeCode())
            {
            case 12: // '\f'
                attrTypes[j] = new OracleTypeDATE();
                break;

            case 9: // '\t'
                attrTypes[j] = new OracleTypeCHAR(connection, 12);
                ((OracleTypeCHAR)attrTypes[j]).length = (int)typedescriptor.getPrecision();
                ((OracleTypeCHAR)attrTypes[j]).form = 1;
                break;

            case 96: // '`'
                attrTypes[j] = new OracleTypeCHAR(connection, 1);
                ((OracleTypeCHAR)attrTypes[j]).length = (int)typedescriptor.getPrecision();
                ((OracleTypeCHAR)attrTypes[j]).form = 1;
                break;

            case 108: // 'l'
                attrTypes[j] = (OracleTypeADT)typedescriptor.getPickler();
                ((OracleTypeADT)attrTypes[j]).setEmbeddedADT();
                break;

            case 2: // '\002'
                attrTypes[j] = new OracleTypeNUMBER(2);
                ((OracleTypeNUMBER)attrTypes[j]).precision = (int)typedescriptor.getPrecision();
                ((OracleTypeNUMBER)attrTypes[j]).scale = typedescriptor.getScale();
                break;

            case 7: // '\007'
                attrTypes[j] = new OracleTypeNUMBER(3);
                ((OracleTypeNUMBER)attrTypes[j]).precision = (int)typedescriptor.getPrecision();
                ((OracleTypeNUMBER)attrTypes[j]).scale = typedescriptor.getScale();
                break;

            case 22: // '\026'
                attrTypes[j] = new OracleTypeNUMBER(8);
                ((OracleTypeNUMBER)attrTypes[j]).precision = (int)typedescriptor.getPrecision();
                ((OracleTypeNUMBER)attrTypes[j]).scale = typedescriptor.getScale();
                break;

            case 4: // '\004'
                attrTypes[j] = new OracleTypeFLOAT();
                ((OracleTypeFLOAT)attrTypes[j]).precision = (int)typedescriptor.getPrecision();
                break;

            case 100: // 'd'
                attrTypes[j] = new OracleTypeBINARY_FLOAT();
                break;

            case 101: // 'e'
                attrTypes[j] = new OracleTypeBINARY_DOUBLE();
                break;

            case 29: // '\035'
                attrTypes[j] = new OracleTypeSINT32();
                break;

            case 110: // 'n'
                attrTypes[j] = new OracleTypeREF(this, j, connection);
                break;

            case 114: // 'r'
                attrTypes[j] = new OracleTypeBFILE(connection);
                break;

            case 95: // '_'
                attrTypes[j] = new OracleTypeRAW();
                break;

            case 112: // 'p'
                attrTypes[j] = new OracleTypeCLOB(connection);
                break;

            case 113: // 'q'
                attrTypes[j] = new OracleTypeBLOB(connection);
                break;

            case 187: 
                attrTypes[j] = new OracleTypeTIMESTAMP(connection);
                ((OracleTypeTIMESTAMP)attrTypes[j]).precision = (int)typedescriptor.getPrecision();
                break;

            case 188: 
                attrTypes[j] = new OracleTypeTIMESTAMPTZ(connection);
                ((OracleTypeTIMESTAMPTZ)attrTypes[j]).precision = (int)typedescriptor.getPrecision();
                break;

            case 232: 
                attrTypes[j] = new OracleTypeTIMESTAMPLTZ(connection);
                ((OracleTypeTIMESTAMPLTZ)attrTypes[j]).precision = (int)typedescriptor.getPrecision();
                break;

            case 189: 
                attrTypes[j] = new OracleTypeINTERVAL(connection);
                ((OracleTypeINTERVAL)attrTypes[j]).typeId = 7;
                ((OracleTypeINTERVAL)attrTypes[j]).precision = (int)typedescriptor.getPrecision();
                ((OracleTypeINTERVAL)attrTypes[j]).scale = typedescriptor.getScale();
                break;

            case 190: 
                attrTypes[j] = new OracleTypeINTERVAL(connection);
                ((OracleTypeINTERVAL)attrTypes[j]).typeId = 10;
                ((OracleTypeINTERVAL)attrTypes[j]).precision = (int)typedescriptor.getPrecision();
                ((OracleTypeINTERVAL)attrTypes[j]).scale = typedescriptor.getScale();
                break;

            case 122: // 'z'
                attrTypes[j] = new OracleTypeCOLLECTION(this, j, connection);
                break;

            default:
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 48, (new StringBuilder()).append("type: ").append(typedescriptor.getInternalTypeCode()).toString());
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }

    }

    public Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException
    {
        if(obj != null)
        {
            if(obj instanceof STRUCT)
                return (STRUCT)obj;
            if((obj instanceof SQLData) || (obj instanceof ObjectData))
                return STRUCT.toSTRUCT(obj, oracleconnection);
            if(obj instanceof Object[])
            {
                StructDescriptor structdescriptor = createStructDescriptor();
                STRUCT struct = createObjSTRUCT(structdescriptor, (Object[])(Object[])obj);
                return struct;
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        {
            return null;
        }
    }

    public Datum[] toDatumArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        Datum adatum[] = null;
        if(obj != null)
            if(obj instanceof Object[])
            {
                Object aobj[] = (Object[])(Object[])obj;
                int j = (int)(i != -1 ? Math.min(((long)aobj.length - l) + 1L, i) : aobj.length);
                adatum = new Datum[j];
                for(int k = 0; k < j; k++)
                    adatum[k] = toDatum(aobj[((int)l + k) - 1], oracleconnection);

            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return adatum;
    }

    public int getTypeCode()
        throws SQLException
    {
        return (getStatus() & 0x10) == 0 ? 2002 : 2008;
    }

    public OracleType[] getAttrTypes()
        throws SQLException
    {
        if(attrTypes == null)
            init(connection);
        return attrTypes;
    }

    public boolean isInHierarchyOf(OracleType oracletype)
        throws SQLException
    {
        if(oracletype == null)
            return false;
        if(!oracletype.isObjectType())
        {
            return false;
        } else
        {
            StructDescriptor structdescriptor = (StructDescriptor)oracletype.getTypeDescriptor();
            return descriptor.isInHierarchyOf(structdescriptor.getName());
        }
    }

    public boolean isInHierarchyOf(StructDescriptor structdescriptor)
        throws SQLException
    {
        if(structdescriptor == null)
            return false;
        else
            return descriptor.isInHierarchyOf(structdescriptor.getName());
    }

    public boolean isObjectType()
    {
        return true;
    }

    public TypeDescriptor getTypeDescriptor()
    {
        return descriptor;
    }

    public void init(OracleConnection oracleconnection)
        throws SQLException
    {
        synchronized(oracleconnection)
        {
            byte abyte0[] = initMetadata(oracleconnection);
            init(abyte0, oracleconnection);
        }
    }

    public void init(byte abyte0[], OracleConnection oracleconnection)
        throws SQLException
    {
        synchronized(oracleconnection)
        {
            statusBits = 1;
            connection = oracleconnection;
            if(abyte0 != null)
                parseTDS(abyte0, 0L);
            setStatusBits(256);
        }
    }

    public byte[] initMetadata(OracleConnection oracleconnection)
        throws SQLException
    {
        OracleConnection oracleconnection1 = connection;
        JVM INSTR monitorenter ;
        byte abyte0[];
        abyte0 = null;
        if((statusBits & 0x100) != 0)
            return null;
        CallableStatement callablestatement;
        if(sqlName == null)
            getFullName();
        if((statusBits & 0x100) != 0)
            break MISSING_BLOCK_LABEL_513;
        callablestatement = null;
        if(tdoCState == 0L)
            tdoCState = connection.getTdoCState(sqlName.getSchema(), sqlName.getSimpleName());
        String s = "begin :1 := dbms_pickler.get_type_shape(:2,:3,:4,:5,:6,:7); end;";
        boolean flag = false;
        callablestatement = connection.prepareCall(s);
        callablestatement.registerOutParameter(1, 2);
        callablestatement.registerOutParameter(4, -3, 16);
        callablestatement.registerOutParameter(5, 4);
        callablestatement.registerOutParameter(6, -4);
        callablestatement.registerOutParameter(7, -4);
        callablestatement.setString(2, sqlName.getSchema());
        callablestatement.setString(3, sqlName.getSimpleName());
        callablestatement.execute();
        int i = callablestatement.getInt(1);
        if(i != 0)
        {
            if(i != 24331)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74, sqlName.toString());
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(i == 24331)
            {
                flag = true;
                callablestatement.registerOutParameter(6, 2004);
                callablestatement.execute();
                int j = callablestatement.getInt(1);
                if(j != 0)
                {
                    SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 74, sqlName.toString());
                    sqlexception1.fillInStackTrace();
                    throw sqlexception1;
                }
            }
        }
        toid = callablestatement.getBytes(4);
        typeVersion = NUMBER.toInt(callablestatement.getBytes(5));
        if(!flag)
            abyte0 = callablestatement.getBytes(6);
        else
            try
            {
                Blob blob = ((OracleCallableStatement)callablestatement).getBlob(6);
                InputStream inputstream = blob.getBinaryStream();
                abyte0 = new byte[(int)blob.length()];
                inputstream.read(abyte0);
                inputstream.close();
                ((BLOB)blob).freeTemporary();
            }
            catch(IOException ioexception)
            {
                SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), ioexception);
                sqlexception2.fillInStackTrace();
                throw sqlexception2;
            }
        metaDataInitialized = true;
        flattenedAttrNum = Util.getUnsignedByte(abyte0[8]) * 256 + Util.getUnsignedByte(abyte0[9]);
        callablestatement.getBytes(7);
        if(callablestatement != null)
            callablestatement.close();
        break MISSING_BLOCK_LABEL_513;
        Exception exception;
        exception;
        if(callablestatement != null)
            callablestatement.close();
        throw exception;
        setStatusBits(256);
        abyte0;
        oracleconnection1;
        JVM INSTR monitorexit ;
        return;
        Exception exception1;
        exception1;
        throw exception1;
    }

    TDSReader parseTDS(byte abyte0[], long l)
        throws SQLException
    {
        if(attrTypes != null)
            return null;
        TDSReader tdsreader = new TDSReader(abyte0, l);
        long l1 = tdsreader.readLong() + tdsreader.offset();
        tdsreader.checkNextByte((byte)38);
        tdsVersion = tdsreader.readByte();
        tdsreader.skipBytes(2);
        flattenedAttrNum = tdsreader.readUB2();
        if((tdsreader.readByte() & 0xff) == 255)
            setStatusBits(128);
        long l2 = tdsreader.offset();
        tdsreader.checkNextByte((byte)41);
        if(tdsreader.readUB2() != 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        long l3 = tdsreader.readLong();
        parseTDSrec(tdsreader);
        if(tdsVersion >= 3)
        {
            tdsreader.skip_to(l2 + l3 + 2L);
            tdsreader.skipBytes(2 * flattenedAttrNum);
            byte byte0 = tdsreader.readByte();
            if(tdsreader.isJavaObject(tdsVersion, byte0))
                setStatusBits(16);
            if(tdsreader.isFinalType(tdsVersion, byte0))
                setStatusBits(32);
            if(tdsreader.readByte() != 1)
                setStatusBits(64);
        } else
        {
            setStatusBits(32);
        }
        tdsreader.skip_to(l1);
        return tdsreader;
    }

    public void parseTDSrec(TDSReader tdsreader)
        throws SQLException
    {
        Vector vector = new Vector(5);
        OracleType oracletype = null;
        idx = 1;
        while((oracletype = getNextTypeObject(tdsreader)) != null) 
            vector.addElement(oracletype);
        if(opcode == 42)
        {
            endOfAdt = true;
            applyTDSpatches(tdsreader);
        }
        attrTypes = new OracleType[vector.size()];
        vector.copyInto(attrTypes);
    }

    private void applyTDSpatches(TDSReader tdsreader)
        throws SQLException
    {
        for(TDSPatch tdspatch = tdsreader.getNextPatch(); tdspatch != null; tdspatch = tdsreader.getNextPatch())
        {
            tdsreader.moveToPatchPos(tdspatch);
            int i = tdspatch.getType();
            if(i == 0)
            {
                tdsreader.readByte();
                byte byte0 = tdspatch.getUptTypeCode();
                switch(byte0)
                {
                case -6: 
                    tdsreader.readLong();
                    // fall through

                case -5: 
                    OracleNamedType oraclenamedtype = tdspatch.getOwner();
                    OracleTypeADT oracletypeadt = null;
                    if(oraclenamedtype.hasName())
                        oracletypeadt = new OracleTypeADT(oraclenamedtype.getFullName(), connection);
                    else
                        oracletypeadt = new OracleTypeADT(oraclenamedtype.getParent(), oraclenamedtype.getOrder(), connection);
                    oracletypeadt.setUptADT();
                    TDSReader tdsreader1 = oracletypeadt.parseTDS(tdsreader.tds(), tdsreader.absoluteOffset());
                    tdsreader.skipBytes((int)tdsreader1.offset());
                    tdspatch.apply(oracletypeadt.cleanup());
                    continue;

                case 58: // ':'
                    OracleNamedType oraclenamedtype1 = tdspatch.getOwner();
                    OracleTypeOPAQUE oracletypeopaque = null;
                    if(oraclenamedtype1.hasName())
                        oracletypeopaque = new OracleTypeOPAQUE(oraclenamedtype1.getFullName(), connection);
                    else
                        oracletypeopaque = new OracleTypeOPAQUE(oraclenamedtype1.getParent(), oraclenamedtype1.getOrder(), connection);
                    oracletypeopaque.parseTDSrec(tdsreader);
                    tdspatch.apply(oracletypeopaque);
                    break;

                default:
                    SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
                    sqlexception1.fillInStackTrace();
                    throw sqlexception1;
                }
                continue;
            }
            if(i == 1)
            {
                OracleType oracletype = getNextTypeObject(tdsreader);
                tdspatch.apply(oracletype, opcode);
            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }

    }

    public OracleNamedType cleanup()
    {
        OracleConnection oracleconnection = connection;
        JVM INSTR monitorenter ;
        if(attrTypes.length == 1 && (attrTypes[0] instanceof OracleTypeCOLLECTION))
        {
            OracleTypeCOLLECTION oracletypecollection = (OracleTypeCOLLECTION)attrTypes[0];
            oracletypecollection.copy_properties(this);
            return oracletypecollection;
        }
        if(attrTypes.length != 1 || (statusBits & 0x80) == 0 || !(attrTypes[0] instanceof OracleTypeUPT) || !(((OracleTypeUPT)attrTypes[0]).realType instanceof OracleTypeOPAQUE)) goto _L2; else goto _L1
_L1:
        OracleTypeOPAQUE oracletypeopaque;
        oracletypeopaque = (OracleTypeOPAQUE)((OracleTypeUPT)attrTypes[0]).realType;
        oracletypeopaque.copy_properties(this);
        oracletypeopaque;
        oracleconnection;
        JVM INSTR monitorexit ;
        return;
_L2:
        this;
        oracleconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    void copy_properties(OracleTypeADT oracletypeadt)
    {
        sqlName = oracletypeadt.sqlName;
        parent = oracletypeadt.parent;
        idx = oracletypeadt.idx;
        connection = oracletypeadt.connection;
        toid = oracletypeadt.toid;
        tdsVersion = oracletypeadt.tdsVersion;
        typeVersion = oracletypeadt.typeVersion;
        tdoCState = oracletypeadt.tdoCState;
        endOfAdt = oracletypeadt.endOfAdt;
    }

    OracleType getNextTypeObject(TDSReader tdsreader)
        throws SQLException
    {
        do
        {
            do
                opcode = tdsreader.readByte();
            while(opcode == 43);
            if(opcode != 44)
                break;
            byte byte0 = tdsreader.readByte();
            if(tdsreader.isJavaObject(3, byte0))
                setStatusBits(16);
        } while(true);
        switch(opcode)
        {
        case 40: // '('
        case 42: // '*'
            return null;

        case 2: // '\002'
            OracleTypeDATE oracletypedate = new OracleTypeDATE();
            oracletypedate.parseTDSrec(tdsreader);
            idx++;
            return oracletypedate;

        case 7: // '\007'
            OracleTypeCHAR oracletypechar = new OracleTypeCHAR(connection, 12);
            oracletypechar.parseTDSrec(tdsreader);
            idx++;
            return oracletypechar;

        case 1: // '\001'
            OracleTypeCHAR oracletypechar1 = new OracleTypeCHAR(connection, 1);
            oracletypechar1.parseTDSrec(tdsreader);
            idx++;
            return oracletypechar1;

        case 39: // '\''
            OracleTypeADT oracletypeadt = new OracleTypeADT(this, idx, connection);
            oracletypeadt.setEmbeddedADT();
            oracletypeadt.parseTDSrec(tdsreader);
            idx++;
            return oracletypeadt;

        case 6: // '\006'
            OracleTypeNUMBER oracletypenumber = new OracleTypeNUMBER(2);
            oracletypenumber.parseTDSrec(tdsreader);
            idx++;
            return oracletypenumber;

        case 3: // '\003'
            OracleTypeNUMBER oracletypenumber1 = new OracleTypeNUMBER(3);
            oracletypenumber1.parseTDSrec(tdsreader);
            idx++;
            return oracletypenumber1;

        case 4: // '\004'
            OracleTypeNUMBER oracletypenumber2 = new OracleTypeNUMBER(8);
            oracletypenumber2.parseTDSrec(tdsreader);
            idx++;
            return oracletypenumber2;

        case 5: // '\005'
            OracleTypeFLOAT oracletypefloat = new OracleTypeFLOAT();
            oracletypefloat.parseTDSrec(tdsreader);
            idx++;
            return oracletypefloat;

        case 37: // '%'
            OracleTypeBINARY_FLOAT oracletypebinary_float = new OracleTypeBINARY_FLOAT();
            oracletypebinary_float.parseTDSrec(tdsreader);
            idx++;
            return oracletypebinary_float;

        case 45: // '-'
            OracleTypeBINARY_DOUBLE oracletypebinary_double = new OracleTypeBINARY_DOUBLE();
            oracletypebinary_double.parseTDSrec(tdsreader);
            idx++;
            return oracletypebinary_double;

        case 8: // '\b'
            OracleTypeSINT32 oracletypesint32 = new OracleTypeSINT32();
            oracletypesint32.parseTDSrec(tdsreader);
            idx++;
            return oracletypesint32;

        case 9: // '\t'
            OracleTypeREF oracletyperef = new OracleTypeREF(this, idx, connection);
            oracletyperef.parseTDSrec(tdsreader);
            idx++;
            return oracletyperef;

        case 31: // '\037'
            OracleTypeBFILE oracletypebfile = new OracleTypeBFILE(connection);
            oracletypebfile.parseTDSrec(tdsreader);
            idx++;
            return oracletypebfile;

        case 19: // '\023'
            OracleTypeRAW oracletyperaw = new OracleTypeRAW();
            oracletyperaw.parseTDSrec(tdsreader);
            idx++;
            return oracletyperaw;

        case 29: // '\035'
            OracleTypeCLOB oracletypeclob = new OracleTypeCLOB(connection);
            oracletypeclob.parseTDSrec(tdsreader);
            if(sqlName != null && !endOfAdt)
                connection.getForm(this, oracletypeclob, idx);
            idx++;
            return oracletypeclob;

        case 30: // '\036'
            OracleTypeBLOB oracletypeblob = new OracleTypeBLOB(connection);
            oracletypeblob.parseTDSrec(tdsreader);
            idx++;
            return oracletypeblob;

        case 21: // '\025'
            OracleTypeTIMESTAMP oracletypetimestamp = new OracleTypeTIMESTAMP(connection);
            oracletypetimestamp.parseTDSrec(tdsreader);
            idx++;
            return oracletypetimestamp;

        case 23: // '\027'
            OracleTypeTIMESTAMPTZ oracletypetimestamptz = new OracleTypeTIMESTAMPTZ(connection);
            oracletypetimestamptz.parseTDSrec(tdsreader);
            idx++;
            return oracletypetimestamptz;

        case 33: // '!'
            OracleTypeTIMESTAMPLTZ oracletypetimestampltz = new OracleTypeTIMESTAMPLTZ(connection);
            oracletypetimestampltz.parseTDSrec(tdsreader);
            idx++;
            return oracletypetimestampltz;

        case 24: // '\030'
            OracleTypeINTERVAL oracletypeinterval = new OracleTypeINTERVAL(connection);
            oracletypeinterval.parseTDSrec(tdsreader);
            idx++;
            return oracletypeinterval;

        case 28: // '\034'
            OracleTypeCOLLECTION oracletypecollection = new OracleTypeCOLLECTION(this, idx, connection);
            oracletypecollection.parseTDSrec(tdsreader);
            idx++;
            return oracletypecollection;

        case 27: // '\033'
            OracleTypeUPT oracletypeupt = new OracleTypeUPT(this, idx, connection);
            oracletypeupt.parseTDSrec(tdsreader);
            idx++;
            return oracletypeupt;

        case 10: // '\n'
        case 11: // '\013'
        case 12: // '\f'
        case 13: // '\r'
        case 14: // '\016'
        case 15: // '\017'
        case 16: // '\020'
        case 17: // '\021'
        case 18: // '\022'
        case 20: // '\024'
        case 22: // '\026'
        case 25: // '\031'
        case 26: // '\032'
        case 32: // ' '
        case 34: // '"'
        case 35: // '#'
        case 36: // '$'
        case 38: // '&'
        case 41: // ')'
        case 43: // '+'
        case 44: // ','
        default:
            Object obj = null;
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 48, (new StringBuilder()).append("get_next_type: ").append(opcode).toString());
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public byte[] linearize(Datum datum)
        throws SQLException
    {
        OracleConnection oracleconnection = connection;
        JVM INSTR monitorenter ;
        return pickle81(datum);
        Exception exception;
        exception;
        throw exception;
    }

    public Datum unlinearize(byte abyte0[], long l, Datum datum, int i, Map map)
        throws SQLException
    {
        OracleConnection oracleconnection = getConnection();
        Datum datum1 = null;
        if(oracleconnection == null)
            datum1 = _unlinearize(abyte0, l, datum, i, map);
        else
            synchronized(oracleconnection)
            {
                datum1 = _unlinearize(abyte0, l, datum, i, map);
            }
        return datum1;
    }

    public Datum _unlinearize(byte abyte0[], long l, Datum datum, int i, Map map)
        throws SQLException
    {
        OracleConnection oracleconnection = connection;
        JVM INSTR monitorenter ;
        if(abyte0 == null)
            return null;
        PickleContext picklecontext = new PickleContext(abyte0, l);
        unpickle81(picklecontext, (STRUCT)datum, 1, i, map);
        oracleconnection;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    protected STRUCT unpickle81(PickleContext picklecontext, STRUCT struct, int i, int j, Map map)
        throws SQLException
    {
        STRUCT struct1 = struct;
        long l = picklecontext.offset();
        byte byte0 = picklecontext.readByte();
        PickleContext _tmp = picklecontext;
        if(!PickleContext.is81format(byte0))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not in 8.1 format");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        PickleContext _tmp1 = picklecontext;
        if(PickleContext.isCollectionImage_pctx(byte0))
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is a collection image,expecting ADT");
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(!picklecontext.readAndCheckVersion())
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image version is not recognized");
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
label0:
        switch(i)
        {
        case 9: // '\t'
            picklecontext.skipBytes(picklecontext.readLength(true) - 2);
            break;

        case 3: // '\003'
            long l1 = picklecontext.readLength();
            struct1 = unpickle81Prefix(picklecontext, struct1, byte0);
            if(struct1 == null)
            {
                StructDescriptor structdescriptor1 = createStructDescriptor();
                struct1 = createByteSTRUCT(structdescriptor1, (byte[])null);
            }
            struct1.setImage(picklecontext.image(), l, 0L);
            struct1.setImageLength(l1);
            picklecontext.skipTo(l + l1);
            break;

        default:
            picklecontext.skipLength();
            struct1 = unpickle81Prefix(picklecontext, struct1, byte0);
            if(struct1 == null)
            {
                StructDescriptor structdescriptor = createStructDescriptor();
                struct1 = createByteSTRUCT(structdescriptor, (byte[])null);
            }
            OracleType aoracletype[] = struct1.getDescriptor().getOracleTypeADT().getAttrTypes();
            switch(j)
            {
            case 1: // '\001'
                Datum adatum[] = new Datum[aoracletype.length];
                for(int k = 0; k < aoracletype.length; k++)
                    adatum[k] = (Datum)aoracletype[k].unpickle81rec(picklecontext, j, map);

                struct1.setDatumArray(adatum);
                break label0;

            case 2: // '\002'
                Object aobj[] = new Object[aoracletype.length];
                for(int i1 = 0; i1 < aoracletype.length; i1++)
                    aobj[i1] = aoracletype[i1].unpickle81rec(picklecontext, j, map);

                struct1.setObjArray(aobj);
                break;

            default:
                SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
                sqlexception3.fillInStackTrace();
                throw sqlexception3;
            }
            break;
        }
        return struct1;
    }

    protected STRUCT unpickle81Prefix(PickleContext picklecontext, STRUCT struct, byte byte0)
        throws SQLException
    {
        STRUCT struct1 = struct;
        PickleContext _tmp = picklecontext;
        if(PickleContext.hasPrefix(byte0))
        {
            long l = picklecontext.readLength() + picklecontext.absoluteOffset();
            byte byte1 = picklecontext.readByte();
            byte byte2 = (byte)(byte1 & 0xc);
            boolean flag = byte2 == 0;
            boolean flag1 = byte2 == 4;
            boolean flag2 = byte2 == 8;
            boolean flag3 = byte2 == 12;
            boolean flag4 = (byte1 & 0x10) != 0;
            if(flag1)
            {
                byte abyte0[] = picklecontext.readBytes(16);
                String s = toid2typename(connection, abyte0);
                StructDescriptor structdescriptor = (StructDescriptor)TypeDescriptor.getTypeDescriptor(s, connection);
                if(struct1 == null)
                    struct1 = createByteSTRUCT(structdescriptor, (byte[])null);
                else
                    struct1.setDescriptor(structdescriptor);
            }
            if(flag4)
                picklecontext.readLength();
            if(flag2 | flag3)
            {
                SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            picklecontext.skipTo(l);
        }
        return struct1;
    }

    protected Object unpickle81rec(PickleContext picklecontext, int i, Map map)
        throws SQLException
    {
        byte byte0 = picklecontext.readByte();
        byte byte1 = 0;
        PickleContext _tmp = picklecontext;
        if(PickleContext.isAtomicNull(byte0))
            return null;
        PickleContext _tmp1 = picklecontext;
        if(PickleContext.isImmediatelyEmbeddedNull(byte0))
            byte1 = picklecontext.readByte();
        STRUCT struct = unpickle81datum(picklecontext, byte0, byte1);
        return toObject(struct, i, map);
    }

    protected Object unpickle81rec(PickleContext picklecontext, byte byte0, int i, Map map)
        throws SQLException
    {
        STRUCT struct = unpickle81datum(picklecontext, byte0, (byte)0);
        return toObject(struct, i, map);
    }

    private STRUCT unpickle81datum(PickleContext picklecontext, byte byte0, byte byte1)
        throws SQLException
    {
        int i = getNumAttrs();
        StructDescriptor structdescriptor = createStructDescriptor();
        STRUCT struct = createByteSTRUCT(structdescriptor, (byte[])null);
        OracleType oracletype = getAttrTypeAt(0);
        Object obj = null;
        PickleContext _tmp = picklecontext;
        if(PickleContext.isImmediatelyEmbeddedNull(byte0) && byte1 == 1)
        {
            obj = null;
        } else
        {
            PickleContext _tmp1 = picklecontext;
            if(PickleContext.isImmediatelyEmbeddedNull(byte0))
            {
                obj = ((OracleTypeADT)oracletype).unpickle81datum(picklecontext, byte0, (byte)(byte1 - 1));
            } else
            {
                PickleContext _tmp2 = picklecontext;
                if(PickleContext.isElementNull(byte0))
                {
                    if(oracletype.getTypeCode() == 2002 || oracletype.getTypeCode() == 2008)
                        obj = oracletype.unpickle81datumAsNull(picklecontext, byte0, byte1);
                    else
                        obj = null;
                } else
                {
                    obj = oracletype.unpickle81rec(picklecontext, byte0, 1, null);
                }
            }
        }
        Datum adatum[] = new Datum[i];
        adatum[0] = (Datum)obj;
        for(int j = 1; j < i; j++)
        {
            OracleType oracletype1 = getAttrTypeAt(j);
            adatum[j] = (Datum)oracletype1.unpickle81rec(picklecontext, 1, null);
        }

        struct.setDatumArray(adatum);
        return struct;
    }

    protected Datum unpickle81datumAsNull(PickleContext picklecontext, byte byte0, byte byte1)
        throws SQLException
    {
        int i = getNumAttrs();
        StructDescriptor structdescriptor = createStructDescriptor();
        STRUCT struct = createByteSTRUCT(structdescriptor, (byte[])null);
        Datum adatum[] = new Datum[i];
        int j = 0;
        OracleType oracletype = getAttrTypeAt(j);
        if(oracletype.getTypeCode() == 2002 || oracletype.getTypeCode() == 2008)
            adatum[j++] = oracletype.unpickle81datumAsNull(picklecontext, byte0, byte1);
        else
            adatum[j++] = (Datum)null;
        for(; j < i; j++)
        {
            OracleType oracletype1 = getAttrTypeAt(j);
            if(oracletype1.getTypeCode() == 2002 || oracletype1.getTypeCode() == 2008)
                adatum[j] = (Datum)oracletype1.unpickle81rec(picklecontext, 1, null);
            else
                adatum[j] = (Datum)oracletype1.unpickle81rec(picklecontext, 1, null);
        }

        struct.setDatumArray(adatum);
        return struct;
    }

    public byte[] pickle81(Datum datum)
        throws SQLException
    {
        PickleContext picklecontext = new PickleContext();
        picklecontext.initStream();
        pickle81(picklecontext, datum);
        byte abyte0[] = picklecontext.stream2Bytes();
        datum.setShareBytes(abyte0);
        return abyte0;
    }

    protected int pickle81(PickleContext picklecontext, Datum datum)
        throws SQLException
    {
        int i = picklecontext.offset() + 2;
        int j = 0;
        j += picklecontext.writeImageHeader(shouldHavePrefix());
        j += pickle81Prefix(picklecontext);
        j += pickle81rec(picklecontext, datum, 0);
        picklecontext.patchImageLen(i, j);
        return j;
    }

    private boolean hasVersion()
    {
        return typeVersion > 1;
    }

    private boolean needsToid()
    {
        if(isTransient)
            return false;
        else
            return (statusBits & 0x40) != 0 || (statusBits & 0x20) == 0 || hasVersion();
    }

    private boolean shouldHavePrefix()
    {
        if(isTransient)
            return false;
        else
            return hasVersion() || needsToid();
    }

    protected int pickle81Prefix(PickleContext picklecontext)
        throws SQLException
    {
        if(shouldHavePrefix())
        {
            int i = 0;
            int j = 1;
            int k = 1;
            if(needsToid())
            {
                k += getTOID().length;
                j |= 4;
            }
            if(hasVersion())
            {
                j |= 0x10;
                if(typeVersion > PickleContext.KOPI20_LN_MAXV)
                    k += 5;
                else
                    k += 2;
            }
            i = picklecontext.writeLength(k);
            i += picklecontext.writeData((byte)j);
            if(needsToid())
                i += picklecontext.writeData(toid);
            if(hasVersion())
                if(typeVersion > PickleContext.KOPI20_LN_MAXV)
                    i += picklecontext.writeLength(typeVersion);
                else
                    i += picklecontext.writeSB2(typeVersion);
            return i;
        } else
        {
            return 0;
        }
    }

    private int pickle81rec(PickleContext picklecontext, Datum datum, int i)
        throws SQLException
    {
        int j = 0;
        if(!metaDataInitialized)
            copy_properties((OracleTypeADT)((STRUCT)datum).getDescriptor().getPickler());
        Datum adatum[] = ((STRUCT)datum).getOracleAttributes();
        int k = adatum.length;
        int l = 0;
        OracleType oracletype = getAttrTypeAt(0);
        if((oracletype instanceof OracleTypeADT) && !(oracletype instanceof OracleTypeCOLLECTION) && !(oracletype instanceof OracleTypeUPT))
        {
            l = 1;
            if(adatum[0] == null)
            {
                if(i > 0)
                    j += picklecontext.writeImmediatelyEmbeddedElementNull((byte)i);
                else
                    j += picklecontext.writeAtomicNull();
            } else
            {
                j += ((OracleTypeADT)oracletype).pickle81rec(picklecontext, adatum[0], i + 1);
            }
        }
        for(; l < k; l++)
        {
            OracleType oracletype1 = getAttrTypeAt(l);
            if(adatum[l] == null)
            {
                if((oracletype1 instanceof OracleTypeADT) && !(oracletype1 instanceof OracleTypeCOLLECTION) && !(oracletype1 instanceof OracleTypeUPT))
                    j += picklecontext.writeAtomicNull();
                else
                    j += picklecontext.writeElementNull();
                continue;
            }
            if((oracletype1 instanceof OracleTypeADT) && !(oracletype1 instanceof OracleTypeCOLLECTION) && !(oracletype1 instanceof OracleTypeUPT))
                j += ((OracleTypeADT)oracletype1).pickle81rec(picklecontext, adatum[l], 1);
            else
                j += oracletype1.pickle81(picklecontext, adatum[l]);
        }

        return j;
    }

    private Object toObject(STRUCT struct, int i, Map map)
        throws SQLException
    {
        SQLException sqlexception;
        switch(i)
        {
        case 1: // '\001'
            return struct;

        case 2: // '\002'
            if(struct != null)
                return struct.toJdbc(map);
            else
                return null;
        }
        sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public String getAttributeType(int i)
        throws SQLException
    {
        return getAttributeType(i, true);
    }

    public String getAttributeType(int i, boolean flag)
        throws SQLException
    {
        if(flag)
        {
            if(sqlName == null)
                getFullName();
            if(attrNames == null)
                initADTAttrNames();
        }
        if(i < 1 || attrTypeNames != null && i > attrTypeNames.length)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(attrTypeNames != null)
            return attrTypeNames[i - 1];
        else
            return null;
    }

    public String getAttributeName(int i)
        throws SQLException
    {
        if(attrNames == null)
            initADTAttrNames();
        String s = null;
        if(attrNames != null)
        {
            synchronized(connection)
            {
                if(i < 1 || i > attrNames.length)
                {
                    SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index");
                    sqlexception.fillInStackTrace();
                    throw sqlexception;
                }
            }
            s = attrNames[i - 1];
        }
        return s;
    }

    public String getAttributeName(int i, boolean flag)
        throws SQLException
    {
        if(flag && connection != null)
            return getAttributeName(i);
        if(i < 1 || attrNames != null && i > attrNames.length)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid index");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(attrNames != null)
            return attrNames[i - 1];
        else
            return null;
    }

    private void initADTAttrNames()
        throws SQLException
    {
        if(connection == null)
            return;
        if(sqlName == null)
            getFullName();
        if(toid != null)
        {
            initADTAttrNamesUsingTOID();
            return;
        }
        OracleConnection oracleconnection = connection;
        JVM INSTR monitorenter ;
        Object obj;
        PreparedStatement preparedstatement;
        ResultSet resultset;
        String as[];
        String as1[];
        byte byte0;
        obj = null;
        preparedstatement = null;
        resultset = null;
        as = new String[attrTypes.length];
        as1 = new String[attrTypes.length];
        byte0 = 0;
        boolean flag = false;
        if(attrNames != null)
            break MISSING_BLOCK_LABEL_1172;
        byte0 = ((byte)(sqlName.getSchema().equals(connection.getDefaultSchemaNameForNamedTypes()) ? 0 : 7));
_L4:
        if(byte0 == 11)
            break; /* Loop/switch isn't completed */
        switch(byte0)
        {
        default:
            break;

        case 0: // '\0'
            preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
            preparedstatement.setString(1, sqlName.getSimpleName());
            preparedstatement.setFetchSize(idx);
            resultset = preparedstatement.executeQuery();
            byte0 = 1;
            break;

        case 1: // '\001'
            if(connection.getVersionNumber() >= 10000)
                byte0 = 2;
            // fall through

        case 2: // '\002'
            preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
            preparedstatement.setString(1, sqlName.getSimpleName());
            preparedstatement.setString(2, sqlName.getSimpleName());
            preparedstatement.setFetchSize(idx);
            resultset = preparedstatement.executeQuery();
            byte0 = 3;
            break;

        case 3: // '\003'
            if(connection.getVersionNumber() >= 10000)
                byte0 = 4;
            // fall through

        case 4: // '\004'
            preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
            preparedstatement.setString(1, sqlName.getSimpleName());
            preparedstatement.setString(2, sqlName.getSimpleName());
            preparedstatement.setFetchSize(idx);
            resultset = preparedstatement.executeQuery();
            byte0 = 5;
            break;

        case 5: // '\005'
            if(connection.getVersionNumber() >= 10000)
                byte0 = 6;
            // fall through

        case 6: // '\006'
            obj = (OracleCallableStatement)connection.prepareCall((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
            ((CallableStatement) (obj)).setString(1, sqlName.getSimpleName());
            ((CallableStatement) (obj)).setString(3, sqlName.getSimpleName());
            ((CallableStatement) (obj)).registerOutParameter(2, -10);
            ((CallableStatement) (obj)).execute();
            resultset = ((OracleCallableStatement)obj).getCursor(2);
            resultset.setFetchSize(1);
            byte0 = 8;
            break;

        case 7: // '\007'
            preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
            preparedstatement.setString(1, sqlName.getSchema());
            preparedstatement.setString(2, sqlName.getSimpleName());
            preparedstatement.setFetchSize(idx);
            resultset = preparedstatement.executeQuery();
            byte0 = 8;
            break;

        case 8: // '\b'
            preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
            preparedstatement.setString(1, sqlName.getSimpleName());
            preparedstatement.setString(2, sqlName.getSimpleName());
            preparedstatement.setFetchSize(idx);
            resultset = preparedstatement.executeQuery();
            byte0 = 9;
            break;

        case 9: // '\t'
            if(connection.getVersionNumber() >= 10000)
                byte0 = 10;
            // fall through

        case 10: // '\n'
            obj = connection.prepareCall((new StringBuilder()).append(getSqlHint()).append(sqlString[byte0]).toString());
            ((CallableStatement) (obj)).setString(1, sqlName.getSimpleName());
            ((CallableStatement) (obj)).registerOutParameter(2, -10);
            ((CallableStatement) (obj)).execute();
            resultset = ((OracleCallableStatement)obj).getCursor(2);
            byte0 = 11;
            break;
        }
        int i = 0;
_L2:
        if(i >= attrTypes.length || !resultset.next())
            break; /* Loop/switch isn't completed */
        if(resultset.getInt(1) != i + 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "inconsistent ADT attribute");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        as[i] = resultset.getString(2);
        String s = resultset.getString(4);
        as1[i] = "";
        if(s != null)
            as1[i] = (new StringBuilder()).append(s).append(".").toString();
        new StringBuilder();
        as1;
        i;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        resultset.getString(3);
        append();
        toString();
        JVM INSTR aastore ;
        i++;
        if(true) goto _L2; else goto _L1
_L1:
        if(i != 0)
        {
            attrTypeNames = as1;
            attrNames = as;
            byte0 = 11;
        } else
        {
            if(resultset != null)
                resultset.close();
            if(preparedstatement != null)
                preparedstatement.close();
            if(obj != null)
                ((CallableStatement) (obj)).close();
        }
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        if(obj != null)
            ((CallableStatement) (obj)).close();
        if(true) goto _L4; else goto _L3
_L3:
        Exception exception;
        break MISSING_BLOCK_LABEL_1172;
        exception;
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        if(obj != null)
            ((CallableStatement) (obj)).close();
        throw exception;
        Exception exception1;
        exception1;
        throw exception1;
    }

    private void initADTAttrNamesUsingTOID()
        throws SQLException
    {
        OracleConnection oracleconnection = connection;
        JVM INSTR monitorenter ;
        CallableStatement callablestatement;
        PreparedStatement preparedstatement;
        ResultSet resultset;
        String as[];
        String as1[];
        int i;
        callablestatement = null;
        preparedstatement = null;
        resultset = null;
        as = new String[attrTypes.length];
        as1 = new String[attrTypes.length];
        i = 0;
        boolean flag = false;
        if(attrNames != null)
            break MISSING_BLOCK_LABEL_550;
        i = sqlName.getSchema().equals(connection.getDefaultSchemaNameForNamedTypes()) ? 0 : 1;
_L4:
        if(i == 11)
            break; /* Loop/switch isn't completed */
        switch(i)
        {
        case 0: // '\0'
            preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlStringTOID[i]).toString());
            preparedstatement.setBytes(1, toid);
            preparedstatement.setFetchSize(idx);
            resultset = preparedstatement.executeQuery();
            i = 1;
            break;

        case 1: // '\001'
            preparedstatement = connection.prepareStatement((new StringBuilder()).append(getSqlHint()).append(sqlStringTOID[i]).toString());
            preparedstatement.setBytes(1, toid);
            preparedstatement.setFetchSize(idx);
            resultset = preparedstatement.executeQuery();
            i = 11;
            break;
        }
        int j = 0;
_L2:
        if(j >= attrTypes.length || !resultset.next())
            break; /* Loop/switch isn't completed */
        if(resultset.getInt(1) != j + 1 && i == 1)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "inconsistent ADT attribute");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        as[j] = resultset.getString(2);
        String s = resultset.getString(4);
        as1[j] = "";
        if(s != null)
            as1[j] = (new StringBuilder()).append(s).append(".").toString();
        new StringBuilder();
        as1;
        j;
        JVM INSTR dup2_x1 ;
        JVM INSTR aaload ;
        append();
        resultset.getString(3);
        append();
        toString();
        JVM INSTR aastore ;
        j++;
        if(true) goto _L2; else goto _L1
_L1:
        if(j != 0)
        {
            attrTypeNames = as1;
            attrNames = as;
            i = 11;
        } else
        {
            if(resultset != null)
                resultset.close();
            if(preparedstatement != null)
                preparedstatement.close();
        }
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        if(callablestatement != null)
            callablestatement.close();
        if(true) goto _L4; else goto _L3
_L3:
        Exception exception;
        break MISSING_BLOCK_LABEL_550;
        exception;
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        if(callablestatement != null)
            callablestatement.close();
        throw exception;
        Exception exception1;
        exception1;
        throw exception1;
    }

    StructDescriptor createStructDescriptor()
        throws SQLException
    {
        StructDescriptor structdescriptor = (StructDescriptor)descriptor;
        if(structdescriptor == null)
            structdescriptor = new StructDescriptor(this, connection);
        return structdescriptor;
    }

    STRUCT createObjSTRUCT(StructDescriptor structdescriptor, Object aobj[])
        throws SQLException
    {
        if((statusBits & 0x10) != 0)
            return new JAVA_STRUCT(structdescriptor, connection, aobj);
        else
            return new STRUCT(structdescriptor, connection, aobj);
    }

    STRUCT createByteSTRUCT(StructDescriptor structdescriptor, byte abyte0[])
        throws SQLException
    {
        if((statusBits & 0x10) != 0)
            return new JAVA_STRUCT(structdescriptor, abyte0, connection);
        else
            return new STRUCT(structdescriptor, abyte0, connection);
    }

    public static String getSubtypeName(Connection connection, byte abyte0[], long l)
        throws SQLException
    {
        PickleContext picklecontext;
label0:
        {
            picklecontext = new PickleContext(abyte0, l);
            byte byte0 = picklecontext.readByte();
            PickleContext _tmp = picklecontext;
            if(PickleContext.is81format(byte0))
            {
                PickleContext _tmp1 = picklecontext;
                if(!PickleContext.isCollectionImage_pctx(byte0))
                {
                    PickleContext _tmp2 = picklecontext;
                    if(PickleContext.hasPrefix(byte0))
                        break label0;
                }
            }
            return null;
        }
        if(!picklecontext.readAndCheckVersion())
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, 1, "Image version is not recognized");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        picklecontext.skipLength();
        picklecontext.skipLength();
        byte byte1 = picklecontext.readByte();
        if((byte1 & 4) != 0)
        {
            byte abyte1[] = picklecontext.readBytes(16);
            return toid2typename(connection, abyte1);
        } else
        {
            return null;
        }
    }

    public static String toid2typename(Connection connection, byte abyte0[])
        throws SQLException
    {
        String s;
        PreparedStatement preparedstatement;
        ResultSet resultset;
        s = (String)((OracleConnection)connection).getDescriptor(abyte0);
        if(s != null)
            break MISSING_BLOCK_LABEL_183;
        preparedstatement = null;
        resultset = null;
        preparedstatement = connection.prepareStatement("select owner, type_name from all_types where type_oid = :1");
        preparedstatement.setBytes(1, abyte0);
        resultset = preparedstatement.executeQuery();
        if(resultset.next())
        {
            s = (new StringBuilder()).append(resultset.getString(1)).append(".").append(resultset.getString(2)).toString();
            ((OracleConnection)connection).putDescriptor(abyte0, s);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(null, 1, "Invalid type oid");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        break MISSING_BLOCK_LABEL_183;
        Exception exception;
        exception;
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        throw exception;
        return s;
    }

    public int getTdsVersion()
    {
        return tdsVersion;
    }

    public void printDebug()
    {
    }

    private String debugText()
    {
        StringWriter stringwriter = new StringWriter();
        PrintWriter printwriter = new PrintWriter(stringwriter);
        printwriter.println((new StringBuilder()).append("OracleTypeADT = ").append(this).toString());
        printwriter.println((new StringBuilder()).append("sqlName = ").append(sqlName).toString());
        printwriter.println("OracleType[] : ");
        if(attrTypes != null)
        {
            for(int i = 0; i < attrTypes.length; i++)
                printwriter.println((new StringBuilder()).append("[").append(i).append("] = ").append(attrTypes[i]).toString());

        } else
        {
            printwriter.println("null");
        }
        printwriter.println("toid : ");
        if(toid != null)
            printUnsignedByteArray(toid, printwriter);
        else
            printwriter.println("null");
        printwriter.println((new StringBuilder()).append("tds version : ").append(tdsVersion).toString());
        printwriter.println((new StringBuilder()).append("type version : ").append(typeVersion).toString());
        printwriter.println((new StringBuilder()).append("type version : ").append(typeVersion).toString());
        printwriter.println((new StringBuilder()).append("opcode : ").append(opcode).toString());
        printwriter.println((new StringBuilder()).append("tdoCState : ").append(tdoCState).toString());
        return stringwriter.getBuffer().substring(0);
    }

    public byte[] getTOID()
    {
        try
        {
            if(toid == null)
                initMetadata(connection);
        }
        catch(SQLException sqlexception) { }
        return toid;
    }

    public int getImageFormatVersion()
    {
        return PickleContext.KOPI20_VERSION;
    }

    public int getTypeVersion()
    {
        try
        {
            if(typeVersion == -1)
                initMetadata(connection);
        }
        catch(SQLException sqlexception) { }
        return typeVersion;
    }

    public int getCharSet()
    {
        return charSetId;
    }

    public int getCharSetForm()
    {
        return charSetForm;
    }

    public long getTdoCState()
    {
        OracleConnection oracleconnection = connection;
        JVM INSTR monitorenter ;
        try
        {
            if(tdoCState == 0L)
            {
                getFullName();
                tdoCState = connection.getTdoCState(sqlName.getSchema(), sqlName.getSimpleName());
            }
        }
        catch(SQLException sqlexception) { }
        return tdoCState;
        Exception exception;
        exception;
        throw exception;
    }

    public long getFIXED_DATA_SIZE()
    {
        try
        {
            return getFixedDataSize();
        }
        catch(SQLException sqlexception)
        {
            return 0L;
        }
    }

    public long getFixedDataSize()
        throws SQLException
    {
        return fixedDataSize;
    }

    public int getAlignmentReq()
        throws SQLException
    {
        return alignmentRequirement;
    }

    public int getNumAttrs()
        throws SQLException
    {
        if(attrTypes == null && connection != null)
            init(connection);
        return attrTypes.length;
    }

    public OracleType getAttrTypeAt(int i)
        throws SQLException
    {
        if(attrTypes == null && connection != null)
            init(connection);
        return attrTypes[i];
    }

    public boolean isEmbeddedADT()
        throws SQLException
    {
        return (statusBits & 2) != 0;
    }

    public boolean isUptADT()
        throws SQLException
    {
        return (statusBits & 4) != 0;
    }

    public boolean isTopADT()
        throws SQLException
    {
        return (statusBits & 1) != 0;
    }

    public void setStatus(int i)
        throws SQLException
    {
        statusBits = i;
    }

    void setEmbeddedADT()
        throws SQLException
    {
        maskAndSetStatusBits(-16, 2);
    }

    void setUptADT()
        throws SQLException
    {
        maskAndSetStatusBits(-16, 4);
    }

    public boolean isSubType()
        throws SQLException
    {
        return (statusBits & 0x40) != 0;
    }

    public boolean isFinalType()
        throws SQLException
    {
        return ((statusBits & 0x20) != 0) | ((statusBits & 2) != 0);
    }

    public boolean isJavaObject()
        throws SQLException
    {
        return (statusBits & 0x10) != 0;
    }

    public int getStatus()
        throws SQLException
    {
        if((statusBits & 1) != 0 && (statusBits & 0x100) == 0)
            init(connection);
        return statusBits;
    }

    public static OracleTypeADT shallowClone(OracleTypeADT oracletypeadt)
        throws SQLException
    {
        OracleTypeADT oracletypeadt1 = new OracleTypeADT();
        shallowCopy(oracletypeadt, oracletypeadt1);
        return oracletypeadt1;
    }

    public static void shallowCopy(OracleTypeADT oracletypeadt, OracleTypeADT oracletypeadt1)
        throws SQLException
    {
        oracletypeadt1.connection = oracletypeadt.connection;
        oracletypeadt1.sqlName = oracletypeadt.sqlName;
        oracletypeadt1.parent = oracletypeadt.parent;
        oracletypeadt1.idx = oracletypeadt.idx;
        oracletypeadt1.descriptor = oracletypeadt.descriptor;
        oracletypeadt1.statusBits = oracletypeadt.statusBits;
        oracletypeadt1.typeCode = oracletypeadt.typeCode;
        oracletypeadt1.dbTypeCode = oracletypeadt.dbTypeCode;
        oracletypeadt1.tdsVersion = oracletypeadt.tdsVersion;
        oracletypeadt1.typeVersion = oracletypeadt.typeVersion;
        oracletypeadt1.fixedDataSize = oracletypeadt.fixedDataSize;
        oracletypeadt1.alignmentRequirement = oracletypeadt.alignmentRequirement;
        oracletypeadt1.attrTypes = oracletypeadt.attrTypes;
        oracletypeadt1.sqlName = oracletypeadt.sqlName;
        oracletypeadt1.tdoCState = oracletypeadt.tdoCState;
        oracletypeadt1.toid = oracletypeadt.toid;
        oracletypeadt1.charSetId = oracletypeadt.charSetId;
        oracletypeadt1.charSetForm = oracletypeadt.charSetForm;
        oracletypeadt1.flattenedAttrNum = oracletypeadt.flattenedAttrNum;
        oracletypeadt1.statusBits = oracletypeadt.statusBits;
        oracletypeadt1.attrNames = oracletypeadt.attrNames;
        oracletypeadt1.attrTypeNames = oracletypeadt.attrTypeNames;
        oracletypeadt1.opcode = oracletypeadt.opcode;
        oracletypeadt1.idx = oracletypeadt.idx;
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeInt(statusBits);
        objectoutputstream.writeInt(tdsVersion);
        objectoutputstream.writeInt(typeVersion);
        objectoutputstream.writeObject(null);
        objectoutputstream.writeObject(null);
        objectoutputstream.writeLong(fixedDataSize);
        objectoutputstream.writeInt(alignmentRequirement);
        objectoutputstream.writeObject(attrTypes);
        objectoutputstream.writeObject(attrNames);
        objectoutputstream.writeObject(attrTypeNames);
        objectoutputstream.writeLong(tdoCState);
        objectoutputstream.writeObject(toid);
        objectoutputstream.writeObject(null);
        objectoutputstream.writeInt(charSetId);
        objectoutputstream.writeInt(charSetForm);
        objectoutputstream.writeBoolean(true);
        objectoutputstream.writeInt(flattenedAttrNum);
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        statusBits = objectinputstream.readInt();
        tdsVersion = objectinputstream.readInt();
        typeVersion = objectinputstream.readInt();
        objectinputstream.readObject();
        objectinputstream.readObject();
        objectinputstream.readLong();
        objectinputstream.readInt();
        attrTypes = (OracleType[])(OracleType[])objectinputstream.readObject();
        attrNames = (String[])(String[])objectinputstream.readObject();
        attrTypeNames = (String[])(String[])objectinputstream.readObject();
        objectinputstream.readLong();
        toid = (byte[])(byte[])objectinputstream.readObject();
        objectinputstream.readObject();
        charSetId = objectinputstream.readInt();
        charSetForm = objectinputstream.readInt();
        objectinputstream.readBoolean();
        flattenedAttrNum = objectinputstream.readInt();
    }

    public void setConnection(OracleConnection oracleconnection)
        throws SQLException
    {
        synchronized(oracleconnection)
        {
            connection = oracleconnection;
            for(int i = 0; i < attrTypes.length; i++)
                attrTypes[i].setConnection(connection);

        }
    }

    private void setStatusBits(int i)
    {
        synchronized(connection)
        {
            statusBits |= i;
        }
    }

    private void maskAndSetStatusBits(int i, int j)
    {
        synchronized(connection)
        {
            statusBits &= i;
            statusBits |= j;
        }
    }

    private void printUnsignedByteArray(byte abyte0[], PrintWriter printwriter)
    {
        int i = abyte0.length;
        int ai[] = Util.toJavaUnsignedBytes(abyte0);
        for(int j = 0; j < i; j++)
            printwriter.print((new StringBuilder()).append("0x").append(Integer.toHexString(ai[j])).append(" ").toString());

        printwriter.println();
        for(int k = 0; k < i; k++)
            printwriter.print((new StringBuilder()).append(ai[k]).append(" ").toString());

        printwriter.println();
    }

    public void initChildNamesRecursively(Map map)
        throws SQLException
    {
        TypeTreeElement typetreeelement = (TypeTreeElement)(TypeTreeElement)map.get(sqlName);
        if(attrTypes != null && attrTypes.length > 0)
        {
            for(int i = 0; i < attrTypes.length; i++)
            {
                OracleType oracletype = attrTypes[i];
                oracletype.setNames(typetreeelement.getChildSchemaName(i + 1), typetreeelement.getChildTypeName(i + 1));
                oracletype.initChildNamesRecursively(map);
                oracletype.cacheDescriptor();
            }

        }
    }

    public void cacheDescriptor()
        throws SQLException
    {
        descriptor = StructDescriptor.createDescriptor(this);
    }

    private void initMetaData1()
        throws SQLException
    {
        short word0 = connection.getVersionNumber();
        if(word0 >= 9000)
            initMetaData1_9_0();
        else
            initMetaData1_pre_9_0();
    }

    public Boolean isInstanciable()
        throws SQLException
    {
        if(isInstanciable == null)
            initMetaData1();
        return isInstanciable;
    }

    public String getSuperTypeName()
        throws SQLException
    {
        if(superTypeName == null)
            initMetaData1();
        return superTypeName;
    }

    public int getNumberOfLocalAttributes()
        throws SQLException
    {
        if(numberOfLocalAttributes == -1)
            initMetaData1();
        return numberOfLocalAttributes;
    }

    public String[] getSubtypeNames()
        throws SQLException
    {
        if(subTypeNames == null)
            initMetaData1();
        return subTypeNames;
    }

    private void initMetaData1_9_0()
        throws SQLException
    {
        int i;
        if(getTOID() != null)
        {
            initMetaData1_9_0UseToid();
            return;
        }
        i = 0;
        if(sqlName == null)
            getFullName();
        OracleConnection oracleconnection = connection;
        JVM INSTR monitorenter ;
        OracleTypeADT oracletypeadt = this;
        JVM INSTR monitorenter ;
        PreparedStatement preparedstatement;
        OracleCallableStatement oraclecallablestatement;
        ResultSet resultset;
        if(numberOfLocalAttributes != -1)
            break MISSING_BLOCK_LABEL_509;
        preparedstatement = null;
        oraclecallablestatement = null;
        resultset = null;
        byte byte0 = -1;
        int j;
        do
        {
            switch(i)
            {
            case 0: // '\0'
                preparedstatement = connection.prepareStatement(initMetaData1_9_0_SQL[i]);
                preparedstatement.setString(1, sqlName.getSimpleName());
                preparedstatement.setString(2, sqlName.getSchema());
                preparedstatement.setFetchSize(1);
                resultset = preparedstatement.executeQuery();
                break;

            case 1: // '\001'
            case 2: // '\002'
                try
                {
                    oraclecallablestatement = (OracleCallableStatement)connection.prepareCall(initMetaData1_9_0_SQL[i]);
                    oraclecallablestatement.setString(1, sqlName.getSimpleName());
                    oraclecallablestatement.registerOutParameter(2, -10);
                    oraclecallablestatement.execute();
                    resultset = oraclecallablestatement.getCursor(2);
                    resultset.setFetchSize(1);
                }
                catch(SQLException sqlexception)
                {
                    if(sqlexception.getErrorCode() == 1403)
                    {
                        if(i == 1)
                        {
                            oraclecallablestatement.close();
                            i++;
                        } else
                        {
                            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Inconsistent catalog view");
                            sqlexception2.fillInStackTrace();
                            throw sqlexception2;
                        }
                    } else
                    {
                        throw sqlexception;
                    }
                    continue;
                }
                break;
            }
            if(resultset.next())
            {
                isInstanciable = new Boolean(resultset.getString(1).equals("YES"));
                superTypeName = (new StringBuilder()).append(resultset.getString(2)).append(".").append(resultset.getString(3)).toString();
                j = resultset.getInt(4);
                break;
            }
            if(i == 2)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Inconsistent catalog view");
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
            resultset.close();
            if(oraclecallablestatement != null)
                oraclecallablestatement.close();
            i++;
        } while(true);
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        if(oraclecallablestatement != null)
            oraclecallablestatement.close();
        break MISSING_BLOCK_LABEL_503;
        Exception exception;
        exception;
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        if(oraclecallablestatement != null)
            oraclecallablestatement.close();
        throw exception;
        numberOfLocalAttributes = j;
        break MISSING_BLOCK_LABEL_533;
        Exception exception1;
        exception1;
        oracletypeadt;
        JVM INSTR monitorexit ;
        throw exception1;
        Exception exception2;
        exception2;
        throw exception2;
    }

    private void initMetaData1_9_0UseToid()
        throws SQLException
    {
        String s;
        PreparedStatement preparedstatement;
        ResultSet resultset;
        ResultSet resultset1;
        s = "SELECT INSTANTIABLE, supertype_owner, supertype_name, LOCAL_ATTRIBUTES, cursor(select owner, type_name from all_types WHERE supertype_name = t.type_name and supertype_owner = t.owner)  FROM all_types t WHERE TYPE_OID = :3";
        preparedstatement = null;
        resultset = null;
        resultset1 = null;
        if(sqlName == null)
            getFullName();
        preparedstatement = connection.prepareStatement(s);
        preparedstatement.setBytes(1, getTOID());
        preparedstatement.setFetchSize(1);
        resultset = preparedstatement.executeQuery();
        if(resultset.next())
        {
            isInstanciable = new Boolean(resultset.getString(1).equals("YES"));
            superTypeName = (new StringBuilder()).append(resultset.getString(2)).append(".").append(resultset.getString(3)).toString();
            numberOfLocalAttributes = resultset.getInt(4);
            resultset1 = (ResultSet)resultset.getObject(5);
            ArrayList arraylist = new ArrayList(5);
            for(; resultset1.next(); arraylist.add((new StringBuilder()).append(resultset1.getString(1)).append(".").append(resultset1.getString(2)).toString()));
            subTypeNames = new String[arraylist.size()];
            for(int i = 0; i < subTypeNames.length; i++)
                subTypeNames[i] = (String)arraylist.get(i);

        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Inconsistent catalog view");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(resultset1 != null)
            resultset1.close();
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        break MISSING_BLOCK_LABEL_367;
        Exception exception;
        exception;
        if(resultset1 != null)
            resultset1.close();
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        throw exception;
    }

    private synchronized void initMetaData1_pre_9_0()
        throws SQLException
    {
        isInstanciable = new Boolean(true);
        superTypeName = "";
        numberOfLocalAttributes = 0;
    }

    private void initMetaData2()
        throws SQLException
    {
        short word0 = connection.getVersionNumber();
        if(word0 >= 9000)
            initMetaData2_9_0();
        else
            initMetaData2_pre_9_0();
    }

    private void initMetaData2_9_0()
        throws SQLException
    {
        if(getTOID() != null)
        {
            initMetaData1_9_0UseToid();
            return;
        }
        if(sqlName == null)
            getFullName();
        OracleConnection oracleconnection = connection;
        JVM INSTR monitorenter ;
        OracleTypeADT oracletypeadt = this;
        JVM INSTR monitorenter ;
        PreparedStatement preparedstatement;
        ResultSet resultset;
        if(subTypeNames != null)
            break MISSING_BLOCK_LABEL_272;
        preparedstatement = null;
        resultset = null;
        Object obj = null;
        String as[];
        preparedstatement = connection.prepareStatement("select owner, type_name from all_types where supertype_name = :1 and supertype_owner = :2");
        preparedstatement.setString(1, sqlName.getSimpleName());
        preparedstatement.setString(2, sqlName.getSchema());
        resultset = preparedstatement.executeQuery();
        Vector vector = new Vector();
        for(; resultset.next(); vector.addElement((new StringBuilder()).append(resultset.getString(1)).append(".").append(resultset.getString(2)).toString()));
        as = new String[vector.size()];
        for(int i = 0; i < as.length; i++)
            as[i] = (String)vector.elementAt(i);

        vector.removeAllElements();
        vector = null;
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        break MISSING_BLOCK_LABEL_266;
        Exception exception;
        exception;
        if(resultset != null)
            resultset.close();
        if(preparedstatement != null)
            preparedstatement.close();
        throw exception;
        subTypeNames = as;
        break MISSING_BLOCK_LABEL_296;
        Exception exception1;
        exception1;
        oracletypeadt;
        JVM INSTR monitorexit ;
        throw exception1;
        Exception exception2;
        exception2;
        throw exception2;
    }

    private void initMetaData2_pre_9_0()
        throws SQLException
    {
        subTypeNames = new String[0];
    }

    public void printXML(PrintWriter printwriter, int i)
        throws SQLException
    {
        printXML(printwriter, i, false);
    }

    public void printXML(PrintWriter printwriter, int i, boolean flag)
        throws SQLException
    {
        for(int j = 0; j < i; j++)
            printwriter.print("  ");

        printwriter.print((new StringBuilder()).append("<OracleTypeADT sqlName=\"").append(sqlName).append("\" ").toString());
        printwriter.print((new StringBuilder()).append(" typecode=\"").append(typeCode).append("\"").toString());
        if(tdsVersion != -9999)
            printwriter.print((new StringBuilder()).append(" tds_version=\"").append(tdsVersion).append("\"").toString());
        printwriter.println();
        for(int k = 0; k < i + 4; k++)
            printwriter.print("  ");

        printwriter.println((new StringBuilder()).append(" is_embedded=\"").append(isEmbeddedADT()).append("\"").append(" is_top_level=\"").append(isTopADT()).append("\"").append(" is_upt=\"").append(isUptADT()).append("\"").append(" finalType=\"").append(isFinalType()).append("\"").append(" subtype=\"").append(isSubType()).append("\">").toString());
        if(attrTypes != null && attrTypes.length > 0)
        {
            for(int l = 0; l < i + 1; l++)
                printwriter.print("  ");

            printwriter.println("<attributes>");
            for(int i1 = 0; i1 < attrTypes.length; i1++)
            {
                for(int l1 = 0; l1 < i + 2; l1++)
                    printwriter.print("  ");

                printwriter.println((new StringBuilder()).append("<attribute name=\"").append(getAttributeName(i1 + 1, flag)).append("\" ").append(" type=\"").append(getAttributeType(i1 + 1, false)).append("\" >").toString());
                attrTypes[i1].printXML(printwriter, i + 3, flag);
                for(int i2 = 0; i2 < i + 2; i2++)
                    printwriter.print("  ");

                printwriter.println("</attribute> ");
            }

            for(int j1 = 0; j1 < i + 1; j1++)
                printwriter.print("  ");

            printwriter.println("</attributes>");
        }
        for(int k1 = 0; k1 < i; k1++)
            printwriter.print("  ");

        printwriter.println("</OracleTypeADT>");
    }

}
