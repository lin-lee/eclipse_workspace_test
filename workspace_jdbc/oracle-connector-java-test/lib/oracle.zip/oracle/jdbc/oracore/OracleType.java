// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleType.java

package oracle.jdbc.oracore;

import java.io.*;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc.oracore:
//            PickleContext, TDSReader

public abstract class OracleType
    implements Serializable
{

    static final long serialVersionUID = 0xc6c411520d11f168L;
    public static final int STYLE_ARRAY_LENGTH = 0;
    public static final int STYLE_DATUM = 1;
    public static final int STYLE_JAVA = 2;
    public static final int STYLE_RAWBYTE = 3;
    public static final int STYLE_INT = 4;
    public static final int STYLE_DOUBLE = 5;
    public static final int STYLE_FLOAT = 6;
    public static final int STYLE_LONG = 7;
    public static final int STYLE_SHORT = 8;
    public static final int STYLE_SKIP = 9;
    static final int FORMAT_ADT_ATTR = 1;
    static final int FORMAT_COLL_ELEM = 2;
    static final int FORMAT_COLL_ELEM_NO_INDICATOR = 3;
    int typeCode;
    int dbTypeCode;
    boolean metaDataInitialized;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleType()
    {
        metaDataInitialized = false;
    }

    public OracleType(int i)
    {
        this();
        typeCode = i;
    }

    public boolean isInHierarchyOf(OracleType oracletype)
        throws SQLException
    {
        return false;
    }

    public boolean isInHierarchyOf(StructDescriptor structdescriptor)
        throws SQLException
    {
        return false;
    }

    public boolean isObjectType()
    {
        return false;
    }

    public TypeDescriptor getTypeDescriptor()
    {
        return null;
    }

    public abstract Datum toDatum(Object obj, OracleConnection oracleconnection)
        throws SQLException;

    public Datum[] toDatumArray(Object obj, OracleConnection oracleconnection, long l, int i)
        throws SQLException
    {
        Datum adatum[] = null;
        if(obj != null)
            if(obj instanceof Object[])
            {
                Object aobj[] = (Object[])(Object[])obj;
                int j = (int)(i != -1 ? Math.min(((long)aobj.length - l) + 1L, i) : aobj.length);
                adatum = new Datum[j];
                for(int k = 0; k < j; k++)
                    adatum[k] = toDatum(aobj[((int)l + k) - 1], oracleconnection);

            } else
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, obj);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        return adatum;
    }

    public void setTypeCode(int i)
    {
        typeCode = i;
    }

    public int getTypeCode()
        throws SQLException
    {
        return typeCode;
    }

    public void setDBTypeCode(int i)
    {
        dbTypeCode = i;
    }

    public int getDBTypeCode()
        throws SQLException
    {
        return dbTypeCode;
    }

    public void parseTDSrec(TDSReader tdsreader)
        throws SQLException
    {
    }

    protected Object unpickle81rec(PickleContext picklecontext, int i, Map map)
        throws SQLException
    {
        if(i == 9)
        {
            picklecontext.skipDataValue();
            return null;
        } else
        {
            byte abyte0[] = picklecontext.readDataValue();
            return toObject(abyte0, i, map);
        }
    }

    protected Object unpickle81rec(PickleContext picklecontext, byte byte0, int i, Map map)
        throws SQLException
    {
        if(i == 9)
        {
            picklecontext.skipDataValue();
            return null;
        } else
        {
            byte abyte0[] = picklecontext.readDataValue(byte0);
            return toObject(abyte0, i, map);
        }
    }

    protected Datum unpickle81datumAsNull(PickleContext picklecontext, byte byte0, byte byte1)
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    protected Object toObject(byte abyte0[], int i, Map map)
        throws SQLException
    {
        return null;
    }

    protected int pickle81(PickleContext picklecontext, Datum datum)
        throws SQLException
    {
        int i = picklecontext.writeLength((int)datum.getLength());
        i += picklecontext.writeData(datum.shareBytes());
        return i;
    }

    void writeSerializedFields(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        writeObject(objectoutputstream);
    }

    void readSerializedFields(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        readObject(objectinputstream);
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeInt(0);
        objectoutputstream.writeInt(0);
        objectoutputstream.writeInt(0);
        objectoutputstream.writeInt(0);
        objectoutputstream.writeInt(typeCode);
        objectoutputstream.writeInt(dbTypeCode);
        objectoutputstream.writeBoolean(metaDataInitialized);
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        int i = objectinputstream.readInt();
        int j = objectinputstream.readInt();
        int k = objectinputstream.readInt();
        int l = objectinputstream.readInt();
        typeCode = objectinputstream.readInt();
        dbTypeCode = objectinputstream.readInt();
        metaDataInitialized = objectinputstream.readBoolean();
    }

    public void setConnection(OracleConnection oracleconnection)
        throws SQLException
    {
    }

    public boolean isNCHAR()
        throws SQLException
    {
        return false;
    }

    public int getPrecision()
        throws SQLException
    {
        return 0;
    }

    public int getScale()
        throws SQLException
    {
        return 0;
    }

    public void initMetadataRecursively()
        throws SQLException
    {
    }

    public void initNamesRecursively()
        throws SQLException
    {
    }

    public void initChildNamesRecursively(Map map)
        throws SQLException
    {
    }

    public void cacheDescriptor()
        throws SQLException
    {
    }

    public void setNames(String s, String s1)
        throws SQLException
    {
    }

    public String toXMLString()
        throws SQLException
    {
        StringWriter stringwriter = new StringWriter();
        PrintWriter printwriter = new PrintWriter(stringwriter);
        printXMLHeader(printwriter);
        printXML(printwriter, 0);
        return stringwriter.getBuffer().substring(0);
    }

    public void printXML(PrintStream printstream)
        throws SQLException
    {
        PrintWriter printwriter = new PrintWriter(printstream, true);
        printXMLHeader(printwriter);
        printXML(printwriter, 0);
    }

    void printXMLHeader(PrintWriter printwriter)
        throws SQLException
    {
        printwriter.println("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
    }

    public void printXML(PrintWriter printwriter, int i)
        throws SQLException
    {
        printXML(printwriter, i, false);
    }

    public void printXML(PrintWriter printwriter, int i, boolean flag)
        throws SQLException
    {
        for(int j = 0; j < i; j++)
            printwriter.print("  ");

        printwriter.println((new StringBuilder()).append("<OracleType typecode=\"").append(typeCode).append("\"").append(" />").toString());
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
