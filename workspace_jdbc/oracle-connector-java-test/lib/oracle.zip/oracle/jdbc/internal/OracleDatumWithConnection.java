// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDatumWithConnection.java

package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import oracle.jdbc.OracleConnection;

// Referenced classes of package oracle.jdbc.internal:
//            OracleConnection

public interface OracleDatumWithConnection
{

    public abstract byte[] shareBytes();

    public abstract long getLength();

    public abstract void setBytes(byte abyte0[]);

    public abstract void setShareBytes(byte abyte0[]);

    public abstract byte[] getBytes();

    public abstract InputStream getStream()
        throws SQLException;

    public abstract String stringValue()
        throws SQLException;

    public abstract String stringValue(Connection connection)
        throws SQLException;

    public abstract boolean booleanValue()
        throws SQLException;

    public abstract int intValue()
        throws SQLException;

    public abstract long longValue()
        throws SQLException;

    public abstract float floatValue()
        throws SQLException;

    public abstract double doubleValue()
        throws SQLException;

    public abstract byte byteValue()
        throws SQLException;

    public abstract BigDecimal bigDecimalValue()
        throws SQLException;

    public abstract Date dateValue()
        throws SQLException;

    public abstract Time timeValue()
        throws SQLException;

    public abstract Time timeValue(Calendar calendar)
        throws SQLException;

    public abstract Timestamp timestampValue()
        throws SQLException;

    public abstract Timestamp timestampValue(Calendar calendar)
        throws SQLException;

    public abstract Reader characterStreamValue()
        throws SQLException;

    public abstract InputStream asciiStreamValue()
        throws SQLException;

    public abstract InputStream binaryStreamValue()
        throws SQLException;

    public abstract boolean isConvertibleTo(Class class1);

    public abstract Object toJdbc()
        throws SQLException;

    public abstract Object makeJdbcArray(int i);

    public abstract Connection getJavaSqlConnection()
        throws SQLException;

    public abstract OracleConnection getOracleConnection()
        throws SQLException;

    public abstract oracle.jdbc.internal.OracleConnection getInternalConnection()
        throws SQLException;

    public abstract oracle.jdbc.driver.OracleConnection getConnection()
        throws SQLException;

    public abstract void setPhysicalConnectionOf(Connection connection);
}
