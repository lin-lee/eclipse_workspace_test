// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   XSEventListener.java

package oracle.jdbc.internal;

import java.util.EventListener;

// Referenced classes of package oracle.jdbc.internal:
//            XSEvent

public interface XSEventListener
    extends EventListener
{

    public abstract void onXSEvent(XSEvent xsevent);
}
