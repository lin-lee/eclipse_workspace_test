// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleBfile.java

package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.sql.BFILE;
import oracle.sql.BfileDBAccess;

// Referenced classes of package oracle.jdbc.internal:
//            OracleDatumWithConnection

public interface OracleBfile
    extends OracleDatumWithConnection, oracle.jdbc.OracleBfile
{

    public abstract long position(BFILE bfile, long l)
        throws SQLException;

    public abstract byte[] getLocator();

    public abstract void setLocator(byte abyte0[]);

    public abstract Object toJdbc()
        throws SQLException;

    public abstract boolean isConvertibleTo(Class class1);

    public abstract Reader characterStreamValue()
        throws SQLException;

    public abstract InputStream asciiStreamValue()
        throws SQLException;

    public abstract InputStream binaryStreamValue()
        throws SQLException;

    public abstract Object makeJdbcArray(int i);

    public abstract BfileDBAccess getDBAccess()
        throws SQLException;

    public abstract void setLength(long l);

    public abstract Connection getJavaSqlConnection()
        throws SQLException;
}
