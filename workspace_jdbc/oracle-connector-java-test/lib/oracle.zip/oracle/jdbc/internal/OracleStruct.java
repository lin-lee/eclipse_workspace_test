// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleStruct.java

package oracle.jdbc.internal;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Map;
import oracle.sql.Datum;
import oracle.sql.ORADataFactory;
import oracle.sql.StructDescriptor;

// Referenced classes of package oracle.jdbc.internal:
//            OracleDatumWithConnection

public interface OracleStruct
    extends OracleDatumWithConnection, oracle.jdbc.OracleStruct
{

    public abstract StructDescriptor getDescriptor()
        throws SQLException;

    public abstract void setDescriptor(StructDescriptor structdescriptor);

    public abstract Datum[] getOracleAttributes()
        throws SQLException;

    public abstract Map getMap();

    public abstract byte[] toBytes()
        throws SQLException;

    public abstract void setDatumArray(Datum adatum[]);

    public abstract void setObjArray(Object aobj[])
        throws SQLException;

    public abstract Object toJdbc()
        throws SQLException;

    public abstract Object toJdbc(Map map)
        throws SQLException;

    public abstract Object toClass(Class class1)
        throws SQLException;

    public abstract Object toClass(Class class1, Map map)
        throws SQLException;

    public abstract boolean isConvertibleTo(Class class1);

    public abstract Object makeJdbcArray(int i);

    public abstract void setAutoBuffering(boolean flag)
        throws SQLException;

    public abstract boolean getAutoBuffering()
        throws SQLException;

    public abstract void setImage(byte abyte0[], long l, long l1)
        throws SQLException;

    public abstract void setImageLength(long l)
        throws SQLException;

    public abstract long getImageOffset();

    public abstract long getImageLength();

    public abstract ORADataFactory getORADataFactory(Hashtable hashtable, String s)
        throws SQLException;

    public abstract boolean isInHierarchyOf(String s)
        throws SQLException;

    public abstract Connection getJavaSqlConnection()
        throws SQLException;
}
