// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   XSAttribute.java

package oracle.jdbc.internal;

import java.sql.SQLException;
import oracle.jdbc.driver.InternalFactory;

public abstract class XSAttribute
{

    public XSAttribute()
    {
    }

    public static final XSAttribute constructXSAttribute()
        throws SQLException
    {
        return InternalFactory.createXSAttribute();
    }

    public abstract void setAttributeName(String s)
        throws SQLException;

    public abstract void setAttributeValue(String s)
        throws SQLException;

    public abstract void setAttributeDefaultValue(String s)
        throws SQLException;

    public abstract void setFlag(long l)
        throws SQLException;

    public abstract String getAttributeName();

    public abstract String getAttributeValue();

    public abstract String getAttributeDefaultValue();

    public abstract long getFlag();
}
