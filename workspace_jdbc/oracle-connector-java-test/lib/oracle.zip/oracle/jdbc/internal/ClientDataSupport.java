// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   ClientDataSupport.java

package oracle.jdbc.internal;


public interface ClientDataSupport
{

    public abstract Object getClientData(Object obj);

    public abstract Object setClientData(Object obj, Object obj1);

    public abstract Object removeClientData(Object obj);
}
