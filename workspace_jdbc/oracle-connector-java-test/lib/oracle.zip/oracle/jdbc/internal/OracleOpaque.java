// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleOpaque.java

package oracle.jdbc.internal;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import oracle.sql.OpaqueDescriptor;

// Referenced classes of package oracle.jdbc.internal:
//            OracleDatumWithConnection

public interface OracleOpaque
    extends OracleDatumWithConnection, oracle.jdbc.OracleOpaque
{

    public abstract OpaqueDescriptor getDescriptor()
        throws SQLException;

    public abstract void setDescriptor(OpaqueDescriptor opaquedescriptor);

    public abstract byte[] toBytes()
        throws SQLException;

    public abstract byte[] getBytesValue()
        throws SQLException;

    public abstract void setValue(byte abyte0[])
        throws SQLException;

    public abstract boolean isConvertibleTo(Class class1);

    public abstract Object makeJdbcArray(int i);

    public abstract Map getMap();

    public abstract Object toJdbc()
        throws SQLException;

    public abstract Object toJdbc(Map map)
        throws SQLException;

    public abstract Object toClass(Class class1)
        throws SQLException;

    public abstract Object toClass(Class class1, Map map)
        throws SQLException;

    public abstract void setImage(byte abyte0[], long l, long l1)
        throws SQLException;

    public abstract void setImageLength(long l)
        throws SQLException;

    public abstract long getImageOffset();

    public abstract long getImageLength();

    public abstract Connection getJavaSqlConnection()
        throws SQLException;
}
