// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePreparedStatement.java

package oracle.jdbc.internal;

import java.io.Reader;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.internal:
//            OracleStatement

public interface OraclePreparedStatement
    extends oracle.jdbc.OraclePreparedStatement, OracleStatement
{

    public abstract void setCheckBindTypes(boolean flag);

    public abstract void setInternalBytes(int i, byte abyte0[], int j)
        throws SQLException;

    public abstract void enterImplicitCache()
        throws SQLException;

    public abstract void enterExplicitCache()
        throws SQLException;

    public abstract void exitImplicitCacheToActive()
        throws SQLException;

    public abstract void exitExplicitCacheToActive()
        throws SQLException;

    public abstract void exitImplicitCacheToClose()
        throws SQLException;

    public abstract void exitExplicitCacheToClose()
        throws SQLException;

    /**
     * @deprecated Method setCharacterStreamAtName is deprecated
     */

    public abstract void setCharacterStreamAtName(String s, Reader reader, int i)
        throws SQLException;

    public abstract String getOriginalSql()
        throws SQLException;
}
