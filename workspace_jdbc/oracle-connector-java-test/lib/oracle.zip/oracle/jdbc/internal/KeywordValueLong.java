// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   KeywordValueLong.java

package oracle.jdbc.internal;

import java.sql.SQLException;
import oracle.jdbc.driver.InternalFactory;

public abstract class KeywordValueLong
{

    public KeywordValueLong()
    {
    }

    public abstract int getKeyword()
        throws SQLException;

    public abstract byte[] getBinaryValue()
        throws SQLException;

    public abstract String getTextValue()
        throws SQLException;

    public static final KeywordValueLong constructKeywordValue(int i, String s)
        throws SQLException
    {
        return InternalFactory.createKeywordValueLong(i, s, null);
    }

    public static final KeywordValueLong constructKeywordValue(int i, byte abyte0[])
        throws SQLException
    {
        return InternalFactory.createKeywordValueLong(i, null, abyte0);
    }
}
