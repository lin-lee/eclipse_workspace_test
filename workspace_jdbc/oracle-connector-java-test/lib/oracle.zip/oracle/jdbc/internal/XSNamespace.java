// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   XSNamespace.java

package oracle.jdbc.internal;

import java.sql.SQLException;
import oracle.jdbc.driver.InternalFactory;
import oracle.sql.TIMESTAMPTZ;

// Referenced classes of package oracle.jdbc.internal:
//            XSAttribute

public abstract class XSNamespace
{

    public static final int ACL_ID_LENGTH = 16;

    public XSNamespace()
    {
    }

    public static final XSNamespace constructXSNamespace()
        throws SQLException
    {
        return InternalFactory.createXSNamespace();
    }

    public abstract void setNamespaceName(String s)
        throws SQLException;

    public abstract void setTimestamp(TIMESTAMPTZ timestamptz)
        throws SQLException;

    public abstract void setFlag(long l)
        throws SQLException;

    public abstract void setAttributes(XSAttribute axsattribute[])
        throws SQLException;

    public abstract void setACLIdList(byte abyte0[][])
        throws SQLException;

    public abstract String getNamespaceName();

    public abstract TIMESTAMPTZ getTimestamp();

    public abstract long getFlag();

    public abstract XSAttribute[] getAttributes();

    public abstract byte[][] getACLIdList();
}
