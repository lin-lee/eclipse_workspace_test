// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleBlob.java

package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.sql.BlobDBAccess;

// Referenced classes of package oracle.jdbc.internal:
//            OracleDatumWithConnection

public interface OracleBlob
    extends OracleDatumWithConnection, oracle.jdbc.OracleBlob
{

    public abstract Object toJdbc()
        throws SQLException;

    public abstract boolean isConvertibleTo(Class class1);

    /**
     * @deprecated Method putBytes is deprecated
     */

    public abstract int putBytes(long l, byte abyte0[])
        throws SQLException;

    /**
     * @deprecated Method putBytes is deprecated
     */

    public abstract int putBytes(long l, byte abyte0[], int i)
        throws SQLException;

    /**
     * @deprecated Method getBinaryOutputStream is deprecated
     */

    public abstract OutputStream getBinaryOutputStream()
        throws SQLException;

    /**
     * @deprecated Method getBinaryOutputStream is deprecated
     */

    public abstract OutputStream getBinaryOutputStream(long l)
        throws SQLException;

    public abstract Reader characterStreamValue()
        throws SQLException;

    public abstract InputStream asciiStreamValue()
        throws SQLException;

    public abstract InputStream binaryStreamValue()
        throws SQLException;

    public abstract byte[] getLocator();

    public abstract void setLocator(byte abyte0[]);

    public abstract int getChunkSize()
        throws SQLException;

    public abstract int getBufferSize()
        throws SQLException;

    /**
     * @deprecated Method trim is deprecated
     */

    public abstract void trim(long l)
        throws SQLException;

    public abstract Object makeJdbcArray(int i);

    public abstract BlobDBAccess getDBAccess()
        throws SQLException;

    public abstract Connection getJavaSqlConnection()
        throws SQLException;

    public abstract void setLength(long l);

    public abstract void setChunkSize(int i);

    public abstract void setPrefetchedData(byte abyte0[]);

    public abstract void setPrefetchedData(byte abyte0[], int i);

    public abstract byte[] getPrefetchedData();

    public abstract int getPrefetchedDataSize();

    public abstract void setActivePrefetch(boolean flag);

    public abstract void clearCachedData();

    public abstract boolean isActivePrefetch();
}
