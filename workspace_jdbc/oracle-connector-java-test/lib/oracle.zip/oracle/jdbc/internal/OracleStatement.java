// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleStatement.java

package oracle.jdbc.internal;

import java.sql.SQLException;

public interface OracleStatement
    extends oracle.jdbc.OracleStatement
{
    public static final class SqlKind extends Enum
    {

        public static final SqlKind SELECT;
        public static final SqlKind DELETE;
        public static final SqlKind INSERT;
        public static final SqlKind MERGE;
        public static final SqlKind UPDATE;
        public static final SqlKind PLSQL_BLOCK;
        public static final SqlKind CALL_BLOCK;
        public static final SqlKind SELECT_FOR_UPDATE;
        public static final SqlKind ALTER_SESSION;
        public static final SqlKind OTHER;
        public static final SqlKind UNINITIALIZED;
        private final boolean dml;
        private final boolean plsqlOrCall;
        private final boolean select;
        private final boolean other;
        private static final SqlKind $VALUES[];

        public static SqlKind[] values()
        {
            return (SqlKind[])$VALUES.clone();
        }

        public static SqlKind valueOf(String s)
        {
            return (SqlKind)Enum.valueOf(oracle/jdbc/internal/OracleStatement$SqlKind, s);
        }

        public boolean isPlsqlOrCall()
        {
            return plsqlOrCall;
        }

        public boolean isDML()
        {
            return dml;
        }

        public boolean isSELECT()
        {
            return select;
        }

        public boolean isOTHER()
        {
            return other;
        }

        static 
        {
            SELECT = new SqlKind("SELECT", 0, false, false, true, false);
            DELETE = new SqlKind("DELETE", 1, false, true, false, false);
            INSERT = new SqlKind("INSERT", 2, false, true, false, false);
            MERGE = new SqlKind("MERGE", 3, false, true, false, false);
            UPDATE = new SqlKind("UPDATE", 4, false, true, false, false);
            PLSQL_BLOCK = new SqlKind("PLSQL_BLOCK", 5, true, false, false, false);
            CALL_BLOCK = new SqlKind("CALL_BLOCK", 6, true, false, false, false);
            SELECT_FOR_UPDATE = new SqlKind("SELECT_FOR_UPDATE", 7, false, false, true, false);
            ALTER_SESSION = new SqlKind("ALTER_SESSION", 8, false, false, false, true);
            OTHER = new SqlKind("OTHER", 9, false, false, false, true);
            UNINITIALIZED = new SqlKind("UNINITIALIZED", 10, false, false, false, false);
            $VALUES = (new SqlKind[] {
                SELECT, DELETE, INSERT, MERGE, UPDATE, PLSQL_BLOCK, CALL_BLOCK, SELECT_FOR_UPDATE, ALTER_SESSION, OTHER, 
                UNINITIALIZED
            });
        }

        private SqlKind(String s, int i, boolean flag, boolean flag1, boolean flag2, boolean flag3)
        {
            super(s, i);
            dml = flag1;
            plsqlOrCall = flag;
            select = flag2;
            other = flag3;
        }
    }


    public static final int DEFAULT_RSET_TYPE = 1;
    public static final int CLOSED = 0;
    public static final int ACTIVE = 1;
    public static final int CACHED = 2;
    public static final int NON_CACHED = 3;

    public abstract void setFixedString(boolean flag);

    public abstract boolean getFixedString();

    public abstract int sendBatch()
        throws SQLException;

    public abstract boolean getserverCursor();

    public abstract int getcacheState();

    public abstract int getstatementType();

    public abstract SqlKind getSqlKind()
        throws SQLException;

    public abstract long getChecksum()
        throws SQLException;

    public abstract void setSnapshotSCN(long l)
        throws SQLException;
}
