// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleArray.java

package oracle.jdbc.internal;

import java.sql.SQLException;
import java.util.Map;
import oracle.sql.ArrayDescriptor;
import oracle.sql.Datum;

// Referenced classes of package oracle.jdbc.internal:
//            OracleDatumWithConnection

public interface OracleArray
    extends OracleDatumWithConnection, oracle.jdbc.OracleArray
{

    public static final int ACCESS_FORWARD = 1;
    public static final int ACCESS_REVERSE = 2;
    public static final int ACCESS_UNKNOWN = 3;

    public abstract Datum[] getOracleArray()
        throws SQLException;

    public abstract Datum[] getOracleArray(long l, int i)
        throws SQLException;

    public abstract void setAutoBuffering(boolean flag)
        throws SQLException;

    public abstract boolean getAutoBuffering()
        throws SQLException;

    public abstract void setAutoIndexing(boolean flag, int i)
        throws SQLException;

    public abstract void setAutoIndexing(boolean flag)
        throws SQLException;

    public abstract boolean getAutoIndexing()
        throws SQLException;

    public abstract int getAccessDirection()
        throws SQLException;

    public abstract ArrayDescriptor getDescriptor()
        throws SQLException;

    public abstract Map getMap()
        throws SQLException;

    public abstract byte[] toBytes()
        throws SQLException;

    public abstract void setDatumArray(Datum adatum[]);

    public abstract void setObjArray(Object obj)
        throws SQLException;

    public abstract void setLocator(byte abyte0[]);

    public abstract void setPrefixSegment(byte abyte0[]);

    public abstract void setPrefixFlag(byte byte0);

    public abstract byte[] getLocator();

    public abstract void setLength(int i);

    public abstract boolean hasDataSeg();

    public abstract boolean isInline();

    public abstract boolean isConvertibleTo(Class class1);

    public abstract Object makeJdbcArray(int i);

    public abstract void setLastIndexOffset(long l, long l1)
        throws SQLException;

    public abstract void setIndexOffset(long l, long l1)
        throws SQLException;

    public abstract long getLastIndex()
        throws SQLException;

    public abstract long getLastOffset()
        throws SQLException;

    public abstract long getOffset(long l)
        throws SQLException;

    public abstract void setImage(byte abyte0[], long l, long l1)
        throws SQLException;

    public abstract void setImageLength(long l)
        throws SQLException;

    public abstract long getImageOffset();

    public abstract long getImageLength();
}
