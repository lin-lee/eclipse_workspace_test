// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleClob.java

package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.sql.ClobDBAccess;

// Referenced classes of package oracle.jdbc.internal:
//            OracleDatumWithConnection

public interface OracleClob
    extends OracleDatumWithConnection, oracle.jdbc.OracleClob
{

    public abstract InputStream getAsciiStream(long l)
        throws SQLException;

    public abstract Reader getCharacterStream(long l)
        throws SQLException;

    public abstract boolean isNCLOB();

    public abstract int getChars(long l, int i, char ac[])
        throws SQLException;

    public abstract int putChars(long l, char ac[])
        throws SQLException;

    public abstract int putChars(long l, char ac[], int i, int j)
        throws SQLException;

    /**
     * @deprecated Method putString is deprecated
     */

    public abstract int putString(long l, String s)
        throws SQLException;

    public abstract int getChunkSize()
        throws SQLException;

    public abstract int getBufferSize()
        throws SQLException;

    public abstract Object toJdbc()
        throws SQLException;

    public abstract boolean isConvertibleTo(Class class1);

    public abstract Reader characterStreamValue()
        throws SQLException;

    public abstract InputStream asciiStreamValue()
        throws SQLException;

    public abstract InputStream binaryStreamValue()
        throws SQLException;

    public abstract String stringValue()
        throws SQLException;

    /**
     * @deprecated Method trim is deprecated
     */

    public abstract void trim(long l)
        throws SQLException;

    /**
     * @deprecated Method getAsciiOutputStream is deprecated
     */

    public abstract OutputStream getAsciiOutputStream(long l)
        throws SQLException;

    /**
     * @deprecated Method getCharacterOutputStream is deprecated
     */

    public abstract Writer getCharacterOutputStream(long l)
        throws SQLException;

    /**
     * @deprecated Method getCharacterOutputStream is deprecated
     */

    public abstract Writer getCharacterOutputStream()
        throws SQLException;

    /**
     * @deprecated Method getAsciiOutputStream is deprecated
     */

    public abstract OutputStream getAsciiOutputStream()
        throws SQLException;

    public abstract byte[] getLocator();

    public abstract void setLocator(byte abyte0[]);

    public abstract Object makeJdbcArray(int i);

    public abstract ClobDBAccess getDBAccess()
        throws SQLException;

    public abstract Connection getJavaSqlConnection()
        throws SQLException;

    public abstract void setLength(long l);

    public abstract void setChunkSize(int i);

    public abstract void setPrefetchedData(char ac[]);

    public abstract void setPrefetchedData(char ac[], int i);

    public abstract char[] getPrefetchedData();

    public abstract int getPrefetchedDataSize();

    public abstract void setActivePrefetch(boolean flag);

    public abstract void clearCachedData();

    public abstract boolean isActivePrefetch();
}
