// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   XSEvent.java

package oracle.jdbc.internal;

import java.util.EventObject;

// Referenced classes of package oracle.jdbc.internal:
//            KeywordValueLong

public abstract class XSEvent extends EventObject
{

    protected XSEvent(Object obj)
    {
        super(obj);
    }

    public abstract byte[] getSessionId();

    public abstract KeywordValueLong[] getDetails();

    public abstract int getFlags();
}
