// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleCallableStatement.java

package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.internal:
//            OraclePreparedStatement

public interface OracleCallableStatement
    extends oracle.jdbc.OracleCallableStatement, OraclePreparedStatement
{

    public abstract byte[] privateGetBytes(int i)
        throws SQLException;

    /**
     * @deprecated Method getBigDecimal is deprecated
     */

    public abstract BigDecimal getBigDecimal(String s, int i)
        throws SQLException;

    /**
     * @deprecated Method getAsciiStream is deprecated
     */

    public abstract InputStream getAsciiStream(String s)
        throws SQLException;

    /**
     * @deprecated Method getCharacterStream is deprecated
     */

    public abstract Reader getCharacterStream(String s)
        throws SQLException;
}
