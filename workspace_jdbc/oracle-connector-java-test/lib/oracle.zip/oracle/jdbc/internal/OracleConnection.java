// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConnection.java

package oracle.jdbc.internal;

import java.net.SocketException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.EnumSet;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;
import javax.transaction.xa.XAResource;
import oracle.jdbc.oracore.OracleTypeADT;
import oracle.jdbc.oracore.OracleTypeCLOB;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import oracle.jdbc.pool.OraclePooledConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.BFILE;
import oracle.sql.BLOB;
import oracle.sql.BfileDBAccess;
import oracle.sql.BlobDBAccess;
import oracle.sql.CLOB;
import oracle.sql.ClobDBAccess;
import oracle.sql.CustomDatum;
import oracle.sql.Datum;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMEZONETAB;

// Referenced classes of package oracle.jdbc.internal:
//            OracleStatement, KeywordValueLong, XSNamespace, XSEventListener

public interface OracleConnection
    extends oracle.jdbc.OracleConnection
{
    public static interface BufferCacheStatistics
    {

        public abstract int getId();

        public abstract int[] getBufferSizes();

        public abstract int getCacheHits(int i);

        public abstract int getCacheMisses(int i);

        public abstract int getBuffersCached(int i);

        public abstract int getBucketsFull(int i);

        public abstract int getReferencesCleared(int i);

        public abstract int getTooBigToCache();
    }

    public static final class XSOperationCode extends Enum
    {

        public static final XSOperationCode NAMESPACE_CREATE;
        public static final XSOperationCode NAMESPACE_DELETE;
        public static final XSOperationCode ATTRIBUTE_CREATE;
        public static final XSOperationCode ATTRIBUTE_SET;
        public static final XSOperationCode ATTRIBUTE_DELETE;
        public static final XSOperationCode ATTRIBUTE_RESET;
        private final int code;
        private static final XSOperationCode $VALUES[];

        public static XSOperationCode[] values()
        {
            return (XSOperationCode[])$VALUES.clone();
        }

        public static XSOperationCode valueOf(String s)
        {
            return (XSOperationCode)Enum.valueOf(oracle/jdbc/internal/OracleConnection$XSOperationCode, s);
        }

        public final int getCode()
        {
            return code;
        }

        static 
        {
            NAMESPACE_CREATE = new XSOperationCode("NAMESPACE_CREATE", 0, 1);
            NAMESPACE_DELETE = new XSOperationCode("NAMESPACE_DELETE", 1, 2);
            ATTRIBUTE_CREATE = new XSOperationCode("ATTRIBUTE_CREATE", 2, 3);
            ATTRIBUTE_SET = new XSOperationCode("ATTRIBUTE_SET", 3, 4);
            ATTRIBUTE_DELETE = new XSOperationCode("ATTRIBUTE_DELETE", 4, 5);
            ATTRIBUTE_RESET = new XSOperationCode("ATTRIBUTE_RESET", 5, 6);
            $VALUES = (new XSOperationCode[] {
                NAMESPACE_CREATE, NAMESPACE_DELETE, ATTRIBUTE_CREATE, ATTRIBUTE_SET, ATTRIBUTE_DELETE, ATTRIBUTE_RESET
            });
        }

        private XSOperationCode(String s, int i, int j)
        {
            super(s, i);
            code = j;
        }
    }

    public static final class TransactionState extends Enum
    {

        public static final TransactionState TRANSACTION_STARTED;
        public static final TransactionState TRANSACTION_ENDED;
        public static final TransactionState TRANSACTION_READONLY;
        public static final TransactionState TRANSACTION_INTENTION;
        private static final TransactionState $VALUES[];

        public static TransactionState[] values()
        {
            return (TransactionState[])$VALUES.clone();
        }

        public static TransactionState valueOf(String s)
        {
            return (TransactionState)Enum.valueOf(oracle/jdbc/internal/OracleConnection$TransactionState, s);
        }

        static 
        {
            TRANSACTION_STARTED = new TransactionState("TRANSACTION_STARTED", 0);
            TRANSACTION_ENDED = new TransactionState("TRANSACTION_ENDED", 1);
            TRANSACTION_READONLY = new TransactionState("TRANSACTION_READONLY", 2);
            TRANSACTION_INTENTION = new TransactionState("TRANSACTION_INTENTION", 3);
            $VALUES = (new TransactionState[] {
                TRANSACTION_STARTED, TRANSACTION_ENDED, TRANSACTION_READONLY, TRANSACTION_INTENTION
            });
        }

        private TransactionState(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class InstanceProperty extends Enum
    {

        public static final InstanceProperty ASM_VOLUME_SUPPORTED;
        public static final InstanceProperty INSTANCE_TYPE;
        private static final InstanceProperty $VALUES[];

        public static InstanceProperty[] values()
        {
            return (InstanceProperty[])$VALUES.clone();
        }

        public static InstanceProperty valueOf(String s)
        {
            return (InstanceProperty)Enum.valueOf(oracle/jdbc/internal/OracleConnection$InstanceProperty, s);
        }

        static 
        {
            ASM_VOLUME_SUPPORTED = new InstanceProperty("ASM_VOLUME_SUPPORTED", 0);
            INSTANCE_TYPE = new InstanceProperty("INSTANCE_TYPE", 1);
            $VALUES = (new InstanceProperty[] {
                ASM_VOLUME_SUPPORTED, INSTANCE_TYPE
            });
        }

        private InstanceProperty(String s, int i)
        {
            super(s, i);
        }
    }


    public static final String CONNECTION_PROPERTY_LOGON_CAP = "oracle.jdbc.thinLogonCapability";
    public static final String CONNECTION_PROPERTY_LOGON_CAP_DEFAULT = "o5";
    public static final byte CONNECTION_PROPERTY_LOGON_CAP_ACCESSMODE = 3;
    public static final String CONNECTION_PROPERTY_NLS_LANG_BACKDOOR = "oracle.jdbc.ociNlsLangBackwardCompatible";
    public static final String CONNECTION_PROPERTY_NLS_LANG_BACKDOOR_DEFAULT = "false";
    public static final byte CONNECTION_PROPERTY_NLS_LANG_BACKDOOR_ACCESSMODE = 3;
    public static final String CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL = "oracle.jdbc.spawnNewThreadToCancel";
    public static final String CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL_DEFAULT = "false";
    public static final byte CONNECTION_PROPERTY_SPAWN_NEW_THREAD_TO_CANCEL_ACCESSMODE = 3;
    public static final String CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR = "oracle.jdbc.overrideEnableReadDataInLocator";
    public static final String CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR_DEFAULT = "false";
    public static final byte CONNECTION_PROPERTY_OVERRIDE_ENABLE_READ_DATA_IN_LOCATOR_ACCESSMODE = 3;
    public static final String CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH = "oracle.jdbc.internal.permitBindDateDefineTimestampMismatch";
    public static final String CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH_DEFAULT = "false";
    public static final byte CONNECTION_PROPERTY_PERMIT_TIMESTAMP_DATE_MISMATCH_ACCESSMODE = 3;
    public static final String CONNECTION_PROPERTY_QUICK_ASCII_CONVERSION = "oracle.jdbc.quickASCIIConversion";
    public static final String CONNECTION_PROPERTY_QUICK_ASCII_CONVERSION_DEFAULT = "false";
    public static final byte CONNECTION_PROPERTY_QUICK_ASCII_CONVERSION_ACCESSMODE = 3;
    public static final String CONNECTION_PROPERTY_ENABLE_JAVANET_FASTPATH = "oracle.jdbc.enableJavaNetFastPath";
    public static final String CONNECTION_PROPERTY_ENABLE_JAVANET_FASTPATH_DEFAULT = "false";
    public static final byte CONNECTION_PROPERTY_ENABLE_JAVANET_FASTPATH_ACCESSMODE = 3;
    public static final String CONNECTION_PROPERTY_PLSQL_VARCHAR_PARAMETER_4K_ONLY = "oracle.jdbc.plsqlVarcharParameter4KOnly";
    public static final String CONNECTION_PROPERTY_PLSQL_VARCHAR_PARAMETER_4K_ONLY_DEFAULT = "false";
    public static final byte CONNECTION_PROPERTY_PLSQL_VARCHAR_PARAMETER_4K_ONLY_ACCESSMODE = 3;
    public static final int CHAR_TO_ASCII = 0;
    public static final int CHAR_TO_UNICODE = 1;
    public static final int RAW_TO_ASCII = 2;
    public static final int RAW_TO_UNICODE = 3;
    public static final int UNICODE_TO_CHAR = 4;
    public static final int ASCII_TO_CHAR = 5;
    public static final int NONE = 6;
    public static final int JAVACHAR_TO_CHAR = 7;
    public static final int RAW_TO_JAVACHAR = 8;
    public static final int CHAR_TO_JAVACHAR = 9;
    public static final int GLOBAL_TXN = 1;
    public static final int NO_GLOBAL_TXN = 0;

    public abstract short getStructAttrNCsId()
        throws SQLException;

    public abstract Map getTypeMap()
        throws SQLException;

    public abstract Properties getDBAccessProperties()
        throws SQLException;

    public abstract Properties getOCIHandles()
        throws SQLException;

    public abstract String getDatabaseProductVersion()
        throws SQLException;

    public abstract String getURL()
        throws SQLException;

    public abstract short getVersionNumber()
        throws SQLException;

    public abstract Map getJavaObjectTypeMap();

    public abstract void setJavaObjectTypeMap(Map map);

    public abstract byte getInstanceProperty(InstanceProperty instanceproperty)
        throws SQLException;

    public abstract BfileDBAccess createBfileDBAccess()
        throws SQLException;

    public abstract BlobDBAccess createBlobDBAccess()
        throws SQLException;

    public abstract ClobDBAccess createClobDBAccess()
        throws SQLException;

    public abstract void setDefaultFixedString(boolean flag);

    public abstract boolean getDefaultFixedString();

    public abstract oracle.jdbc.OracleConnection getWrapper();

    public abstract Class classForNameAndSchema(String s, String s1)
        throws ClassNotFoundException;

    public abstract void setFDO(byte abyte0[])
        throws SQLException;

    public abstract byte[] getFDO(boolean flag)
        throws SQLException;

    public abstract boolean getBigEndian()
        throws SQLException;

    public abstract Object getDescriptor(byte abyte0[]);

    public abstract void putDescriptor(byte abyte0[], Object obj)
        throws SQLException;

    public abstract OracleConnection getPhysicalConnection();

    public abstract void removeDescriptor(String s);

    public abstract void removeAllDescriptor();

    public abstract int numberOfDescriptorCacheEntries();

    public abstract Enumeration descriptorCacheKeys();

    public abstract long getTdoCState(String s, String s1)
        throws SQLException;

    public abstract BufferCacheStatistics getByteBufferCacheStatistics();

    public abstract BufferCacheStatistics getCharBufferCacheStatistics();

    public abstract Datum toDatum(CustomDatum customdatum)
        throws SQLException;

    public abstract short getDbCsId()
        throws SQLException;

    public abstract short getJdbcCsId()
        throws SQLException;

    public abstract short getNCharSet();

    public abstract ResultSet newArrayDataResultSet(Datum adatum[], long l, int i, Map map)
        throws SQLException;

    public abstract ResultSet newArrayDataResultSet(ARRAY array, long l, int i, Map map)
        throws SQLException;

    public abstract ResultSet newArrayLocatorResultSet(ArrayDescriptor arraydescriptor, byte abyte0[], long l, int i, Map map)
        throws SQLException;

    public abstract ResultSetMetaData newStructMetaData(StructDescriptor structdescriptor)
        throws SQLException;

    public abstract void getForm(OracleTypeADT oracletypeadt, OracleTypeCLOB oracletypeclob, int i)
        throws SQLException;

    public abstract int CHARBytesToJavaChars(byte abyte0[], int i, char ac[])
        throws SQLException;

    public abstract int NCHARBytesToJavaChars(byte abyte0[], int i, char ac[])
        throws SQLException;

    public abstract boolean IsNCharFixedWith();

    public abstract short getDriverCharSet();

    public abstract int getC2SNlsRatio();

    public abstract int getMaxCharSize()
        throws SQLException;

    public abstract int getMaxCharbyteSize();

    public abstract int getMaxNCharbyteSize();

    public abstract boolean isCharSetMultibyte(short word0);

    public abstract int javaCharsToCHARBytes(char ac[], int i, byte abyte0[])
        throws SQLException;

    public abstract int javaCharsToNCHARBytes(char ac[], int i, byte abyte0[])
        throws SQLException;

    public abstract void setStartTime(long l)
        throws SQLException;

    public abstract long getStartTime()
        throws SQLException;

    public abstract boolean isStatementCacheInitialized();

    public abstract void getPropertyForPooledConnection(OraclePooledConnection oraclepooledconnection)
        throws SQLException;

    public abstract void setTypeMap(Map map)
        throws SQLException;

    public abstract String getProtocolType();

    public abstract Connection getLogicalConnection(OraclePooledConnection oraclepooledconnection, boolean flag)
        throws SQLException;

    public abstract void setTxnMode(int i);

    public abstract int getTxnMode();

    public abstract int getHeapAllocSize()
        throws SQLException;

    public abstract int getOCIEnvHeapAllocSize()
        throws SQLException;

    public abstract void setAbandonedTimeoutEnabled(boolean flag)
        throws SQLException;

    public abstract int getHeartbeatNoChangeCount()
        throws SQLException;

    public abstract void closeInternal(boolean flag)
        throws SQLException;

    public abstract void cleanupAndClose(boolean flag)
        throws SQLException;

    public abstract OracleConnectionCacheCallback getConnectionCacheCallbackObj()
        throws SQLException;

    public abstract Object getConnectionCacheCallbackPrivObj()
        throws SQLException;

    public abstract int getConnectionCacheCallbackFlag()
        throws SQLException;

    public abstract Properties getServerSessionInfo()
        throws SQLException;

    public abstract CLOB createClob(byte abyte0[])
        throws SQLException;

    public abstract CLOB createClobWithUnpickledBytes(byte abyte0[])
        throws SQLException;

    public abstract CLOB createClob(byte abyte0[], short word0)
        throws SQLException;

    public abstract BLOB createBlob(byte abyte0[])
        throws SQLException;

    public abstract BLOB createBlobWithUnpickledBytes(byte abyte0[])
        throws SQLException;

    public abstract BFILE createBfile(byte abyte0[])
        throws SQLException;

    public abstract boolean isDescriptorSharable(OracleConnection oracleconnection)
        throws SQLException;

    public abstract OracleStatement refCursorCursorToStatement(int i)
        throws SQLException;

    public abstract XAResource getXAResource()
        throws SQLException;

    /**
     * @deprecated Method isV8Compatible is deprecated
     */

    public abstract boolean isV8Compatible()
        throws SQLException;

    public abstract boolean getMapDateToTimestamp();

    public abstract byte[] createLightweightSession(String s, KeywordValueLong akeywordvaluelong[], int i, KeywordValueLong akeywordvaluelong1[][], int ai[])
        throws SQLException;

    public abstract void executeLightweightSessionRoundtrip(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j, KeywordValueLong akeywordvaluelong1[][], int ai[])
        throws SQLException;

    public abstract void executeLightweightSessionPiggyback(int i, byte abyte0[], KeywordValueLong akeywordvaluelong[], int j)
        throws SQLException;

    public abstract void doXSNamespaceOp(XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[], XSNamespace axsnamespace1[][])
        throws SQLException;

    public abstract void doXSNamespaceOp(XSOperationCode xsoperationcode, byte abyte0[], XSNamespace axsnamespace[])
        throws SQLException;

    public abstract String getDefaultSchemaNameForNamedTypes()
        throws SQLException;

    public abstract void setUsable(boolean flag);

    public abstract Class getClassForType(String s, Map map);

    public abstract void addXSEventListener(XSEventListener xseventlistener)
        throws SQLException;

    public abstract void addXSEventListener(XSEventListener xseventlistener, Executor executor)
        throws SQLException;

    public abstract void removeXSEventListener(XSEventListener xseventlistener)
        throws SQLException;

    public abstract int getTimezoneVersionNumber()
        throws SQLException;

    public abstract TIMEZONETAB getTIMEZONETAB()
        throws SQLException;

    public abstract String getDatabaseTimeZone()
        throws SQLException;

    public abstract boolean getTimestamptzInGmt();

    public abstract boolean getUse1900AsYearForTime();

    public abstract boolean isDataInLocatorEnabled()
        throws SQLException;

    public abstract boolean isLobStreamPosStandardCompliant()
        throws SQLException;

    public abstract long getCurrentSCN()
        throws SQLException;

    public abstract EnumSet getTransactionState()
        throws SQLException;

    public abstract boolean isConnectionSocketKeepAlive()
        throws SocketException, SQLException;
}
