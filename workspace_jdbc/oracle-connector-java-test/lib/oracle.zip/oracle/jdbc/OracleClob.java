// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleClob.java

package oracle.jdbc;

import java.sql.Clob;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc:
//            LargeObjectAccessMode

public interface OracleClob
    extends Clob
{

    public abstract void open(LargeObjectAccessMode largeobjectaccessmode)
        throws SQLException;

    public abstract void close()
        throws SQLException;

    public abstract boolean isOpen()
        throws SQLException;

    public abstract boolean isTemporary()
        throws SQLException;

    public abstract boolean isEmptyLob()
        throws SQLException;

    public abstract boolean isSecureFile()
        throws SQLException;
}
