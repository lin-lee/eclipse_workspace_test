// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConnectionWrapper.java

package oracle.jdbc;

import java.lang.reflect.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.*;
import java.util.*;
import oracle.jdbc.aq.AQDequeueOptions;
import oracle.jdbc.aq.AQEnqueueOptions;
import oracle.jdbc.aq.AQMessage;
import oracle.jdbc.aq.AQNotificationRegistration;
import oracle.jdbc.dcn.DatabaseChangeRegistration;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.pool.OracleConnectionCacheCallback;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc:
//            OracleConnection, OracleSavepoint, OracleOCIFailover

public class OracleConnectionWrapper
    implements oracle.jdbc.OracleConnection
{
    protected class CloseInvocationHandler
        implements InvocationHandler
    {

        private OracleConnectionWrapper wrapper;
        final OracleConnectionWrapper this$0;

        public Object invoke(Object obj, Method method, Object aobj[])
            throws Throwable
        {
            try
            {
                return method.invoke(wrapper, aobj);
            }
            catch(IllegalArgumentException illegalargumentexception)
            {
                return method.invoke(wrapper.connection, aobj);
            }
        }

        protected CloseInvocationHandler(OracleConnectionWrapper oracleconnectionwrapper1)
        {
            this$0 = OracleConnectionWrapper.this;
            super();
            wrapper = oracleconnectionwrapper1;
        }
    }


    protected oracle.jdbc.OracleConnection connection;
    private Map proxies;
    private static Map proxyClasses = new HashMap();
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleConnectionWrapper()
    {
        proxies = new HashMap(3);
    }

    public OracleConnectionWrapper(oracle.jdbc.OracleConnection oracleconnection)
    {
        proxies = new HashMap(3);
        connection = oracleconnection;
        oracleconnection.setWrapper(this);
    }

    public oracle.jdbc.OracleConnection unwrap()
    {
        return connection;
    }

    public OracleConnection physicalConnectionWithin()
    {
        return connection.physicalConnectionWithin();
    }

    public String getDatabaseTimeZone()
        throws SQLException
    {
        return physicalConnectionWithin().getDatabaseTimeZone();
    }

    public void setWrapper(oracle.jdbc.OracleConnection oracleconnection)
    {
        connection.setWrapper(oracleconnection);
    }

    public Statement createStatement()
        throws SQLException
    {
        return connection.createStatement();
    }

    public PreparedStatement prepareStatement(String s)
        throws SQLException
    {
        return connection.prepareStatement(s);
    }

    public CallableStatement prepareCall(String s)
        throws SQLException
    {
        return connection.prepareCall(s);
    }

    public String nativeSQL(String s)
        throws SQLException
    {
        return connection.nativeSQL(s);
    }

    public void setAutoCommit(boolean flag)
        throws SQLException
    {
        connection.setAutoCommit(flag);
    }

    public boolean getAutoCommit()
        throws SQLException
    {
        return connection.getAutoCommit();
    }

    public void commit()
        throws SQLException
    {
        connection.commit();
    }

    public void rollback()
        throws SQLException
    {
        connection.rollback();
    }

    public void close()
        throws SQLException
    {
        connection.close();
    }

    public boolean isClosed()
        throws SQLException
    {
        return connection.isClosed();
    }

    public DatabaseMetaData getMetaData()
        throws SQLException
    {
        return connection.getMetaData();
    }

    public void setReadOnly(boolean flag)
        throws SQLException
    {
        connection.setReadOnly(flag);
    }

    public boolean isReadOnly()
        throws SQLException
    {
        return connection.isReadOnly();
    }

    public void setCatalog(String s)
        throws SQLException
    {
        connection.setCatalog(s);
    }

    public String getCatalog()
        throws SQLException
    {
        return connection.getCatalog();
    }

    public void setTransactionIsolation(int i)
        throws SQLException
    {
        connection.setTransactionIsolation(i);
    }

    public int getTransactionIsolation()
        throws SQLException
    {
        return connection.getTransactionIsolation();
    }

    public SQLWarning getWarnings()
        throws SQLException
    {
        return connection.getWarnings();
    }

    public void clearWarnings()
        throws SQLException
    {
        connection.clearWarnings();
    }

    public Statement createStatement(int i, int j)
        throws SQLException
    {
        return connection.createStatement(i, j);
    }

    public PreparedStatement prepareStatement(String s, int i, int j)
        throws SQLException
    {
        return connection.prepareStatement(s, i, j);
    }

    public CallableStatement prepareCall(String s, int i, int j)
        throws SQLException
    {
        return connection.prepareCall(s, i, j);
    }

    public Map getTypeMap()
        throws SQLException
    {
        return connection.getTypeMap();
    }

    public void setTypeMap(Map map)
        throws SQLException
    {
        connection.setTypeMap(map);
    }

    public boolean isProxySession()
    {
        return connection.isProxySession();
    }

    public void openProxySession(int i, Properties properties)
        throws SQLException
    {
        connection.openProxySession(i, properties);
    }

    public void archive(int i, int j, String s)
        throws SQLException
    {
        connection.archive(i, j, s);
    }

    public boolean getAutoClose()
        throws SQLException
    {
        return connection.getAutoClose();
    }

    public CallableStatement getCallWithKey(String s)
        throws SQLException
    {
        return connection.getCallWithKey(s);
    }

    public int getDefaultExecuteBatch()
    {
        return connection.getDefaultExecuteBatch();
    }

    public int getDefaultRowPrefetch()
    {
        return connection.getDefaultRowPrefetch();
    }

    public Object getDescriptor(String s)
    {
        return connection.getDescriptor(s);
    }

    public String[] getEndToEndMetrics()
        throws SQLException
    {
        return connection.getEndToEndMetrics();
    }

    public short getEndToEndECIDSequenceNumber()
        throws SQLException
    {
        return connection.getEndToEndECIDSequenceNumber();
    }

    public boolean getIncludeSynonyms()
    {
        return connection.getIncludeSynonyms();
    }

    public boolean getRestrictGetTables()
    {
        return connection.getRestrictGetTables();
    }

    public boolean getImplicitCachingEnabled()
        throws SQLException
    {
        return connection.getImplicitCachingEnabled();
    }

    public boolean getExplicitCachingEnabled()
        throws SQLException
    {
        return connection.getExplicitCachingEnabled();
    }

    public Object getJavaObject(String s)
        throws SQLException
    {
        return connection.getJavaObject(s);
    }

    public boolean getRemarksReporting()
    {
        return connection.getRemarksReporting();
    }

    public String getSQLType(Object obj)
        throws SQLException
    {
        return connection.getSQLType(obj);
    }

    public int getStmtCacheSize()
    {
        return connection.getStmtCacheSize();
    }

    public int getStatementCacheSize()
        throws SQLException
    {
        return connection.getStatementCacheSize();
    }

    public PreparedStatement getStatementWithKey(String s)
        throws SQLException
    {
        return connection.getStatementWithKey(s);
    }

    public short getStructAttrCsId()
        throws SQLException
    {
        return connection.getStructAttrCsId();
    }

    public String getUserName()
        throws SQLException
    {
        return connection.getUserName();
    }

    public String getCurrentSchema()
        throws SQLException
    {
        return connection.getCurrentSchema();
    }

    public boolean getUsingXAFlag()
    {
        return connection.getUsingXAFlag();
    }

    public boolean getXAErrorFlag()
    {
        return connection.getXAErrorFlag();
    }

    public OracleSavepoint oracleSetSavepoint()
        throws SQLException
    {
        return connection.oracleSetSavepoint();
    }

    public OracleSavepoint oracleSetSavepoint(String s)
        throws SQLException
    {
        return connection.oracleSetSavepoint(s);
    }

    public void oracleRollback(OracleSavepoint oraclesavepoint)
        throws SQLException
    {
        connection.oracleRollback(oraclesavepoint);
    }

    public void oracleReleaseSavepoint(OracleSavepoint oraclesavepoint)
        throws SQLException
    {
        connection.oracleReleaseSavepoint(oraclesavepoint);
    }

    public int pingDatabase()
        throws SQLException
    {
        return connection.pingDatabase();
    }

    public int pingDatabase(int i)
        throws SQLException
    {
        return connection.pingDatabase(i);
    }

    public void purgeExplicitCache()
        throws SQLException
    {
        connection.purgeExplicitCache();
    }

    public void purgeImplicitCache()
        throws SQLException
    {
        connection.purgeImplicitCache();
    }

    public void putDescriptor(String s, Object obj)
        throws SQLException
    {
        connection.putDescriptor(s, obj);
    }

    public void registerSQLType(String s, Class class1)
        throws SQLException
    {
        connection.registerSQLType(s, class1);
    }

    public void registerSQLType(String s, String s1)
        throws SQLException
    {
        connection.registerSQLType(s, s1);
    }

    public void setAutoClose(boolean flag)
        throws SQLException
    {
        connection.setAutoClose(flag);
    }

    public void setDefaultExecuteBatch(int i)
        throws SQLException
    {
        connection.setDefaultExecuteBatch(i);
    }

    public void setDefaultRowPrefetch(int i)
        throws SQLException
    {
        connection.setDefaultRowPrefetch(i);
    }

    public void setEndToEndMetrics(String as[], short word0)
        throws SQLException
    {
        connection.setEndToEndMetrics(as, word0);
    }

    public void setExplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        connection.setExplicitCachingEnabled(flag);
    }

    public void setImplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        connection.setImplicitCachingEnabled(flag);
    }

    public void setIncludeSynonyms(boolean flag)
    {
        connection.setIncludeSynonyms(flag);
    }

    public void setRemarksReporting(boolean flag)
    {
        connection.setRemarksReporting(flag);
    }

    public void setRestrictGetTables(boolean flag)
    {
        connection.setRestrictGetTables(flag);
    }

    public void setStmtCacheSize(int i)
        throws SQLException
    {
        connection.setStmtCacheSize(i);
    }

    public void setStatementCacheSize(int i)
        throws SQLException
    {
        connection.setStatementCacheSize(i);
    }

    public void setStmtCacheSize(int i, boolean flag)
        throws SQLException
    {
        connection.setStmtCacheSize(i, flag);
    }

    public void setUsingXAFlag(boolean flag)
    {
        connection.setUsingXAFlag(flag);
    }

    public void setXAErrorFlag(boolean flag)
    {
        connection.setXAErrorFlag(flag);
    }

    public void shutdown(OracleConnection.DatabaseShutdownMode databaseshutdownmode)
        throws SQLException
    {
        connection.shutdown(databaseshutdownmode);
    }

    public void startup(String s, int i)
        throws SQLException
    {
        connection.startup(s, i);
    }

    public void startup(OracleConnection.DatabaseStartupMode databasestartupmode)
        throws SQLException
    {
        connection.startup(databasestartupmode);
    }

    public PreparedStatement prepareStatementWithKey(String s)
        throws SQLException
    {
        return connection.prepareStatementWithKey(s);
    }

    public CallableStatement prepareCallWithKey(String s)
        throws SQLException
    {
        return connection.prepareCallWithKey(s);
    }

    public void setCreateStatementAsRefCursor(boolean flag)
    {
        connection.setCreateStatementAsRefCursor(flag);
    }

    public boolean getCreateStatementAsRefCursor()
    {
        return connection.getCreateStatementAsRefCursor();
    }

    public void setSessionTimeZone(String s)
        throws SQLException
    {
        connection.setSessionTimeZone(s);
    }

    public String getSessionTimeZone()
    {
        return connection.getSessionTimeZone();
    }

    public String getSessionTimeZoneOffset()
        throws SQLException
    {
        return connection.getSessionTimeZoneOffset();
    }

    public Connection _getPC()
    {
        return connection._getPC();
    }

    public boolean isLogicalConnection()
    {
        return connection.isLogicalConnection();
    }

    public void registerTAFCallback(OracleOCIFailover oracleocifailover, Object obj)
        throws SQLException
    {
        connection.registerTAFCallback(oracleocifailover, obj);
    }

    public Properties getProperties()
    {
        return connection.getProperties();
    }

    public void close(Properties properties)
        throws SQLException
    {
        connection.close(properties);
    }

    public void close(int i)
        throws SQLException
    {
        connection.close(i);
    }

    public void applyConnectionAttributes(Properties properties)
        throws SQLException
    {
        connection.applyConnectionAttributes(properties);
    }

    public Properties getConnectionAttributes()
        throws SQLException
    {
        return connection.getConnectionAttributes();
    }

    public Properties getUnMatchedConnectionAttributes()
        throws SQLException
    {
        return connection.getUnMatchedConnectionAttributes();
    }

    public void registerConnectionCacheCallback(OracleConnectionCacheCallback oracleconnectioncachecallback, Object obj, int i)
        throws SQLException
    {
        connection.registerConnectionCacheCallback(oracleconnectioncachecallback, obj, i);
    }

    public void setConnectionReleasePriority(int i)
        throws SQLException
    {
        connection.setConnectionReleasePriority(i);
    }

    public int getConnectionReleasePriority()
        throws SQLException
    {
        return connection.getConnectionReleasePriority();
    }

    public void setPlsqlWarnings(String s)
        throws SQLException
    {
        connection.setPlsqlWarnings(s);
    }

    public void setHoldability(int i)
        throws SQLException
    {
        connection.setHoldability(i);
    }

    public int getHoldability()
        throws SQLException
    {
        return connection.getHoldability();
    }

    public Statement createStatement(int i, int j, int k)
        throws SQLException
    {
        return connection.createStatement(i, j, k);
    }

    public PreparedStatement prepareStatement(String s, int i, int j, int k)
        throws SQLException
    {
        return connection.prepareStatement(s, i, j, k);
    }

    public CallableStatement prepareCall(String s, int i, int j, int k)
        throws SQLException
    {
        return connection.prepareCall(s, i, j, k);
    }

    public synchronized Savepoint setSavepoint()
        throws SQLException
    {
        return connection.setSavepoint();
    }

    public synchronized Savepoint setSavepoint(String s)
        throws SQLException
    {
        return connection.setSavepoint(s);
    }

    public synchronized void rollback(Savepoint savepoint)
        throws SQLException
    {
        connection.rollback(savepoint);
    }

    public synchronized void releaseSavepoint(Savepoint savepoint)
        throws SQLException
    {
        connection.releaseSavepoint(savepoint);
    }

    public PreparedStatement prepareStatement(String s, int i)
        throws SQLException
    {
        return connection.prepareStatement(s, i);
    }

    public PreparedStatement prepareStatement(String s, int ai[])
        throws SQLException
    {
        return connection.prepareStatement(s, ai);
    }

    public PreparedStatement prepareStatement(String s, String as[])
        throws SQLException
    {
        return connection.prepareStatement(s, as);
    }

    public ARRAY createARRAY(String s, Object obj)
        throws SQLException
    {
        return connection.createARRAY(s, obj);
    }

    public Array createOracleArray(String s, Object obj)
        throws SQLException
    {
        return connection.createOracleArray(s, obj);
    }

    public BINARY_DOUBLE createBINARY_DOUBLE(double d)
        throws SQLException
    {
        return connection.createBINARY_DOUBLE(d);
    }

    public BINARY_FLOAT createBINARY_FLOAT(float f)
        throws SQLException
    {
        return connection.createBINARY_FLOAT(f);
    }

    public DATE createDATE(Date date)
        throws SQLException
    {
        return connection.createDATE(date);
    }

    public DATE createDATE(Time time)
        throws SQLException
    {
        return connection.createDATE(time);
    }

    public DATE createDATE(Timestamp timestamp)
        throws SQLException
    {
        return connection.createDATE(timestamp);
    }

    public DATE createDATE(Date date, Calendar calendar)
        throws SQLException
    {
        return connection.createDATE(date, calendar);
    }

    public DATE createDATE(Time time, Calendar calendar)
        throws SQLException
    {
        return connection.createDATE(time, calendar);
    }

    public DATE createDATE(Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        return connection.createDATE(timestamp, calendar);
    }

    public DATE createDATE(String s)
        throws SQLException
    {
        return connection.createDATE(s);
    }

    public INTERVALDS createINTERVALDS(String s)
        throws SQLException
    {
        return connection.createINTERVALDS(s);
    }

    public INTERVALYM createINTERVALYM(String s)
        throws SQLException
    {
        return connection.createINTERVALYM(s);
    }

    public NUMBER createNUMBER(boolean flag)
        throws SQLException
    {
        return connection.createNUMBER(flag);
    }

    public NUMBER createNUMBER(byte byte0)
        throws SQLException
    {
        return connection.createNUMBER(byte0);
    }

    public NUMBER createNUMBER(short word0)
        throws SQLException
    {
        return connection.createNUMBER(word0);
    }

    public NUMBER createNUMBER(int i)
        throws SQLException
    {
        return connection.createNUMBER(i);
    }

    public NUMBER createNUMBER(long l)
        throws SQLException
    {
        return connection.createNUMBER(l);
    }

    public NUMBER createNUMBER(float f)
        throws SQLException
    {
        return connection.createNUMBER(f);
    }

    public NUMBER createNUMBER(double d)
        throws SQLException
    {
        return connection.createNUMBER(d);
    }

    public NUMBER createNUMBER(BigDecimal bigdecimal)
        throws SQLException
    {
        return connection.createNUMBER(bigdecimal);
    }

    public NUMBER createNUMBER(BigInteger biginteger)
        throws SQLException
    {
        return connection.createNUMBER(biginteger);
    }

    public NUMBER createNUMBER(String s, int i)
        throws SQLException
    {
        return connection.createNUMBER(s, i);
    }

    public TIMESTAMP createTIMESTAMP(Date date)
        throws SQLException
    {
        return connection.createTIMESTAMP(date);
    }

    public TIMESTAMP createTIMESTAMP(DATE date)
        throws SQLException
    {
        return connection.createTIMESTAMP(date);
    }

    public TIMESTAMP createTIMESTAMP(Time time)
        throws SQLException
    {
        return connection.createTIMESTAMP(time);
    }

    public TIMESTAMP createTIMESTAMP(Timestamp timestamp)
        throws SQLException
    {
        return connection.createTIMESTAMP(timestamp);
    }

    public TIMESTAMP createTIMESTAMP(String s)
        throws SQLException
    {
        return connection.createTIMESTAMP(s);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Date date)
        throws SQLException
    {
        return connection.createTIMESTAMPTZ(date);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Date date, Calendar calendar)
        throws SQLException
    {
        return connection.createTIMESTAMPTZ(date, calendar);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Time time)
        throws SQLException
    {
        return connection.createTIMESTAMPTZ(time);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Time time, Calendar calendar)
        throws SQLException
    {
        return connection.createTIMESTAMPTZ(time, calendar);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp timestamp)
        throws SQLException
    {
        return connection.createTIMESTAMPTZ(timestamp);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        return connection.createTIMESTAMPTZ(timestamp, calendar);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(String s)
        throws SQLException
    {
        return connection.createTIMESTAMPTZ(s);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(String s, Calendar calendar)
        throws SQLException
    {
        return connection.createTIMESTAMPTZ(s, calendar);
    }

    public TIMESTAMPTZ createTIMESTAMPTZ(DATE date)
        throws SQLException
    {
        return connection.createTIMESTAMPTZ(date);
    }

    public TIMESTAMPLTZ createTIMESTAMPLTZ(Date date, Calendar calendar)
        throws SQLException
    {
        return connection.createTIMESTAMPLTZ(date, calendar);
    }

    public TIMESTAMPLTZ createTIMESTAMPLTZ(Time time, Calendar calendar)
        throws SQLException
    {
        return connection.createTIMESTAMPLTZ(time, calendar);
    }

    public TIMESTAMPLTZ createTIMESTAMPLTZ(Timestamp timestamp, Calendar calendar)
        throws SQLException
    {
        return connection.createTIMESTAMPLTZ(timestamp, calendar);
    }

    public TIMESTAMPLTZ createTIMESTAMPLTZ(String s, Calendar calendar)
        throws SQLException
    {
        return connection.createTIMESTAMPLTZ(s, calendar);
    }

    public TIMESTAMPLTZ createTIMESTAMPLTZ(DATE date, Calendar calendar)
        throws SQLException
    {
        return connection.createTIMESTAMPLTZ(date, calendar);
    }

    public Array createArrayOf(String s, Object aobj[])
        throws SQLException
    {
        return connection.createArrayOf(s, aobj);
    }

    public Blob createBlob()
        throws SQLException
    {
        return connection.createBlob();
    }

    public Clob createClob()
        throws SQLException
    {
        return connection.createClob();
    }

    public NClob createNClob()
        throws SQLException
    {
        return connection.createNClob();
    }

    public SQLXML createSQLXML()
        throws SQLException
    {
        return connection.createSQLXML();
    }

    public Struct createStruct(String s, Object aobj[])
        throws SQLException
    {
        return connection.createStruct(s, aobj);
    }

    public boolean isValid(int i)
        throws SQLException
    {
        return connection.isValid(i);
    }

    public void setClientInfo(String s, String s1)
        throws SQLClientInfoException
    {
        connection.setClientInfo(s, s1);
    }

    public void setClientInfo(Properties properties)
        throws SQLClientInfoException
    {
        connection.setClientInfo(properties);
    }

    public String getClientInfo(String s)
        throws SQLException
    {
        return connection.getClientInfo(s);
    }

    public Properties getClientInfo()
        throws SQLException
    {
        return connection.getClientInfo();
    }

    public boolean isWrapperFor(Class class1)
        throws SQLException
    {
        if(class1.isInterface())
        {
            return class1.isInstance(this) || connection.isWrapperFor(class1);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    protected Object proxyFor(Object obj, Class class1)
        throws SQLException
    {
        SQLException sqlexception;
        try
        {
            Object obj1 = proxies.get(class1);
            if(obj1 == null)
            {
                Class class2 = (Class)proxyClasses.get(class1);
                if(class2 == null)
                {
                    class2 = Proxy.getProxyClass(class1.getClassLoader(), new Class[] {
                        class1
                    });
                    proxyClasses.put(class1, class2);
                }
                obj1 = class2.getConstructor(new Class[] {
                    java/lang/reflect/InvocationHandler
                }).newInstance(new Object[] {
                    new CloseInvocationHandler(this)
                });
                proxies.put(class1, obj1);
            }
            return obj1;
        }
        catch(Exception exception)
        {
            sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Cannot construct proxy");
        }
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    public Object unwrap(Class class1)
        throws SQLException
    {
        if(class1.isInterface())
        {
            if(class1.isInstance(this))
                return this;
            else
                return proxyFor(connection.unwrap(class1), class1);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public DatabaseChangeRegistration registerDatabaseChangeNotification(Properties properties)
        throws SQLException
    {
        return connection.registerDatabaseChangeNotification(properties);
    }

    public DatabaseChangeRegistration getDatabaseChangeRegistration(int i)
        throws SQLException
    {
        return connection.getDatabaseChangeRegistration(i);
    }

    public void unregisterDatabaseChangeNotification(DatabaseChangeRegistration databasechangeregistration)
        throws SQLException
    {
        connection.unregisterDatabaseChangeNotification(databasechangeregistration);
    }

    public void unregisterDatabaseChangeNotification(int i, String s, int j)
        throws SQLException
    {
        connection.unregisterDatabaseChangeNotification(i, s, j);
    }

    public void unregisterDatabaseChangeNotification(int i)
        throws SQLException
    {
        connection.unregisterDatabaseChangeNotification(i);
    }

    public void unregisterDatabaseChangeNotification(long l, String s)
        throws SQLException
    {
        connection.unregisterDatabaseChangeNotification(l, s);
    }

    public AQNotificationRegistration[] registerAQNotification(String as[], Properties aproperties[], Properties properties)
        throws SQLException
    {
        return connection.registerAQNotification(as, aproperties, properties);
    }

    public void unregisterAQNotification(AQNotificationRegistration aqnotificationregistration)
        throws SQLException
    {
        connection.unregisterAQNotification(aqnotificationregistration);
    }

    public AQMessage dequeue(String s, AQDequeueOptions aqdequeueoptions, byte abyte0[])
        throws SQLException
    {
        return connection.dequeue(s, aqdequeueoptions, abyte0);
    }

    public AQMessage dequeue(String s, AQDequeueOptions aqdequeueoptions, String s1)
        throws SQLException
    {
        return connection.dequeue(s, aqdequeueoptions, s1);
    }

    public void enqueue(String s, AQEnqueueOptions aqenqueueoptions, AQMessage aqmessage)
        throws SQLException
    {
        connection.enqueue(s, aqenqueueoptions, aqmessage);
    }

    public void commit(EnumSet enumset)
        throws SQLException
    {
        connection.commit(enumset);
    }

    public void cancel()
        throws SQLException
    {
        connection.cancel();
    }

    public void abort()
        throws SQLException
    {
        connection.abort();
    }

    public TypeDescriptor[] getAllTypeDescriptorsInCurrentSchema()
        throws SQLException
    {
        return connection.getAllTypeDescriptorsInCurrentSchema();
    }

    public TypeDescriptor[] getTypeDescriptorsFromListInCurrentSchema(String as[])
        throws SQLException
    {
        return connection.getTypeDescriptorsFromListInCurrentSchema(as);
    }

    public TypeDescriptor[] getTypeDescriptorsFromList(String as[][])
        throws SQLException
    {
        return connection.getTypeDescriptorsFromList(as);
    }

    public String getDataIntegrityAlgorithmName()
        throws SQLException
    {
        return connection.getDataIntegrityAlgorithmName();
    }

    public String getEncryptionAlgorithmName()
        throws SQLException
    {
        return connection.getEncryptionAlgorithmName();
    }

    public String getAuthenticationAdaptorName()
        throws SQLException
    {
        return connection.getAuthenticationAdaptorName();
    }

    public boolean isUsable()
    {
        return connection.isUsable();
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

    public void setDefaultTimeZone(TimeZone timezone)
        throws SQLException
    {
        connection.setDefaultTimeZone(timezone);
    }

    public TimeZone getDefaultTimeZone()
        throws SQLException
    {
        return connection.getDefaultTimeZone();
    }

    public void setApplicationContext(String s, String s1, String s2)
        throws SQLException
    {
        connection.setApplicationContext(s, s1, s2);
    }

    public void clearAllApplicationContext(String s)
        throws SQLException
    {
        connection.clearAllApplicationContext(s);
    }

}
