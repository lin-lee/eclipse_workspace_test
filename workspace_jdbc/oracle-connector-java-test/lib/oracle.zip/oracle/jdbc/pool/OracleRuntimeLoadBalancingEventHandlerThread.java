// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleRuntimeLoadBalancingEventHandlerThread.java

package oracle.jdbc.pool;

import java.security.*;
import java.sql.SQLException;
import oracle.ons.*;

// Referenced classes of package oracle.jdbc.pool:
//            OracleConnectionCacheManager

/**
 * @deprecated Class OracleRuntimeLoadBalancingEventHandlerThread is deprecated
 */

class OracleRuntimeLoadBalancingEventHandlerThread extends Thread
{

    private Notification event;
    private OracleConnectionCacheManager cacheManager;
    String m_service;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleRuntimeLoadBalancingEventHandlerThread(String s)
        throws SQLException
    {
        event = null;
        cacheManager = null;
        m_service = s;
        cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
    }

    public void run()
    {
        Subscriber subscriber = null;
        final String type = (new StringBuilder()).append("%\"eventType=database/event/servicemetrics/").append(m_service).append("\"").toString();
        while(cacheManager.failoverEnabledCacheExists()) 
        {
            try
            {
                subscriber = (Subscriber)AccessController.doPrivileged(new PrivilegedExceptionAction() {

                    final String val$type;
                    final OracleRuntimeLoadBalancingEventHandlerThread this$0;

                    public Object run()
                    {
                        try
                        {
                            return new Subscriber(type, "", 30000L);
                        }
                        catch(SubscriptionException subscriptionexception)
                        {
                            return null;
                        }
                    }

            
            {
                this$0 = OracleRuntimeLoadBalancingEventHandlerThread.this;
                type = s;
                super();
            }
                }
);
            }
            catch(PrivilegedActionException privilegedactionexception) { }
            if(subscriber != null)
                try
                {
                    do
                    {
                        if(!cacheManager.failoverEnabledCacheExists())
                            break;
                        if((event = subscriber.receive(0x493e0L)) != null)
                            handleEvent(event);
                    } while(true);
                }
                catch(ONSException onsexception)
                {
                    subscriber.close();
                }
            try
            {
                Thread.currentThread();
                Thread.sleep(10000L);
            }
            catch(InterruptedException interruptedexception) { }
        }
    }

    void handleEvent(Notification notification)
    {
        try
        {
            cacheManager.parseRuntimeLoadBalancingEvent(m_service, notification != null ? notification.body() : null);
        }
        catch(SQLException sqlexception) { }
    }

}
