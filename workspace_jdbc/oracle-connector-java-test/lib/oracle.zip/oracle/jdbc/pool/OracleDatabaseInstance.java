// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDatabaseInstance.java

package oracle.jdbc.pool;


/**
 * @deprecated Class OracleDatabaseInstance is deprecated
 */

class OracleDatabaseInstance
{

    String databaseUniqName;
    String instanceName;
    int percent;
    int flag;
    int attemptedConnRequestCount;
    int numberOfConnectionsCount;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleDatabaseInstance(String s, String s1)
    {
        databaseUniqName = null;
        instanceName = null;
        percent = 0;
        flag = 0;
        attemptedConnRequestCount = 0;
        numberOfConnectionsCount = 0;
        databaseUniqName = s;
        instanceName = s1;
    }

}
