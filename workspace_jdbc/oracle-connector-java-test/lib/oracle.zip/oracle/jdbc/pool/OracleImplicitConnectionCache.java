// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleImplicitConnectionCache.java

package oracle.jdbc.pool;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;
import javax.sql.PooledConnection;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.xa.client.OracleXADataSource;

// Referenced classes of package oracle.jdbc.pool:
//            OracleConnectionPoolDataSource, OracleConnectionCacheEntry, OraclePooledConnection, OracleDatabaseInstance, 
//            OracleConnectionCacheEventListener, OracleRuntimeLoadBalancingEventHandlerThread, OracleImplicitConnectionCacheThread, OracleGravitateConnectionCacheThread, 
//            OracleConnectionCacheCallback, OracleConnectionCacheManager, OracleDataSource, OracleFailoverWorkerThread

/**
 * @deprecated Class OracleImplicitConnectionCache is deprecated
 */

class OracleImplicitConnectionCache
{

    protected OracleDataSource cacheEnabledDS;
    protected String cacheName;
    protected OracleConnectionPoolDataSource connectionPoolDS;
    protected boolean fastConnectionFailoverEnabled;
    protected String defaultUser;
    protected String defaultPassword;
    protected static final int DEFAULT_MIN_LIMIT = 0;
    protected static final int DEFAULT_MAX_LIMIT = 0x7fffffff;
    protected static final int DEFAULT_INITIAL_LIMIT = 0;
    protected static final int DEFAULT_MAX_STATEMENTS_LIMIT = 0;
    protected static final int DEFAULT_INACTIVITY_TIMEOUT = 0;
    protected static final int DEFAULT_TIMETOLIVE_TIMEOUT = 0;
    protected static final int DEFAULT_ABANDONED_CONN_TIMEOUT = 0;
    protected static final int DEFAULT_CONNECTION_WAIT_TIMEOUT = 0;
    protected static final String DEFAULT_ATTRIBUTE_WEIGHT = "0";
    protected static final int DEFAULT_LOWER_THRESHOLD_LIMIT = 20;
    protected static final int DEFAULT_PROPERTY_CHECK_INTERVAL = 900;
    protected static final int CLOSE_AND_REMOVE_ALL_CONNECTIONS = 1;
    protected static final int CLOSE_AND_REMOVE_FAILOVER_CONNECTIONS = 2;
    protected static final int PROCESS_INACTIVITY_TIMEOUT = 4;
    protected static final int CLOSE_AND_REMOVE_N_CONNECTIONS = 8;
    protected static final int DISABLE_STATEMENT_CACHING = 16;
    protected static final int RESET_STATEMENT_CACHE_SIZE = 18;
    protected static final int CLOSE_AND_REMOVE_RLB_CONNECTIONS = 24;
    protected static final int ABORT_AND_CLOSE_ALL_CONNECTIONS = 32;
    public static final int REFRESH_INVALID_CONNECTIONS = 4096;
    public static final int REFRESH_ALL_CONNECTIONS = 8192;
    private static final String ATTRKEY_DELIM = "0xffff";
    protected int cacheMinLimit;
    protected int cacheMaxLimit;
    protected int cacheInitialLimit;
    protected int cacheMaxStatementsLimit;
    protected Properties cacheAttributeWeights;
    protected int cacheInactivityTimeout;
    protected int cacheTimeToLiveTimeout;
    protected int cacheAbandonedConnectionTimeout;
    protected int cacheLowerThresholdLimit;
    protected int cachePropertyCheckInterval;
    protected boolean cacheClosestConnectionMatch;
    protected boolean cacheValidateConnection;
    protected boolean cacheUseLIFO;
    protected int cacheConnectionWaitTimeout;
    static final String MIN_LIMIT_KEY = "MinLimit";
    static final String MAX_LIMIT_KEY = "MaxLimit";
    static final String INITIAL_LIMIT_KEY = "InitialLimit";
    static final String MAX_STATEMENTS_LIMIT_KEY = "MaxStatementsLimit";
    static final String ATTRIBUTE_WEIGHTS_KEY = "AttributeWeights";
    static final String INACTIVITY_TIMEOUT_KEY = "InactivityTimeout";
    static final String TIME_TO_LIVE_TIMEOUT_KEY = "TimeToLiveTimeout";
    static final String ABANDONED_CONNECTION_TIMEOUT_KEY = "AbandonedConnectionTimeout";
    static final String LOWER_THRESHOLD_LIMIT_KEY = "LowerThresholdLimit";
    static final String PROPERTY_CHECK_INTERVAL_KEY = "PropertyCheckInterval";
    static final String VALIDATE_CONNECTION_KEY = "ValidateConnection";
    static final String CLOSEST_CONNECTION_MATCH_KEY = "ClosestConnectionMatch";
    static final String CONNECTION_WAIT_TIMEOUT_KEY = "ConnectionWaitTimeout";
    static final String LOCAL_TXN_COMMIT_ON_CLOSE = "LocalTransactionCommitOnClose";
    static final String USE_LIFO_KEY = "UseLIFO";
    static final int INSTANCE_GOOD = 1;
    static final int INSTANCE_UNKNOWN = 2;
    static final int INSTANCE_VIOLATING = 3;
    static final int INSTANCE_NO_DATA = 4;
    static final int INSTANCE_BLOCKED = 5;
    static final int RLB_NUMBER_OF_HITS_PER_INSTANCE = 1000;
    int dbInstancePercentTotal;
    boolean useGoodGroup;
    Vector instancesToRetireQueue;
    OracleDatabaseInstance instanceToRetire;
    int retireConnectionsCount;
    int countTotal;
    protected OracleConnectionCacheManager cacheManager;
    protected boolean disableConnectionRequest;
    protected OracleImplicitConnectionCacheThread timeoutThread;
    protected OracleRuntimeLoadBalancingEventHandlerThread runtimeLoadBalancingThread;
    protected OracleGravitateConnectionCacheThread gravitateCacheThread;
    protected int connectionsToRemove;
    private HashMap userMap;
    Vector checkedOutConnectionList;
    LinkedList databaseInstancesList;
    int cacheSize;
    protected static final String EVENT_DELIMITER = " ";
    protected boolean isEntireServiceDownProcessed;
    protected int defaultUserPreFailureSize;
    protected String dataSourceServiceName;
    protected OracleFailoverWorkerThread failoverWorkerThread;
    protected Random rand;
    protected int downEventCount;
    protected int upEventCount;
    protected int pendingCreationRequests;
    protected int connectionClosedCount;
    protected int connectionCreatedCount;
    boolean cacheLocalTxnCommitOnClose;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleImplicitConnectionCache(OracleDataSource oracledatasource, Properties properties)
        throws SQLException
    {
        cacheEnabledDS = null;
        cacheName = null;
        connectionPoolDS = null;
        fastConnectionFailoverEnabled = false;
        defaultUser = null;
        defaultPassword = null;
        cacheMinLimit = 0;
        cacheMaxLimit = 0x7fffffff;
        cacheInitialLimit = 0;
        cacheMaxStatementsLimit = 0;
        cacheAttributeWeights = null;
        cacheInactivityTimeout = 0;
        cacheTimeToLiveTimeout = 0;
        cacheAbandonedConnectionTimeout = 0;
        cacheLowerThresholdLimit = 20;
        cachePropertyCheckInterval = 900;
        cacheClosestConnectionMatch = false;
        cacheValidateConnection = false;
        cacheUseLIFO = false;
        cacheConnectionWaitTimeout = 0;
        dbInstancePercentTotal = 0;
        useGoodGroup = false;
        instancesToRetireQueue = null;
        instanceToRetire = null;
        retireConnectionsCount = 0;
        countTotal = 0;
        cacheManager = null;
        disableConnectionRequest = false;
        timeoutThread = null;
        runtimeLoadBalancingThread = null;
        gravitateCacheThread = null;
        connectionsToRemove = 0;
        userMap = null;
        checkedOutConnectionList = null;
        databaseInstancesList = null;
        cacheSize = 0;
        isEntireServiceDownProcessed = false;
        defaultUserPreFailureSize = 0;
        dataSourceServiceName = null;
        failoverWorkerThread = null;
        rand = null;
        downEventCount = 0;
        upEventCount = 0;
        pendingCreationRequests = 0;
        connectionClosedCount = 0;
        connectionCreatedCount = 0;
        cacheLocalTxnCommitOnClose = false;
        cacheEnabledDS = oracledatasource;
        initializeConnectionCache();
        setConnectionCacheProperties(properties);
        defaultUserPrePopulateCache(cacheInitialLimit);
    }

    private void defaultUserPrePopulateCache(int i)
        throws SQLException
    {
        if(i > 0)
        {
            String s = defaultUser;
            String s1 = defaultPassword;
            validateUser(s, s1);
            Object obj = null;
            for(int j = 0; j < i; j++)
            {
                OraclePooledConnection oraclepooledconnection = makeOneConnection(s, s1);
                synchronized(this)
                {
                    if(oraclepooledconnection != null)
                    {
                        cacheSize--;
                        storeCacheConnection(null, oraclepooledconnection);
                    }
                }
            }

        }
    }

    protected void initializeConnectionCache()
        throws SQLException
    {
        userMap = new HashMap();
        checkedOutConnectionList = new Vector();
        if(cacheManager == null)
            cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
        if(cacheEnabledDS.user != null && !cacheEnabledDS.user.startsWith("\""))
            defaultUser = cacheEnabledDS.user.toLowerCase();
        else
            defaultUser = cacheEnabledDS.user;
        defaultPassword = cacheEnabledDS.password;
        if(connectionPoolDS == null)
        {
            if(cacheEnabledDS instanceof OracleXADataSource)
                connectionPoolDS = new OracleXADataSource();
            else
                connectionPoolDS = new OracleConnectionPoolDataSource();
            cacheEnabledDS.copy(connectionPoolDS);
        }
        if(fastConnectionFailoverEnabled = cacheEnabledDS.getFastConnectionFailoverEnabled())
        {
            rand = new Random(0L);
            instancesToRetireQueue = new Vector();
            cacheManager.failoverEnabledCacheCount++;
        }
    }

    private void validateUser(String s, String s1)
        throws SQLException
    {
        if(s == null || s1 == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 79);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    protected Connection getConnection(String s, String s1, Properties properties)
        throws SQLException
    {
        OraclePooledConnection oraclepooledconnection = null;
        Connection connection = null;
        try
        {
            if(disableConnectionRequest)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 142);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            validateUser(s, s1);
            if(!s.startsWith("\""))
                s = s.toLowerCase();
            if(getNumberOfCheckedOutConnections() < cacheMaxLimit)
                oraclepooledconnection = getCacheConnection(s, s1, properties);
            if(oraclepooledconnection == null)
            {
                processConnectionCacheCallback();
                if(cacheSize > 0)
                    oraclepooledconnection = getCacheConnection(s, s1, properties);
                if(oraclepooledconnection == null && cacheConnectionWaitTimeout > 0)
                {
                    long l = (long)cacheConnectionWaitTimeout * 1000L;
                    long l1 = System.currentTimeMillis();
                    long l2 = 0L;
                    do
                    {
                        processConnectionWaitTimeout(l);
                        if(cacheSize > 0)
                            oraclepooledconnection = getCacheConnection(s, s1, properties);
                        long l3 = System.currentTimeMillis();
                        l -= System.currentTimeMillis() - l1;
                        l1 = l3;
                    } while(oraclepooledconnection == null && l > 0L);
                }
            }
            if(oraclepooledconnection != null && oraclepooledconnection.physicalConn != null)
            {
                connection = oraclepooledconnection.getConnection();
                if(connection != null)
                {
                    if(cacheValidateConnection && testDatabaseConnection((OracleConnection)connection) != 0)
                    {
                        ((OracleConnection)connection).close(4096);
                        SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 143);
                        sqlexception1.fillInStackTrace();
                        throw sqlexception1;
                    }
                    if(cacheAbandonedConnectionTimeout > 0)
                        ((OracleConnection)connection).setAbandonedTimeoutEnabled(true);
                    if(cacheTimeToLiveTimeout > 0)
                        ((OracleConnection)connection).setStartTime(System.currentTimeMillis());
                    synchronized(this)
                    {
                        cacheSize--;
                        checkedOutConnectionList.addElement(oraclepooledconnection);
                    }
                }
            }
        }
        catch(SQLException sqlexception2)
        {
            synchronized(this)
            {
                if(oraclepooledconnection != null)
                {
                    cacheSize--;
                    abortConnection(oraclepooledconnection);
                }
            }
            throw sqlexception2;
        }
        return connection;
    }

    private OraclePooledConnection getCacheConnection(String s, String s1, Properties properties)
        throws SQLException
    {
        OraclePooledConnection oraclepooledconnection = retrieveCacheConnection(s, s1, properties);
        if(oraclepooledconnection == null)
        {
            oraclepooledconnection = makeOneConnection(s, s1);
            if(oraclepooledconnection != null && properties != null && !properties.isEmpty())
                setUnMatchedAttributes(properties, oraclepooledconnection);
        }
        return oraclepooledconnection;
    }

    OraclePooledConnection makeOneConnection(String s, String s1)
        throws SQLException
    {
        OraclePooledConnection oraclepooledconnection;
        oraclepooledconnection = null;
        boolean flag = false;
        synchronized(this)
        {
            if(getTotalCachedConnections() + pendingCreationRequests < cacheMaxLimit)
            {
                pendingCreationRequests++;
                flag = true;
            }
        }
        if(!flag)
            break MISSING_BLOCK_LABEL_159;
        oraclepooledconnection = makeCacheConnection(s, s1);
        synchronized(this)
        {
            if(oraclepooledconnection != null)
                connectionCreatedCount++;
            pendingCreationRequests--;
        }
        break MISSING_BLOCK_LABEL_159;
        Exception exception2;
        exception2;
        synchronized(this)
        {
            if(oraclepooledconnection != null)
                connectionCreatedCount++;
            pendingCreationRequests--;
        }
        throw exception2;
        return oraclepooledconnection;
    }

    protected int getTotalCachedConnections()
    {
        return cacheSize + getNumberOfCheckedOutConnections();
    }

    protected int getNumberOfCheckedOutConnections()
    {
        return checkedOutConnectionList.size();
    }

    private synchronized OraclePooledConnection retrieveCacheConnection(String s, String s1, Properties properties)
        throws SQLException
    {
        OraclePooledConnection oraclepooledconnection = null;
        OracleConnectionCacheEntry oracleconnectioncacheentry = (OracleConnectionCacheEntry)userMap.get(OraclePooledConnection.generateKey(s, s1));
        if(oracleconnectioncacheentry != null)
            if(properties == null || properties != null && properties.isEmpty())
            {
                if(oracleconnectioncacheentry.userConnList != null)
                    oraclepooledconnection = retrieveFromConnectionList(oracleconnectioncacheentry.userConnList);
            } else
            if(oracleconnectioncacheentry.attrConnMap != null)
            {
                String s2 = buildAttrKey(properties);
                Vector vector = (Vector)(Vector)oracleconnectioncacheentry.attrConnMap.get(s2);
                if(vector != null)
                    oraclepooledconnection = retrieveFromConnectionList(vector);
                if(oraclepooledconnection == null && cacheClosestConnectionMatch)
                    oraclepooledconnection = retrieveClosestConnectionMatch(oracleconnectioncacheentry.attrConnMap, properties);
                if(oraclepooledconnection == null && oracleconnectioncacheentry.userConnList != null)
                    oraclepooledconnection = retrieveFromConnectionList(oracleconnectioncacheentry.userConnList);
            }
        if(oraclepooledconnection != null && properties != null && !properties.isEmpty())
            setUnMatchedAttributes(properties, oraclepooledconnection);
        return oraclepooledconnection;
    }

    private OraclePooledConnection retrieveClosestConnectionMatch(HashMap hashmap, Properties properties)
        throws SQLException
    {
        Object obj = null;
        OraclePooledConnection oraclepooledconnection1 = null;
        Vector vector = null;
        int i = properties.size();
        int j = 0;
        int k = 0;
        boolean flag = false;
        int i1 = 0;
        boolean flag1 = false;
        if(cacheAttributeWeights != null)
            j = getAttributesWeightCount(properties, null);
        if(hashmap != null && !hashmap.isEmpty())
        {
            for(Iterator iterator = hashmap.entrySet().iterator(); iterator.hasNext();)
            {
                java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                Vector vector1 = (Vector)entry.getValue();
                Object aobj[] = vector1.toArray();
                int k1 = vector1.size();
                int l1 = 0;
                while(l1 < k1) 
                {
                    OraclePooledConnection oraclepooledconnection = (OraclePooledConnection)aobj[l1];
                    if(oraclepooledconnection.cachedConnectionAttributes != null && !oraclepooledconnection.cachedConnectionAttributes.isEmpty() && oraclepooledconnection.cachedConnectionAttributes.size() <= i)
                        if(j > 0)
                        {
                            int l = getAttributesWeightCount(properties, oraclepooledconnection.cachedConnectionAttributes);
                            if(l > k)
                            {
                                oraclepooledconnection1 = oraclepooledconnection;
                                k = l;
                                vector = vector1;
                            }
                        } else
                        {
                            int j1 = getAttributesMatchCount(properties, oraclepooledconnection.cachedConnectionAttributes);
                            if(j1 > i1)
                            {
                                oraclepooledconnection1 = oraclepooledconnection;
                                i1 = j1;
                                vector = vector1;
                            }
                        }
                    l1++;
                }
            }

        }
        if(vector != null)
            vector.remove(oraclepooledconnection1);
        return oraclepooledconnection1;
    }

    private int getAttributesMatchCount(Properties properties, Properties properties1)
        throws SQLException
    {
        int i = 0;
        Object obj = null;
        Object obj1 = null;
        Object obj3 = null;
        Iterator iterator = properties.entrySet().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
            Object obj2 = entry.getKey();
            Object obj4 = entry.getValue();
            if(properties1.containsKey(obj2) && obj4.equals(properties1.get(obj2)))
                i++;
        } while(true);
        return i;
    }

    private int getAttributesWeightCount(Properties properties, Properties properties1)
        throws SQLException
    {
        Object obj = null;
        Object obj1 = null;
        Object obj3 = null;
        int i = 0;
        Iterator iterator = properties.entrySet().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
            Object obj2 = entry.getKey();
            Object obj4 = entry.getValue();
            if(properties1 == null)
            {
                if(cacheAttributeWeights.containsKey(obj2))
                    i += Integer.parseInt((String)(String)cacheAttributeWeights.get(obj2));
            } else
            if(properties1.containsKey(obj2) && obj4.equals(properties1.get(obj2)))
                if(cacheAttributeWeights.containsKey(obj2))
                    i += Integer.parseInt((String)(String)cacheAttributeWeights.get(obj2));
                else
                    i++;
        } while(true);
        return i;
    }

    private void setUnMatchedAttributes(Properties properties, OraclePooledConnection oraclepooledconnection)
        throws SQLException
    {
        if(oraclepooledconnection.unMatchedCachedConnAttr == null)
            oraclepooledconnection.unMatchedCachedConnAttr = new Properties();
        else
            oraclepooledconnection.unMatchedCachedConnAttr.clear();
        if(!cacheClosestConnectionMatch)
        {
            oraclepooledconnection.unMatchedCachedConnAttr.putAll(properties);
        } else
        {
            Properties properties1 = oraclepooledconnection.cachedConnectionAttributes;
            Object obj = null;
            Object obj1 = null;
            Object obj3 = null;
            Iterator iterator = properties.entrySet().iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                Object obj2 = entry.getKey();
                Object obj4 = entry.getValue();
                if(!properties1.containsKey(obj2) && !obj4.equals(properties1.get(obj2)))
                    oraclepooledconnection.unMatchedCachedConnAttr.put(obj2, obj4);
            } while(true);
        }
    }

    private OraclePooledConnection retrieveFromConnectionList(Vector vector)
        throws SQLException
    {
        if(vector.isEmpty())
            return null;
        OraclePooledConnection oraclepooledconnection = null;
        if(fastConnectionFailoverEnabled)
        {
            if(useGoodGroup && databaseInstancesList != null && databaseInstancesList.size() > 0)
                synchronized(databaseInstancesList)
                {
                    int j = databaseInstancesList.size();
                    Object obj = null;
                    boolean flag = false;
                    boolean aflag[] = new boolean[j];
                    int k1 = dbInstancePercentTotal;
label0:
                    for(int l1 = 0; l1 < j; l1++)
                    {
                        int i2 = 0;
                        int l;
                        if(k1 <= 1)
                            l = 0;
                        else
                            l = rand.nextInt(k1 - 1);
                        for(int j2 = 0; j2 < j; j2++)
                        {
                            OracleDatabaseInstance oracledatabaseinstance = (OracleDatabaseInstance)databaseInstancesList.get(j2);
                            if(aflag[j2] || oracledatabaseinstance.flag > 3)
                                continue;
                            i2 += oracledatabaseinstance.percent;
                            if(l > i2)
                                continue;
                            if(l1 == 0)
                                oracledatabaseinstance.attemptedConnRequestCount++;
                            if((oraclepooledconnection = selectConnectionFromList(vector, oracledatabaseinstance)) != null)
                                break label0;
                            k1 -= oracledatabaseinstance.percent;
                            aflag[j2] = true;
                            break;
                        }

                    }

                }
            else
            if(!cacheUseLIFO)
            {
                int i = vector.size();
                int k = rand.nextInt(i);
                Object obj1 = null;
                int i1 = 0;
                do
                {
                    if(i1 >= i)
                        break;
                    int j1 = (k++ + i) % i;
                    OraclePooledConnection oraclepooledconnection1 = (OraclePooledConnection)vector.get(j1);
                    if(!oraclepooledconnection1.connectionMarkedDown)
                    {
                        oraclepooledconnection = oraclepooledconnection1;
                        vector.remove(oraclepooledconnection);
                        break;
                    }
                    i1++;
                } while(true);
            } else
            {
                oraclepooledconnection = (OraclePooledConnection)vector.remove(0);
            }
        } else
        {
            oraclepooledconnection = (OraclePooledConnection)vector.remove(0);
        }
        return oraclepooledconnection;
    }

    private OraclePooledConnection selectConnectionFromList(Vector vector, OracleDatabaseInstance oracledatabaseinstance)
    {
        OraclePooledConnection oraclepooledconnection = null;
        Object obj = null;
        int i = vector.size();
        int j = 0;
        do
        {
            if(j >= i)
                break;
            OraclePooledConnection oraclepooledconnection1 = (OraclePooledConnection)vector.get(j);
            if(!oraclepooledconnection1.connectionMarkedDown && oraclepooledconnection1.dataSourceDbUniqNameKey == oracledatabaseinstance.databaseUniqName && oraclepooledconnection1.dataSourceInstanceNameKey == oracledatabaseinstance.instanceName)
            {
                oraclepooledconnection = oraclepooledconnection1;
                vector.remove(oraclepooledconnection);
                break;
            }
            j++;
        } while(true);
        return oraclepooledconnection;
    }

    private void removeCacheConnection(OraclePooledConnection oraclepooledconnection)
        throws SQLException
    {
        boolean flag = false;
        OracleConnectionCacheEntry oracleconnectioncacheentry = oraclepooledconnection.removeFromImplictCache(userMap);
        if(oracleconnectioncacheentry != null)
        {
            Properties properties = oraclepooledconnection.cachedConnectionAttributes;
            if(properties == null || properties != null && properties.isEmpty())
            {
                if(oracleconnectioncacheentry.userConnList != null)
                    flag = oracleconnectioncacheentry.userConnList.removeElement(oraclepooledconnection);
            } else
            if(oracleconnectioncacheentry.attrConnMap != null)
            {
                String s = buildAttrKey(properties);
                Vector vector = (Vector)(Vector)oracleconnectioncacheentry.attrConnMap.get(s);
                if(vector != null)
                {
                    if(oraclepooledconnection.unMatchedCachedConnAttr != null)
                    {
                        oraclepooledconnection.unMatchedCachedConnAttr.clear();
                        oraclepooledconnection.unMatchedCachedConnAttr = null;
                    }
                    if(oraclepooledconnection.cachedConnectionAttributes != null)
                    {
                        oraclepooledconnection.cachedConnectionAttributes.clear();
                        oraclepooledconnection.cachedConnectionAttributes = null;
                    }
                    Object obj = null;
                    flag = vector.removeElement(oraclepooledconnection);
                }
            }
        }
        if(flag)
            cacheSize--;
    }

    protected void doForEveryCachedConnection(int i)
        throws SQLException
    {
        int j = 0;
        synchronized(this)
        {
            if(userMap != null && !userMap.isEmpty())
            {
                Iterator iterator = userMap.entrySet().iterator();
                do
                {
                    if(!iterator.hasNext())
                        break;
                    java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                    OracleConnectionCacheEntry oracleconnectioncacheentry = (OracleConnectionCacheEntry)entry.getValue();
                    if(oracleconnectioncacheentry.userConnList != null && !oracleconnectioncacheentry.userConnList.isEmpty())
                    {
                        Vector vector = oracleconnectioncacheentry.userConnList;
                        Object aobj[] = vector.toArray();
                        for(int k = 0; k < aobj.length; k++)
                        {
                            OraclePooledConnection oraclepooledconnection = (OraclePooledConnection)aobj[k];
                            if(oraclepooledconnection != null && performPooledConnectionTask(oraclepooledconnection, i))
                                j++;
                        }

                    }
                    if(oracleconnectioncacheentry.attrConnMap != null && !oracleconnectioncacheentry.attrConnMap.isEmpty())
                    {
                        for(Iterator iterator1 = oracleconnectioncacheentry.attrConnMap.entrySet().iterator(); iterator1.hasNext();)
                        {
                            java.util.Map.Entry entry1 = (java.util.Map.Entry)iterator1.next();
                            Vector vector1 = (Vector)entry1.getValue();
                            Object aobj1[] = vector1.toArray();
                            int l = 0;
                            while(l < aobj1.length) 
                            {
                                OraclePooledConnection oraclepooledconnection1 = (OraclePooledConnection)aobj1[l];
                                if(oraclepooledconnection1 != null && performPooledConnectionTask(oraclepooledconnection1, i))
                                    j++;
                                l++;
                            }
                        }

                        if(i == 1 || i == 32)
                            oracleconnectioncacheentry.attrConnMap.clear();
                    }
                } while(true);
                if(i == 1 || i == 32)
                {
                    userMap.clear();
                    cacheSize = 0;
                }
            }
        }
        if(j > 0)
            defaultUserPrePopulateCache(j);
    }

    private boolean performPooledConnectionTask(OraclePooledConnection oraclepooledconnection, int i)
        throws SQLException
    {
        boolean flag = false;
        switch(i)
        {
        default:
            break;

        case 2: // '\002'
            if(oraclepooledconnection.connectionMarkedDown)
            {
                oraclepooledconnection.needToAbort = true;
                closeAndRemovePooledConnection(oraclepooledconnection);
            }
            break;

        case 8: // '\b'
            if(connectionsToRemove > 0)
            {
                closeAndRemovePooledConnection(oraclepooledconnection);
                connectionsToRemove--;
            }
            break;

        case 24: // '\030'
            if(retireConnectionsCount <= 0 || instanceToRetire.databaseUniqName != oraclepooledconnection.dataSourceDbUniqNameKey || instanceToRetire.instanceName != oraclepooledconnection.dataSourceInstanceNameKey)
                break;
            closeAndRemovePooledConnection(oraclepooledconnection);
            retireConnectionsCount--;
            if(getTotalCachedConnections() < cacheMinLimit)
                flag = true;
            break;

        case 4096: 
            Connection connection = oraclepooledconnection.getLogicalHandle();
            if((connection != null || (connection = oraclepooledconnection.getPhysicalHandle()) != null) && testDatabaseConnection((OracleConnection)connection) != 0)
            {
                closeAndRemovePooledConnection(oraclepooledconnection);
                flag = true;
            }
            break;

        case 8192: 
            closeAndRemovePooledConnection(oraclepooledconnection);
            flag = true;
            break;

        case 1: // '\001'
            closeAndRemovePooledConnection(oraclepooledconnection);
            break;

        case 4: // '\004'
            processInactivityTimeout(oraclepooledconnection);
            break;

        case 16: // '\020'
            setStatementCaching(oraclepooledconnection, cacheMaxStatementsLimit, false);
            break;

        case 18: // '\022'
            setStatementCaching(oraclepooledconnection, cacheMaxStatementsLimit, true);
            break;

        case 32: // ' '
            abortConnection(oraclepooledconnection);
            closeAndRemovePooledConnection(oraclepooledconnection);
            break;
        }
        return flag;
    }

    protected synchronized void doForEveryCheckedOutConnection(int i)
        throws SQLException
    {
        int j = checkedOutConnectionList.size();
label0:
        switch(i)
        {
        default:
            break;

        case 1: // '\001'
            for(int k = 0; k < j; k++)
                closeCheckedOutConnection((OraclePooledConnection)checkedOutConnectionList.get(k), false);

            checkedOutConnectionList.removeAllElements();
            break;

        case 24: // '\030'
            int l = 0;
            do
            {
                if(l >= j || retireConnectionsCount <= 0)
                    break label0;
                OraclePooledConnection oraclepooledconnection = (OraclePooledConnection)checkedOutConnectionList.get(l);
                if(instanceToRetire.databaseUniqName == oraclepooledconnection.dataSourceDbUniqNameKey && instanceToRetire.instanceName == oraclepooledconnection.dataSourceInstanceNameKey)
                {
                    oraclepooledconnection.closeOption = 4096;
                    retireConnectionsCount -= 2;
                }
                l++;
            } while(true);

        case 32: // ' '
            for(int i1 = 0; i1 < j; i1++)
            {
                OraclePooledConnection oraclepooledconnection1 = null;
                abortConnection(oraclepooledconnection1 = (OraclePooledConnection)checkedOutConnectionList.get(i1));
                closeCheckedOutConnection(oraclepooledconnection1, false);
            }

            checkedOutConnectionList.removeAllElements();
            break;
        }
    }

    protected void closeCheckedOutConnection(OraclePooledConnection oraclepooledconnection, boolean flag)
        throws SQLException
    {
        OracleConnection oracleconnection;
        OracleConnection oracleconnection1;
        boolean flag1;
        boolean flag2;
        if(oraclepooledconnection == null)
            break MISSING_BLOCK_LABEL_172;
        oracleconnection = (OracleConnection)oraclepooledconnection.getLogicalHandle();
        oracleconnection1 = (OracleConnection)oraclepooledconnection.getPhysicalHandle();
        flag1 = oracleconnection.getAutoCommit();
        if(!flag)
            break MISSING_BLOCK_LABEL_136;
        flag2 = oraclepooledconnection.localTxnCommitOnClose;
        try
        {
            oraclepooledconnection.localTxnCommitOnClose = false;
            oracleconnection.cleanupAndClose(true);
            try
            {
                if(!flag1 && !oraclepooledconnection.needToAbort)
                    oracleconnection1.rollback();
            }
            catch(SQLException sqlexception1) { }
        }
        catch(SQLException sqlexception2)
        {
            if(oraclepooledconnection.localTxnCommitOnClose != flag2)
                oraclepooledconnection.localTxnCommitOnClose = flag2;
            break MISSING_BLOCK_LABEL_172;
        }
        if(oraclepooledconnection.localTxnCommitOnClose != flag2)
            oraclepooledconnection.localTxnCommitOnClose = flag2;
        break MISSING_BLOCK_LABEL_172;
        Exception exception;
        exception;
        if(oraclepooledconnection.localTxnCommitOnClose != flag2)
            oraclepooledconnection.localTxnCommitOnClose = flag2;
        throw exception;
        try
        {
            if(!flag1 && !oraclepooledconnection.needToAbort)
            {
                oracleconnection1.cancel();
                oracleconnection1.rollback();
            }
        }
        catch(SQLException sqlexception) { }
        actualPooledConnectionClose(oraclepooledconnection);
    }

    synchronized void storeCacheConnection(Properties properties, OraclePooledConnection oraclepooledconnection)
        throws SQLException
    {
        boolean flag = false;
        if(oraclepooledconnection == null || oraclepooledconnection.physicalConn == null)
            return;
        if(cacheInactivityTimeout > 0)
            oraclepooledconnection.setLastAccessedTime(System.currentTimeMillis());
        if(oraclepooledconnection.unMatchedCachedConnAttr != null)
        {
            oraclepooledconnection.unMatchedCachedConnAttr.clear();
            oraclepooledconnection.unMatchedCachedConnAttr = null;
        }
        OracleConnectionCacheEntry oracleconnectioncacheentry = oraclepooledconnection.removeFromImplictCache(userMap);
        if(oracleconnectioncacheentry != null)
        {
            if(properties == null || properties != null && properties.isEmpty())
            {
                if(oracleconnectioncacheentry.userConnList == null)
                    oracleconnectioncacheentry.userConnList = new Vector();
                if(cacheUseLIFO)
                {
                    oracleconnectioncacheentry.userConnList.add(0, oraclepooledconnection);
                    flag = true;
                } else
                {
                    flag = oracleconnectioncacheentry.userConnList.add(oraclepooledconnection);
                }
            } else
            {
                oraclepooledconnection.cachedConnectionAttributes = properties;
                if(oracleconnectioncacheentry.attrConnMap == null)
                    oracleconnectioncacheentry.attrConnMap = new HashMap();
                String s = buildAttrKey(properties);
                Vector vector1 = (Vector)(Vector)oracleconnectioncacheentry.attrConnMap.get(s);
                if(vector1 != null)
                {
                    if(cacheUseLIFO)
                    {
                        vector1.add(0, oraclepooledconnection);
                        flag = true;
                    } else
                    {
                        flag = vector1.add(oraclepooledconnection);
                    }
                } else
                {
                    Vector vector2 = new Vector();
                    flag = vector2.add(oraclepooledconnection);
                    oracleconnectioncacheentry.attrConnMap.put(s, vector2);
                }
            }
        } else
        {
            OracleConnectionCacheEntry oracleconnectioncacheentry1 = new OracleConnectionCacheEntry();
            oraclepooledconnection.addToImplicitCache(userMap, oracleconnectioncacheentry1);
            if(properties == null || properties != null && properties.isEmpty())
            {
                Vector vector = new Vector();
                flag = vector.add(oraclepooledconnection);
                oracleconnectioncacheentry1.userConnList = vector;
            } else
            {
                String s1 = buildAttrKey(properties);
                oraclepooledconnection.cachedConnectionAttributes = properties;
                HashMap hashmap = new HashMap();
                Vector vector3 = new Vector();
                flag = vector3.add(oraclepooledconnection);
                hashmap.put(s1, vector3);
                oracleconnectioncacheentry1.attrConnMap = hashmap;
            }
        }
        if(flag)
            cacheSize++;
        if(cacheConnectionWaitTimeout > 0)
            notifyAll();
    }

    private String buildAttrKey(Properties properties)
        throws SQLException
    {
        int i = properties.keySet().size();
        Object aobj[] = properties.keySet().toArray();
        boolean flag = true;
        StringBuffer stringbuffer = new StringBuffer();
        while(flag) 
        {
            flag = false;
            int j = 0;
            while(j < i - 1) 
            {
                if(((String)aobj[j]).compareTo((String)aobj[j + 1]) > 0)
                {
                    flag = true;
                    Object obj = aobj[j];
                    aobj[j] = aobj[j + 1];
                    aobj[j + 1] = obj;
                }
                j++;
            }
        }
        for(int k = 0; k < i; k++)
            stringbuffer.append((new StringBuilder()).append(aobj[k]).append("0xffff").append(properties.get(aobj[k])).toString());

        return stringbuffer.toString();
    }

    protected OraclePooledConnection makeCacheConnection(String s, String s1)
        throws SQLException
    {
        OraclePooledConnection oraclepooledconnection = (OraclePooledConnection)connectionPoolDS.getPooledConnection(s, s1);
        if(oraclepooledconnection != null)
        {
            if(cacheMaxStatementsLimit > 0)
                setStatementCaching(oraclepooledconnection, cacheMaxStatementsLimit, true);
            oraclepooledconnection.registerImplicitCacheConnectionEventListener(new OracleConnectionCacheEventListener(this));
            oraclepooledconnection.cachedConnectionAttributes = new Properties();
            if(fastConnectionFailoverEnabled)
                initFailoverParameters(oraclepooledconnection);
            synchronized(this)
            {
                cacheSize++;
                if(fastConnectionFailoverEnabled && runtimeLoadBalancingThread == null)
                {
                    runtimeLoadBalancingThread = new OracleRuntimeLoadBalancingEventHandlerThread(dataSourceServiceName);
                    cacheManager.checkAndStartThread(runtimeLoadBalancingThread);
                }
            }
            oraclepooledconnection.localTxnCommitOnClose = cacheLocalTxnCommitOnClose;
        }
        return oraclepooledconnection;
    }

    private void setStatementCaching(OraclePooledConnection oraclepooledconnection, int i, boolean flag)
        throws SQLException
    {
        if(i > 0)
            oraclepooledconnection.setStatementCacheSize(i);
        oraclepooledconnection.setImplicitCachingEnabled(flag);
        oraclepooledconnection.setExplicitCachingEnabled(flag);
    }

    protected synchronized void reusePooledConnection(PooledConnection pooledconnection)
        throws SQLException
    {
        OraclePooledConnection oraclepooledconnection = (OraclePooledConnection)pooledconnection;
        if(oraclepooledconnection != null && oraclepooledconnection.physicalConn != null)
        {
            if(oraclepooledconnection.localTxnCommitOnClose)
                oraclepooledconnection.physicalConn.commit();
            storeCacheConnection(oraclepooledconnection.cachedConnectionAttributes, oraclepooledconnection);
            checkedOutConnectionList.removeElement(oraclepooledconnection);
            oraclepooledconnection.logicalHandle = null;
        }
    }

    protected void closePooledConnection(PooledConnection pooledconnection)
        throws SQLException
    {
        if(pooledconnection != null)
        {
            actualPooledConnectionClose((OraclePooledConnection)pooledconnection);
            if(((OraclePooledConnection)pooledconnection).closeOption == 4096)
                checkedOutConnectionList.removeElement(pooledconnection);
            pooledconnection = null;
            if(getTotalCachedConnections() < cacheMinLimit)
                defaultUserPrePopulateCache(1);
        }
    }

    protected void refreshCacheConnections(int i)
        throws SQLException
    {
        doForEveryCachedConnection(i);
    }

    protected void reinitializeCacheConnections(Properties properties)
        throws SQLException
    {
        int l = 0;
        synchronized(this)
        {
            defaultUser = cacheEnabledDS.user;
            defaultPassword = cacheEnabledDS.password;
            fastConnectionFailoverEnabled = cacheEnabledDS.getFastConnectionFailoverEnabled();
            cleanupTimeoutThread();
            doForEveryCheckedOutConnection(1);
            int i = cacheInitialLimit;
            int j = cacheMaxLimit;
            int k = cacheMaxStatementsLimit;
            setConnectionCacheProperties(properties);
            if(cacheInitialLimit > i)
                l = cacheInitialLimit - i;
            if(j != 0x7fffffff && cacheMaxLimit < j && cacheSize > cacheMaxLimit)
            {
                connectionsToRemove = cacheSize - cacheMaxLimit;
                doForEveryCachedConnection(8);
                connectionsToRemove = 0;
            }
            if(cacheMaxStatementsLimit != k)
                if(cacheMaxStatementsLimit == 0)
                    doForEveryCachedConnection(16);
                else
                    doForEveryCachedConnection(18);
        }
        if(l > 0)
            defaultUserPrePopulateCache(l);
    }

    protected synchronized void setConnectionCacheProperties(Properties properties)
        throws SQLException
    {
        try
        {
            if(properties != null)
            {
                String s = null;
                if((s = properties.getProperty("MinLimit")) != null && (cacheMinLimit = Integer.parseInt(s)) < 0)
                    cacheMinLimit = 0;
                if((s = properties.getProperty("MaxLimit")) != null && (cacheMaxLimit = Integer.parseInt(s)) < 0)
                    cacheMaxLimit = 0x7fffffff;
                if(cacheMaxLimit < cacheMinLimit)
                    cacheMinLimit = cacheMaxLimit;
                if((s = properties.getProperty("InitialLimit")) != null && (cacheInitialLimit = Integer.parseInt(s)) < 0)
                    cacheInitialLimit = 0;
                if(cacheInitialLimit > cacheMaxLimit)
                    cacheInitialLimit = cacheMaxLimit;
                if((s = properties.getProperty("MaxStatementsLimit")) != null && (cacheMaxStatementsLimit = Integer.parseInt(s)) < 0)
                    cacheMaxStatementsLimit = 0;
                Properties properties1 = (Properties)properties.get("AttributeWeights");
                if(properties1 != null)
                {
                    Object obj = null;
                    boolean flag = false;
                    Object obj1 = null;
                    Iterator iterator = properties1.entrySet().iterator();
                    do
                    {
                        if(!iterator.hasNext())
                            break;
                        java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                        Object obj2 = entry.getKey();
                        int i;
                        if((s = (String)(String)properties1.get(obj2)) != null && (i = Integer.parseInt(s)) < 0)
                            properties1.put(obj2, "0");
                    } while(true);
                    if(cacheAttributeWeights == null)
                        cacheAttributeWeights = new Properties();
                    cacheAttributeWeights.putAll(properties1);
                }
                if((s = properties.getProperty("InactivityTimeout")) != null && (cacheInactivityTimeout = Integer.parseInt(s)) < 0)
                    cacheInactivityTimeout = 0;
                if((s = properties.getProperty("TimeToLiveTimeout")) != null && (cacheTimeToLiveTimeout = Integer.parseInt(s)) < 0)
                    cacheTimeToLiveTimeout = 0;
                if((s = properties.getProperty("AbandonedConnectionTimeout")) != null && (cacheAbandonedConnectionTimeout = Integer.parseInt(s)) < 0)
                    cacheAbandonedConnectionTimeout = 0;
                if((s = properties.getProperty("LowerThresholdLimit")) != null)
                {
                    cacheLowerThresholdLimit = Integer.parseInt(s);
                    if(cacheLowerThresholdLimit < 0 || cacheLowerThresholdLimit > 100)
                        cacheLowerThresholdLimit = 20;
                }
                if((s = properties.getProperty("PropertyCheckInterval")) != null && (cachePropertyCheckInterval = Integer.parseInt(s)) < 0)
                    cachePropertyCheckInterval = 900;
                if((s = properties.getProperty("ValidateConnection")) != null)
                    cacheValidateConnection = Boolean.valueOf(s).booleanValue();
                if((s = properties.getProperty("ClosestConnectionMatch")) != null)
                    cacheClosestConnectionMatch = Boolean.valueOf(s).booleanValue();
                if((s = properties.getProperty("UseLIFO")) != null)
                    cacheUseLIFO = Boolean.valueOf(s).booleanValue();
                if((s = properties.getProperty("ConnectionWaitTimeout")) != null && (cacheConnectionWaitTimeout = Integer.parseInt(s)) < 0)
                    cacheConnectionWaitTimeout = 0;
                if((s = properties.getProperty("LocalTransactionCommitOnClose")) != null)
                    cacheLocalTxnCommitOnClose = s.equalsIgnoreCase("true");
            } else
            {
                cacheMinLimit = 0;
                cacheMaxLimit = 0x7fffffff;
                cacheInitialLimit = 0;
                cacheMaxStatementsLimit = 0;
                cacheAttributeWeights = null;
                cacheInactivityTimeout = 0;
                cacheTimeToLiveTimeout = 0;
                cacheAbandonedConnectionTimeout = 0;
                cacheLowerThresholdLimit = 20;
                cachePropertyCheckInterval = 900;
                cacheClosestConnectionMatch = false;
                cacheValidateConnection = false;
                cacheConnectionWaitTimeout = 0;
                cacheLocalTxnCommitOnClose = false;
                cacheUseLIFO = false;
            }
            if((cacheInactivityTimeout > 0 || cacheTimeToLiveTimeout > 0 || cacheAbandonedConnectionTimeout > 0) && cachePropertyCheckInterval > 0)
            {
                if(timeoutThread == null)
                    timeoutThread = new OracleImplicitConnectionCacheThread(this);
                cacheManager.checkAndStartThread(timeoutThread);
            }
            if(cachePropertyCheckInterval == 0)
                cleanupTimeoutThread();
        }
        catch(NumberFormatException numberformatexception)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 139, (new StringBuilder()).append("OracleImplicitConnectionCache:setConnectionCacheProperties() - NumberFormatException Occurred :").append(numberformatexception.getMessage()).toString());
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    protected Properties getConnectionCacheProperties()
        throws SQLException
    {
        Properties properties = new Properties();
        properties.setProperty("MinLimit", String.valueOf(cacheMinLimit));
        properties.setProperty("MaxLimit", String.valueOf(cacheMaxLimit));
        properties.setProperty("InitialLimit", String.valueOf(cacheInitialLimit));
        properties.setProperty("MaxStatementsLimit", String.valueOf(cacheMaxStatementsLimit));
        if(cacheAttributeWeights != null)
            properties.put("AttributeWeights", cacheAttributeWeights);
        else
            properties.setProperty("AttributeWeights", "NULL");
        properties.setProperty("InactivityTimeout", String.valueOf(cacheInactivityTimeout));
        properties.setProperty("TimeToLiveTimeout", String.valueOf(cacheTimeToLiveTimeout));
        properties.setProperty("AbandonedConnectionTimeout", String.valueOf(cacheAbandonedConnectionTimeout));
        properties.setProperty("LowerThresholdLimit", String.valueOf(cacheLowerThresholdLimit));
        properties.setProperty("PropertyCheckInterval", String.valueOf(cachePropertyCheckInterval));
        properties.setProperty("ConnectionWaitTimeout", String.valueOf(cacheConnectionWaitTimeout));
        properties.setProperty("ValidateConnection", String.valueOf(cacheValidateConnection));
        properties.setProperty("ClosestConnectionMatch", String.valueOf(cacheClosestConnectionMatch));
        properties.setProperty("LocalTransactionCommitOnClose", String.valueOf(cacheLocalTxnCommitOnClose));
        properties.setProperty("UseLIFO", String.valueOf(cacheUseLIFO));
        return properties;
    }

    protected int testDatabaseConnection(OracleConnection oracleconnection)
        throws SQLException
    {
        return oracleconnection.pingDatabase();
    }

    protected synchronized void closeConnectionCache(int i)
        throws SQLException
    {
        cleanupTimeoutThread();
        purgeCacheConnections(true, i);
        connectionPoolDS = null;
        cacheEnabledDS = null;
        checkedOutConnectionList = null;
        userMap = null;
        cacheManager = null;
    }

    protected synchronized void disableConnectionCache()
        throws SQLException
    {
        disableConnectionRequest = true;
    }

    protected synchronized void enableConnectionCache()
        throws SQLException
    {
        disableConnectionRequest = false;
    }

    protected void initFailoverParameters(OraclePooledConnection oraclepooledconnection)
        throws SQLException
    {
        String s = null;
        String s1 = null;
        String s2 = null;
        Properties properties = ((OracleConnection)(OracleConnection)oraclepooledconnection.getPhysicalHandle()).getServerSessionInfo();
        s2 = properties.getProperty("INSTANCE_NAME");
        if(s2 != null)
            s = oraclepooledconnection.dataSourceInstanceNameKey = s2.trim().toLowerCase().intern();
        s2 = properties.getProperty("SERVER_HOST");
        if(s2 != null)
            oraclepooledconnection.dataSourceHostNameKey = s2.trim().toLowerCase().intern();
        s2 = properties.getProperty("SERVICE_NAME");
        if(s2 != null)
            dataSourceServiceName = s2.trim();
        s2 = properties.getProperty("DATABASE_NAME");
        if(s2 != null)
            s1 = oraclepooledconnection.dataSourceDbUniqNameKey = s2.trim().toLowerCase().intern();
        if(databaseInstancesList == null)
            databaseInstancesList = new LinkedList();
        int i = databaseInstancesList.size();
        synchronized(databaseInstancesList)
        {
            Object obj = null;
            boolean flag = false;
            int j = 0;
            do
            {
                if(j >= i)
                    break;
                OracleDatabaseInstance oracledatabaseinstance = (OracleDatabaseInstance)databaseInstancesList.get(j);
                if(oracledatabaseinstance.databaseUniqName == s1 && oracledatabaseinstance.instanceName == s)
                {
                    oracledatabaseinstance.numberOfConnectionsCount++;
                    flag = true;
                    break;
                }
                j++;
            } while(true);
            if(!flag)
            {
                OracleDatabaseInstance oracledatabaseinstance1 = new OracleDatabaseInstance(s1, s);
                oracledatabaseinstance1.numberOfConnectionsCount++;
                databaseInstancesList.add(oracledatabaseinstance1);
            }
        }
    }

    protected void processFailoverEvent(int i, String s, String s1, String s2, String s3, int j)
    {
        if(i == 256)
        {
            if(s3.equalsIgnoreCase("down") || s3.equalsIgnoreCase("not_restarting") || s3.equalsIgnoreCase("restart_failed"))
            {
                downEventCount++;
                markDownLostConnections(true, false, s, s1, s2, s3);
                cleanupFailoverConnections(true, false, s, s1, s2, s3);
            } else
            if(s3.equalsIgnoreCase("up"))
            {
                if(downEventCount > 0)
                    upEventCount++;
                try
                {
                    processUpEvent(j);
                }
                catch(Exception exception) { }
                isEntireServiceDownProcessed = false;
            }
        } else
        if(i == 512 && s3.equalsIgnoreCase("nodedown"))
        {
            markDownLostConnections(false, true, s, s1, s2, s3);
            cleanupFailoverConnections(false, true, s, s1, s2, s3);
        }
    }

    void processUpEvent(int i)
        throws SQLException
    {
        int j;
        int k;
        int l;
        boolean flag;
label0:
        {
            j = 0;
            k = 0;
            l = getTotalCachedConnections();
            flag = false;
            synchronized(this)
            {
                if(i <= 1)
                    i = 2;
                if(downEventCount == 0 && upEventCount == 0 && getNumberOfDefaultUserConnections() > 0)
                    j = (int)((double)cacheSize * 0.25D);
                else
                    j = defaultUserPreFailureSize;
                if(j > 0)
                    break label0;
                if(getNumberOfDefaultUserConnections() > 0)
                {
                    k = (int)((double)cacheSize * 0.25D);
                    flag = true;
                    break MISSING_BLOCK_LABEL_115;
                }
            }
            return;
        }
        k = j / i;
        if(k + l > cacheMaxLimit)
            flag = true;
        if(downEventCount == upEventCount)
        {
            defaultUserPreFailureSize = 0;
            downEventCount = 0;
            upEventCount = 0;
        }
        oracleimplicitconnectioncache;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
        if(k > 0)
            loadBalanceConnections(k, flag);
        return;
    }

    private void loadBalanceConnections(int i, boolean flag)
        throws SQLException
    {
        if(flag)
        {
            connectionsToRemove = i;
            doForEveryCachedConnection(8);
            connectionsToRemove = 0;
        }
        if(i <= 10)
        {
            try
            {
                defaultUserPrePopulateCache(i);
            }
            catch(Exception exception) { }
        } else
        {
            int j = (int)((double)i * 0.25D);
            for(int k = 0; k < 4; k++)
                try
                {
                    defaultUserPrePopulateCache(j);
                }
                catch(Exception exception1) { }

        }
    }

    private int getNumberOfDefaultUserConnections()
    {
        int i = 0;
        if(userMap != null && !userMap.isEmpty())
        {
            OracleConnectionCacheEntry oracleconnectioncacheentry = (OracleConnectionCacheEntry)userMap.get(OraclePooledConnection.generateKey(defaultUser, defaultPassword));
            if(oracleconnectioncacheentry != null && oracleconnectioncacheentry.userConnList != null && !oracleconnectioncacheentry.userConnList.isEmpty())
                i = oracleconnectioncacheentry.userConnList.size();
        }
        return i;
    }

    synchronized void markDownLostConnections(boolean flag, boolean flag1, String s, String s1, String s2, String s3)
    {
        if(!isEntireServiceDownProcessed)
        {
            if(userMap != null && !userMap.isEmpty())
            {
                for(Iterator iterator = userMap.entrySet().iterator(); iterator.hasNext();)
                {
                    boolean flag2 = false;
                    java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                    String s4 = null;
                    if(defaultUser != null && defaultPassword != null)
                        s4 = (new StringBuilder()).append(defaultUser).append(defaultPassword).toString();
                    if(s4 != null && s4.equalsIgnoreCase((String)entry.getKey()))
                        flag2 = true;
                    OracleConnectionCacheEntry oracleconnectioncacheentry = (OracleConnectionCacheEntry)entry.getValue();
                    if(oracleconnectioncacheentry != null && oracleconnectioncacheentry.userConnList != null && !oracleconnectioncacheentry.userConnList.isEmpty())
                    {
                        boolean flag3 = false;
                        Iterator iterator2 = oracleconnectioncacheentry.userConnList.iterator();
                        do
                        {
                            if(!iterator2.hasNext())
                                break;
                            OraclePooledConnection oraclepooledconnection = (OraclePooledConnection)iterator2.next();
                            if(flag)
                                flag3 = markDownConnectionsForServiceEvent(s, s1, oraclepooledconnection);
                            else
                            if(flag1)
                                flag3 = markDownConnectionsForHostEvent(s2, oraclepooledconnection);
                            if(flag3 && flag2)
                                defaultUserPreFailureSize++;
                        } while(true);
                    }
                    if(oracleconnectioncacheentry != null && oracleconnectioncacheentry.attrConnMap != null && !oracleconnectioncacheentry.attrConnMap.isEmpty())
                    {
                        Iterator iterator1 = oracleconnectioncacheentry.attrConnMap.entrySet().iterator();
                        while(iterator1.hasNext()) 
                        {
                            java.util.Map.Entry entry1 = (java.util.Map.Entry)iterator1.next();
                            Iterator iterator3 = ((Vector)entry1.getValue()).iterator();
                            while(iterator3.hasNext()) 
                            {
                                OraclePooledConnection oraclepooledconnection1 = (OraclePooledConnection)iterator3.next();
                                if(flag)
                                    markDownConnectionsForServiceEvent(s, s1, oraclepooledconnection1);
                                else
                                if(flag1)
                                    markDownConnectionsForHostEvent(s2, oraclepooledconnection1);
                            }
                        }
                    }
                }

            }
            if(s == null)
                isEntireServiceDownProcessed = true;
        }
    }

    private boolean markDownConnectionsForServiceEvent(String s, String s1, OraclePooledConnection oraclepooledconnection)
    {
        boolean flag = false;
        if(s == null || s1 == oraclepooledconnection.dataSourceDbUniqNameKey && s == oraclepooledconnection.dataSourceInstanceNameKey)
        {
            oraclepooledconnection.connectionMarkedDown = true;
            flag = true;
        }
        return flag;
    }

    private boolean markDownConnectionsForHostEvent(String s, OraclePooledConnection oraclepooledconnection)
    {
        boolean flag = false;
        if(s == oraclepooledconnection.dataSourceHostNameKey)
        {
            oraclepooledconnection.connectionMarkedDown = true;
            oraclepooledconnection.needToAbort = true;
            flag = true;
        }
        return flag;
    }

    synchronized void cleanupFailoverConnections(boolean flag, boolean flag1, String s, String s1, String s2, String s3)
    {
        Object obj = null;
        Object aobj[] = checkedOutConnectionList.toArray();
        int i = checkedOutConnectionList.size();
        OraclePooledConnection aoraclepooledconnection[] = new OraclePooledConnection[i];
        int j = 0;
        for(int k = 0; k < i; k++)
            try
            {
                OraclePooledConnection oraclepooledconnection = (OraclePooledConnection)aobj[k];
                if((!flag || s != null && s != oraclepooledconnection.dataSourceInstanceNameKey || s1 != oraclepooledconnection.dataSourceDbUniqNameKey) && (!flag1 || s2 != oraclepooledconnection.dataSourceHostNameKey))
                    continue;
                if(oraclepooledconnection.isSameUser(defaultUser, defaultPassword) && oraclepooledconnection.cachedConnectionAttributes != null && oraclepooledconnection.cachedConnectionAttributes.isEmpty())
                    defaultUserPreFailureSize++;
                checkedOutConnectionList.removeElement(oraclepooledconnection);
                abortConnection(oraclepooledconnection);
                oraclepooledconnection.needToAbort = true;
                aoraclepooledconnection[j++] = oraclepooledconnection;
            }
            catch(Exception exception) { }

        for(int l = 0; l < j; l++)
            try
            {
                closeCheckedOutConnection(aoraclepooledconnection[l], false);
            }
            catch(SQLException sqlexception1) { }

        if(checkedOutConnectionList.size() < i && cacheConnectionWaitTimeout > 0)
            notifyAll();
        try
        {
            doForEveryCachedConnection(2);
        }
        catch(SQLException sqlexception) { }
        if(databaseInstancesList != null && (i = databaseInstancesList.size()) > 0)
            synchronized(databaseInstancesList)
            {
                Object obj1 = null;
                Object aobj1[] = databaseInstancesList.toArray();
                for(int i1 = 0; i1 < i; i1++)
                {
                    OracleDatabaseInstance oracledatabaseinstance = (OracleDatabaseInstance)aobj1[i1];
                    if(oracledatabaseinstance.databaseUniqName != s1 || oracledatabaseinstance.instanceName != s)
                        continue;
                    if(oracledatabaseinstance.flag <= 3)
                        dbInstancePercentTotal -= oracledatabaseinstance.percent;
                    databaseInstancesList.remove(oracledatabaseinstance);
                }

            }
    }

    void zapRLBInfo()
    {
        databaseInstancesList.clear();
    }

    protected synchronized void closeAndRemovePooledConnection(OraclePooledConnection oraclepooledconnection)
        throws SQLException
    {
        if(oraclepooledconnection != null)
        {
            if(oraclepooledconnection.needToAbort)
                abortConnection(oraclepooledconnection);
            actualPooledConnectionClose(oraclepooledconnection);
            removeCacheConnection(oraclepooledconnection);
        }
    }

    private void abortConnection(OraclePooledConnection oraclepooledconnection)
    {
        try
        {
            ((OracleConnection)(OracleConnection)oraclepooledconnection.getPhysicalHandle()).abort();
        }
        catch(Exception exception) { }
    }

    private void actualPooledConnectionClose(OraclePooledConnection oraclepooledconnection)
        throws SQLException
    {
        int i = 0;
        if(databaseInstancesList != null && (i = databaseInstancesList.size()) > 0)
            synchronized(databaseInstancesList)
            {
                Object obj = null;
                int j = 0;
                do
                {
                    if(j >= i)
                        break;
                    OracleDatabaseInstance oracledatabaseinstance = (OracleDatabaseInstance)databaseInstancesList.get(j);
                    if(oracledatabaseinstance.databaseUniqName == oraclepooledconnection.dataSourceDbUniqNameKey && oracledatabaseinstance.instanceName == oraclepooledconnection.dataSourceInstanceNameKey)
                    {
                        if(oracledatabaseinstance.numberOfConnectionsCount > 0)
                            oracledatabaseinstance.numberOfConnectionsCount--;
                        break;
                    }
                    j++;
                } while(true);
            }
        try
        {
            connectionClosedCount++;
            oraclepooledconnection.close();
        }
        catch(SQLException sqlexception) { }
    }

    protected int getCacheTimeToLiveTimeout()
    {
        return cacheTimeToLiveTimeout;
    }

    protected int getCacheInactivityTimeout()
    {
        return cacheInactivityTimeout;
    }

    protected int getCachePropertyCheckInterval()
    {
        return cachePropertyCheckInterval;
    }

    protected int getCacheAbandonedTimeout()
    {
        return cacheAbandonedConnectionTimeout;
    }

    private synchronized void processConnectionCacheCallback()
        throws SQLException
    {
        float f = (float)cacheMaxLimit / 100F;
        int i = (int)((float)cacheLowerThresholdLimit * f);
        releaseBasedOnPriority(1024, i);
        if(cacheSize < i)
            releaseBasedOnPriority(512, i);
    }

    private void releaseBasedOnPriority(int i, int j)
        throws SQLException
    {
        Object aobj[] = checkedOutConnectionList.toArray();
        for(int k = 0; k < aobj.length && cacheSize < j; k++)
        {
            OraclePooledConnection oraclepooledconnection = (OraclePooledConnection)aobj[k];
            OracleConnection oracleconnection = null;
            if(oraclepooledconnection != null)
                oracleconnection = (OracleConnection)(OracleConnection)oraclepooledconnection.getLogicalHandle();
            if(oracleconnection == null)
                continue;
            OracleConnectionCacheCallback oracleconnectioncachecallback = oracleconnection.getConnectionCacheCallbackObj();
            if(oracleconnectioncachecallback != null && (oracleconnection.getConnectionCacheCallbackFlag() == 2 || oracleconnection.getConnectionCacheCallbackFlag() == 4) && i == oracleconnection.getConnectionReleasePriority())
            {
                Object obj = oracleconnection.getConnectionCacheCallbackPrivObj();
                oracleconnectioncachecallback.releaseConnection(oracleconnection, obj);
            }
        }

    }

    private synchronized void processConnectionWaitTimeout(long l)
        throws SQLException
    {
        try
        {
            wait(l);
        }
        catch(InterruptedException interruptedexception) { }
    }

    private void processInactivityTimeout(OraclePooledConnection oraclepooledconnection)
        throws SQLException
    {
        long l = oraclepooledconnection.getLastAccessedTime();
        long l1 = System.currentTimeMillis();
        if(getTotalCachedConnections() > cacheMinLimit && l1 - l > (long)(cacheInactivityTimeout * 1000))
            closeAndRemovePooledConnection(oraclepooledconnection);
    }

    private void cleanupTimeoutThread()
        throws SQLException
    {
        if(timeoutThread != null)
        {
            timeoutThread.timeToLive = false;
            if(timeoutThread.isSleeping)
                timeoutThread.interrupt();
            timeoutThread = null;
        }
    }

    protected void purgeCacheConnections(boolean flag, int i)
    {
        try
        {
            if(flag)
                doForEveryCheckedOutConnection(i);
            doForEveryCachedConnection(i);
        }
        catch(SQLException sqlexception) { }
    }

    protected void updateDatabaseInstance(String s, String s1, int i, int j)
    {
        if(databaseInstancesList == null)
            databaseInstancesList = new LinkedList();
        synchronized(databaseInstancesList)
        {
            int k = databaseInstancesList.size();
            boolean flag = false;
            int l = 0;
            do
            {
                if(l >= k)
                    break;
                OracleDatabaseInstance oracledatabaseinstance1 = (OracleDatabaseInstance)databaseInstancesList.get(l);
                if(oracledatabaseinstance1.databaseUniqName == s && oracledatabaseinstance1.instanceName == s1)
                {
                    oracledatabaseinstance1.percent = i;
                    oracledatabaseinstance1.flag = j;
                    flag = true;
                    break;
                }
                l++;
            } while(true);
            if(!flag)
            {
                OracleDatabaseInstance oracledatabaseinstance = new OracleDatabaseInstance(s, s1);
                oracledatabaseinstance.percent = i;
                oracledatabaseinstance.flag = j;
                databaseInstancesList.add(oracledatabaseinstance);
            }
        }
    }

    protected void processDatabaseInstances()
        throws SQLException
    {
        Object obj = null;
        if(databaseInstancesList != null)
        {
            synchronized(databaseInstancesList)
            {
                int i = 0;
                boolean flag = false;
                useGoodGroup = false;
                int j = databaseInstancesList.size();
                for(int k = 0; k < j; k++)
                {
                    OracleDatabaseInstance oracledatabaseinstance = (OracleDatabaseInstance)databaseInstancesList.get(k);
                    if(oracledatabaseinstance.flag <= 3)
                        i += oracledatabaseinstance.percent;
                }

                if(i > 0)
                {
                    dbInstancePercentTotal = i;
                    useGoodGroup = true;
                }
                if(j > 1)
                {
                    for(int l = 0; l < j; l++)
                    {
                        OracleDatabaseInstance oracledatabaseinstance1 = (OracleDatabaseInstance)databaseInstancesList.get(l);
                        countTotal += oracledatabaseinstance1.attemptedConnRequestCount;
                    }

                    if(countTotal > j * 1000)
                    {
                        for(int i1 = 0; i1 < j; i1++)
                        {
                            OracleDatabaseInstance oracledatabaseinstance2 = (OracleDatabaseInstance)databaseInstancesList.get(i1);
                            float f = (float)oracledatabaseinstance2.attemptedConnRequestCount / (float)countTotal;
                            float f1 = (float)oracledatabaseinstance2.numberOfConnectionsCount / (float)getTotalCachedConnections();
                            if(f1 <= f * 2.0F)
                                continue;
                            if((int)((double)oracledatabaseinstance2.numberOfConnectionsCount * 0.25D) >= 1)
                                instancesToRetireQueue.addElement(oracledatabaseinstance2);
                            flag = true;
                        }

                        if(flag)
                        {
                            for(int j1 = 0; j1 < j; j1++)
                            {
                                OracleDatabaseInstance oracledatabaseinstance3 = (OracleDatabaseInstance)databaseInstancesList.get(j1);
                                oracledatabaseinstance3.attemptedConnRequestCount = 0;
                            }

                            boolean flag1 = false;
                        }
                    }
                }
            }
            if(instancesToRetireQueue.size() > 0)
            {
                if(gravitateCacheThread != null)
                {
                    try
                    {
                        gravitateCacheThread.interrupt();
                        gravitateCacheThread.join();
                    }
                    catch(InterruptedException interruptedexception) { }
                    gravitateCacheThread = null;
                }
                gravitateCacheThread = new OracleGravitateConnectionCacheThread(this);
                cacheManager.checkAndStartThread(gravitateCacheThread);
            }
        }
    }

    protected void gravitateCache()
    {
        do
        {
            if(instancesToRetireQueue.size() <= 0)
                break;
            instanceToRetire = (OracleDatabaseInstance)instancesToRetireQueue.remove(0);
            retireConnectionsCount = (int)((double)instanceToRetire.numberOfConnectionsCount * 0.25D);
            try
            {
                doForEveryCachedConnection(24);
            }
            catch(SQLException sqlexception) { }
            if(retireConnectionsCount > 0)
                try
                {
                    doForEveryCheckedOutConnection(24);
                }
                catch(SQLException sqlexception1) { }
        } while(true);
        retireConnectionsCount = 0;
        instanceToRetire = null;
        countTotal = 0;
    }

    protected void cleanupRLBThreads()
    {
        if(gravitateCacheThread != null)
        {
            try
            {
                gravitateCacheThread.interrupt();
                gravitateCacheThread.join();
            }
            catch(InterruptedException interruptedexception) { }
            gravitateCacheThread = null;
        }
        if(runtimeLoadBalancingThread != null)
        {
            try
            {
                runtimeLoadBalancingThread.interrupt();
            }
            catch(Exception exception) { }
            runtimeLoadBalancingThread = null;
        }
    }

    Map getStatistics()
        throws SQLException
    {
        HashMap hashmap = new HashMap(2);
        hashmap.put("PhysicalConnectionClosedCount", new Integer(connectionClosedCount));
        hashmap.put("PhysicalConnectionCreatedCount", new Integer(connectionCreatedCount));
        return hashmap;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
