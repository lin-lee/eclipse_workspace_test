// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConnectionCacheManager.java

package oracle.jdbc.pool;

import java.io.UnsupportedEncodingException;
import java.security.*;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import javax.sql.ConnectionPoolDataSource;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.ons.ONS;
import oracle.ons.ONSException;

// Referenced classes of package oracle.jdbc.pool:
//            OracleFailoverEventHandlerThread, OracleImplicitConnectionCache, OracleConnectionPoolDataSource, OracleFailoverWorkerThread, 
//            OracleDataSource

/**
 * @deprecated Class OracleConnectionCacheManager is deprecated
 */

public class OracleConnectionCacheManager
{

    private static OracleConnectionCacheManager cacheManagerInstance = null;
    protected Hashtable m_connCache;
    public static final int REFRESH_INVALID_CONNECTIONS = 4096;
    public static final int REFRESH_ALL_CONNECTIONS = 8192;
    public static final String PHYSICAL_CONNECTION_CREATED_COUNT = "PhysicalConnectionCreatedCount";
    public static final String PHYSICAL_CONNECTION_CLOSED_COUNT = "PhysicalConnectionClosedCount";
    protected static final int FAILOVER_EVENT_TYPE_SERVICE = 256;
    protected static final int FAILOVER_EVENT_TYPE_HOST = 512;
    protected static final String EVENT_DELIMITER = "{} =";
    protected OracleFailoverEventHandlerThread failoverEventHandlerThread;
    private static boolean isONSInitializedForRemoteSubscription = false;
    static final int ORAERROR_END_OF_FILE_ON_COM_CHANNEL = 3113;
    static final int ORAERROR_NOT_CONNECTED_TO_ORACLE = 3114;
    static final int ORAERROR_INIT_SHUTDOWN_IN_PROGRESS = 1033;
    static final int ORAERROR_ORACLE_NOT_AVAILABLE = 1034;
    static final int ORAERROR_IMMEDIATE_SHUTDOWN_IN_PROGRESS = 1089;
    static final int ORAERROR_SHUTDOWN_IN_PROGRESS_NO_CONN = 1090;
    static final int ORAERROR_NET_IO_EXCEPTION = 17002;
    protected int fatalErrorCodes[];
    protected int failoverEnabledCacheCount;
    protected static AtomicInteger UNNAMED_CACHE_COUNT;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    private OracleConnectionCacheManager()
    {
        m_connCache = null;
        failoverEventHandlerThread = null;
        fatalErrorCodes = null;
        failoverEnabledCacheCount = 0;
        m_connCache = new Hashtable();
        UNNAMED_CACHE_COUNT = new AtomicInteger();
    }

    /**
     * @deprecated Method getConnectionCacheManagerInstance is deprecated
     */

    public static synchronized OracleConnectionCacheManager getConnectionCacheManagerInstance()
        throws SQLException
    {
        try
        {
            if(cacheManagerInstance == null)
                cacheManagerInstance = new OracleConnectionCacheManager();
        }
        catch(RuntimeException runtimeexception) { }
        return cacheManagerInstance;
    }

    /**
     * @deprecated Method createCache is deprecated
     */

    public String createCache(OracleDataSource oracledatasource, Properties properties)
        throws SQLException
    {
        String s = null;
        if(oracledatasource == null || !oracledatasource.getConnectionCachingEnabled())
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 137);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(oracledatasource.connCacheName != null)
            s = oracledatasource.connCacheName;
        else
            s = (new StringBuilder()).append(oracledatasource.dataSourceName).append("#0x").append(Integer.toHexString(UNNAMED_CACHE_COUNT.getAndIncrement())).toString();
        createCache(s, oracledatasource, properties);
        return s;
    }

    /**
     * @deprecated Method createCache is deprecated
     */

    public void createCache(String s, OracleDataSource oracledatasource, Properties properties)
        throws SQLException
    {
        if(oracledatasource == null || !oracledatasource.getConnectionCachingEnabled())
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 137);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(s == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 138);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        if(m_connCache.containsKey(s))
        {
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 140);
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        boolean flag = oracledatasource.getFastConnectionFailoverEnabled();
        if(flag && failoverEventHandlerThread == null)
        {
            final String onsConfigStr = oracledatasource.getONSConfiguration();
            if(onsConfigStr != null && !onsConfigStr.equals(""))
                synchronized(this)
                {
                    if(!isONSInitializedForRemoteSubscription)
                    {
                        try
                        {
                            AccessController.doPrivileged(new PrivilegedExceptionAction() {

                                final String val$onsConfigStr;
                                final OracleConnectionCacheManager this$0;

                                public Object run()
                                    throws ONSException
                                {
                                    ONS ons = new ONS(onsConfigStr);
                                    return null;
                                }

            
            {
                this$0 = OracleConnectionCacheManager.this;
                onsConfigStr = s;
                super();
            }
                            }
);
                        }
                        catch(PrivilegedActionException privilegedactionexception)
                        {
                            SQLException sqlexception3 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 175, privilegedactionexception);
                            sqlexception3.fillInStackTrace();
                            throw sqlexception3;
                        }
                        isONSInitializedForRemoteSubscription = true;
                    }
                }
            failoverEventHandlerThread = new OracleFailoverEventHandlerThread();
        }
        OracleImplicitConnectionCache oracleimplicitconnectioncache = new OracleImplicitConnectionCache(oracledatasource, properties);
        oracleimplicitconnectioncache.cacheName = s;
        oracledatasource.odsCache = oracleimplicitconnectioncache;
        m_connCache.put(s, oracleimplicitconnectioncache);
        if(flag)
            checkAndStartThread(failoverEventHandlerThread);
    }

    /**
     * @deprecated Method removeCache is deprecated
     */

    public void removeCache(String s, long l)
        throws SQLException
    {
        OracleImplicitConnectionCache oracleimplicitconnectioncache = s == null ? null : (OracleImplicitConnectionCache)(OracleImplicitConnectionCache)m_connCache.remove(s);
        if(oracleimplicitconnectioncache != null)
        {
            oracleimplicitconnectioncache.disableConnectionCache();
            if(l > 0L)
                try
                {
                    Thread.currentThread();
                    Thread.sleep(l * 1000L);
                }
                catch(InterruptedException interruptedexception) { }
            if(oracleimplicitconnectioncache.cacheEnabledDS.getFastConnectionFailoverEnabled())
                cleanupFCFThreads(oracleimplicitconnectioncache);
            oracleimplicitconnectioncache.closeConnectionCache(l >= 0L ? 1 : 32);
            oracleimplicitconnectioncache = null;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    /**
     * @deprecated Method reinitializeCache is deprecated
     */

    public void reinitializeCache(String s, Properties properties)
        throws SQLException
    {
        OracleImplicitConnectionCache oracleimplicitconnectioncache = s == null ? null : (OracleImplicitConnectionCache)(OracleImplicitConnectionCache)m_connCache.get(s);
        if(oracleimplicitconnectioncache != null)
        {
            disableCache(s);
            oracleimplicitconnectioncache.reinitializeCacheConnections(properties);
            enableCache(s);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    /**
     * @deprecated Method existsCache is deprecated
     */

    public boolean existsCache(String s)
        throws SQLException
    {
        return m_connCache.containsKey(s);
    }

    /**
     * @deprecated Method enableCache is deprecated
     */

    public void enableCache(String s)
        throws SQLException
    {
        OracleImplicitConnectionCache oracleimplicitconnectioncache = s == null ? null : (OracleImplicitConnectionCache)(OracleImplicitConnectionCache)m_connCache.get(s);
        if(oracleimplicitconnectioncache != null)
        {
            oracleimplicitconnectioncache.enableConnectionCache();
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    /**
     * @deprecated Method disableCache is deprecated
     */

    public void disableCache(String s)
        throws SQLException
    {
        OracleImplicitConnectionCache oracleimplicitconnectioncache = s == null ? null : (OracleImplicitConnectionCache)(OracleImplicitConnectionCache)m_connCache.get(s);
        if(oracleimplicitconnectioncache != null)
        {
            oracleimplicitconnectioncache.disableConnectionCache();
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    /**
     * @deprecated Method refreshCache is deprecated
     */

    public void refreshCache(String s, int i)
        throws SQLException
    {
        OracleImplicitConnectionCache oracleimplicitconnectioncache = s == null ? null : (OracleImplicitConnectionCache)(OracleImplicitConnectionCache)m_connCache.get(s);
        if(oracleimplicitconnectioncache != null)
        {
            switch(i)
            {
            case 4096: 
            case 8192: 
                oracleimplicitconnectioncache.refreshCacheConnections(i);
                break;

            default:
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        } else
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    /**
     * @deprecated Method purgeCache is deprecated
     */

    public void purgeCache(String s, boolean flag)
        throws SQLException
    {
        OracleImplicitConnectionCache oracleimplicitconnectioncache = s == null ? null : (OracleImplicitConnectionCache)(OracleImplicitConnectionCache)m_connCache.get(s);
        if(oracleimplicitconnectioncache != null)
        {
            oracleimplicitconnectioncache.purgeCacheConnections(flag, 1);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    /**
     * @deprecated Method getCacheProperties is deprecated
     */

    public Properties getCacheProperties(String s)
        throws SQLException
    {
        OracleImplicitConnectionCache oracleimplicitconnectioncache = s == null ? null : (OracleImplicitConnectionCache)(OracleImplicitConnectionCache)m_connCache.get(s);
        if(oracleimplicitconnectioncache != null)
        {
            return oracleimplicitconnectioncache.getConnectionCacheProperties();
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    /**
     * @deprecated Method getCacheNameList is deprecated
     */

    public String[] getCacheNameList()
        throws SQLException
    {
        String as[] = (String[])(String[])m_connCache.keySet().toArray(new String[m_connCache.size()]);
        return as;
    }

    /**
     * @deprecated Method getNumberOfAvailableConnections is deprecated
     */

    public int getNumberOfAvailableConnections(String s)
        throws SQLException
    {
        OracleImplicitConnectionCache oracleimplicitconnectioncache = s == null ? null : (OracleImplicitConnectionCache)(OracleImplicitConnectionCache)m_connCache.get(s);
        if(oracleimplicitconnectioncache != null)
        {
            return oracleimplicitconnectioncache.cacheSize;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    /**
     * @deprecated Method getNumberOfActiveConnections is deprecated
     */

    public int getNumberOfActiveConnections(String s)
        throws SQLException
    {
        OracleImplicitConnectionCache oracleimplicitconnectioncache = s == null ? null : (OracleImplicitConnectionCache)(OracleImplicitConnectionCache)m_connCache.get(s);
        if(oracleimplicitconnectioncache != null)
        {
            return oracleimplicitconnectioncache.getNumberOfCheckedOutConnections();
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    /**
     * @deprecated Method setConnectionPoolDataSource is deprecated
     */

    public synchronized void setConnectionPoolDataSource(String s, ConnectionPoolDataSource connectionpooldatasource)
        throws SQLException
    {
        OracleImplicitConnectionCache oracleimplicitconnectioncache = s == null ? null : (OracleImplicitConnectionCache)(OracleImplicitConnectionCache)m_connCache.get(s);
        if(oracleimplicitconnectioncache != null)
        {
            if(oracleimplicitconnectioncache.cacheSize > 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 78);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            ((OracleConnectionPoolDataSource)connectionpooldatasource).makeURL();
            ((OracleConnectionPoolDataSource)connectionpooldatasource).setURL(((OracleConnectionPoolDataSource)connectionpooldatasource).url);
            oracleimplicitconnectioncache.connectionPoolDS = (OracleConnectionPoolDataSource)connectionpooldatasource;
        } else
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 141);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
    }

    protected void verifyAndHandleEvent(int i, byte abyte0[])
        throws SQLException
    {
        String s = null;
        String s1 = null;
        String s2 = null;
        String s3 = null;
        String s4 = null;
        int j = 0;
        StringTokenizer stringtokenizer = null;
        try
        {
            stringtokenizer = new StringTokenizer(new String(abyte0, "UTF-8"), "{} =", true);
        }
        catch(UnsupportedEncodingException unsupportedencodingexception) { }
        Object obj = null;
        Object obj1 = null;
        String s7 = null;
        do
        {
            if(!stringtokenizer.hasMoreTokens())
                break;
            String s6 = null;
            String s5 = stringtokenizer.nextToken();
            if(s5.equals("=") && stringtokenizer.hasMoreTokens())
                s6 = stringtokenizer.nextToken();
            else
                s7 = s5;
            if(s7.equalsIgnoreCase("version") && s6 != null && !s6.equals("1.0"))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 146);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(s7.equalsIgnoreCase("service") && s6 != null)
                s = s6;
            if(s7.equalsIgnoreCase("instance") && s6 != null && !s6.equals(" "))
                s1 = s6.toLowerCase().intern();
            if(s7.equalsIgnoreCase("database") && s6 != null)
                s2 = s6.toLowerCase().intern();
            if(s7.equalsIgnoreCase("host") && s6 != null)
                s3 = s6.toLowerCase().intern();
            if(s7.equalsIgnoreCase("status") && s6 != null)
                s4 = s6;
            if(s7.equalsIgnoreCase("card") && s6 != null)
                try
                {
                    j = Integer.parseInt(s6);
                }
                catch(NumberFormatException numberformatexception) { }
        } while(true);
        invokeFailoverProcessingThreads(i, s, s1, s2, s3, s4, j);
        stringtokenizer = null;
    }

    private void invokeFailoverProcessingThreads(int i, String s, String s1, String s2, String s3, String s4, int j)
        throws SQLException
    {
        Object obj = null;
        boolean flag = false;
        boolean flag1 = false;
        if(i == 256)
            flag = true;
        if(i == 512)
            flag1 = true;
        Iterator iterator = m_connCache.values().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            OracleImplicitConnectionCache oracleimplicitconnectioncache = (OracleImplicitConnectionCache)iterator.next();
            if(flag && s.equalsIgnoreCase(oracleimplicitconnectioncache.dataSourceServiceName) || flag1)
            {
                OracleFailoverWorkerThread oraclefailoverworkerthread = new OracleFailoverWorkerThread(oracleimplicitconnectioncache, i, s1, s2, s3, s4, j);
                checkAndStartThread(oraclefailoverworkerthread);
                oracleimplicitconnectioncache.failoverWorkerThread = oraclefailoverworkerthread;
            }
        } while(true);
    }

    protected void checkAndStartThread(Thread thread)
        throws SQLException
    {
        try
        {
            if(!thread.isAlive())
            {
                thread.setDaemon(true);
                thread.start();
            }
        }
        catch(IllegalThreadStateException illegalthreadstateexception) { }
    }

    protected boolean failoverEnabledCacheExists()
    {
        return failoverEnabledCacheCount > 0;
    }

    protected void parseRuntimeLoadBalancingEvent(String s, byte abyte0[])
        throws SQLException
    {
        Object obj = null;
        Enumeration enumeration = m_connCache.elements();
        do
        {
            if(!enumeration.hasMoreElements())
                break;
            try
            {
                OracleImplicitConnectionCache oracleimplicitconnectioncache = (OracleImplicitConnectionCache)enumeration.nextElement();
                if(s.equalsIgnoreCase(oracleimplicitconnectioncache.dataSourceServiceName))
                    if(abyte0 == null)
                        oracleimplicitconnectioncache.zapRLBInfo();
                    else
                        retrieveServiceMetrics(oracleimplicitconnectioncache, abyte0);
            }
            catch(Exception exception) { }
        } while(true);
    }

    private void retrieveServiceMetrics(OracleImplicitConnectionCache oracleimplicitconnectioncache, byte abyte0[])
        throws SQLException
    {
        StringTokenizer stringtokenizer = null;
        String s = null;
        String s1 = null;
        int i = 0;
        int j = 0;
        boolean flag = false;
        try
        {
            stringtokenizer = new StringTokenizer(new String(abyte0, "UTF-8"), "{} =", true);
        }
        catch(UnsupportedEncodingException unsupportedencodingexception) { }
        Object obj = null;
        Object obj1 = null;
        String s4 = null;
        do
        {
            if(!stringtokenizer.hasMoreTokens())
                break;
            String s3 = null;
            String s2 = stringtokenizer.nextToken();
            if(s2.equals("=") && stringtokenizer.hasMoreTokens())
            {
                s3 = stringtokenizer.nextToken();
            } else
            {
                if(s2.equals("}"))
                {
                    if(flag)
                    {
                        oracleimplicitconnectioncache.updateDatabaseInstance(s1, s, i, j);
                        flag = false;
                    }
                    continue;
                }
                if(s2.equals("{") || s2.equals(" "))
                    continue;
                s4 = s2;
                flag = true;
            }
            if(s4.equalsIgnoreCase("version") && s3 != null && !s3.equals("1.0"))
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 146);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            if(s4.equalsIgnoreCase("database") && s3 != null)
                s1 = s3.toLowerCase().intern();
            if(s4.equalsIgnoreCase("instance") && s3 != null)
                s = s3.toLowerCase().intern();
            if(s4.equalsIgnoreCase("percent") && s3 != null)
                try
                {
                    i = Integer.parseInt(s3);
                    if(i == 0)
                        i = 1;
                }
                catch(NumberFormatException numberformatexception) { }
            if(s4.equalsIgnoreCase("flag") && s3 != null)
                if(s3.equalsIgnoreCase("good"))
                {
                    OracleImplicitConnectionCache _tmp = oracleimplicitconnectioncache;
                    j = 1;
                } else
                if(s3.equalsIgnoreCase("violating"))
                {
                    OracleImplicitConnectionCache _tmp1 = oracleimplicitconnectioncache;
                    j = 3;
                } else
                if(s3.equalsIgnoreCase("NO_DATA"))
                {
                    OracleImplicitConnectionCache _tmp2 = oracleimplicitconnectioncache;
                    j = 4;
                } else
                if(s3.equalsIgnoreCase("UNKNOWN"))
                {
                    OracleImplicitConnectionCache _tmp3 = oracleimplicitconnectioncache;
                    j = 2;
                } else
                if(s3.equalsIgnoreCase("BLOCKED"))
                {
                    OracleImplicitConnectionCache _tmp4 = oracleimplicitconnectioncache;
                    j = 5;
                }
        } while(true);
        oracleimplicitconnectioncache.processDatabaseInstances();
    }

    protected void cleanupFCFThreads(OracleImplicitConnectionCache oracleimplicitconnectioncache)
        throws SQLException
    {
        cleanupFCFWorkerThread(oracleimplicitconnectioncache);
        oracleimplicitconnectioncache.cleanupRLBThreads();
        if(failoverEnabledCacheCount <= 0)
            cleanupFCFEventHandlerThread();
        failoverEnabledCacheCount--;
    }

    protected void cleanupFCFWorkerThread(OracleImplicitConnectionCache oracleimplicitconnectioncache)
        throws SQLException
    {
        if(oracleimplicitconnectioncache.failoverWorkerThread != null)
        {
            try
            {
                if(oracleimplicitconnectioncache.failoverWorkerThread.isAlive())
                    oracleimplicitconnectioncache.failoverWorkerThread.join();
            }
            catch(InterruptedException interruptedexception) { }
            oracleimplicitconnectioncache.failoverWorkerThread = null;
        }
    }

    protected void cleanupFCFEventHandlerThread()
        throws SQLException
    {
        if(failoverEventHandlerThread != null)
        {
            try
            {
                failoverEventHandlerThread.interrupt();
            }
            catch(Exception exception) { }
            failoverEventHandlerThread = null;
        }
    }

    public boolean isFatalConnectionError(SQLException sqlexception)
    {
        boolean flag = false;
        int i = sqlexception.getErrorCode();
        if(i == 3113 || i == 3114 || i == 1033 || i == 1034 || i == 1089 || i == 1090 || i == 17002)
            flag = true;
        if(!flag && fatalErrorCodes != null)
        {
            int j = 0;
            do
            {
                if(j >= fatalErrorCodes.length)
                    break;
                if(i == fatalErrorCodes[j])
                {
                    flag = true;
                    break;
                }
                j++;
            } while(true);
        }
        return flag;
    }

    public synchronized void setConnectionErrorCodes(int ai[])
        throws SQLException
    {
        if(ai != null)
            fatalErrorCodes = ai;
    }

    public int[] getConnectionErrorCodes()
        throws SQLException
    {
        return fatalErrorCodes;
    }

    /**
     * @deprecated Method getStatistics is deprecated
     */

    public Map getStatistics(String s)
        throws SQLException
    {
        Map map = null;
        OracleImplicitConnectionCache oracleimplicitconnectioncache = null;
        if(m_connCache != null && (oracleimplicitconnectioncache = (OracleImplicitConnectionCache)m_connCache.get(s)) != null)
            map = oracleimplicitconnectioncache.getStatistics();
        return map;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
