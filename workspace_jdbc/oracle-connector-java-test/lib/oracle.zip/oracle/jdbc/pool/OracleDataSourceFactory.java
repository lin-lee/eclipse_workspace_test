// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDataSourceFactory.java

package oracle.jdbc.pool;

import java.sql.SQLException;
import java.util.*;
import javax.naming.*;
import javax.naming.spi.ObjectFactory;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.xa.client.OracleXADataSource;

// Referenced classes of package oracle.jdbc.pool:
//            OracleDataSource, OracleConnectionPoolDataSource, OracleOCIConnectionPool

public class OracleDataSourceFactory
    implements ObjectFactory
{

    private static final String CONNECTION_CACHING_ENABLED = "connectionCachingEnabled";
    private static final String CONNECTION_CACHE_NAME = "connectionCacheName";
    private static final String CONNECTION_CACHE_PROPERTIES = "connectionCacheProperties";
    private static final String CONNECTION_PROPERTIES = "connectionProperties";
    private static final String FAST_CONNECTION_FAILOVER_ENABLED = "fastConnectionFailoverEnabled";
    private static final String ONS_CONFIG_STR = "onsConfigStr";
    private static final String ORACLE_CONN_DATA_POOL_SOURCE = "oracle.jdbc.pool.OracleConnectionPoolDataSource";
    private static final String ORACLE_OCI_CONN_POOL = "oracle.jdbc.pool.OracleOCIConnectionPool";
    private static final String ORACLE_DATA_SOURCE = "oracle.jdbc.pool.OracleDataSource";
    private static final String ORACLE_XA_DATA_SOURCE = "oracle.jdbc.xa.client.OracleXADataSource";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleDataSourceFactory()
    {
    }

    public Object getObjectInstance(Object obj, Name name, Context context, Hashtable hashtable)
        throws Exception
    {
        Reference reference = (Reference)obj;
        Object obj1 = null;
        String s = reference.getClassName();
        Properties properties = new Properties();
        if(s.equals("oracle.jdbc.pool.OracleDataSource") || s.equals("oracle.jdbc.xa.client.OracleXADataSource"))
        {
            if(s.equals("oracle.jdbc.pool.OracleDataSource"))
                obj1 = new OracleDataSource();
            else
                obj1 = new OracleXADataSource();
            StringRefAddr stringrefaddr = null;
            if((stringrefaddr = (StringRefAddr)reference.get("connectionCachingEnabled")) != null)
            {
                String s2 = (String)stringrefaddr.getContent();
                if(s2.equals(String.valueOf("true")))
                    ((OracleDataSource) (obj1)).setConnectionCachingEnabled(true);
            }
            if((stringrefaddr = (StringRefAddr)reference.get("connectionCacheName")) != null)
                ((OracleDataSource) (obj1)).setConnectionCacheName((String)stringrefaddr.getContent());
            if((stringrefaddr = (StringRefAddr)reference.get("connectionCacheProperties")) != null)
            {
                String s3 = (String)stringrefaddr.getContent();
                Properties properties1 = extractConnectionCacheProperties(s3);
                ((OracleDataSource) (obj1)).setConnectionCacheProperties(properties1);
            }
            if((stringrefaddr = (StringRefAddr)reference.get("connectionProperties")) != null)
            {
                String s4 = (String)stringrefaddr.getContent();
                Properties properties2 = extractConnectionProperties(s4);
                ((OracleDataSource) (obj1)).setConnectionProperties(properties2);
            }
            if((stringrefaddr = (StringRefAddr)reference.get("fastConnectionFailoverEnabled")) != null)
            {
                String s5 = (String)stringrefaddr.getContent();
                if(s5.equals(String.valueOf("true")))
                    ((OracleDataSource) (obj1)).setFastConnectionFailoverEnabled(true);
            }
            if((stringrefaddr = (StringRefAddr)reference.get("onsConfigStr")) != null)
                ((OracleDataSource) (obj1)).setONSConfiguration((String)stringrefaddr.getContent());
        } else
        if(s.equals("oracle.jdbc.pool.OracleConnectionPoolDataSource"))
            obj1 = new OracleConnectionPoolDataSource();
        else
        if(s.equals("oracle.jdbc.pool.OracleOCIConnectionPool"))
        {
            obj1 = new OracleOCIConnectionPool();
            String s1 = null;
            String s6 = null;
            String s9 = null;
            String s10 = null;
            String s11 = null;
            String s12 = null;
            String s13 = null;
            StringRefAddr stringrefaddr3 = null;
            Object obj2 = null;
            String s14 = null;
            if((stringrefaddr3 = (StringRefAddr)reference.get("connpool_min_limit")) != null)
                s1 = (String)stringrefaddr3.getContent();
            if((stringrefaddr3 = (StringRefAddr)reference.get("connpool_max_limit")) != null)
                s6 = (String)stringrefaddr3.getContent();
            if((stringrefaddr3 = (StringRefAddr)reference.get("connpool_increment")) != null)
                s9 = (String)stringrefaddr3.getContent();
            if((stringrefaddr3 = (StringRefAddr)reference.get("connpool_active_size")) != null)
                s10 = (String)stringrefaddr3.getContent();
            if((stringrefaddr3 = (StringRefAddr)reference.get("connpool_pool_size")) != null)
                s11 = (String)stringrefaddr3.getContent();
            if((stringrefaddr3 = (StringRefAddr)reference.get("connpool_timeout")) != null)
                s12 = (String)stringrefaddr3.getContent();
            if((stringrefaddr3 = (StringRefAddr)reference.get("connpool_nowait")) != null)
                s13 = (String)stringrefaddr3.getContent();
            if((stringrefaddr3 = (StringRefAddr)reference.get("transactions_distributed")) != null)
                s14 = (String)stringrefaddr3.getContent();
            properties.put("connpool_min_limit", s1);
            properties.put("connpool_max_limit", s6);
            properties.put("connpool_increment", s9);
            properties.put("connpool_active_size", s10);
            properties.put("connpool_pool_size", s11);
            properties.put("connpool_timeout", s12);
            if(s13 == "true")
                properties.put("connpool_nowait", s13);
            if(s14 == "true")
                properties.put("transactions_distributed", s14);
        } else
        {
            return null;
        }
        if(obj1 != null)
        {
            StringRefAddr stringrefaddr1 = null;
            if((stringrefaddr1 = (StringRefAddr)reference.get("url")) != null)
                ((OracleDataSource) (obj1)).setURL((String)stringrefaddr1.getContent());
            if((stringrefaddr1 = (StringRefAddr)reference.get("userName")) != null || (stringrefaddr1 = (StringRefAddr)reference.get("u")) != null || (stringrefaddr1 = (StringRefAddr)reference.get("user")) != null)
                ((OracleDataSource) (obj1)).setUser((String)stringrefaddr1.getContent());
            if((stringrefaddr1 = (StringRefAddr)reference.get("passWord")) != null || (stringrefaddr1 = (StringRefAddr)reference.get("password")) != null)
                ((OracleDataSource) (obj1)).setPassword((String)stringrefaddr1.getContent());
            if((stringrefaddr1 = (StringRefAddr)reference.get("description")) != null || (stringrefaddr1 = (StringRefAddr)reference.get("describe")) != null)
                ((OracleDataSource) (obj1)).setDescription((String)stringrefaddr1.getContent());
            if((stringrefaddr1 = (StringRefAddr)reference.get("driverType")) != null || (stringrefaddr1 = (StringRefAddr)reference.get("driver")) != null)
                ((OracleDataSource) (obj1)).setDriverType((String)stringrefaddr1.getContent());
            if((stringrefaddr1 = (StringRefAddr)reference.get("serverName")) != null || (stringrefaddr1 = (StringRefAddr)reference.get("host")) != null)
                ((OracleDataSource) (obj1)).setServerName((String)stringrefaddr1.getContent());
            if((stringrefaddr1 = (StringRefAddr)reference.get("databaseName")) != null || (stringrefaddr1 = (StringRefAddr)reference.get("sid")) != null)
                ((OracleDataSource) (obj1)).setDatabaseName((String)stringrefaddr1.getContent());
            if((stringrefaddr1 = (StringRefAddr)reference.get("serviceName")) != null)
                ((OracleDataSource) (obj1)).setServiceName((String)stringrefaddr1.getContent());
            if((stringrefaddr1 = (StringRefAddr)reference.get("networkProtocol")) != null || (stringrefaddr1 = (StringRefAddr)reference.get("protocol")) != null)
                ((OracleDataSource) (obj1)).setNetworkProtocol((String)stringrefaddr1.getContent());
            if((stringrefaddr1 = (StringRefAddr)reference.get("portNumber")) != null || (stringrefaddr1 = (StringRefAddr)reference.get("port")) != null)
            {
                String s7 = (String)stringrefaddr1.getContent();
                ((OracleDataSource) (obj1)).setPortNumber(Integer.parseInt(s7));
            }
            if((stringrefaddr1 = (StringRefAddr)reference.get("tnsentryname")) != null || (stringrefaddr1 = (StringRefAddr)reference.get("tns")) != null)
                ((OracleDataSource) (obj1)).setTNSEntryName((String)stringrefaddr1.getContent());
            else
            if(s.equals("oracle.jdbc.pool.OracleOCIConnectionPool"))
            {
                String s8 = null;
                StringRefAddr stringrefaddr2;
                if((stringrefaddr2 = (StringRefAddr)reference.get("connpool_is_poolcreated")) != null)
                    s8 = (String)stringrefaddr2.getContent();
                if(s8.equals(String.valueOf("true")))
                    ((OracleOCIConnectionPool)obj1).setPoolConfig(properties);
            }
        }
        return obj1;
    }

    private Properties extractConnectionCacheProperties(String s)
        throws SQLException
    {
        Properties properties = new Properties();
        s = s.substring(1, s.length() - 1);
        int i = s.indexOf("AttributeWeights", 0);
        if(i >= 0)
        {
            if(s.charAt(i + 16) != '=' || i > 0 && s.charAt(i - 1) != ' ')
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 139);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            Properties properties1 = new Properties();
            int j = s.indexOf("}", i);
            String s1 = s.substring(i, j);
            String s3 = s1.substring(18);
            StringTokenizer stringtokenizer2 = new StringTokenizer(s3, ", ");
            synchronized(stringtokenizer2)
            {
                String s9;
                String s10;
                for(; stringtokenizer2.hasMoreTokens(); properties1.setProperty(s9, s10))
                {
                    String s6 = stringtokenizer2.nextToken();
                    int i1 = s6.length();
                    int j1 = s6.indexOf("=");
                    s9 = s6.substring(0, j1);
                    s10 = s6.substring(j1 + 1, i1);
                }

            }
            properties.put("AttributeWeights", properties1);
            if(i > 0 && j + 1 == s.length())
                s = s.substring(0, i - 2);
            else
            if(i > 0 && j + 1 < s.length())
            {
                String s4 = s.substring(0, i - 2);
                String s7 = s.substring(j + 1, s.length());
                s = s4.concat(s7);
            } else
            {
                s = s.substring(j + 2, s.length());
            }
        }
        StringTokenizer stringtokenizer = new StringTokenizer(s, ", ");
        synchronized(stringtokenizer)
        {
            String s5;
            String s8;
            for(; stringtokenizer.hasMoreTokens(); properties.setProperty(s5, s8))
            {
                String s2 = stringtokenizer.nextToken();
                int k = s2.length();
                int l = s2.indexOf("=");
                s5 = s2.substring(0, l);
                s8 = s2.substring(l + 1, k);
            }

        }
        return properties;
    }

    private Properties extractConnectionProperties(String s)
        throws SQLException
    {
        Properties properties = new Properties();
        s = s.substring(1, s.length() - 1);
        String as[] = s.split(";");
        String as1[] = as;
        int i = as1.length;
        for(int j = 0; j < i; j++)
        {
            String s1 = as1[j];
            int k = s1.length();
            int l = s1.indexOf("=");
            if(k == 0 || l <= 0)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            String s2 = s1.substring(0, l);
            String s3 = s1.substring(l + 1, k);
            properties.setProperty(s2.trim(), s3.trim());
        }

        return properties;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
