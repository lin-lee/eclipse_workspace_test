// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleFailoverWorkerThread.java

package oracle.jdbc.pool;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.pool:
//            OracleImplicitConnectionCache

/**
 * @deprecated Class OracleFailoverWorkerThread is deprecated
 */

class OracleFailoverWorkerThread extends Thread
{

    protected OracleImplicitConnectionCache implicitCache;
    protected int eventType;
    protected String eventServiceName;
    protected String instanceNameKey;
    protected String databaseNameKey;
    protected String hostNameKey;
    protected String status;
    protected int cardinality;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleFailoverWorkerThread(OracleImplicitConnectionCache oracleimplicitconnectioncache, int i, String s, String s1, String s2, String s3, int j)
        throws SQLException
    {
        implicitCache = null;
        eventType = 0;
        eventServiceName = null;
        instanceNameKey = null;
        databaseNameKey = null;
        hostNameKey = null;
        status = null;
        cardinality = 0;
        implicitCache = oracleimplicitconnectioncache;
        eventType = i;
        instanceNameKey = s;
        databaseNameKey = s1;
        hostNameKey = s2;
        status = s3;
        cardinality = j;
    }

    public void run()
    {
        try
        {
            if(status != null)
                implicitCache.processFailoverEvent(eventType, instanceNameKey, databaseNameKey, hostNameKey, status, cardinality);
        }
        catch(Exception exception) { }
    }

}
