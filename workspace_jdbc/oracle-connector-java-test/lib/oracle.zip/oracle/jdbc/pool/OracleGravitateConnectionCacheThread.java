// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleGravitateConnectionCacheThread.java

package oracle.jdbc.pool;

import java.sql.SQLException;

// Referenced classes of package oracle.jdbc.pool:
//            OracleImplicitConnectionCache

/**
 * @deprecated Class OracleGravitateConnectionCacheThread is deprecated
 */

class OracleGravitateConnectionCacheThread extends Thread
{

    protected OracleImplicitConnectionCache implicitCache;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleGravitateConnectionCacheThread(OracleImplicitConnectionCache oracleimplicitconnectioncache)
        throws SQLException
    {
        implicitCache = null;
        implicitCache = oracleimplicitconnectioncache;
    }

    public void run()
    {
        implicitCache.gravitateCache();
    }

}
