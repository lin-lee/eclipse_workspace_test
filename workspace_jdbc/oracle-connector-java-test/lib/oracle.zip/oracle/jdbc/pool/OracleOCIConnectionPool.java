// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleOCIConnectionPool.java

package oracle.jdbc.pool;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;
import javax.naming.*;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.driver.OracleDriver;
import oracle.jdbc.internal.OracleConnection;
import oracle.jdbc.oci.OracleOCIConnection;

// Referenced classes of package oracle.jdbc.pool:
//            OracleDataSource

public class OracleOCIConnectionPool extends OracleDataSource
{
    private static final class Lifecycle extends Enum
    {

        public static final Lifecycle NEW;
        public static final Lifecycle OPEN;
        public static final Lifecycle CLOSING;
        public static final Lifecycle CLOSED;
        private static final Lifecycle $VALUES[];

        public static Lifecycle[] values()
        {
            return (Lifecycle[])$VALUES.clone();
        }

        public static Lifecycle valueOf(String s)
        {
            return (Lifecycle)Enum.valueOf(oracle/jdbc/pool/OracleOCIConnectionPool$Lifecycle, s);
        }

        static 
        {
            NEW = new Lifecycle("NEW", 0);
            OPEN = new Lifecycle("OPEN", 1);
            CLOSING = new Lifecycle("CLOSING", 2);
            CLOSED = new Lifecycle("CLOSED", 3);
            $VALUES = (new Lifecycle[] {
                NEW, OPEN, CLOSING, CLOSED
            });
        }

        private Lifecycle(String s, int i)
        {
            super(s, i);
        }
    }


    public OracleOCIConnection m_connection_pool;
    public static final String IS_CONNECTION_POOLING = "is_connection_pooling";
    private int m_conn_min_limit;
    private int m_conn_max_limit;
    private int m_conn_increment;
    private int m_conn_active_size;
    private int m_conn_pool_size;
    private int m_conn_timeout;
    private String m_conn_nowait;
    private int m_is_transactions_distributed;
    public static final String CONNPOOL_OBJECT = "connpool_object";
    public static final String CONNPOOL_LOGON_MODE = "connection_pool";
    public static final String CONNECTION_POOL = "connection_pool";
    public static final String CONNPOOL_CONNECTION = "connpool_connection";
    public static final String CONNPOOL_PROXY_CONNECTION = "connpool_proxy_connection";
    public static final String CONNPOOL_ALIASED_CONNECTION = "connpool_alias_connection";
    public static final String PROXY_USER_NAME = "proxy_user_name";
    public static final String PROXY_DISTINGUISHED_NAME = "proxy_distinguished_name";
    public static final String PROXY_CERTIFICATE = "proxy_certificate";
    public static final String PROXY_ROLES = "proxy_roles";
    public static final String PROXY_NUM_ROLES = "proxy_num_roles";
    public static final String PROXY_PASSWORD = "proxy_password";
    public static final String PROXYTYPE = "proxytype";
    public static final String PROXYTYPE_USER_NAME = "proxytype_user_name";
    public static final String PROXYTYPE_DISTINGUISHED_NAME = "proxytype_distinguished_name";
    public static final String PROXYTYPE_CERTIFICATE = "proxytype_certificate";
    public static final String CONNECTION_ID = "connection_id";
    public static final String CONNPOOL_MIN_LIMIT = "connpool_min_limit";
    public static final String CONNPOOL_MAX_LIMIT = "connpool_max_limit";
    public static final String CONNPOOL_INCREMENT = "connpool_increment";
    public static final String CONNPOOL_ACTIVE_SIZE = "connpool_active_size";
    public static final String CONNPOOL_POOL_SIZE = "connpool_pool_size";
    public static final String CONNPOOL_TIMEOUT = "connpool_timeout";
    public static final String CONNPOOL_NOWAIT = "connpool_nowait";
    public static final String CONNPOOL_IS_POOLCREATED = "connpool_is_poolcreated";
    public static final String TRANSACTIONS_DISTRIBUTED = "transactions_distributed";
    private Hashtable m_lconnections;
    private Lifecycle lifecycle;
    private OracleDriver m_oracleDriver;
    protected int m_stmtCacheSize;
    protected boolean m_stmtClearMetaData;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    private void ensureOpen()
        throws SQLException
    {
        if(lifecycle == Lifecycle.NEW)
            createConnectionPool(null);
        if(lifecycle != Lifecycle.OPEN)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public OracleOCIConnectionPool(String s, String s1, String s2, Properties properties)
        throws SQLException
    {
        this();
        setURL(s2);
        setUser(s);
        setPassword(s1);
        createConnectionPool(properties);
    }

    /**
     * @deprecated Method OracleOCIConnectionPool is deprecated
     */

    public OracleOCIConnectionPool(String s, String s1, String s2)
        throws SQLException
    {
        this();
        setURL(s2);
        setUser(s);
        setPassword(s1);
        createConnectionPool(null);
    }

    public OracleOCIConnectionPool()
        throws SQLException
    {
        m_conn_min_limit = 0;
        m_conn_max_limit = 0;
        m_conn_increment = 0;
        m_conn_active_size = 0;
        m_conn_pool_size = 0;
        m_conn_timeout = 0;
        m_conn_nowait = "false";
        m_is_transactions_distributed = 0;
        m_lconnections = null;
        lifecycle = Lifecycle.NEW;
        m_oracleDriver = new OracleDriver();
        m_stmtCacheSize = 0;
        m_stmtClearMetaData = false;
        isOracleDataSource = false;
        m_lconnections = new Hashtable(10);
        setDriverType("oci8");
    }

    public synchronized Connection getConnection()
        throws SQLException
    {
        ensureOpen();
        Connection connection = getConnection(user, password);
        return connection;
    }

    public synchronized Connection getConnection(String s, String s1)
        throws SQLException
    {
        ensureOpen();
        Properties properties;
        if(connectionProperties != null)
            properties = new Properties(connectionProperties);
        else
            properties = new Properties();
        properties.put("is_connection_pooling", "true");
        properties.put("user", s);
        properties.put("password", s1);
        properties.put("connection_pool", "connpool_connection");
        properties.put("connpool_object", m_connection_pool);
        OracleOCIConnection oracleociconnection = (OracleOCIConnection)m_oracleDriver.connect(url, properties);
        if(oracleociconnection == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            oracleociconnection.setStmtCacheSize(m_stmtCacheSize, m_stmtClearMetaData);
            m_lconnections.put(oracleociconnection, oracleociconnection);
            oracleociconnection.setConnectionPool(this);
            return oracleociconnection;
        }
    }

    public synchronized Reference getReference()
        throws NamingException
    {
        Reference reference = new Reference(getClass().getName(), "oracle.jdbc.pool.OracleDataSourceFactory", null);
        super.addRefProperties(reference);
        reference.add(new StringRefAddr("connpool_min_limit", String.valueOf(m_conn_min_limit)));
        reference.add(new StringRefAddr("connpool_max_limit", String.valueOf(m_conn_max_limit)));
        reference.add(new StringRefAddr("connpool_increment", String.valueOf(m_conn_increment)));
        reference.add(new StringRefAddr("connpool_active_size", String.valueOf(m_conn_active_size)));
        reference.add(new StringRefAddr("connpool_pool_size", String.valueOf(m_conn_pool_size)));
        reference.add(new StringRefAddr("connpool_timeout", String.valueOf(m_conn_timeout)));
        reference.add(new StringRefAddr("connpool_nowait", m_conn_nowait));
        reference.add(new StringRefAddr("connpool_is_poolcreated", String.valueOf(isPoolCreated())));
        reference.add(new StringRefAddr("transactions_distributed", String.valueOf(isDistributedTransEnabled())));
        return reference;
    }

    public synchronized OracleConnection getProxyConnection(String s, Properties properties)
        throws SQLException
    {
        ensureOpen();
        if("proxytype_user_name".equals(s))
            properties.put("user", properties.getProperty("proxy_user_name"));
        else
        if("proxytype_distinguished_name".equals(s))
            properties.put("user", properties.getProperty("proxy_distinguished_name"));
        else
        if("proxytype_certificate".equals(s))
        {
            properties.put("user", String.valueOf(properties.getProperty("proxy_user_name")));
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 107, "null properties");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        properties.put("is_connection_pooling", "true");
        properties.put("proxytype", s);
        String as[];
        if((as = (String[])(String[])properties.get("proxy_roles")) != null)
            properties.put("proxy_num_roles", new Integer(as.length));
        else
            properties.put("proxy_num_roles", new Integer(0));
        properties.put("connection_pool", "connpool_proxy_connection");
        properties.put("connpool_object", m_connection_pool);
        OracleOCIConnection oracleociconnection = (OracleOCIConnection)m_oracleDriver.connect(url, properties);
        if(oracleociconnection == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        } else
        {
            oracleociconnection.setStmtCacheSize(m_stmtCacheSize, m_stmtClearMetaData);
            m_lconnections.put(oracleociconnection, oracleociconnection);
            oracleociconnection.setConnectionPool(this);
            return oracleociconnection;
        }
    }

    public synchronized OracleConnection getAliasedConnection(byte abyte0[])
        throws SQLException
    {
        ensureOpen();
        Properties properties = new Properties();
        properties.put("is_connection_pooling", "true");
        properties.put("connection_id", abyte0);
        properties.put("connection_pool", "connpool_alias_connection");
        properties.put("connpool_object", m_connection_pool);
        OracleOCIConnection oracleociconnection = (OracleOCIConnection)m_oracleDriver.connect(url, properties);
        if(oracleociconnection == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            oracleociconnection.setStmtCacheSize(m_stmtCacheSize, m_stmtClearMetaData);
            m_lconnections.put(oracleociconnection, oracleociconnection);
            oracleociconnection.setConnectionPool(this);
            return oracleociconnection;
        }
    }

    public synchronized void close()
        throws SQLException
    {
        if(lifecycle != Lifecycle.OPEN)
            return;
        lifecycle = Lifecycle.CLOSING;
        for(Iterator iterator = m_lconnections.values().iterator(); iterator.hasNext(); iterator.remove())
        {
            OracleOCIConnection oracleociconnection = (OracleOCIConnection)iterator.next();
            if(oracleociconnection != null && oracleociconnection != m_connection_pool)
                oracleociconnection.close();
        }

        m_connection_pool.close();
        lifecycle = Lifecycle.CLOSED;
    }

    public synchronized void setPoolConfig(Properties properties)
        throws SQLException
    {
        if(properties == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 106, "null properties");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(!isPoolCreated())
        {
            createConnectionPool(properties);
        } else
        {
            Properties properties1 = new Properties();
            checkPoolConfig(properties, properties1);
            int ai[] = new int[6];
            readPoolConfig(properties1, ai);
            m_connection_pool.setConnectionPoolInfo(ai[0], ai[1], ai[2], ai[3], ai[4], ai[5]);
        }
        storePoolProperties();
    }

    public static void readPoolConfig(int i, int j, int k, int l, boolean flag, boolean flag1, int ai[])
    {
        for(int i1 = 0; i1 < 6; i1++)
            ai[i1] = 0;

        ai[0] = i;
        ai[1] = j;
        ai[2] = k;
        ai[3] = l;
        if(flag)
            ai[4] = 1;
        if(flag1)
            ai[5] = 1;
    }

    public static void readPoolConfig(Properties properties, int ai[])
    {
        String s = properties.getProperty("connpool_min_limit");
        if(s != null)
            ai[0] = Integer.parseInt(s);
        s = properties.getProperty("connpool_max_limit");
        if(s != null)
            ai[1] = Integer.parseInt(s);
        s = properties.getProperty("connpool_increment");
        if(s != null)
            ai[2] = Integer.parseInt(s);
        s = properties.getProperty("connpool_timeout");
        if(s != null)
            ai[3] = Integer.parseInt(s);
        s = properties.getProperty("connpool_nowait");
        if(s != null && s.equalsIgnoreCase("true"))
            ai[4] = 1;
        s = properties.getProperty("transactions_distributed");
        if(s != null && s.equalsIgnoreCase("true"))
            ai[5] = 1;
    }

    private void checkPoolConfig(Properties properties, Properties properties1)
        throws SQLException
    {
        String s = (String)properties.get("transactions_distributed");
        String s1 = (String)properties.get("connpool_nowait");
        if(s != null && !s.equalsIgnoreCase("true") || s1 != null && !s1.equalsIgnoreCase("true") || properties.get("connpool_min_limit") == null || properties.get("connpool_max_limit") == null || properties.get("connpool_increment") == null || Integer.decode((String)properties.get("connpool_min_limit")).intValue() < 0 || Integer.decode((String)properties.get("connpool_max_limit")).intValue() < 0 || Integer.decode((String)properties.get("connpool_increment")).intValue() < 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 106, "");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        for(Enumeration enumeration = properties.propertyNames(); enumeration.hasMoreElements();)
        {
            String s2 = (String)enumeration.nextElement();
            String s3 = properties.getProperty(s2);
            if("transactions_distributed".equals(s2) || "connpool_nowait".equals(s2))
                properties1.put(s2, "true");
            else
                properties1.put(s2, s3);
        }

    }

    private synchronized void storePoolProperties()
        throws SQLException
    {
        Properties properties = getPoolConfig();
        m_conn_min_limit = Integer.decode(properties.getProperty("connpool_min_limit")).intValue();
        m_conn_max_limit = Integer.decode(properties.getProperty("connpool_max_limit")).intValue();
        m_conn_increment = Integer.decode(properties.getProperty("connpool_increment")).intValue();
        m_conn_active_size = Integer.decode(properties.getProperty("connpool_active_size")).intValue();
        m_conn_pool_size = Integer.decode(properties.getProperty("connpool_pool_size")).intValue();
        m_conn_timeout = Integer.decode(properties.getProperty("connpool_timeout")).intValue();
        m_conn_nowait = properties.getProperty("connpool_nowait");
    }

    public synchronized Properties getPoolConfig()
        throws SQLException
    {
        ensureOpen();
        Properties properties = m_connection_pool.getConnectionPoolInfo();
        properties.put("connpool_is_poolcreated", String.valueOf(isPoolCreated()));
        return properties;
    }

    public synchronized int getActiveSize()
        throws SQLException
    {
        ensureOpen();
        Properties properties = m_connection_pool.getConnectionPoolInfo();
        String s = properties.getProperty("connpool_active_size");
        int i = Integer.decode(s).intValue();
        return i;
    }

    public synchronized int getPoolSize()
        throws SQLException
    {
        ensureOpen();
        Properties properties = m_connection_pool.getConnectionPoolInfo();
        String s = properties.getProperty("connpool_pool_size");
        int i = Integer.decode(s).intValue();
        return i;
    }

    public synchronized int getTimeout()
        throws SQLException
    {
        ensureOpen();
        Properties properties = m_connection_pool.getConnectionPoolInfo();
        String s = properties.getProperty("connpool_timeout");
        int i = Integer.decode(s).intValue();
        return i;
    }

    public synchronized String getNoWait()
        throws SQLException
    {
        ensureOpen();
        Properties properties = m_connection_pool.getConnectionPoolInfo();
        return properties.getProperty("connpool_nowait");
    }

    public synchronized int getMinLimit()
        throws SQLException
    {
        ensureOpen();
        Properties properties = m_connection_pool.getConnectionPoolInfo();
        String s = properties.getProperty("connpool_min_limit");
        int i = Integer.decode(s).intValue();
        return i;
    }

    public synchronized int getMaxLimit()
        throws SQLException
    {
        ensureOpen();
        Properties properties = m_connection_pool.getConnectionPoolInfo();
        String s = properties.getProperty("connpool_max_limit");
        int i = Integer.decode(s).intValue();
        return i;
    }

    public synchronized int getConnectionIncrement()
        throws SQLException
    {
        ensureOpen();
        Properties properties = m_connection_pool.getConnectionPoolInfo();
        String s = properties.getProperty("connpool_increment");
        int i = Integer.decode(s).intValue();
        return i;
    }

    public synchronized boolean isDistributedTransEnabled()
    {
        return m_is_transactions_distributed == 1;
    }

    private void createConnectionPool(Properties properties)
        throws SQLException
    {
        if(lifecycle != Lifecycle.NEW)
            return;
        if(user == null || password == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 106, " ");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        Properties properties1 = new Properties();
        if(properties != null)
            checkPoolConfig(properties, properties1);
        properties1.put("is_connection_pooling", "true");
        properties1.put("user", user);
        properties1.put("password", password);
        properties1.put("connection_pool", "connection_pool");
        if(getURL() == null)
            makeURL();
        m_connection_pool = (OracleOCIConnection)m_oracleDriver.connect(url, properties1);
        if(m_connection_pool == null)
        {
            SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
            sqlexception1.fillInStackTrace();
            throw sqlexception1;
        }
        m_connection_pool.setConnectionPool(this);
        m_lconnections.put(m_connection_pool, m_connection_pool);
        lifecycle = Lifecycle.OPEN;
        storePoolProperties();
        if(properties != null && "true".equalsIgnoreCase(properties.getProperty("transactions_distributed")))
            m_is_transactions_distributed = 1;
    }

    public synchronized boolean isPoolCreated()
    {
        return lifecycle == Lifecycle.OPEN;
    }

    public synchronized void connectionClosed(OracleOCIConnection oracleociconnection)
        throws SQLException
    {
        if(lifecycle != Lifecycle.CLOSING && m_lconnections.remove(oracleociconnection) == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "internal OracleOCIConnectionPool error");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            return;
        }
    }

    public synchronized void setStmtCacheSize(int i)
        throws SQLException
    {
        setStmtCacheSize(i, false);
    }

    public synchronized void setStmtCacheSize(int i, boolean flag)
        throws SQLException
    {
        if(i < 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            m_stmtCacheSize = i;
            m_stmtClearMetaData = flag;
            return;
        }
    }

    public synchronized int getStmtCacheSize()
    {
        return m_stmtCacheSize;
    }

    public synchronized boolean isStmtCacheEnabled()
    {
        return m_stmtCacheSize > 0;
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
