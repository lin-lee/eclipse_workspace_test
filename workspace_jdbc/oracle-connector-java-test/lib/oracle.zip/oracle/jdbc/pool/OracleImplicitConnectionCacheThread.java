// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleImplicitConnectionCacheThread.java

package oracle.jdbc.pool;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Vector;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.pool:
//            OraclePooledConnection, OracleConnectionCacheCallback, OracleImplicitConnectionCache

/**
 * @deprecated Class OracleImplicitConnectionCacheThread is deprecated
 */

class OracleImplicitConnectionCacheThread extends Thread
{

    private OracleImplicitConnectionCache implicitCache;
    protected boolean timeToLive;
    protected boolean isSleeping;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleImplicitConnectionCacheThread(OracleImplicitConnectionCache oracleimplicitconnectioncache)
        throws SQLException
    {
        implicitCache = null;
        timeToLive = true;
        isSleeping = false;
        implicitCache = oracleimplicitconnectioncache;
    }

    public void run()
    {
        long l = 0L;
        long l1 = 0L;
        long l2 = 0L;
        do
        {
            if(!timeToLive)
                break;
            try
            {
                if(timeToLive && (l = implicitCache.getCacheTimeToLiveTimeout()) > 0L)
                    runTimeToLiveTimeout(l);
                if(timeToLive && (l1 = implicitCache.getCacheInactivityTimeout()) > 0L)
                    runInactivityTimeout();
                if(timeToLive && (l2 = implicitCache.getCacheAbandonedTimeout()) > 0L)
                    runAbandonedTimeout(l2);
                if(timeToLive)
                {
                    isSleeping = true;
                    try
                    {
                        sleep(implicitCache.getCachePropertyCheckInterval() * 1000);
                    }
                    catch(InterruptedException interruptedexception) { }
                    isSleeping = false;
                }
                if(implicitCache == null || l <= 0L && l1 <= 0L && l2 <= 0L)
                    timeToLive = false;
            }
            catch(SQLException sqlexception) { }
        } while(true);
    }

    private void runTimeToLiveTimeout(long l)
        throws SQLException
    {
        long l1 = 0L;
        long l3 = 0L;
        if(implicitCache.getNumberOfCheckedOutConnections() > 0)
        {
            Object obj = null;
            synchronized(implicitCache)
            {
                Object aobj[] = implicitCache.checkedOutConnectionList.toArray();
                int i = implicitCache.checkedOutConnectionList.size();
                for(int j = 0; j < i; j++)
                {
                    OraclePooledConnection oraclepooledconnection = (OraclePooledConnection)aobj[j];
                    Connection connection = oraclepooledconnection.getLogicalHandle();
                    if(connection == null)
                        continue;
                    long l4 = ((OracleConnection)connection).getStartTime();
                    long l2 = System.currentTimeMillis();
                    if(l2 - l4 <= l * 1000L)
                        continue;
                    try
                    {
                        implicitCache.closeCheckedOutConnection(oraclepooledconnection, true);
                    }
                    catch(SQLException sqlexception) { }
                }

            }
        }
    }

    private void runInactivityTimeout()
    {
        try
        {
            OracleImplicitConnectionCache _tmp = implicitCache;
            implicitCache.doForEveryCachedConnection(4);
        }
        catch(SQLException sqlexception) { }
    }

    private void runAbandonedTimeout(long l)
        throws SQLException
    {
        if(implicitCache.getNumberOfCheckedOutConnections() > 0)
        {
            Object obj = null;
            synchronized(implicitCache)
            {
                Object aobj[] = implicitCache.checkedOutConnectionList.toArray();
                for(int i = 0; i < aobj.length; i++)
                {
                    OraclePooledConnection oraclepooledconnection = (OraclePooledConnection)aobj[i];
                    OracleConnection oracleconnection = (OracleConnection)(OracleConnection)oraclepooledconnection.getLogicalHandle();
                    if(oracleconnection == null)
                        continue;
                    OracleConnectionCacheCallback oracleconnectioncachecallback = oracleconnection.getConnectionCacheCallbackObj();
                    if((long)(oracleconnection.getHeartbeatNoChangeCount() * implicitCache.getCachePropertyCheckInterval()) <= l)
                        continue;
                    try
                    {
                        boolean flag = true;
                        if(oracleconnectioncachecallback != null && (oracleconnection.getConnectionCacheCallbackFlag() == 4 || oracleconnection.getConnectionCacheCallbackFlag() == 1))
                            flag = oracleconnectioncachecallback.handleAbandonedConnection(oracleconnection, oracleconnection.getConnectionCacheCallbackPrivObj());
                        if(flag)
                        {
                            implicitCache.closeCheckedOutConnection(oraclepooledconnection, true);
                            implicitCache.checkedOutConnectionList.remove(oraclepooledconnection);
                            implicitCache.storeCacheConnection(oraclepooledconnection.cachedConnectionAttributes, oraclepooledconnection);
                        }
                    }
                    catch(SQLException sqlexception) { }
                }

            }
        }
    }

}
