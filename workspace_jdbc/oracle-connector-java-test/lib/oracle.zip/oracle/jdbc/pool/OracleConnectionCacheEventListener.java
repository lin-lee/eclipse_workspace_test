// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConnectionCacheEventListener.java

package oracle.jdbc.pool;

import java.io.Serializable;
import java.sql.SQLException;
import javax.sql.*;

// Referenced classes of package oracle.jdbc.pool:
//            OracleImplicitConnectionCache

/**
 * @deprecated Class OracleConnectionCacheEventListener is deprecated
 */

class OracleConnectionCacheEventListener
    implements ConnectionEventListener, Serializable
{

    static final int CONNECTION_CLOSED_EVENT = 101;
    static final int CONNECTION_ERROROCCURED_EVENT = 102;
    protected OracleImplicitConnectionCache implicitCache;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleConnectionCacheEventListener()
    {
        this(null);
    }

    public OracleConnectionCacheEventListener(OracleImplicitConnectionCache oracleimplicitconnectioncache)
    {
        implicitCache = null;
        implicitCache = oracleimplicitconnectioncache;
    }

    public void connectionClosed(ConnectionEvent connectionevent)
    {
        try
        {
            if(implicitCache != null)
                implicitCache.reusePooledConnection((PooledConnection)connectionevent.getSource());
        }
        catch(SQLException sqlexception) { }
    }

    public void connectionErrorOccurred(ConnectionEvent connectionevent)
    {
        try
        {
            if(implicitCache != null)
                implicitCache.closePooledConnection((PooledConnection)connectionevent.getSource());
        }
        catch(SQLException sqlexception) { }
    }

}
