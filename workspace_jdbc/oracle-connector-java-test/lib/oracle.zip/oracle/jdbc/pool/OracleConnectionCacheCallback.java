// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConnectionCacheCallback.java

package oracle.jdbc.pool;

import oracle.jdbc.OracleConnection;

/**
 * @deprecated Interface OracleConnectionCacheCallback is deprecated
 */

public interface OracleConnectionCacheCallback
{

    /**
     * @deprecated Method handleAbandonedConnection is deprecated
     */

    public abstract boolean handleAbandonedConnection(OracleConnection oracleconnection, Object obj);

    /**
     * @deprecated Method releaseConnection is deprecated
     */

    public abstract void releaseConnection(OracleConnection oracleconnection, Object obj);
}
