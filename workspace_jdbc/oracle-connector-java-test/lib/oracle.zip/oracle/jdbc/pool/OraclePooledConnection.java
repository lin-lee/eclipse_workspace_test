// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OraclePooledConnection.java

package oracle.jdbc.pool;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.sql.*;
import javax.transaction.xa.XAResource;
import oracle.jdbc.driver.*;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.pool:
//            OracleConnectionCacheEntry

public class OraclePooledConnection
    implements PooledConnection, Serializable
{

    static final long serialVersionUID = 0xfd2c389ebc99eb47L;
    public static final String url_string = "connection_url";
    public static final String pool_auto_commit_string = "pool_auto_commit";
    public static final String object_type_map = "obj_type_map";
    public static final String transaction_isolation = "trans_isolation";
    public static final String statement_cache_size = "stmt_cache_size";
    public static final String isClearMetaData = "stmt_cache_clear_metadata";
    public static final String ImplicitStatementCachingEnabled = "ImplicitStatementCachingEnabled";
    public static final String ExplicitStatementCachingEnabled = "ExplicitStatementCachingEnabled";
    public static final String LoginTimeout = "LoginTimeout";
    public static final String connect_auto_commit_string = "connect_auto_commit";
    public static final String implicit_caching_enabled = "implicit_cache_enabled";
    public static final String explicit_caching_enabled = "explict_cache_enabled";
    public static final String connection_properties_string = "connection_properties";
    public static final String event_listener_string = "event_listener";
    public static final String sql_exception_string = "sql_exception";
    public static final String close_callback_string = "close_callback";
    public static final String private_data = "private_data";
    static final int CONNECTION_CLOSED_EVENT = 101;
    static final int CONNECTION_ERROROCCURED_EVENT = 102;
    private Hashtable eventListeners;
    private SQLException sqlException;
    protected boolean autoCommit;
    private ConnectionEventListener iccEventListener;
    protected transient OracleConnection logicalHandle;
    protected transient OracleConnection physicalConn;
    private Hashtable connectionProperty;
    public Properties cachedConnectionAttributes;
    public Properties unMatchedCachedConnAttr;
    public int closeOption;
    private String pcKey;
    private OracleCloseCallback closeCallback;
    private Object privateData;
    private long lastAccessedTime;
    protected String dataSourceInstanceNameKey;
    protected String dataSourceHostNameKey;
    protected String dataSourceDbUniqNameKey;
    protected boolean connectionMarkedDown;
    protected boolean needToAbort;
    protected transient OracleDriver oracleDriver;
    boolean localTxnCommitOnClose;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OraclePooledConnection()
    {
        this((Connection)null);
    }

    public OraclePooledConnection(String s)
        throws SQLException
    {
        eventListeners = null;
        sqlException = null;
        autoCommit = true;
        iccEventListener = null;
        logicalHandle = null;
        physicalConn = null;
        connectionProperty = null;
        cachedConnectionAttributes = null;
        unMatchedCachedConnAttr = null;
        closeOption = 0;
        pcKey = null;
        closeCallback = null;
        privateData = null;
        lastAccessedTime = 0L;
        dataSourceInstanceNameKey = null;
        dataSourceHostNameKey = null;
        dataSourceDbUniqNameKey = null;
        connectionMarkedDown = false;
        needToAbort = false;
        oracleDriver = new OracleDriver();
        localTxnCommitOnClose = false;
        Connection connection = oracleDriver.connect(s, new Properties());
        if(connection == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            initialize(connection);
            return;
        }
    }

    public OraclePooledConnection(String s, String s1, String s2)
        throws SQLException
    {
        eventListeners = null;
        sqlException = null;
        autoCommit = true;
        iccEventListener = null;
        logicalHandle = null;
        physicalConn = null;
        connectionProperty = null;
        cachedConnectionAttributes = null;
        unMatchedCachedConnAttr = null;
        closeOption = 0;
        pcKey = null;
        closeCallback = null;
        privateData = null;
        lastAccessedTime = 0L;
        dataSourceInstanceNameKey = null;
        dataSourceHostNameKey = null;
        dataSourceDbUniqNameKey = null;
        connectionMarkedDown = false;
        needToAbort = false;
        oracleDriver = new OracleDriver();
        localTxnCommitOnClose = false;
        Properties properties = new Properties();
        properties.put("user", s1);
        properties.put("password", s2);
        Connection connection = oracleDriver.connect(s, properties);
        if(connection == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            initialize(connection);
            return;
        }
    }

    public OraclePooledConnection(Connection connection)
    {
        eventListeners = null;
        sqlException = null;
        autoCommit = true;
        iccEventListener = null;
        logicalHandle = null;
        physicalConn = null;
        connectionProperty = null;
        cachedConnectionAttributes = null;
        unMatchedCachedConnAttr = null;
        closeOption = 0;
        pcKey = null;
        closeCallback = null;
        privateData = null;
        lastAccessedTime = 0L;
        dataSourceInstanceNameKey = null;
        dataSourceHostNameKey = null;
        dataSourceDbUniqNameKey = null;
        connectionMarkedDown = false;
        needToAbort = false;
        oracleDriver = new OracleDriver();
        localTxnCommitOnClose = false;
        initialize(connection);
    }

    public OraclePooledConnection(Connection connection, boolean flag)
    {
        this(connection);
        autoCommit = flag;
    }

    private void initialize(Connection connection)
    {
        physicalConn = (OracleConnection)connection;
        eventListeners = new Hashtable(10);
        closeCallback = null;
        privateData = null;
        lastAccessedTime = 0L;
    }

    public synchronized void addConnectionEventListener(ConnectionEventListener connectioneventlistener)
    {
        if(eventListeners == null)
            sqlException = new SQLException("Listener Hashtable Null");
        else
            eventListeners.put(connectioneventlistener, connectioneventlistener);
    }

    public synchronized void close()
        throws SQLException
    {
        if(closeCallback != null)
            closeCallback.beforeClose(physicalConn, privateData);
        if(physicalConn != null)
        {
            try
            {
                physicalConn.close();
            }
            catch(SQLException sqlexception) { }
            physicalConn = null;
        }
        if(closeCallback != null)
            closeCallback.afterClose(privateData);
        lastAccessedTime = 0L;
        iccEventListener = null;
    }

    public synchronized Connection getConnection()
        throws SQLException
    {
        if(physicalConn == null)
        {
            sqlException = new SQLException("Physical Connection doesn't exist");
            callListener(102);
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        try
        {
            if(logicalHandle != null)
                logicalHandle.closeInternal(false);
            logicalHandle = (OracleConnection)physicalConn.getLogicalConnection(this, autoCommit);
        }
        catch(SQLException sqlexception1)
        {
            sqlException = sqlexception1;
            callListener(102);
            callImplicitCacheListener(102);
            SQLException sqlexception2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, (new StringBuilder()).append("OraclePooledConnection.getConnection() - SQLException Ocurred:").append(sqlexception1.getMessage()).toString());
            sqlexception2.fillInStackTrace();
            throw sqlexception2;
        }
        return logicalHandle;
    }

    public Connection getLogicalHandle()
        throws SQLException
    {
        return logicalHandle;
    }

    public Connection getPhysicalHandle()
        throws SQLException
    {
        return physicalConn;
    }

    public synchronized void setLastAccessedTime(long l)
        throws SQLException
    {
        lastAccessedTime = l;
    }

    public long getLastAccessedTime()
        throws SQLException
    {
        return lastAccessedTime;
    }

    public synchronized void registerCloseCallback(OracleCloseCallback oracleclosecallback, Object obj)
    {
        closeCallback = oracleclosecallback;
        privateData = obj;
    }

    public synchronized void removeConnectionEventListener(ConnectionEventListener connectioneventlistener)
    {
        if(eventListeners == null)
            sqlException = new SQLException("Listener Hashtable Null");
        else
            eventListeners.remove(connectioneventlistener);
    }

    public synchronized void registerImplicitCacheConnectionEventListener(ConnectionEventListener connectioneventlistener)
    {
        if(iccEventListener != null)
            sqlException = new SQLException("Implicit cache listeneralready registered");
        else
            iccEventListener = connectioneventlistener;
    }

    public void logicalCloseForImplicitConnectionCache()
    {
        if(closeOption == 4096)
            callImplicitCacheListener(102);
        else
            callImplicitCacheListener(101);
    }

    public void logicalClose()
    {
        if(cachedConnectionAttributes != null)
            logicalCloseForImplicitConnectionCache();
        else
            callListener(101);
    }

    private void callListener(int i)
    {
        if(eventListeners == null)
            return;
        Enumeration enumeration = eventListeners.keys();
        ConnectionEvent connectionevent = new ConnectionEvent(this, sqlException);
        do
        {
            if(!enumeration.hasMoreElements())
                break;
            ConnectionEventListener connectioneventlistener = (ConnectionEventListener)enumeration.nextElement();
            ConnectionEventListener connectioneventlistener1 = (ConnectionEventListener)eventListeners.get(connectioneventlistener);
            if(i == 101)
                connectioneventlistener1.connectionClosed(connectionevent);
            else
            if(i == 102)
                connectioneventlistener1.connectionErrorOccurred(connectionevent);
        } while(true);
    }

    private void callImplicitCacheListener(int i)
    {
        if(iccEventListener == null)
            return;
        ConnectionEvent connectionevent = new ConnectionEvent(this, sqlException);
        switch(i)
        {
        case 101: // 'e'
            iccEventListener.connectionClosed(connectionevent);
            break;

        case 102: // 'f'
            iccEventListener.connectionErrorOccurred(connectionevent);
            break;
        }
    }

    /**
     * @deprecated Method setStmtCacheSize is deprecated
     */

    public synchronized void setStmtCacheSize(int i)
        throws SQLException
    {
        setStmtCacheSize(i, false);
    }

    /**
     * @deprecated Method setStmtCacheSize is deprecated
     */

    public synchronized void setStmtCacheSize(int i, boolean flag)
        throws SQLException
    {
        if(i < 0)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(physicalConn != null)
            physicalConn.setStmtCacheSize(i, flag);
    }

    /**
     * @deprecated Method getStmtCacheSize is deprecated
     */

    public synchronized int getStmtCacheSize()
    {
        if(physicalConn != null)
            return physicalConn.getStmtCacheSize();
        else
            return 0;
    }

    public void setStatementCacheSize(int i)
        throws SQLException
    {
        if(physicalConn != null)
            physicalConn.setStatementCacheSize(i);
    }

    public int getStatementCacheSize()
        throws SQLException
    {
        if(physicalConn != null)
            return physicalConn.getStatementCacheSize();
        else
            return 0;
    }

    public void setImplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        if(physicalConn != null)
            physicalConn.setImplicitCachingEnabled(flag);
    }

    public boolean getImplicitCachingEnabled()
        throws SQLException
    {
        if(physicalConn != null)
            return physicalConn.getImplicitCachingEnabled();
        else
            return false;
    }

    public void setExplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        if(physicalConn != null)
            physicalConn.setExplicitCachingEnabled(flag);
    }

    public boolean getExplicitCachingEnabled()
        throws SQLException
    {
        if(physicalConn != null)
            return physicalConn.getExplicitCachingEnabled();
        else
            return false;
    }

    public void purgeImplicitCache()
        throws SQLException
    {
        if(physicalConn != null)
            physicalConn.purgeImplicitCache();
    }

    public void purgeExplicitCache()
        throws SQLException
    {
        if(physicalConn != null)
            physicalConn.purgeExplicitCache();
    }

    public PreparedStatement getStatementWithKey(String s)
        throws SQLException
    {
        if(physicalConn != null)
            return physicalConn.getStatementWithKey(s);
        else
            return null;
    }

    public CallableStatement getCallWithKey(String s)
        throws SQLException
    {
        if(physicalConn != null)
            return physicalConn.getCallWithKey(s);
        else
            return null;
    }

    public boolean isStatementCacheInitialized()
    {
        if(physicalConn != null)
            return physicalConn.isStatementCacheInitialized();
        else
            return false;
    }

    public final void setProperties(Hashtable hashtable)
    {
        connectionProperty = hashtable;
    }

    public final void setUserName(String s, String s1)
    {
        pcKey = generateKey(s, s1);
    }

    static final String generateKey(String s, String s1)
    {
        return (new StringBuilder()).append(s.toUpperCase()).append(s1).toString();
    }

    final OracleConnectionCacheEntry addToImplicitCache(HashMap hashmap, OracleConnectionCacheEntry oracleconnectioncacheentry)
    {
        return (OracleConnectionCacheEntry)hashmap.put(pcKey, oracleconnectioncacheentry);
    }

    final OracleConnectionCacheEntry removeFromImplictCache(HashMap hashmap)
    {
        return (OracleConnectionCacheEntry)hashmap.get(pcKey);
    }

    final boolean isSameUser(String s, String s1)
    {
        return s != null && s1 != null && pcKey.equalsIgnoreCase((new StringBuilder()).append(s).append(s1).toString());
    }

    public XAResource getXAResource()
        throws SQLException
    {
        SQLException sqlexception = DatabaseError.createUnsupportedFeatureSqlException();
        sqlexception.fillInStackTrace();
        throw sqlexception;
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.defaultWriteObject();
        try
        {
            physicalConn.getPropertyForPooledConnection(this);
            if(eventListeners != null)
                connectionProperty.put("event_listener", eventListeners);
            if(sqlException != null)
                connectionProperty.put("sql_exception", sqlException);
            connectionProperty.put("pool_auto_commit", (new StringBuilder()).append("").append(autoCommit).toString());
            if(closeCallback != null)
                connectionProperty.put("close_callback", closeCallback);
            if(privateData != null)
                connectionProperty.put("private_data", privateData);
            objectoutputstream.writeObject(connectionProperty);
            physicalConn.close();
        }
        catch(SQLException sqlexception) { }
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException, SQLException
    {
        objectinputstream.defaultReadObject();
        connectionProperty = (Hashtable)objectinputstream.readObject();
        try
        {
            Properties properties = (Properties)connectionProperty.get("connection_properties");
            String s = properties.getProperty("connection_url");
            oracleDriver = new OracleDriver();
            Connection connection = oracleDriver.connect(s, properties);
            initialize(connection);
            eventListeners = (Hashtable)connectionProperty.get("event_listener");
            sqlException = (SQLException)connectionProperty.get("sql_exception");
            autoCommit = ((String)connectionProperty.get("pool_auto_commit")).equals("true");
            closeCallback = (OracleCloseCallback)connectionProperty.get("close_callback");
            privateData = connectionProperty.get("private_data");
            Map map = (Map)connectionProperty.get("obj_type_map");
            if(map != null)
                ((OracleConnection)connection).setTypeMap(map);
            String s1 = properties.getProperty("trans_isolation");
            connection.setTransactionIsolation(Integer.parseInt(s1));
            s1 = properties.getProperty("stmt_cache_size");
            int i = Integer.parseInt(s1);
            if(i != -1)
            {
                setStatementCacheSize(i);
                String s2 = properties.getProperty("implicit_cache_enabled");
                if(s2 != null && s2.equalsIgnoreCase("true"))
                    setImplicitCachingEnabled(true);
                else
                    setImplicitCachingEnabled(false);
                s2 = properties.getProperty("explict_cache_enabled");
                if(s2 != null && s2.equalsIgnoreCase("true"))
                    setExplicitCachingEnabled(true);
                else
                    setExplicitCachingEnabled(false);
            }
            physicalConn.setAutoCommit(((String)properties.get("connect_auto_commit")).equals("true"));
        }
        catch(Exception exception) { }
    }

    public void addStatementEventListener(StatementEventListener statementeventlistener)
    {
    }

    public void removeStatementEventListener(StatementEventListener statementeventlistener)
    {
    }

    protected OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
