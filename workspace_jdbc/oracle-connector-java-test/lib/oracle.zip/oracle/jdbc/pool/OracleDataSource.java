// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDataSource.java

package oracle.jdbc.pool;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.util.Enumeration;
import java.util.Properties;
import javax.naming.NamingException;
import javax.naming.Reference;
import javax.naming.Referenceable;
import javax.naming.StringRefAddr;
import javax.sql.DataSource;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.driver.DatabaseError;
import oracle.jdbc.driver.OracleDriver;

// Referenced classes of package oracle.jdbc.pool:
//            OracleConnectionCacheManager, OracleImplicitConnectionCache, OracleConnectionPoolDataSource

public class OracleDataSource
    implements DataSource, Serializable, Referenceable
{

    static final long serialVersionUID = 0x2e7c5b99cbdcaa8bL;
    protected PrintWriter logWriter;
    protected int loginTimeout;
    protected String databaseName;
    protected String serviceName;
    protected String dataSourceName;
    protected String description;
    protected String networkProtocol;
    protected int portNumber;
    protected String user;
    protected String password;
    protected String serverName;
    protected String url;
    protected String driverType;
    protected String tnsEntry;
    protected int maxStatements;
    protected boolean implicitCachingEnabled;
    protected boolean explicitCachingEnabled;
    protected transient OracleImplicitConnectionCache odsCache;
    protected transient OracleConnectionCacheManager cacheManager;
    protected String connCacheName;
    protected Properties connCacheProperties;
    protected Properties connectionProperties;
    protected boolean connCachingEnabled;
    protected boolean fastConnFailover;
    protected String onsConfigStr;
    public boolean isOracleDataSource;
    private static final boolean fastConnectionFailoverSysProperty = "true".equalsIgnoreCase(OracleDriver.getSystemPropertyFastConnectionFailover("false"));
    private boolean urlExplicit;
    private boolean useDefaultConnection;
    protected transient OracleDriver driver;
    private static final String spawnNewThreadToCancelProperty = "oracle.jdbc.spawnNewThreadToCancel";
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleDataSource()
        throws SQLException
    {
        logWriter = null;
        loginTimeout = 0;
        databaseName = null;
        serviceName = null;
        dataSourceName = "OracleDataSource";
        description = null;
        networkProtocol = "tcp";
        portNumber = 0;
        user = null;
        password = null;
        serverName = null;
        url = null;
        driverType = null;
        tnsEntry = null;
        maxStatements = 0;
        implicitCachingEnabled = false;
        explicitCachingEnabled = false;
        odsCache = null;
        cacheManager = null;
        connCacheName = null;
        connCacheProperties = null;
        connectionProperties = null;
        connCachingEnabled = false;
        fastConnFailover = false;
        onsConfigStr = null;
        isOracleDataSource = true;
        urlExplicit = false;
        useDefaultConnection = false;
        driver = new OracleDriver();
        processFastConnectionFailoverSysProperty();
    }

    void processFastConnectionFailoverSysProperty()
    {
        if(isOracleDataSource && fastConnectionFailoverSysProperty)
        {
            connCachingEnabled = true;
            if(cacheManager == null)
                try
                {
                    cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
                }
                catch(SQLException sqlexception) { }
            fastConnFailover = true;
            setSpawnNewThreadToCancel(true);
        }
    }

    public Connection getConnection()
        throws SQLException
    {
        String s = null;
        String s1 = null;
        synchronized(this)
        {
            s = user;
            s1 = password;
        }
        return getConnection(s, s1);
    }

    public Connection getConnection(String s, String s1)
        throws SQLException
    {
        Connection connection = null;
        Object obj = null;
        if(connCachingEnabled)
        {
            connection = getConnection(s, s1, null);
        } else
        {
            Properties properties;
            synchronized(this)
            {
                makeURL();
                properties = connectionProperties != null ? (Properties)connectionProperties.clone() : new Properties();
                if(url != null)
                    properties.setProperty("connection_url", url);
                if(s != null)
                    properties.setProperty("user", s);
                if(s1 != null)
                    properties.setProperty("password", s1);
                if(loginTimeout != 0)
                    properties.setProperty("LoginTimeout", (new StringBuilder()).append("").append(loginTimeout).toString());
                if(maxStatements != 0)
                    properties.setProperty("stmt_cache_size", (new StringBuilder()).append("").append(maxStatements).toString());
            }
            connection = getPhysicalConnection(properties);
            if(connection == null)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
        }
        return connection;
    }

    protected Connection getPhysicalConnection(Properties properties)
        throws SQLException
    {
        Connection connection = null;
        Properties properties1 = properties;
        String s = properties.getProperty("connection_url");
        String s1 = properties.getProperty("user");
        String s2 = properties1.getProperty("password");
        String s3 = null;
        boolean flag = false;
        synchronized(this)
        {
            if(connectionProperties != null)
            {
                properties1 = (Properties)connectionProperties.clone();
                if(s1 != null)
                    properties1.put("user", s1);
                if(s2 != null)
                    properties1.put("password", s2);
            }
            if(s1 == null && user != null)
                properties1.put("user", user);
            if(s2 == null && password != null)
                properties1.put("password", password);
            if(s == null)
                s = url;
            String s4 = properties.getProperty("LoginTimeout");
            if(s4 != null)
                properties1.put("oracle.net.CONNECT_TIMEOUT", (new StringBuilder()).append("").append(Integer.parseInt(s4) * 1000).toString());
            flag = useDefaultConnection;
            if(driver == null)
                driver = new OracleDriver();
        }
        if(flag)
            connection = driver.defaultConnection();
        else
            connection = driver.connect(s, properties1);
        if(connection == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        s3 = properties.getProperty("stmt_cache_size");
        int i = 0;
        if(s3 != null)
            ((OracleConnection)connection).setStatementCacheSize(i = Integer.parseInt(s3));
        boolean flag1 = false;
        s3 = properties.getProperty("ExplicitStatementCachingEnabled");
        if(s3 != null)
            ((OracleConnection)connection).setExplicitCachingEnabled(flag1 = s3.equals("true"));
        boolean flag2 = false;
        s3 = properties.getProperty("ImplicitStatementCachingEnabled");
        if(s3 != null)
            ((OracleConnection)connection).setImplicitCachingEnabled(flag2 = s3.equals("true"));
        if(i > 0 && !flag1 && !flag2)
        {
            ((OracleConnection)connection).setImplicitCachingEnabled(true);
            ((OracleConnection)connection).setExplicitCachingEnabled(true);
        }
        return connection;
    }

    /**
     * @deprecated Method getConnection is deprecated
     */

    public Connection getConnection(Properties properties)
        throws SQLException
    {
        String s = null;
        String s1 = null;
        synchronized(this)
        {
            if(!connCachingEnabled)
            {
                SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 137);
                sqlexception.fillInStackTrace();
                throw sqlexception;
            }
            s = user;
            s1 = password;
        }
        Connection connection = getConnection(s, s1, properties);
        return connection;
    }

    /**
     * @deprecated Method getConnection is deprecated
     */

    public Connection getConnection(String s, String s1, Properties properties)
        throws SQLException
    {
        if(!connCachingEnabled)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 137);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(odsCache == null)
            cacheInitialize();
        Connection connection = odsCache.getConnection(s, s1, properties);
        return connection;
    }

    private synchronized void cacheInitialize()
        throws SQLException
    {
        if(odsCache == null)
            if(connCacheName != null)
                cacheManager.createCache(connCacheName, this, connCacheProperties);
            else
                connCacheName = cacheManager.createCache(this, connCacheProperties);
    }

    /**
     * @deprecated Method close is deprecated
     */

    public synchronized void close()
        throws SQLException
    {
        if(connCachingEnabled && odsCache != null)
        {
            cacheManager.removeCache(odsCache.cacheName, 0L);
            odsCache = null;
        }
    }

    /**
     * @deprecated Method setConnectionCachingEnabled is deprecated
     */

    public synchronized void setConnectionCachingEnabled(boolean flag)
        throws SQLException
    {
        if(isOracleDataSource)
        {
            if(flag)
            {
                connCachingEnabled = true;
                if(cacheManager == null)
                    cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
            } else
            if(odsCache == null)
            {
                connCachingEnabled = false;
                fastConnFailover = false;
                setSpawnNewThreadToCancel(false);
                connCacheName = null;
                connCacheProperties = null;
            }
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 137);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public boolean getConnectionCachingEnabled()
        throws SQLException
    {
        return connCachingEnabled;
    }

    public synchronized void setConnectionCacheName(String s)
        throws SQLException
    {
        if(s == null)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 138);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        } else
        {
            connCacheName = s;
            return;
        }
    }

    public String getConnectionCacheName()
        throws SQLException
    {
        if(connCachingEnabled && odsCache != null)
            return odsCache.cacheName;
        else
            return connCacheName;
    }

    /**
     * @deprecated Method setConnectionCacheProperties is deprecated
     */

    public synchronized void setConnectionCacheProperties(Properties properties)
        throws SQLException
    {
        connCacheProperties = properties;
    }

    public Properties getConnectionCacheProperties()
        throws SQLException
    {
        if(connCachingEnabled && odsCache != null)
            return odsCache.getConnectionCacheProperties();
        else
            return connCacheProperties;
    }

    public synchronized void setFastConnectionFailoverEnabled(boolean flag)
        throws SQLException
    {
        if(!fastConnFailover)
        {
            fastConnFailover = flag;
            setSpawnNewThreadToCancel(flag);
        } else
        if(!flag)
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 255);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public boolean getFastConnectionFailoverEnabled()
        throws SQLException
    {
        return fastConnFailover;
    }

    /**
     * @deprecated Method getONSConfiguration is deprecated
     */

    public String getONSConfiguration()
        throws SQLException
    {
        return onsConfigStr;
    }

    /**
     * @deprecated Method setONSConfiguration is deprecated
     */

    public synchronized void setONSConfiguration(String s)
        throws SQLException
    {
        onsConfigStr = s;
    }

    public synchronized int getLoginTimeout()
    {
        return loginTimeout;
    }

    public synchronized void setLoginTimeout(int i)
    {
        loginTimeout = i;
    }

    public synchronized void setLogWriter(PrintWriter printwriter)
    {
        logWriter = printwriter;
    }

    public synchronized PrintWriter getLogWriter()
    {
        return logWriter;
    }

    public synchronized void setTNSEntryName(String s)
    {
        tnsEntry = s;
    }

    public synchronized String getTNSEntryName()
    {
        return tnsEntry;
    }

    public synchronized void setDataSourceName(String s)
    {
        dataSourceName = s;
    }

    public synchronized String getDataSourceName()
    {
        return dataSourceName;
    }

    public synchronized String getDatabaseName()
    {
        return databaseName;
    }

    public synchronized void setDatabaseName(String s)
    {
        databaseName = s;
    }

    public synchronized void setServiceName(String s)
    {
        serviceName = s;
    }

    public synchronized String getServiceName()
    {
        return serviceName;
    }

    public synchronized void setServerName(String s)
    {
        serverName = s;
    }

    public synchronized String getServerName()
    {
        return serverName;
    }

    public synchronized void setURL(String s)
    {
        url = s;
        if(url != null)
            urlExplicit = true;
        if(connCachingEnabled && odsCache != null && odsCache.connectionPoolDS != null)
            odsCache.connectionPoolDS.url = s;
    }

    public synchronized String getURL()
        throws SQLException
    {
        if(!urlExplicit)
            makeURL();
        return url;
    }

    public synchronized void setUser(String s)
    {
        user = s;
    }

    public String getUser()
    {
        return user;
    }

    public synchronized void setPassword(String s)
    {
        password = s;
    }

    protected String getPassword()
    {
        return password;
    }

    public synchronized String getDescription()
    {
        return description;
    }

    public synchronized void setDescription(String s)
    {
        description = s;
    }

    public synchronized String getDriverType()
    {
        return driverType;
    }

    public synchronized void setDriverType(String s)
    {
        driverType = s;
    }

    public synchronized String getNetworkProtocol()
    {
        return networkProtocol;
    }

    public synchronized void setNetworkProtocol(String s)
    {
        networkProtocol = s;
    }

    public synchronized void setPortNumber(int i)
    {
        portNumber = i;
    }

    public synchronized int getPortNumber()
    {
        return portNumber;
    }

    public synchronized Reference getReference()
        throws NamingException
    {
        Reference reference = new Reference(getClass().getName(), "oracle.jdbc.pool.OracleDataSourceFactory", null);
        addRefProperties(reference);
        return reference;
    }

    protected void addRefProperties(Reference reference)
    {
        if(url != null)
            reference.add(new StringRefAddr("url", url));
        if(user != null)
            reference.add(new StringRefAddr("userName", user));
        if(password != null)
            reference.add(new StringRefAddr("passWord", password));
        if(description != null)
            reference.add(new StringRefAddr("description", description));
        if(driverType != null)
            reference.add(new StringRefAddr("driverType", driverType));
        if(serverName != null)
            reference.add(new StringRefAddr("serverName", serverName));
        if(databaseName != null)
            reference.add(new StringRefAddr("databaseName", databaseName));
        if(serviceName != null)
            reference.add(new StringRefAddr("serviceName", serviceName));
        if(networkProtocol != null)
            reference.add(new StringRefAddr("networkProtocol", networkProtocol));
        if(portNumber != 0)
            reference.add(new StringRefAddr("portNumber", Integer.toString(portNumber)));
        if(tnsEntry != null)
            reference.add(new StringRefAddr("tnsentryname", tnsEntry));
        if(maxStatements != 0)
            reference.add(new StringRefAddr("maxStatements", Integer.toString(maxStatements)));
        if(implicitCachingEnabled)
            reference.add(new StringRefAddr("implicitCachingEnabled", "true"));
        if(explicitCachingEnabled)
            reference.add(new StringRefAddr("explicitCachingEnabled", "true"));
        if(connCachingEnabled)
            reference.add(new StringRefAddr("connectionCachingEnabled", "true"));
        if(connCacheName != null)
            reference.add(new StringRefAddr("connectionCacheName", connCacheName));
        if(connCacheProperties != null)
            reference.add(new StringRefAddr("connectionCacheProperties", connCacheProperties.toString()));
        if(fastConnFailover)
            reference.add(new StringRefAddr("fastConnectionFailoverEnabled", "true"));
        if(onsConfigStr != null)
            reference.add(new StringRefAddr("onsConfigStr", onsConfigStr));
    }

    void makeURL()
        throws SQLException
    {
        if(urlExplicit)
            return;
        if(driverType == null || !driverType.equals("oci8") && !driverType.equals("oci") && !driverType.equals("thin") && !driverType.equals("kprb"))
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, "OracleDataSource.makeURL");
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
        if(driverType.equals("kprb"))
        {
            useDefaultConnection = true;
            url = "jdbc:oracle:kprb:@";
            return;
        }
        if((driverType.equals("oci8") || driverType.equals("oci")) && networkProtocol != null && networkProtocol.equals("ipc"))
        {
            url = "jdbc:oracle:oci:@";
            return;
        }
        if(tnsEntry != null)
        {
            url = (new StringBuilder()).append("jdbc:oracle:").append(driverType).append(":@").append(tnsEntry).toString();
            return;
        }
        if(serviceName != null)
        {
            url = (new StringBuilder()).append("jdbc:oracle:").append(driverType).append(":@(DESCRIPTION=(ADDRESS=(PROTOCOL=").append(networkProtocol).append(")(PORT=").append(portNumber).append(")(HOST=").append(serverName).append("))(CONNECT_DATA=(SERVICE_NAME=").append(serviceName).append(")))").toString();
        } else
        {
            url = (new StringBuilder()).append("jdbc:oracle:").append(driverType).append(":@(DESCRIPTION=(ADDRESS=(PROTOCOL=").append(networkProtocol).append(")(PORT=").append(portNumber).append(")(HOST=").append(serverName).append("))(CONNECT_DATA=(SID=").append(databaseName).append(")))").toString();
            DatabaseError.addSqlWarning(null, new SQLWarning("URL with SID jdbc:subprotocol:@host:port:sid will be deprecated in 10i\nPlease use URL with SERVICE_NAME as jdbc:subprotocol:@//host:port/service_name"));
            if(fastConnFailover)
            {
                SQLException sqlexception1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, "OracleDataSource.makeURL");
                sqlexception1.fillInStackTrace();
                throw sqlexception1;
            }
        }
    }

    protected void trace(String s)
    {
        if(logWriter == null);
    }

    protected void copy(OracleDataSource oracledatasource)
        throws SQLException
    {
        oracledatasource.setUser(user);
        oracledatasource.setPassword(password);
        oracledatasource.setTNSEntryName(tnsEntry);
        makeURL();
        oracledatasource.setURL(url);
        if(loginTimeout > 0)
            oracledatasource.setLoginTimeout(loginTimeout);
        oracledatasource.connectionProperties = connectionProperties;
    }

    /**
     * @deprecated Method setMaxStatements is deprecated
     */

    public void setMaxStatements(int i)
        throws SQLException
    {
        maxStatements = i;
    }

    public int getMaxStatements()
        throws SQLException
    {
        return maxStatements;
    }

    public void setImplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        implicitCachingEnabled = flag;
    }

    public boolean getImplicitCachingEnabled()
        throws SQLException
    {
        return implicitCachingEnabled;
    }

    public void setExplicitCachingEnabled(boolean flag)
        throws SQLException
    {
        explicitCachingEnabled = flag;
    }

    public boolean getExplicitCachingEnabled()
        throws SQLException
    {
        return explicitCachingEnabled;
    }

    public void setConnectionProperties(Properties properties)
        throws SQLException
    {
        if(properties == null)
            connectionProperties = properties;
        else
            connectionProperties = (Properties)properties.clone();
        setSpawnNewThreadToCancel(fastConnFailover);
    }

    public Properties getConnectionProperties()
        throws SQLException
    {
        return filterConnectionProperties(connectionProperties);
    }

    public static final Properties filterConnectionProperties(Properties properties)
    {
        Properties properties1 = null;
        if(properties != null)
        {
            properties1 = (Properties)properties.clone();
            Enumeration enumeration = properties1.propertyNames();
            Object obj = null;
            do
            {
                if(!enumeration.hasMoreElements())
                    break;
                String s = (String)enumeration.nextElement();
                if(s != null && s.matches(".*[P,p][A,a][S,s][S,s][W,w][O,o][R,r][D,d].*"))
                    properties1.remove(s);
            } while(true);
            properties.remove("oracle.jdbc.spawnNewThreadToCancel");
        }
        return properties1;
    }

    private void setSpawnNewThreadToCancel(boolean flag)
    {
        if(flag)
        {
            if(connectionProperties == null)
                connectionProperties = new Properties();
            connectionProperties.setProperty("oracle.jdbc.spawnNewThreadToCancel", "true");
        } else
        if(connectionProperties != null)
            connectionProperties.remove("oracle.jdbc.spawnNewThreadToCancel");
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.defaultWriteObject();
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException, SQLException
    {
        objectinputstream.defaultReadObject();
        if(connCachingEnabled)
            setConnectionCachingEnabled(connCachingEnabled);
    }

    public boolean isWrapperFor(Class class1)
        throws SQLException
    {
        if(class1.isInterface())
        {
            return class1.isInstance(this);
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    public Object unwrap(Class class1)
        throws SQLException
    {
        if(class1.isInterface() && class1.isInstance(this))
        {
            return this;
        } else
        {
            SQLException sqlexception = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 177);
            sqlexception.fillInStackTrace();
            throw sqlexception;
        }
    }

    protected oracle.jdbc.internal.OracleConnection getConnectionDuringExceptionHandling()
    {
        return null;
    }

}
