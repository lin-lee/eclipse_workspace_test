// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleFailoverEventHandlerThread.java

package oracle.jdbc.pool;

import java.security.*;
import java.sql.SQLException;
import oracle.ons.*;

// Referenced classes of package oracle.jdbc.pool:
//            OracleConnectionCacheManager

/**
 * @deprecated Class OracleFailoverEventHandlerThread is deprecated
 */

class OracleFailoverEventHandlerThread extends Thread
{

    private Notification event;
    private OracleConnectionCacheManager cacheManager;
    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    OracleFailoverEventHandlerThread()
        throws SQLException
    {
        event = null;
        cacheManager = null;
        cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
    }

    public void run()
    {
        Subscriber subscriber = null;
        while(cacheManager.failoverEnabledCacheExists()) 
        {
            try
            {
                subscriber = (Subscriber)AccessController.doPrivileged(new PrivilegedExceptionAction() {

                    final OracleFailoverEventHandlerThread this$0;

                    public Object run()
                    {
                        try
                        {
                            return new Subscriber("(%\"eventType=database/event/service\")|(%\"eventType=database/event/host\")", "", 30000L);
                        }
                        catch(SubscriptionException subscriptionexception)
                        {
                            return null;
                        }
                    }

            
            {
                this$0 = OracleFailoverEventHandlerThread.this;
                super();
            }
                }
);
            }
            catch(PrivilegedActionException privilegedactionexception) { }
            if(subscriber != null)
                try
                {
                    do
                    {
                        if(!cacheManager.failoverEnabledCacheExists())
                            break;
                        if((event = subscriber.receive(true)) != null)
                            handleEvent(event);
                    } while(true);
                }
                catch(ONSException onsexception)
                {
                    subscriber.close();
                }
            try
            {
                Thread.currentThread();
                Thread.sleep(10000L);
            }
            catch(InterruptedException interruptedexception) { }
        }
    }

    void handleEvent(Notification notification)
    {
        try
        {
            char c = '\0';
            if(notification.type().equalsIgnoreCase("database/event/service"))
            {
                OracleConnectionCacheManager _tmp = cacheManager;
                c = '\u0100';
            } else
            if(notification.type().equalsIgnoreCase("database/event/host"))
            {
                OracleConnectionCacheManager _tmp1 = cacheManager;
                c = '\u0200';
            }
            if(c != 0)
                cacheManager.verifyAndHandleEvent(c, notification.body());
        }
        catch(SQLException sqlexception) { }
    }

}
