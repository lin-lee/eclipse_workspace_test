// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConnectionPoolDataSource.java

package oracle.jdbc.pool;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.PooledConnection;
import oracle.jdbc.internal.OracleConnection;

// Referenced classes of package oracle.jdbc.pool:
//            OracleDataSource, OraclePooledConnection

public class OracleConnectionPoolDataSource extends OracleDataSource
    implements ConnectionPoolDataSource
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleConnectionPoolDataSource()
        throws SQLException
    {
        dataSourceName = "OracleConnectionPoolDataSource";
        isOracleDataSource = false;
        connCachingEnabled = false;
        fastConnFailover = false;
    }

    public PooledConnection getPooledConnection()
        throws SQLException
    {
        String s = null;
        String s1 = null;
        synchronized(this)
        {
            s = user;
            s1 = password;
        }
        return getPooledConnection(s, s1);
    }

    public PooledConnection getPooledConnection(String s, String s1)
        throws SQLException
    {
        Connection connection = getPhysicalConnection(s, s1);
        OraclePooledConnection oraclepooledconnection = new OraclePooledConnection(connection);
        if(s1 == null)
            s1 = password;
        oraclepooledconnection.setUserName(s.startsWith("\"") ? s : s.toLowerCase(), s1);
        return oraclepooledconnection;
    }

    PooledConnection getPooledConnection(Properties properties)
        throws SQLException
    {
        Connection connection = getPhysicalConnection(properties);
        OraclePooledConnection oraclepooledconnection = new OraclePooledConnection(connection);
        String s = properties.getProperty("user");
        if(s == null)
            s = ((OracleConnection)connection).getUserName();
        String s1 = properties.getProperty("password");
        if(s1 == null)
            s1 = password;
        oraclepooledconnection.setUserName(s.startsWith("\"") ? s : s.toLowerCase(), s1);
        return oraclepooledconnection;
    }

    protected Connection getPhysicalConnection()
        throws SQLException
    {
        return super.getConnection(user, password);
    }

    protected Connection getPhysicalConnection(String s, String s1, String s2)
        throws SQLException
    {
        url = s;
        return super.getConnection(s1, s2);
    }

    protected Connection getPhysicalConnection(String s, String s1)
        throws SQLException
    {
        return super.getConnection(s, s1);
    }

}
