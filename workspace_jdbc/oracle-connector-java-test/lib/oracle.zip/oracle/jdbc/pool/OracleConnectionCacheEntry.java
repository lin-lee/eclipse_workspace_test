// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleConnectionCacheEntry.java

package oracle.jdbc.pool;

import java.util.HashMap;
import java.util.Vector;

/**
 * @deprecated Class OracleConnectionCacheEntry is deprecated
 */

class OracleConnectionCacheEntry
{

    Vector userConnList;
    HashMap attrConnMap;

    OracleConnectionCacheEntry()
    {
        userConnList = null;
        attrConnMap = null;
    }
}
