// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleArray.java

package oracle.jdbc;

import java.sql.Array;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc:
//            OracleTypeMetaData

public interface OracleArray
    extends Array
{

    public abstract OracleTypeMetaData getOracleMetaData()
        throws SQLException;

    public abstract int length()
        throws SQLException;

    public abstract String getSQLTypeName()
        throws SQLException;

    public abstract Object toJdbc()
        throws SQLException;

    public abstract int[] getIntArray()
        throws SQLException;

    public abstract int[] getIntArray(long l, int i)
        throws SQLException;

    public abstract double[] getDoubleArray()
        throws SQLException;

    public abstract double[] getDoubleArray(long l, int i)
        throws SQLException;

    public abstract short[] getShortArray()
        throws SQLException;

    public abstract short[] getShortArray(long l, int i)
        throws SQLException;

    public abstract long[] getLongArray()
        throws SQLException;

    public abstract long[] getLongArray(long l, int i)
        throws SQLException;

    public abstract float[] getFloatArray()
        throws SQLException;

    public abstract float[] getFloatArray(long l, int i)
        throws SQLException;
}
