// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleTypeMetaData.java

package oracle.jdbc;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import oracle.sql.SQLName;

public interface OracleTypeMetaData
{
    public static interface Struct
        extends OracleTypeMetaData
    {

        public abstract int getTypeVersion()
            throws SQLException;

        public abstract int getLength()
            throws SQLException;

        public abstract ResultSetMetaData getMetaData()
            throws SQLException;

        public abstract boolean isFinalType()
            throws SQLException;

        public abstract boolean isSubtype()
            throws SQLException;

        public abstract boolean isInstantiable()
            throws SQLException;

        public abstract String getSupertypeName()
            throws SQLException;

        public abstract int getLocalAttributeCount()
            throws SQLException;

        public abstract String[] getSubtypeNames()
            throws SQLException;
    }

    public static interface Opaque
        extends OracleTypeMetaData
    {

        public abstract long getMaxLength()
            throws SQLException;

        public abstract boolean isTrustedLibrary()
            throws SQLException;

        public abstract boolean isModeledInC()
            throws SQLException;

        public abstract boolean hasUnboundedSize()
            throws SQLException;

        public abstract boolean hasFixedSize()
            throws SQLException;
    }

    public static interface Array
        extends OracleTypeMetaData
    {

        public abstract int getBaseType()
            throws SQLException;

        public abstract String getBaseName()
            throws SQLException;

        public abstract ArrayStorage getArrayStorage()
            throws SQLException;

        public abstract long getMaxLength()
            throws SQLException;
    }

    public static final class ArrayStorage extends Enum
    {

        public static final ArrayStorage VARRAY;
        public static final ArrayStorage NESTED_TABLE;
        private static final Map lookup;
        private final int code;
        private static final ArrayStorage $VALUES[];

        public static ArrayStorage[] values()
        {
            return (ArrayStorage[])$VALUES.clone();
        }

        public static ArrayStorage valueOf(String s)
        {
            return (ArrayStorage)Enum.valueOf(oracle/jdbc/OracleTypeMetaData$ArrayStorage, s);
        }

        public static ArrayStorage withCode(int i)
        {
            return (ArrayStorage)lookup.get(Integer.valueOf(i));
        }

        public int getCode()
        {
            return code;
        }

        static 
        {
            VARRAY = new ArrayStorage("VARRAY", 0, 3);
            NESTED_TABLE = new ArrayStorage("NESTED_TABLE", 1, 2);
            $VALUES = (new ArrayStorage[] {
                VARRAY, NESTED_TABLE
            });
            lookup = new HashMap(2);
            ArrayStorage aarraystorage[] = values();
            int i = aarraystorage.length;
            for(int j = 0; j < i; j++)
            {
                ArrayStorage arraystorage = aarraystorage[j];
                lookup.put(Integer.valueOf(arraystorage.getCode()), arraystorage);
            }

        }

        private ArrayStorage(String s, int i, int j)
        {
            super(s, i);
            code = j;
        }
    }

    public static final class Kind extends Enum
    {

        public static final Kind ARRAY;
        public static final Kind OPAQUE;
        public static final Kind STRUCT;
        public static final Kind TYPE;
        private static final Kind $VALUES[];

        public static Kind[] values()
        {
            return (Kind[])$VALUES.clone();
        }

        public static Kind valueOf(String s)
        {
            return (Kind)Enum.valueOf(oracle/jdbc/OracleTypeMetaData$Kind, s);
        }

        static 
        {
            ARRAY = new Kind("ARRAY", 0);
            OPAQUE = new Kind("OPAQUE", 1);
            STRUCT = new Kind("STRUCT", 2);
            TYPE = new Kind("TYPE", 3);
            $VALUES = (new Kind[] {
                ARRAY, OPAQUE, STRUCT, TYPE
            });
        }

        private Kind(String s, int i)
        {
            super(s, i);
        }
    }


    public abstract Kind getKind();

    public abstract String getName()
        throws SQLException;

    public abstract SQLName getSQLName()
        throws SQLException;

    public abstract String getSchemaName()
        throws SQLException;

    public abstract int getTypeCode()
        throws SQLException;

    public abstract String getTypeCodeName()
        throws SQLException;
}
