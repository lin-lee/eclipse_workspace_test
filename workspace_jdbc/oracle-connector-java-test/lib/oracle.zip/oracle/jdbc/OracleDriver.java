// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleDriver.java

package oracle.jdbc;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Properties;
import oracle.jdbc.driver.BuildInfo;

public class OracleDriver extends oracle.jdbc.driver.OracleDriver
{

    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    public OracleDriver()
    {
    }

    public static final boolean isDMS()
    {
        return BuildInfo.isDMS();
    }

    public static final boolean isInServer()
    {
        return BuildInfo.isInServer();
    }

    /**
     * @deprecated Method isJDK14 is deprecated
     */

    public static final boolean isJDK14()
    {
        return BuildInfo.isJDK14();
    }

    public static final boolean isDebug()
    {
        return BuildInfo.isDebug();
    }

    public static final boolean isPrivateDebug()
    {
        return BuildInfo.isPrivateDebug();
    }

    public static final String getJDBCVersion()
    {
        return BuildInfo.getJDBCVersion();
    }

    public static final String getDriverVersion()
    {
        return BuildInfo.getDriverVersion();
    }

    public static final String getBuildDate()
    {
        return BuildInfo.getBuildDate();
    }

    public static void main(String args[])
        throws Exception
    {
        String s = "JDK6";
        System.out.println((new StringBuilder()).append("Oracle ").append(getDriverVersion()).append(" ").append(getJDBCVersion()).append(isDMS() ? " DMS" : "").append(isPrivateDebug() ? " private" : "").append(isDebug() ? " debug" : "").append(isInServer() ? " for JAVAVM" : "").append(" compiled with ").append(s).append(" on ").append(getBuildDate()).toString());
        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(128);
        DEFAULT_CONNECTION_PROPERTIES.store(bytearrayoutputstream, "Default Connection Properties Resource");
        System.out.println(bytearrayoutputstream.toString("ISO-8859-1"));
    }

}
