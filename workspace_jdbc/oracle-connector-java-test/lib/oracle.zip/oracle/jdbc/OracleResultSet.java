// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleResultSet.java

package oracle.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import oracle.sql.*;

// Referenced classes of package oracle.jdbc:
//            OracleDataFactory

public interface OracleResultSet
    extends ResultSet
{
    public static final class AuthorizationIndicator extends Enum
    {

        public static final AuthorizationIndicator NONE;
        public static final AuthorizationIndicator UNAUTHORIZED;
        public static final AuthorizationIndicator UNKNOWN;
        private static final AuthorizationIndicator $VALUES[];

        public static AuthorizationIndicator[] values()
        {
            return (AuthorizationIndicator[])$VALUES.clone();
        }

        public static AuthorizationIndicator valueOf(String s)
        {
            return (AuthorizationIndicator)Enum.valueOf(oracle/jdbc/OracleResultSet$AuthorizationIndicator, s);
        }

        static 
        {
            NONE = new AuthorizationIndicator("NONE", 0);
            UNAUTHORIZED = new AuthorizationIndicator("UNAUTHORIZED", 1);
            UNKNOWN = new AuthorizationIndicator("UNKNOWN", 2);
            $VALUES = (new AuthorizationIndicator[] {
                NONE, UNAUTHORIZED, UNKNOWN
            });
        }

        private AuthorizationIndicator(String s, int i)
        {
            super(s, i);
        }
    }


    public static final int HOLD_CURSORS_OVER_COMMIT = 1;
    public static final int CLOSE_CURSORS_AT_COMMIT = 2;

    public abstract ARRAY getARRAY(int i)
        throws SQLException;

    public abstract ARRAY getARRAY(String s)
        throws SQLException;

    public abstract BFILE getBfile(int i)
        throws SQLException;

    public abstract BFILE getBFILE(int i)
        throws SQLException;

    public abstract BFILE getBfile(String s)
        throws SQLException;

    public abstract BFILE getBFILE(String s)
        throws SQLException;

    public abstract BLOB getBLOB(int i)
        throws SQLException;

    public abstract BLOB getBLOB(String s)
        throws SQLException;

    public abstract CHAR getCHAR(int i)
        throws SQLException;

    public abstract CHAR getCHAR(String s)
        throws SQLException;

    public abstract CLOB getCLOB(int i)
        throws SQLException;

    public abstract CLOB getCLOB(String s)
        throws SQLException;

    public abstract OPAQUE getOPAQUE(int i)
        throws SQLException;

    public abstract OPAQUE getOPAQUE(String s)
        throws SQLException;

    public abstract INTERVALYM getINTERVALYM(int i)
        throws SQLException;

    public abstract INTERVALYM getINTERVALYM(String s)
        throws SQLException;

    public abstract INTERVALDS getINTERVALDS(int i)
        throws SQLException;

    public abstract INTERVALDS getINTERVALDS(String s)
        throws SQLException;

    public abstract TIMESTAMP getTIMESTAMP(int i)
        throws SQLException;

    public abstract TIMESTAMP getTIMESTAMP(String s)
        throws SQLException;

    public abstract TIMESTAMPTZ getTIMESTAMPTZ(int i)
        throws SQLException;

    public abstract TIMESTAMPTZ getTIMESTAMPTZ(String s)
        throws SQLException;

    public abstract TIMESTAMPLTZ getTIMESTAMPLTZ(int i)
        throws SQLException;

    public abstract TIMESTAMPLTZ getTIMESTAMPLTZ(String s)
        throws SQLException;

    public abstract ResultSet getCursor(int i)
        throws SQLException;

    public abstract ResultSet getCursor(String s)
        throws SQLException;

    /**
     * @deprecated Method getCustomDatum is deprecated
     */

    public abstract CustomDatum getCustomDatum(int i, CustomDatumFactory customdatumfactory)
        throws SQLException;

    public abstract ORAData getORAData(int i, ORADataFactory oradatafactory)
        throws SQLException;

    public abstract Object getObject(int i, OracleDataFactory oracledatafactory)
        throws SQLException;

    public abstract Object getObject(String s, OracleDataFactory oracledatafactory)
        throws SQLException;

    /**
     * @deprecated Method getCustomDatum is deprecated
     */

    public abstract CustomDatum getCustomDatum(String s, CustomDatumFactory customdatumfactory)
        throws SQLException;

    public abstract ORAData getORAData(String s, ORADataFactory oradatafactory)
        throws SQLException;

    public abstract DATE getDATE(int i)
        throws SQLException;

    public abstract DATE getDATE(String s)
        throws SQLException;

    public abstract NUMBER getNUMBER(int i)
        throws SQLException;

    public abstract NUMBER getNUMBER(String s)
        throws SQLException;

    public abstract Datum getOracleObject(int i)
        throws SQLException;

    public abstract Datum getOracleObject(String s)
        throws SQLException;

    public abstract RAW getRAW(int i)
        throws SQLException;

    public abstract RAW getRAW(String s)
        throws SQLException;

    public abstract REF getREF(int i)
        throws SQLException;

    public abstract REF getREF(String s)
        throws SQLException;

    public abstract ROWID getROWID(int i)
        throws SQLException;

    public abstract ROWID getROWID(String s)
        throws SQLException;

    public abstract STRUCT getSTRUCT(int i)
        throws SQLException;

    public abstract STRUCT getSTRUCT(String s)
        throws SQLException;

    public abstract void updateARRAY(int i, ARRAY array)
        throws SQLException;

    public abstract void updateARRAY(String s, ARRAY array)
        throws SQLException;

    public abstract void updateBfile(int i, BFILE bfile)
        throws SQLException;

    public abstract void updateBFILE(int i, BFILE bfile)
        throws SQLException;

    public abstract void updateBfile(String s, BFILE bfile)
        throws SQLException;

    public abstract void updateBFILE(String s, BFILE bfile)
        throws SQLException;

    public abstract void updateBLOB(int i, BLOB blob)
        throws SQLException;

    public abstract void updateBLOB(String s, BLOB blob)
        throws SQLException;

    public abstract void updateCHAR(int i, CHAR char1)
        throws SQLException;

    public abstract void updateCHAR(String s, CHAR char1)
        throws SQLException;

    public abstract void updateCLOB(int i, CLOB clob)
        throws SQLException;

    public abstract void updateCLOB(String s, CLOB clob)
        throws SQLException;

    /**
     * @deprecated Method updateCustomDatum is deprecated
     */

    public abstract void updateCustomDatum(int i, CustomDatum customdatum)
        throws SQLException;

    public abstract void updateORAData(int i, ORAData oradata)
        throws SQLException;

    /**
     * @deprecated Method updateCustomDatum is deprecated
     */

    public abstract void updateCustomDatum(String s, CustomDatum customdatum)
        throws SQLException;

    public abstract void updateORAData(String s, ORAData oradata)
        throws SQLException;

    public abstract void updateDATE(int i, DATE date)
        throws SQLException;

    public abstract void updateDATE(String s, DATE date)
        throws SQLException;

    public abstract void updateINTERVALYM(int i, INTERVALYM intervalym)
        throws SQLException;

    public abstract void updateINTERVALYM(String s, INTERVALYM intervalym)
        throws SQLException;

    public abstract void updateINTERVALDS(int i, INTERVALDS intervalds)
        throws SQLException;

    public abstract void updateINTERVALDS(String s, INTERVALDS intervalds)
        throws SQLException;

    public abstract void updateTIMESTAMP(int i, TIMESTAMP timestamp)
        throws SQLException;

    public abstract void updateTIMESTAMP(String s, TIMESTAMP timestamp)
        throws SQLException;

    public abstract void updateTIMESTAMPTZ(int i, TIMESTAMPTZ timestamptz)
        throws SQLException;

    public abstract void updateTIMESTAMPTZ(String s, TIMESTAMPTZ timestamptz)
        throws SQLException;

    public abstract void updateTIMESTAMPLTZ(int i, TIMESTAMPLTZ timestampltz)
        throws SQLException;

    public abstract void updateTIMESTAMPLTZ(String s, TIMESTAMPLTZ timestampltz)
        throws SQLException;

    public abstract void updateNUMBER(int i, NUMBER number)
        throws SQLException;

    public abstract void updateNUMBER(String s, NUMBER number)
        throws SQLException;

    public abstract void updateOracleObject(int i, Datum datum)
        throws SQLException;

    public abstract void updateOracleObject(String s, Datum datum)
        throws SQLException;

    public abstract void updateRAW(int i, RAW raw)
        throws SQLException;

    public abstract void updateRAW(String s, RAW raw)
        throws SQLException;

    public abstract void updateREF(int i, REF ref)
        throws SQLException;

    public abstract void updateREF(String s, REF ref)
        throws SQLException;

    public abstract void updateROWID(int i, ROWID rowid)
        throws SQLException;

    public abstract void updateROWID(String s, ROWID rowid)
        throws SQLException;

    public abstract void updateSTRUCT(int i, STRUCT struct)
        throws SQLException;

    public abstract void updateSTRUCT(String s, STRUCT struct)
        throws SQLException;

    public abstract AuthorizationIndicator getAuthorizationIndicator(int i)
        throws SQLException;

    public abstract AuthorizationIndicator getAuthorizationIndicator(String s)
        throws SQLException;
}
