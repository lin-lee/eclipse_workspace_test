// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleOCIConnection.java

package oracle.jdbc.oci;

import java.sql.SQLException;
import java.util.Properties;

public class OracleOCIConnection extends oracle.jdbc.driver.OracleOCIConnection
{

    public OracleOCIConnection(String s, Properties properties, Object obj)
        throws SQLException
    {
        super(s, properties, obj);
    }
}
