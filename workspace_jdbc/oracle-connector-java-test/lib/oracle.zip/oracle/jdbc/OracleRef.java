// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleRef.java

package oracle.jdbc;

import java.sql.Ref;
import java.sql.SQLException;

// Referenced classes of package oracle.jdbc:
//            OracleTypeMetaData

public interface OracleRef
    extends Ref
{

    public abstract OracleTypeMetaData getOracleMetaData()
        throws SQLException;
}
