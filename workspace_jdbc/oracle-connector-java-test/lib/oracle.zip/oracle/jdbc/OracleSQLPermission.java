// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   OracleSQLPermission.java

package oracle.jdbc;

import java.security.BasicPermission;

public final class OracleSQLPermission extends BasicPermission
{

    private static final String allowedTargets[] = {
        "callAbort"
    };

    private final void checkTarget(String s)
    {
        for(int i = 0; i < allowedTargets.length; i++)
            if(s.equals(allowedTargets[i]))
                return;

        throw new IllegalArgumentException(s);
    }

    public OracleSQLPermission(String s)
    {
        super(s);
        checkTarget(s);
    }

    public OracleSQLPermission(String s, String s1)
    {
        super(s, s1);
        checkTarget(s);
    }

}
