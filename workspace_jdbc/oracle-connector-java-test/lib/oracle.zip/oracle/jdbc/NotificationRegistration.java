// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   NotificationRegistration.java

package oracle.jdbc;

import java.util.Properties;

public interface NotificationRegistration
{
    public static final class RegistrationState extends Enum
    {

        public static final RegistrationState ACTIVE;
        public static final RegistrationState CLOSED;
        private static final RegistrationState $VALUES[];

        public static RegistrationState[] values()
        {
            return (RegistrationState[])$VALUES.clone();
        }

        public static RegistrationState valueOf(String s)
        {
            return (RegistrationState)Enum.valueOf(oracle/jdbc/NotificationRegistration$RegistrationState, s);
        }

        static 
        {
            ACTIVE = new RegistrationState("ACTIVE", 0);
            CLOSED = new RegistrationState("CLOSED", 1);
            $VALUES = (new RegistrationState[] {
                ACTIVE, CLOSED
            });
        }

        private RegistrationState(String s, int i)
        {
            super(s, i);
        }
    }


    public abstract Properties getRegistrationOptions();

    public abstract String getDatabaseName();

    public abstract String getUserName();

    public abstract RegistrationState getState();
}
