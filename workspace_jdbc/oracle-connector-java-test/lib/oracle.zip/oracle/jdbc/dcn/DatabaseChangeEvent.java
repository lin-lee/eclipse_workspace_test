// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   DatabaseChangeEvent.java

package oracle.jdbc.dcn;

import java.util.EventObject;

// Referenced classes of package oracle.jdbc.dcn:
//            TableChangeDescription, QueryChangeDescription

public abstract class DatabaseChangeEvent extends EventObject
{
    public static final class AdditionalEventType extends Enum
    {

        public static final AdditionalEventType NONE;
        public static final AdditionalEventType TIMEOUT;
        public static final AdditionalEventType GROUPING;
        private final int code;
        private static final AdditionalEventType $VALUES[];

        public static AdditionalEventType[] values()
        {
            return (AdditionalEventType[])$VALUES.clone();
        }

        public static AdditionalEventType valueOf(String s)
        {
            return (AdditionalEventType)Enum.valueOf(oracle/jdbc/dcn/DatabaseChangeEvent$AdditionalEventType, s);
        }

        public final int getCode()
        {
            return code;
        }

        public static final AdditionalEventType getEventType(int i)
        {
            if(i == TIMEOUT.getCode())
                return TIMEOUT;
            if(i == GROUPING.getCode())
                return GROUPING;
            else
                return NONE;
        }

        static 
        {
            NONE = new AdditionalEventType("NONE", 0, 0);
            TIMEOUT = new AdditionalEventType("TIMEOUT", 1, 1);
            GROUPING = new AdditionalEventType("GROUPING", 2, 2);
            $VALUES = (new AdditionalEventType[] {
                NONE, TIMEOUT, GROUPING
            });
        }

        private AdditionalEventType(String s, int i, int j)
        {
            super(s, i);
            code = j;
        }
    }

    public static final class EventType extends Enum
    {

        public static final EventType NONE;
        public static final EventType STARTUP;
        public static final EventType SHUTDOWN;
        public static final EventType SHUTDOWN_ANY;
        public static final EventType DEREG;
        public static final EventType OBJCHANGE;
        public static final EventType QUERYCHANGE;
        private final int code;
        private static final EventType $VALUES[];

        public static EventType[] values()
        {
            return (EventType[])$VALUES.clone();
        }

        public static EventType valueOf(String s)
        {
            return (EventType)Enum.valueOf(oracle/jdbc/dcn/DatabaseChangeEvent$EventType, s);
        }

        public final int getCode()
        {
            return code;
        }

        public static final EventType getEventType(int i)
        {
            if(i == STARTUP.getCode())
                return STARTUP;
            if(i == SHUTDOWN.getCode())
                return SHUTDOWN;
            if(i == SHUTDOWN_ANY.getCode())
                return SHUTDOWN_ANY;
            if(i == DEREG.getCode())
                return DEREG;
            if(i == OBJCHANGE.getCode())
                return OBJCHANGE;
            if(i == QUERYCHANGE.getCode())
                return QUERYCHANGE;
            else
                return NONE;
        }

        static 
        {
            NONE = new EventType("NONE", 0, 0);
            STARTUP = new EventType("STARTUP", 1, 1);
            SHUTDOWN = new EventType("SHUTDOWN", 2, 2);
            SHUTDOWN_ANY = new EventType("SHUTDOWN_ANY", 3, 3);
            DEREG = new EventType("DEREG", 4, 5);
            OBJCHANGE = new EventType("OBJCHANGE", 5, 6);
            QUERYCHANGE = new EventType("QUERYCHANGE", 6, 7);
            $VALUES = (new EventType[] {
                NONE, STARTUP, SHUTDOWN, SHUTDOWN_ANY, DEREG, OBJCHANGE, QUERYCHANGE
            });
        }

        private EventType(String s, int i, int j)
        {
            super(s, i);
            code = j;
        }
    }


    private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
    public static final boolean TRACE = false;

    protected DatabaseChangeEvent(Object obj)
    {
        super(obj);
    }

    public abstract EventType getEventType();

    public abstract AdditionalEventType getAdditionalEventType();

    public abstract TableChangeDescription[] getTableChangeDescription();

    public abstract QueryChangeDescription[] getQueryChangeDescription();

    public abstract String getConnectionInformation();

    public abstract String getDatabaseName();

    /**
     * @deprecated Method getRegistrationId is deprecated
     */

    public abstract int getRegistrationId();

    public abstract long getRegId();

    public abstract byte[] getTransactionId();

    public abstract String getTransactionId(boolean flag);

    public abstract String toString();

}
