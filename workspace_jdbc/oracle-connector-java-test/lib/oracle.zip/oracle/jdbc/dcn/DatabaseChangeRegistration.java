// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   DatabaseChangeRegistration.java

package oracle.jdbc.dcn;

import java.sql.SQLException;
import java.util.concurrent.Executor;
import oracle.jdbc.NotificationRegistration;

// Referenced classes of package oracle.jdbc.dcn:
//            DatabaseChangeListener

public interface DatabaseChangeRegistration
    extends NotificationRegistration
{

    /**
     * @deprecated Method getRegistrationId is deprecated
     */

    public abstract int getRegistrationId();

    public abstract long getRegId();

    public abstract String[] getTables();

    public abstract void addListener(DatabaseChangeListener databasechangelistener)
        throws SQLException;

    public abstract void addListener(DatabaseChangeListener databasechangelistener, Executor executor)
        throws SQLException;

    public abstract void removeListener(DatabaseChangeListener databasechangelistener)
        throws SQLException;
}
