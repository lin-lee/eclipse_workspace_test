// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   DatabaseChangeListener.java

package oracle.jdbc.dcn;

import java.util.EventListener;

// Referenced classes of package oracle.jdbc.dcn:
//            DatabaseChangeEvent

public interface DatabaseChangeListener
    extends EventListener
{

    public abstract void onDatabaseChangeNotification(DatabaseChangeEvent databasechangeevent);
}
