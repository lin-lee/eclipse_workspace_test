// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   TableChangeDescription.java

package oracle.jdbc.dcn;

import java.util.EnumSet;

// Referenced classes of package oracle.jdbc.dcn:
//            RowChangeDescription

public interface TableChangeDescription
{
    public static final class TableOperation extends Enum
    {

        public static final TableOperation ALL_ROWS;
        public static final TableOperation INSERT;
        public static final TableOperation UPDATE;
        public static final TableOperation DELETE;
        public static final TableOperation ALTER;
        public static final TableOperation DROP;
        private final int code;
        private static final TableOperation $VALUES[];

        public static TableOperation[] values()
        {
            return (TableOperation[])$VALUES.clone();
        }

        public static TableOperation valueOf(String s)
        {
            return (TableOperation)Enum.valueOf(oracle/jdbc/dcn/TableChangeDescription$TableOperation, s);
        }

        public final int getCode()
        {
            return code;
        }

        public static final EnumSet getTableOperations(int i)
        {
            EnumSet enumset = EnumSet.noneOf(oracle/jdbc/dcn/TableChangeDescription$TableOperation);
            if((i & ALL_ROWS.getCode()) != 0)
                enumset.add(ALL_ROWS);
            if((i & INSERT.getCode()) != 0)
                enumset.add(INSERT);
            if((i & UPDATE.getCode()) != 0)
                enumset.add(UPDATE);
            if((i & DELETE.getCode()) != 0)
                enumset.add(DELETE);
            if((i & ALTER.getCode()) != 0)
                enumset.add(ALTER);
            if((i & DROP.getCode()) != 0)
                enumset.add(DROP);
            return enumset;
        }

        static 
        {
            ALL_ROWS = new TableOperation("ALL_ROWS", 0, 1);
            INSERT = new TableOperation("INSERT", 1, 2);
            UPDATE = new TableOperation("UPDATE", 2, 4);
            DELETE = new TableOperation("DELETE", 3, 8);
            ALTER = new TableOperation("ALTER", 4, 16);
            DROP = new TableOperation("DROP", 5, 32);
            $VALUES = (new TableOperation[] {
                ALL_ROWS, INSERT, UPDATE, DELETE, ALTER, DROP
            });
        }

        private TableOperation(String s, int i, int j)
        {
            super(s, i);
            code = j;
        }
    }


    public abstract EnumSet getTableOperations();

    public abstract String getTableName();

    public abstract int getObjectNumber();

    public abstract RowChangeDescription[] getRowChangeDescription();
}
