// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   RowChangeDescription.java

package oracle.jdbc.dcn;

import oracle.sql.ROWID;

// Referenced classes of package oracle.jdbc.dcn:
//            TableChangeDescription

public interface RowChangeDescription
{
    public static final class RowOperation extends Enum
    {

        public static final RowOperation INSERT;
        public static final RowOperation UPDATE;
        public static final RowOperation DELETE;
        private final int code;
        private static final RowOperation $VALUES[];

        public static RowOperation[] values()
        {
            return (RowOperation[])$VALUES.clone();
        }

        public static RowOperation valueOf(String s)
        {
            return (RowOperation)Enum.valueOf(oracle/jdbc/dcn/RowChangeDescription$RowOperation, s);
        }

        public final int getCode()
        {
            return code;
        }

        public static final RowOperation getRowOperation(int i)
        {
            if(i == INSERT.getCode())
                return INSERT;
            if(i == UPDATE.getCode())
                return UPDATE;
            else
                return DELETE;
        }

        static 
        {
            INSERT = new RowOperation("INSERT", 0, TableChangeDescription.TableOperation.INSERT.getCode());
            UPDATE = new RowOperation("UPDATE", 1, TableChangeDescription.TableOperation.UPDATE.getCode());
            DELETE = new RowOperation("DELETE", 2, TableChangeDescription.TableOperation.DELETE.getCode());
            $VALUES = (new RowOperation[] {
                INSERT, UPDATE, DELETE
            });
        }

        private RowOperation(String s, int i, int j)
        {
            super(s, i);
            code = j;
        }
    }


    public abstract RowOperation getRowOperation();

    public abstract ROWID getRowid();
}
