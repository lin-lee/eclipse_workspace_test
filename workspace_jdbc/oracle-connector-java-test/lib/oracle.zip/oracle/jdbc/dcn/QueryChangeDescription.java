// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   QueryChangeDescription.java

package oracle.jdbc.dcn;


// Referenced classes of package oracle.jdbc.dcn:
//            TableChangeDescription, DatabaseChangeEvent

public interface QueryChangeDescription
{
    public static final class QueryChangeEventType extends Enum
    {

        public static final QueryChangeEventType DEREG;
        public static final QueryChangeEventType QUERYCHANGE;
        private final int code;
        private static final QueryChangeEventType $VALUES[];

        public static QueryChangeEventType[] values()
        {
            return (QueryChangeEventType[])$VALUES.clone();
        }

        public static QueryChangeEventType valueOf(String s)
        {
            return (QueryChangeEventType)Enum.valueOf(oracle/jdbc/dcn/QueryChangeDescription$QueryChangeEventType, s);
        }

        public final int getCode()
        {
            return code;
        }

        public static final QueryChangeEventType getQueryChangeEventType(int i)
        {
            if(i == DEREG.getCode())
                return DEREG;
            else
                return QUERYCHANGE;
        }

        static 
        {
            DEREG = new QueryChangeEventType("DEREG", 0, DatabaseChangeEvent.EventType.DEREG.getCode());
            QUERYCHANGE = new QueryChangeEventType("QUERYCHANGE", 1, DatabaseChangeEvent.EventType.QUERYCHANGE.getCode());
            $VALUES = (new QueryChangeEventType[] {
                DEREG, QUERYCHANGE
            });
        }

        private QueryChangeEventType(String s, int i, int j)
        {
            super(s, i);
            code = j;
        }
    }


    public abstract long getQueryId();

    public abstract QueryChangeEventType getQueryChangeEventType();

    public abstract TableChangeDescription[] getTableChangeDescription();
}
